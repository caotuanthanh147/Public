if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
	if type(f) == t then return f end
	return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
Services = setmetatable({}, {
	__index = function(self, name)
		local success, cache = pcall(function()
			return cloneref(game:GetService(name))
		end)
		if success then
			rawset(self, name, cache)
			return cache
		else
			error("Invalid Service: " .. tostring(name))
		end
	end
})
local Players = Services.Players
local Plr = Players.LocalPlayer
local PGui = Plr.PlayerGui
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
}
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local function notyuri()
end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true 
Library.ShowCustomCursor = true 
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "q8QX76jyz"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end
local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
}
local Tables = {
}
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
    AutoSkipDialogue = nil,
}
local function AddMultiDropdown(group, id, config)
    config = config or {}
    local labelId = config.label
    group:AddDropdown(id, {
        Text = config.Text,
        Values = config.Values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    return function()
        local labels = (Options[id] and Options[id].Value) or {}
        local ids = {}
        for label, active in pairs(labels) do
            if active then
                if labelId then
                    local mappedId = labelId[label]
                    if mappedId then ids[mappedId] = true end
                else
                    ids[label] = true
                end
            end
        end
        return ids
    end
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local function SafeInvoke(remote, ...)
    local args = {...}
    local result = nil
    task.spawn(function()
        local success, res = pcall(function()
            return remote:InvokeServer(unpack(args))
        end)
        result = res
    end)
    local start = tick()
    repeat task.wait() until result ~= nil or (tick() - start) > 2 
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Function then
                task.spawn(connection.Function, ...)
            end
        end
    else
        notyuri("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags 
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            local newThread = task.spawn(featureFunc, ...)
            currentTable[flagKey] = newThread
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            notyuri("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
function AddSliderToggle(Config)
    local Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false
    })
    local Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    Toggle:OnChanged(function()
        Slider:SetVisible(Toggle.Value)
    end)
    return Toggle, Slider
end
local function GetCharacter()
    local c = Plr.Character
    return (c and GetObject(c, "HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            pcall(function()
                local promptOverlay = GetObject(game:GetService("CoreGui"), "RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = GetObject(promptOverlay.promptOverlay, "ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Plr)
                    end
                end
            end)
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local success, err = pcall(function()
            local pauseGui = GetObject(game:GetService("CoreGui").RobloxGui, "CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    local prevDist = target.MaxActivationDistance
    if teleport then
        local char = GetCharacter()
        local hrp = char and GetObject(char, "HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local partPos = isModel and part:GetPivot().Position or part.Position
            local dist = (hrp.Position - partPos).Magnitude
            if dist > prevDist then
                local partCFrame = isModel and part:GetPivot() or part.CFrame
                hrp.CFrame = partCFrame
                task.wait(0.2)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and GetObject(Plr.Character, "HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, 1)
        task.wait()
        firetouchinterest(part, root, 0)
    end)
end
local SharedConfig = GetObject(RS, "Shared.Config")
local CafeRecipeConfig = SharedConfig and GetSafeModule(SharedConfig, "CafeRecipeConfig") or nil
local CafeOrderGuideConfig = SharedConfig and GetSafeModule(SharedConfig, "CafeOrderGuideConfig") or nil
local CafeConfig = SharedConfig and GetSafeModule(SharedConfig, "CafeConfig") or nil
if not CafeConfig then
    notyuri("[Cafe] ReplicatedStorage.Shared.Config.CafeConfig not found/failed to load - AutoCoffee sanity threshold cannot run")
end
local UpgradesConfig = SharedConfig and GetSafeModule(SharedConfig, "Upgrades") or nil
if not UpgradesConfig then
    notyuri("[Cafe] ReplicatedStorage.Shared.Config.Upgrades not found/failed to load - AutoUpgrade cannot run")
end
local function GetSessionUpgrades()
    if not UpgradesConfig then return {} end
    local raw = RS:GetAttribute("CafeUpgrades")
    if typeof(raw) ~= "string" then
        return UpgradesConfig.GetDefaultLevels()
    end
    local ok, result = pcall(function()
        return HttpService:JSONDecode(raw)
    end)
    if ok and typeof(result) == "table" then
        return result
    end
    return UpgradesConfig.GetDefaultLevels()
end
local SharedConstants = GetObject(RS, "Shared.Constants")
local RunState = SharedConstants and GetSafeModule(SharedConstants, "RunState") or nil
if not RunState then
    notyuri("[Cafe] ReplicatedStorage.Shared.Constants.RunState not found/failed to load - AutoRetry cannot run")
end
local SharedModules = GetObject(RS, "Shared.Modules")
local BackpackUtil = SharedModules and GetSafeModule(SharedModules, "BackpackUtil") or nil
if not BackpackUtil then
    notyuri("[Cafe] ReplicatedStorage.Shared.Modules.BackpackUtil not found/failed to load - hold-limit checks disabled")
end
local ClientModules = GetObject(Plr, "PlayerScripts.Client.Modules")
local CafeOrderGuideResolver = ClientModules and GetSafeModule(ClientModules, "CafeOrderGuideResolver") or nil
if not CafeOrderGuideResolver then
    notyuri("[Cafe] PlayerScripts.Client.Modules.CafeOrderGuideResolver not found/failed to load - AutoCook inventory-match check disabled")
end
if not CafeOrderGuideConfig then
    notyuri("[Cafe] ReplicatedStorage.Shared.Config.CafeOrderGuideConfig not found/failed to load - AutoCook cannot run")
end
local PackagesFolder = GetObject(RS, "Packages")
local BridgeNet2 = PackagesFolder and GetSafeModule(PackagesFolder, "BridgeNet2")
local function SafeReferenceBridge(name)
    if not BridgeNet2 then return nil end
    local ok, result = pcall(BridgeNet2.ReferenceBridge, name)
    if ok then
        return result
    end
    notyuri("[Cafe] BridgeNet2.ReferenceBridge(\"" .. name .. "\") failed/timed out - skipping: " .. tostring(result))
    return nil
end
local _bridgeCache = {}
local function GetBridge(name)
    if _bridgeCache[name] then
        return _bridgeCache[name]
    end
    local bridge = SafeReferenceBridge(name)
    if bridge then
        _bridgeCache[name] = bridge
    end
    return bridge
end
if not BridgeNet2 then
    notyuri("[Cafe] ReplicatedStorage.Packages.BridgeNet2 not found/failed to load - AutoSkipDialogue/AutoOrder(fly)/AutoCoffee cannot run")
end
local Scriptables = GetObject(workspace, "Scriptables")
local SupportedFoodTypes = { Waffle = true, Pancake = true, Coffee = true, ["Decaf Coffee"] = true, ["Creamer Coffee"] = true, ["Iced Creamer Coffee"] = true, Milkshake = true, ["Orange Juice"] = true, ["Banana Juice"] = true, ["Apple Juice"] = true, Croissant = true }
local function ReadOrderState(orderFrame)
    local toppings = {}
    if CafeOrderGuideConfig then
        for _, toppingName in ipairs(CafeOrderGuideConfig.ToppingAttributes) do
            toppings[toppingName] = orderFrame:GetAttribute("Topping_" .. toppingName) == true
        end
    end
    return {
        OrderId = orderFrame:GetAttribute("OrderId"),
        CustomerId = orderFrame:GetAttribute("CustomerId"),
        RecipeId = orderFrame:GetAttribute("RecipeId"),
        RecipeName = orderFrame:GetAttribute("RecipeName"),
        FoodType = orderFrame:GetAttribute("FoodType") or orderFrame:GetAttribute("RecipeId"),
        Doneness = orderFrame:GetAttribute("Doneness"),
        Flavor = orderFrame:GetAttribute("Flavor"),
        Plate = orderFrame:GetAttribute("Plate"),
        Syrup = orderFrame:GetAttribute("Syrup"),
        WhippedCream = orderFrame:GetAttribute("WhippedCream"),
        Toppings = toppings,
    }
end
local function GetOrderBoard()
    local ordersModel = Scriptables and GetObject(Scriptables, "Orders")
    return ordersModel and GetObject(ordersModel, "OrderFrame.SurfaceGui.OrderBoard")
end
local function GetNextSupportedOrder()
    local OrderBoard = GetOrderBoard()
    if not OrderBoard then return nil end
    for _, child in ipairs(OrderBoard:GetChildren()) do
        if child:IsA("Frame") and child.Name:sub(1, 6) == "Order_" then
            local state = ReadOrderState(child)
            if state.FoodType and SupportedFoodTypes[state.FoodType] then
                return state
            end
        end
    end
    return nil
end
local function GetSupportedOrders(excludeOrderIds)
    local list = {}
    local OrderBoard = GetOrderBoard()
    if not OrderBoard then return list end
    for _, child in ipairs(OrderBoard:GetChildren()) do
        if child:IsA("Frame") and child.Name:sub(1, 6) == "Order_" then
            local state = ReadOrderState(child)
            if state.FoodType and SupportedFoodTypes[state.FoodType] then
                if not (excludeOrderIds and excludeOrderIds[state.OrderId]) then
                    table.insert(list, state)
                end
            end
        end
    end
    return list
end
local function GetBackpackOrHeldTool(name)
    local char = Plr.Character
    if char then
        local held = char:FindFirstChildOfClass("Tool")
        if held and (not name or held.Name == name) then
            return held
        end
    end
    local backpack = Plr:FindFirstChildOfClass("Backpack")
    if backpack then
        for _, tool in ipairs(backpack:GetChildren()) do
            if tool:IsA("Tool") and (not name or tool.Name == name) then
                return tool
            end
        end
    end
    return nil
end
local function CanHoldMore(count)
    if not BackpackUtil then return true end 
    return BackpackUtil.CanAddTools(Plr, count or 1)
end
local function EquipTool(tool)
    if not tool then return end
    local char = Plr.Character
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if hum then
        hum:EquipTool(tool)
    end
end
local function PlaceToolWithRetry(toolName, station, placePrompt, maxAttempts)
    maxAttempts = maxAttempts or 5
    local tool = GetBackpackOrHeldTool(toolName)
    if not tool then
        notyuri("[Cafe] Not holding " .. toolName .. ", cannot place on " .. station.Name)
        return false
    end
    for attempt = 1, maxAttempts do
        if station:GetAttribute("Occupied") == true then
            return true
        end
        tool = GetBackpackOrHeldTool(toolName)
        if not tool then
            notyuri("[Cafe] Lost " .. toolName .. " mid-placement (attempt " .. attempt .. ")")
            return false
        end
        EquipTool(tool)
        task.wait(0.1)
        FirePP(placePrompt, true)
        task.wait(0.25)
        if station:GetAttribute("Occupied") == true then
            return true
        end
        if attempt < maxAttempts then
            notyuri("[Cafe] " .. toolName .. " not placed on " .. station.Name .. ", retrying (" .. attempt .. "/" .. maxAttempts .. ")")
            task.wait(0.2)
        end
    end
    notyuri("[Cafe] Failed to place " .. toolName .. " on " .. station.Name .. " after " .. maxAttempts .. " attempts")
    return false
end
local function NewLock()
    local busy = false
    local lock
    lock = {
        wait = function()
            while busy do task.wait() end
            busy = true
        end,
        release = function()
            busy = false
        end,
        withLock = function(fn, ...)
            lock.wait()
            local results = table.pack(pcall(fn, ...))
            lock.release()
            if not results[1] then
                error(results[2], 0)
            end
            return table.unpack(results, 2, results.n)
        end,
    }
    return lock
end
local CharacterLock = NewLock()
local function GetFoodInteractables()
    return Scriptables and GetObject(Scriptables, "Food Interactables")
end
local function FindPickupPrompt(toolGivenName)
    local foodInteractables = GetFoodInteractables()
    local PickupFolder = foodInteractables and GetObject(foodInteractables, "Pickup")
    if not PickupFolder then return nil end
    for _, model in ipairs(PickupFolder:GetChildren()) do
        local interactable = GetObject(model, "Interactable") or model
        if interactable:GetAttribute("ToolGiven") == toolGivenName then
            local prompt = interactable:FindFirstChildWhichIsA("ProximityPrompt", true)
            if prompt then return prompt end
        end
    end
    return nil
end
local function FindApplyPrompt(appliedIngredient, foodType)
    local foodInteractables = GetFoodInteractables()
    local ApplyFolder = foodInteractables and GetObject(foodInteractables, "ApplyToHeldFood")
    if not ApplyFolder then return nil end
    for _, model in ipairs(ApplyFolder:GetChildren()) do
        local interactable = GetObject(model, "Interactable") or model
        if interactable:GetAttribute("AppliedIngredient") == appliedIngredient then
            local prompt = interactable:FindFirstChildWhichIsA("ProximityPrompt", true)
            if prompt then return prompt end
        end
    end
    return nil
end
local function GetBowlMissingIngredients(bowl)
    local required = (CafeOrderGuideConfig and CafeOrderGuideConfig.RequiredBowlIngredients)
        or { "Scoop of Flour", "Egg", "Sugar Cube", "Uncapped Milk" }
    local attrMap = CafeOrderGuideConfig and CafeOrderGuideConfig.BowlIngredientAttributes or {}
    local missing = {}
    local debugGui = GetObject(bowl, "CookingBowlDebug")
    local bg = debugGui and GetObject(debugGui, "Background")
    for _, ingName in ipairs(required) do
        local attrName = attrMap[ingName]
        if attrName then
            if bowl:GetAttribute(attrName) ~= true then
                table.insert(missing, ingName)
            end
        elseif bg then
            local img = bg:FindFirstChild(ingName)
            if img and img:IsA("ImageLabel") then
                if img.ImageTransparency >= 0.5 and img.ImageTransparency <= 0.6 then
                    table.insert(missing, ingName)
                end
            else
                table.insert(missing, ingName)
            end
        else
            table.insert(missing, ingName) 
        end
    end
    return missing
end
local BowlsInUse = {}
local function FindFreeBatterBowl()
    if not Scriptables then return nil end
    for _, obj in ipairs(Scriptables:GetChildren()) do
        if obj.Name:sub(1, 10) == "BatterBowl" and not BowlsInUse[obj] then
            return obj
        end
    end
    return nil
end
local function FillBowl(bowl)
    local bowlPrompt = GetObject(bowl, "CookingPrompt")
    if not bowlPrompt then
        notyuri("[Cafe] BatterBowl CookingPrompt not found")
        return false
    end
    local missing = GetBowlMissingIngredients(bowl)
    for _, ingName in ipairs(missing) do
        if bowl:GetAttribute("Ready") == true then break end
        local shouldStop = false
        CharacterLock.withLock(function()
            local tool = GetBackpackOrHeldTool(ingName)
            if tool then
                EquipTool(tool)
                task.wait(0.1)
                FirePP(bowlPrompt, true)
                task.wait(0.3)
                return
            end
            if not CanHoldMore(1) then
                notyuri("[Cafe] Backpack full (5/5), cannot pick up ingredient: " .. ingName)
                shouldStop = true
                return
            end
            local pickupPrompt = FindPickupPrompt(ingName)
            if not pickupPrompt then
                notyuri("[Cafe] No pickup prompt found for ingredient: " .. ingName)
            else
                FirePP(pickupPrompt, true)
                task.wait(0.3)
                tool = GetBackpackOrHeldTool(ingName)
                if tool then
                    EquipTool(tool)
                    task.wait(0.1)
                    FirePP(bowlPrompt, true)
                    task.wait(0.3)
                else
                    notyuri("[Cafe] Did not receive expected tool: " .. ingName)
                end
            end
        end)
        if shouldStop then break end
    end
    return bowl:GetAttribute("Ready") == true
end
local BridgeNetPackage = RS:FindFirstChild("ffrostflame_bridgenet2@1.0.0")
local DataRemoteEvent = BridgeNetPackage and GetObject(BridgeNetPackage, "dataRemoteEvent")
local function WaitForGrillCooked(grillPart, timeoutSec)
    local start = tick()
    repeat
        if grillPart:GetAttribute("CookingStage") == "Cooked" then
            return true
        end
        task.wait()
    until (tick() - start) > (timeoutSec or 60)
    return false
end
local function WaitForPancakeFlipReady(grillPart, timeoutSec)
    local start = tick()
    local meter
    repeat
        local billboard = GetObject(grillPart, "CookingMeterBillboard")
        meter = billboard and GetObject(billboard, "PancakeMeterProgress")
        if meter then break end
        task.wait()
    until (tick() - start) > (timeoutSec or 60)
    if not meter then
        notyuri("[Cafe] PancakeMeterProgress not found on " .. grillPart.Name)
        return false
    end
    local lastValue = meter.Value
    repeat
        local currentValue = meter.Value
        if currentValue < lastValue then
            return true
        end
        lastValue = currentValue
        task.wait()
    until (tick() - start) > (timeoutSec or 60)
    return false
end
local function FindGrillInstances(grillName)
    local list = {}
    local GrillsFolder = Scriptables and GetObject(Scriptables, "Grills")
    if not GrillsFolder or not grillName then return list end
    for _, child in ipairs(GrillsFolder:GetChildren()) do
        if child.Name == grillName or child.Name:sub(1, #grillName) == grillName then
            table.insert(list, child)
        end
    end
    return list
end
local function FindFreeGrillInstance(grillName)
    for _, grillPart in ipairs(FindGrillInstances(grillName)) do
        if grillPart:GetAttribute("Occupied") ~= true then
            return grillPart
        end
    end
    return nil
end
local function FindGrillPromptByAction(grillPart, action)
    for _, child in ipairs(grillPart:GetChildren()) do
        if child.Name == "CookingPrompt" and child:GetAttribute("CookingGrillAction") == action then
            return child
        end
    end
    return nil
end
local function PlaceBatterOnGrill(foodType)
    if not CafeOrderGuideConfig then
        notyuri("[Cafe] CafeOrderGuideConfig not loaded, cannot resolve grill/batter tool")
        return nil
    end
    local recipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes[foodType]
    if not recipeCfg or not recipeCfg.GrillName then
        notyuri("[Cafe] No grill recipe config for FoodType: " .. tostring(foodType))
        return nil
    end
    local grillPart = FindFreeGrillInstance(recipeCfg.GrillName)
    if not grillPart then
        return nil
    end
    local takePrompt = FindGrillPromptByAction(grillPart, "Take")
    if not takePrompt then
        notyuri("[Cafe] Grill CookingPrompt (Take) not found on " .. grillPart.Name)
        return nil
    end
    local flipPrompt = FindGrillPromptByAction(grillPart, "Flip")
    if foodType == "Pancake" and not flipPrompt then
        notyuri("[Cafe] Grill CookingPrompt (Flip) not found on " .. grillPart.Name)
        return nil
    end
    local batterName = CafeOrderGuideConfig.BatterTool or "Batter"
    local placed = false
    CharacterLock.withLock(function()
        placed = PlaceToolWithRetry(batterName, grillPart, takePrompt)
    end)
    if not placed then
        return nil
    end
    return grillPart, takePrompt, flipPrompt
end
local function WaitAndCollectFromGrill(grillPart, takePrompt, flipPrompt, foodType)
    if foodType == "Pancake" then
        local flipReady = WaitForPancakeFlipReady(grillPart, 90)
        if flipReady then
            CharacterLock.withLock(function()
                FirePP(flipPrompt, true)
                task.wait(0.2)
            end)
        end
    end
    local cooked = WaitForGrillCooked(grillPart, 90)
    if not cooked then
        notyuri("[Cafe] Timed out waiting for cook-complete on " .. grillPart.Name)
        return false
    end
    task.wait(0.2)
    local ok = true
    CharacterLock.withLock(function()
        if not CanHoldMore(1) then
            notyuri("[Cafe] Backpack full (5/5), cannot pick up cooked food from grill")
            ok = false
            return
        end
        FirePP(takePrompt, true)
        task.wait(0.2)
    end)
    return ok
end
local function FindCoffeeMakerInstance(coffeeMakerName, free)
    if not Scriptables or not coffeeMakerName then return nil end
    for _, descendant in ipairs(Scriptables:GetDescendants()) do
        if descendant.Name == coffeeMakerName and descendant:GetAttribute("Occupied") ~= nil then
            local occupied = descendant:GetAttribute("Occupied") == true
            if free then
                if not occupied then return descendant end
            else
                if occupied then return descendant end
            end
        end
    end
    return nil
end
local function FindPromptsFolder()
    return GetObject(workspace, "Main.Prompts")
end
local function FindCroissantStations(nameList, attrName, freeOnly)
    local PromptsFolder = FindPromptsFolder()
    local list = {}
    local seen = {}
    if PromptsFolder and nameList then
        for _, name in ipairs(nameList) do
            local inst = PromptsFolder:FindFirstChild(name)
            if inst and not seen[inst] and (not freeOnly or inst:GetAttribute("Occupied") ~= true) then
                seen[inst] = true
                table.insert(list, inst)
            end
        end
    end
    return list
end
local function FindFreeCroissantPinBoard()
    local recipeCfg = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Croissant"]
    local nameList = recipeCfg and recipeCfg.PinBoardNames
    return FindCroissantStations(nameList, "CroissantPinBoardSubject")[1]
end
local function FindFreeCroissantOven()
    local recipeCfg = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Croissant"]
    local nameList = recipeCfg and recipeCfg.OvenNames
    return FindCroissantStations(nameList, "CroissantOvenSubject", true)[1]
end
local function WaitForCroissantOvenCooked(ovenPart, timeoutSec)
    local start = tick()
    repeat
        if ovenPart:GetAttribute("Ready") == true then
            return true
        end
        task.wait()
    until (tick() - start) > (timeoutSec or 90)
    return false
end
local function PlaceBatterOnPinBoard()
    if not CafeOrderGuideConfig then
        notyuri("[Cafe] CafeOrderGuideConfig not loaded, cannot resolve pin board/batter tool")
        return nil
    end
    local pinBoard = FindFreeCroissantPinBoard()
    if not pinBoard then
        return nil
    end
    local rollPrompt = GetObject(pinBoard, "default.CookingPrompt")
    if not rollPrompt then
        notyuri("[Cafe] PinBoard CookingPrompt (Roll) not found on " .. pinBoard.Name)
        return nil
    end
    local batterName = CafeOrderGuideConfig.BatterTool or "Batter"
    local fired = false
    CharacterLock.withLock(function()
        local tool = GetBackpackOrHeldTool(batterName)
        if not tool then
            notyuri("[Cafe] Not holding " .. batterName .. ", cannot place on " .. pinBoard.Name)
            return
        end
        EquipTool(tool)
        task.wait(0.1)
        if not rollPrompt.Enabled then
            notyuri("[Cafe] PinBoard Roll prompt not enabled on " .. pinBoard.Name)
            return
        end
        FirePP(rollPrompt, true)
        task.wait(0.25)
        fired = true
    end)
    if not fired then
        return nil
    end
    return pinBoard
end
local function WaitForCroissantDoughTool(timeoutSec)
    local start = tick()
    repeat
        local tool = GetBackpackOrHeldTool()
        if tool and tool:GetAttribute("IsRecipeFood") == true and tool:GetAttribute("FoodType") == "Croissant" and tool:GetAttribute("Doneness") == "Uncooked" then
            return tool
        end
        task.wait()
    until (tick() - start) > (timeoutSec or 30)
    return nil
end
local function BakeCroissant(doughTool)
    local oven = FindFreeCroissantOven()
    if not oven then
        return nil
    end
    local bakePrompt = GetObject(oven, "Handle.CookingPrompt")
    if not bakePrompt then
        notyuri("[Cafe] Oven CookingPrompt (Bake) not found on " .. oven.Name)
        return nil
    end
    local placed = false
    CharacterLock.withLock(function()
        EquipTool(doughTool)
        task.wait(0.1)
        placed = PlaceToolWithRetry(doughTool.Name, oven, bakePrompt)
    end)
    if not placed then
        return nil
    end
    return oven, bakePrompt
end
local function WaitAndCollectFromOven(oven, bakePrompt)
    local cooked = WaitForCroissantOvenCooked(oven, 90)
    if not cooked then
        notyuri("[Cafe] Timed out waiting for cook-complete on " .. oven.Name)
        return false
    end
    task.wait(0.2)
    local ok = true
    CharacterLock.withLock(function()
        if not CanHoldMore(1) then
            notyuri("[Cafe] Backpack full (5/5), cannot pick up cooked Croissant from oven")
            ok = false
            return
        end
        FirePP(bakePrompt, true)
        task.wait(0.2)
    end)
    return ok
end
local function FindStartedAtAttribute(instance)
    for attrName, attrValue in pairs(instance:GetAttributes()) do
        if attrName:sub(-9) == "StartedAt" and typeof(attrValue) == "number" then
            return attrValue
        end
    end
    return nil
end
local function ClearBurn()
    local TrashPrompt = GetObject(workspace, "Main.Prompts.TrashBin.TrashBin.Trash.TrashPrompt")
    if not TrashPrompt then
        notyuri("[Cafe] Trash.TrashPrompt not found - cannot clear burnt items")
        return
    end
    local CookTimeout = 60
    local GrillsFolder = Scriptables and GetObject(Scriptables, "Grills")
    if GrillsFolder then
        for _, grillPart in ipairs(GrillsFolder:GetChildren()) do
            local burnt = grillPart:GetAttribute("CookingStage") == "Burnt"
            local stuck = false
            if not burnt and grillPart:GetAttribute("Occupied") == true then
                local startedAt = FindStartedAtAttribute(grillPart)
                if startedAt and (workspace:GetServerTimeNow() - startedAt) > CookTimeout then
                    stuck = true
                end
            end
            if burnt or stuck then
                local takePrompt = FindGrillPromptByAction(grillPart, "Take")
                if takePrompt then
                    CharacterLock.withLock(function()
                        if not CanHoldMore(1) then
                            notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. (burnt and "burnt" or "stuck") .. " item from " .. grillPart.Name)
                            return
                        end
                        FirePP(takePrompt, true)
                        task.wait(0.2)
                        FirePP(TrashPrompt, true)
                        task.wait(0.2)
                    end)
                else
                    notyuri("[Cafe] " .. (burnt and "Burnt" or "Stuck") .. " item on " .. grillPart.Name .. " but no Take prompt found")
                end
            end
        end
    end
    local stationNames = {}
    local milkshakeMixerName = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes.Milkshake and CafeOrderGuideConfig.Recipes.Milkshake.MixerName
    if milkshakeMixerName then
        table.insert(stationNames, milkshakeMixerName)
    end
    local coffeeMakerName = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes.Coffee and CafeOrderGuideConfig.Recipes.Coffee.CoffeeMakerName
    if coffeeMakerName then
        table.insert(stationNames, coffeeMakerName)
    end
    local blenderName = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Orange Juice"] and CafeOrderGuideConfig.Recipes["Orange Juice"].BlenderName
    if blenderName then
        table.insert(stationNames, blenderName)
    end
    for _, stationName in ipairs(stationNames) do
        local station = FindCoffeeMakerInstance(stationName, false)
        if station then
            local overmixed = station:GetAttribute("Overmixed") == true
            local stuck = false
            if not overmixed then
                local startedAt = FindStartedAtAttribute(station)
                if startedAt and (workspace:GetServerTimeNow() - startedAt) > CookTimeout then
                    stuck = true
                end
            end
            if overmixed or stuck then
                local cookingPrompt = GetObject(station, "Handle.CookingPrompt")
                if cookingPrompt then
                    CharacterLock.withLock(function()
                        if not CanHoldMore(1) then
                            notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. (overmixed and "overmixed" or "stuck") .. " item from " .. station.Name)
                            return
                        end
                        FirePP(cookingPrompt, true)
                        task.wait(0.2)
                        FirePP(TrashPrompt, true)
                        task.wait(0.2)
                    end)
                else
                    notyuri("[Cafe] " .. (overmixed and "Overmixed" or "Stuck") .. " item on " .. station.Name .. " but no CookingPrompt found")
                end
            end
        end
    end
    local croissantRecipeCfg = CafeOrderGuideConfig and CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Croissant"]
    local ovenStations = FindCroissantStations(croissantRecipeCfg and croissantRecipeCfg.OvenNames, "CroissantOvenSubject")
    for _, ovenPart in ipairs(ovenStations) do
        local burnt = ovenPart:GetAttribute("CookingStage") == "Burnt"
        local stuck = false
        if not burnt and ovenPart:GetAttribute("Occupied") == true then
            local startedAt = FindStartedAtAttribute(ovenPart)
            if startedAt and (workspace:GetServerTimeNow() - startedAt) > CookTimeout then
                stuck = true
            end
        end
        if burnt or stuck then
            local bakePrompt = GetObject(ovenPart, "Handle.CookingPrompt")
            if bakePrompt then
                CharacterLock.withLock(function()
                    if not CanHoldMore(1) then
                        notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. (burnt and "burnt" or "stuck") .. " item from " .. ovenPart.Name)
                        return
                    end
                    FirePP(bakePrompt, true)
                    task.wait(0.2)
                    FirePP(TrashPrompt, true)
                    task.wait(0.2)
                end)
            else
                notyuri("[Cafe] " .. (burnt and "Burnt" or "Stuck") .. " item on " .. ovenPart.Name .. " but no Bake prompt found")
            end
        end
    end
end
local function PlaceBeansInCoffeeMaker(foodType)
    if not CafeOrderGuideConfig then
        notyuri("[Cafe] CafeOrderGuideConfig not loaded, cannot resolve coffee maker/beans")
        return nil
    end
    local recipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes[foodType]
    if not recipeCfg or not recipeCfg.CoffeeMakerName or not recipeCfg.CoffeeBeanTool then
        notyuri("[Cafe] No coffee recipe config for FoodType: " .. tostring(foodType))
        return nil
    end
    local coffeeMaker = FindCoffeeMakerInstance(recipeCfg.CoffeeMakerName, true)
    if not coffeeMaker then
        return nil
    end
    local cookingPrompt = GetObject(coffeeMaker, "Handle.CookingPrompt")
    if not cookingPrompt then
        notyuri("[Cafe] Coffee_Maker Handle.CookingPrompt not found on " .. coffeeMaker.Name)
        return nil
    end
    local placed = false
    CharacterLock.withLock(function()
        local beanTool = GetBackpackOrHeldTool(recipeCfg.CoffeeBeanTool)
        if not beanTool then
            if not CanHoldMore(1) then
                notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. recipeCfg.CoffeeBeanTool)
                return
            end
            local pickupPrompt = FindPickupPrompt(recipeCfg.CoffeeBeanTool)
            if not pickupPrompt then
                notyuri("[Cafe] No pickup prompt found for: " .. recipeCfg.CoffeeBeanTool)
                return
            end
            FirePP(pickupPrompt, true)
            task.wait(0.3)
            beanTool = GetBackpackOrHeldTool(recipeCfg.CoffeeBeanTool)
            if not beanTool then
                notyuri("[Cafe] Did not receive expected tool: " .. recipeCfg.CoffeeBeanTool)
                return
            end
        end
        placed = PlaceToolWithRetry(recipeCfg.CoffeeBeanTool, coffeeMaker, cookingPrompt)
    end)
    if not placed then
        return nil
    end
    return coffeeMaker, cookingPrompt
end
local function PlaceScoopInMixer(foodType, flavor)
    if not CafeOrderGuideConfig then
        notyuri("[Cafe] CafeOrderGuideConfig not loaded, cannot resolve mixer/scoop")
        return nil
    end
    local recipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes[foodType]
    if not recipeCfg or not recipeCfg.MixerName then
        notyuri("[Cafe] No mixer recipe config for FoodType: " .. tostring(foodType))
        return nil
    end
    if not flavor then
        notyuri("[Cafe] No Flavor on order, cannot resolve ice cream scoop for FoodType: " .. tostring(foodType))
        return nil
    end
    local scoopToolName = flavor .. " Scoop"
    local mixer = FindCoffeeMakerInstance(recipeCfg.MixerName, true)
    if not mixer then
        return nil
    end
    local cookingPrompt = GetObject(mixer, "Handle.CookingPrompt")
    if not cookingPrompt then
        notyuri("[Cafe] " .. recipeCfg.MixerName .. " Handle.CookingPrompt not found on " .. mixer.Name)
        return nil
    end
    local placed = false
    CharacterLock.withLock(function()
        local scoopTool = GetBackpackOrHeldTool(scoopToolName)
        if not scoopTool then
            if not CanHoldMore(1) then
                notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. scoopToolName)
                return
            end
            local pickupPrompt = FindPickupPrompt(scoopToolName)
            if not pickupPrompt then
                notyuri("[Cafe] No pickup prompt found for: " .. scoopToolName)
                return
            end
            FirePP(pickupPrompt, true)
            task.wait(0.3)
            scoopTool = GetBackpackOrHeldTool(scoopToolName)
            if not scoopTool then
                notyuri("[Cafe] Did not receive expected tool: " .. scoopToolName)
                return
            end
        end
        placed = PlaceToolWithRetry(scoopToolName, mixer, cookingPrompt)
    end)
    if not placed then
        return nil
    end
    return mixer, cookingPrompt
end
local function PlaceFruitInBlender(foodType)
    if not CafeOrderGuideConfig then
        notyuri("[Cafe] CafeOrderGuideConfig not loaded, cannot resolve blender/fruit")
        return nil
    end
    local recipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes[foodType]
    if not recipeCfg or not recipeCfg.BlenderName or not recipeCfg.FruitTool then
        notyuri("[Cafe] No blender recipe config for FoodType: " .. tostring(foodType))
        return nil
    end
    local blender = FindCoffeeMakerInstance(recipeCfg.BlenderName, true)
    if not blender then
        return nil
    end
    local cookingPrompt = GetObject(blender, "Handle.CookingPrompt")
    if not cookingPrompt then
        notyuri("[Cafe] " .. recipeCfg.BlenderName .. " Handle.CookingPrompt not found on " .. blender.Name)
        return nil
    end
    local placed = false
    CharacterLock.withLock(function()
        local fruitTool = GetBackpackOrHeldTool(recipeCfg.FruitTool)
        if not fruitTool then
            if not CanHoldMore(1) then
                notyuri("[Cafe] Backpack full (5/5), cannot pick up " .. recipeCfg.FruitTool)
                return
            end
            local pickupPrompt = FindPickupPrompt(recipeCfg.FruitTool)
            if not pickupPrompt then
                notyuri("[Cafe] No pickup prompt found for: " .. recipeCfg.FruitTool)
                return
            end
            FirePP(pickupPrompt, true)
            task.wait(0.3)
            fruitTool = GetBackpackOrHeldTool(recipeCfg.FruitTool)
            if not fruitTool then
                notyuri("[Cafe] Did not receive expected tool: " .. recipeCfg.FruitTool)
                return
            end
        end
        placed = PlaceToolWithRetry(recipeCfg.FruitTool, blender, cookingPrompt)
    end)
    if not placed then
        return nil
    end
    return blender, cookingPrompt
end
local function WaitForCoffeeReady(coffeeMaker, timeoutSec)
    local start = tick()
    repeat
        if coffeeMaker:GetAttribute("Ready") == true then
            return true
        end
        task.wait()
    until (tick() - start) > (timeoutSec or 60)
    return false
end
local function WaitAndCollectFromCoffeeMaker(coffeeMaker, cookingPrompt)
    local ready = WaitForCoffeeReady(coffeeMaker, 90)
    if not ready then
        notyuri("[Cafe] Timed out waiting for coffee-ready on " .. coffeeMaker.Name)
        return false
    end
    task.wait(0.2)
    local ok = true
    CharacterLock.withLock(function()
        if not CanHoldMore(1) then
            notyuri("[Cafe] Backpack full (5/5), cannot pick up coffee from " .. coffeeMaker.Name)
            ok = false
            return
        end
        FirePP(cookingPrompt, true)
        task.wait(0.2)
    end)
    return ok
end
local function ApplyOrderToppings(orderState, foodType)
    CharacterLock.withLock(function()
        local applicators = CafeOrderGuideConfig and CafeOrderGuideConfig.IngredientApplicators
        if orderState.Syrup and applicators and applicators.Syrup then
            local terms = applicators.Syrup[orderState.Syrup]
            if terms then
                for _, term in ipairs(terms) do
                    local prompt = FindApplyPrompt(term, foodType)
                    if prompt then FirePP(prompt, true) task.wait(0.2) break end
                end
            else
                notyuri("[Cafe] No IngredientApplicators.Syrup entry for: " .. tostring(orderState.Syrup))
            end
        end
        if orderState.WhippedCream and applicators and applicators.WhippedCream then
            local terms = applicators.WhippedCream[orderState.WhippedCream]
            if terms then
                for _, term in ipairs(terms) do
                    local prompt = FindApplyPrompt(term, foodType)
                    if prompt then FirePP(prompt, true) task.wait(0.2) break end
                end
            else
                notyuri("[Cafe] No IngredientApplicators.WhippedCream entry for: " .. tostring(orderState.WhippedCream))
            end
        end
        if orderState.Toppings then
            for toppingName, active in pairs(orderState.Toppings) do
                if active then
                    local prompt = FindApplyPrompt(toppingName, foodType)
                    if prompt then FirePP(prompt, true) task.wait(0.2) end
                end
            end
        end
    end)
end
local function GetCafeCustomersFolder()
    return GetObject(workspace, "CafeCustomers")
end
local function FindCustomerById(customerId)
    local CafeCustomersFolder = GetCafeCustomersFolder()
    if not CafeCustomersFolder or not customerId then return nil end
    for _, model in ipairs(CafeCustomersFolder:GetChildren()) do
        if model:IsA("Model") then
            local id = model:GetAttribute("CafeCustomerId") or model:GetAttribute("CustomerId")
            if id == customerId then
                return model
            end
        end
    end
    return nil
end
local function ServeHeldFood(customerId)
    local customer = FindCustomerById(customerId)
    if not customer then
        notyuri("[Cafe] Could not find customer for CustomerId: " .. tostring(customerId))
        return false
    end
    local hrp = GetObject(customer, "HumanoidRootPart")
    local prompt = hrp and GetObject(hrp, "CafeRuntimePrompt")
    if not prompt then
        notyuri("[Cafe] CafeRuntimePrompt not found on customer: " .. customer.Name)
        return false
    end
    CharacterLock.withLock(function()
        FirePP(prompt, true)
        task.wait(0.2)
    end)
    return true
end
local function GetBellPrompt()
    local bellModel = Scriptables and GetObject(Scriptables, "Bell")
    return bellModel and bellModel:FindFirstChildWhichIsA("ProximityPrompt", true)
end
local function GetOrderPaperPrompt()
    return Scriptables and GetObject(Scriptables, "OrderPaper.CafeRuntimePrompt")
end
local function GetEnabledDeliveryMarkerPrompt()
    local MarkersFolder = Scriptables and GetObject(Scriptables, "Markers")
    if not MarkersFolder then return nil end
    for _, marker in ipairs(MarkersFolder:GetChildren()) do
        local prompt = GetObject(marker, "CafeRuntimePrompt")
        if prompt and prompt.Enabled and prompt.ActionText == "Place Box" then
            return prompt
        end
    end
    return nil
end
local function GetPanPickupPrompt()
    return Scriptables and GetObject(Scriptables, "PanPickup.PanPickupPrompt")
end
local function GetPanStatusLabel()
    return Scriptables and GetObject(Scriptables, "PanPickup.PANStatusBillboard.Background.StatusLabel")
end
local function GetCoffeeMakerSanity()
    return Scriptables and GetObject(Scriptables, "Tea_Maker_Sanity")
end
local function GetPowerBreakRepairPrompt()
    return Scriptables and GetObject(Scriptables, "PowerBox.powerbox.PowerBreakRepairPrompt")
end
local function GetCryoRoomGasLeakRepairPrompt()
    local scriptableFolder = GetObject(workspace, "Scriptable")
    return scriptableFolder and GetObject(scriptableFolder, "CryoRoomGasLeakSource.CryoRoomGasLeakRepairPrompt")
end
local function GetPowerBreakAnomalyPrompt()
    return GetObject(workspace, "Power Break Anomaly.HumanoidRootPart.PowerBreakAnomalyPrompt")
end
local function FireAllCashierPrompts()
    local CashierOrderSystem = Scriptables and GetObject(Scriptables, "CashierOrderSystem")
    if not CashierOrderSystem then return end
    for _, descendant in ipairs(CashierOrderSystem:GetDescendants()) do
        if descendant:IsA("ProximityPrompt") and descendant.Name == "CafeRuntimePrompt" and descendant.Enabled then
            FirePP(descendant, true)
            task.wait(0.2)
        end
    end
end
local DirtyPlate = "Dirty Plate"
local function GetCleanPlateStationPrompt()
    local cleanPlateStation = Scriptables and GetObject(Scriptables, "CleanPlate")
    return cleanPlateStation and cleanPlateStation:FindFirstChild("CleanPlateStationPrompt")
end
local function FireAllCleanPlatePrompts()
    for _, descendant in ipairs(workspace:GetDescendants()) do
        if descendant:IsA("ProximityPrompt") and descendant.Name == "CafeRuntimePrompt" and descendant.Parent and descendant.Parent.Name == "DirtyPlateNode" and descendant.Enabled then
            FirePP(descendant, true)
            task.wait()
        end
    end
    local CafeMesses = GetObject(workspace, "CafeMesses")
    if CafeMesses then
        for _, descendant in ipairs(CafeMesses:GetDescendants()) do
            if descendant:IsA("ProximityPrompt") and descendant.Enabled then
                FirePP(descendant, true)
                task.wait()
            end
        end
    end
end
local function HandleAnomalyIfPresent()
    local CafeCustomersFolder = GetCafeCustomersFolder()
    if not CafeCustomersFolder then return false end
    for _, model in ipairs(CafeCustomersFolder:GetChildren()) do
        if model:IsA("Model") and model:GetAttribute("IsAnomaly") == true then
            local state = model:GetAttribute("CustomerState") or model:GetAttribute("CafeCustomerState")
            if state == "OrderPresented" then
                local lever = Scriptables and GetObject(Scriptables, "Lever")
                if lever then
                    local prompt = lever:FindFirstChildWhichIsA("ProximityPrompt", true)
                    if prompt and prompt.ActionText == "Close Shutter" then
                        FirePP(prompt, true)
                        task.wait(0.2)
                        return true
                    elseif prompt then
                        notyuri("[Cafe] Anomaly customer OrderPresented but Lever prompt ActionText=" .. tostring(prompt.ActionText))
                    else
                        notyuri("[Cafe] Anomaly customer OrderPresented but Lever has no ProximityPrompt")
                    end
                else
                    notyuri("[Cafe] Anomaly customer detected but Lever not found")
                end
            end
        end
    end
    return false
end
local PAN_TOOL_NAMES = { "Pan", "Seasoned Pan" }
local function GetPanTool()
    for _, name in ipairs(PAN_TOOL_NAMES) do
        local tool = GetBackpackOrHeldTool(name)
        if tool then return tool end
    end
    return nil
end
local function FindFlyHitPart(flyModel)
    local part = flyModel:FindFirstChild("uglybody.006")
    if part and part:IsA("BasePart") then
        return part
    end
    return flyModel:FindFirstChildWhichIsA("BasePart", true)
end
local function IsPanReady(panStatusLabel)
    if not panStatusLabel then return false end
    return string.find(panStatusLabel.Text, "ready", 1, true) ~= nil
end
local function HandleHitFly()
    local flyModel = GetObject(workspace, "FlyAnomalyServer")
    if not flyModel then
        return
    end
    local panTool = GetPanTool()
    if not panTool then
        notyuri("[Cafe] HandleHitFly: no pan tool held, attempting pickup")
        local PanPickupPrompt = GetPanPickupPrompt()
        if not PanPickupPrompt then
            notyuri("[Cafe] PanPickup.PanPickupPrompt not found - cannot pick up Pan")
            return
        end
        local PanStatusLabel = GetPanStatusLabel()
        local panReady = IsPanReady(PanStatusLabel)
        notyuri("[Cafe] HandleHitFly: IsPanReady=" .. tostring(panReady) .. " PanStatusLabel.Text=" .. tostring(PanStatusLabel and PanStatusLabel.Text))
        if not panReady then
            return
        end
        CharacterLock.withLock(function()
            notyuri("[Cafe] HandleHitFly: firing PanPickupPrompt")
            FirePP(PanPickupPrompt, true)
            task.wait(0.3)
        end)
        panTool = GetPanTool()
        notyuri("[Cafe] HandleHitFly: after pickup attempt, panTool=" .. tostring(panTool and panTool.Name))
        if not panTool then
            notyuri("[Cafe] HandleHitFly: pickup failed, no pan tool in backpack/held")
            return
        end
    end
    local PanActivatedRemote = GetBridge("PanActivated")
    if not PanActivatedRemote then
        notyuri("[Cafe] PanActivated bridge not available - AutoOrder(fly) cannot fire")
        return
    end
    local hitPart = FindFlyHitPart(flyModel)
    if not hitPart then
        notyuri("[Cafe] No hittable part found on FlyAnomalyServer")
        return
    end
    CharacterLock.withLock(function()
        EquipTool(panTool)
        task.wait(0.1)
        PanActivatedRemote:Fire(hitPart)
        task.wait(0.3)
    end)
end
local SUGAR_TOOL_NAMES = { "Sugar Bag", "Sugar Cube" }
local function GetSugarTool()
    for _, name in ipairs(SUGAR_TOOL_NAMES) do
        local tool = GetBackpackOrHeldTool(name)
        if tool then return tool end
    end
    return nil
end
local function HandleGlorpShoo()
    local glorpModel = GetObject(workspace, "GlorpAnomaly")
    if not glorpModel then
        return
    end
    
    local hrp = GetObject(glorpModel, "HumanoidRootPart")
    if not hrp then
        notyuri("[Cafe] HandleGlorpShoo: GlorpAnomaly has no HumanoidRootPart")
        return
    end
    
    local ShooPrompt = GetObject(hrp, "GlorpShooPrompt")
    if not ShooPrompt then
        notyuri("[Cafe] HandleGlorpShoo: GlorpShooPrompt not found")
        return
    end
    
    if not ShooPrompt.Enabled then
        return
    end
    
    CharacterLock.withLock(function()
        FirePP(ShooPrompt, true)
        task.wait(0.3)
    end)
end
local function HandleMishyGive()
    local MishySpawnsFolder = Scriptables and GetObject(Scriptables, "MishySpawns")
    if not MishySpawnsFolder then
        return
    end
    for _, station in ipairs(MishySpawnsFolder:GetChildren()) do
        local mishyModel = station:FindFirstChild("MishyAnomaly")
        if mishyModel then
            local hrp = GetObject(mishyModel, "RootPart")
            local GivePrompt = hrp and GetObject(hrp, "MishyGivePrompt")
            if GivePrompt and GivePrompt.Enabled then
                local itemName = GivePrompt.ObjectText
                if typeof(itemName) ~= "string" or itemName == "" then
                    notyuri("[Cafe] HandleMishyGive: GivePrompt has no ObjectText")
                    return
                end
                local shouldStop = false
                CharacterLock.withLock(function()
                    local tool = GetBackpackOrHeldTool(itemName)
                    if tool then
                        EquipTool(tool)
                        task.wait(0.1)
                        FirePP(GivePrompt, true)
                        task.wait(0.3)
                        return
                    end
                    if not CanHoldMore(1) then
                        notyuri("[Cafe] HandleMishyGive: Backpack full (5/5), cannot pick up: " .. itemName)
                        shouldStop = true
                        return
                    end
                    local pickupPrompt = FindPickupPrompt(itemName)
                    if not pickupPrompt then
                        notyuri("[Cafe] HandleMishyGive: No pickup prompt found for: " .. itemName)
                        return
                    end
                    FirePP(pickupPrompt, true)
                    task.wait(0.3)
                    tool = GetBackpackOrHeldTool(itemName)
                    if tool then
                        EquipTool(tool)
                        task.wait(0.1)
                        FirePP(GivePrompt, true)
                        task.wait(0.3)
                    else
                        notyuri("[Cafe] HandleMishyGive: Did not receive expected tool: " .. itemName)
                    end
                end)
                if shouldStop then return end
                return
            end
        end
    end
end
local TT = "Tea Cup"
local function IsCoffeeReady(coffeeMakerSanity)
    if not coffeeMakerSanity then return false end
    return coffeeMakerSanity:GetAttribute("Ready") == true
end
local function ShouldDrinkCoffee()
    local maxSanity = Plr:GetAttribute("CafeMaxSanity") or (CafeConfig and CafeConfig.Sanity.MaximumValue)
    local sanity = Plr:GetAttribute("CafeSanity") or (CafeConfig and CafeConfig.Sanity.StartingValue)
    if not maxSanity or not sanity then
        notyuri("[Cafe] AutoCoffee: sanity values unavailable (no CafeSanity/CafeMaxSanity attribute and CafeConfig not loaded)")
        return false
    end
    local thresholdPercent = Options.CoffeeThreshold.Value
    return sanity < (maxSanity * (thresholdPercent / 100))
end
local function Func_AutoCoffee()
    while Toggles.AutoCoffee.Value do
        local ok, err = pcall(function()
            local RequestClassItemUseRemote = GetBridge("RequestClassItemUse")
            if not RequestClassItemUseRemote then
                notyuri("[Cafe] RequestClassItemUse bridge not available - AutoCoffee cannot fire")
                task.wait(1)
                return
            end
            local TT = GetBackpackOrHeldTool(TT)
            if not TT then
                local CoffeeMakerSanity = GetCoffeeMakerSanity()
                local CoffeeCookingPrompt = CoffeeMakerSanity and GetObject(CoffeeMakerSanity, "Handle.CookingPrompt")
                if not CoffeeCookingPrompt then
                    notyuri("[Cafe] Tea_Maker_Sanity.Handle.CookingPrompt not found - cannot pick up Coffee Cup")
                    task.wait(1)
                    return
                end
                if not IsCoffeeReady(CoffeeMakerSanity) then
                    task.wait(0.5)
                    return
                end
                if not CanHoldMore(1) then
                    notyuri("[Cafe] Backpack full (5/5), cannot pick up Coffee Cup")
                    task.wait(1)
                    return
                end
                CharacterLock.withLock(function()
                    FirePP(CoffeeCookingPrompt, true)
                    task.wait(0.3)
                end)
                TT = GetBackpackOrHeldTool(TT)
                if not TT then
                    task.wait(0.5)
                    return
                end
            end
            if not ShouldDrinkCoffee() then
                task.wait(0.5)
                return
            end
            CharacterLock.withLock(function()
                EquipTool(TT)
                task.wait(0.1)
                RequestClassItemUseRemote:Fire("Tea Cup")
                task.wait(0.3)
            end)
        end)
        if not ok then
            notyuri("[Cafe] AutoCoffee error: " .. tostring(err))
        end
        task.wait(0.3)
    end
end
local function FireAllCustomerPrompts()
    local CafeCustomersFolder = GetCafeCustomersFolder()
    if not CafeCustomersFolder then return end
    for _, model in ipairs(CafeCustomersFolder:GetChildren()) do
        if model:IsA("Model") and model:GetAttribute("IsAnomaly") ~= true then
            for _, descendant in ipairs(model:GetDescendants()) do
                if descendant:IsA("ProximityPrompt") and descendant.Enabled and descendant.ActionText ~= "Serve" then
                    FirePP(descendant, true)
                    task.wait(0.2)
                end
            end
        end
    end
end
local CustomerESPFolder = Instance.new("Folder")
CustomerESPFolder.Parent = Services.CoreGui
local function getPartForAdornee(target)
    if target:IsA("BasePart") then
        return target
    elseif target:IsA("Model") then
        return target.PrimaryPart or target:FindFirstChildWhichIsA("BasePart", true)
    end
    return nil
end
local function makeLabel(text, sizeY, posY, bold, textColor)
    local lbl = Instance.new("TextLabel")
    lbl.Size = UDim2.new(1, 0, sizeY, 0)
    lbl.Position = UDim2.new(0, 0, posY, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = text
    lbl.TextColor3 = textColor or Color3.new(1, 1, 1)
    lbl.TextStrokeColor3 = Color3.new(0, 0, 0)
    lbl.TextStrokeTransparency = 0.4
    lbl.TextScaled = true
    lbl.Font = bold and Enum.Font.GothamBold or Enum.Font.Gotham
    lbl.TextXAlignment = Enum.TextXAlignment.Center
    return lbl
end
local CustomerESPPool = {
    Free = {},
    Active = {},
}
local function CustomerESPAcq(fillColor, outlineColor, labelName, roleText, textColor)
    local entry = table.remove(CustomerESPPool.Free)
    if not entry then
        local h = Instance.new("Highlight")
        h.FillTransparency = 0.4
        h.OutlineTransparency = 0
        h.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        local bb = Instance.new("BillboardGui")
        bb.Size = UDim2.new(0, 100, 0, 30)
        bb.StudsOffset = Vector3.new(0, 3, 0)
        bb.AlwaysOnTop = true
        bb.ResetOnSpawn = false
        local nameLbl = makeLabel("", 0.5, 0, true, Color3.new(1, 1, 1))
        nameLbl.Parent = bb
        local roleLbl = makeLabel("", 0.5, 0.5, false, Color3.new(1, 1, 1))
        roleLbl.Parent = bb
        entry = { highlight = h, billboard = bb, nameLbl = nameLbl, roleLbl = roleLbl }
    end
    entry.highlight.FillColor = fillColor
    entry.highlight.OutlineColor = outlineColor
    entry.highlight.Parent = CustomerESPFolder
    entry.nameLbl.Text = labelName
    entry.nameLbl.TextColor3 = textColor or Color3.new(1, 1, 1)
    entry.roleLbl.Text = roleText
    entry.roleLbl.TextColor3 = textColor or Color3.new(1, 1, 1)
    entry.billboard.Parent = CustomerESPFolder
    CustomerESPPool.Active[entry] = true
    return entry
end
local function CustomerESPRelease(entry)
    if not entry or not CustomerESPPool.Active[entry] then return end
    CustomerESPPool.Active[entry] = nil
    entry.highlight.Adornee = nil
    entry.highlight.Parent = nil
    entry.billboard.Adornee = nil
    entry.billboard.Parent = nil
    table.insert(CustomerESPPool.Free, entry)
end
local function makeCustomerHighlight(target, fillColor, outlineColor, labelName, roleText, textColor)
    local part = getPartForAdornee(target)
    if not part then return nil end
    local entry = CustomerESPAcq(fillColor, outlineColor, labelName, roleText, textColor)
    entry.highlight.Adornee = target
    entry.billboard.Adornee = part
    return entry
end
local function removeCustomerHighlight(tbl, key)
    if tbl[key] then
        CustomerESPRelease(tbl[key])
        tbl[key] = nil
    end
end
local CustomerESPHighlights = {}
local function RefreshCustomerESP()
    if not Toggles.CustomerESP.Value then
        for k in pairs(CustomerESPHighlights) do removeCustomerHighlight(CustomerESPHighlights, k) end
        return
    end
    local CafeCustomersFolder = GetCafeCustomersFolder()
    if not CafeCustomersFolder then return end
    local normalColor = Options.CustomerColor.Value
    local anomalyColor = Options.AnomalyColor.Value
    local outlineColor = Options.CustomerOutline.Value
    local current = {}
    for _, model in ipairs(CafeCustomersFolder:GetChildren()) do
        if model:IsA("Model") then
            current[model] = true
        end
    end
    for key in pairs(CustomerESPHighlights) do
        if not current[key] or not key.Parent then
            removeCustomerHighlight(CustomerESPHighlights, key)
        end
    end
    for model in pairs(current) do
        local isAnomaly = model:GetAttribute("IsAnomaly") == true
        local customerType = model:GetAttribute("CustomerType") or (isAnomaly and "Anomaly" or "Normal")
        local color = isAnomaly and anomalyColor or normalColor
        if not CustomerESPHighlights[model] then
            CustomerESPHighlights[model] = makeCustomerHighlight(model, color, outlineColor, model.Name, customerType, color)
        else
            local entry = CustomerESPHighlights[model]
            entry.highlight.FillColor = color
            entry.highlight.OutlineColor = outlineColor
            entry.nameLbl.Text = model.Name
            entry.nameLbl.TextColor3 = color
            entry.roleLbl.Text = customerType
            entry.roleLbl.TextColor3 = color
        end
    end
end
local function FuncCustomerESP()
    while true do
        RunService.Heartbeat:Wait()
        if Toggles.CustomerESP.Value then
            RefreshCustomerESP()
        end
        task.wait(0.3)
    end
end
local function IsRunFailedScreenShowing()
    local EndScreen = PGui:FindFirstChild("EndScreen")
    if not (EndScreen and EndScreen.Enabled) then
        return false
    end
    if not RunState then
        return false
    end
    return RS:GetAttribute("CafeRunState") == RunState.RunFailed
end
local function Func_AutoRetry()
    while Toggles.AutoRetry.Value do
        local ok, err = pcall(function()
            if not IsRunFailedScreenShowing() then
                task.wait(0.5)
                return
            end
            local CafeRoundAction = GetBridge("CafeRoundAction")
            if not CafeRoundAction then
                notyuri("[Cafe] CafeRoundAction bridge not available - AutoRetry cannot fire")
                task.wait(1)
                return
            end
            CafeRoundAction:Fire({
                Action = "PlayAgain"
            })
            task.wait(1)
        end)
        if not ok then
            notyuri("[Cafe] AutoRetry error: " .. tostring(err))
        end
        task.wait(0.3)
    end
end
local HandledMinigameRequestIds = {}
local CroissantMinigameLastFired = 0
local function HandleCookingMinigameStart(startData)
    local requestId = startData and startData.RequestId
    local minigame = startData and startData.Minigame
    if typeof(requestId) ~= "string" then
        return
    end
    if HandledMinigameRequestIds[requestId] then
        return
    end
    HandledMinigameRequestIds[requestId] = true
    task.delay(30, function()
        HandledMinigameRequestIds[requestId] = nil
    end)
    if minigame == "PowerBreaker" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete PowerBreaker minigame")
            return
        end
        notyuri("[Cafe] Auto-completing PowerBreaker minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 1,
            ResultData = {
                Success = true,
                Matches = 4,
            },
        })
        return
    end
    if minigame == "CryoRepair" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete CryoRepair minigame")
            return
        end
        notyuri("[Cafe] Auto-completing CryoRepair minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 1,
            ResultData = {
                Success = true,
                GoodHits = 2,
                Tries = 2,
            },
        })
        return
    end
    if minigame == "Milkshake" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete Milkshake minigame")
            return
        end
        notyuri("[Cafe] Auto-completing Milkshake minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 2.5,
        })
        return
    end
    if minigame == "Knife" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete Knife minigame")
            return
        end
        notyuri("[Cafe] Auto-completing Knife minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 2.5,
        })
        return
    end
    if minigame == "CleanPlates" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete CleanPlates minigame")
            return
        end
        notyuri("[Cafe] Auto-completing CleanPlates minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 1,
            ResultData = {
                Success = true,
            },
        })
        return
    end
    if minigame == "Coffee" then
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete Coffee minigame")
            return
        end
        notyuri("[Cafe] Auto-completing Coffee minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 2.5,
            ResultData = {
                Tries = 3,
                BadCount = 0,
            },
        })
        return
    end
    if minigame == "Croissant" then
        local now = tick()
        if now - CroissantMinigameLastFired < 1 then
            return
        end
        CroissantMinigameLastFired = now
        local CookingMinigameComplete = GetBridge("CookingMinigameComplete")
        if not CookingMinigameComplete then
            notyuri("[Cafe] CookingMinigameComplete bridge not available - cannot auto-complete Croissant minigame")
            return
        end
        notyuri("[Cafe] Auto-completing Croissant minigame, RequestId: " .. requestId)
        CookingMinigameComplete:Fire({
            RequestId = requestId,
            Multiplier = 1,
            ResultData = {
                Success = true,
            },
        })
        return
    end
end
local function Func_AutoOrder()
    while Toggles.AutoOrder.Value do
        local ok, err = pcall(function()
            FireAllCashierPrompts()
            if HandleAnomalyIfPresent() then
                return 
            end
            ClearBurn()
            FireAllCustomerPrompts()
            FireAllCleanPlatePrompts()
            HandleHitFly()
            HandleGlorpShoo()
            HandleMishyGive()
            local BellPrompt = GetBellPrompt()
            if BellPrompt and BellPrompt.Enabled then
                FirePP(BellPrompt, true)
                task.wait(0.2)
            end
            local OrderPaperPrompt = GetOrderPaperPrompt()
            if OrderPaperPrompt and OrderPaperPrompt.Enabled then
                FirePP(OrderPaperPrompt, true)
                task.wait(0.2)
            end
            local deliveryBox = GetBackpackOrHeldTool("Delivery Box")
            if deliveryBox then
                local deliveryMarkerPrompt = GetEnabledDeliveryMarkerPrompt()
                if deliveryMarkerPrompt then
                    CharacterLock.withLock(function()
                        EquipTool(deliveryBox)
                        task.wait(0.1)
                        FirePP(deliveryMarkerPrompt, true)
                        task.wait(0.2)
                    end)
                end
            end
            local char = Plr.Character
            local hrp = char and GetObject(char, "HumanoidRootPart")
            local selfSavePrompt = hrp and GetObject(hrp, "CafeSelfSavePrompt")
            if selfSavePrompt and selfSavePrompt.Enabled then
                FirePP(selfSavePrompt, true)
                task.wait(0.2)
            end
            local cryoRoomGasLeakRepairPrompt = GetCryoRoomGasLeakRepairPrompt()
            if cryoRoomGasLeakRepairPrompt and cryoRoomGasLeakRepairPrompt.Enabled then
                FirePP(cryoRoomGasLeakRepairPrompt, true)
                task.wait(0.2)
            end
            local powerBreakAnomalyPrompt = GetPowerBreakAnomalyPrompt()
            if powerBreakAnomalyPrompt and powerBreakAnomalyPrompt.Enabled then
                FirePP(powerBreakAnomalyPrompt, true)
                task.wait(0.2)
            end
            local powerBreakRepairPrompt = GetPowerBreakRepairPrompt()
            if powerBreakRepairPrompt and powerBreakRepairPrompt.Enabled then
                FirePP(powerBreakRepairPrompt, true)
                task.wait(0.2)
            end
        end)
        if not ok then
            notyuri("[Cafe] AutoOrder error: " .. tostring(err))
        end
        task.wait(0.5)
    end
end
local PartyGameModes = SharedConfig and GetSafeModule(SharedConfig, "PartyGameModes")

local function GetEmptyTeleporter()
    local zones = GetObject(workspace, "Main.Zones")
    if not zones then
        return nil
    end
    for _, child in ipairs(zones:GetChildren()) do
        if child.Name == "Teleporter" then
            local label = GetObject(child, "BillboardHolder.BillboardGui.Players")
            if label and label:IsA("TextLabel") then
                local current, max = label.Text:match("^(%d+)/(%d+)$")
                if current and tonumber(current) == 0 then
                    return child
                end
            end
        end
    end
    return nil
end
local function Func_AutoJoin()
    while Toggles.AutoJoin.Value do
        local ok, err = pcall(function()
            local teleporter = GetEmptyTeleporter()
            if not teleporter then
                return
            end
            local enterPart = teleporter:FindFirstChild("EnterPart")
            if not enterPart then
                return
            end
            FireTI(enterPart)
            local PartyCreate = GetBridge("PartyCreate")
            if not PartyCreate then
                return
            end
            if not PartyGameModes then
                return
            end
            task.wait(1)
            PartyCreate:Fire({
                maxPlayers = 1,
                friendOnly = false,
                gameModeId = "Normal"
            })
            task.wait(.1)
            local PartySetSkipFTUE = GetBridge("PartySetSkipFTUE")
            if not PartySetSkipFTUE then
                return
            end
            PartySetSkipFTUE:Fire({ skipFTUE = true })
            local DataEvent = RS:FindFirstChild("ffrostflame_bridgenet2@1.0.0")
            local DataRemoteEvent2 = DataEvent and DataEvent:FindFirstChild("dataRemoteEvent")
            task.wait(.1)
            if DataRemoteEvent2 then
                DataRemoteEvent2:FireServer({ { skipFTUE = true }, "*" })
            end
        end)
        task.wait()
    end
end
local function HandleDialogueEffect(effectData)
    if not effectData or effectData.EffectName ~= "PlayCustomerDialogue" then
        return
    end
    local CafeRoundAction = GetBridge("CafeRoundAction")
    if not CafeRoundAction then
        return
    end
    CafeRoundAction:Fire({
        Action = "DialogueSkip"
    })
end
local function StartAutoSkipDialogue()
    if Connections.AutoSkipDialogue then
        return
    end
    local CafeEffectRemote = GetBridge("CafeEffectRemote")
    if not CafeEffectRemote then
        notyuri("[Cafe] CafeEffectRemote not available - AutoSkipDialogue cannot start")
        return
    end
    SafeConnect("AutoSkipDialogue", function()
        return CafeEffectRemote
    end, HandleDialogueEffect)
end
local function StopAutoSkipDialogue()
    if Connections.AutoSkipDialogue then
        Connections.AutoSkipDialogue:Disconnect()
        Connections.AutoSkipDialogue = nil
    end
end
local InFlightOrderIds = {}
local InFlightCount = 0
local MAX_CONCURRENT_ORDERS = 3
local function FindMatchingHeldOrder(orderState)
    if not CafeOrderGuideResolver then return nil end
    local orderData = {
        FoodType = orderState.FoodType,
        Doneness = orderState.Doneness,
        Flavor = orderState.Flavor,
        Plate = orderState.Plate,
        Syrup = orderState.Syrup,
        WhippedCream = orderState.WhippedCream,
        Toppings = orderState.Toppings,
    }
    local char = Plr.Character
    local held = char and char:FindFirstChildOfClass("Tool")
    if held then
        local recipeState = CafeOrderGuideResolver.GetToolRecipeState(held)
        if recipeState and CafeOrderGuideResolver.RecipeStateMatchesOrder(recipeState, orderData) then
            return held
        end
    end
    local backpack = Plr:FindFirstChildOfClass("Backpack")
    if backpack then
        for _, tool in ipairs(backpack:GetChildren()) do
            if tool:IsA("Tool") then
                local recipeState = CafeOrderGuideResolver.GetToolRecipeState(tool)
                if recipeState and CafeOrderGuideResolver.RecipeStateMatchesOrder(recipeState, orderData) then
                    return tool
                end
            end
        end
    end
    return nil
end
local function RecipeBaseMatchesOrder(recipeState, orderState)
    if not recipeState or recipeState.FoodType ~= orderState.FoodType then
        return false
    end
    local defaultDoneness = CafeOrderGuideConfig and CafeOrderGuideConfig.DefaultDoneness
    if orderState.Doneness and (recipeState.Doneness or defaultDoneness) ~= orderState.Doneness then
        return false
    end
    local defaultPlate = CafeOrderGuideConfig and CafeOrderGuideConfig.DefaultPlate
    if orderState.Plate and (recipeState.Plate or defaultPlate) ~= orderState.Plate then
        return false
    end
    if recipeState.Flavor ~= orderState.Flavor then
        return false
    end
    if recipeState.Syrup and orderState.Syrup and recipeState.Syrup ~= orderState.Syrup then
        return false
    end
    if recipeState.WhippedCream and orderState.WhippedCream and recipeState.WhippedCream ~= orderState.WhippedCream then
        return false
    end
    return true
end
local function GetMissingToppings(recipeState, orderState)
    local missing = {}
    if not CafeOrderGuideConfig or not CafeOrderGuideConfig.ToppingAttributes then
        return missing
    end
    local haveToppings = (recipeState and recipeState.Toppings) or {}
    local wantToppings = orderState.Toppings or {}
    for _, toppingName in ipairs(CafeOrderGuideConfig.ToppingAttributes) do
        local wants = wantToppings[toppingName] == true
        local has = haveToppings[toppingName] == true
        if wants and not has then
            table.insert(missing, toppingName)
        end
    end
    return missing
end
local function FindUnlockIdForName(optionList, name)
    if not optionList or not name then return nil end
    for _, option in ipairs(optionList) do
        if option.Name == name then
            return option.UnlockId
        end
    end
    return nil
end
local function GetMissingSyrupIngredient(recipeState, orderState)
    if not orderState.Syrup then
        return nil
    end
    if recipeState and recipeState.Syrup == orderState.Syrup then
        return nil
    end
    return orderState.Syrup .. "Syrup"
end
local function GetMissingWhippedCreamIngredient(recipeState, orderState)
    if not orderState.WhippedCream then
        return nil
    end
    if recipeState and recipeState.WhippedCream == orderState.WhippedCream then
        return nil
    end
    return orderState.WhippedCream .. "WhippedCream"
end
local function FindPartialMatchHeldItem(orderState)
    if not CafeOrderGuideResolver then return nil end
    local function checkTool(tool)
        local recipeState = CafeOrderGuideResolver.GetToolRecipeState(tool)
        if not recipeState or not RecipeBaseMatchesOrder(recipeState, orderState) then
            return nil
        end
        local missingToppings = GetMissingToppings(recipeState, orderState)
        local missingSyrup = GetMissingSyrupIngredient(recipeState, orderState)
        local missingWhippedCream = GetMissingWhippedCreamIngredient(recipeState, orderState)
        if #missingToppings == 0 and not missingSyrup and not missingWhippedCream then
            return nil
        end
        return recipeState, { Toppings = missingToppings, Syrup = missingSyrup, WhippedCream = missingWhippedCream }
    end
    local char = Plr.Character
    local held = char and char:FindFirstChildOfClass("Tool")
    if held then
        local recipeState, missing = checkTool(held)
        if recipeState then
            return held, missing
        end
    end
    local backpack = Plr:FindFirstChildOfClass("Backpack")
    if backpack then
        for _, tool in ipairs(backpack:GetChildren()) do
            if tool:IsA("Tool") then
                local recipeState, missing = checkTool(tool)
                if recipeState then
                    return tool, missing
                end
            end
        end
    end
    return nil
end
local function ApplyMissingToppings(orderState, foodType, missing)
    CharacterLock.withLock(function()
        if missing.Syrup then
            local prompt = FindApplyPrompt(missing.Syrup, foodType)
            if prompt then FirePP(prompt, true) task.wait(0.2) end
        end
        if missing.WhippedCream then
            local prompt = FindApplyPrompt(missing.WhippedCream, foodType)
            if prompt then FirePP(prompt, true) task.wait(0.2) end
        end
        for _, toppingName in ipairs(missing.Toppings) do
            local prompt = FindApplyPrompt(toppingName, foodType)
            if prompt then FirePP(prompt, true) task.wait(0.2) end
        end
    end)
end
local function ProcessOrder(orderState)
    local matchingTool = FindMatchingHeldOrder(orderState)
    if matchingTool then
        notyuri("[Cafe] Found matching dish already in inventory for OrderId: " .. tostring(orderState.OrderId) .. ", serving directly")
        local ok, err = pcall(function()
            CharacterLock.withLock(function()
                EquipTool(matchingTool)
                task.wait(0.1)
            end)
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook direct-serve error: " .. tostring(err))
        end
        return
    end
    local partialTool, missing = FindPartialMatchHeldItem(orderState)
    if partialTool then
        notyuri("[Cafe] Found partial match in inventory for OrderId: " .. tostring(orderState.OrderId) .. ", adding " .. #missing.Toppings .. " missing topping(s) instead of cooking new")
        local ok, err = pcall(function()
            CharacterLock.withLock(function()
                EquipTool(partialTool)
                task.wait(0.1)
            end)
            ApplyMissingToppings(orderState, orderState.FoodType, missing)
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook partial-match error: " .. tostring(err))
        end
        return
    end
    if orderState.FoodType == "Orange Juice" or orderState.FoodType == "Banana Juice" or orderState.FoodType == "Apple Juice" then
        local ok, err = pcall(function()
            local blender, cookingPrompt = PlaceFruitInBlender(orderState.FoodType)
            if not blender then
                return
            end
            if not WaitAndCollectFromCoffeeMaker(blender, cookingPrompt) then
                return
            end
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook order error: " .. tostring(err))
        end
        return
    end
    if orderState.FoodType == "Milkshake" then
        local ok, err = pcall(function()
            local mixer, cookingPrompt = PlaceScoopInMixer(orderState.FoodType, orderState.Flavor)
            if not mixer then
                return
            end
            if not WaitAndCollectFromCoffeeMaker(mixer, cookingPrompt) then
                return
            end
            ApplyOrderToppings(orderState, orderState.FoodType)
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook order error: " .. tostring(err))
        end
        return
    end
    if orderState.FoodType == "Coffee" or orderState.FoodType == "Decaf Coffee" then
        local ok, err = pcall(function()
            local coffeeMaker, cookingPrompt = PlaceBeansInCoffeeMaker(orderState.FoodType)
            if not coffeeMaker then
                return
            end
            if not WaitAndCollectFromCoffeeMaker(coffeeMaker, cookingPrompt) then
                return
            end
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook order error: " .. tostring(err))
        end
        return
    end
    if orderState.FoodType == "Creamer Coffee" or orderState.FoodType == "Iced Creamer Coffee" then
        local ok, err = pcall(function()
            local creamerRecipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Creamer Coffee"]
            local coffeeMaker, cookingPrompt = PlaceBeansInCoffeeMaker("Creamer Coffee")
            if not coffeeMaker then
                return
            end
            if not WaitAndCollectFromCoffeeMaker(coffeeMaker, cookingPrompt) then
                return
            end
            local creamerIngredient = creamerRecipeCfg and creamerRecipeCfg.ApplyIngredient
            if not creamerIngredient then
                notyuri("[Cafe] No ApplyIngredient in Recipes[\"Creamer Coffee\"], cannot apply creamer")
                return
            end
            local creamerApplied = false
            CharacterLock.withLock(function()
                if not CanHoldMore(1) then
                    notyuri("[Cafe] Backpack full (5/5), cannot apply " .. creamerIngredient)
                    return
                end
                local prompt = FindApplyPrompt(creamerIngredient, "Creamer Coffee")
                if not prompt then
                    notyuri("[Cafe] No apply prompt found for: " .. creamerIngredient)
                    return
                end
                FirePP(prompt, true)
                task.wait(0.2)
                creamerApplied = true
            end)
            if not creamerApplied then
                return
            end
            if orderState.FoodType == "Iced Creamer Coffee" then
                local icedRecipeCfg = CafeOrderGuideConfig.Recipes and CafeOrderGuideConfig.Recipes["Iced Creamer Coffee"]
                local iceIngredient = icedRecipeCfg and icedRecipeCfg.ApplyIngredient
                if not iceIngredient then
                    notyuri("[Cafe] No ApplyIngredient in Recipes[\"Iced Creamer Coffee\"], cannot apply ice")
                    return
                end
                local iceApplied = false
                CharacterLock.withLock(function()
                    if not CanHoldMore(1) then
                        notyuri("[Cafe] Backpack full (5/5), cannot apply " .. iceIngredient)
                        return
                    end
                    local prompt = FindApplyPrompt(iceIngredient, "Iced Creamer Coffee")
                    if not prompt then
                        notyuri("[Cafe] No apply prompt found for: " .. iceIngredient)
                        return
                    end
                    FirePP(prompt, true)
                    task.wait(0.2)
                    iceApplied = true
                end)
                if not iceApplied then
                    return
                end
            end
            ServeHeldFood(orderState.CustomerId)
        end)
        if not ok then
            notyuri("[Cafe] AutoCook order error: " .. tostring(err))
        end
        return
    end
    if orderState.FoodType == "Croissant" then
        local bowl = FindFreeBatterBowl()
        if not bowl then
            return
        end
        BowlsInUse[bowl] = true
        local ok, err = pcall(function()
            if not FillBowl(bowl) then
                return
            end
            local batterName = CafeOrderGuideConfig.BatterTool or "Batter"
            local batterTool
            CharacterLock.withLock(function()
                if not CanHoldMore(1) then
                    notyuri("[Cafe] Backpack full (5/5), cannot pick up Batter")
                    return
                end
                local bowlPrompt = GetObject(bowl, "CookingPrompt")
                if bowlPrompt then
                    FirePP(bowlPrompt, true)
                    task.wait(0.3)
                end
                batterTool = GetBackpackOrHeldTool(batterName)
            end)
            if not batterTool then
                notyuri("[Cafe] Failed to pick up " .. batterName .. " after filling bowl")
                return
            end
            BowlsInUse[bowl] = nil
            local pinBoard = PlaceBatterOnPinBoard()
            if not pinBoard then
                return
            end
            local doughTool = WaitForCroissantDoughTool(30)
            if not doughTool then
                notyuri("[Cafe] Timed out waiting for Croissant dough tool after pin board")
                return
            end
            local oven, bakePrompt = BakeCroissant(doughTool)
            if not oven then
                return
            end
            if not WaitAndCollectFromOven(oven, bakePrompt) then
                return
            end
            ApplyOrderToppings(orderState, orderState.FoodType)
            ServeHeldFood(orderState.CustomerId)
        end)
        BowlsInUse[bowl] = nil
        if not ok then
            notyuri("[Cafe] AutoCook order error: " .. tostring(err))
        end
        return
    end
    local bowl = FindFreeBatterBowl()
    if not bowl then
        return
    end
    BowlsInUse[bowl] = true
    local ok, err = pcall(function()
        if not FillBowl(bowl) then
            return
        end
        local batterName = CafeOrderGuideConfig.BatterTool or "Batter"
        local batterTool
        CharacterLock.withLock(function()
            if not CanHoldMore(1) then
                notyuri("[Cafe] Backpack full (5/5), cannot pick up Batter")
                return
            end
            local bowlPrompt = GetObject(bowl, "CookingPrompt")
            if bowlPrompt then
                FirePP(bowlPrompt, true)
                task.wait(0.3)
            end
            batterTool = GetBackpackOrHeldTool(batterName)
        end)
        if not batterTool then
            notyuri("[Cafe] Failed to pick up " .. batterName .. " after filling bowl")
            return
        end
        BowlsInUse[bowl] = nil
        local grillPart, takePrompt, flipPrompt = PlaceBatterOnGrill(orderState.FoodType)
        if not grillPart then
            return
        end
        if not WaitAndCollectFromGrill(grillPart, takePrompt, flipPrompt, orderState.FoodType) then
            return
        end
        ApplyOrderToppings(orderState, orderState.FoodType)
        ServeHeldFood(orderState.CustomerId)
    end)
    BowlsInUse[bowl] = nil
    if not ok then
        notyuri("[Cafe] AutoCook order error: " .. tostring(err))
    end
end
local function Func_AutoCafe()
    while Toggles.AutoCook.Value do
        local ok, err = pcall(function()
            if not CafeOrderGuideConfig then
                notyuri("[Cafe] CafeOrderGuideConfig not loaded, stopping")
                Toggles.AutoCook.Value = false
                return
            end
            if InFlightCount >= MAX_CONCURRENT_ORDERS then
                task.wait(0.5)
                return
            end
            local pending = GetSupportedOrders(InFlightOrderIds)
            if #pending == 0 then
                task.wait(1)
                return
            end
            local slots = MAX_CONCURRENT_ORDERS - InFlightCount
            for i = 1, math.min(slots, #pending) do
                local orderState = pending[i]
                InFlightOrderIds[orderState.OrderId] = true
                InFlightCount = InFlightCount + 1
                task.spawn(function()
                    ProcessOrder(orderState)
                    InFlightOrderIds[orderState.OrderId] = nil
                    InFlightCount = InFlightCount - 1
                end)
            end
        end)
        if not ok then
            notyuri("[Cafe] AutoCook error: " .. tostring(err))
        end
        task.wait(0.5)
    end
end
local AutoUpgradeSelected = function() return {} end
local function Func_AutoUpgrade()
    while Toggles.AutoUpgrade.Value do
        local ok, err = pcall(function()
            if not UpgradesConfig then
                Toggles.AutoUpgrade.Value = false
                return
            end
            local selectedIds = AutoUpgradeSelected()
            local sessionUpgrades = GetSessionUpgrades()
            local cash = RS:GetAttribute("CafeCash") or 0
            local bridge = GetBridge("RequestUpgradePurchase")
            if not bridge then
                Toggles.AutoUpgrade.Value = false
                return
            end
            for _, upgrade in ipairs(UpgradesConfig.GetUpgrades()) do
                if selectedIds[upgrade.Id] then
                    local level = UpgradesConfig.GetLevel(sessionUpgrades, upgrade.Id)
                    local price = UpgradesConfig.GetPrice(upgrade.Id, level)
                    local missing = UpgradesConfig.GetMissingRequirement(sessionUpgrades, upgrade.Id)
                    if not missing and price and cash >= price then
                        bridge:Fire(upgrade.Id)
                        cash = cash - price
                        task.wait(0.3)
                    end
                end
            end
        end)
        task.wait(1)
    end
end
local Window = Library:CreateWindow({
	Title = "Yuri",
	Center = true,
	AutoShow = true,
	Resizable = true,
	ShowCustomCursor = false,
	UnlockMouseWhileOpen = false,
	NotifySide = "Left",
	TabPadding = 8,
	MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
	Main = Window:AddTab("Main"),
    Player = Window:AddTab("Player"),
    ESP = Window:AddTab("ESP"),
    Config = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Autofarm"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
}
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
local TPW_T, TPW_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1})
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
GB.Player.Left.General:AddToggle("ThirdPerson", { Text = "Force Third Person" })
local FPS_T, FPS_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AntiKick", { Text = "Anti Kick (Client)" })
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused"})
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function()
    local Servers = game:HttpGet('https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100')
end})
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Plr) end })
GB.Player.Left.Server:AddToggle("AutoServerhop", { Text = "Auto Serverhop" })
GB.Player.Left.Server:AddSlider("AutoHopMins", { Text = "Minutes", Default = 30, Min = 0, Max = 300, Compact = true, Rounding = 0 })
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    TPW_S:SetVisible(TPW_T.Value)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Toggles.ThirdPerson:OnChanged(function(state)
    Plr:SetAttribute("CafeForcedThirdPerson", state or nil)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then Hum.JumpPower = Options.JPValue.Value Hum.UseJumpPower = true end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if FPS_T.Value then
        setfpscap(FPS_S.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    FPS_S:SetVisible(FPS_T.Value)
    if not v then
        setfpscap(999)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local function RunAntiAFK()
    local GC = getconnections or get_signal_cons
    if GC then
        for i,v in pairs(GC(Players.LocalPlayer.Idled)) do
            if v["Disable"] then
                v["Disable"](v)
            elseif v["Disconnect"] then
                v["Disconnect"](v)
            end
        end
    else
        Players.LocalPlayer.Idled:Connect(function()
            VirtualUser:CaptureController()
            VirtualUser:ClickButton2(Vector2.new())
        end)
    end
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then RunAntiAFK() end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
local CookingMinigameStartRefCount = 0
local function AcquireCookingMinigameStartConnection()
    CookingMinigameStartRefCount = CookingMinigameStartRefCount + 1
    if CookingMinigameStartRefCount == 1 then
        SafeConnect("CookingMinigameStart", function()
            local bridge = GetBridge("CookingMinigameStart")
            if not bridge then
                error("CookingMinigameStart bridge not available")
            end
            return bridge
        end, HandleCookingMinigameStart)
    end
end
local function ReleaseCookingMinigameStartConnection()
    CookingMinigameStartRefCount = math.max(0, CookingMinigameStartRefCount - 1)
    if CookingMinigameStartRefCount == 0 then
        if Connections.CookingMinigameStart then
            Connections.CookingMinigameStart:Disconnect()
            Connections.CookingMinigameStart = nil
        end
    end
end
TB_Tabs.Autofarm.T1:AddToggle("AutoCook", {
    Text = "Auto Cook",
    Default = false,
})
Toggles.AutoCook:OnChanged(function(state)
    Thread("AutoCook", SafeLoop("AutoCook", Func_AutoCafe), state)
    if state then
        AcquireCookingMinigameStartConnection()
    else
        ReleaseCookingMinigameStartConnection()
    end
end)

TB_Tabs.Autofarm.T1:AddToggle("AutoOrder", {
    Text = "Auto Order",
    Default = false,
})
Toggles.AutoOrder:OnChanged(function(state)
    Thread("AutoOrder", SafeLoop("AutoOrder", Func_AutoOrder), state)
    if state then
        AcquireCookingMinigameStartConnection()
    else
        ReleaseCookingMinigameStartConnection()
    end
end)
do
    local upgradeValues = {}
    if UpgradesConfig then
        for _, upgrade in ipairs(UpgradesConfig.GetUpgrades()) do
            table.insert(upgradeValues, upgrade.DisplayName)
        end
    end
    local upgradeLabelToId = {}
    if UpgradesConfig then
        for _, upgrade in ipairs(UpgradesConfig.GetUpgrades()) do
            upgradeLabelToId[upgrade.DisplayName] = upgrade.Id
        end
    end
    AutoUpgradeSelected = AddMultiDropdown(TB_Tabs.Autofarm2.T1, "UpgradeSelected", {
        Text = "Upgrades List",
        Values = upgradeValues,
        label = upgradeLabelToId,
    })
end
TB_Tabs.Autofarm.T1:AddToggle("AutoUpgrade", {
    Text = "Auto Upgrade",
    Default = false,
})
Toggles.AutoUpgrade:OnChanged(function(state)
    Thread("AutoUpgrade", SafeLoop("AutoUpgrade", Func_AutoUpgrade), state)
end)
TB_Tabs.Autofarm.T1:AddToggle("AutoRetry", {
    Text = "Auto Retry",
    Default = false,
})
Toggles.AutoRetry:OnChanged(function(state)
    Thread("AutoRetry", SafeLoop("AutoRetry", Func_AutoRetry), state)
end)
TB_Tabs.Autofarm.T1:AddToggle("AutoCoffee", {
    Text = "Auto Coffee",
    Default = false,
})
Toggles.AutoCoffee:OnChanged(function(state)
    Thread("AutoCoffee", SafeLoop("AutoCoffee", Func_AutoCoffee), state)
end)
TB_Tabs.Autofarm2.T1:AddSlider("CoffeeThreshold", {
    Text = "Coffee Threshold",
    Default = 95,
    Min = 0,
    Max = 100,
    Rounding = 0,
    Compact = true,
})
TB_Tabs.Autofarm.T1:AddToggle("AutoSkipDialogue", {
    Text = "Auto Skip Dialogue",
    Default = false,
})
TB_Tabs.Autofarm.T1:AddToggle("AutoJoin", {
    Text = "Auto Join",
    Default = false,
})
Toggles.AutoJoin:OnChanged(function(state)
    Thread("AutoJoin", SafeLoop("AutoJoin", Func_AutoJoin), state)
end)
Toggles.AutoSkipDialogue:OnChanged(function(state)
    if state then
        StartAutoSkipDialogue()
    else
        StopAutoSkipDialogue()
    end
end)
local ESPGroup = Tabs.ESP:AddLeftGroupbox("ESP")
ESPGroup:AddToggle("CustomerESP", { Text = "Customer", Default = false })
ESPGroup:AddLabel("Customer Color"):AddColorPicker("CustomerColor", {
    Title = "Customer Color",
    Default = Color3.fromRGB(80, 255, 120),
})
ESPGroup:AddLabel("Anomaly Color"):AddColorPicker("AnomalyColor", {
    Title = "Anomaly Color",
    Default = Color3.fromRGB(255, 60, 60),
})
ESPGroup:AddLabel("Outline Color"):AddColorPicker("CustomerOutline", {
    Title = "Outline Color",
    Default = Color3.fromRGB(0, 0, 0),
})
Toggles.CustomerESP:OnChanged(function()
    RefreshCustomerESP()
end)
task.spawn(SafeLoop("CustomerESP", FuncCustomerESP))
local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
	Default = Library.KeybindFrame.Visible,
	Text = "Open Keybind Menu",
	Callback = function(value)
		Library.KeybindFrame.Visible = value
	end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
	Text = "Custom Cursor",
	Default = false,
	Callback = function(Value)
		Library.ShowCustomCursor = Value
	end,
})
MenuGroup:AddDropdown("NotificationSide", {
	Values = { "Left", "Right" },
	Default = "Right",
	Text = "Notification Side",
	Callback = function(Value)
		Library:SetNotifySide(Value)
	end,
})
MenuGroup:AddDropdown("DPIDropdown", {
	Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
	Default = "100%",
	Text = "DPI Scale",
	Callback = function(Value)
		Value = Value:gsub("%%", "")
		local DPI = tonumber(Value)
		Library:SetDPIScale(DPI)
	end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
	:AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    Shared.Farm = false
    Cleanup(Connections)
    Cleanup(Flags)
    CustomerESPFolder:Destroy()
	Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
SaveManager:IgnoreThemeSettings()
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/AnomalyCafe")
SaveManager:BuildConfigSection(Tabs.Config)
ThemeManager:ApplyToTab(Tabs.Config)
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
SaveManager:SetLoadingOrder(true, {"Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle"})
if UIS.TouchEnabled and not UIS.KeyboardEnabled then
    Library:SetDPIScale(75)
elseif UIS.KeyboardEnabled then
    Library:SetDPIScale(100)
end
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end