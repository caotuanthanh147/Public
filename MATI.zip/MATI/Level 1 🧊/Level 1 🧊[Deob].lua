--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.UIKit [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("GuiService")
local var3 = game:GetService("Players")
local var4 = game:GetService("TweenService")
local var5 = require(var1:WaitForChild("FrozenHouse").Config).Palette
local tbl1 = { Panel = Color3.fromHex("#FFF8EC") }
tbl1.PanelEdge = Color3.fromHex("#E6D3B3")
tbl1.Text = var5.Text
tbl1.SubText = Color3.fromHex("#5B6B78")
tbl1.Action = var5.Orange
tbl1.ActionDark = var5.OrangeDark
tbl1.Secondary = Color3.fromHex("#E3EEF4")
tbl1.Good = var5.Teal
tbl1.Track = Color3.fromHex("#DCE7EE")
tbl1.Coin = Color3.fromHex("#F6C445")
tbl1.CoinDark = Color3.fromHex("#E0A526")
local tbl2 = { Colors = tbl1 }
tbl1 = { Display = Font.new("rbxasset://fonts/families/FredokaOne.json") }
tbl1.Body = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Medium)
tbl1.Bold = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
tbl2.Fonts = tbl1
tbl2.new = function(arg1, arg2, arg3)
	local var1 = arg2
	local var2 = Instance.new(arg1)
	for k1, v1 in pairs(var1 or {}) do
		if k1 == "Parent" then
			continue
		end

		var2[k1] = v1
	end

	var1 = arg3
	for k2, v2 in ipairs(var1 or {}) do
		v2.Parent = var2
	end

	if arg2 and arg2.Parent then
		var2.Parent = arg2.Parent
	end

	return var2
end

tbl1 = tbl2.new
tbl2.corner = function(arg1)
	local str1 = "UICorner"
	local tbl2 = { CornerRadius = UDim.new(0, arg1 or 14) }
	return tbl1(str1, tbl2)
end

tbl2.stroke = function(arg1, arg2, arg3)
	local var1 = arg1
	local tbl3 = { Color = var1 or tbl2.Colors.PanelEdge }
	tbl3.Thickness = arg2 or 2
	tbl3.Transparency = arg3 or 0
	tbl3.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	local str1 = "UIStroke"
	return tbl1(str1, tbl3)
end

tbl2.padding = function(arg1)
	local tbl2 = { PaddingLeft = UDim.new(0, arg1) }
	tbl2.PaddingRight = UDim.new(0, arg1)
	tbl2.PaddingTop = UDim.new(0, arg1)
	tbl2.PaddingBottom = UDim.new(0, arg1)
	local str1 = "UIPadding"
	return tbl1(str1, tbl2)
end

tbl2.tween = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg4
	local var2 = arg5
	local var3 = var4:Create(arg1, TweenInfo.new(arg2, var1 or Enum.EasingStyle.Quad, var2 or Enum.EasingDirection.Out), arg3)
	var3:Play()
	return var3
end

tbl2.screen = function(arg1, arg2)
	return (tbl1("ScreenGui", {
		Name = arg1,
		ResetOnSpawn = false,
		IgnoreGuiInset = false,
		ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets,
		ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
		DisplayOrder = arg2 or 0,
		Parent = var3.LocalPlayer:WaitForChild("PlayerGui"),
	}))
end

local var6 = Vector2.new(1280, 720)
tbl2.backdrop = function(arg1)
	local var1 = arg1.BackgroundColor3
	var1 = var1 or Color3.new(0, 0, 0)
	local var3 = tbl1
	local var4 = arg1.Class or "TextButton"
	local tbl3 = {
		Name = arg1.Name or "Backdrop",
		BackgroundColor3 = var1,
		BorderSizePixel = 0,
		Selectable = false,
	}

	if arg1.BackgroundTransparency ~= nil then
		var1 = arg1.BackgroundTransparency
	else
		var1 = 0.45
	end

	tbl3.BackgroundTransparency = var1
	tbl3.AnchorPoint = Vector2.zero
	tbl3.ZIndex = arg1.ZIndex or 0
	tbl3.Visible = if arg1.Visible ~= nil then arg1.Visible else true
	tbl3.Parent = arg1.Parent
	var3 = var3(var4, tbl3)
	if var3:IsA("TextButton") then
		var3.Text = ""
		var3.AutoButtonColor = false
		if arg1.Modal ~= nil then
			var3.Modal = arg1.Modal
		end
	end

	if arg1.Active ~= nil then
		var3.Active = arg1.Active
	end

	var4 = {}
	tbl3 = nil
	var1 = function()
		local num1 = 1
		local var1 = var3.Parent
		local var2 = var1:FindFirstChildOfClass("UIScale")
		while not var1 and var1 == game and var2 and (not var4[var2]) do
			num1 = num1 * var2.Scale
		end

		return num1
	end

	tbl3 = function()
		local var5 = var3.Parent
		if not var5 or (not var5:IsDescendantOf(game)) then
			return
		end

		local var7 = var1()
		if var7 <= 0 then
			return
		end

		local var9 = workspace.CurrentCamera
		if not var9 then
			return
		end

		local var10 = -var2:GetGuiInset()
		local var11 = var5.AbsolutePosition
		var3.Position = UDim2.fromOffset(math.floor((var10.X - var11.X) / var7) - 1, math.floor((var10.Y - var11.Y) / var7) - 1)
		local var12 = var9.ViewportSize
		var3.Size = UDim2.fromOffset(math.ceil(var12.X / var7) + 2, math.ceil(var12.Y / var7) + 2)
	end

	tbl3()
	task.defer(tbl3)
	local var6 = workspace.CurrentCamera
	if var6 then
		var6:GetPropertyChangedSignal("ViewportSize"):Connect(tbl3)
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		local var2 = workspace.CurrentCamera
		if var2 then
			var2:GetPropertyChangedSignal("ViewportSize"):Connect(tbl3)
		end

		tbl3()
	end)

	if arg1.Parent then
		arg1.Parent:GetPropertyChangedSignal("AbsoluteSize"):Connect(tbl3)
	end

	var3:GetPropertyChangedSignal("Visible"):Connect(tbl3)
	local var8 = var3:FindFirstAncestorWhichIsA("LayerCollector")
	if var8 then
		var8:GetPropertyChangedSignal("Enabled"):Connect(function()
			if var8.Enabled then
				task.defer(tbl3)
			end
		end)

		var8:GetPropertyChangedSignal("AbsoluteSize"):Connect(tbl3)
	end

	return var3
end

tbl2.autoScale = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = tbl1("UIScale", { Parent = arg1 })
	var1:GetPropertyChangedSignal("ViewportSize"):Connect(function()
		local var3 = var1.ViewportSize
		var2.Scale = math.min(var3.X / var6.X, var3.Y / var6.Y, 1.35)
	end)

	local var3 = var1.ViewportSize
	var2.Scale = math.min(var3.X / var6.X, var3.Y / var6.Y, 1.35)
	return var2
end

tbl2.fitText = function(arg1)
	if arg1.AutomaticSize ~= Enum.AutomaticSize.None or arg1.TextScaled then
		return arg1
	end

	arg1.TextScaled = true
	local var1 = arg1.TextSize
	local tbl2 = { MaxTextSize = var1, MinTextSize = math.min(var1, 8) }
	tbl2.Parent = arg1
	tbl1("UITextSizeConstraint", tbl2)
	return arg1
end

tbl2.panel = function(arg1)
	local var1 = arg1
	local var2 = tbl1("Frame", { BackgroundColor3 = tbl2.Colors.Panel, BorderSizePixel = 0 })
	for k1, v1 in pairs(var1 or {}) do
		if k1 == "Parent" or k1 == "Radius" then
			continue
		end

		var2[k1] = v1
	end

	tbl2.corner(arg1 and arg1.Radius or 16).Parent = var2
	tbl2.stroke().Parent = var2
	if arg1 and arg1.Parent then
		var2.Parent = arg1.Parent
	end

	return var2
end

tbl2.label = function(arg1)
	local var1 = arg1
	local var2 = tbl1("TextLabel", {
		BackgroundTransparency = 1,
		TextColor3 = tbl2.Colors.Text,
		FontFace = tbl2.Fonts.Body,
		TextSize = 20,
		TextWrapped = true,
	})

	for k1, v1 in pairs(var1 or {}) do
		if k1 == "Parent" then
			continue
		end

		var2[k1] = v1
	end

	tbl2.fitText(var2)
	if arg1 and arg1.Parent then
		var2.Parent = arg1.Parent
	end

	return var2
end

local tbl3 = {}
local function selection(arg1)
	local var1 = math.floor((arg1 or 14) + 0.5)
	local var3 = tbl3[var1]
	if not var3 then
		local tbl4 = { Name = "FocusRing", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1) }
		local var4 = tbl2.corner(var1)
		local var6 = tbl1("UIStroke", { Color = var5.Focus, Thickness = 4, ApplyStrokeMode = Enum.ApplyStrokeMode.Border })
		local tbl5 = {
			Name = "Inner",
			BackgroundColor3 = var5.FocusGlow,
			BackgroundTransparency = 0.84,
			BorderSizePixel = 0,
			Position = UDim2.fromOffset(3, 3),
		}

		tbl5.Size = UDim2.new(1, -6, 1, -6)
		local var7 = tbl2.corner((math.max(2, var1 - 3)))
		local str1 = "UIStroke"
		local tbl6 = { Color = var5.Focus, Thickness = 2, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
		local str2 = "Frame"
		local tbl7 = { var7, tbl1(str1, tbl6) }
		var3 = tbl1("Frame", tbl4, { var4, var6, tbl1(str2, tbl5, tbl7) })
		tbl3[var1] = var3
	end

	return var3
end

tbl2.focusRing = function(arg1, arg2)
	arg1.SelectionImageObject = selection(arg2)
	local var2 = arg1:FindFirstChildOfClass("UIScale")
	if not var2 then
		var2 = tbl1("UIScale", { Parent = arg1 })
	end

	arg1.SelectionGained:Connect(function()
		tbl2.tween(var2, 0.12, { Scale = 1.04 })
	end)

	arg1.SelectionLost:Connect(function()
		tbl2.tween(var2, 0.12, { Scale = 1 })
	end)

	return arg1
end

tbl2.setEnabled = function(arg1, arg2)
	arg1.Active = arg2
	arg1.Selectable = arg2
	arg1.BackgroundTransparency = if arg2 then 0 else 0.45
	if arg1:IsA("TextButton") then
		arg1.TextTransparency = if arg2 then 0 else 0.4
	end

	return arg1
end

tbl2.button = function(arg1)
	local var1 = arg1.Secondary
	local var2 = arg1.Size
	var2 = var2 or UDim2.fromOffset(180, 52)
	local tbl3 = {
		AutoButtonColor = false,
		BackgroundColor3 = var1 and tbl2.Colors.Secondary or tbl2.Colors.Action,
		BorderSizePixel = 0,
		Text = arg1.Text or "",
		TextColor3 = tbl2.Colors.Text,
		FontFace = tbl2.Fonts.Display,
		TextSize = arg1.TextSize or 22,
		Size = var2,
		ClipsDescendants = false,
	}

	var2 = arg1.Position
	var2 = var2 or UDim2.new()
	tbl3.Position = var2
	var2 = arg1.AnchorPoint
	tbl3.AnchorPoint = var2 or Vector2.zero
	tbl3.LayoutOrder = arg1.LayoutOrder or 0
	tbl3.Name = arg1.Name or "Button"
	tbl3.SelectionImageObject = selection(arg1.Radius)
	local var3 = tbl1("TextButton", tbl3)
	tbl2.corner(arg1.Radius or 14).Parent = var3
	tbl2.fitText(var3)
	tbl2.stroke(var1 and tbl2.Colors.PanelEdge or tbl2.Colors.ActionDark, 2).Parent = var3
	tbl3 = tbl1("UIScale", { Parent = var3 })
	var3.MouseEnter:Connect(function()
		tbl2.tween(tbl3, 0.12, { Scale = 1.04 })
	end)

	var3.MouseLeave:Connect(function()
		tbl2.tween(tbl3, 0.12, { Scale = 1 })
	end)

	var3.MouseButton1Down:Connect(function()
		tbl2.tween(tbl3, 0.08, { Scale = 0.95 })
	end)

	var3.MouseButton1Up:Connect(function()
		tbl2.tween(tbl3, 0.12, { Scale = 1 })
	end)

	var3.SelectionGained:Connect(function()
		tbl2.tween(tbl3, 0.12, { Scale = 1.04 })
	end)

	var3.SelectionLost:Connect(function()
		tbl2.tween(tbl3, 0.12, { Scale = 1 })
	end)

	if arg1.OnClick then
		var3.Activated:Connect(arg1.OnClick)
	end

	if arg1.Parent then
		var3.Parent = arg1.Parent
	end

	return var3
end

tbl2.setButtonStyle = function(arg1, arg2)
	local var1 = arg1:FindFirstChildOfClass("UIStroke")
	if arg2 == "action" then
		arg1.BackgroundColor3 = tbl2.Colors.Action
		arg1.TextColor3 = tbl2.Colors.Text
		if not var1 then
			return
		end

		var1.Color = tbl2.Colors.ActionDark
		return
	end

	if arg2 == "done" then
		arg1.BackgroundColor3 = var5.Teal
		arg1.TextColor3 = var5.White
		if not var1 then
			return
		end

		var1.Color = Color3.fromHex("#3E958D")
		return
	end

	arg1.BackgroundColor3 = tbl2.Colors.Secondary
	arg1.TextColor3 = tbl2.Colors.SubText
	if var1 then
		var1.Color = tbl2.Colors.PanelEdge
	end
end

tbl2.progressBar = function(arg1)
	local var1 = arg1.Position
	var1 = var1 or UDim2.new()
	local tbl3 = {
		Name = arg1.Name or "Progress",
		BackgroundColor3 = tbl2.Colors.Track,
		BorderSizePixel = 0,
		Size = arg1.Size,
		Position = var1,
	}

	var1 = arg1.AnchorPoint
	tbl3.AnchorPoint = var1 or Vector2.zero
	tbl3.LayoutOrder = arg1.LayoutOrder or 0
	local var2 = arg1.Radius or 8
	local var3 = tbl1("Frame", tbl3, { tbl2.corner(var2) })
	local var4 = arg1.Color
	var1 = { Name = "Fill", BackgroundColor3 = var4 or var5.Orange, BorderSizePixel = 0 }
	var1.Size = UDim2.fromScale(0, 1)
	local num1 = 235
	local num2 = 235
	local num3 = 235
	var2 = tbl2.corner(arg1.Radius or 8)
	local str1 = "UIGradient"
	local tbl4 = {
		Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(num1, num2, num3)),
		Rotation = 90,
	}

	local var6 = tbl1("Frame", var1, { var2, tbl1(str1, tbl4) })
	var6.Parent = var3
	if arg1.Parent then
		var3.Parent = arg1.Parent
	end

	return {
		set = function(arg1, arg2)
			local var1 = UDim2.fromScale(math.clamp(arg1, 0, 1), 1)
			if arg2 then
				var6.Size = var1
				return
			end

			tbl2.tween(var6, 0.25, { Size = var1 })
		end,
		track = var3,
		fill = var6,
	}
end

tbl2.coin = function(arg1)
	local var1 = arg1
	local var2 = tbl1("Frame", {
		Name = "Coin",
		BackgroundColor3 = tbl2.Colors.CoinDark,
		Size = UDim2.fromOffset(arg1, arg1),
	}, { tbl2.corner(var1) })

	local tbl3 = { BackgroundColor3 = tbl2.Colors.Coin, AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl3.Position = UDim2.fromScale(0.5, 0.5)
	tbl3.Size = UDim2.fromScale(0.74, 0.74)
	tbl3.Parent = var2
	var1 = tbl2.corner(arg1)
	local tbl4 = { Color = Color3.fromHex("#FBE29A") }
	tbl4.Thickness = math.max(1, arg1 / 14)
	local str1 = "UIStroke"
	tbl1("Frame", tbl3, { var1, tbl1(str1, tbl4) })
	tbl3 = { BackgroundColor3 = Color3.fromHex("#FFF3C4"), BackgroundTransparency = 0.2 }
	tbl3.Position = UDim2.fromScale(0.28, 0.24)
	tbl3.Size = UDim2.fromScale(0.2, 0.2)
	tbl3.Parent = var2
	local var3 = arg1
	tbl1("Frame", tbl3, { tbl2.corner(var3) })
	return var2
end

tbl2.toolPreview = function(arg1, arg2)
	local var2 = arg2
	var2 = var2 or UDim2.fromOffset(96, 96)
	local tbl2 = {
		Name = "Preview",
		BackgroundTransparency = 1,
		Size = var2,
		LightDirection = Vector3.new(-1, -1, -1),
	}

	tbl2.Ambient = Color3.fromRGB(190, 190, 200)
	tbl2.LightColor = Color3.fromRGB(255, 244, 230)
	local var3 = var1:FindFirstChild("FrozenHouseAssets")
	local var4 = tbl1("ViewportFrame", tbl2)
	tbl2 = var3
	tbl2 = tbl2 and (var3:FindFirstChild("Tools") and var3.Tools:FindFirstChild(arg1))
	if tbl2 then
		var2 = Instance.new("Model")
		for k1, v1 in ipairs(tbl2:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			v1:Clone().Parent = var2
		end

		var2.Parent = var4
		local var5, var6 = var2:GetBoundingBox()
		local var7 = var6.Magnitude * 1.9
		local var8 = tbl1("Camera", { FieldOfView = 30, Parent = var4 })
		var8.CFrame = CFrame.lookAt(var5.Position + Vector3.new(var7 * 0.75, var7 * 0.35, -var7 * 0.35), var5.Position)
		var4.CurrentCamera = var8
	end

	return var4
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Arrival [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = require(var1.Config)
local var3 = require(script.Parent.UIKit)
local var4 = nil
local var5 = nil
local var6 = require(script.Parent.ClientState)
local var7 = require(var1.Layout)
local var8 = var3.new
local var9 = var2.Palette
local var10 = game:GetService("RunService")
local function hideArrow()
	if var5 then
		var5:Destroy()
		var5 = nil
	end
end

local bool1 = false
local var11 = nil
local var12 = nil
local function showArrow()
	if var5 or var6.attr("FrontDoorOpen") then
		return
	end

	local var1 = Instance.new("Part")
	var1.Name = "EntranceArrowAnchor"
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.CFrame = CFrame.new(var7.EntranceArrowTarget)
	var1.Parent = workspace
	local var4 = Instance.new("BillboardGui")
	var4.Size = UDim2.fromOffset(150, 110)
	var4.AlwaysOnTop = true
	var4.MaxDistance = 120
	var4.StudsOffsetWorldSpace = Vector3.new(0, 5, 0)
	var4.Parent = var1
	local tbl1 = { BackgroundTransparency = 1, ClipsDescendants = true, AnchorPoint = Vector2.new(0.5, 0) }
	tbl1.Position = UDim2.fromScale(0.5, 0.42)
	tbl1.Size = UDim2.fromOffset(64, 40)
	tbl1.Parent = var4
	local var11 = var8("Frame", tbl1)
	local tbl2 = { BackgroundColor3 = var9.Orange, AnchorPoint = Vector2.new(0.5, 0.5), Rotation = 45 }
	tbl2.Position = UDim2.new(0.5, 0, 0, -6)
	tbl2.Size = UDim2.fromOffset(44, 44)
	tbl2.Parent = var11
	local str1 = "UIStroke"
	local tbl3 = { Color = var9.Text, Thickness = 3 }
	var8("Frame", tbl2, { var8(str1, tbl3) })
	tbl1 = {
		Text = "Melt the door free",
		FontFace = var3.Fonts.Display,
		TextScaled = true,
		TextColor3 = var9.White,
		TextStrokeColor3 = var9.Text,
		TextStrokeTransparency = 0.1,
		Size = UDim2.new(1, 0, 0.36, 0),
	}

	tbl1.Parent = var4
	var3.label(tbl1)
	var5 = var1
	tbl1 = nil
	local num1 = 0
	var10.RenderStepped:Connect(function(arg1)
		if not var5 then
			tbl1:Disconnect()
			return
		end

		local var1 = num1 + arg1
		num1 = var1
		var4.StudsOffsetWorldSpace = Vector3.new(0, math.sin(num1 * 4) * 0.6 + 5, 0)
	end)

	task.delay(var2.Arrival.ArrowSeconds, hideArrow)
end

local var13 = game:GetService("Players")
local function updateWaiting()
	local var3 = var6.attr("ExpectedCount") or 0
	local var4 = var6.attr("ReadyCount") or 0
	local bool2 = false
	if var6.phase() == "Arriving" then
		bool2 = false
		if 1 < var3 then
			bool2 = not var6.cinematic
		end
	end

	var11.Visible = bool2
	if bool2 then
		var11.Label.Text = string.format(var2.Text.Waiting, math.min(var4, var3), var3)
	end
end

local function startMoment()
	if bool1 or (var6.phase() == "Arriving" or var6.cinematic) then
		return
	end

	bool1 = true
	var11.Visible = false
	if var6.phase() == "Running" then
		if var6.attr("Difficulty") == "hard" then
			var12.HUD.banner(var2.Text.HardBanner)
			var12.HUD.toast(var2.Text.HardDetail, 4)
		end

		var12.HUD.banner(var2.Text.StartBanner)
		showArrow()
	end
end

local var14 = nil
return {
	ready = function()
		task.spawn(function()
			local var1 = var13.LocalPlayer.Character
			local var5 = var1
			var5 = var5 and var1:FindFirstChild("HumanoidRootPart")
			var4.Visible = true
			var4.GroupTransparency = 1
			var3.tween(var4, 0.35, { GroupTransparency = 0 })
			if var5 then
				local var10 = var1:FindFirstChild("Head")
				local var11 = var10 and var10.Position or var5.Position + Vector3.new(0, 1.5, 0)
				local var14 = var7.EntranceArrowTarget
				local var15 = CFrame.lookAt(var11, (Vector3.new(var14.X, var11.Y, var14.Z)))
				var12.Cinematics.play({
					{ cf = var7.Cameras.EstablishingFrom, time = 0 },
					{ cf = var7.Cameras.EstablishingTo, time = var2.Arrival.EstablishingSeconds * 0.6 },
					{ cf = var15, time = var2.Arrival.EstablishingSeconds * 0.4 },
				}, { hideHud = true })

			end

			var3.tween(var4, 0.4, { GroupTransparency = 1 })
			task.delay(0.42, function()
				var4.Visible = false
			end)

			updateWaiting()
			startMoment()
		end)
	end,
	init = function(arg1)
		var12 = arg1
		var14 = var3.screen("FrozenHouseArrival", 25)
		var3.autoScale(var14)
		local tbl1 = {
			Name = "TitleCard",
			BackgroundTransparency = 1,
			AnchorPoint = Vector2.new(0.5, 0.5),
			Visible = false,
		}

		tbl1.Position = UDim2.fromScale(0.5, 0.32)
		tbl1.Size = UDim2.fromOffset(760, 170)
		tbl1.Parent = var14
		var4 = var8("CanvasGroup", tbl1)
		local tbl2 = {
			Text = var2.Title,
			FontFace = var3.Fonts.Display,
			TextSize = 76,
			TextColor3 = var9.White,
			Size = UDim2.new(1, 0, 0, 96),
		}

		tbl2.Parent = var4
		var3.label(tbl2, nil)
		local var1 = var8("UIStroke", { Color = var9.DeepBlue, Thickness = 5 })
		var1.Parent = var4:FindFirstChildOfClass("TextLabel")
		local tbl3 = { BackgroundColor3 = var9.Orange, AnchorPoint = Vector2.new(0.5, 0) }
		tbl3.Position = UDim2.new(0.5, 0, 0, 104)
		tbl3.Size = UDim2.fromOffset(300, 48)
		local var7 = var3.corner(24)
		local str1 = "UIStroke"
		local tbl4 = { Color = var9.OrangeDark, Thickness = 3 }
		tbl2 = var8("Frame", tbl3, { var7, var8(str1, tbl4) })
		tbl2.Parent = var4
		tbl3 = {
			Text = "Level 1 \194\183 " .. var2.LevelName,
			FontFace = var3.Fonts.Display,
			TextSize = 26,
			Size = UDim2.fromScale(1, 1),
		}

		tbl3.Parent = tbl2
		var3.label(tbl3)
		local tbl5 = {
			Name = "Waiting",
			BackgroundColor3 = var3.Colors.Panel,
			AnchorPoint = Vector2.new(0.5, 1),
			Visible = false,
		}

		tbl5.Position = UDim2.new(0.5, 0, 1, -100)
		tbl5.Size = UDim2.fromOffset(380, 52)
		tbl5.Parent = var14
		local var10 = var3.corner(26)
		tbl4 = "UIStroke"
		local tbl6 = { Color = var9.DeepBlue, Thickness = 3 }
		var11 = var8("CanvasGroup", tbl5, { var10, var8(tbl4, tbl6) })
		tbl3 = {
			Name = "Label",
			Text = "",
			FontFace = var3.Fonts.Display,
			TextSize = 24,
			Size = UDim2.fromScale(1, 1),
		}

		tbl3.Parent = var11
		var3.label(tbl3)
		var10 = "ReadyCount"
		for k1, v1 in ipairs({ "ExpectedCount", var10, "Phase" }) do
			var6.onAttr(v1, updateWaiting)
		end

		var6.onAttr("Phase", function()
			task.defer(startMoment)
		end)

		var6.cinematicChanged:Connect(function(arg1)
			if not arg1 then
				task.defer(startMoment)
			end

			updateWaiting()
		end)

		var6.localMelt:Connect(hideArrow)
		var6.onAttr("FrontDoorOpen", function(arg1)
			if arg1 and var5 then
				var5:Destroy()
				var5 = nil
			end
		end)
	end,
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Audio [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = game:GetService("Players")
local var3 = game:GetService("RunService")
local var4 = game:GetService("SoundService")
local var5 = game:GetService("TweenService")
local var6 = require(var1.AudioConfig)
local var7 = require(var1.Layout)
local var8 = require(script.Parent.ClientState)
local var9 = require(script.Parent.IceWorld)
local var10 = require(script.Parent.Input)
local tbl1 = {}
local tbl2 = {}
local tbl3 = {}
local function playTemplate(arg1, arg2, arg3, arg4)
	local var2 = tbl2[arg1]
	if not var2 then
		return
	end

	local var3 = var2:Clone()
	local var5 = var3.Volume * arg2
	var3.Volume = var5
	var5 = var3.PlaybackSpeed * arg3
	var3.PlaybackSpeed = var5
	if arg4 then
		var5 = var3.PlaybackSpeed * (1 + (math.random() * 2 - 1) * arg4)
		var3.PlaybackSpeed = var5
	end

	var3.Parent = var4
	var3.Ended:Once(function()
		var3:Destroy()
	end)

	var3:Play()
	task.delay(12, function()
		if var3.Parent then
			var3:Destroy()
		end
	end)
end

local tbl4 = {
	play = function(arg1, arg2, arg3)
		local var2 = os.clock()
		local var3
		if arg2 and var2 - (tbl3[arg1] or 0) < arg2 then
			var3 = false
		else
			tbl3[arg1] = var2
			var3 = true
		end

		if var3 then
			playTemplate(arg1, 1, 1, arg3)
		end
	end,
	playTuned = function(arg1, arg2, arg3, arg4)
		local var3 = arg1 .. "@" .. arg3
		local var4 = os.clock()
		local var5
		if arg4 and var4 - (tbl3[var3] or 0) < arg4 then
			var5 = false
		else
			tbl3[var3] = var4
			var5 = true
		end

		if var5 then
			playTemplate(arg1, arg2, arg3)
		end
	end,
}

tbl4.batteryLow = function()
	tbl4.playTuned("UITick", 0.9, 0.62, 1)
	task.delay(0.14, function()
		tbl4.playTuned("UITick", 0.9, 0.52, 1)
	end)
end

tbl4.batteryReady = function()
	tbl4.playTuned("Purchase", 0.3, 1.6, 2)
end

tbl4.manualOpen = function()
	tbl4.playTuned("UITick", 1, 0.8, 0.15)
end

tbl4.manualClose = function()
	tbl4.playTuned("UITick", 0.8, 1.15, 0.15)
end

local function makeSound(arg1, arg2)
	local var2 = var6[arg1]
	if not var2 then
		return nil
	end

	local var3 = Instance.new("Sound")
	var3.Name = arg1
	var3.SoundId = var2.Id
	var3.Volume = var2.Volume
	var3.PlaybackSpeed = var2.Speed or 1
	var3.Looped = var2.Loop == true
	var3.SoundGroup = tbl1[var2.Group]
	if var2.Region then
		var3.PlaybackRegionsEnabled = true
		var3.PlaybackRegion = NumberRange.new(var2.Region[1], var2.Region[2])
		if var2.Loop then
			var3.LoopRegion = NumberRange.new(var2.Region[1], var2.Region[2])
		end
	end

	local var5 = arg2
	var3.Parent = var5 or var4
	return var3
end

tbl4.playAt = function(arg1, arg2, arg3)
	local var2 = os.clock()
	local var3
	if arg3 and var2 - (tbl3[arg1] or 0) < arg3 then
		var3 = false
	else
		tbl3[arg1] = var2
		var3 = true
	end

	if not var3 then
		return
	end

	var3 = Instance.new("Attachment")
	var3.WorldPosition = arg2
	var3.Parent = workspace.Terrain
	var2 = makeSound(arg1, var3)
	if not var2 then
		var3:Destroy()
		return
	end

	var2.RollOffMaxDistance = 80
	var2.RollOffMinDistance = 8
	local var4 = var2.PlaybackSpeed * (0.92 + math.random() * 0.16)
	var2.PlaybackSpeed = var4
	var2.Ended:Once(function()
		var3:Destroy()
	end)

	var2:Play()
	task.delay(8, function()
		if var3.Parent then
			var3:Destroy()
		end
	end)
end

local tbl5 = {}
local tbl6 = {
	Hairdryer = { "Hairdryer" },
	HeatGun = { "HeatGunMotor", "HeatGunHiss" },
	SteamBlaster = { "SteamJet", "SteamHum" },
	Flamethrower = { "FlameLoop" },
}

local tbl7 = {
	SteamBlaster = { start = "SteamRelease" },
	Flamethrower = { start = "FlameIgnite", stop = "FlameStop" },
}

local function playOn(arg1, arg2)
	local var2 = makeSound(arg1, arg2)
	if not var2 then
		return
	end

	var2.RollOffMinDistance = 6
	var2.RollOffMaxDistance = 60
	var2.Ended:Once(function()
		var2:Destroy()
	end)

	var2:Play()
	task.delay(6, function()
		if var2.Parent then
			var2:Destroy()
		end
	end)
end

local num1 = -math.huge
local tbl8 = {}
tbl4.windDownFreezer = function(arg1)
	local var2 = tbl8.FreezerHum
	if var2 then
		var5:Create(var2, TweenInfo.new(arg1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { PlaybackSpeed = 0.25, Volume = 0 }):Play()
	end
end

local function applyVolumes()
	tbl1.Music.Volume = var8.settings.MusicVolume
	tbl1.Effects.Volume = var8.settings.EffectsVolume
end

local function updateToolLoops()
	local tbl1 = {}
	for k1, v1 in ipairs(var2:GetPlayers()) do
		local var1 = v1.Character
		local var3 = var1
		var3 = var3 and var1:FindFirstChildOfClass("Tool")
		local var4 = var3
		local str1 = "ToolId"
		local var6 = var3
		var4 = var4 and var3:GetAttribute(str1)
		var6 = var6 and var3:FindFirstChild("Handle")
		if not var1 or (not var4) or (not var6) then
			continue
		end

		tbl1[var1] = true
		str1 = tbl5[var1]
		if str1 then
			local var7
			local var8
			if str1.toolId ~= var4 or str1.handle ~= var6 then
				if str1 then
					for k2, v2 in ipairs(str1.sounds) do
						v2:Destroy()
					end
				end

				local var9 = tbl6[var4]
				str1 = { toolId = var4, handle = var6, sounds = {}, on = false }
				for k3, v3 in ipairs(var9 or {}) do
					local var11 = makeSound(v3, var6)
					if not var11 then
						continue
					end

					var11.RollOffMinDistance = 6
					var11.RollOffMaxDistance = 60
					var11:SetAttribute("TargetVolume", var11.Volume)
					var11:SetAttribute("BaseSpeed", var11.PlaybackSpeed)
					var11.Volume = 0
					var7 = var11
					table.insert(str1.sounds, var7)
				end

				tbl5[var1] = str1
			end
		end

		local var13 = nil
		if v1 == var2.LocalPlayer then
			var13 = var10.firing
		else
			var13 = v1:GetAttribute("Melting") == true
		end

		if var13 == str1.on then
			continue
		end

		str1.on = var13
		local var14 = tbl7[var4]
		local var16 = var14
		if var16 then
			var16 = if var13 then var14.start else var14.stop
		end

		if var16 then
			playOn(var16, var6)
		end

		local var18 = not var13
		if var18 then
			var18 = false
			if v1 == var2.LocalPlayer then
				var18 = os.clock() - num1 < 0.3
			end
		end

		for k4, v4 in ipairs(str1.sounds) do
			local var19 = v4:GetAttribute("BaseSpeed") or 1
			if var13 then
				v4.PlaybackSpeed = var19
				if not v4.IsPlaying then
					v4:Play()
				end

				local var20 = v4:GetAttribute("TargetVolume")
				local var21 = TweenInfo.new(0.12)
				var5:Create(v4, var21, { Volume = var20 }):Play()
			elseif var18 then
				local var22 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				var5:Create(v4, var22, { Volume = 0, PlaybackSpeed = var19 * 0.5 }):Play()
			else
				var5:Create(v4, TweenInfo.new(0.25), { Volume = 0 }):Play()
			end
		end
	end

	for k5, v5 in pairs(tbl5) do
		if tbl1[k5] then
			continue
		end

		for k6, v6 in ipairs(v5.sounds) do
			v6:Destroy()
		end

		tbl5[k5] = nil
	end
end

local function updateAmbience()
	local var1 = var8.character()
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
	if not var2 then
		return
	end

	local var3 = var2.Position
	local var4 = var7.inside(var7.box(-28, -14, -36, 28, 27, 14), var3)
	local var9 = var3.Y < -2
	local bool1 = true
	if var8.phase() ~= "Complete" then
		bool1 = var8.phase() == "Finale"
	end

	local var10 = if var4 then 0.04 else var6.Wind.Volume
	local var11 = var4 and var6.RoomTone.Volume or 0
	local num1 = 0
	if not bool1 then
		local var12 = math.clamp(1 - ((var3 - Vector3.new(-21, -7, -2)).Magnitude - 10) / 40, 0, 1) * var6.FreezerHum.Volume
		num1 = var12 * (if var9 then 1 else 0.35)
	end

	local var13 = TweenInfo.new(1)
	var5:Create(tbl8.Wind, var13, { Volume = var10 }):Play()
	var13 = TweenInfo.new(1)
	var5:Create(tbl8.RoomTone, var13, { Volume = var11 }):Play()
	if var8.phase() ~= "Finale" then
		local var14 = TweenInfo.new(1)
		var5:Create(tbl8.FreezerHum, var14, { Volume = num1 }):Play()
	end
end

tbl4.init = function()
	local str1 = "Effects"
	for k1, v1 in ipairs({ "Music", str1 }) do
		local var1 = var4:FindFirstChild("FrozenHouse" .. v1)
		var1 = var1 or Instance.new("SoundGroup")
		var1.Name = "FrozenHouse" .. v1
		var1.Parent = var4
		tbl1[v1] = var1
	end

	tbl1.Music.Volume = var8.settings.MusicVolume
	tbl1.Effects.Volume = var8.settings.EffectsVolume
	var8.settingsChanged:Connect(applyVolumes)
	local var2 = Instance.new("Folder")
	var2.Name = "FrozenHouseSoundTemplates"
	var2.Parent = var4
	local str2 = "CellFinish"
	for k2, v2 in ipairs({
		"Crack",
		str2,
		"Drips",
		"UITick",
		"Purchase",
		"RoomClear",
		"Reveal",
		"ToastPop",
		"Jingle",
	}) do

		tbl2[v2] = makeSound(v2, var2)
	end

	tbl8.Wind = makeSound("Wind")
	tbl8.RoomTone = makeSound("RoomTone")
	tbl8.FreezerHum = makeSound("FreezerHum")
	tbl8.Music = makeSound("Music")
	for k3, v3 in pairs(tbl8) do
		if v3 ~= tbl8.Music then
			v3.Volume = 0
		end

		v3:Play()
	end

	local var7 = makeSound("Sizzle")
	var7.Volume = 0
	var7:Play()
	local num2 = 0
	var9.burst:Connect(function(arg1, arg2)
		local var1 = os.clock()
		if var1 - num2 < 0.35 then
			return
		end

		num2 = var1
		tbl4.playAt("CellFinish", arg1, 0.09)
		if 4 <= arg2 and math.random() < 0.25 then
			tbl4.playAt("Crack", arg1, 0.8)
		end
	end)

	var8.on("RegionCleared", function()
		tbl4.play("RoomClear", 0.5)
	end)

	var8.on("KeyPieceFound", function()
		tbl4.playTuned("Reveal", 1.2, 1.2, 0.5)
	end)

	var8.on("BasementOpen", function()
		tbl4.play("Reveal", 0.5)
	end)

	var8.on("Reveal", function(arg1)
		if arg1.key == "Toaster" then
			tbl4.play("ToastPop", 0.5)
			return
		end

		if arg1.key ~= "WelcomeMat" then
			tbl4.play("Reveal", 0.4)
		end
	end)

	var8.on("ToolPurchased", function()
		tbl4.playTuned("Reveal", 1.5, 1.05, 0.3)
	end)

	var8.on("ToolUpgraded", function()
		tbl4.play("Purchase", 0.2)
	end)

	local str3 = "PurchaseRecovered"
	local bool1 = false
	for k4, v4 in ipairs({ "PurchaseDelivered", str3 }) do
		var8.on(v4, function()
			tbl4.playTuned("Reveal", 1.5, 1.05, 0.3)
		end)

	end

	var8.on("Finale", function()
		tbl4.windDownFreezer(2.2)
	end)

	var8.batteryCue:Connect(function(arg1)
		if arg1 == "empty" then
			num1 = os.clock()
			return
		end

		tbl4.playTuned("UITick", 0.7, 0.6, 0.5)
	end)

	local num3 = 0
	var3.Heartbeat:Connect(function(arg1)
		updateToolLoops()
		local var2 = var10.firing
		if var2 then
			var2 = false
			if var10.impact ~= nil then
				var2 = var10.impact.iceId ~= nil
			end
		end

		if var2 ~= bool1 then
			bool1 = var2
			local var3 = var7
			local var4 = var2 and var6.Sizzle.Volume or 0
			local var8 = TweenInfo.new((if var2 then 0.1 else 0.3) or 0.15)
			var5:Create(var3, var8, { Volume = var4 }):Play()
			if var2 then
				tbl4.play("Drips", 3)
			end
		end

		local var9 = num3 + arg1
		num3 = var9
		if 0.5 <= num3 then
			num3 = 0
			updateAmbience()
		end
	end)
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Cinematics [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = nil
local var3 = game:GetService("TweenService")
local var4 = game:GetService("UserInputService")
local var5 = require(script.Parent.ClientState)
local var6 = require(script.Parent.UIKit)
local tbl1 = {
	isRunning = function()
		return var2 ~= nil
	end,
	skip = function()
		if var2 then
			var2.skipped = true
			if var2.tween then
				var2.tween:Cancel()
			end
		end
	end,
}

local var7 = nil
local var8 = nil
tbl1.play = function(arg1, arg2)
	local var4 = arg2
	arg2 = var4 or {}
	if var2 then
		tbl1.skip()
		task.wait()
	end

	var4 = { skipped = false }
	var2 = var4
	var5.setCinematic(true)
	if arg2.hideHud and (var7 and var7.HUD) then
		var7.HUD.setVisible(false)
	end

	var8.Enabled = true
	local var6 = workspace.CurrentCamera
	var6.CameraType = Enum.CameraType.Scriptable
	var6.CFrame = arg1[1].cf
	for i1 = 2, #arg1 do
		if var4.skipped then
			break
		end

		local var9 = arg1[i1]
		local var10 = var9.style
		local var11 = TweenInfo.new(var9.time, var10 or Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
		local var12 = var3:Create(var6, var11, { CFrame = var9.cf })
		var4.tween = var12
		var12:Play()
		local bool1 = false
		local var13 = var12.Completed:Connect(function()
			bool1 = true
		end)

		while not bool1 and (not var4.skipped) do
			task.wait()
		end

		var13:Disconnect()
		var11 = 0
		if var9.hold and (not var4.skipped and (var11 < var9.hold and (not var4.skipped))) then
			var11 = var11 + task.wait()
			continue
		end
	end

	if var2 == var4 then
		var2 = nil
		var8.Enabled = false
		local var14 = workspace.CurrentCamera
		var14.CameraType = Enum.CameraType.Custom
		local var15 = var1.LocalPlayer.Character
		local var16 = var15
		var16 = var16 and var15:FindFirstChildOfClass("Humanoid")
		if var16 then
			var14.CameraSubject = var16
		end

		var5.setCinematic(false)
		if arg2.hideHud and (var7 and var7.HUD) then
			var7.HUD.setVisible(true)
		end
	end

	if var4.skipped and arg2.onSkip then
		arg2.onSkip()
	end

	return not var4.skipped
end

tbl1.init = function(arg1)
	var7 = arg1
	var8 = var6.screen("FrozenHouseCinematic", 30)
	var6.autoScale(var8)
	var8.Enabled = false
	local tbl2 = {
		Name = "Skip",
		Text = "Skip",
		TextSize = 22,
		Secondary = true,
		AnchorPoint = Vector2.new(1, 1),
	}

	tbl2.Position = UDim2.new(1, -20, 1, -20)
	tbl2.Size = UDim2.fromOffset(130, 52)
	tbl2.Parent = var8
	tbl2.OnClick = tbl1.skip
	var6.button(tbl2)
	var4.InputBegan:Connect(function(arg1, arg2)
		if not var2 or arg2 then
			return
		end

		local var3 = arg1.UserInputType
		if var3 == Enum.UserInputType.Keyboard or (var3 == Enum.UserInputType.MouseButton1 or (var3 == Enum.UserInputType.Touch or var3.Name:find("Gamepad"))) then
			tbl1.skip()
		end
	end)

	var1.LocalPlayer.CharacterAdded:Connect(function()
		if not var2 then
			local var3 = workspace.CurrentCamera
			var3.CameraType = Enum.CameraType.Custom
			local var4 = var1.LocalPlayer.Character
			local var5 = var4
			var5 = var5 and var4:FindFirstChildOfClass("Humanoid")
			if var5 then
				var3.CameraSubject = var5
			end
		end
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ClientMain [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = script.Parent
local var3 = require(var2.ClientState)
var3.init()
local var4 = require(var2.Focus)
local var5 = game:GetService("ContentProvider")
local var6 = game:GetService("Players")
local var7 = require(var1:WaitForChild("FrozenHouse").Net).init()
local var8 = require(var2.Battery)
local var9 = require(var2.IceWorld)
local var10 = require(var2.Input)
local var11 = require(var2.FirstPerson)
local var12 = require(var2.Effects)
local var13 = require(var2.Audio)
local var14 = require(var2.ToolCycle)
local var15 = require(var2.HUD)
local var16 = require(var2.Manual)
local var17 = require(var2.ToolShed)
local var18 = require(var2.SettingsPanel)
local var19 = require(var2.Helper)
local var20 = require(var2.Cinematics)
local var21 = require(var2.Arrival)
local var22 = require(var2.Tutorial)
local var23 = require(var2.Completion)
local var24 = require(var2.ClassInfo)
local var25 = require(var2.ClassLook)
local var26 = require(var2.Grenades)
var4.init({ Audio = var13 })
var8.init()
var9.init()
var10.init()
var11.init()
var12.init()
var13.init()
var25.init()
var16.init({
	Audio = var13,
	ToolShed = var17,
	SettingsPanel = var18,
	ClassInfo = var24,
	Helper = var19,
	HUD = var15,
})

var18.init({ Audio = var13, HUD = var15 })
var19.init({ HUD = var15, Audio = var13 })
var24.init({ Audio = var13 })
var14.init({ Audio = var13, HUD = var15 })
var15.init({
	Audio = var13,
	Helper = var19,
	SettingsPanel = var18,
	Manual = var16,
	Input = var10,
	FirstPerson = var11,
	ClassInfo = var24,
	Grenades = var26,
	ToolCycle = var14,
})

var26.init({ HUD = var15, Audio = var13, FirstPerson = var11 })
var17.init({ HUD = var15, Audio = var13, Manual = var16 })
var20.init({ HUD = var15 })
var23.init({ HUD = var15, Audio = var13, Cinematics = var20, Effects = var12 })
var21.init({ HUD = var15, Audio = var13, Cinematics = var20 })
var22.init({ HUD = var15 })
if game:GetService("RunService"):IsStudio() then
	local var27 = Instance.new("BindableFunction")
	var27.Name = "FrozenHouseManualHook"
	var27.OnInvoke = function(arg1, arg2)
		if arg1 == "shed" then
			return var17.describe()
		end

		if arg1 == "shedWay" then
			var17.showWay()
			return var17.describe()
		end

		if arg1 == "open" then
			var16.open()
		elseif arg1 == "close" then
			var16.close()
		elseif arg1 == "layout" then
			var16.forceLayout(arg2)
		elseif arg1 == "classInfo" then
			var24.open()
			local tbl1 = { info = var24.describe() }
			tbl1.hud = var15.describeClass()
			return tbl1
		end

		return var16.describe()
	end

	var27.Parent = var6.LocalPlayer:WaitForChild("PlayerScripts")
	var3.on("DevChat", function(arg1)
		local var1 = game:GetService("TextChatService"):FindFirstChild("TextChannels")
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("RBXSystem")
		if var2 and typeof(arg1.text) == "string" then
			var2:DisplaySystemMessage(arg1.text)
		end
	end)

end

local var28 = var6.LocalPlayer
local var29 = var28.Character;
(var29 or var28.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart", 10)
task.spawn(function()
	local var3 = var1:FindFirstChild("FrozenHouseAssets")
	local tbl1 = {}
	if var3 then
		table.insert(tbl1, var3)
	end

	pcall(function()
		var5:PreloadAsync(tbl1)
	end)
end)

var7.get("ClientReady"):FireServer()
var21.ready()

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ClientState [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local str1 = "ClassPerks"
local var3 = require(var1:WaitForChild("MeltShared"):WaitForChild(str1))
local var4 = require(var2.Config)
local var5 = require(var2.Layout)
local var6 = require(var2.Net)
local var7 = require(var2.ToolStats)
local var8 = require(script.Parent.Signal)
local tbl1 = { player = game:GetService("Players").LocalPlayer }
tbl1.state = var1:WaitForChild("FrozenHouseState")
tbl1.settings = table.clone(var4.DefaultSettings)
tbl1.settingsChanged = var8.new()
tbl1.menuChanged = var8.new()
tbl1.cinematicChanged = var8.new()
tbl1.firingChanged = var8.new()
tbl1.localMelt = var8.new()
tbl1.cursorChanged = var8.new()
tbl1.batteryCue = var8.new()
tbl1.menuOpen = nil
tbl1.cinematic = false
tbl1.firing = false
tbl1.freeCursor = false
tbl1.attr = function(arg1)
	local var1 = arg1
	return tbl1.state:GetAttribute(var1)
end

tbl1.onAttr = function(arg1, arg2, arg3)
	local var2 = tbl1.state:GetAttributeChangedSignal(arg1):Connect(function()
		local var1 = arg1
		arg2(tbl1.state:GetAttribute(var1))
	end)

	if arg3 then
		local var3 = arg1
		task.spawn(arg2, tbl1.state:GetAttribute(var3))
	end

	return var2
end

tbl1.playerAttr = function(arg1)
	local var1 = arg1
	return tbl1.player:GetAttribute(var1)
end

tbl1.onPlayerAttr = function(arg1, arg2, arg3)
	local var2 = tbl1.player:GetAttributeChangedSignal(arg1):Connect(function()
		local var1 = arg1
		arg2(tbl1.player:GetAttribute(var1))
	end)

	if arg3 then
		local var3 = arg1
		task.spawn(arg2, tbl1.player:GetAttribute(var3))
	end

	return var2
end

tbl1.phase = function()
	return tbl1.state:GetAttribute("Phase") or "Arriving"
end

tbl1.canPlay = function()
	local var2 = tbl1.phase()
	local bool2 = true
	if var2 ~= "Running" then
		bool2 = true
		if var2 ~= "Finale" then
			bool2 = var2 == "Complete"
		end
	end

	return bool2
end

str1 = {}
tbl1.on = function(arg1, arg2)
	local var1 = str1[arg1]
	str1[arg1] = var1 or {}
	table.insert(str1[arg1], arg2)
end

tbl1.emit = function(arg1, arg2)
	local var1 = str1[arg1]
	for k1, v1 in ipairs(var1 or {}) do
		task.spawn(v1, arg2)
	end
end

tbl1.setMenu = function(arg1)
	if tbl1.menuOpen ~= arg1 then
		tbl1.menuOpen = arg1
		tbl1.menuChanged:Fire(arg1)
	end
end

tbl1.setFreeCursor = function(arg1)
	if tbl1.freeCursor ~= arg1 then
		tbl1.freeCursor = arg1
		tbl1.cursorChanged:Fire(arg1)
	end
end

tbl1.setCinematic = function(arg1)
	if tbl1.cinematic ~= arg1 then
		tbl1.cinematic = arg1
		tbl1.cinematicChanged:Fire(arg1)
	end
end

local bool1 = false
tbl1.setSetting = function(arg1, arg2)
	if tbl1.settings[arg1] == arg2 then
		return
	end

	tbl1.settings[arg1] = arg2
	tbl1.settingsChanged:Fire(arg1, arg2)
	if not bool1 then
		bool1 = true
		task.delay(1, function()
			bool1 = false
			var6.get("SaveSettings"):FireServer(tbl1.settings)
		end)

	end
end

tbl1.character = function()
	return tbl1.player.Character
end

tbl1.humanoid = function()
	local var1 = tbl1.player.Character
	local var2 = var1
	return var2 and var1:FindFirstChildOfClass("Humanoid")
end

tbl1.heldTool = function()
	local var1 = tbl1.player.Character
	local var2 = var1
	var2 = var2 and var1:FindFirstChildOfClass("Tool")
	if var2 and var2:GetAttribute("ToolId") then
		return var2
	end

	return nil
end

tbl1.heldMelter = function()
	local var2 = tbl1.heldTool()
	if var2 and var2:GetAttribute("ToolId") ~= var4.Grenade.ToolId then
		return var2
	end

	return nil
end

tbl1.holdingGrenade = function()
	local var2 = tbl1.heldTool()
	local bool1 = false
	if var2 ~= nil then
		bool1 = var2:GetAttribute("ToolId") == var4.Grenade.ToolId
	end

	return bool1
end

tbl1.grenades = function(arg1)
	local var1 = arg1
	return (var1 or tbl1.player):GetAttribute("Grenades") or 0
end

tbl1.productsAvailable = function()
	local tbl2 = {}
	for k1 in string.gmatch(tbl1.state:GetAttribute("ProductsAvailable") or "", "[^,]+") do
		tbl2[k1] = true
	end

	return tbl2
end

tbl1.toolDef = function()
	local var1 = tbl1.player:GetAttribute("EquippedTool")
	return var4.ToolById[var1 or var4.StarterToolId]
end

tbl1.perks = function(arg1)
	local var1 = arg1
	var1 = var1 or tbl1.player
	local var2 = var1
	local var4 = var3.resolve(var1:GetAttribute("RunClass"), tbl1.state:GetAttribute("GodlyCount") or 0)
	return var3.withBatteryBoost(var4, tbl1.batteryBoost(var2))
end

tbl1.batteryBoost = function(arg1)
	local var1 = arg1
	var1 = (var1 or tbl1.player):GetAttribute("BatteryBoost")
	if typeof(var1) == "number" and 1 < var1 then
		return var1
	end

	return 1
end

tbl1.toolStats = function()
	local var1 = tbl1.toolDef()
	local var2 = var1.Id
	local var3 = tbl1.levels(var1.Id)
	return var7.effective(var2, var3, tbl1.perks())
end

tbl1.ownedTools = function(arg1)
	local var1 = arg1
	var1 = (var1 or tbl1.player):GetAttribute("OwnedTools")
	local tbl2 = {}
	for k1 in string.gmatch(var1 or var4.StarterToolId, "[^,]+") do
		tbl2[k1] = true
	end

	return tbl2
end

tbl1.levels = function(arg1, arg2)
	local var1 = arg2
	local str1 = "ToolUpgrades"
	var1 = var7.decodeLevels((var1 or tbl1.player):GetAttribute(str1))[arg1]
	return var1 or var7.defaultLevels()
end

tbl1.coins = function()
	return tbl1.player:GetAttribute("Coins") or 0
end

tbl1.regionAt = function(arg1)
	local var1 = arg1
	return var5.regionAt(var1)
end

tbl1.init = function()
	var6.get("RunEvent").OnClientEvent:Connect(function(arg1, arg2)
		local var1 = arg2
		tbl1.emit(arg1, var1 or {})
	end)

	var6.get("SettingsLoaded").OnClientEvent:Connect(function(arg1)
		if typeof(arg1) == "table" then
			for k1, v1 in pairs(var4.DefaultSettings) do
				local var1 = arg1[k1]
				if typeof(var1) ~= typeof(v1) then
					continue
				end

				tbl1.settings[k1] = var1
				tbl1.settingsChanged:Fire(k1, var1)
			end
		end
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Completion [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local var3 = var1:WaitForChild("MeltShared")
local str1 = "Classes"
local str2 = "Leaderboards"
local str3 = "ClassIcons"
local var4 = require(var3:WaitForChild(str1))
local var5 = require(var3:WaitForChild(str2))
local var6 = require(var3:WaitForChild(str3))
local var7 = require(var2.Config)
str3 = require(script.Parent.UIKit)
local var8 = var7.Text
local var9 = require(var2.Layout)
local var10 = require(var2.Net)
str1 = require(script.Parent.ClientState)
str2 = require(script.Parent.Focus)
local var11 = nil
local tbl1 = {}
local tbl2 = {
	Checking = var8.GemsSaving,
	Saving = var8.GemsSaving,
	Saved = var8.GemsSaved,
	Already = var8.GemsAlready,
	Retrying = var8.GemsRetrying,
	Failed = var8.GemsFailed,
}

local bool1 = false
local bool2 = false
local var12 = nil
local var13 = nil
local function relayout()
	tbl1.Gems.Visible = bool1
	tbl1.GemStatus.Visible = bool1
	local var1 = if bool1 then 110 else 0
	tbl1.RunOnly.Position = UDim2.fromOffset(20, var1 + 326)
	tbl1.Record.Position = UDim2.fromOffset(20, var1 + 352)
	tbl1.Best.Position = UDim2.fromOffset(20, var1 + 376)
	tbl1.Best.Visible = bool2
	local var2 = var12
	local var3 = UDim2.fromOffset
	local num1 = 540
	local var4 = var1 + 500
	var2.Size = var3(num1, var4 + (if bool2 then 28 else 0))
end

local function drawGems(arg1)
	local var1 = arg1.amount
	var1 = var1 or var4.CompletionGems
	tbl1.GemAmount.Text = string.format(var8.GemsEarned, var1)
	local var2 = arg1.base
	var2 = var2 or var4.CompletionGems
	local var3 = if typeof(arg1.bonus) == "number" then arg1.bonus else 0
	local bool1 = false
	if typeof(arg1.vip) == "number" then
		bool1 = 0 < arg1.vip
	end

	if bool1 and 0 < var3 then
		tbl1.GemSpins.Text = string.format(var8.GemsBreakdownVip, var2, var3)
		return
	end

	if bool1 then
		tbl1.GemSpins.Text = string.format(var8.GemsBaseVip, var2)
		return
	end

	if 0 < var3 then
		tbl1.GemSpins.Text = string.format(var8.GemsBreakdown, var2, var3)
		return
	end

	tbl1.GemSpins.Text = string.format(var8.GemsSpins, var1 // var4.SpinCost)
end

local var14 = nil
local bool3 = false
local var15 = nil
local function hideSavedTitle()
	str3.tween(var11, 0.3, { GroupTransparency = 1 })
	task.delay(0.32, function()
		var11.Visible = false
	end)
end

local function showPanel()
	if not var13 then
		return
	end

	local var1 = var13
	local var2 = typeof(var1.gems) == "table" and var1.gems or nil
	bool1 = var2 ~= nil
	relayout()
	if var2 then
		drawGems(var2)
		local var3 = var2.status
		tbl1.GemStatus.Text = tbl2[var3] or ""
		local var4 = tbl1.GemStatus
		local var5 = if var3 == "Failed" or var3 == "Retrying" then Color3.fromHex("#B8452F") else str3.Colors.SubText
		var4.TextColor3 = var5
	end

	local var6 = tbl1.Title
	var6.Text = if var1.difficulty == "hard" then var8.HardComplete else var8.HouseSaved
	local var10 = math.max(0, (math.floor(var1.seconds or 0)))
	tbl1.Time.Text = string.format("%d:%02d", var10 // 60, var10 % 60)
	tbl1.Party.Text = tostring(var1.partySize or 1)
	if var1.totalMass then
		if 0 < var1.totalMass then
			var6 = math.floor((var1.iceMass or 0) / var1.totalMass * 100 + 0.5)
			var6 = var6 or 0
		end
	end

	tbl1.Contribution.Text = 0 .. "% of the ice"
	local var11 = var1.rooms
	tbl1.Rooms.Text = string.format("%d/%d", var11 or (#var9.Regions), #var9.Regions)
	var14.Visible = true
	str1.setMenu("Completion")
	str2.open("FrozenHouseCompletion", {
		root = var14,
		hints = { { action = "Confirm", label = var7.Text.HintSelect } },
		initial = function()
			return var12.Buttons.Explore
		end,
		back = nil,
		lockControls = false,
	})
end

local function showSavedTitle()
	var11.Visible = true
	var11.GroupTransparency = 1
	local var1 = var11:FindFirstChildOfClass("UIScale")
	var1.Scale = 0.7
	str3.tween(var11, 0.3, { GroupTransparency = 0 })
	str3.tween(var1, 0.45, { Scale = 1 }, Enum.EasingStyle.Back)
end

local var16 = nil
local var17 = str3.new
local var18 = var7.Palette
local function runFinale()
	if bool3 then
		return
	end

	bool3 = true
	local var1 = var7.Finale
	task.wait(var1.HouseShot)
	local var2 = var9.Cameras.HouseSaved
	local var3 = var2 * CFrame.new(0, -2, -10)
	task.spawn(function()
		var15.Cinematics.play({
			{ cf = var2, time = 0 },
			{
				cf = var3,
				time = var1.TotalSeconds - var1.HouseShot + 0.6,
				style = Enum.EasingStyle.Sine,
			},
		}, { hideHud = true, onSkip = hideSavedTitle })

		hideSavedTitle()
		bool3 = false
		showPanel()
	end)

	task.wait((math.max(0, var1.SavedTitle - (os.clock() - os.clock()))))
	if var15.Cinematics.isRunning() then
		showSavedTitle()
		var15.Audio.play("Jingle", 2)
	end
end

return {
	init = function(arg1)
		var15 = arg1
		var16 = str3.screen("FrozenHouseCompletion", 26)
		str3.autoScale(var16)
		local tbl3 = {
			Name = "SavedTitle",
			BackgroundTransparency = 1,
			AnchorPoint = Vector2.new(0.5, 0.5),
			Visible = false,
		}

		tbl3.Position = UDim2.fromScale(0.5, 0.3)
		tbl3.Size = UDim2.fromOffset(800, 140)
		tbl3.Parent = var16
		local str4 = "UIScale"
		var11 = var17("CanvasGroup", tbl3, { var17(str4) })
		local tbl4 = {
			Text = var7.Text.HouseSaved,
			FontFace = str3.Fonts.Display,
			TextSize = 96,
			TextColor3 = var18.Orange,
			Size = UDim2.fromScale(1, 1),
		}

		tbl4.Parent = var11
		local var1 = str3.label(tbl4)
		var17("UIStroke", { Color = var18.Text, Thickness = 6, Parent = var1 })
		local tbl5 = {
			Name = "Root",
			BackgroundTransparency = 1,
			Size = UDim2.fromScale(1, 1),
			Visible = false,
		}

		tbl5.Parent = var16
		var14 = var17("Frame", tbl5)
		str3.backdrop({ Name = "Dim", Class = "Frame", BackgroundTransparency = 0.5, Parent = var14 })
		tbl3 = { Name = "Panel", AnchorPoint = Vector2.new(0.5, 0.5) }
		tbl3.Position = UDim2.fromScale(0.5, 0.52)
		tbl3.Size = UDim2.fromOffset(540, 500)
		tbl3.Parent = var14
		var12 = str3.panel(tbl3)
		tbl5 = {
			Name = "Title",
			Text = var7.Text.HouseSaved,
			FontFace = str3.Fonts.Display,
			TextSize = 52,
			TextColor3 = var18.OrangeDark,
			Position = UDim2.fromOffset(0, 18),
		}

		tbl5.Size = UDim2.new(1, 0, 0, 60)
		tbl5.Parent = var12
		tbl1.Title = str3.label(tbl5)
		tbl3 = {
			Text = "The freezer is off and the Frozen House is thawed.",
			TextSize = 19,
			TextColor3 = str3.Colors.SubText,
			Position = UDim2.fromOffset(20, 78),
		}

		tbl3.Size = UDim2.new(1, -40, 0, 26)
		tbl3.Parent = var12
		str3.label(tbl3)
		tbl5 = { Name = "Stats", BackgroundColor3 = Color3.fromHex("#EAF6FB") }
		tbl5.Position = UDim2.fromOffset(28, 116)
		tbl5.Size = UDim2.new(1, -56, 0, 200)
		tbl5.Parent = var12
		local num1 = 14
		tbl4 = var17("Frame", tbl5, { str3.corner(14), str3.padding(num1) })
		local tbl6 = { Padding = UDim.new(0, 6) }
		tbl6.SortOrder = Enum.SortOrder.LayoutOrder
		tbl6.Parent = tbl4
		var17("UIListLayout", tbl6)
		tbl3 = function(arg1, arg2, arg3)
			local tbl2 = { BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 38) }
			tbl2.LayoutOrder = arg3
			tbl2.Parent = tbl4
			local var1 = var17("Frame", tbl2)
			tbl2 = {
				Text = arg2,
				TextSize = 21,
				TextXAlignment = Enum.TextXAlignment.Left,
				Size = UDim2.fromScale(0.55, 1),
			}

			tbl2.Parent = var1
			str3.label(tbl2)
			local tbl3 = {
				Text = "",
				FontFace = str3.Fonts.Display,
				TextSize = 26,
				TextXAlignment = Enum.TextXAlignment.Right,
				Position = UDim2.fromScale(0.45, 0),
			}

			tbl3.Size = UDim2.fromScale(0.55, 1)
			tbl3.Parent = var1
			tbl1[arg1] = str3.label(tbl3)
		end

		tbl3("Time", "Time", 1)
		tbl3("Party", "Party size", 2)
		tbl3("Contribution", "You melted", 3)
		tbl3("Rooms", "Rooms cleared", 4)
		str4 = { Name = "Gems", BackgroundColor3 = Color3.fromHex("#DDF4F7"), Visible = false }
		str4.Position = UDim2.fromOffset(28, 326)
		str4.Size = UDim2.new(1, -56, 0, 76)
		str4.Parent = var12
		local var2 = Color3.fromHex("#9BD6E0")
		local num2 = 2
		tbl5 = var17("Frame", str4, { str3.corner(14), str3.stroke(var2, num2) })
		str4 = { Position = UDim2.fromOffset(16, 14) }
		str4.Size = UDim2.fromOffset(48, 48)
		str4.Parent = tbl5
		var6.gem(str4)
		local tbl7 = {
			Name = "Amount",
			Text = "",
			FontFace = str3.Fonts.Display,
			TextSize = 32,
			TextColor3 = Color3.fromHex("#1F6F80"),
		}

		tbl7.TextXAlignment = Enum.TextXAlignment.Left
		tbl7.Position = UDim2.fromOffset(78, 6)
		tbl7.Size = UDim2.new(1, -90, 0, 38)
		tbl7.Parent = tbl5
		tbl1.GemAmount = str3.label(tbl7)
		tbl7 = {
			Name = "Spins",
			Text = "",
			FontFace = str3.Fonts.Bold,
			TextSize = 18,
			TextXAlignment = Enum.TextXAlignment.Left,
			Position = UDim2.fromOffset(78, 44),
		}

		tbl7.Size = UDim2.new(1, -90, 0, 24)
		tbl7.Parent = tbl5
		tbl1.GemSpins = str3.label(tbl7)
		tbl1.Gems = tbl5
		tbl7 = {
			Name = "GemStatus",
			Text = "",
			TextSize = 16,
			TextColor3 = str3.Colors.SubText,
			Position = UDim2.fromOffset(20, 406),
			Visible = false,
		}

		tbl7.Size = UDim2.new(1, -40, 0, 22)
		tbl7.Parent = var12
		tbl1.GemStatus = str3.label(tbl7)
		tbl7 = {
			Text = var7.Text.RunOnly,
			FontFace = str3.Fonts.Bold,
			TextSize = 18,
			Position = UDim2.fromOffset(20, 326),
		}

		tbl7.Size = UDim2.new(1, -40, 0, 24)
		tbl7.Parent = var12
		tbl1.RunOnly = str3.label(tbl7)
		tbl7 = {
			Text = "Saving your record\226\128\166",
			TextSize = 16,
			TextColor3 = str3.Colors.SubText,
			Position = UDim2.fromOffset(20, 352),
		}

		tbl7.Size = UDim2.new(1, -40, 0, 22)
		tbl7.Parent = var12
		tbl1.Record = str3.label(tbl7)
		tbl7 = {
			Name = "PersonalBest",
			Text = "",
			FontFace = str3.Fonts.Display,
			TextSize = 18,
			TextColor3 = Color3.fromHex("#B8860B"),
			Visible = false,
		}

		tbl7.TextXAlignment = Enum.TextXAlignment.Left
		tbl7.Position = UDim2.fromOffset(20, 376)
		tbl7.Size = UDim2.new(1, -40, 0, 24)
		tbl7.Parent = var12
		tbl1.Best = str3.label(tbl7)
		tbl7 = { Name = "Buttons", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 1) }
		tbl7.Position = UDim2.new(0.5, 0, 1, -22)
		tbl7.Size = UDim2.new(1, -56, 0, 60)
		tbl7.Parent = var12
		tbl6 = var17("Frame", tbl7)
		tbl7 = {
			Name = "Lobby",
			Text = "Return to Lobby",
			TextSize = 22,
			Size = UDim2.new(0.5, -8, 1, 0),
		}

		tbl7.Parent = tbl6
		tbl7.OnClick = function()
			if str2.blocked() then
				return
			end

			var15.Audio.play("UITick", 0.05)
			var10.get("RequestLobby"):FireServer()
		end

		str3.button(tbl7)
		tbl7 = {
			Name = "Explore",
			Text = "Keep Exploring",
			TextSize = 22,
			Secondary = true,
			AnchorPoint = Vector2.new(1, 0),
		}

		tbl7.Position = UDim2.fromScale(1, 0)
		tbl7.Size = UDim2.new(0.5, -8, 1, 0)
		tbl7.Parent = tbl6
		tbl7.OnClick = function()
			var15.Audio.play("UITick", 0.05)
			var14.Visible = false
			str2.close("FrozenHouseCompletion")
			if str1.menuOpen == "Completion" then
				str1.setMenu(nil)
			end
		end

		str3.button(tbl7)
		str1.on("Finale", function()
			task.spawn(runFinale)
		end)

		str1.on("Completed", function(arg1)
			var13 = arg1
			if not bool3 and (not var15.Cinematics.isRunning()) then
				showPanel()
			end
		end)

		str1.on("RecordSaved", function(arg1)
			local var1 = tbl1.Record
			var1.Text = if arg1.saved then "Completion saved to your record." else "Your completion couldn't be saved right now."
		end)

		str1.on("RecordUpdated", function(arg1)
			if arg1.improved ~= true or typeof(arg1.bestMs) ~= "number" then
				return
			end

			bool2 = true
			local var1 = arg1.bestMs
			tbl1.Best.Text = string.format(var8.NewPersonalBest, var5.formatTime(var1))
			relayout()
			local var2 = var17("UIScale", { Parent = tbl1.Best })
			var2.Scale = 0.8
			str3.tween(var2, 0.4, { Scale = 1 }, Enum.EasingStyle.Back)
		end)

		str1.on("GemReward", function(arg1)
			if var13 and typeof(var13.gems) == "table" then
				local var1 = var13.gems
				var1.status = arg1.status
				if typeof(arg1.amount) == "number" then
					var1.amount = arg1.amount
					var1.base = arg1.base
					var1.bonus = arg1.bonus
					var1.vip = arg1.vip
					drawGems(var1)
				end
			end

			local var2 = arg1.status
			tbl1.GemStatus.Text = tbl2[var2] or ""
			local var3 = tbl1.GemStatus
			local var4 = if var2 == "Failed" or var2 == "Retrying" then Color3.fromHex("#B8452F") else str3.Colors.SubText
			var3.TextColor3 = var4
		end)
	end,
	describe = function()
		return {
			open = var14.Visible,
			title = tbl1.Title.Text,
			gemsRow = tbl1.Gems.Visible,
			gemAmount = tbl1.GemAmount.Text,
			gemSpins = tbl1.GemSpins.Text,
			gemStatus = tbl1.GemStatus.Visible and tbl1.GemStatus.Text or nil,
			record = tbl1.Record.Text,
			personalBest = tbl1.Best.Visible and tbl1.Best.Text or nil,
		}
	end,
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Effects [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = require(var1.Config)
local var3 = require(script.Parent.ClientState)
local var4 = nil
local var5 = var2.IceLook
local var6 = require(var1.ToolStats)
local var7 = setmetatable({}, { __mode = "k" })
local var8 = var2.Palette
local var9 = require(script.Parent.IceWorld)
local var10 = game:GetService("Players")
local var11 = require(script.Parent.Battery)
local var12 = require(script.Parent.FirstPerson)
local function applyAirflow(arg1, arg2, arg3)
	if arg1.Enabled ~= arg2 then
		arg1.Enabled = arg2
	end

	local var1 = arg1:GetAttribute("BaseRate")
	var1 = var1 or arg1.Rate
	arg1:SetAttribute("BaseRate", var1)
	arg1.Rate = var3.settings.ReducedEffects and var1 * 0.35 or var1
	if arg1:GetAttribute("Widen") ~= arg3 then
		local var4 = arg1:GetAttribute("BaseSize")
		local var5 = arg1:GetAttribute("BaseSpread")
		var4 = var4 or arg1.Size
		arg1:SetAttribute("BaseSize", var4)
		var5 = var5 or arg1.SpreadAngle
		arg1:SetAttribute("BaseSpread", var5)
		local tbl1 = {}
		for k1, v1 in ipairs(var4.Keypoints) do
			local var6 = v1.Time
			local var7 = v1.Value * arg3
			local var8 = v1.Envelope * arg3
			table.insert(tbl1, NumberSequenceKeypoint.new(var6, var7, var8))
		end

		arg1.Size = NumberSequence.new(tbl1)
		arg1.SpreadAngle = var5 * arg3
		arg1:SetAttribute("Widen", arg3)
	end
end

local var13 = require(script.Parent.Input)
local function fitFlame(arg1, arg2, arg3)
	local var1 = var2.ToolById.Flamethrower.Range + var2.Firing.RangeTolerance
	local var5, var6 = var9.raycast(arg2, arg3, var1)
	local var7 = var1
	if var5 then
		var7 = math.min(var7, var5.distance)
	end

	if var6 then
		var7 = math.min(var7, var6.Distance)
	end

	local var8 = math.max(0.05, var7 / 54)
	arg1.Lifetime = NumberRange.new(var8 * 0.85, var8)
end

local function animateToolLights(arg1, arg2, arg3, arg4)
	local var3 = var7[arg1]
	local var4
	if not var3 then
		var3 = { glow = 0, running = 0, glows = {}, strips = {}, pressure = {} }
		for k1, v1 in ipairs(arg1:GetChildren()) do
			var4 = v1:IsA("BasePart")
			if not var4 then
				continue
			end

			if v1.Name == "NozzleGlow" or v1.Name == "MuzzleGlow" then
				table.insert(var3.glows, v1)
			else
				if v1.Name == "LightStrip" or v1.Name == "Indicator" then
					table.insert(var3.strips, v1)
				else
					if string.match(v1.Name, "^Pressure%d$") then
						var4 = var3.pressure
						var4[tonumber((string.sub(v1.Name, 9)))] = v1
					else
						var4 = v1.Name
						if var4 ~= "Charge" then
							continue
						end

						var3.charge = v1
					end
				end
			end
		end

		var7[arg1] = var3
	end

	local var5 = if arg2 then math.min(1, var3.glow + arg3 * 8) else math.max(0, var3.glow - arg3 * 2)
	var3.glow = var5
	var5 = if arg2 then var3.running + arg3 else 0
	var3.running = var5
	var5 = 1 - 0.85 * var3.glow
	for k2, v2 in ipairs(var3.glows) do
		if 0.01 >= math.abs(v2.Transparency - var5) then
			continue
		end

		v2.Transparency = var5
	end

	for k3, v3 in ipairs(var3.strips) do
		local var6 = if arg2 then Enum.Material.Neon else Enum.Material.SmoothPlastic
		if v3.Material == var6 then
			continue
		end

		v3.Material = var6
	end

	for k4, v4 in pairs(var3.pressure) do
		local var10 = arg2
		if var10 then
			var10 = (k4 - 1) * 0.15 <= var3.running
		end

		local var11 = if var10 then Enum.Material.Neon else Enum.Material.SmoothPlastic
		if v4.Material == var11 then
			continue
		end

		v4.Material = var11
	end

	if var3.charge then
		local var12 = var3.charge
		local var13
		if arg4 then
			var13 = var2.Battery.LowFraction <= arg4
		else
			var13 = arg2
		end

		local var15 = if var13 then Enum.Material.Neon else Enum.Material.SmoothPlastic
		if var12.Material ~= var15 then
			var12.Material = var15
		end

		var12 = var3.charge
		var13 = if arg4 and arg4 < var2.Battery.LowFraction then var8.Coral else Color3.fromHex("#FFB547")
		var12.Color = var13
	end
end

local tbl1 = {}
local function emitterPart(arg1)
	local var1 = Instance.new("Part")
	var1.Name = arg1
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.Parent = var4
	local var2 = Instance.new("Attachment")
	var2.Name = "LightAt"
	var2.Position = Vector3.new(0, 0, -(var5.ContactLightOffset - 0.35))
	var2.Parent = var1
	local var3 = Instance.new("PointLight")
	var3.Name = "Warm"
	var3.Color = var5.ContactLightColor
	var3.Range = var5.ContactLightRange
	var3.Brightness = 0
	var3.Shadows = false
	var3.Enabled = false
	var3.Parent = var2
	local var6 = Instance.new("ParticleEmitter")
	var6.Name = "Steam"
	var6.Texture = "rbxasset://textures/particles/smoke_main.dds"
	local num1 = 245
	local num2 = 250
	local num3 = 255
	var6.Color = ColorSequence.new(Color3.fromRGB(num1, num2, num3))
	var6.LightEmission = 0.15
	num3 = 1
	local num4 = 0.9
	var6.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(num3, num4) })
	num3 = 1
	num4 = 1
	var6.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.8), NumberSequenceKeypoint.new(num3, num4) })
	var6.Lifetime = NumberRange.new(0.35, 0.6)
	var6.Speed = NumberRange.new(1.5, 3)
	var6.SpreadAngle = Vector2.new(25, 25)
	var6.EmissionDirection = Enum.NormalId.Front
	var6.Acceleration = Vector3.new(0, 3, 0)
	var6.Rate = 10
	var6.Enabled = false
	var6.Parent = var1
	local var7 = Instance.new("ParticleEmitter")
	var7.Name = "Drops"
	var7.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	var7.Color = ColorSequence.new(var5.Edge)
	var7.LightEmission = 0.3
	var7.Size = NumberSequence.new(0.16, 0.05)
	var7.Transparency = NumberSequence.new(0.15, 0.85)
	var7.Lifetime = NumberRange.new(0.45, 0.75)
	var7.Speed = NumberRange.new(0.8, 2)
	var7.SpreadAngle = Vector2.new(40, 40)
	var7.EmissionDirection = Enum.NormalId.Front
	var7.Acceleration = Vector3.new(0, -34, 0)
	var7.Rate = 6
	var7.Enabled = false
	var7.Parent = var1
	local var8 = Instance.new("ParticleEmitter")
	var8.Name = "Glow"
	var8.Texture = "rbxasset://textures/particles/smoke_main.dds"
	var8.Color = ColorSequence.new(var5.ContactLightColor)
	var8.LightEmission = var5.ContactGlowEmission
	var8.LightInfluence = 0
	local num5 = 1
	local num6 = 1.7
	var8.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.3), NumberSequenceKeypoint.new(num5, num6) })
	num6 = 1
	local num7 = 1
	var8.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.35, var5.ContactGlowTransparency),
		NumberSequenceKeypoint.new(num6, num7),
	})

	var8.Lifetime = NumberRange.new(0.3, 0.45)
	var8.Speed = NumberRange.new(0)
	var8.Rate = 10
	var8.LockedToPart = true
	var8.Enabled = false
	var8.Parent = var1
	return var1
end

local var14 = require(var1.IceCodec)
local tbl2 = {}
local function torchPart()
	local var1 = emitterPart("TorchContact")
	local num1 = 1
	local num2 = 1.2
	var1.Glow.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.8), NumberSequenceKeypoint.new(num1, num2) })
	num2 = 1
	local num3 = 1
	var1.Glow.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.35, 0.62),
		NumberSequenceKeypoint.new(num2, num3),
	})

	num1 = 1
	num2 = 0.6
	var1.Steam.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(num1, num2) })
	var1.LightAt.Warm.Range = 3
	return var1
end

local function setTorchEmitting(arg1, arg2)
	arg1.Steam.Enabled = arg2
	local var1 = arg1.Steam
	var1.Rate = if var3.settings.ReducedEffects then 2 else 4
	arg1.Drops.Enabled = false
	arg1.Glow.Enabled = arg2
	var1 = arg1.Glow
	var1.Rate = if var3.settings.ReducedEffects then 3 else 6
	var1 = tbl1
	local var2
	if arg2 then
		local var4 = 0.5 * var5.ContactLightBrightness
		var2 = var4 * (if var3.settings.ReducedEffects then var5.ReducedLight else 1)
	else
		var2 = 0
	end

	var1[arg1] = var2
end

local tbl3 = {}
local function setEmitting(arg1, arg2)
	local var1 = arg1.Steam
	var1.Enabled = arg2
	local var2 = arg2
	arg1.Drops.Enabled = var2 and (not var3.settings.ReducedEffects)
	local var4 = arg1.Glow
	var4.Enabled = arg2
	var1.Rate = if var3.settings.ReducedEffects then 4 else 10
	var4.Rate = if var3.settings.ReducedEffects then 5 else 10
	var2 = tbl1
	local var6
	if arg2 then
		local var7 = var5.ContactLightBrightness
		var6 = var7 * (if var3.settings.ReducedEffects then var5.ReducedLight else 1)
	else
		var6 = 0
	end

	var2[arg1] = var6
end

local var15 = game:GetService("TweenService")
local var16 = game:GetService("RunService")
local var17 = require(var1.FreezerStatus)
local var18 = require(var1.Layout)
local var19 = require(var1.Net)
local function sparkle(arg1, arg2)
	local var1 = Instance.new("Part")
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.CFrame = CFrame.new(arg1)
	var1.Parent = var4
	local var2 = Instance.new("ParticleEmitter")
	var2.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	var2.Color = ColorSequence.new(var8.WarmLight, var8.Orange)
	var2.LightEmission = 0.6
	local num1 = 1
	local num2 = 0
	var2.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(num1, num2) })
	var2.Lifetime = NumberRange.new(0.6, 1.1)
	var2.Speed = NumberRange.new(3, 7)
	var2.SpreadAngle = Vector2.new(180, 180)
	var2.Drag = 3
	var2.Rate = 0
	var2.Parent = var1
	if var3.settings.ReducedEffects then
		local var5 = math.floor(arg2 / 3)
		var5 = var5 or arg2
	end

	var2:Emit(arg2)
	task.delay(1.5, function()
		var1:Destroy()
	end)
end

local var20 = nil
local var21 = nil
local tbl4 = { sparkle = sparkle }
local function updateAirflow(arg1)
	local var1 = var10.LocalPlayer
	local var4 = var1:GetAttribute("EquippedTool")
	var4 = var4 or var2.StarterToolId
	local var5 = var6.upgradeTable(var4, "SizeMultiplier")[var3.levels(var4, var1).Size]
	local var9, var14 = var11.read()
	var1 = var3.toolDef().Id
	local var16 = var12.emitter()
	local var17 = if 0 < var14 then var9 / var14 else nil
	local var18 = var12.viewmodelModel()
	if var16 then
		applyAirflow(var16, var13.firing, var5)
		if var13.firing and var1 == "Flamethrower" then
			local var20 = workspace.CurrentCamera
			fitFlame(var16, var20.CFrame.Position, var20.CFrame.LookVector)
		end
	end

	if var18 then
		animateToolLights(var18, var13.firing, arg1, var17)
	end

	for k1, v1 in ipairs(var10:GetPlayers()) do
		local var21 = v1.Character
		local var22 = var21
		local var23 = var21
		var23 = var23 and var21:FindFirstChildOfClass("Tool")
		local var24 = var23
		var24 = var24 and var23:FindFirstChild("Handle")
		local var25 = var24
		var25 = var25 and var24:FindFirstChild("Nozzle")
		local var26 = var25
		var23 = v1 == var10.LocalPlayer
		var22 = var22 and var21:FindFirstChildOfClass("Tool")
		var26 = var26 and var25:FindFirstChild("Airflow")
		if var23 then
			var24 = var13.firing
		else
			var24 = v1:GetAttribute("Melting") == true
		end

		if var26 then
			var25 = applyAirflow
			local var27 = var26
			local var28
			if var23 then
				var28 = var24
				if var28 then
					var28 = var16 == nil
				end
			else
				var28 = var24
			end

			local var29
			if var23 then
				var29 = var5
			else
				local var30 = v1:GetAttribute("EquippedTool")
				var30 = var30 or var2.StarterToolId
				var29 = var6.upgradeTable(var30, "SizeMultiplier")[var3.levels(var30, v1).Size]
			end

			var25(var27, var28, var29)
			if var26.Enabled and (var22 and var22:GetAttribute("ToolId") == "Flamethrower") then
				var25 = var26.Parent
				fitFlame(var26, var25.WorldPosition, var25.WorldCFrame.LookVector)
			end
		end

		if not var22 then
			continue
		end

		if not var22:GetAttribute("ToolId") then
			continue
		end

		var25 = animateToolLights
		local var31 = var22
		var28 = var24
		var29 = arg1
		var25(var31, var28, var29, if var23 then var17 else nil)
	end
end

local var22 = nil
local function updateGlows(arg1)
	for k1, v1 in pairs(tbl1) do
		local var1 = k1.LightAt.Warm
		local var2 = var1.Brightness
		if var2 == v1 then
			continue
		end

		var2 = var2 + (v1 - var2) * math.min(1, arg1 * (if var2 < v1 then var5.ContactFadeIn else var5.ContactFadeOut))
		if math.abs(v1 - var2) < 0.02 then
			var2 = v1
		end

		var1.Brightness = var2
		var1.Enabled = 0 < var2
	end
end

local function onHeatFx(arg1)
	local var1 = arg1
	local var2 = os.clock()
	for k1, v1 in ipairs(var14.decodeImpacts(var1)) do
		if v1.tool == 0 then
			local var4 = tbl2[v1.userId]
			if not var4 then
				var4 = { part = torchPart(), seen = 0 }
				tbl2[v1.userId] = var4
			end

			var4.part.CFrame = CFrame.lookAt(v1.position + v1.normal * 0.2, v1.position + v1.normal * 2)
			var4.seen = var2
			setTorchEmitting(var4.part, true)
		else
			if v1.userId == var10.LocalPlayer.UserId then
				continue
			end

			local var6 = tbl3[v1.userId]
			if not var6 then
				var6 = { part = emitterPart("RemoteImpact"), seen = 0 }
				tbl3[v1.userId] = var6
			end

			var6.part.CFrame = CFrame.lookAt(v1.position + v1.normal * 0.35, v1.position + v1.normal * 2)
			var6.seen = var2
			setEmitting(var6.part, true)
		end
	end
end

local function animateDoor(arg1, arg2)
	if arg1:GetAttribute("ClientOpened") then
		return
	end

	local str1 = "BasePivot"
	local tbl1 = {}
	local var1
	if typeof(arg1:GetAttribute(str1)) == "CFrame" then
		tbl1 = { arg1 }
	else
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("Model") then
				continue
			end

			local str2 = "BasePivot"
			if typeof(v1:GetAttribute(str2)) ~= "CFrame" then
				continue
			end

			table.insert(tbl1, v1)
		end
	end

	if #tbl1 == 0 then
		return
	end

	arg1:SetAttribute("ClientOpened", true)
	for k2, v2 in ipairs(tbl1) do
		local var2 = v2:GetAttribute("BasePivot")
		local var3 = v2:GetAttribute("OpenAngle") or -100
		if arg2 then
			v2:PivotTo(var2 * CFrame.Angles(0, math.rad(var3), 0))
		else
			local var4 = Instance.new("NumberValue")
			var4.Changed:Connect(function(arg1)
				v2:PivotTo(var2 * CFrame.Angles(0, math.rad(var3 * arg1), 0))
			end)

			local var5 = var15:Create(var4, TweenInfo.new(1.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Value = 1 })
			var5.Completed:Connect(function()
				var4:Destroy()
			end)

			var5:Play()
		end
	end
end

local function regionCleared(arg1)
	for k1, v1 in ipairs(var20:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if v1:GetAttribute("RegionLamp") ~= arg1 then
			continue
		end

		sparkle(v1.Position - Vector3.new(0, 1, 0), 18)
	end
end

local function buildForecast(arg1)
	local var2 = arg1:FindFirstChild("Forecast")
	if not var2 or var2:GetAttribute("Built") then
		return
	end

	var2:SetAttribute("Built", true)
	var2.Enabled = true
	local var3 = Instance.new("Frame")
	var3.Size = UDim2.fromScale(1, 1)
	var3.BackgroundColor3 = var8.DeepBlue
	var3.Parent = var2
	local var4 = Instance.new("UIGradient")
	var4.Color = ColorSequence.new(var8.DeepBlue, var8.Teal)
	var4.Rotation = 90
	var4.Parent = var3
	local function text(arg1, arg2, arg3, arg4, arg5)
		local var1 = Instance.new("TextLabel")
		var1.BackgroundTransparency = 1
		var1.AnchorPoint = Vector2.new(0.5, 0.5)
		var1.Position = arg2
		var1.Size = arg3
		var1.Text = arg1
		var1.TextScaled = true
		var1.TextColor3 = arg4
		local var2 = arg5
		var2 = var2 or Font.new("rbxasset://fonts/families/FredokaOne.json")
		var1.FontFace = var2
		var1.Parent = var3
		return var1
	end

	text("LOCAL FORECAST", UDim2.fromScale(0.5, 0.14), UDim2.fromScale(0.8, 0.16), var8.Cream)
	local var5 = text("INDOORS, VERY COLD.", UDim2.fromScale(0.5, 0.84), UDim2.fromScale(0.9, 0.16), var8.White)
	local var6 = Instance.new("Frame")
	var6.BackgroundTransparency = 1
	var6.AnchorPoint = Vector2.new(0.5, 0.5)
	var6.Position = UDim2.fromScale(0.5, 0.5)
	var6.Size = UDim2.fromScale(0.34, 0.5)
	var6.Parent = var3
	Instance.new("UIAspectRatioConstraint").Parent = var6
	for i1 = 0, 2 do
		local var7 = Instance.new("Frame")
		var7.AnchorPoint = Vector2.new(0.5, 0.5)
		var7.Position = UDim2.fromScale(0.5, 0.5)
		var7.Size = UDim2.fromScale(0.1, 1)
		var7.Rotation = i1 * 60
		var7.BackgroundColor3 = var8.IceFrost
		var7.BorderSizePixel = 0
		var7.Parent = var6
		local var9 = Instance.new("UICorner")
		var9.CornerRadius = UDim.new(0.5, 0)
		var9.Parent = var7
	end

	local var10 = nil
	local num1 = 0
	var16.RenderStepped:Connect(function(arg1)
		if not var2.Parent then
			var10:Disconnect()
			return
		end

		local var1 = num1 + arg1
		num1 = var1
		var6.Rotation = num1 * 25 % 360
		var6.Position = UDim2.fromScale(0.5, math.sin(num1 * 2) * 0.03 + 0.5)
		var5.TextTransparency = math.sin(num1 * 3) * 0.15 + 0.15
	end)
end

local function toasterPop(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:GetAttribute("ToastRest") then
			continue
		end

		local var1 = v1.CFrame
		local var2 = TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local var3 = var15:Create(v1, var2, { CFrame = var1 + Vector3.new(0, 1.3, 0) })
		var3.Completed:Connect(function()
			task.wait(0.7)
			local var2 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			var15:Create(v1, var2, { CFrame = var1 + Vector3.new(0, 0.45, 0) }):Play()
		end)

		var3:Play()
	end
end

local function startFan(arg1)
	if var21 then
		return
	end

	var21 = arg1
	local var1 = arg1:FindFirstChild("Motor")
	local var2 = arg1:GetPivot()
	local num1 = 0
	local var4 = var1 and var1.Position or var2.Position
	var16.RenderStepped:Connect(function(arg1)
		local var1 = num1
		num1 = (var1 + arg1 * math.rad(if var3.settings.ReducedEffects then 40 else 120)) % 6.2831853071795862
		arg1:PivotTo(CFrame.new(var4) * CFrame.Angles(0, num1, 0) * CFrame.new(-var4) * var2)
	end)
end

local function findProp(arg1)
	local var1 = var20
	for k1 in string.gmatch(arg1, "[^%.]+") do
		local var2 = var1
		var1 = var2 and var1:FindFirstChild(k1)
	end

	return var1
end

local tbl5 = {
	TV = "Props.LivingRoom.TV",
	Toaster = "Props.Kitchen.Toaster",
	CeilingFan = "Props.LivingRoom.CeilingFan",
	FridgeNote = "Props.Kitchen.Fridge",
	WelcomeMat = "Props.Porch.WelcomeMat",
}

for k1, v1 in ipairs(var18.KeyPieces) do
	tbl5["KeyPiece_" .. v1.Id] = "Props." .. v1.Folder .. ".KeyPiece_" .. v1.Id
end

local function floatKey(arg1, arg2)
	if arg1:GetAttribute("ClientFloating") then
		return
	end

	arg1:SetAttribute("ClientFloating", true)
	local var2 = arg1:FindFirstChildWhichIsA("PointLight", true)
	local var3 = arg1:GetPivot()
	if var2 then
		var2.Brightness = 1.8
		var2.Range = 9
	end

	local num1 = 0
	local var4 = nil
	local var5 = if arg2 then 0 else 1
	var16.RenderStepped:Connect(function(arg1)
		if not arg1.Parent then
			var4:Disconnect()
			return
		end

		local var1 = num1 + arg1
		num1 = var1
		var1 = math.min(1, var5 + arg1 / 0.9)
		var5 = var1
		var1 = 1 - (1 - var5) ^ 3
		arg1:PivotTo(CFrame.new(var3.Position) * CFrame.new(0, var1 * 1.4 + math.sin(num1 * 2.2) * 0.12 * var1, 0) * CFrame.Angles(0, num1 * 1.4 * var1, 0) * var3.Rotation * CFrame.Angles(0, 0, var1 * -1.5707963267948966))
	end)
end

local var23 = nil
local function questMarker(arg1, arg2, arg3, arg4, arg5)
	local var1 = Instance.new("BillboardGui")
	var1.Name = arg1
	var1.Size = UDim2.fromOffset(140, 70)
	var1.StudsOffsetWorldSpace = Vector3.new(0, arg4, 0)
	var1.AlwaysOnTop = true
	var1.MaxDistance = arg5
	var1.Adornee = arg2
	local var2 = Instance.new("TextLabel")
	var2.Size = UDim2.fromScale(1, 1)
	var2.BackgroundTransparency = 1
	var2.Text = arg3
	var2.TextScaled = true
	var2.TextColor3 = var8.Orange
	var2.TextStrokeColor3 = var8.Text
	var2.TextStrokeTransparency = 0.2
	var2.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
	var2.Parent = var1
	var1.ResetOnSpawn = false
	var1.Parent = var10.LocalPlayer:WaitForChild("PlayerGui")
	local var3 = nil
	local num1 = 0
	var16.RenderStepped:Connect(function(arg1)
		if not var1.Parent then
			var3:Disconnect()
			return
		end

		local var2 = num1 + arg1
		num1 = var2
		var1.StudsOffsetWorldSpace = Vector3.new(0, arg4 + math.sin(num1 * 3) * 0.4, 0)
	end)

	return var1
end

local tbl6 = {}
local bool1 = false
local function tweenNumber(arg1, arg2, arg3)
	local var1 = Instance.new("NumberValue")
	var1.Changed:Connect(arg3)
	local var2 = arg2
	local var3 = var15:Create(var1, TweenInfo.new(arg1, var2 or Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), { Value = 1 })
	var3.Completed:Connect(function()
		var1:Destroy()
	end)

	var3:Play()
	return var3
end

tbl4.playFinale = function()
	if bool1 then
		return
	end

	bool1 = true
	if var23 then
		var23:Destroy()
		var23 = nil
	end

	local var1 = var20.Basement.FreezerChamber
	local var3 = var1.OffSwitch.Lever
	local var4 = var3:GetAttribute("BasePivot")
	local var7 = var2.Finale
	if typeof(var4) == "CFrame" then
		local var8 = var3:GetAttribute("OnAngle") or 25
		local var9 = var3:GetAttribute("OffAngle") or -70
		tweenNumber(0.5, Enum.EasingStyle.Back, function(arg1)
			var3:PivotTo(var4 * CFrame.Angles(0, 0, (math.rad(var8 + (var9 - var8) * arg1))))
		end)

	end

	task.delay(var7.GaugeSwing[1], function()
		local var2 = var1:FindFirstChild("StatusDisplay")
		local var3 = var2
		local var4 = var2
		var3 = var3 and var2:FindFirstChild("Pointer")
		var4 = var4 and var2:FindFirstChild("Status", true)
		tweenNumber(var7.GaugeSwing[2] - var7.GaugeSwing[1], Enum.EasingStyle.Sine, function(arg1)
			local var1 = var3
			var1 = var1 and var17.pointerPivot(var3, arg1)
			if var1 then
				var3:PivotTo(var1)
			end

			if var4 then
				var17.paint(var4, arg1)
			end
		end)
	end)

	task.delay(var7.LightsWarm, function()
		for k1, v1 in ipairs(var20:GetDescendants()) do
			if v1:IsA("BasePart") and v1:GetAttribute("FinaleColdGlow") then
				local var1 = TweenInfo.new(0.8)
				var15:Create(v1, var1, { Color = var2.Lighting.WarmDiffuser }):Play()
				local var3 = v1:FindFirstChildOfClass("PointLight")
				if not var3 then
					continue
				end

				local var4 = TweenInfo.new(0.8)
				var15:Create(var3, var4, { Color = var2.Lighting.WarmLightColor }):Play()
			else
				if v1:IsA("BasePart") and v1:GetAttribute("FrozenPipe") then
					local var5 = TweenInfo.new(1.6)
					var15:Create(v1, var5, { Color = Color3.fromHex("#C98A5B") }):Play()
				else
					if not v1:IsA("BasePart") then
						continue
					end

					if not v1:GetAttribute("FrostRing") then
						continue
					end

					var15:Create(v1, TweenInfo.new(1.2), { Transparency = 1 }):Play()
				end
			end
		end
	end)

	task.delay(var7.MistClear, function()
		local var2 = var1:FindFirstChild("FreezerMist")
		local var3 = var2
		var3 = var3 and var2:FindFirstChildOfClass("ParticleEmitter")
		if var3 then
			var3.Enabled = false
			sparkle(var2.Position + Vector3.new(0, 2, 0), 30)
		end
	end)
end

local function updateKeyMarkers()
	local var1 = var3.character()
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
	local bool2 = false
	if var2 ~= nil then
		bool2 = false
		if var3.phase() == "Running" then
			bool2 = false
			if var3.attr("FrontDoorOpen") == true then
				bool2 = var3.attr("BasementKeyFound") ~= true
			end
		end
	end

	local var4 = if var2 then var18.regionAt(var2.Position) else nil
	for k1, v1 in ipairs(var18.KeyPieces) do
		local var5 = var20.Props:FindFirstChild(v1.Folder)
		local var6 = var5
		var6 = var6 and var5:FindFirstChild("KeyPiece_" .. v1.Id)
		local var7 = var6
		var7 = var7 and var6.PrimaryPart
		local bool3 = false
		if var2 ~= nil then
			bool3 = math.abs(var2.Position.Y - (v1.Floor + 3)) < 8
		end

		local var9 = bool2
		if var9 then
			var9 = false
			if var7 ~= nil then
				var9 = false
				if var4 == v1.Region then
					var9 = bool3
				end
			end
		end

		local var11 = tbl6[v1.Id]
		if var9 and (not var11) then
			tbl6[v1.Id] = questMarker("KeyMarker_" .. v1.Id, var7, "KEY PIECE", 2.4, 70)
		elseif not var9 and var11 then
			var11:Destroy()
			tbl6[v1.Id] = nil
		end
	end
end

local function applyReveal(arg1, arg2)
	local var2 = tbl5[arg1]
	if not var2 then
		return
	end

	local var4 = findProp(var2)
	if not var4 or var4 == var20 then
		return
	end

	if arg1 == "TV" then
		local var7 = var4:FindFirstChild("TVScreen")
		if var7 then
			buildForecast(var7)
		end
	elseif arg1 == "CeilingFan" then
		startFan(var4)
	elseif arg1 == "Toaster" and arg2 then
		toasterPop(var4)
	else
		if string.sub(arg1, 1, 9) == "KeyPiece_" then
			floatKey(var4, arg2)
		end
	end

	if arg2 then
		local var8 = sparkle
		var8((if var4:IsA("Model") then var4:GetBoundingBox().Position else var4.Position) + Vector3.new(0, 1, 0), 24)
	end
end

tbl4.init = function()
	var20 = workspace:WaitForChild("FrozenHouse"):WaitForChild("World")
	var4 = Instance.new("Folder")
	var4.Name = "FrozenHouseClientFx"
	var4.Parent = workspace
	var22 = emitterPart("LocalImpact")
	var19.get("HeatFx").OnClientEvent:Connect(onHeatFx)
	var16.Heartbeat:Connect(function(arg1)
		updateAirflow(arg1)
		local var1 = var13.firing
		var1 = var1 and var13.impact
		local var5
		if var1 and var1.iceId then
			var5 = var1.normal * 2
			var22.CFrame = CFrame.lookAt(var1.position + var1.normal * 0.35, var1.position + var5)
			setEmitting(var22, true)
		else
			local var6 = var22
			local var7 = var6.Steam
			var7.Enabled = false
			var6.Drops.Enabled = false
			local var8 = var6.Glow
			var8.Enabled = false
			var7.Rate = if var3.settings.ReducedEffects then 4 else 10
			var8.Rate = if var3.settings.ReducedEffects then 5 else 10
			var5 = 0
			tbl1[var6] = var5
		end

		local var9 = os.clock()
		for k1, v1 in pairs(tbl3) do
			if 0.3 >= var9 - v1.seen then
				continue
			end

			if not v1.part.Steam.Enabled then
				continue
			end

			local var10 = v1.part
			local var11 = var10.Steam
			var11.Enabled = false
			var10.Drops.Enabled = false
			local var12 = var10.Glow
			var12.Enabled = false
			var11.Rate = if var3.settings.ReducedEffects then 4 else 10
			var12.Rate = if var3.settings.ReducedEffects then 5 else 10
			tbl1[var10] = 0
		end

		for k2, v2 in pairs(tbl2) do
			if var2.HumanTorch.FxInterval + 0.15 >= var9 - v2.seen then
				continue
			end

			if not v2.part.Steam.Enabled then
				continue
			end

			local var14 = v2.part
			var14.Steam.Enabled = false
			local var15 = var14.Steam
			var15.Rate = if var3.settings.ReducedEffects then 2 else 4
			var14.Drops.Enabled = false
			var14.Glow.Enabled = false
			var15 = var14.Glow
			var15.Rate = if var3.settings.ReducedEffects then 3 else 6
			tbl1[var14] = 0
		end

		updateGlows(arg1)
	end)

	var10.PlayerRemoving:Connect(function(arg1)
		local var1 = tbl2
		for k1, v1 in ipairs({ tbl3, var1 }) do
			local var2 = v1[arg1.UserId]
			if not var2 then
				continue
			end

			tbl1[var2.part] = nil
			var2.part:Destroy()
			v1[arg1.UserId] = nil
		end
	end)

	local var1 = var20:WaitForChild("House")
	local tbl6 = { FrontDoorOpen = var1:WaitForChild("FrontDoor") }
	tbl6.BasementOpen = var1:WaitForChild("BasementDoor")
	local var5 = tbl6.BasementOpen:WaitForChild("Padlock")
	for k1, v1 in pairs(tbl6) do
		if var3.attr(k1) == true then
			animateDoor(v1, true)
		end

		var3.onAttr(k1, function(arg1)
			if not arg1 then
				return
			end

			local bool2 = false
			if k1 == "BasementOpen" then
				bool2 = var5:FindFirstChild("Body")
			end

			if bool2 then
				sparkle(bool2.Position, 20)
			end

			animateDoor(v1, false)
		end)

	end

	var3.on("KeyPieceFound", function(arg1)
		if typeof(arg1.position) == "Vector3" then
			sparkle(arg1.position + Vector3.new(0, 1.4, 0), 30)
		end

		updateKeyMarkers()
	end)

	local num1 = 0
	var16.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if 0.25 <= num1 then
			num1 = 0
			updateKeyMarkers()
		end
	end)

	for k2 in pairs(tbl5) do
		if not var3.attr("Reveal_" .. k2) then
			continue
		end

		applyReveal(k2, false)
	end

	var3.on("Reveal", function(arg1)
		applyReveal(arg1.key, true)
	end)

	var3.on("RegionCleared", function(arg1)
		regionCleared(arg1.region)
	end)

	local function updateMarker()
		local bool1 = false
		if var3.attr("FreezerReady") == true then
			bool1 = var3.phase() == "Running"
		end

		if bool1 and (not var23) then
			var23 = questMarker("TurnOffMarker", var20.Basement.FreezerChamber.OffSwitch:FindFirstChild("Console"), "TURN OFF", 5.6, 90)
			return
		end

		if not bool1 and var23 then
			var23:Destroy()
			var23 = nil
		end
	end

	var3.onAttr("FreezerReady", updateMarker, true)
	var3.onAttr("Phase", updateMarker)
	var3.on("Finale", function()
		tbl4.playFinale()
	end)
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.HUD [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local var3 = var1:WaitForChild("MeltShared")
local str1 = "Classes"
local str2 = "ClassIcons"
local str3 = "ClassPerks"
local var4 = require(var3:WaitForChild(str1))
local str4 = "Products"
local var5 = require(var3:WaitForChild(str2))
local var6 = require(var3:WaitForChild(str3))
str1 = require(var3:WaitForChild(str4))
local var7 = require(var2.Config)
local var8 = require(script.Parent.UIKit)
local var9 = require(script.Parent.Focus)
local bool1 = false
local tbl1 = {}
local tbl2 = {}
local var10 = game:GetService("ContextActionService")
local var11 = game:GetService("Players")
local var12 = game:GetService("RunService")
local var13 = game:GetService("StarterGui")
local var14 = game:GetService("UserInputService")
local var15 = require(var2.Layout)
local var16 = require(var2.ToolStats)
str2 = require(var2.Net)
str3 = require(script.Parent.Battery)
str4 = require(script.Parent.ClientState)
local var17 = require(script.Parent.Icons)
local var18 = require(script.Parent.Quests)
local function showNextBanner()
	if bool1 or #tbl1 == 0 then
		return
	end

	bool1 = true
	local var1 = tbl2.banner
	local var2 = table.remove(tbl1, 1)
	var1.Label.Text = var2
	var1.Visible = true
	var1.Position = UDim2.new(0.5, 0, 0, 150)
	var1.GroupTransparency = 1
	var8.tween(var1, 0.25, { GroupTransparency = 0, Position = UDim2.new(0.5, 0, 0, 160) })
	task.delay(2.4, function()
		var8.tween(var1, 0.3, { GroupTransparency = 1 })
		task.wait(0.32)
		var1.Visible = false
		bool1 = false
		showNextBanner()
	end)
end

local tbl3 = {}
local tbl4 = {
	upgradesButton = function()
		return tbl2.upgrades
	end,
	banner = function(arg1)
		table.insert(tbl1, arg1)
		showNextBanner()
	end,
	toast = function(arg1, arg2)
		local var1 = tbl2.toast
		var1.Label.Text = arg1
		var1.Visible = true
		var1.GroupTransparency = 0
		local var2 = os.clock()
		tbl2.toastStamp = var2
		task.delay(arg2 or 2.6, function()
			if tbl2.toastStamp == var2 then
				var8.tween(var1, 0.3, { GroupTransparency = 1 })
				task.wait(0.3)
				if tbl2.toastStamp == var2 then
					var1.Visible = false
				end
			end
		end)
	end,
}

tbl4.hint = function(arg1, arg2, arg3)
	if tbl3[arg1] or str4.phase() ~= "Running" then
		return false
	end

	tbl3[arg1] = true
	tbl4.toast(arg2, arg3 or 3)
	return true
end

local var19 = var8.new
local var20 = var7.Palette
local tbl5 = {}
local var21 = nil
tbl4.findIce = function()
	if tbl2.findIce.Visible then
		var21.Audio.play("UITick", 0.05)
		var21.Helper.activate(tbl2.helperRegion)
	end
end

local var22 = nil
local var23 = tbl4.findIce
local function keycap(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg4
	var1 = var1 or Vector2.new(0.5, 0.5)
	local tbl1 = {
		Name = "Keycap",
		BackgroundColor3 = var20.Text,
		AnchorPoint = var1,
		Position = arg3,
		ZIndex = 5,
	}

	tbl1.Size = UDim2.fromOffset(math.max(26, #arg2 * 11 + 14), 26)
	var1 = var9.Controls.mode() == var9.Mode.KeyboardMouse
	tbl1.Visible = var1
	tbl1.Parent = arg1
	local var2 = var8.corner(7)
	local str1 = "UIStroke"
	local tbl2 = { Color = var20.White, Thickness = 2 }
	local var3 = var19("Frame", tbl1, { var2, var19(str1, tbl2) })
	tbl1 = {
		Text = arg2,
		FontFace = var8.Fonts.Display,
		TextSize = 16,
		TextColor3 = var20.White,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 6,
	}

	tbl1.Parent = var3
	local var4 = var8.label(tbl1)
	var2 = {
		Name = "Glyph",
		BackgroundTransparency = 1,
		Size = UDim2.fromOffset(26, 26),
		Visible = false,
		ZIndex = 6,
	}

	var2.AnchorPoint = Vector2.new(0.5, 0.5)
	var2.Position = UDim2.fromScale(0.5, 0.5)
	var2.Parent = var3
	tbl1 = var19("ImageLabel", var2)
	table.insert(tbl5, {
		cap = var3,
		label = var4,
		glyph = tbl1,
		text = arg2,
		gamepadKey = arg5,
		width = var3.Size.X.Offset,
	})

	return var3
end

local function requestEntrance()
	var21.Audio.play("UITick", 0.05)
	str2.get("RequestEntrance"):FireServer()
end

local var24 = nil
local function jumpButton()
	local var1 = var11.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TouchGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("TouchControlFrame")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("JumpButton")
	if var4 and (var4:IsA("GuiObject") and (var4.Visible and 0 < var4.AbsoluteSize.X)) then
		return var4
	end

	return nil
end

local var25 = nil
local var26 = nil
tbl4.callout = function(arg1)
	if arg1 == var26 then
		return
	end

	var26 = arg1
	local var2 = tbl2.callout
	if arg1 then
		var2.Label.Text = arg1
		var2.Visible = true
		var2.Position = UDim2.new(0.5, 0, 1, -178)
		var8.tween(var2, 0.22, { GroupTransparency = 0, Position = UDim2.new(0.5, 0, 1, -190) })
		var21.Audio.play("UITick", 0.05)
		return
	end

	var8.tween(var2, 0.25, { GroupTransparency = 1 })
	task.delay(0.26, function()
		if var26 == nil then
			var2.Visible = false
		end
	end)
end

local var27 = nil
local num1 = 0
local bool2 = false
tbl4.toggleEquip = function()
	local var2 = str4.humanoid()
	if not str4.character() or (not var2) then
		return
	end

	if str4.holdingGrenade() then
		var21.Grenades.toggle()
		return
	end

	if str4.heldTool() then
		bool2 = true
		var2:UnequipTools()
		return
	end

	local var3 = var11.LocalPlayer:FindFirstChildOfClass("Backpack")
	for k1, v1 in ipairs(var3 and var3:GetChildren() or {}) do
		if not v1:IsA("Tool") then
			continue
		end

		if not v1:GetAttribute("ToolId") then
			continue
		end

		var2:EquipTool(v1)
		return
	end
end

local var28 = nil
local var29 = nil
local function refreshQuest()
	local var1, var2 = var18.current()
	tbl2.objectiveLabel.Text = var1
	tbl2.objectiveSub.Text = var2 or ""
	tbl2.objectiveSub.Visible = var2 ~= nil
	local var3 = tbl2.objective
	local var4 = UDim2.fromOffset
	local num1 = 490
	var3.Size = var4(num1, if var2 then 54 else 34)
	tbl2.objective.Visible = var1 ~= ""
	if var1 ~= var28 then
		if var28 and (var1 ~= "" and str4.phase() == "Running") then
			tbl2.objectiveScale.Scale = 1.08
			var8.tween(tbl2.objectiveScale, 0.35, { Scale = 1 }, Enum.EasingStyle.Back)
		end

		var28 = var1
	end
end

local var30 = nil
local num2 = 0
local bool3 = false
local function affordable(arg1)
	local var1 = str4.ownedTools()
	local var2 = str4.perks()
	local bool1 = false
	local var3 = nil
	for k1, v1 in ipairs(var7.Tools) do
		local var4
		if var1[v1.Id] then
			local var5 = str4.levels(v1.Id)
			for k2, v2 in ipairs(var7.Upgrades.Tracks) do
				local var6 = var16.price(v1.Id, v2, var5[v2], var2)
				if not var6 or var6 > arg1 then
					continue
				end

				bool1 = true
			end
		elseif not v1.Product and (v1.Requires and var1[v1.Requires] or var16.toolPrice(v1.Id, var2) <= arg1 and (not var3)) then
			var3 = v1
		end
	end

	return bool1, var3
end

local tbl6 = {}
local var31 = nil
local var32 = nil
local bool4 = false
local var33 = var7.Battery
local tbl7 = { mode = nil, lowest = 1, lowCued = false }
tbl4.describeClass = function()
	return {
		chip = tbl2.classChip.Visible,
		name = tbl2.className.Text,
		sub = tbl2.classSub.Text,
		team = tbl2.teamPill.Visible and tbl2.teamLabel.Text or nil,
		technician = tbl2.technician.Visible and tbl2.technicianLabel.Text or nil,
		battery = tbl2.batteryLabel.Text,
	}
end

tbl4.refreshIdleHints = function()
	if not var21 or (not var21.ToolCycle) then
		return
	end

	local tbl1 = {}
	if str4.canPlay() then
		if not str4.cinematic then
			if str4.holdingGrenade() then
				table.insert(tbl1, { action = "UseTool", label = var7.Text.HintThrow })
			else
				if str4.heldMelter() then
					table.insert(tbl1, { action = "UseTool", label = var7.Text.HintUseTool })
				end
			end

			if 1 < (#var21.ToolCycle.items()) then
				table.insert(tbl1, { action = "NextTool", label = var7.Text.HintTools })
			end

			table.insert(tbl1, { action = "Interact", label = var7.Text.HintInteract })
			table.insert(tbl1, { action = "OpenMenu", label = var7.Text.HintMenu })
		end
	end

	var9.setIdleHints(tbl1)
end

tbl4.setVisible = function(arg1)
	var22.Enabled = arg1
	var25.Enabled = arg1
end

local function buildTop()
	local tbl1 = { Name = "Top", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0) }
	tbl1.Position = UDim2.new(0.5, 0, 0, 6)
	tbl1.Size = UDim2.fromOffset(500, 200)
	tbl1.Parent = var22
	local var1 = var19("Frame", tbl1)
	local tbl3 = {
		FillDirection = Enum.FillDirection.Vertical,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
		Padding = UDim.new(0, 6),
	}

	tbl3.SortOrder = Enum.SortOrder.LayoutOrder
	tbl3.Parent = var1
	var19("UIListLayout", tbl3)
	tbl1 = { Name = "ProgressCard", Size = UDim2.fromOffset(470, 78), LayoutOrder = 1 }
	tbl1.Parent = var1
	local var2 = var8.panel(tbl1)
	tbl3 = {
		Name = "Title",
		Text = var7.Title,
		FontFace = var8.Fonts.Display,
		TextSize = 26,
		TextColor3 = var20.DeepBlue,
		Size = UDim2.new(1, 0, 0, 32),
	}

	tbl3.Position = UDim2.fromOffset(0, 4)
	tbl3.Parent = var2
	var8.label(tbl3)
	local tbl4 = {
		Name = "DifficultyBadge",
		BackgroundColor3 = Color3.fromHex("#D9522B"),
		Visible = false,
	}

	tbl4.AnchorPoint = Vector2.new(1, 0)
	tbl4.Position = UDim2.new(1, -10, 0, 8)
	tbl4.Size = UDim2.fromOffset(62, 24)
	tbl4.Parent = var2
	local var3 = var8.corner(12)
	local str1 = "UIStroke"
	local tbl5 = { Color = Color3.fromHex("#A83A1B"), Thickness = 2 }
	tbl1 = var19("Frame", tbl4, { var3, var19(str1, tbl5) })
	tbl4 = {
		Name = "Label",
		Text = var7.Text.HardBadge,
		FontFace = var8.Fonts.Display,
		TextSize = 15,
		TextColor3 = var20.White,
		Size = UDim2.fromScale(1, 1),
	}

	tbl4.Parent = tbl1
	var8.label(tbl4)
	tbl2.difficultyBadge = tbl1
	str4.onAttr("Difficulty", function(arg1)
		tbl1.Visible = arg1 == "hard"
	end, true)

	tbl4 = { Name = "HouseBar", Size = UDim2.new(1, -36, 0, 26), Radius = 10 }
	tbl4.Position = UDim2.new(0.5, 0, 0, 40)
	tbl4.AnchorPoint = Vector2.new(0.5, 0)
	tbl4.Color = var20.Orange
	tbl4.Parent = var2
	tbl3 = var8.progressBar(tbl4)
	local tbl6 = {
		Name = "HouseLabel",
		Text = "House thawed: 0%",
		FontFace = var8.Fonts.Bold,
		TextSize = 17,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 3,
	}

	tbl6.Parent = tbl3.track
	tbl4 = var8.label(tbl6)
	tbl2.houseBar = tbl3
	tbl2.houseLabel = tbl4
	var3 = { Name = "RoomPill", Size = UDim2.fromOffset(280, 36), LayoutOrder = 2, Radius = 18 }
	var3.Parent = var1
	tbl6 = var8.panel(var3)
	str1 = {
		Name = "RoomLabel",
		Text = "",
		FontFace = var8.Fonts.Bold,
		TextSize = 19,
		Size = UDim2.fromScale(1, 1),
	}

	str1.Parent = tbl6
	tbl2.roomLabel = var8.label(str1)
	tbl2.roomPill = tbl6
	str1 = {
		Name = "Objective",
		BackgroundColor3 = var20.DeepBlue,
		BackgroundTransparency = 0.1,
		Size = UDim2.fromOffset(490, 34),
		LayoutOrder = 3,
	}

	str1.Parent = var1
	local num1 = 17
	var3 = var19("CanvasGroup", str1, { var8.corner(num1) })
	tbl2.objectiveScale = var19("UIScale", { Parent = var3 })
	tbl5 = { Name = "Tag", BackgroundColor3 = var20.Orange, Position = UDim2.fromOffset(5, 5) }
	tbl5.Size = UDim2.fromOffset(66, 24)
	tbl5.Parent = var3
	local num2 = 12
	local var4 = var19("Frame", tbl5, { var8.corner(num2) })
	tbl5 = {
		Text = var7.Text.QuestLabel,
		FontFace = var8.Fonts.Display,
		TextSize = 15,
		Size = UDim2.fromScale(1, 1),
	}

	tbl5.Parent = var4
	var8.label(tbl5)
	local tbl7 = {
		Name = "Goal",
		Text = "",
		TextColor3 = var20.Cream,
		FontFace = var8.Fonts.Bold,
		TextScaled = true,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(80, 4),
	}

	tbl7.Size = UDim2.new(1, -92, 0, 26)
	tbl7.Parent = var3
	tbl2.objectiveLabel = var8.label(tbl7)
	var19("UITextSizeConstraint", { MaxTextSize = 17, Parent = tbl2.objectiveLabel })
	tbl7 = {
		Name = "Detail",
		Text = "",
		TextColor3 = var20.IceFrost,
		TextScaled = true,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(80, 30),
		Visible = false,
	}

	tbl7.Size = UDim2.new(1, -92, 0, 20)
	tbl7.Parent = var3
	tbl2.objectiveSub = var8.label(tbl7)
	var19("UITextSizeConstraint", { MaxTextSize = 15, Parent = tbl2.objectiveSub })
	tbl2.objective = var3
	tbl7 = {
		Name = "FindIce",
		Text = "Find remaining ice",
		TextSize = 18,
		Secondary = true,
		Size = UDim2.fromOffset(220, 40),
		LayoutOrder = 4,
	}

	tbl7.Parent = var1
	tbl7.OnClick = var23
	tbl2.findIce = var8.button(tbl7)
	keycap(tbl2.findIce, "F", UDim2.fromOffset(4, 4), nil, nil)
	tbl2.findIce.Visible = false
end

local function buildCoins()
	local tbl1 = { Name = "Coins", AnchorPoint = Vector2.new(1, 0), Radius = 27 }
	tbl1.Position = UDim2.new(1, -12, 0, 8)
	tbl1.Size = UDim2.fromOffset(160, 54)
	tbl1.Parent = var22
	local var1 = var8.panel(tbl1)
	tbl1 = var8.coin(34)
	tbl1.Position = UDim2.fromOffset(12, 10)
	tbl1.Parent = var1
	tbl2.coinIcon = tbl1
	tbl2.coinScale = var19("UIScale", { Parent = tbl1 })
	local tbl3 = {
		Name = "Amount",
		Text = "0",
		FontFace = var8.Fonts.Display,
		TextSize = 28,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(54, 0),
	}

	tbl3.Size = UDim2.new(1, -62, 1, 0)
	tbl3.Parent = var1
	tbl2.coinsLabel = var8.label(tbl3)
	tbl3 = {
		Name = "Pulse",
		Text = "",
		FontFace = var8.Fonts.Display,
		TextSize = 22,
		TextColor3 = var20.OrangeDark,
		AnchorPoint = Vector2.new(1, 0),
		TextTransparency = 1,
	}

	tbl3.Position = UDim2.new(1, -10, 1, 4)
	tbl3.Size = UDim2.fromOffset(100, 26)
	tbl3.TextXAlignment = Enum.TextXAlignment.Right
	tbl3.Parent = var1
	tbl2.coinPulse = var8.label(tbl3)
end

local function buildSettingsButton()
	local tbl1 = {
		Name = "Settings",
		Text = "\226\154\153",
		TextSize = 30,
		Secondary = true,
		Position = UDim2.fromOffset(12, 8),
		Radius = 27,
	}

	tbl1.Size = UDim2.fromOffset(54, 54)
	tbl1.Parent = var22
	tbl1.OnClick = function()
		var21.Audio.play("UITick", 0.05)
		var21.SettingsPanel.toggle()
	end

	tbl2.settings = var8.button(tbl1)
	keycap(tbl2.settings, "M", UDim2.new(1, -4, 1, -4), nil, nil)
end

local function buildClassChip()
	local tbl1 = {
		Name = "ClassChip",
		AutoButtonColor = false,
		Text = "",
		BackgroundColor3 = var8.Colors.Panel,
		Position = UDim2.fromOffset(74, 8),
		Visible = false,
	}

	tbl1.Size = UDim2.fromOffset(226, 54)
	tbl1.Parent = var22
	local var1 = var19("TextButton", tbl1, { var8.corner(27), var8.stroke() })
	local tbl3 = { Name = "Insignia", BackgroundTransparency = 1, Position = UDim2.fromOffset(8, 7) }
	tbl3.Size = UDim2.fromOffset(40, 40)
	tbl3.Parent = var1
	tbl2.classIcon = var19("Frame", tbl3)
	local tbl4 = {
		Name = "ClassName",
		Text = "",
		FontFace = var8.Fonts.Display,
		TextSize = 19,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = false,
		TextTruncate = Enum.TextTruncate.AtEnd,
		Position = UDim2.fromOffset(56, 5),
	}

	tbl4.Size = UDim2.new(1, -68, 0, 26)
	tbl4.Parent = var1
	tbl2.className = var8.label(tbl4)
	tbl4 = {
		Name = "Sub",
		Text = "",
		FontFace = var8.Fonts.Bold,
		TextSize = 14,
		TextColor3 = var8.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(56, 30),
	}

	tbl4.Size = UDim2.new(1, -68, 0, 18)
	tbl4.Parent = var1
	tbl2.classSub = var8.label(tbl4)
	keycap(var1, "C", UDim2.new(1, -4, 1, -4), nil, nil)
	var1.Activated:Connect(function()
		var21.Audio.play("UITick", 0.05)
		var21.ClassInfo.toggle()
	end)

	tbl2.classChip = var1
	tbl4 = {
		Name = "TeamPerks",
		BackgroundColor3 = var20.Teal,
		Position = UDim2.fromOffset(74, 68),
		Visible = false,
	}

	tbl4.Size = UDim2.fromOffset(0, 28)
	tbl4.AutomaticSize = Enum.AutomaticSize.X
	tbl4.Parent = var22
	local var2 = var8.corner(14)
	local tbl5 = { PaddingLeft = UDim.new(0, 12) }
	tbl5.PaddingRight = UDim.new(0, 12)
	local str1 = "UIPadding"
	local var3 = var19("Frame", tbl4, { var2, var19(str1, tbl5) })
	tbl3 = {
		Name = "Label",
		Text = "",
		FontFace = var8.Fonts.Bold,
		TextSize = 15,
		TextColor3 = var20.White,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 28),
	}

	tbl3.Parent = var3
	tbl2.teamLabel = var8.label(tbl3)
	tbl2.teamPill = var3
end

local function buildUpgradesButton()
	local tbl1 = {
		Name = "Upgrades",
		AutoButtonColor = false,
		Text = "",
		BackgroundColor3 = var20.DeepBlue,
		AnchorPoint = Vector2.new(0, 0.5),
	}

	tbl1.Position = UDim2.new(0, 14, 0.42, 0)
	tbl1.Size = UDim2.fromOffset(96, 100)
	tbl1.Parent = var22
	local var1 = var8.corner(20)
	local str1 = "UIStroke"
	local tbl3 = { Color = var20.White, Thickness = 3, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var2 = var19("TextButton", tbl1, { var1, var19(str1, tbl3) })
	local var3 = var19("UIScale", { Parent = var2 })
	var2.MouseEnter:Connect(function()
		var8.tween(var3, 0.12, { Scale = 1.05 })
	end)

	var2.MouseLeave:Connect(function()
		var8.tween(var3, 0.12, { Scale = 1 })
	end)

	var1 = { Name = "Icon", AnchorPoint = Vector2.new(0.5, 0) }
	var1.Position = UDim2.new(0.5, 0, 0, 4)
	var1.Size = UDim2.fromOffset(66, 66)
	var1.Parent = var2
	var17.label("Manual", var1, "")
	local tbl4 = {
		Name = "Label",
		Text = "Upgrades",
		FontFace = var8.Fonts.Display,
		TextSize = 18,
		TextColor3 = var20.Cream,
		Position = UDim2.new(0, 0, 1, -30),
	}

	tbl4.Size = UDim2.new(1, 0, 0, 24)
	tbl4.Parent = var2
	var8.label(tbl4)
	local str2 = "OpenMenu"
	keycap(var2, "TAB", UDim2.new(0.5, 0, 1, 6), Vector2.new(0.5, 0), var9.Controls.key(str2))
	local tbl5 = {
		Name = "Dot",
		BackgroundColor3 = var20.Coral,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
		ZIndex = 4,
	}

	tbl5.Position = UDim2.new(1, -6, 0, 6)
	tbl5.Size = UDim2.fromOffset(20, 20)
	tbl5.Parent = var2
	tbl3 = var8.corner(10)
	local str3 = "UIStroke"
	local tbl6 = { Color = var20.White, Thickness = 2 }
	tbl2.upgradesDot = var19("Frame", tbl5, { tbl3, var19(str3, tbl6) })
	var2.Activated:Connect(function()
		var21.Manual.toggle()
	end)

	tbl2.upgrades = var2
end

local function buildToolChip()
	local tbl1 = {
		Name = "ToolChip",
		AutoButtonColor = false,
		Text = "",
		BackgroundColor3 = var8.Colors.Panel,
		AnchorPoint = Vector2.new(0.5, 1),
	}

	tbl1.Position = UDim2.new(0.5, 0, 1, -12)
	tbl1.Size = UDim2.fromOffset(250, 66)
	tbl1.Parent = var22
	local var1 = var19("TextButton", tbl1, { var8.corner(33), var8.stroke() })
	tbl2.toolChip = var1
	local tbl3 = {
		Name = "ToolName",
		Text = "Hairdryer",
		FontFace = var8.Fonts.Display,
		TextSize = 22,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(72, 6),
	}

	tbl3.Size = UDim2.new(1, -84, 0, 30)
	tbl3.Parent = var1
	tbl2.toolName = var8.label(tbl3)
	tbl3 = {
		Name = "Hint",
		Text = "Hold to melt",
		TextSize = 15,
		TextColor3 = var8.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(72, 36),
	}

	tbl3.Size = UDim2.new(1, -84, 0, 20)
	tbl3.Parent = var1
	tbl2.toolHint = var8.label(tbl3)
	var1.Activated:Connect(function()
		var21.Audio.play("UITick", 0.05)
		tbl4.toggleEquip()
	end)
end

local function buildGrenadeChip()
	local tbl1 = {
		Name = "GrenadeChip",
		AutoButtonColor = false,
		Text = "",
		BackgroundColor3 = var8.Colors.Panel,
		AnchorPoint = Vector2.new(0, 1),
		Visible = false,
	}

	tbl1.Position = UDim2.new(0.5, 137, 1, -12)
	tbl1.Size = UDim2.fromOffset(176, 66)
	tbl1.Parent = var22
	local num1 = 33
	local var1 = var19("TextButton", tbl1, { var8.corner(num1) })
	tbl2.grenadeStroke = var8.stroke()
	tbl2.grenadeStroke.Parent = var1
	local num2 = 54
	num1 = 54
	local var2 = var8.toolPreview(var7.Grenade.ToolId, UDim2.fromOffset(num2, num1))
	var2.Position = UDim2.fromOffset(8, 6)
	var2.Parent = var1
	num2 = {
		Name = "Count",
		Text = "",
		FontFace = var8.Fonts.Display,
		TextSize = 21,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = false,
		Position = UDim2.fromOffset(66, 6),
	}

	num2.Size = UDim2.new(1, -78, 0, 30)
	num2.Parent = var1
	tbl2.grenadeCount = var8.label(num2)
	num2 = {
		Name = "Hint",
		Text = "",
		TextSize = 14,
		TextColor3 = var8.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(66, 36),
	}

	num2.Size = UDim2.new(1, -78, 0, 20)
	num2.Parent = var1
	tbl2.grenadeHint = var8.label(num2)
	local str1 = "NextTool"
	keycap(var1, "G", UDim2.new(1, -6, 0, 6), nil, var9.Controls.key(str1))
	var1.Activated:Connect(function()
		var21.Audio.play("UITick", 0.05)
		var21.Grenades.toggle()
	end)

	tbl2.grenadeChip = var1
end

local function buildEntranceButton()
	local tbl1 = {
		Name = "Entrance",
		Text = var7.Text.ReturnToEntrance,
		TextSize = 18,
		Secondary = true,
		Position = UDim2.fromOffset(12, 70),
		Radius = 24,
		Visible = false,
	}

	tbl1.Size = UDim2.fromOffset(236, 48)
	tbl1.Parent = var22
	tbl1.OnClick = requestEntrance
	tbl2.entrance = var8.button(tbl1)
	tbl1 = { PaddingRight = UDim.new(0, 40) }
	tbl1.Parent = tbl2.entrance
	var19("UIPadding", tbl1)
	keycap(tbl2.entrance, "Z", UDim2.new(1, 20, 0.5, 0), nil, var7.Keys.ReturnToEntranceGamepad)
end

local function buildBattery()
	local tbl1 = { Name = "Battery", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 1) }
	tbl1.Position = UDim2.new(0.5, 0, 1, -86)
	tbl1.Size = UDim2.fromOffset(292, 40)
	tbl1.Parent = var22
	local var1 = var19("Frame", tbl1)
	local tbl3 = { Name = "Icon", Position = UDim2.fromOffset(0, 1) }
	tbl3.Size = UDim2.fromOffset(38, 38)
	tbl3.Parent = var1
	tbl2.batteryIcon = var17.label("Battery", tbl3, "")
	tbl3 = { Name = "Running", Position = UDim2.fromOffset(1, 2), Visible = false }
	tbl3.Size = UDim2.fromOffset(36, 36)
	tbl3.Parent = var1
	tbl2.batteryBolt = var17.label("Bolt", tbl3, "")
	local tbl4 = {
		Name = "Shell",
		BackgroundColor3 = var8.Colors.Panel,
		Position = UDim2.fromOffset(44, 5),
	}

	tbl4.Size = UDim2.fromOffset(234, 30)
	tbl4.Parent = var1
	local var2 = var8.corner(10)
	local str1 = "UIStroke"
	local tbl5 = { Color = var20.Text, Thickness = 3, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var3 = var19("Frame", tbl4, { var2, var19(str1, tbl5) })
	tbl3 = { Name = "Terminal", BackgroundColor3 = var20.Text, AnchorPoint = Vector2.new(0, 0.5) }
	tbl3.Position = UDim2.new(1, 2, 0.5, 0)
	tbl3.Size = UDim2.fromOffset(8, 14)
	tbl3.Parent = var3
	str1 = 3
	var19("Frame", tbl3, { var8.corner(str1) })
	tbl3 = { Name = "Inner", BackgroundTransparency = 1, Position = UDim2.fromOffset(4, 4) }
	tbl3.Size = UDim2.new(1, -8, 1, -8)
	tbl3.Parent = var3
	tbl1 = var19("Frame", tbl3)
	local tbl6 = { Name = "Fill", BackgroundColor3 = var20.Teal, Size = UDim2.fromScale(1, 1) }
	tbl6.Parent = tbl1
	local num1 = 222
	local num2 = 222
	local num3 = 222
	tbl5 = var8.corner(6)
	local str2 = "UIGradient"
	local tbl7 = {
		Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(num1, num2, num3)),
		Rotation = 90,
	}

	tbl2.batteryFill = var19("Frame", tbl6, { tbl5, var19(str2, tbl7) })
	var2 = {
		Name = "Label",
		Text = "Battery 100%",
		FontFace = var8.Fonts.Bold,
		TextSize = 17,
		TextColor3 = var20.Text,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 3,
	}

	var2.Parent = var3
	tbl2.batteryLabel = var8.label(var2)
	var19("UIStroke", { Color = var20.White, Thickness = 2, Transparency = 0.15, Parent = tbl2.batteryLabel })
	tbl2.battery = var1
	var2 = {
		Name = "Technician",
		BackgroundColor3 = var20.DeepBlue,
		AnchorPoint = Vector2.new(0, 0.5),
		Visible = false,
	}

	var2.Position = UDim2.new(1, 12, 0.5, 0)
	var2.Size = UDim2.fromOffset(0, 30)
	var2.AutomaticSize = Enum.AutomaticSize.X
	var2.Parent = var1
	str1 = var8.corner(15)
	str2 = { PaddingLeft = UDim.new(0, 12) }
	str2.PaddingRight = UDim.new(0, 12)
	local str3 = "UIPadding"
	tbl4 = var19("Frame", var2, { str1, var19(str3, str2) })
	tbl6 = {
		Name = "Label",
		Text = "",
		FontFace = var8.Fonts.Bold,
		TextSize = 16,
		TextColor3 = var20.Cream,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 30),
	}

	tbl6.Parent = tbl4
	tbl2.technicianLabel = var8.label(tbl6)
	tbl2.technician = tbl4
end

local function buildMelt()
	local tbl1 = {
		Name = "MeltButton",
		AutoButtonColor = false,
		Text = "MELT",
		FontFace = var8.Fonts.Display,
		TextSize = 30,
		TextColor3 = var20.Text,
		BackgroundColor3 = var20.Orange,
		AnchorPoint = Vector2.new(1, 1),
	}

	tbl1.Position = UDim2.new(1, -150, 1, -70)
	tbl1.Size = UDim2.fromOffset(128, 128)
	tbl1.Visible = var14.TouchEnabled
	tbl1.Parent = var22
	local var1 = var8.corner(64)
	local str1 = "UIStroke"
	local tbl3 = { Color = var20.OrangeDark, Thickness = 4 }
	local var2 = var19("TextButton", tbl1, { var1, var19(str1, tbl3) })
	var8.fitText(var2)
	local var3 = var19("UIScale", { Parent = var2 })
	tbl2.melt = var2
	tbl1 = nil
	var2.InputBegan:Connect(function(arg1)
		local var2 = arg1.UserInputType
		if (var2 == Enum.UserInputType.Touch or var2 == Enum.UserInputType.MouseButton1) and str4.holdingGrenade() then
			var8.tween(var3, 0.08, { Scale = 0.92 })
			task.delay(0.12, function()
				var8.tween(var3, 0.12, { Scale = 1 })
			end)

			var21.Grenades.throw()
			return
		end

		if var2 == Enum.UserInputType.Touch or var2 == Enum.UserInputType.MouseButton1 then
			var8.tween(var3, 0.08, { Scale = 0.92 })
			var21.Input.touchPress()
			if var2 == Enum.UserInputType.Touch then
				tbl1 = arg1
				var21.FirstPerson.trackTouchAim(arg1)
			end
		end
	end)

	var2.InputEnded:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
			var8.tween(var3, 0.12, { Scale = 1 })
			var21.Input.touchRelease()
		end
	end)

	var14.TouchEnded:Connect(function(arg1)
		if arg1 == tbl1 then
			tbl1 = nil
			var8.tween(var3, 0.12, { Scale = 1 })
			var21.Input.touchRelease()
		end
	end)

	var14.InputEnded:Connect(function(arg1)
		if arg1 == tbl1 then
			tbl1 = nil
			var8.tween(var3, 0.12, { Scale = 1 })
			var21.Input.touchRelease()
		end
	end)
end

local function buildReticle()
	var25 = var19("ScreenGui", {
		Name = "FrozenHouseReticle",
		ResetOnSpawn = false,
		IgnoreGuiInset = true,
		ScreenInsets = Enum.ScreenInsets.None,
		DisplayOrder = 4,
		Parent = var11.LocalPlayer:WaitForChild("PlayerGui"),
	})

	var8.autoScale(var25)
	local tbl1 = {
		Name = "Reticle",
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
	}

	tbl1.Position = UDim2.fromScale(0.5, 0.5)
	tbl1.Size = UDim2.fromOffset(34, 34)
	tbl1.Parent = var25
	local var1 = var19("Frame", tbl1)
	tbl2.reticleStroke = var19("UIStroke", { Color = var20.White, Thickness = 3, Transparency = 0.1 })
	local tbl3 = { Name = "Ring", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl3.Position = UDim2.fromScale(0.5, 0.5)
	tbl3.Size = UDim2.fromScale(1, 1)
	tbl3.Parent = var1
	tbl2.reticleRing = var19("Frame", tbl3, { var8.corner(17), tbl2.reticleStroke })
	tbl3 = { Name = "Dot", BackgroundColor3 = var20.Orange, AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl3.Position = UDim2.fromScale(0.5, 0.5)
	tbl3.Size = UDim2.fromOffset(8, 8)
	tbl3.Parent = var1
	local var2 = var8.corner(4)
	local str1 = "UIStroke"
	local tbl4 = { Color = var20.Text, Thickness = 1 }
	tbl2.reticleDot = var19("Frame", tbl3, { var2, var19(str1, tbl4) })
	tbl2.reticle = var1
end

local function buildMouseHint()
	local tbl1 = {
		Name = "MouseHint",
		BackgroundColor3 = var20.DeepBlue,
		BackgroundTransparency = 0.25,
		AnchorPoint = Vector2.new(0, 1),
		Visible = false,
	}

	tbl1.Position = UDim2.new(0, 16, 1, -16)
	tbl1.Size = UDim2.fromOffset(214, 34)
	tbl1.Parent = var22
	local num1 = 17
	local var1 = var19("Frame", tbl1, { var8.corner(num1) })
	tbl1 = {
		Text = "Hold Alt to use the mouse",
		FontFace = var8.Fonts.Bold,
		TextSize = 16,
		TextColor3 = var20.Cream,
		Size = UDim2.fromScale(1, 1),
	}

	tbl1.Parent = var1
	var8.label(tbl1)
	tbl2.mouseHint = var1
end

local function buildBannerAndToast()
	local tbl1 = {
		Name = "Banner",
		BackgroundColor3 = var8.Colors.Panel,
		AnchorPoint = Vector2.new(0.5, 0),
		Visible = false,
	}

	tbl1.Position = UDim2.new(0.5, 0, 0, 160)
	tbl1.Size = UDim2.fromOffset(420, 64)
	tbl1.Parent = var22
	local var1 = var8.corner(20)
	local str1 = "UIStroke"
	local tbl3 = { Color = var20.Orange, Thickness = 3 }
	local var2 = var19("CanvasGroup", tbl1, { var1, var19(str1, tbl3) })
	tbl1 = {
		Name = "Label",
		Text = "",
		FontFace = var8.Fonts.Display,
		TextSize = 30,
		TextColor3 = var20.Text,
		Size = UDim2.fromScale(1, 1),
	}

	tbl1.Parent = var2
	var8.label(tbl1)
	tbl2.banner = var2
	local tbl4 = {
		Name = "Toast",
		BackgroundColor3 = var20.DeepBlue,
		AnchorPoint = Vector2.new(0.5, 1),
		Visible = false,
	}

	tbl4.Position = UDim2.new(0.5, 0, 1, -134)
	tbl4.Size = UDim2.fromOffset(380, 44)
	tbl4.Parent = var22
	str1 = 22
	local var3 = var19("CanvasGroup", tbl4, { var8.corner(str1) })
	tbl4 = {
		Name = "Label",
		Text = "",
		FontFace = var8.Fonts.Bold,
		TextSize = 20,
		TextColor3 = var20.Cream,
		Size = UDim2.fromScale(1, 1),
	}

	tbl4.Parent = var3
	var8.label(tbl4)
	tbl2.toast = var3
end

local function buildCallout()
	local tbl1 = {
		Name = "Callout",
		BackgroundColor3 = var8.Colors.Panel,
		AnchorPoint = Vector2.new(0.5, 1),
		GroupTransparency = 1,
		Visible = false,
	}

	tbl1.Position = UDim2.new(0.5, 0, 1, -190)
	tbl1.Size = UDim2.fromOffset(520, 60)
	tbl1.Parent = var22
	local var1 = var8.corner(20)
	local str1 = "UIStroke"
	local tbl3 = { Color = var20.DeepBlue, Thickness = 3 }
	local var2 = var19("CanvasGroup", tbl1, { var1, var19(str1, tbl3) })
	local tbl4 = { Name = "Lock", BackgroundTransparency = 1, Position = UDim2.fromOffset(16, 8) }
	tbl4.Size = UDim2.fromOffset(38, 44)
	tbl4.Parent = var2
	local var3 = var19("Frame", tbl4)
	var1 = { Name = "Shackle", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0) }
	var1.Position = UDim2.new(0.5, 0, 0, 2)
	var1.Size = UDim2.fromOffset(22, 30)
	var1.Parent = var3
	str1 = var8.corner(11)
	local str2 = "UIStroke"
	local tbl5 = { Color = var20.DeepBlue, Thickness = 5 }
	var19("Frame", var1, { str1, var19(str2, tbl5) })
	var1 = { Name = "Body", BackgroundColor3 = var20.Orange, AnchorPoint = Vector2.new(0.5, 1) }
	var1.Position = UDim2.fromScale(0.5, 1)
	var1.Size = UDim2.fromOffset(36, 26)
	var1.Parent = var3
	str1 = var8.corner(7)
	str2 = "UIStroke"
	tbl5 = { Color = var20.OrangeDark, Thickness = 2 }
	tbl1 = var19("Frame", var1, { str1, var19(str2, tbl5) })
	local tbl6 = { Name = "Keyhole", BackgroundColor3 = var20.Text, AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl6.Position = UDim2.fromScale(0.5, 0.5)
	tbl6.Size = UDim2.fromOffset(6, 12)
	tbl6.Parent = tbl1
	str2 = 3
	var19("Frame", tbl6, { var8.corner(str2) })
	var1 = {
		Name = "Label",
		Text = "",
		FontFace = var8.Fonts.Display,
		TextScaled = true,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(68, 8),
	}

	var1.Size = UDim2.new(1, -84, 1, -16)
	var1.Parent = var2
	tbl4 = var8.label(var1)
	var19("UITextSizeConstraint", { MaxTextSize = 24, Parent = tbl4 })
	tbl2.callout = var2
end

local function refreshProgress()
	local var10
	local var1 = str4.attr("HouseProgress") or 0
	tbl2.houseBar.set(var1)
	local var2 = tbl2.houseLabel
	local str1 = "House thawed: "
	var2.Text = str1 .. (if 1 <= var1 then "100%" else string.format("%d%%", (math.min(99, (math.floor(var1 * 100))))))
	var2 = var29
	var2 = var2 and var15.RegionById[var29]
	if var2 then
		local var4 = str4.attr("Region" .. var2.Id .. "Progress") or 0
		local var5 = tbl2.roomLabel
		if str4.attr("Region" .. var2.Id .. "Cleared") then
			local var8 = var2.Short .. ": cleared!"
			if not var8 then
				local var9 = var2.Short
				local str2 = ": "
				var8 = var9 .. str2 .. (if 1 <= var4 then "100%" else string.format("%d%%", (math.min(99, (math.floor(var4 * 100))))))
			end
		end

		var5.Text = var10
		tbl2.roomPill.Visible = true
	else
		tbl2.roomPill.Visible = false
	end

	refreshQuest()
	local var12 = nil
	str1 = false
	if str4.phase() == "Running" then
		if var2 and (not str4.attr("Region" .. var2.Id .. "Cleared") and var7.Helper.FindIceThreshold <= (str4.attr("Region" .. var2.Id .. "Progress") or 0)) then
			var12 = var2.Id
			str1 = true
		else
			if var7.Helper.FindIceThreshold <= var1 and var1 < 1 then
				str1 = true
			end
		end
	end

	tbl2.helperRegion = var12
	tbl2.findIce.Visible = str1
end

local function refreshCoins(arg1)
	arg1 = arg1 or 0
	tbl2.coinsLabel.Text = tostring(arg1)
	if var30 and var30 < arg1 then
		local var1 = num2 + (arg1 - var30)
		num2 = var1
		if not bool3 then
			bool3 = true
			task.delay(0.6, function()
				bool3 = false
				if 0 < num2 then
					tbl2.coinPulse.Text = "+" .. num2
					tbl2.coinPulse.TextTransparency = 0
					tbl2.coinPulse.Position = UDim2.new(1, -10, 1, 4)
					var8.tween(tbl2.coinPulse, 0.8, { TextTransparency = 1, Position = UDim2.new(1, -10, 1, -8) })
					tbl2.coinScale.Scale = 1.25
					var8.tween(tbl2.coinScale, 0.25, { Scale = 1 })
					num2 = 0
				end
			end)

		end
	end

	var30 = arg1
	local var2, var3 = affordable(arg1)
	tbl2.upgradesDot.Visible = var2
	if var3 and (not tbl6[var3.Id]) then
		tbl6[var3.Id] = true
		tbl4.toast(string.format(var7.Text.ToolReady, var3.Name), 3)
		return
	end

	if var2 then
		if not str4.menuOpen then
			tbl4.hint("upgrade", var14.TouchEnabled and var7.Text.UpgradeReadyTouch or (var9.Controls.isGamepad() and var7.Text.UpgradeReadyGamepad or var7.Text.UpgradeReadyKeyboard), 3.5)
		end
	end
end

local function refreshTool()
	local var1 = str4.toolDef()
	tbl2.toolName.Text = var1.Name
	if var32 ~= var1.Id then
		var32 = var1.Id
		local var3 = tbl2.toolChip:FindFirstChild("Preview")
		if var3 then
			var3:Destroy()
		end

		local num1 = 58
		local num2 = 58
		local var4 = var8.toolPreview(var1.Id, UDim2.fromOffset(num1, num2))
		var4.Position = UDim2.fromOffset(6, 4)
		var4.Parent = tbl2.toolChip
	end

	local var5 = str4.heldTool() ~= nil
	local var6 = var9.Controls.isTouch()
	local var10 = var9.Controls.isGamepad()
	local var11 = str4.settings.ToggleMelting
	if str4.holdingGrenade() then
		local var12 = tbl2.toolHint
		var12.Text = if var6 then "Tap to take out" else var7.Text.GrenadeBack
		return
	end

	if not var5 then
		local var13 = tbl2.toolHint
		local var14
		if var6 then
			var14 = "Tap to take out"
		elseif var10 then
			var14 = "Shoulder buttons to take out"
		else
			var14 = "Press 1 to take out"
		end

		var13.Text = var14
		return
	end

	if var6 then
		local var15 = tbl2.toolHint
		var15.Text = if var11 then "Tap MELT to toggle" else "Hold MELT, drag to aim"
		return
	end

	if var10 then
		local var16 = tbl2.toolHint
		var16.Text = if var11 then "Pull the trigger to toggle" else "Hold the trigger to melt"
		return
	end

	local var17 = tbl2.toolHint
	var17.Text = if var11 then "Click to toggle melting" else "Hold click to melt"
end

local function refreshGrenades()
	local var2 = str4.grenades()
	if 0 < var2 then
		bool4 = true
	end

	local var4 = str4.productsAvailable()
	local var5 = tbl2.grenadeChip
	local bool2 = true
	if 0 >= var2 then
		bool2 = bool4
		if not bool2 then
			bool2 = true
			if var4.FireGrenade ~= true then
				bool2 = var4.FireGrenade5 == true
			end
		end
	end

	var5.Visible = bool2
	var5 = str4.holdingGrenade()
	bool2 = tbl2.grenadeCount
	bool2.Text = if 0 < var2 then "x" .. var2 else var7.Text.NoGrenades
	bool2 = tbl2.grenadeCount
	bool2.TextColor3 = if 0 < var2 then var8.Colors.Text else var8.Colors.SubText
	if var2 == 0 then
		tbl2.grenadeHint.Text = "In the Tool Shed"
	elseif var5 then
		bool2 = tbl2.grenadeHint
		local var6
		if var9.Controls.isTouch() then
			var6 = var7.Text.ThrowHintTouch
		else
			var6 = if var9.Controls.isGamepad() then var7.Text.ThrowHintGamepad else var7.Text.ThrowHintKeyboard
		end

		bool2.Text = var6
	else
		bool2 = tbl2.grenadeHint
		if var9.Controls.isTouch() then
			var6 = "Tap to hold one"
		elseif var9.Controls.isGamepad() then
			var6 = "Shoulder buttons to hold one"
		else
			var6 = "Press G to hold one"
		end

		bool2.Text = var6
	end

	bool2 = tbl2.grenadeStroke
	bool2.Color = if var5 then var20.Orange else var8.Colors.PanelEdge
	bool2 = tbl2.grenadeStroke
	bool2.Thickness = if var5 then 4 else 2
end

local function refreshClass()
	local var1 = str4.playerAttr("ClassStatus")
	local var2 = str4.playerAttr("RunClass")
	local var3 = str4.playerAttr("ProfileClass")
	local var6 = str4.perks()
	tbl2.perks = var6
	local bool1 = false
	if typeof(var1) == "string" then
		bool1 = var1 ~= "Off"
	end

	tbl2.classChip.Visible = bool1
	if bool1 then
		local var8
		if typeof(var2) == "string" and var4.ById[var2] then
			var8 = var2
		else
			var8 = if typeof(var3) == "string" and var4.ById[var3] then var3 else var4.StarterId
		end

		if var31 ~= var8 then
			var31 = var8
			tbl2.classIcon:ClearAllChildren()
			local tbl1 = { Size = UDim2.fromScale(1, 1) }
			tbl1.Parent = tbl2.classIcon
			var5.build(var8, tbl1)
		end

		tbl2.className.Text = var4.ById[var8].Name
		if var1 == "Loading" then
			tbl2.classSub.Text = "Loading\226\128\166"
		elseif var1 == "Unavailable" or var1 == "Outdated" then
			tbl2.classSub.Text = "No perks yet"
		else
			if not var4.ById[var2 or ""] then
				tbl2.classSub.Text = "From the run's start"
			else
				tbl2.classSub.Text = var7.Text.ClassTitle
			end
		end
	end

	tbl2.teamPill.Visible = var6.team
	if var6.team then
		var8 = tbl2.teamLabel
		local var9 = if 100 < var6.amp then var7.Text.TeamPerks .. "  \194\183  " .. string.format(var7.Text.TeamBonus, var6.amp - 100) else var7.Text.TeamPerks
		var8.Text = var9
	end
end

local function refreshKeycaps()
	local var1 = var9.Controls.isGamepad()
	for k1, v1 in ipairs(tbl5) do
		if var1 then
			local var3 = var9.Controls.imageForKey(v1.gamepadKey)
			v1.cap.Visible = var3 ~= nil
			v1.glyph.Visible = var3 ~= nil
			v1.label.Visible = false
			if not var3 then
				continue
			end

			v1.glyph.Image = var3
			v1.cap.Size = UDim2.fromOffset(30, 26)
		else
			local var4 = var9.Controls.mode() == var9.Mode.KeyboardMouse
			v1.cap.Visible = var4
			v1.glyph.Visible = false
			v1.label.Visible = true
			v1.cap.Size = UDim2.fromOffset(v1.width, 26)
		end
	end
end

local function updateBattery()
	local var4, var5, var8 = str3.read()
	if 0 < var5 then
		local var9 = math.clamp(var4 / var5, 0, 1)
		var9 = var9 or 0
	end

	local num1 = 0
	tbl2.batteryFill.Size = UDim2.fromScale(num1, 1)
	local var10 = num1 < var33.LowFraction
	tbl2.batteryFill.BackgroundColor3 = var10 and var20.Orange or var20.Teal
	local var12 = if var8 == "full" then 100 else math.min(99, (math.floor(num1 * 100)))
	local var13 = nil
	if var8 == "hold" or var21.Input.wanting and var21.Input.batteryLocked then
		var13 = "Release to recharge"
	elseif var8 == "run" then
		var13 = (if var10 then "Low battery " else "Battery ") .. var12 .. "%"
	elseif var8 == "charge" then
		var13 = "Charging\226\128\166 " .. var12 .. "%"
	else
		var13 = "Battery 100%"
	end

	tbl2.batteryLabel.Text = var13
	tbl2.batteryBolt.Visible = var8 == "run"
	tbl2.batteryIcon.Visible = var8 ~= "run"
	local var15 = tbl2.perks
	local var16 = math.floor((if var15 and var8 == "run" then var6.technicianBonus(var15, var4, var5) else 0) * 100 + 0.5)
	tbl2.technician.Visible = 1 <= var16
	if 1 <= var16 then
		tbl2.technicianLabel.Text = string.format(var7.Text.TechnicianActive, var16)
	end

	tbl7.lowest = math.min(tbl7.lowest, num1)
	if var8 == "run" and (var10 and (not tbl7.lowCued)) then
		tbl7.lowCued = true
		var21.Audio.batteryLow()
		tbl4.hint("release", var7.Text.ReleaseHint, 3)
	else
		if 0.5 <= num1 then
			tbl7.lowCued = false
		end
	end

	if var8 == "full" then
		if tbl7.mode ~= nil then
			if tbl7.mode ~= "full" then
				if tbl7.lowest < var33.ReadyCueBelow then
					var21.Audio.batteryReady()
				end

				tbl7.lowest = 1
			end
		end
	end

	tbl7.mode = var8
end

local function placeMelt()
	local var2 = tbl2.melt
	if not var2 or (not var2.Visible or (not var24)) then
		return
	end

	local var3 = var22.AbsoluteSize
	local var7 = jumpButton()
	local var8 = var3.X - 24
	local var9 = var3.Y - 24
	if var7 then
		var8 = var7.AbsolutePosition.X - 16
		var9 = var7.AbsolutePosition.Y + var7.AbsoluteSize.Y
	end

	local var10 = var2.AbsoluteSize
	if 1 < var10.X then
		for k1, v1 in ipairs(var22:GetChildren()) do
			if v1 == var2 then
				continue
			end

			if not v1:IsA("GuiObject") then
				continue
			end

			if not v1.Visible then
				continue
			end

			if 2 >= v1.AbsoluteSize.X then
				continue
			end

			local var11 = v1.AbsolutePosition
			local var13 = v1.AbsoluteSize
			local bool1 = false
			if var11.X < var8 then
				bool1 = var8 - var10.X < var11.X + var13.X
			end

			if not bool1 then
				continue
			end

			if var9 - var10.Y >= var11.Y + var13.Y then
				continue
			end

			var9 = math.min(var9, var11.Y - 16)
		end

		var9 = math.max(var9, var10.Y + 24)
	end

	local var14 = math.max(var24.Scale, 0.01)
	var2.Position = UDim2.fromOffset(var8 / var14, var9 / var14)
end

local function autoEquip(arg1)
	if arg1 ~= var27 then
		var27 = arg1
		num1 = os.clock() + 20
		bool2 = false
	end

	if not arg1 or (bool2 or num1 <= os.clock()) then
		return
	end

	if str4.heldTool() or str4.holdingGrenade() then
		return
	end

	local var2 = str4.humanoid()
	local var3 = var11.LocalPlayer:FindFirstChildOfClass("Backpack")
	if not var2 or (var2.Health <= 0 or (not var3)) then
		return
	end

	for k1, v1 in ipairs(var3:GetChildren()) do
		if not v1:IsA("Tool") then
			continue
		end

		if not v1:GetAttribute("ToolId") then
			continue
		end

		var2:EquipTool(v1)
		return
	end
end

tbl4.init = function(arg1)
	var21 = arg1
	pcall(function()
		var13:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
	end)

	if var14.KeyboardEnabled then
		pcall(function()
			var13:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false)
		end)

	end

	var14.LastInputTypeChanged:Connect(function(arg1)
		if arg1 == Enum.UserInputType.Keyboard and var14.KeyboardEnabled then
			pcall(function()
				var13:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false)
			end)

		end
	end)

	var22 = var8.screen("FrozenHouseHUD", 5)
	var24 = var8.autoScale(var22)
	buildTop()
	buildCoins()
	buildSettingsButton()
	buildClassChip()
	buildUpgradesButton()
	buildToolChip()
	buildGrenadeChip()
	buildEntranceButton()
	buildBattery()
	buildMelt()
	buildReticle()
	buildMouseHint()
	buildBannerAndToast()
	buildCallout()
	for k1, v1 in ipairs(var15.Regions) do
		str4.onAttr("Region" .. v1.Id .. "Progress", refreshProgress)
		str4.onAttr("Region" .. v1.Id .. "Cleared", refreshProgress)
	end

	local str3 = "Phase"
	for k2, v2 in ipairs({
		"HouseProgress",
		str3,
		"FrontDoorOpen",
		"KeyPiecesFound",
		"BasementKeyFound",
		"BasementOpen",
		"FreezerFound",
		"FreezerReady",
	}) do

		str4.onAttr(v2, refreshProgress)
	end

	for k3, v3 in ipairs(var15.KeyPieces) do
		str4.onAttr("KeyPiece_" .. v3.Id, refreshProgress)
	end

	refreshProgress()
	str4.onPlayerAttr("Coins", refreshCoins, true)
	local str5 = "ToolUpgrades"
	for k4, v4 in ipairs({ "OwnedTools", str5 }) do
		str4.onPlayerAttr(v4, function()
			refreshCoins(str4.coins())
		end)

	end

	str4.onPlayerAttr("EquippedTool", refreshTool, true)
	str4.onPlayerAttr("EquippedTool", tbl4.refreshIdleHints)
	str4.onPlayerAttr("Grenades", tbl4.refreshIdleHints)
	str4.onPlayerAttr("OwnedTools", tbl4.refreshIdleHints)
	str4.onAttr("Phase", tbl4.refreshIdleHints)
	str4.cinematicChanged:Connect(tbl4.refreshIdleHints)
	str4.menuChanged:Connect(tbl4.refreshIdleHints)
	str4.settingsChanged:Connect(refreshTool)
	local str6 = "Holding"
	for k5, v5 in ipairs({ "Grenades", str6 }) do
		str4.onPlayerAttr(v5, refreshGrenades)
	end

	str4.onAttr("ProductsAvailable", refreshGrenades)
	refreshGrenades()
	str4.on("PurchaseDelivered", function(arg1)
		local var2 = str1.grenadeCount(str1.ByKey[arg1.product])
		if 1 < var2 then
			local var3 = tonumber(arg1.grenades)
			tbl4.toast(string.format(var7.Text.GrenadesAdded, var2, var3 or str4.grenades()), 3)
			return
		end

		if var2 == 1 then
			local var4 = tonumber(arg1.grenades)
			tbl4.toast(string.format(var7.Text.GrenadeAdded, var4 or str4.grenades()), 3)
			return
		end

		if arg1.product == "Flamethrower" then
			tbl4.banner(var7.Text.FlamethrowerUnlocked)
			return
		end

		if 1 < str1.batteryMultiplier(str1.ByKey[arg1.product]) then
			tbl4.banner(var7.Text.BatteryPackFitted)
		end
	end)

	str4.on("PurchaseRecovered", function(arg1)
		local var2 = str1.ByKey[arg1.product]
		if var2 then
			tbl4.toast(string.format(var7.Text.PurchaseRecovered, var2.Name), 4)
		end
	end)

	str4.on("PurchasePending", function(arg1)
		local var2 = str1.ByKey[arg1.product]
		if var2 then
			tbl4.toast(string.format(var7.Text.PurchasePending, var2.Name), 4.5)
		end
	end)

	str4.on("RunItemsExpired", function()
		tbl4.toast(var7.Text.RunItemsExpired, 3.5)
	end)

	local str7 = "ProfileClass"
	local function classChanged()
		refreshClass()
		refreshCoins(str4.coins())
	end

	for k6, v6 in ipairs({ "RunClass", str7, "ClassStatus" }) do
		str4.onPlayerAttr(v6, classChanged)
	end

	str4.onAttr("GodlyCount", classChanged)
	refreshClass()
	local var1 = nil
	str4.firingChanged:Connect(function(arg1)
		if arg1 then
			var1 = os.clock()
			tbl4.hint("battery", var7.Text.BatteryHint, 3)
			return
		end

		if var1 and 3 <= os.clock() - var1 then
			tbl4.hint("release", var7.Text.ReleaseHint, 3)
		end

		var1 = nil
	end)

	str4.batteryCue:Connect(function()
		tbl4.hint("release", var7.Text.ReleaseHint, 3)
	end)

	str4.on("RegionCleared", function(arg1)
		local var4 = var15.RegionById[arg1.region]
		if var4 then
			local var5 = var7.Text.RoomCleared
			local var6 = var4.Name
			tbl4.banner(string.format(var5, var6))
		end
	end)

	str4.on("KeyPieceFound", function(arg1)
		local var1 = tonumber(arg1.total)
		var1 = var1 or (#var15.KeyPieces)
		local var3 = tonumber(arg1.count) or 0
		local var4 = tbl4.banner
		var4(if var1 <= var3 then var7.Text.KeyComplete else string.format(var7.Text.KeyPieceFound, var3, var1))
		var4 = false
		if typeof(arg1.by) == "number" then
			var4 = var11:GetPlayerByUserId(arg1.by)
		end

		if var4 and var4 ~= var11.LocalPlayer then
			tbl4.toast(string.format(var7.Text.KeyPieceFoundBy, var4.DisplayName), 3)
		end
	end)

	str4.on("BasementOpen", function()
		tbl4.banner(var7.Text.BasementOpen)
	end)

	str4.on("FreezerFound", function()
		tbl4.banner(var7.Text.FreezerFound)
	end)

	str4.on("FreezerReady", function()
		tbl4.banner(var7.Text.QuestTurnOff)
	end)

	str4.on("LobbyFailed", function(arg1)
		tbl4.toast(({
			studio = "Returning to the lobby only works in the live game.",
			unconfigured = "The lobby isn't set up yet.",
			failed = "Couldn't reach the lobby. Please try again.",
		})[arg1.reason] or "Couldn't reach the lobby. Please try again.", 3.5)
	end)

	str4.on("LobbyTeleporting", function()
		tbl4.toast("Heading back to the lobby\226\128\166", 4)
	end)

	refreshKeycaps()
	var9.Controls.changed:Connect(function()
		refreshKeycaps()
		tbl4.refreshIdleHints()
	end)

	local str8 = "PreviousTool"
	var10:BindAction("FrozenHousePreviousTool", function(_, arg2)
		if arg2 == Enum.UserInputState.Begin then
			var21.ToolCycle.previous()
		end

		return Enum.ContextActionResult.Sink
	end, false, var9.Controls.key(str8))

	str8 = "NextTool"
	var10:BindAction("FrozenHouseNextTool", function(_, arg2)
		if arg2 == Enum.UserInputState.Begin then
			var21.ToolCycle.next()
		end

		return Enum.ContextActionResult.Sink
	end, false, var9.Controls.key(str8))

	var14.InputBegan:Connect(function(arg1, arg2)
		if arg2 or (str4.cinematic or var14:GetFocusedTextBox()) then
			return
		end

		local var2 = arg1.KeyCode
		local var3 = str4.menuOpen
		if var2 == Enum.KeyCode.One then
			tbl4.toggleEquip()
			return
		end

		if (var2 == var7.Keys.Upgrades or var2 == var9.Controls.key("OpenMenu")) and (var3 == nil or var3 == "Manual") then
			var21.Manual.toggle()
			return
		end

		if var2 == var7.Keys.Settings and (var3 == nil or var3 == "Settings") then
			var21.Audio.play("UITick", 0.05)
			var21.SettingsPanel.toggle()
			return
		end

		if var2 == var7.Keys.FindIce and var3 == nil then
			var23()
			return
		end

		if var2 == var7.Keys.ClassInfo and (var3 == nil or var3 == "ClassInfo") then
			var21.ClassInfo.toggle()
			return
		end

		if (var2 == var7.Keys.ReturnToEntrance or var2 == var7.Keys.ReturnToEntranceGamepad) and var3 == nil then
			var21.Audio.play("UITick", 0.05)
			str2.get("RequestEntrance"):FireServer()
		end
	end)

	local num1 = 0
	var12.RenderStepped:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		var1 = str4.heldTool() ~= nil
		local var2 = var1
		var2 = var2 and var21.Input.iceInReach
		local var3 = tbl2.reticle
		local bool2 = false
		if str4.menuOpen == nil then
			bool2 = not str4.cinematic
			bool2 = bool2 and (not str4.freeCursor)
		end

		var3.Visible = bool2
		tbl2.reticleRing.Visible = var1
		tbl2.reticleStroke.Color = var2 and var20.Orange or var20.White
		var3 = tbl2.reticleStroke
		var3.Thickness = if var2 then 4 else 3
		var3 = if var21.Input.firing then 1.2 else 1
		tbl2.reticleRing.Size = UDim2.fromScale(var3, var3)
		tbl2.reticleDot.BackgroundColor3 = var1 and var20.Orange or var20.White
		updateBattery()
		if 0.2 <= num1 then
			num1 = 0
			if tbl2.entrance then
				bool2 = tbl2.entrance
				local bool5 = false
				if str4.phase() == "Running" then
					bool5 = not str4.cinematic
				end

				bool2.Visible = bool5
			end

			placeMelt()
			bool2 = str4.character()
			autoEquip(bool2)
			local var4 = bool2
			var4 = var4 and bool2:FindFirstChild("HumanoidRootPart")
			local var6 = var4 and var15.regionAt(var4.Position) or nil
			if var6 ~= var29 then
				var29 = var6
				refreshProgress()
			end

			local bool7 = false
			if str4.menuOpen == nil then
				bool7 = not str4.cinematic
			end

			tbl4.callout(var4 and (bool7 and var18.callout(var4.Position)) or nil)
			refreshTool()
			refreshGrenades()
			local var7 = str4.holdingGrenade()
			tbl2.melt.Visible = var14.TouchEnabled and var1
			local var8 = tbl2.melt
			var8.Text = if var7 then "THROW" else "MELT"
			tbl2.battery.Visible = not var7
			local var10 = var9.Controls.mode() == var9.Mode.KeyboardMouse
			tbl2.mouseHint.Visible = var10 and (not str4.freeCursor)
		end
	end)
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Helper [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse").Config)
local num1 = 0
local var2 = nil
local var3 = var1.Palette
local var4 = require(script.Parent.UIKit)
local var5 = require(script.Parent.ClientState)
local function patches(arg1)
	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in ipairs(arg1) do
		local var1 = v1.center
		local var2 = string.format("%d,%d,%d", math.floor(var1.X / 8), math.floor(var1.Y / 7), (math.floor(var1.Z / 8)))
		local var4 = tbl1[var2]
		if not var4 then
			var4 = { sum = Vector3.new(0, 0, 0), count = 0, min = v1.min, max = v1.max }
			tbl1[var2] = var4
			table.insert(tbl2, var4)
		end

		local var5 = var4.sum + v1.center * v1.count
		var4.sum = var5
		var5 = var4.count + v1.count
		var4.count = var5
		var5 = var4.min:Min(v1.min)
		var4.min = var5
		var5 = var4.max:Max(v1.max)
		var4.max = var5
	end

	for k2, v2 in ipairs(tbl2) do
		v2.center = v2.sum / v2.count
	end

	return tbl2
end

local var6 = require(script.Parent.IceWorld)
local var7 = nil
local function markPatch(arg1)
	local var1 = Instance.new("Part")
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.CFrame = CFrame.new(arg1.center)
	var1.Parent = var2
	local var5 = Instance.new("SphereHandleAdornment")
	var5.Adornee = var1
	var5.Radius = math.clamp((arg1.max - arg1.min).Magnitude / 2 + 0.8, 1, 6)
	var5.Color3 = var3.Orange
	var5.Transparency = 0.6
	var5.AlwaysOnTop = true
	var5.ZIndex = 2
	var5.Parent = var1
	local var6 = Instance.new("BillboardGui")
	var6.Size = UDim2.fromOffset(70, 70)
	var6.AlwaysOnTop = true
	var6.MaxDistance = 250
	var6.StudsOffsetWorldSpace = Vector3.new(0, 3, 0)
	var6.Parent = var1
	local var7 = Instance.new("Frame")
	var7.BackgroundColor3 = var3.DeepBlue
	var7.Size = UDim2.fromScale(1, 0.72)
	var7.Parent = var6
	var4.corner(20).Parent = var7
	local tbl1 = {
		Text = "ICE",
		TextScaled = true,
		TextColor3 = var3.White,
		FontFace = var4.Fonts.Display,
		Size = UDim2.fromScale(1, 1),
	}

	tbl1.Parent = var7
	var4.label(tbl1)
	tbl1 = {
		Name = "Distance",
		Text = "",
		TextScaled = true,
		FontFace = var4.Fonts.Display,
		TextColor3 = var3.White,
		TextStrokeColor3 = var3.Text,
		TextStrokeTransparency = 0,
		Position = UDim2.fromScale(0, 0.72),
	}

	tbl1.Size = UDim2.fromScale(1, 0.28)
	tbl1.Parent = var6
	local var8 = var4.label(tbl1)
	return var1, var8
end

local var8 = game:GetService("PathfindingService")
local function trail(arg1)
	for k1, v1 in ipairs(arg1) do
		if 1 >= k1 then
			continue
		end

		if k1 % 2 ~= 0 then
			continue
		end

		local var1 = Instance.new("Part")
		var1.Shape = Enum.PartType.Ball
		var1.Anchored = true
		var1.CanCollide = false
		var1.CanQuery = false
		var1.CanTouch = false
		var1.CastShadow = false
		var1.Material = Enum.Material.Neon
		var1.Color = var3.Orange
		var1.Transparency = 0.15
		var1.Size = Vector3.new(0.7, 0.7, 0.7)
		var1.CFrame = CFrame.new(v1.Position + Vector3.new(0, 0.6, 0))
		var1.Parent = var2
	end
end

local var9 = game:GetService("RunService")
local var10 = game:GetService("Players")
local function clear()
	local var1 = num1 + 1
	num1 = var1
	if var2 then
		var2:ClearAllChildren()
	end
end

return {
	activate = function(arg1)
		local var3 = num1 + 1
		num1 = var3
		if var2 then
			var2:ClearAllChildren()
		end

		local var4 = var5.character()
		local var10 = var4
		var10 = var10 and var4:FindFirstChild("HumanoidRootPart")
		var3 = num1
		if not var10 then
			return
		end

		local var11 = arg1
		local var12 = patches(var6.remainingClusters(var11))
		if #var12 == 0 then
			var7.HUD.toast("No ice left here!", 2)
			return
		end

		table.sort(var12, function(arg1, arg2)
			return (arg1.center - var10.Position).Magnitude < (arg2.center - var10.Position).Magnitude
		end)

		local tbl1 = {}
		for i1 = 1, math.min(#var12, var1.Helper.MaxMarkers) do
			local var13 = var12[i1]
			local var14, var15 = markPatch(var13)
			tbl1[var13] = { anchor = var14, label = var15 }
		end

		var11 = var7.HUD.toast
		local var16 = string.format
		local str1 = "%d patch%s of ice left"
		local var17 = #var12
		var16 = var16(str1, var17, if #var12 == 1 then "" else "es")
		var11(var16, 2.5)
		task.spawn(function()
			local var1 = nil
			for i1 = 1, math.min(3, #var12) do
				local var2 = var8:CreatePath({ AgentRadius = 1.6, AgentHeight = 5, AgentCanJump = true, WaypointSpacing = 3 })
				local var4 = pcall(function()
					var2:ComputeAsync(var10.Position, var12[i1].center)
				end)

				if num1 ~= var3 then
					return
				end

				if not var4 then
					continue
				end

				if var2.Status == Enum.PathStatus.Success or var2.Status == Enum.PathStatus.ClosestNoPath then
					local var6 = var2:GetWaypoints()
					local num2 = 0
					for i2 = 2, #var6 do
						num2 = num2 + (var6[i2].Position - var6[i2 - 1].Position).Magnitude
					end

					if not var1 or num2 < var1.length then
						var1 = { length = num2, waypoints = var6 }
					end
				end
			end

			if var1 and num1 == var3 then
				trail(var1.waypoints)
			end
		end)

		str1 = nil
		var17 = nil
		var16 = true
		var17 = var6.changed:Connect(function()
			var16 = true
		end)

		var11 = os.clock()
		var9.Heartbeat:Connect(function()
			if num1 ~= var3 then
				str1:Disconnect()
				var17:Disconnect()
				return
			end

			local var4 = var5.character()
			var4 = var4 and var5.character():FindFirstChild("HumanoidRootPart")
			local num2 = 0
			for k1, v1 in pairs(tbl1) do
				if var16 and (not var6.requiredIceIn(k1.min, k1.max, arg1)) then
					v1.anchor:Destroy()
					tbl1[k1] = nil
				else
					if not var4 then
						continue
					end

					if not v1.label.Parent then
						continue
					end

					v1.label.Text = string.format("%dm", (math.floor((k1.center - var4.Position).Magnitude / 3.5)))
					num2 = num2 + 1
				end
			end

			var16 = false
			if num2 == 0 or var1.Helper.ShowSeconds < os.clock() - var11 then
				str1:Disconnect()
				var17:Disconnect()
				local var7 = num1 + 1
				num1 = var7
				if var2 then
					var2:ClearAllChildren()
				end
			end
		end)
	end,
	init = function(arg1)
		var7 = arg1
		var2 = Instance.new("Folder")
		var2.Name = "FrozenHouseHelper"
		var2.Parent = workspace
		var10.LocalPlayer.CharacterAdded:Connect(clear)
	end,
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Input [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = game:GetService("Players")
local var3 = game:GetService("RunService")
local var4 = game:GetService("UserInputService")
local var5 = require(var1.Config)
local var6 = require(var1.Net)
local var7 = require(script.Parent.Battery)
local var8 = require(script.Parent.ClientState)
local var9 = require(script.Parent.IceWorld)
local tbl1 = {
	firing = false,
	wanting = false,
	batteryLocked = false,
	aimTarget = nil,
	impact = nil,
	iceInReach = false,
	onThrow = nil,
	computeAim = function()
		local var1 = workspace.CurrentCamera.CFrame
		local var4, var5 = var9.raycast(var1.Position, var1.LookVector, 500)
		if var4 then
			return var4.position
		end

		return var5 and var5.Position or var1.Position + var1.LookVector * 500
	end,
}

local num1 = -math.huge
local num2 = 0
local bool1 = false
local tbl2 = {}
local function refresh()
	local var3 = var8.canPlay()
	if var3 then
		var3 = false
		if var8.menuOpen == nil then
			var3 = not var8.freeCursor
			if var3 then
				var3 = not var8.cinematic
				if var3 then
					var3 = false
					if var8.heldMelter() ~= nil then
						local var13 = var8.humanoid()
						var3 = false
						if var13 ~= nil then
							var3 = 0 < var13.Health
						end
					end
				end
			end
		end
	end

	if not var3 then
		bool1 = false
	end

	local var16 = var8.canPlay()
	var3 = false
	if var16 then
		var16 = false
		if var8.menuOpen == nil then
			var16 = not var8.freeCursor
			if var16 then
				var16 = not var8.cinematic
				if var16 then
					var16 = false
					if var8.heldMelter() ~= nil then
						local var22 = var8.humanoid()
						var16 = false
						if var22 ~= nil then
							var16 = 0 < var22.Health
						end
					end
				end
			end
		end
	end

	if var16 then
		if var8.settings.ToggleMelting then
			var3 = bool1
		else
			var3 = next(tbl2) ~= nil
		end
	end

	if not var3 then
		tbl1.batteryLocked = false
	if tbl1.firing ~= false then
			tbl1.firing = false
			var8.firing = false
			tbl1.impact = nil
			var8.firingChanged:Fire(false)
		end

	if tbl1.wanting ~= false then
			tbl1.wanting = false
			var6.get("MeltState"):FireServer(false)
		end

		var7.noteLocal("charge")
		return
	end

	if not tbl1.wanting and (not tbl1.batteryLocked and var7.energy() < var5.Battery.RestartEnergy) then
		var8.batteryCue:Fire("refused")
		if var8.settings.ToggleMelting then
			bool1 = false
			tbl1.batteryLocked = false
		else
			tbl1.batteryLocked = true
		end

		if var8.settings.ToggleMelting then
			return refresh()
		end
	end

	if tbl1.wanting ~= true then
		tbl1.wanting = true
		num1 = workspace:GetServerTimeNow()
		var16 = tbl1.computeAim()
		tbl1.aimTarget = var16
		var6.get("MeltState"):FireServer(true, var16)
		num2 = os.clock()
	end

	var16 = not tbl1.batteryLocked
	if tbl1.firing ~= var16 then
		tbl1.firing = var16
		var8.firing = var16
		if not var16 then
			tbl1.impact = nil
		end

		var8.firingChanged:Fire(var16)
	end

	var16 = var7.noteLocal
	var16(if tbl1.batteryLocked then "hold" else "run")
end

tbl1.refresh = refresh
tbl1.touchPress = function()
	if var8.settings.ToggleMelting then
		local var4 = var8.canPlay()
		if var4 then
			var4 = false
			if var8.menuOpen == nil then
				var4 = not var8.freeCursor
				if var4 then
					var4 = not var8.cinematic
					if var4 then
						var4 = false
						if var8.heldMelter() ~= nil then
							local var11 = var8.humanoid()
							var4 = false
							if var11 ~= nil then
								var4 = 0 < var11.Health
							end
						end
					end
				end
			end
		end

		if var4 then
			var4 = not bool1
			bool1 = var4
		end
	else
		tbl2.touch = true
	end

	refresh()
end

tbl1.touchRelease = function()
	tbl2.touch = nil
	refresh()
end

local bool2 = false
tbl1._press = function(arg1)
	assert(var3:IsStudio(), "Input._press is a Studio testing seam")
	if var8.settings.ToggleMelting then
		local var5 = var8.canPlay()
		local var6 = arg1 or "gamepad"
		if var5 then
			var5 = false
			if var8.menuOpen == nil then
				var5 = not var8.freeCursor
				if var5 then
					var5 = not var8.cinematic
					if var5 then
						var5 = false
						if var8.heldMelter() ~= nil then
							local var13 = var8.humanoid()
							var5 = false
							if var13 ~= nil then
								var5 = 0 < var13.Health
							end
						end
					end
				end
			end
		end

		if var5 then
			var5 = not bool1
			bool1 = var5
		end
	else
		tbl2[var6] = true
	end

	refresh()
end

tbl1._release = function(arg1)
	assert(var3:IsStudio(), "Input._release is a Studio testing seam")
	tbl2[arg1 or "gamepad"] = nil
	refresh()
end

tbl1._held = function(arg1)
	return tbl2[arg1 or "gamepad"] == true
end

local num3 = -math.huge
local function onCharacter(arg1)
	table.clear(tbl2)
	bool1 = false
	refresh()
	arg1.ChildRemoved:Connect(function(arg1)
		if arg1:IsA("Tool") then
			bool1 = false
			refresh()
		end
	end)

	arg1.ChildAdded:Connect(function(arg1)
		if arg1:IsA("Tool") then
			refresh()
		end
	end)

	local var2 = arg1:WaitForChild("Humanoid", 10)
	if var2 then
		var2.Died:Connect(function()
			table.clear(tbl2)
			bool1 = false
			refresh()
		end)

	end
end

local function step()
	if tbl1.wanting then
		local var4 = var8.canPlay()
		if var4 then
			var4 = false
			if var8.menuOpen == nil then
				var4 = not var8.freeCursor
				if var4 then
					var4 = not var8.cinematic
					if var4 then
						var4 = false
						if var8.heldMelter() ~= nil then
							local var15 = var8.humanoid()
							var4 = false
							if var15 ~= nil then
								var4 = 0 < var15.Health
							end
						end
					end
				end
			end
		end

		if not var4 then
			refresh()
		end
	end

	if tbl1.firing then
		local var18 = var7.state()
		local bool6 = false
		if var18 ~= nil then
			bool6 = false
			if var18.mode == "hold" then
				bool6 = num1 < var18.at
			end
		end

		if var7.energy() <= 0 or bool6 then
			var8.batteryCue:Fire("empty")
			if var8.settings.ToggleMelting then
				bool1 = false
				tbl1.batteryLocked = false
			else
				tbl1.batteryLocked = true
			end

			refresh()
		end
	end

	local var19 = var8.character()
	local var20 = var19
	var20 = var20 and var19:FindFirstChild("Head")
	if not var20 or (not var8.heldMelter() or var8.cinematic) then
		tbl1.iceInReach = false
		tbl1.impact = nil
		return
	end

	local var21 = tbl1.computeAim()
	local var22 = var21 - var20.Position
	local var23 = var8.toolDef().Range + var5.Firing.RangeTolerance
	local var24 = nil
	if 0.05 < var22.Magnitude then
		var24 = var9.raycast(var20.Position, var22.Unit, (math.min(var22.Magnitude + 0.75, var23)))
	end

	tbl1.iceInReach = var24 ~= nil
	if tbl1.wanting then
		tbl1.aimTarget = var21
		local var25 = os.clock()
		if 1 / var5.Firing.AimSendHz <= var25 - num2 then
			num2 = var25
			var6.get("MeltAim"):FireServer(var21)
		end
	end

	if not tbl1.firing then
		tbl1.impact = nil
		return
	end

	local var26 = tbl1
	if var24 then
		local tbl2 = { position = var24.position, normal = var24.normal, iceId = var24.fieldId }
		tbl2 = tbl2 or nil
	end

	var26.impact = nil
	if var24 and (not bool2) then
		bool2 = true
		var8.localMelt:Fire()
	end
end

tbl1.init = function()
	var4.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
			if not not var8.freeCursor then
				return
			end

			if 0.3 >= os.clock() - num3 then
				return
			end

			if var8.holdingGrenade() then
				if not tbl1.onThrow then
					return
				end

				tbl1.onThrow()
				return
			end

			if var8.settings.ToggleMelting then
				local var4 = var8.canPlay()
				if var4 then
					var4 = false
					if var8.menuOpen == nil then
						var4 = not var8.freeCursor
						if var4 then
							var4 = not var8.cinematic
							if var4 then
								var4 = false
								if var8.heldMelter() ~= nil then
									local var11 = var8.humanoid()
									var4 = false
									if var11 ~= nil then
										var4 = 0 < var11.Health
									end
								end
							end
						end
					end
				end

				if var4 then
					var4 = not bool1
					bool1 = var4
				end
			else
				tbl2.mouse = true
			end

			refresh()
			return
		end

		if arg1.KeyCode == Enum.KeyCode.ButtonR2 then
			if var8.holdingGrenade() then
				if not tbl1.onThrow then
					return
				end

				tbl1.onThrow()
				return
			end

			if var8.settings.ToggleMelting then
				local var15 = var8.canPlay()
				if var15 then
					var15 = false
					if var8.menuOpen == nil then
						var15 = not var8.freeCursor
						if var15 then
							var15 = not var8.cinematic
							if var15 then
								var15 = false
								if var8.heldMelter() ~= nil then
									local var21 = var8.humanoid()
									var15 = false
									if var21 ~= nil then
										var15 = 0 < var21.Health
									end
								end
							end
						end
					end
				end

				if var15 then
					var15 = not bool1
					bool1 = var15
				end
			else
				tbl2.gamepad = true
			end

			refresh()
		end
	end)

	var4.InputEnded:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
			tbl2.mouse = nil
			refresh()
			return
		end

		if arg1.KeyCode == Enum.KeyCode.ButtonR2 then
			tbl2.gamepad = nil
			refresh()
		end
	end)

	var4.WindowFocusReleased:Connect(function()
		table.clear(tbl2)
		refresh()
	end)

	var8.menuChanged:Connect(function(arg1)
		if arg1 == nil then
			num3 = os.clock()
		end

		table.clear(tbl2)
		bool1 = false
		refresh()
	end)

	local function letGo()
		table.clear(tbl2)
		bool1 = false
		refresh()
	end

	var8.cursorChanged:Connect(letGo)
	var8.cinematicChanged:Connect(letGo)
	var4.GamepadDisconnected:Connect(letGo)
	var8.onAttr("Phase", refresh)
	var8.settingsChanged:Connect(function(arg1)
		if arg1 == "ToggleMelting" then
			table.clear(tbl2)
			bool1 = false
			refresh()
		end
	end)

	var8.on("LobbyTeleporting", function()
		table.clear(tbl2)
		bool1 = false
		refresh()
	end)

	local var1 = var2.LocalPlayer
	var1.CharacterAdded:Connect(onCharacter)
	var1.CharacterRemoving:Connect(function()
		table.clear(tbl2)
		bool1 = false
		refresh()
	end)

	if var1.Character then
		task.spawn(onCharacter, var1.Character)
	end

	var3.RenderStepped:Connect(step)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.SettingsPanel [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = require(var1.Config)
local var3 = require(script.Parent.UIKit)
local var4 = var3.new
local var5 = nil
local function row(arg1, arg2, arg3)
	local tbl1 = { Name = arg1, BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, arg3 or 58) }
	tbl1.LayoutOrder = arg2
	tbl1.Parent = var5
	local str1 = "Frame"
	return var4(str1, tbl1)
end

local var6 = var2.Palette
local var7 = require(script.Parent.ClientState)
local var8 = nil
local tbl1 = {}
local var9 = nil
local var10 = require(script.Parent.Focus)
local tbl2 = {}
local var11 = game:GetService("UserInputService")
local var12 = require(var1.Net)
tbl2.open = function()
	if var7.menuOpen and var7.menuOpen ~= "Settings" then
		return
	end

	var9.Visible = true
	var7.setMenu("Settings")
	local tbl1 = { root = var9, hints = var10.basic(var2.Text.HintClose), lockControls = false }
	tbl1.initial = function()
		local str1 = "TextButton"
		return var5.MusicVolume:FindFirstChildWhichIsA(str1)
	end

	tbl1.back = tbl2.close
	var10.open("FrozenHouseSettings", tbl1)
end

tbl2.close = function()
	if not var9.Visible then
		return
	end

	var9.Visible = false
	if var7.menuOpen == "Settings" then
		var7.setMenu(nil)
	end

	var10.close("FrozenHouseSettings")
end

tbl2.toggle = function()
	if var9.Visible then
		tbl2.close()
		return
	end

	tbl2.open()
end

local var13 = nil
local function volumeRow(arg1, arg2, arg3)
	local var1 = row(arg1, arg3)
	local tbl2 = {
		Text = arg2,
		FontFace = var3.Fonts.Bold,
		TextSize = 20,
		TextXAlignment = Enum.TextXAlignment.Left,
		Size = UDim2.new(0, 170, 1, 0),
	}

	tbl2.Parent = var1
	var3.label(tbl2)
	tbl2 = { Text = "-", TextSize = 30, Secondary = true, Size = UDim2.fromOffset(48, 48) }
	tbl2.Position = UDim2.new(0, 172, 0.5, -24)
	tbl2.Parent = var1
	local var2 = var3.button(tbl2)
	local tbl3 = { Size = UDim2.fromOffset(110, 16) }
	tbl3.Position = UDim2.new(0, 230, 0.5, -8)
	tbl3.Color = var6.Teal
	tbl3.Parent = var1
	tbl2 = var3.progressBar(tbl3)
	local tbl4 = { Text = "", FontFace = var3.Fonts.Bold, TextSize = 17, Size = UDim2.fromOffset(110, 20) }
	tbl4.Position = UDim2.new(0, 230, 0.5, 8)
	tbl4.Parent = var1
	tbl3 = var3.label(tbl4)
	local tbl5 = { Text = "+", TextSize = 26, Secondary = true, Size = UDim2.fromOffset(48, 48) }
	tbl5.Position = UDim2.new(0, 350, 0.5, -24)
	tbl5.Parent = var1
	tbl4 = var3.button(tbl5)
	var2.Activated:Connect(function()
		var7.setSetting(arg1, (math.clamp(math.floor((var7.settings[arg1] + -0.1) * 10 + 0.5) / 10, 0, 1)))
		var8.Audio.play("UITick", 0.03)
	end)

	tbl4.Activated:Connect(function()
		var7.setSetting(arg1, (math.clamp(math.floor((var7.settings[arg1] + 0.1) * 10 + 0.5) / 10, 0, 1)))
		var8.Audio.play("UITick", 0.03)
	end)

	tbl1[arg1] = function()
		local var1 = var7.settings[arg1]
		tbl2.set(var1, true)
		tbl3.Text = string.format("%d%%", (math.floor(var1 * 100 + 0.5)))
	end

	local var4 = var7.settings[arg1]
	tbl2.set(var4, true)
	tbl3.Text = string.format("%d%%", (math.floor(var4 * 100 + 0.5)))
	return var2
end

local function toggleRow(arg1, arg2, arg3, arg4, arg5)
	local var1 = row(arg1, arg5)
	local tbl2 = {
		Text = arg2,
		FontFace = var3.Fonts.Bold,
		TextSize = 20,
		TextXAlignment = Enum.TextXAlignment.Left,
		Size = UDim2.new(0, 220, 1, 0),
	}

	tbl2.Parent = var1
	var3.label(tbl2)
	tbl2 = { Text = "", TextSize = 20, Size = UDim2.fromOffset(170, 48) }
	tbl2.Position = UDim2.new(1, -170, 0.5, -24)
	tbl2.Parent = var1
	local var2 = var3.button(tbl2)
	var2.Activated:Connect(function()
		var7.setSetting(arg1, not var7.settings[arg1])
		var8.Audio.play("UITick", 0.03)
	end)

	tbl1[arg1] = function()
		local var1 = var7.settings[arg1]
		var2.Text = var1 and arg3 or arg4
		local var4 = var3.setButtonStyle
		local var5 = var2
		var4(var5, if var1 then "done" else "secondary")
	end

	local var4 = var7.settings[arg1]
	var2.Text = var4 and arg3 or arg4
	local var5 = var3.setButtonStyle
	local var6 = var2
	var5(var6, if var4 then "done" else "secondary")
end

tbl2.init = function(arg1)
	var8 = arg1
	var13 = var3.screen("FrozenHouseSettings", 21)
	var3.autoScale(var13)
	local tbl3 = {
		Name = "Root",
		BackgroundTransparency = 1,
		Size = UDim2.fromScale(1, 1),
		Visible = false,
	}

	tbl3.Parent = var13
	var9 = var4("Frame", tbl3)
	var3.backdrop({ Name = "Dim", BackgroundTransparency = 0.55, Parent = var9 }).Activated:Connect(tbl2.close)
	tbl3 = { Name = "Panel", AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl3.Position = UDim2.fromScale(0.5, 0.52)
	tbl3.Size = UDim2.fromOffset(460, 540)
	tbl3.Parent = var9
	local var1 = var3.panel(tbl3)
	local tbl4 = {
		Text = "Settings",
		FontFace = var3.Fonts.Display,
		TextSize = 34,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(26, 16),
	}

	tbl4.Size = UDim2.fromOffset(300, 40)
	tbl4.Parent = var1
	var3.label(tbl4)
	tbl4 = {
		Text = "X",
		TextSize = 26,
		Secondary = true,
		AnchorPoint = Vector2.new(1, 0),
		Radius = 26,
	}

	tbl4.Position = UDim2.new(1, -18, 0, 14)
	tbl4.Size = UDim2.fromOffset(52, 52)
	tbl4.Parent = var1
	tbl4.OnClick = tbl2.close
	var3.button(tbl4)
	local tbl5 = { Name = "List", BackgroundTransparency = 1, Position = UDim2.fromOffset(26, 80) }
	tbl5.Size = UDim2.new(1, -52, 1, -96)
	tbl5.Parent = var1
	var5 = var4("Frame", tbl5)
	tbl5 = { Padding = UDim.new(0, 8) }
	tbl5.SortOrder = Enum.SortOrder.LayoutOrder
	tbl5.Parent = var5
	var4("UIListLayout", tbl5)
	volumeRow("MusicVolume", "Music volume", 1)
	volumeRow("EffectsVolume", "Effects volume", 2)
	toggleRow("ReducedEffects", "Reduced effects", "On", "Off", 3)
	toggleRow("ToggleMelting", "Melting control", "Toggle", "Hold", 4)
	tbl3 = row("Actions", 5, 132)
	tbl5 = {
		Name = "Entrance",
		Text = var2.Text.ReturnToEntrance,
		TextSize = 21,
		Secondary = true,
		Size = UDim2.new(1, 0, 0, 56),
	}

	tbl5.Position = UDim2.fromOffset(0, 8)
	tbl5.Parent = tbl3
	tbl5.OnClick = function()
		var8.Audio.play("UITick", 0.05)
		var12.get("RequestEntrance"):FireServer()
		tbl2.close()
	end

	var3.button(tbl5)
	tbl5 = { Name = "Lobby", Text = "Return to Lobby", TextSize = 21, Size = UDim2.new(1, 0, 0, 56) }
	tbl5.Position = UDim2.fromOffset(0, 72)
	tbl5.Parent = tbl3
	tbl5.OnClick = function()
		var8.Audio.play("UITick", 0.05)
		var12.get("RequestLobby"):FireServer()
	end

	var3.button(tbl5)
	tbl5 = {
		Name = "RunNote",
		Text = var2.Text.RunOnly,
		TextSize = 16,
		TextColor3 = var3.Colors.SubText,
		Size = UDim2.new(1, 0, 0, 22),
		LayoutOrder = 6,
	}

	tbl5.Parent = var5
	var3.label(tbl5)
	var7.settingsChanged:Connect(function(arg1)
		if tbl1[arg1] then
			tbl1[arg1]()
		end
	end)

	var11.InputBegan:Connect(function(arg1)
		if var9.Visible and arg1.KeyCode == Enum.KeyCode.Escape then
			tbl2.close()
		end
	end)

	var7.cinematicChanged:Connect(function(arg1)
		if arg1 then
			tbl2.close()
		end
	end)
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Manual [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local str1 = "ClassPerks"
local var3 = require(var1:WaitForChild("MeltShared"):WaitForChild(str1))
local var4 = require(var2.Config)
local var5 = require(script.Parent.UIKit)
local var6 = var4.Palette
local var7 = game:GetService("HttpService")
local var8 = game:GetService("UserInputService")
local var9 = require(var2.Net)
local var10 = require(var2.ToolStats)
local var11 = require(script.Parent.ClientState)
local var12 = require(script.Parent.Icons)
str1 = require(script.Parent.Focus)
local tbl1 = { Cover = var6.DeepBlue, Spine = Color3.fromHex("#2C6388") }
tbl1.Page = Color3.fromHex("#FFF6E6")
tbl1.PageEdge = Color3.fromHex("#E6D1AE")
tbl1.Card = Color3.fromHex("#E7EEF3")
tbl1.CardEdge = Color3.fromHex("#C3D0DA")
tbl1.CardLocked = Color3.fromHex("#CDD5DC")
tbl1.Tile = Color3.fromHex("#FFFFFF")
tbl1.TileLocked = Color3.fromHex("#3B4652")
tbl1.Detail = Color3.fromHex("#E4EEF5")
tbl1.DetailEdge = Color3.fromHex("#B9CCDA")
tbl1.Heading = Color3.fromHex("#2F5F86")
tbl1.Warn = Color3.fromHex("#B8452F")
tbl1.Max = Color3.fromHex("#2F8A82")
local tbl2 = {}
local var13 = nil
local function snapshot()
	local str1 = "ToolUpgrades"
	local var1 = var10.decodeLevels(var11.playerAttr(str1))
	local var2 = var11.ownedTools()
	for k1, v1 in ipairs(var4.Tools) do
		local var5 = tbl2[v1.Id]
		if var5 and var5.owned then
			var2[v1.Id] = true
		end

		local var6 = var1[v1.Id]
		var6 = var6 or var10.defaultLevels()
		local var7
		local var8
		if var5 and var5.levels then
			for k2, v2 in pairs(var5.levels) do
				local var9 = math.max(var6[k2], v2)
				var6[k2] = var9
			end
		end

		var1[v1.Id] = var6
	end

	local tbl1 = { coins = var11.coins() }
	tbl1.owned = var2
	tbl1.levels = var1
	str1 = var11.playerAttr("EquippedTool")
	tbl1.equipped = str1 or var4.StarterToolId
	tbl1.perks = var11.perks()
	return tbl1
end

local tbl3 = {}
local num1 = 0
local var14 = nil
local str2 = "Tools"
local var15 = nil
local function refresh()
	if not var13 then
		return
	end

	local var1 = snapshot()
	for k1, v1 in pairs(tbl3) do
		v1.update(var1)
	end
end

local tbl4 = {
	coins = "Not enough coins yet.",
	unavailable = "The manual opens when the run starts.",
	busy = "One moment\226\128\166",
	stale = "That upgrade already changed.",
	maxed = "That upgrade is already maxed.",
	notOwned = "Find this tool in the Tool Shed first.",
}

local function flash(arg1, arg2)
	local var1 = num1 + 1
	num1 = var1
	var1 = num1
	for k1, v1 in pairs(tbl3) do
		v1.message.Label.Text = arg1
		v1.message.BackgroundColor3 = arg2 and var6.Teal or var6.DeepBlue
		v1.message.GroupTransparency = 0
		v1.message.Visible = true
	end

	task.delay(1.8, function()
		if num1 == var1 then
			for k1, v1 in pairs(tbl3) do
				var5.tween(v1.message, 0.25, { GroupTransparency = 1 })
			end
		end
	end)
end

local var16 = nil
local num2 = 0
local function invoke(arg1, arg2, arg3, arg4)
	local var1 = var7:GenerateGUID(false)
	local function call()
		local var2 = arg1
		local var3 = arg2
		local var4 = arg3
		local var5 = arg4
		local var6 = var1
		return var9.get("Shop"):InvokeServer(var2, var3, var4, var5, var6)
	end

	local success, result = pcall(call)
	if not success then
		task.wait(0.3)
		local success, result = pcall(call)
		success = success
		result = result
	end

	if success and typeof(result) == "table" then
		return result
	end

	return { ok = false, reason = "error" }
end

local function forEachCard(arg1, arg2, arg3)
	for k1, v1 in pairs(tbl3) do
		for k2, v2 in ipairs(v1.cards) do
			if v2.tool ~= arg1 then
				continue
			end

			if arg2 == nil or v2.track == arg2 then
				arg3(v2)
			end
		end
	end
end

local tbl5 = {}
local var17 = var5.new
local var18 = var5.Fonts
local var19 = var4.Upgrades
local function showShed()
	tbl5.close()
	if var15.ToolShed then
		var15.ToolShed.showWay()
	end
end

local function buyUpgrade(arg1, arg2)
	local var2 = snapshot()
	if var16 or (os.clock() < num2 or (not var2.owned[arg1])) then
		return
	end

	local var3 = var2.levels[arg1][arg2]
	local var6 = var10.price(arg1, arg2, var3, var2.perks)
	if not var6 or var2.coins < var6 then
		return
	end

	var16 = arg1 .. ":" .. arg2
	refresh()
	task.spawn(function()
		local var1 = invoke("upgrade", arg1, arg2, var3)
		var16 = nil
		if var1.ok then
			num2 = os.clock() + 0.35
			local var2 = tbl2[arg1]
			var2 = var2 or {}
			local var5 = var2.levels
			var2.levels = var5 or {}
			var2.levels[arg2] = var1.level
			tbl2[arg1] = var2
			refresh()
			forEachCard(arg1, arg2, function(arg1)
				arg1.pop(var1.level)
			end)

			flash(var10.TrackInfo[arg2].Card .. " upgraded!", true)
			return
		end

		local var9 = arg1
		local var11 = tbl4[var1.reason]
		if var1.reason == "requires" then
			local var12 = var4.ToolById[var9]
			local var13 = var12
			var13 = var13 and (var12.Requires and var4.ToolById[var12.Requires])
			local var14 = var13
			var11 = var14 and string.format("Buy the %s first.", var13.Name)
		end

		flash(var11 or "That didn't work. Try again.", false)
		refresh()
	end)
end

local function layoutFrame(arg1, arg2)
	local tbl1 = {
		Name = arg1,
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0.5, 0.5),
		ZIndex = 2,
		Visible = false,
	}

	tbl1.Position = UDim2.fromScale(0.5, 0.5)
	tbl1.Size = UDim2.fromOffset(arg2.X, arg2.Y)
	tbl1.Parent = var13
	local var1 = var17("Frame", tbl1)
	local var2 = var17("UIScale", { Name = "Fit", Parent = var1 })
	local tbl2 = { Name = "Content", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl2.Position = UDim2.fromScale(0.5, 0.5)
	tbl2.Size = UDim2.fromScale(1, 1)
	tbl2.Parent = var1
	tbl1 = var17("Frame", tbl2)
	return var1, var2, tbl1, (var17("UIScale", { Name = "Pop", Parent = tbl1 }))
end

local var20 = Vector2.new(1120, 610)
local function buildHeading(arg1, arg2, arg3)
	local tbl2 = { Name = "Heading", BackgroundTransparency = 1, Size = UDim2.fromOffset(arg3.w, arg3.h) }
	tbl2.Parent = arg1
	local var1 = var17("Frame", tbl2)
	local var2 = arg3.h
	local var3 = arg3.h
	var5.toolPreview(arg2, UDim2.fromOffset(var2, var3)).Parent = var1
	local var7 = var4.ToolById[arg2]
	local tbl3 = {}
	if arg3.showName then
		var2 = { Name = "Name", Text = string.upper(var7.Name), TextWrapped = false }
		var2.FontFace = var18.Display
		var2.TextSize = arg3.name
		var2.TextColor3 = tbl1.Heading
		var2.TextXAlignment = Enum.TextXAlignment.Left
		var2.Position = UDim2.fromOffset(arg3.h + 6, 0)
		tbl2 = arg3.w - arg3.h - arg3.control - 12
		var2.Size = UDim2.new(0, tbl2, 1, 0)
		var2.Parent = var1
		local var8 = var5.label(var2)
		task.spawn(function()
			local var1 = Instance.new("GetTextBoundsParams")
			var1.Text = var8.Text
			var1.Font = var18.Display
			var1.Width = 100000
			for i1 = arg3.name, 14, -1 do
				var1.Size = i1
				local success, result = pcall(function()
					local var2 = var1
					return game:GetService("TextService"):GetTextBoundsAsync(var2)
				end)

				if not success or result.X <= tbl2 then
					var8.TextSize = i1
					return
				end
			end
		end)

	end

	var2 = {
		Name = "Control",
		Text = "",
		TextSize = 17,
		AnchorPoint = Vector2.new(1, 0.5),
		Radius = 14,
	}

	var2.Position = UDim2.fromScale(1, 0.5)
	var2.Size = UDim2.fromOffset(arg3.control, arg3.h - 8)
	var2.Parent = var1
	tbl2 = nil
	var2.OnClick = function()
		if tbl2 then
			tbl2()
		end
	end

	local var9 = var5.button(var2)
	var9.FontFace = var18.Bold
	var3 = {
		Name = "Status",
		FontFace = var18.Bold,
		TextSize = 17,
		BackgroundTransparency = 0,
		AnchorPoint = Vector2.new(1, 0.5),
	}

	var3.Position = UDim2.fromScale(1, 0.5)
	var3.Size = UDim2.fromOffset(arg3.control, arg3.h - 8)
	var3.Parent = var1
	var2 = var5.label(var3)
	var5.corner(14).Parent = var2
	tbl3.update = function(arg1)
		tbl2 = nil
		local var3 = arg1.owned[arg2]
		if var3 and arg1.equipped == arg2 then
			var9.Visible = false
			var2.Visible = true
			var2.Text = "Equipped"
			var2.BackgroundColor3 = var6.Teal
			var2.TextColor3 = var6.White
			return
		end

		if var3 then
			var9.Visible = true
			var2.Visible = false
			local var7 = var9
			var7.Text = if var16 == arg2 then "Equipping\226\128\166" else "Equip"
			var5.setButtonStyle(var9, "action")
			tbl2 = function()
				local var1 = arg2
				if var16 then
					return
				end

				var16 = var1
				refresh()
				task.spawn(function()
					local var2 = invoke("equip", var1)
					var16 = nil
					if var2.ok then
						flash(string.format(var4.Text.ToolEquipped, var4.ToolById[var1].Name), true)
					else
						local var7 = var1
						local var8 = tbl4[var2.reason]
						if var2.reason == "requires" then
							local var9 = var4.ToolById[var7]
							local var10 = var9
							var10 = var10 and (var9.Requires and var4.ToolById[var9.Requires])
							local var11 = var10
							var8 = var11 and string.format("Buy the %s first.", var10.Name)
						end

						flash(var8 or "That didn't work. Try again.", false)
					end

					refresh()
				end)
			end

			return
		end

		var9.Visible = false
		var2.Visible = true
		var2.Text = "In the Tool Shed"
		var2.BackgroundColor3 = tbl1.CardLocked
		var2.TextColor3 = var5.Colors.SubText
	end

	tbl3.frame = var1
	return tbl3
end

local tbl6 = { w = 150, h = 180, title = 19, marker = 20, icon = 84, price = 22 }
local function buildCard(arg1, arg2, arg3, arg4, arg5)
	local tbl2 = {
		Name = arg3 .. "Card",
		AutoButtonColor = false,
		Text = "",
		BackgroundColor3 = tbl1.Card,
		Size = UDim2.fromOffset(arg4.w, arg4.h),
	}

	tbl2.LayoutOrder = arg5
	tbl2.Parent = arg1
	local num1 = 14
	local var1 = var17("TextButton", tbl2, { var5.corner(num1) })
	local var2 = var17("UIStroke", {
		Color = tbl1.CardEdge,
		Thickness = 2,
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
		Parent = var1,
	})

	local var3 = var10.TrackInfo[arg3]
	tbl2 = var17("UIScale", { Parent = var1 })
	local tbl3 = {
		Name = "Title",
		Text = var3.Card,
		FontFace = var18.Bold,
		TextSize = arg4.title,
		Position = UDim2.fromOffset(4, 4),
	}

	tbl3.Size = UDim2.new(1, -8, 0, arg4.title + 6)
	tbl3.Parent = var1
	local var7 = var5.label(tbl3)
	local tbl4 = { Name = "Markers", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0) }
	tbl4.Position = UDim2.new(0.5, 0, 0, arg4.title + 12)
	tbl4.Size = UDim2.fromOffset(arg4.marker * var19.MaxLevel + 8, arg4.marker)
	tbl4.Parent = var1
	tbl3 = var17("Frame", tbl4)
	local tbl5 = {
		FillDirection = Enum.FillDirection.Horizontal,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 2),
	}

	tbl5.SortOrder = Enum.SortOrder.LayoutOrder
	tbl5.Parent = tbl3
	var17("UIListLayout", tbl5)
	local tbl6 = { tool = arg2, track = arg3 }
	num1 = {}
	for i1 = 1, var19.MaxLevel do
		local tbl7 = { Name = "Marker" .. i1, Size = UDim2.fromOffset(arg4.marker, arg4.marker) }
		tbl7.LayoutOrder = i1
		tbl7.Parent = tbl3
		local var8 = var12.label("CrystalOff", tbl7, "\194\183")
		local tbl8 = { label = var8, scale = var17("UIScale", { Parent = var8 }), on = false }
		num1[i1] = tbl8
	end

	local tbl9 = { Name = "Tile", BackgroundColor3 = tbl1.Tile, AnchorPoint = Vector2.new(0.5, 0) }
	tbl9.Position = UDim2.new(0.5, 0, 0, arg4.title + arg4.marker + 18)
	tbl9.Size = UDim2.fromOffset(arg4.icon, arg4.icon)
	tbl9.Parent = var1
	local var9 = tbl1.CardEdge
	local num2 = 2
	tbl4 = var17("Frame", tbl9, { var5.corner(12), var5.stroke(var9, num2) })
	local tbl10 = { Name = "Icon", AnchorPoint = Vector2.new(0.5, 0.5) }
	tbl10.Position = UDim2.fromScale(0.5, 0.5)
	tbl10.Size = UDim2.fromScale(0.9, 0.9)
	tbl10.Parent = tbl4
	tbl5 = var12.label(arg3, tbl10, var3.Card)
	local tbl11 = { Name = "Lock", AnchorPoint = Vector2.new(0.5, 0.5), ZIndex = 3, Visible = false }
	tbl11.Position = UDim2.fromScale(0.5, 0.5)
	tbl11.Size = UDim2.fromScale(0.66, 0.66)
	tbl11.Parent = tbl4
	tbl9 = var12.label("Lock", tbl11, "Locked")
	local tbl12 = {
		Name = "Level",
		BackgroundColor3 = var6.DeepBlue,
		AnchorPoint = Vector2.new(1, 1),
		ZIndex = 3,
	}

	tbl12.Position = UDim2.new(1, 6, 1, 6)
	tbl12.Size = UDim2.fromOffset(40, 21)
	tbl12.Parent = tbl4
	local var13 = var6.White
	local num3 = 1.5
	tbl10 = var17("Frame", tbl12, { var5.corner(10), var5.stroke(var13, num3) })
	tbl12 = {
		Text = "0/5",
		FontFace = var18.Bold,
		TextSize = 15,
		TextColor3 = var6.White,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 4,
	}

	tbl12.Parent = tbl10
	tbl11 = var5.label(tbl12)
	num2 = { Name = "Price", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 1) }
	num2.Position = UDim2.new(0.5, 0, 1, -6)
	num2.Size = UDim2.new(1, -8, 0, arg4.price + 4)
	num2.Parent = var1
	tbl12 = var17("Frame", num2)
	local tbl13 = {
		FillDirection = Enum.FillDirection.Horizontal,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 5),
	}

	tbl13.SortOrder = Enum.SortOrder.LayoutOrder
	tbl13.Parent = tbl12
	var17("UIListLayout", tbl13)
	var9 = var5.coin(arg4.price)
	var9.LayoutOrder = 1
	var9.Parent = tbl12
	tbl13 = {
		Text = "",
		FontFace = var18.Display,
		TextSize = arg4.price + 2,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromScale(0, 1),
		LayoutOrder = 2,
	}

	tbl13.Parent = tbl12
	num2 = var5.label(tbl13)
	num3 = {
		Name = "Pending",
		BackgroundColor3 = var6.White,
		BackgroundTransparency = 0.3,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 6,
		Visible = false,
	}

	num3.Parent = var1
	local num4 = 14
	tbl13 = var17("Frame", num3, { var5.corner(num4) })
	num3 = {
		Text = "\226\128\166",
		FontFace = var18.Display,
		TextSize = 44,
		Size = UDim2.fromScale(1, 1),
		ZIndex = 7,
	}

	num3.Parent = tbl13
	var5.label(num3)
	var1.Activated:Connect(function()
		local var1 = arg2
		var14 = { tool = var1, track = arg3 }
		if var1 == "Flamethrower" then
			str2 = "RunItems"
		else
			if var1 ~= var4.StarterToolId then
				str2 = "Tools"
			end
		end

		var15.Audio.play("UITick", 0.03)
		refresh()
	end)

	tbl6.pop = function(arg1)
		local var2 = num1[arg1]
		if var2 and (not var11.settings.ReducedEffects) then
			var2.scale.Scale = 1.7
			var5.tween(var2.scale, 0.35, { Scale = 1 }, Enum.EasingStyle.Back)
		end
	end

	var13 = 0
	tbl6.unlock = function()
		if not tbl9:IsA("ImageLabel") or var11.settings.ReducedEffects then
			return
		end

		var13 = os.clock() + 0.45
		tbl9.Visible = true
		tbl9.ImageTransparency = 0
		tbl9.Position = UDim2.fromScale(0.5, 0.5)
		var5.tween(tbl9, 0.4, { ImageTransparency = 1, Position = UDim2.fromScale(0.5, 0.15) })
		task.delay(0.45, function()
			tbl9.Visible = false
			tbl9.ImageTransparency = 0
			tbl9.Position = UDim2.fromScale(0.5, 0.5)
			refresh()
		end)
	end

	num3 = false
	tbl6.update = function(arg1)
		local var4 = arg1.owned[arg2] == true
		local var8 = var4 and arg1.levels[arg2][arg3] or 0
		local var11 = var4 and var10.price(arg2, arg3, var8, arg1.perks) or nil
		local bool2 = false
		if var14 ~= nil then
			bool2 = false
			if var14.tool == arg2 then
				bool2 = var14.track == arg3
			end
		end

		var7.Text = var4 and var3.Card or "???"
		for k1, v1 in ipairs(num1) do
			local var17 = var4
			if var17 then
				var17 = k1 <= var8
			end

			if var17 == v1.on then
				continue
			end

			v1.on = var17
			local var18 = var12.set
			local var20 = v1.label
			var18(var20, if var17 then "CrystalOn" else "CrystalOff")
		end

		var1.BackgroundColor3 = var4 and tbl1.Card or tbl1.CardLocked
		tbl4.BackgroundColor3 = var4 and tbl1.Tile or tbl1.TileLocked
		if tbl5:IsA("ImageLabel") then
			local var21 = tbl5
			var21.ImageTransparency = if var4 then 0 else 0.72
		end

		if var13 <= os.clock() then
			tbl9.Visible = not var4
		end

		tbl10.Visible = var4
		tbl11.Text = string.format("%d/%d", var8, var19.MaxLevel)
		var9.Visible = var11 ~= nil
		if not var4 then
			num2.Text = "?"
			num2.TextColor3 = var5.Colors.SubText
		elseif not var11 then
			num2.Text = "MAX"
			num2.TextColor3 = tbl1.Max
		else
			num2.Text = tostring(var11)
			num2.TextColor3 = var11 <= arg1.coins and var5.Colors.Text or tbl1.Warn
		end

		tbl13.Visible = var16 == arg2 .. ":" .. arg3
		var2.Color = bool2 and var6.Orange or tbl1.CardEdge
		local var22 = var2
		var22.Thickness = if bool2 then 4 else 2
		if bool2 ~= num3 then
			num3 = bool2
			var22 = var5.tween
			local var23 = tbl2
			local num4 = 0.12
			var22(var23, num4, { Scale = if bool2 then 1.05 else 1 })
		end
	end

	tbl6.frame = var1
	return tbl6
end

local function buildGrenadePanel(arg1, arg2)
	local tbl2 = {
		Name = "Grenades",
		BackgroundColor3 = tbl1.Detail,
		Position = UDim2.fromOffset(arg2.x, arg2.y),
		ZIndex = 2,
	}

	tbl2.Size = UDim2.fromOffset(arg2.w, arg2.h)
	tbl2.Parent = arg1
	local var1 = tbl1.DetailEdge
	local num1 = 2
	local var2 = var17("Frame", tbl2, { var5.corner(18), var5.stroke(var1, num1) })
	local num2 = 92
	local num3 = 92
	local var3 = var5.toolPreview(var4.Grenade.ToolId, UDim2.fromOffset(num2, num3))
	var3.Position = UDim2.fromOffset(12, 12)
	var3.Parent = var2
	tbl2 = arg2.w - 132
	num2 = {
		Name = "Title",
		Text = "FIRE GRENADES",
		FontFace = var18.Display,
		TextSize = 24,
		TextColor3 = tbl1.Heading,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(118, 12),
	}

	num2.Size = UDim2.fromOffset(tbl2, 30)
	num2.Parent = var2
	var5.label(num2)
	num2 = {
		Name = "Count",
		Text = "",
		FontFace = var18.Display,
		TextSize = 26,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(118, 44),
	}

	num2.Size = UDim2.fromOffset(tbl2, 32)
	num2.Parent = var2
	local var6 = var5.label(num2)
	num3 = {
		Name = "How",
		Text = "",
		FontFace = var18.Bold,
		TextSize = 17,
		TextColor3 = var5.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(118, 78),
	}

	num3.Size = UDim2.fromOffset(tbl2, 24)
	num3.Parent = var2
	num2 = var5.label(num3)
	var1 = {
		Name = "Info",
		Text = var4.Text.GrenadeInfo,
		FontFace = var18.Body,
		TextSize = 17,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Top,
		Position = UDim2.fromOffset(14, 114),
	}

	var1.Size = UDim2.fromOffset(arg2.w - 28, arg2.h - 122)
	var1.Parent = var2
	var5.label(var1)
	return { update = function()
		local var2 = var11.grenades()
		local var3 = var6
		local var5 = if 0 < var2 then string.format("You have %d", var2) else var4.Text.NoGrenades
		var3.Text = var5
		if var2 == 0 then
			num2.Text = var4.Text.GrenadesInShed
			return
		end

		if str1.Controls.isTouch() then
			num2.Text = "Tap the grenade button, then THROW"
			return
		end

		if str1.Controls.isGamepad() then
			num2.Text = "Shoulder buttons to hold one, trigger to throw"
			return
		end

		num2.Text = "G to hold one, click to throw"
	end }
end

local function buildDetail(arg1, arg2)
	local tbl2 = {
		Name = "Detail",
		BackgroundColor3 = tbl1.Detail,
		Position = UDim2.fromOffset(arg2.x, arg2.y),
		ZIndex = 2,
	}

	tbl2.Size = UDim2.fromOffset(arg2.w, arg2.h)
	tbl2.Parent = arg1
	local var1 = tbl1.DetailEdge
	local num1 = 2
	local var2 = var17("Frame", tbl2, { var5.corner(18), var5.stroke(var1, num1) })
	tbl2 = {
		Name = "Empty",
		Text = var4.Text.ChooseUpgrade,
		FontFace = var18.Display,
		TextSize = arg2.value + 4,
		TextColor3 = tbl1.Heading,
		Size = UDim2.fromScale(1, 1),
	}

	tbl2.Parent = var2
	local var7 = var5.label(tbl2)
	local tbl3 = {
		Name = "Body",
		BackgroundTransparency = 1,
		Size = UDim2.fromScale(1, 1),
		Visible = false,
	}

	tbl3.Parent = var2
	tbl2 = var17("Frame", tbl3)
	local tbl4 = { Name = "Text", BackgroundTransparency = 1, Position = UDim2.fromOffset(16, 12) }
	tbl4.Size = UDim2.new(1, -32, 1, -24)
	tbl4.Parent = tbl2
	local var8 = var17("Frame", tbl4)
	var1 = { Padding = UDim.new(0, 3) }
	var1.SortOrder = Enum.SortOrder.LayoutOrder
	var1.Parent = var8
	var17("UIListLayout", var1)
	tbl4 = function(arg1, arg2, arg3, arg4, arg5, arg6)
		local tbl1 = {
			Name = arg1,
			Text = "",
			FontFace = arg3,
			TextSize = arg4,
			TextColor3 = arg5,
			TextXAlignment = Enum.TextXAlignment.Left,
			AutomaticSize = Enum.AutomaticSize.Y,
			Size = UDim2.fromOffset(arg6, arg4 + 4),
		}

		tbl1.LayoutOrder = arg2
		tbl1.Parent = var8
		return var5.label(tbl1)
	end

	tbl3 = arg2.w - 32 - arg2.art - 12
	var1 = tbl4("Heading", 1, var18.Display, arg2.heading, tbl1.Heading, arg2.w - 32)
	num1 = tbl4("Description", 2, var18.Body, arg2.body, var5.Colors.Text, arg2.w - 32)
	local var9 = tbl4("Levels", 3, var18.Bold, arg2.body, var5.Colors.SubText, tbl3)
	local var11 = tbl4("Value", 4, var18.Display, arg2.value, var5.Colors.Text, tbl3)
	local var13 = tbl4("Extra", 5, var18.Body, arg2.body - 1, var5.Colors.SubText, tbl3)
	local tbl5 = {
		Name = "Need",
		Text = "",
		FontFace = var18.Bold,
		TextSize = arg2.body,
		TextColor3 = tbl1.Warn,
		TextXAlignment = Enum.TextXAlignment.Left,
		AnchorPoint = Vector2.new(0, 1),
	}

	tbl5.Position = UDim2.new(0, 16, 1, -10)
	tbl5.Size = UDim2.fromOffset(tbl3, arg2.body + 6)
	tbl5.Parent = tbl2
	local var15 = var5.label(tbl5)
	local tbl6 = { Name = "Art", BackgroundTransparency = 1, AnchorPoint = Vector2.new(1, 1) }
	tbl6.Position = UDim2.new(1, -14, 1, -12)
	tbl6.Size = UDim2.fromOffset(arg2.art, arg2.art)
	tbl6.Parent = tbl2
	tbl5 = var17("Frame", tbl6)
	local tbl7 = { Name = "Icon", Size = UDim2.fromScale(1, 1) }
	tbl7.Parent = tbl5
	local var20 = var12.label("Battery", tbl7, "")
	local tbl8 = {
		Name = "Next",
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
	}

	tbl8.Position = UDim2.fromScale(0.5, 0.5)
	tbl8.Parent = tbl5
	local var21 = var17("UICorner", { CornerRadius = UDim.new(0.5, 0) })
	local str1 = "UIStroke"
	local tbl9 = { Color = var6.Orange, Thickness = 3 }
	tbl6 = var17("Frame", tbl8, { var21, var17(str1, tbl9) })
	local tbl10 = {
		Name = "Now",
		BackgroundColor3 = var6.IceDeep,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
	}

	tbl10.Position = UDim2.fromScale(0.5, 0.5)
	tbl10.Parent = tbl5
	local var22 = var17("UICorner", { CornerRadius = UDim.new(0.5, 0) })
	tbl9 = "UIStroke"
	local tbl11 = { Color = var6.DeepBlue, Thickness = 2 }
	tbl7 = var17("Frame", tbl10, { var22, var17(tbl9, tbl11) })
	tbl10 = {
		Name = "Buy",
		Text = "BUY",
		TextSize = arg2.buyText,
		Position = UDim2.fromOffset(arg2.x, arg2.y + arg2.h + 12),
	}

	tbl10.Size = UDim2.fromOffset(arg2.w, arg2.buyH)
	tbl10.Parent = arg1
	local tbl12 = {}
	tbl10.OnClick = function()
		if tbl12.action then
			tbl12.action()
		end
	end

	tbl8 = var5.button(tbl10)
	tbl8.ZIndex = 2
	tbl12.update = function(arg1)
		tbl12.action = nil
		if not var14 then
			var7.Visible = true
			tbl2.Visible = false
			tbl8.Text = "BUY"
			var5.setButtonStyle(tbl8, "secondary")
			return
		end

		var7.Visible = false
		tbl2.Visible = true
		local var2 = var14.tool
		local var6 = var14.track
		local var8 = var4.ToolById[var2]
		local var17 = var10.TrackInfo[var6]
		var1.Text = string.upper(var8.Name) .. " \226\128\148 " .. string.upper(var17.Heading)
		var15.Text = ""
		local bool1 = false
		if not arg1.owned[var2] then
			local var18 = var8.Requires and (arg1.owned[var8.Requires] or var4.ToolById[var8.Requires]) or nil
			local var21 = num1
			local var22 = string.format
			var21.Text = var22(if var8.Product then var4.Text.ShedFindProductTool else var4.Text.ShedFindTool, var8.Name)
			var9.Visible = false
			var11.Visible = false
			var21 = var13
			if var18 then
				var22 = string.format(var4.Text.ShedRequires, var18.Name)
			else
				var22 = if var8.Product then var4.Text.ShedProductTool else ""
			end

			var21.Text = var22
			var21 = var13
			var22 = true
			if var18 == nil then
				var22 = var8.Product ~= nil
			end

			var21.Visible = var22
			var12.set(var20, "Lock")
			tbl8.Text = string.upper(var4.Text.ShedShowButton)
			var5.setButtonStyle(tbl8, "action")
			tbl12.action = showShed
		else
			local var23 = arg1.levels[var2][var6]
			local var24 = var10.price(var2, var6, var23, arg1.perks)
			local var25 = var10.compare(var2, var6, var23, arg1.perks)
			num1.Text = var17.Description
			local tbl1 = {}
			if var25.extra then
				table.insert(tbl1, var25.extra)
			end

			if var24 and 0 < arg1.perks.bp.UpgradeDiscount then
				local var28 = arg1.perks.bp.UpgradeDiscount
				local var29 = var4.Text.ClassDiscount
				table.insert(tbl1, string.format(var29, var3.percent(var28)))
			end

			var9.Text = var25.levels
			local var30 = table.concat(tbl1, "  \194\183  ")
			var11.Text = var25.value
			var13.Text = var30
			var9.Visible = true
			var11.Visible = true
			var13.Visible = 0 < (#tbl1)
			if var6 == "Size" then
				local var32 = var10.trackValue(var2, "Size", var19.MaxLevel)
				local var33 = var10.trackValue(var2, "Size", var23) / var32
				local var34 = var10.trackValue(var2, "Size", (math.min(var23 + 1, var19.MaxLevel))) / var32
				tbl7.Size = UDim2.fromScale(var33, var33)
				tbl6.Size = UDim2.fromScale(var34, var34)
				tbl6.Visible = var24 ~= nil
				bool1 = true
			else
				var12.set(var20, var6)
			end

			if not var24 then
				tbl8.Text = "MAXED"
				var5.setButtonStyle(tbl8, "done")
			else
				if var16 == var2 .. ":" .. var6 then
					tbl8.Text = "BUYING\226\128\166"
					var5.setButtonStyle(tbl8, "secondary")
				else
					if arg1.coins < var24 then
						tbl8.Text = string.format("BUY \226\128\148 %d COINS", var24)
						var5.setButtonStyle(tbl8, "secondary")
						local var35 = var24 - arg1.coins
						local var36 = var15
						local var37 = string.format
						local str1 = "Need %d more coin%s"
						local var38 = var35
						var36.Text = var37(str1, var38, if var35 == 1 then "" else "s")
					else
						tbl8.Text = string.format("BUY \226\128\148 %d COINS", var24)
						var5.setButtonStyle(tbl8, "action")
						tbl12.action = function()
							buyUpgrade(var2, var6)
						end

					end
				end
			end
		end

		var20.Visible = not bool1
		tbl7.Visible = bool1
		if not bool1 then
			tbl6.Visible = false
		end
	end

	tbl12.buy = tbl8
	return tbl12
end

local function buildCoins(arg1, arg2)
	local tbl1 = {
		Name = "Coins",
		BackgroundTransparency = 1,
		Position = UDim2.fromOffset(arg2.x, arg2.y),
		ZIndex = 2,
	}

	tbl1.Size = UDim2.fromOffset(arg2.w, arg2.h)
	tbl1.Parent = arg1
	local var1 = var17("Frame", tbl1)
	local tbl2 = {
		FillDirection = Enum.FillDirection.Horizontal,
		HorizontalAlignment = Enum.HorizontalAlignment.Right,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 8),
	}

	tbl2.SortOrder = Enum.SortOrder.LayoutOrder
	tbl2.Parent = var1
	var17("UIListLayout", tbl2)
	tbl1 = {
		Text = "Your coins: 0",
		FontFace = var18.Display,
		TextSize = arg2.size,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromScale(0, 1),
		LayoutOrder = 1,
	}

	tbl1.Parent = var1
	local var2 = var5.label(tbl1)
	tbl1 = var5.coin(arg2.h - 2)
	tbl1.LayoutOrder = 2
	tbl1.Parent = var1
	return { update = function(arg1)
		var2.Text = "Your coins: " .. tostring(arg1.coins)
	end }
end

local function buildClose(arg1, arg2)
	local tbl1 = {
		Name = "Close",
		AutoButtonColor = false,
		Text = "X",
		FontFace = var18.Display,
		TextSize = math.floor(arg2 * 0.58),
		ZIndex = 8,
	}

	tbl1.TextColor3 = var6.White
	tbl1.BackgroundColor3 = var6.Coral
	tbl1.AnchorPoint = Vector2.new(0.5, 0.5)
	tbl1.Position = UDim2.new(1, -10, 0, 10)
	tbl1.Size = UDim2.fromOffset(arg2, arg2)
	tbl1.Parent = arg1
	local var1 = var5.corner(18)
	local str1 = "UIStroke"
	local tbl2 = { Color = var6.Text, Thickness = 4, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var2 = var17("TextButton", tbl1, { var1, var17(str1, tbl2) })
	var5.fitText(var2)
	local var3 = var17("UIScale", { Parent = var2 })
	var2.MouseEnter:Connect(function()
		var5.tween(var3, 0.12, { Scale = 1.08 })
	end)

	var2.MouseLeave:Connect(function()
		var5.tween(var3, 0.12, { Scale = 1 })
	end)

	var2.Activated:Connect(function()
		tbl5.close()
	end)

	return var2
end

local function buildMessage(arg1)
	local tbl1 = {
		Name = "Message",
		BackgroundColor3 = var6.Teal,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
		ZIndex = 9,
	}

	tbl1.Position = UDim2.fromScale(0.5, 0)
	tbl1.Size = UDim2.fromOffset(380, 46)
	tbl1.Parent = arg1
	local num1 = 23
	local var1 = var17("CanvasGroup", tbl1, { var5.corner(num1) })
	tbl1 = {
		Name = "Label",
		Text = "",
		FontFace = var18.Display,
		TextSize = 24,
		TextColor3 = var6.White,
		Size = UDim2.fromScale(1, 1),
	}

	tbl1.Parent = var1
	var5.label(tbl1)
	return var1
end

local function buildExtras(arg1, arg2, arg3)
	local tbl1 = {
		Name = "Extras",
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0.5, 1),
		ZIndex = 7,
	}

	tbl1.Position = UDim2.new(0.5, 0, 1, -12)
	tbl1.Size = UDim2.fromOffset(arg2, arg3 or 40)
	tbl1.Parent = arg1
	local tbl2 = {
		FillDirection = Enum.FillDirection.Horizontal,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 10),
	}

	tbl2.SortOrder = Enum.SortOrder.LayoutOrder
	local str1 = "UIListLayout"
	local var1 = var17("Frame", tbl1, { var17(str1, tbl2) })
	tbl1 = {}
	for k1, v1 in ipairs({
		{
			id = "Settings",
			text = var4.Text.MenuSettings,
			run = function()
				tbl5.close()
				if var15.SettingsPanel then
					var15.SettingsPanel.open()
				end
			end,
		},
		{
			id = "ClassInfo",
			text = var4.Text.MenuClassInfo,
			run = function()
				tbl5.close()
				if var15.ClassInfo then
					var15.ClassInfo.open()
				end
			end,
		},
		{
			id = "FindIce",
			text = var4.Text.MenuFindIce,
			run = function()
				tbl5.close()
				if var15.HUD then
					var15.HUD.findIce()
				end
			end,
		},
	}) do

		local tbl3 = {
			Name = v1.id,
			Text = v1.text,
			TextSize = 18,
			Secondary = true,
			Size = UDim2.fromOffset(math.floor((arg2 - 20) / 3), (arg3 or 40) - 2),
		}

		tbl3.LayoutOrder = k1
		tbl3.OnClick = v1.run
		tbl3.Parent = var1
		local var2 = var5.button(tbl3)
		table.insert(tbl1, var2)
	end

	return var1, tbl1
end

local var21 = Vector2.new(780, 390)
local var22 = var4.StarterToolId
local tbl7 = { w = 116, h = 168, title = 16, marker = 17, icon = 64, price = 19 }
local var23 = Vector2.new(40, 40)
local var24 = nil
local var25 = nil
local function applyLayout()
	local var1 = var13.AbsoluteSize - var23
	local var2 = str1.Controls.isGamepad()
	for k1, v1 in pairs(tbl3) do
		local var4 = v1.base
		local var6 = if str1.Controls.isGamepad() then var4 + Vector2.new(0, 40) else var4
		if v1.size ~= var6 then
			v1.size = var6
			v1.frame.Size = UDim2.fromOffset(var6.X, var6.Y)
		end

		if not v1.extrasRow then
			continue
		end

		v1.extrasRow.Visible = var2
	end

	local var8 = var20
	local var9 = if str1.Controls.isGamepad() then var8 + Vector2.new(0, 40) else var8
	var8 = var21
	var8 = math.min(var1.X / var9.X, var1.Y / var9.Y)
	local var11 = if str1.Controls.isGamepad() then var8 + Vector2.new(0, 40) else var8
	local var12 = nil
	local var15 = nil
	if var24 == "Book" or var24 ~= "Page" and 0.72 <= var8 then
		var12 = tbl3.book
		var15 = math.min(var8, 1.3)
	else
		var12 = tbl3.page
		var15 = math.clamp(math.min(var1.X / var11.X, var1.Y / var11.Y), 0.4, 1.3)
	end

	var12.fit.Scale = var15
	local var16 = var25 ~= var12
	if var12 ~= var25 then
		if var25 then
			var25.frame.Visible = false
		end

		var25 = var12
		if var12 == tbl3.page and var14 then
			var22 = var14.tool
		end
	end

	var12.frame.Visible = true
	if var16 and var13.Visible then
		str1.UiFocus.reland("FrozenHouseManual")
	end
end

tbl5.forceLayout = function(arg1)
	var24 = arg1
	if var13.Visible then
		applyLayout()
		refresh()
	end
end

local bool1 = false
tbl5.isOpen = function()
	local bool3 = false
	if var13 ~= nil then
		bool3 = var13.Visible
		bool3 = bool3 and (not bool1)
	end

	return bool3
end

local var26 = nil
tbl5.open = function()
	if var11.menuOpen and var11.menuOpen ~= "Manual" then
		return
	end

	if tbl5.isOpen() then
		return
	end

	bool1 = false
	applyLayout()
	refresh()
	var13.Visible = true
	var11.setMenu("Manual")
	if var11.settings.ReducedEffects then
		var25.pop.Scale = 1
		var26.BackgroundTransparency = 0.45
	else
		var25.pop.Scale = 0.92
		var26.BackgroundTransparency = 1
		var5.tween(var25.pop, 0.18, { Scale = 1 }, Enum.EasingStyle.Back)
		var5.tween(var26, 0.18, { BackgroundTransparency = 0.45 })
	end

	var15.Audio.manualOpen()
	local tbl1 = { root = var13, hints = str1.basic(var4.Text.HintClose), lockControls = false }
	tbl1.initial = tbl5.firstCard
	tbl1.back = tbl5.close
	str1.open("FrozenHouseManual", tbl1)
end

tbl5.firstCard = function()
	if not var25 then
		return nil
	end

	local function shown(arg1)
		while not arg1 and arg1 == var13 and arg1:IsA("GuiObject") and (not arg1.Visible) do
		end

		return true
	end

	for k1, v1 in ipairs(var25.cards) do
		if not shown(v1.frame) then
			continue
		end

		if not v1.frame.Selectable then
			continue
		end

		return v1.frame
	end

	local var1 = var25.extras
	return var1 and var25.extras[1]
end

tbl5.close = function()
	if not tbl5.isOpen() then
		return
	end

	bool1 = true
	if var11.menuOpen == "Manual" then
		var11.setMenu(nil)
	end

	str1.close("FrozenHouseManual")
	var15.Audio.manualClose()
	local var2 = if var11.settings.ReducedEffects then 0 else 0.12
	if 0 < var2 then
		var5.tween(var25.pop, var2, { Scale = 0.95 })
		var5.tween(var26, var2, { BackgroundTransparency = 1 })
	end

	task.delay(var2, function()
		if bool1 then
			bool1 = false
			var13.Visible = false
		end
	end)
end

tbl5.toggle = function()
	if tbl5.isOpen() then
		tbl5.close()
		return
	end

	tbl5.open()
end

local var27 = nil
local function buildBook()
	local var1, var2, var3, var4 = layoutFrame("Book", var20 + Vector2.new(0, 40))
	local tbl2 = { Name = "Cover", BackgroundColor3 = tbl1.Cover, Size = UDim2.fromScale(1, 1) }
	tbl2.Parent = var3
	local var7 = var5.corner(30)
	local str1 = "UIStroke"
	local tbl3 = { Color = var6.Text, Thickness = 4, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var8 = var17("Frame", tbl2, { var7, var17(str1, tbl3) })
	local tbl4 = { cards = {}, headings = {}, frame = var1, fit = var2, pop = var4, base = var20 }
	local tbl5 = {}
	for i1 = 0, 1 do
		local var9 = Color3.new(1, 1, 1)
		str1 = Color3.fromRGB(236, 226, 208)
		tbl3 = var17
		local str3 = "Frame"
		local tbl7 = {
			Name = if i1 == 0 then "LeftPage" else "RightPage",
			BackgroundColor3 = tbl1.Page,
			Position = UDim2.fromOffset(i1 * 550 + 22, 20),
		}

		tbl7.Size = UDim2.fromOffset(526, 570)
		tbl7.Parent = var8
		local var10 = var5.corner(20)
		local var11 = var5.stroke(tbl1.PageEdge, 2)
		local var13 = i1 == 0 and ColorSequence.new(var9, str1) or ColorSequence.new(str1, var9)
		local str4 = "UIGradient"
		local tbl8 = { Color = var13 }
		tbl5[i1] = tbl3(str3, tbl7, { var10, var11, var17(str4, tbl8) })
	end

	local tbl9 = { Name = "Spine", BackgroundColor3 = tbl1.Spine, AnchorPoint = Vector2.new(0.5, 0) }
	tbl9.Position = UDim2.new(0.5, 0, 0, 12)
	tbl9.Size = UDim2.new(0, 14, 1, -24)
	tbl9.Parent = var8
	tbl3 = 7
	var17("Frame", tbl9, { var5.corner(tbl3) })
	for i2 = 1, 7 do
		tbl3 = {
			Name = "Ring",
			BackgroundColor3 = var6.Cream,
			AnchorPoint = Vector2.new(0.5, 0.5),
			ZIndex = 2,
		}

		tbl3.Position = UDim2.new(0.5, 0, 0, (i2 - 1) * 87 + 44)
		tbl3.Size = UDim2.fromOffset(16, 16)
		tbl3.Parent = var8
		local var14 = var5.corner(8)
		local str5 = "UIStroke"
		local tbl10 = { Color = var6.OrangeDark, Thickness = 2 }
		var17("Frame", tbl3, { var14, var17(str5, tbl10) })
	end

	str1 = { tbl5[1], 1, 0, 90 }
	for k1, v1 in ipairs({ { tbl5[0], 0, 0, 0 }, str1, { tbl5[1], 1, 1, 180 }, { tbl5[0], 0, 1, 270 } }) do
		local tbl11 = { Name = "Frost", AnchorPoint = Vector2.new(v1[2], v1[3]), ImageTransparency = 0.25 }
		tbl11.Position = UDim2.fromScale(v1[2], v1[3])
		tbl11.Size = UDim2.fromOffset(74, 74)
		tbl11.Rotation = v1[4]
		tbl11.Parent = v1[1]
		var12.label("Frost", tbl11, "")
	end

	tbl2 = function(arg1, arg2, arg3)
		local tbl1 = {
			Name = arg2,
			BackgroundTransparency = 1,
			Position = UDim2.fromOffset(24, arg3),
			ZIndex = 2,
		}

		tbl1.Size = UDim2.fromOffset(478, 240)
		tbl1.Parent = arg1
		local var1 = var17("Frame", tbl1)
		table.insert(tbl4.headings, (buildHeading(var1, arg2, { w = 478, h = 50, name = 30, control = 232, showName = true })))
		local tbl2 = { Name = "Cards", BackgroundTransparency = 1, Position = UDim2.fromOffset(0, 58) }
		tbl2.Size = UDim2.fromOffset(478, tbl6.h)
		tbl2.Parent = var1
		local var2 = var17("Frame", tbl2)
		local num1 = 0
		local tbl3 = {
			FillDirection = Enum.FillDirection.Horizontal,
			HorizontalAlignment = Enum.HorizontalAlignment.Center,
			Padding = UDim.new(num1, 14),
		}

		local var3 = Enum.SortOrder.LayoutOrder
		tbl3.SortOrder = var3
		tbl3.Parent = var2
		var17("UIListLayout", tbl3)
		for k1, v1 in ipairs(var19.Tracks) do
			table.insert(tbl4.cards, (buildCard(var2, arg2, v1, tbl6, k1)))
		end
	end

	tbl2(tbl5[0], "Hairdryer", 16)
	tbl3 = {
		Name = "LeafTabs",
		BackgroundTransparency = 1,
		Position = UDim2.fromOffset(24, 8),
		ZIndex = 2,
	}

	tbl3.Size = UDim2.fromOffset(478, 30)
	tbl3.Parent = tbl5[1]
	local var16 = var17("Frame", tbl3)
	local tbl12 = { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 8) }
	tbl12.SortOrder = Enum.SortOrder.LayoutOrder
	tbl12.Parent = var16
	var17("UIListLayout", tbl12)
	local tbl13 = { key = "Tools", text = "Heat Gun & Steam Blaster", width = 240 }
	local tbl14 = { key = "RunItems", text = "Flamethrower & grenades", width = 230 }
	local tbl15 = {}
	local tbl16 = {}
	for k2, v2 in ipairs({ tbl13, tbl14 }) do
		local tbl17 = {
			Name = v2.key,
			AutoButtonColor = false,
			Text = v2.text,
			FontFace = var18.Bold,
			TextSize = 16,
			TextColor3 = var5.Colors.Text,
			BackgroundColor3 = tbl1.Card,
			Size = UDim2.fromOffset(v2.width, 30),
		}

		tbl17.LayoutOrder = k2
		tbl17.Parent = var16
		local num1 = 15
		local var21 = var17("TextButton", tbl17, { var5.corner(num1) })
		var5.fitText(var21)
		var21.Activated:Connect(function()
			str2 = v2.key
			var15.Audio.play("UITick", 0.03)
			refresh()
		end)

		local var22 = var17("UIStroke", {
			Color = tbl1.CardEdge,
			Thickness = 2,
			ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
			Parent = var21,
		})

		tbl16[v2.key] = { tab = var21, stroke = var22 }
		num1 = {
			Name = v2.key .. "Leaf",
			BackgroundTransparency = 1,
			Position = UDim2.fromOffset(0, 42),
		}

		num1.Size = UDim2.fromOffset(526, 480)
		num1.Parent = tbl5[1]
		tbl15[v2.key] = var17("Frame", num1)
	end

	tbl2(tbl15.Tools, "HeatGun", 0)
	tbl2(tbl15.Tools, "SteamBlaster", 240)
	tbl2(tbl15.RunItems, "Flamethrower", 0)
	tbl4.grenades = buildGrenadePanel(tbl15.RunItems, { x = 24, y = 252, w = 478, h = 200 })
	tbl4.detail = buildDetail(tbl5[0], {
		x = 24,
		y = 266,
		w = 478,
		h = 208,
		heading = 22,
		body = 18,
		value = 28,
		art = 92,
		buyText = 26,
		buyH = 58,
	})

	tbl4.coins = buildCoins(tbl5[1], { x = 24, y = 522, w = 478, h = 36, size = 26 })
	buildClose(var3, 68)
	tbl4.message = buildMessage(var3)
	tbl4.update = function(arg1)
		for k1, v1 in pairs(tbl15) do
			v1.Visible = k1 == str2
			local var2 = k1 == str2
			local var3 = tbl16[k1].tab
			var3.BackgroundColor3 = if var2 then var6.Orange else tbl1.Card
			var3 = tbl16[k1].stroke
			var3.Color = if var2 then var6.OrangeDark else tbl1.CardEdge
		end

		tbl4.grenades.update()
		for k2, v2 in ipairs(tbl4.headings) do
			v2.update(arg1)
		end

		for k3, v3 in ipairs(tbl4.cards) do
			v3.update(arg1)
		end

		tbl4.detail.update(arg1)
		tbl4.coins.update(arg1)
	end

	local var23, var24 = buildExtras(var8, 420)
	tbl4.extrasRow = var23
	tbl4.extras = var24
	return tbl4
end

local function buildPage()
	local var1, var2, var3, var7 = layoutFrame("Page", var21 + Vector2.new(0, 40))
	local tbl2 = { Name = "Paper", BackgroundColor3 = tbl1.Page, Size = UDim2.fromScale(1, 1) }
	tbl2.Parent = var3
	local var8 = var5.corner(24)
	local str1 = "UIStroke"
	local tbl3 = { Color = tbl1.Cover, Thickness = 7, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var9 = var17("Frame", tbl2, { var8, var17(str1, tbl3) })
	local tbl4 = { Name = "Tabs", BackgroundTransparency = 1, Position = UDim2.fromOffset(16, 12) }
	tbl4.Size = UDim2.fromOffset(520, 42)
	tbl4.Parent = var9
	local var10 = var17("Frame", tbl4)
	var8 = { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 8) }
	var8.SortOrder = Enum.SortOrder.LayoutOrder
	var8.Parent = var10
	var17("UIListLayout", var8)
	tbl3 = #var4.Tools
	str1 = var4.Tools
	local tbl5 = {
		cards = {},
		headings = {},
		tabs = {},
		holders = {},
		frame = var1,
		fit = var2,
		pop = var7,
		base = var21,
	}

	tbl2 = math.floor((520 - (tbl3 - 1) * 8) / #str1)
	for k1, v1 in ipairs(var4.Tools) do
		local tbl6 = {
			Name = v1.Id,
			AutoButtonColor = false,
			Text = "",
			BackgroundColor3 = tbl1.Card,
			Size = UDim2.fromOffset(tbl2, 42),
		}

		tbl6.LayoutOrder = k1
		tbl6.Parent = var10
		local num1 = 21
		local var11 = var17("TextButton", tbl6, { var5.corner(num1) })
		local var13 = var17("UIStroke", {
			Color = tbl1.CardEdge,
			Thickness = 2,
			ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
			Parent = var11,
		})

		local tbl8 = { AnchorPoint = Vector2.new(0, 0.5) }
		tbl8.Position = UDim2.new(0, 6, 0.5, 0)
		tbl8.Size = UDim2.fromOffset(18, 18)
		tbl8.Parent = var11
		tbl6 = var12.label("Lock", tbl8, "")
		local var16 = var5.label
		tbl8 = {
			Text = v1.Name,
			FontFace = var18.Bold,
			TextSize = if tbl2 < 150 then 15 else 18,
			Position = UDim2.fromOffset(20, 0),
		}

		tbl8.Size = UDim2.new(1, -24, 1, 0)
		tbl8.Parent = var11
		var16 = var16(tbl8)
		var11.Activated:Connect(function()
			var22 = v1.Id
			local var1 = v1.Id
			local tbl1 = { tool = var1, track = var14 and (var14.tool == v1.Id and var14.track) or "Battery" }
			var14 = tbl1
			if var1 == "Flamethrower" then
				str2 = "RunItems"
			else
				if var1 ~= var4.StarterToolId then
					str2 = "Tools"
				end
			end

			var15.Audio.play("UITick", 0.03)
			refresh()
		end)

		tbl5.tabs[v1.Id] = { tab = var11, stroke = var13, lock = tbl6, name = var16 }
		local tbl9 = {
			Name = v1.Id,
			BackgroundTransparency = 1,
			Position = UDim2.fromOffset(16, 64),
			Visible = false,
		}

		tbl9.Size = UDim2.fromOffset(372, 312)
		tbl9.Parent = var9
		tbl8 = var17("Frame", tbl9)
		tbl5.holders[v1.Id] = tbl8
		table.insert(tbl5.headings, (buildHeading(tbl8, v1.Id, { w = 372, h = 44, control = 250, showName = false })))
		local tbl10 = { Name = "Cards", BackgroundTransparency = 1, Position = UDim2.fromOffset(0, 52) }
		tbl10.Size = UDim2.fromOffset(372, tbl7.h)
		tbl10.Parent = tbl8
		num1 = var17("Frame", tbl10)
		local num2 = 0
		local tbl11 = { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(num2, 12) }
		local var20 = Enum.SortOrder.LayoutOrder
		tbl11.SortOrder = var20
		tbl11.Parent = num1
		var17("UIListLayout", tbl11)
		for k2, v2 in ipairs(var19.Tracks) do
			table.insert(tbl5.cards, (buildCard(num1, v1.Id, v2, tbl7, k2)))
		end

		tbl10 = { Name = "Benefits", Text = table.concat(v1.Benefits, "  \194\183  "), TextSize = 16 }
		tbl10.TextColor3 = var5.Colors.SubText
		tbl10.TextXAlignment = Enum.TextXAlignment.Left
		tbl10.Position = UDim2.fromOffset(2, 52 + tbl7.h + 10)
		tbl10.Size = UDim2.fromOffset(372, 40)
		tbl10.Parent = tbl8
		var5.label(tbl10)
	end

	tbl5.detail = buildDetail(var9, {
		x = 404,
		y = 64,
		w = 360,
		h = 250,
		heading = 19,
		body = 16,
		value = 23,
		art = 72,
		buyText = 22,
		buyH = 50,
	})

	tbl5.coins = buildCoins(var9, { x = 540, y = 14, w = 190, h = 38, size = 20 })
	buildClose(var3, 58)
	tbl5.message = buildMessage(var3)
	tbl5.update = function(arg1)
		for k1, v1 in pairs(tbl5.tabs) do
			local var1 = k1 == var22
			v1.tab.BackgroundColor3 = var1 and var6.Orange or tbl1.Card
			v1.stroke.Color = var1 and var6.OrangeDark or tbl1.CardEdge
			v1.lock.Visible = not arg1.owned[k1]
			tbl5.holders[k1].Visible = var1
		end

		for k2, v2 in ipairs(tbl5.headings) do
			v2.update(arg1)
		end

		for k3, v3 in ipairs(tbl5.cards) do
			v3.update(arg1)
		end

		tbl5.detail.update(arg1)
		tbl5.coins.update(arg1)
	end

	local var23, var24 = buildExtras(var3, 360, 34)
	tbl5.extrasRow = var23
	tbl5.extras = var24
	return tbl5
end

tbl5.init = function(arg1)
	var15 = arg1
	var27 = var5.screen("FrozenHouseManual", 20)
	local tbl1 = {
		Name = "Root",
		BackgroundTransparency = 1,
		Size = UDim2.fromScale(1, 1),
		Visible = false,
	}

	tbl1.Parent = var27
	var13 = var17("Frame", tbl1)
	var26 = var5.backdrop({ Name = "Dim", BackgroundTransparency = 0.45, Parent = var13 })
	var26.Activated:Connect(tbl5.close)
	tbl3.book = buildBook()
	tbl3.page = buildPage()
	var13:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		if var13.Visible then
			applyLayout()
		end
	end)

	str1.Controls.changed:Connect(function()
		if var13.Visible then
			applyLayout()
			str1.UiFocus.reland("FrozenHouseManual")
		end
	end)

	local str2 = "OwnedTools"
	local function changed()
		if var13.Visible then
			refresh()
		end
	end

	for k1, v1 in ipairs({ "Coins", str2, "EquippedTool", "ToolUpgrades", "RunClass", "Grenades" }) do
		var11.onPlayerAttr(v1, changed)
	end

	var11.onAttr("GodlyCount", changed)
	var8.InputBegan:Connect(function(arg1)
		if tbl5.isOpen() and arg1.KeyCode == Enum.KeyCode.Escape then
			tbl5.close()
		end
	end)

	var11.cinematicChanged:Connect(function(arg1)
		if arg1 then
			tbl5.close()
		end
	end)
end

tbl5.noteOwned = function(arg1)
	local var1 = tbl2[arg1]
	var1 = var1 or {}
	if not var1.owned then
		var1.owned = true
		tbl2[arg1] = var1
		forEachCard(arg1, nil, function(arg1)
			arg1.unlock()
		end)

	end

	refresh()
end

tbl5.describe = function()
	local var1 = snapshot()
	local tbl1 = {
		layout = var25 and var25.frame.Name or "none",
		selected = var14,
		class = var1.perks.classId,
		cards = {},
	}

	for k1, v1 in ipairs(tbl3.book and tbl3.book.cards or {}) do
		local var2 = var1.owned[v1.tool] == true
		local var3 = var2 and var1.levels[v1.tool][v1.track] or 0
		local var4 = var2
		local str1 = "%s.%s owned=%s level=%d price=%s"
		local var5 = v1.tool
		local var6 = v1.track
		local var7 = tostring(var2)
		local var8 = var3
		local var9 = tostring(var4 and var10.price(v1.tool, v1.track, var3, var1.perks))
		table.insert(tbl1.cards, string.format(str1, var5, var6, var7, var8, var9))
	end

	if var25 then
		if var25.detail then
			local var16 = var25.frame:FindFirstChild("Detail", true)
			local var17 = var16
			local var18 = var16
			var18 = var18 and var16:FindFirstChild("Value", true)
			local var19 = var18
			var17 = var17 and var16:FindFirstChild("Extra", true)
			tbl1.detailValue = var19 and var18.Text
			var19 = var17
			tbl1.detailExtra = var19 and var17.Text
			tbl1.buy = var25.detail.buy.Text
		end
	end

	return tbl1
end

return tbl5

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Signal [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	return (setmetatable({ handlers = {} }, tbl1))
end

tbl1.Connect = function(arg1, arg2)
	local tbl1 = { fn = arg2, connected = true }
	table.insert(arg1.handlers, tbl1)
	return { Disconnect = function()
		tbl1.connected = false
		local var2 = table.find(arg1.handlers, tbl1)
		if var2 then
			table.remove(arg1.handlers, var2)
		end
	end }
end

tbl1.Fire = function(arg1, ...)
	local var1 = arg1.handlers
	for k1, v1 in ipairs(table.clone(var1)) do
		if not v1.connected then
			continue
		end

		task.spawn(v1.fn, ...)
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.FirstPerson [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("MeltShared")
local str1 = "SkinArt"
local str2 = "SkinFx"
local var3 = require(var2:WaitForChild(str1))
local var4 = require(var2:WaitForChild(str2))
local var5 = require(var1:WaitForChild("FrozenHouse").Config)
local var6 = game:GetService("Players")
local var7 = game:GetService("RunService")
local var8 = game:GetService("UserInputService")
local var9 = require(script.Parent.ClientState)
str1 = require(script.Parent.Input)
str2 = require(script.Parent.UIKit)
local var10 = var5.Palette
local var11 = var5.Camera
local tbl1 = {}
local var12 = var6.LocalPlayer
local var13 = nil
local bool1 = false
local var14 = nil
local var15 = nil
local var16 = nil
local num1 = 1
local var17 = Vector2.zero
local var18 = nil
local num2 = 0
local num3 = 0
local num4 = 0
local num5 = 0
local bool2 = false
local num6 = 1
local num7 = 0
local tbl2 = {
	Hairdryer = { jitter = 0.012, freq = 1, push = 0.05, kick = 0 },
	HeatGun = { jitter = 0.007, freq = 1.6, push = 0.03, kick = 0.03 },
	SteamBlaster = { jitter = 0.005, freq = 0.8, push = 0.08, kick = 0.16 },
	Flamethrower = { jitter = 0.009, freq = 1.1, push = 0.1, kick = 0.1 },
	FireGrenade = { jitter = 0, freq = 1, push = 0, kick = 0 },
}

local var19 = nil
local var20 = Vector2.zero
local tbl3 = {}
for k1, v1 in ipairs(var5.Keys.FreeCursor) do
	tbl3[v1] = true
end

local function disarmPrompt(arg1)
	if arg1:IsA("ProximityPrompt") then
		arg1.ClickablePrompt = false
	end
end

local function reducedEffects()
	return var9.settings.ReducedEffects == true
end

local function updateOwnHose(arg1)
	local var1 = var9.character()
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("FlamethrowerPack")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Hose", true)
	if var3 and (var3:IsA("Beam") and var3.Enabled == arg1) then
		var3.Enabled = not arg1
	end
end

local function buildViewmodel(arg1, arg2)
	local var2 = var1:FindFirstChild("FrozenHouseAssets")
	local var5 = var2
	var5 = var5 and var2:FindFirstChild("Tools")
	local var6 = var5
	var6 = var6 and var5:FindFirstChild(arg1)
	if not var6 or (not var6:FindFirstChild("Handle")) then
		return nil
	end

	local var7 = var6:GetAttribute("ViewScale")
	local var8 = var6:GetAttribute("ViewOffset")
	local var9 = Instance.new("Model")
	var9.Name = "FrozenHouseViewmodel"
	var7 = var7 or var11.ViewmodelScale
	var8 = var8 or var11.ViewmodelOffset
	for k1, v1 in ipairs(var6:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local var12 = v1:Clone()
		if var12:GetAttribute("ViewOnly") then
			var12.Transparency = 0
		end

		var12.Parent = var9
	end

	local var13 = arg2
	var13 = var13 and arg2:GetAttribute("SkinId")
	if var13 then
		var9:SetAttribute("ToolId", arg1)
		local success, result = pcall(var3.apply, var9, var13)
		if not success or (not result) then
			var3.remove(var9)
			var13 = nil
		end
	end

	local var14 = var9.Handle
	local var15 = var14.CFrame
	local var16 = var15 * CFrame.new(0, -0.05, 0.05)
	local var17 = Instance.new("Part")
	var17.Name = "Mitten"
	var17.Shape = Enum.PartType.Ball
	var17.Size = Vector3.new(0.8, 0.8, 0.8)
	var17.Color = var10.Coral
	var17.Material = Enum.Material.SmoothPlastic
	var17.TopSurface = Enum.SurfaceType.Smooth
	var17.BottomSurface = Enum.SurfaceType.Smooth
	var17.CFrame = var16
	var17.Parent = var9
	var16 = var15 * CFrame.new(-0.28, 0.25, -0.2)
	var17 = Instance.new("Part")
	var17.Name = "Thumb"
	var17.Shape = Enum.PartType.Ball
	var17.Size = Vector3.new(0.34, 0.34, 0.34)
	var17.Color = var10.Coral
	var17.Material = Enum.Material.SmoothPlastic
	var17.TopSurface = Enum.SurfaceType.Smooth
	var17.BottomSurface = Enum.SurfaceType.Smooth
	var17.CFrame = var16
	var17.Parent = var9
	local var18 = Vector3.new(0.35, -0.55, 1).Unit
	local var19 = Vector3.new(0.05, -0.45, 0.2) + var18 * 0.15
	var16 = var15 * (CFrame.lookAt(var19, var19 + var18) * CFrame.Angles(0, 1.5707963267948966, 0))
	var17 = Instance.new("Part")
	var17.Name = "Cuff"
	var17.Shape = Enum.PartType.Cylinder
	var17.Size = Vector3.new(0.35, 0.74, 0.74)
	var17.Color = var10.Cream
	var17.Material = Enum.Material.SmoothPlastic
	var17.TopSurface = Enum.SurfaceType.Smooth
	var17.BottomSurface = Enum.SurfaceType.Smooth
	var17.CFrame = var16
	var17.Parent = var9
	var19 = Vector3.new(0.05, -0.45, 0.2) + var18 * 1.7
	var16 = var15 * (CFrame.lookAt(var19, var19 + var18) * CFrame.Angles(0, 1.5707963267948966, 0))
	var17 = Instance.new("Part")
	var17.Name = "Sleeve"
	var17.Shape = Enum.PartType.Cylinder
	var17.Size = Vector3.new(2.8, 0.68, 0.68)
	var17.Color = var10.DeepBlue
	var17.Material = Enum.Material.SmoothPlastic
	var17.TopSurface = Enum.SurfaceType.Smooth
	var17.BottomSurface = Enum.SurfaceType.Smooth
	var17.CFrame = var16
	var17.Parent = var9
	local tbl1 = {}
	for k2, v2 in ipairs(var9:GetDescendants()) do
		if v2:IsA("JointInstance") or v2:IsA("WeldConstraint") then
			v2:Destroy()
		else
			if not v2:IsA("BasePart") then
				continue
			end

			v2.Anchored = true
			v2.CanCollide = false
			v2.CanQuery = false
			v2.CanTouch = false
			v2.CastShadow = false
			v2.Massless = true
			if v2:GetAttribute("FxRotateCenter") ~= nil then
				continue
			end

			table.insert(tbl1, v2)
		end
	end

	local var20 = var14:FindFirstChild("Nozzle")
	var16 = var20
	var16 = var16 and var20:FindFirstChild("Airflow")
	var17 = var16
	local var21 = var16
	var9:ScaleTo(var7)
	var17 = var17 and var16.Speed
	var21 = var21 and var16.Size
	local var22
	local var23
	if var16 then
		var16.Speed = var17
		var16.Size = var21
		local tbl3 = {}
		for k3, v3 in ipairs(var16.Transparency.Keypoints) do
			local var24 = v3.Time
			local var25 = math.clamp(1 - (1 - v3.Value) * var11.ViewmodelJetOpacity, 0, 1)
			table.insert(tbl3, NumberSequenceKeypoint.new(var24, var25))
		end

		var16.Transparency = NumberSequence.new(tbl3)
		var16.LockedToPart = true
		var16.Enabled = false
	end

	local tbl4 = {}
	local var26 = nil
	for k4, v4 in ipairs(tbl1) do
		tbl4[k4] = var14.CFrame:ToObjectSpace(v4.CFrame)
		if v4.Name ~= "GaugeNeedle" then
			continue
		end

		local tbl5 = { index = k4, pivot = tbl4[k4] * CFrame.new(0, -0.08 * var7, 0) }
		tbl5.reach = CFrame.new(0, 0.08 * var7, 0)
		var26 = tbl5
	end

	var9.Parent = workspace.CurrentCamera
	local var27 = nil
	if var13 and var9:FindFirstChild(var3.FolderName) then
		var27 = var4.attach(var9, {
			mode = "world",
			reduced = reducedEffects,
			active = function()
				return str1.firing
			end,
		})

	end

	local var28 = tbl2[arg1]
	local tbl6 = {
		model = var9,
		toolId = arg1,
		skinId = var13,
		fx = var27,
		parts = tbl1,
		offsets = tbl4,
		cframes = {},
		emitter = var16,
		hold = CFrame.new(var8) * CFrame.Angles(0.069813170079773182, 0.10471975511965978, 0),
	}

	tbl6.profile = var28 or tbl2.Hairdryer
	tbl6.needle = var26
	return tbl6
end

local function setHiddenTool(arg1)
	if var16 and var16 ~= arg1 then
		for k1, v1 in ipairs(var16:GetDescendants()) do
			if not v1:IsA("BasePart") then
				continue
			end

			v1.LocalTransparencyModifier = 0
		end
	end

	var16 = arg1
	if arg1 then
		for k2, v2 in ipairs(arg1:GetDescendants()) do
			if not v2:IsA("BasePart") then
				continue
			end

			if v2.LocalTransparencyModifier == 1 then
				continue
			end

			v2.LocalTransparencyModifier = 1
		end
	end
end

local var21 = require(script.Parent.IceWorld)
local var22 = setmetatable({}, { __mode = "k" })
local function watchTool(arg1)
	if var22[arg1] or (not arg1:IsA("Tool") or arg1:GetAttribute("ToolId") == nil) then
		return
	end

	local var1 = var4.watchTool(arg1, { reduced = reducedEffects })
	var22[arg1] = var1
	arg1.ChildAdded:Connect(function(arg1)
		if arg1.Name == var3.FolderName then
			var1.refresh()
		end
	end)
end

local function watchCharacter(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		watchTool(v1)
	end

	arg1.ChildAdded:Connect(watchTool)
end

tbl1.emitter = function()
	local var1 = var15
	return var1 and var15.emitter
end

tbl1.viewmodelModel = function()
	local var1 = var15
	return var1 and var15.model
end

tbl1.throwKick = function()
	num6 = 0
end

tbl1.trackTouchAim = function(arg1)
	var19 = arg1
	var20 = Vector2.zero
end

local function watchPlayer(arg1)
	if arg1 == var12 then
		return
	end

	if arg1.Character then
		watchCharacter(arg1.Character)
	end

	arg1.CharacterAdded:Connect(watchCharacter)
end

local function disarmPrompts(arg1)
	if var8.TouchEnabled and (not var8.MouseEnabled) then
		return
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("ProximityPrompt") then
			continue
		end

		v1.ClickablePrompt = false
	end

	arg1.DescendantAdded:Connect(disarmPrompt)
end

local function updateCursor()
	local bool3 = true
	if var9.menuOpen == nil then
		bool3 = bool1
	end

	var13.Visible = bool3
	var8.MouseIconEnabled = bool3
	var9.setFreeCursor(bool3)
end

local function applyTouchAim()
	if var20.Magnitude == 0 then
		return
	end

	local var1 = var20
	var20 = Vector2.zero
	local var3 = workspace.CurrentCamera
	if var9.cinematic or var3.CameraType ~= Enum.CameraType.Custom then
		return
	end

	local var4, var5 = var3.CFrame:ToEulerAnglesYXZ()
	local var6 = math.rad(var11.MaxTouchPitchDegrees)
	local var7 = CFrame.new(var3.CFrame.Position) * CFrame.fromEulerAnglesYXZ(math.clamp(var4 - var1.Y * var11.TouchAimSensitivity, -var6, var6), var5 - var1.X * var11.TouchAimSensitivity, 0)
	var3.CFrame = var7
end

local function renderViewmodel(arg1)
	local var3 = not var9.cinematic
	local var4 = workspace.CurrentCamera
	if var3 then
		var3 = false
		if var4.CameraType == Enum.CameraType.Custom then
			var3 = (var4.CFrame.Position - var4.Focus.Position).Magnitude < 1.5
		end
	end

	updateOwnHose(var3)
	if not var3 then
		if var15 then
			if var15.fx then
				var15.fx:destroy()
			end

			var15.model:Destroy()
			var15 = nil
		end

		if var16 and var16 ~= nil then
			for k1, v1 in ipairs(var16:GetDescendants()) do
				if not v1:IsA("BasePart") then
					continue
				end

				v1.LocalTransparencyModifier = 0
			end
		end

		var16 = nil
		var18 = nil
		return
	end

	local var5 = var9.heldTool()
	local var6 = var5
	var6 = var6 and var5:GetAttribute("ToolId")
	local var8 = var9.humanoid()
	local bool3 = false
	if var6 ~= nil then
		bool3 = false
		if var8 ~= nil then
			bool3 = 0 < var8.Health
		end
	end

	if bool3 then
		if var15 then
			if var15.toolId ~= var6 or var15.skinId ~= var5:GetAttribute("SkinId") then
				if var15 then
					if var15.fx then
						var15.fx:destroy()
					end

					var15.model:Destroy()
					var15 = nil
				end

				var15 = buildViewmodel(var6, var5)
				num1 = 1
			end
		end
	end

	setHiddenTool(bool3 and var5 or nil)
	local var10 = var4.CFrame
	if not var15 then
		var18 = var10
		return
	end

	local var12 = if bool3 and var9.menuOpen == nil then 0 else 1
	local var13 = num1
	local var19 = var12 - num1
	local num8 = 1
	num1 = var13 + var19 * math.min(num8, arg1 * (if var12 == 0 then 9 else 14))
	if not bool3 then
		if 0.97 < num1 then
			if var15 then
				if var15.fx then
					var15.fx:destroy()
				end

				var15.model:Destroy()
				var15 = nil
			end

			return
		end
	end

	var13 = if var9.settings.ReducedEffects then 0.35 else 1
	if var18 then
		local var23, var24 = var18:ToObjectSpace(var10):ToEulerAnglesYXZ()
		local var25 = var17 + Vector2.new(-var24, -var23) * 0.6
		var17 = var25
	end

	var18 = var10
	local var26 = var17:Lerp(Vector2.zero, (math.min(1, arg1 * 10)))
	var17 = var26
	var26 = Vector2.new(math.clamp(var17.X, -0.1, 0.1), (math.clamp(var17.Y, -0.08, 0.08))) * var13
	var17 = var26
	var26 = var9.character()
	var24 = var26
	var24 = var24 and var26:FindFirstChild("HumanoidRootPart")
	local num10 = 0
	if var24 and (var8 and var8.FloorMaterial ~= Enum.Material.Air) then
		num8 = var24.AssemblyLinearVelocity
		num10 = Vector2.new(num8.X, num8.Z).Magnitude
	end

	num8 = math.clamp(num10 / 16, 0, 1) * var13
	local var27 = num2 + arg1 * (num10 * 0.5 + 4)
	num2 = var27
	local var30 = str1.firing
	var27 = CFrame.new(math.sin(num2) * 0.05 * num8, -math.abs((math.cos(num2))) * 0.06 * num8, 0)
	local var31 = var15.profile
	if var30 and (not bool2) then
		num5 = var31.kick
	end

	bool2 = var30
	local var32 = num5 + (0 - num5) * math.min(1, arg1 * 9)
	num5 = var32
	var32 = num3
	var32 = var32 + ((if var30 then 1 else 0) - num3) * math.min(1, arg1 * 12)
	num3 = var32
	var32 = os.clock()
	local var33 = var31.jitter * var13 * num3
	local var34 = CFrame.new(math.sin(var32 * 53 * var31.freq) * var33, math.sin(var32 * 41 * var31.freq) * var33, var31.push * num3 + num5 * var13) * CFrame.Angles(num3 * 0.026179938779914945 + num5 * 0.13962634015954636 * var13, 0, 0)
	local var35 = math.min(1, num6 + arg1 / 0.35)
	num6 = var35
	var35 = math.sin(num6 * 3.1415926535897931) * var13
	local var37 = var15.needle
	local var38 = CFrame.new(0, 0.15 * var35, -0.5 * var35) * CFrame.Angles(-0.52359877559829882 * var35, 0, 0)
	if var37 then
		local var39 = num7
		var39 = var39 + ((if var30 then 1 else 0) - num7) * math.min(1, arg1 * 5)
		num7 = var39
		var15.offsets[var37.index] = var37.pivot * CFrame.Angles(num7 * -1.3089969389957472, 0, 0) * var37.reach
	end

	local var40 = workspace:Raycast(var10.Position, var10.LookVector * var11.ViewmodelReach, var14)
	local var41 = var21.raycast(var10.Position, var10.LookVector, var11.ViewmodelReach)
	local var42 = math.min(var40 and var40.Distance or math.huge, var41 and var41.distance or math.huge)
	local var43 = num4 + ((var42 < var11.ViewmodelReach and 1 - var42 / var11.ViewmodelReach or 0) - num4) * math.min(1, arg1 * 12)
	num4 = var43
	local var44 = num1 * num1
	local var45 = var10 * CFrame.Angles(var17.Y, var17.X, 0) * var27
	local var46 = var15.hold
	local var47 = var45 * var46 * CFrame.new(0, num4 * -0.3, num4 * 0.9) * (CFrame.new(0, var44 * -1.1, var44 * 0.3) * CFrame.Angles(var44 * -0.69813170079773179, 0, var44 * 0.24434609527920614)) * var34 * var38
	local var48 = var15.cframes
	for k2, v2 in ipairs(var15.offsets) do
		var48[k2] = var47 * v2
	end

	workspace:BulkMoveTo(var15.parts, var48, Enum.BulkMoveMode.FireCFrameChanged)
	if var15.fx then
		var15.fx:_update(os.clock())
	end
end

tbl1.init = function()
	var12.CameraMode = Enum.CameraMode.LockFirstPerson
	for k1, v1 in ipairs(var6:GetPlayers()) do
		if v1 == var12 then
		else
			if v1.Character then
				watchCharacter(v1.Character)
			end

			v1.CharacterAdded:Connect(watchCharacter)
		end
	end

	var6.PlayerAdded:Connect(watchPlayer)
	local var2 = workspace.CurrentCamera
	local function applyFieldOfView()
		local var2 = workspace.CurrentCamera
		if var2 then
			var2.FieldOfView = var11.FieldOfView
		end
	end

	if var2 then
		var2.FieldOfView = var11.FieldOfView
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(applyFieldOfView)
	var2 = workspace:WaitForChild("FrozenHouse")
	local str1 = "World"
	disarmPrompts(var2:WaitForChild(str1))
	var14 = RaycastParams.new()
	var14.FilterType = Enum.RaycastFilterType.Include
	local str3 = "World"
	local tbl1 = { var2:WaitForChild(str3) }
	var14.FilterDescendantsInstances = tbl1
	var14.IgnoreWater = true
	local var3 = str2.screen("FrozenHouseCursor", 100)
	str1 = {
		Name = "FreeCursor",
		Modal = true,
		Text = "",
		BackgroundTransparency = 1,
		Selectable = false,
		Size = UDim2.fromOffset(1, 1),
		Visible = false,
	}

	str1.Parent = var3
	var13 = str2.new("TextButton", str1)
	var8.InputBegan:Connect(function(arg1)
		if tbl3[arg1.KeyCode] then
			bool1 = true
			local bool3 = true
			if var9.menuOpen == nil then
				bool3 = bool1
			end

			var13.Visible = bool3
			var8.MouseIconEnabled = bool3
			var9.setFreeCursor(bool3)
		end
	end)

	var8.InputEnded:Connect(function(arg1)
		if tbl3[arg1.KeyCode] then
			bool1 = false
			local bool3 = true
			if var9.menuOpen == nil then
				bool3 = bool1
			end

			var13.Visible = bool3
			var8.MouseIconEnabled = bool3
			var9.setFreeCursor(bool3)
		end
	end)

	var8.WindowFocusReleased:Connect(function()
		bool1 = false
		local bool3 = true
		if var9.menuOpen == nil then
			bool3 = bool1
		end

		var13.Visible = bool3
		var8.MouseIconEnabled = bool3
		var9.setFreeCursor(bool3)
	end)

	var9.menuChanged:Connect(updateCursor)
	tbl1 = true
	if var9.menuOpen == nil then
		tbl1 = bool1
	end

	var13.Visible = tbl1
	var8.MouseIconEnabled = tbl1
	var9.setFreeCursor(tbl1)
	var8.TouchMoved:Connect(function(arg1)
		if arg1 == var19 then
			local var1 = var20 + Vector2.new(arg1.Delta.X, arg1.Delta.Y)
			var20 = var1
		end
	end)

	var8.TouchEnded:Connect(function(arg1)
		if arg1 == var19 then
			var19 = nil
		end
	end)

	var7:BindToRenderStep("FrozenHouseTouchAim", Enum.RenderPriority.Input.Value + 1, applyTouchAim)
	var7:BindToRenderStep("FrozenHouseViewmodel", Enum.RenderPriority.Camera.Value + 1, renderViewmodel)
	var12.CharacterRemoving:Connect(function()
		if var15 then
			if var15.fx then
				var15.fx:destroy()
			end

			var15.model:Destroy()
			var15 = nil
		end

		var16 = nil
		var18 = nil
		var19 = nil
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.IceRenderer [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = game:GetService("AssetService")
local var3 = game:GetService("RunService")
local var4 = require(var1.Config)
local var5 = require(var1.IceMesher)
local var6 = require(var1.IceShading)
local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	var1.grid = arg1
	var1.size = arg1.chunkSize * arg1.spacing
	var1.half = Vector3.new(arg1.nx - 1, arg1.ny - 1, arg1.nz - 1) * (arg1.spacing / 2)
	var1.frame = CFrame.new(arg1.origin + var1.half)
	local var2 = os.clock()
	var1.shading = var6.new(arg1, var4.IceLook)
	var1.shadingSetupMs = (os.clock() - var2) * 1000
	var1.glows = {}
	var1.entries = {}
	var1.pending = {}
	var1.dirty = {}
	var1.retryAt = {}
	var1.faceChunks = {}
	var1.out = var5.newOutput(arg1.chunkSize)
	var1.shade = { r = {}, g = {}, b = {} }
	var1.focus = Vector3.new(0, 0, 0)
	var1.budget = var4.Ice.RenderBudgetMs / 1000
	var1.building = false
	var1.alive = true
	var1.stats = {
		builds = 0,
		seconds = 0,
		maxMs = 0,
		shadeSeconds = 0,
		failures = 0,
		evictions = 0,
		applied = 0,
		seams = 0,
		gated = 0,
	}

	local var3 = Instance.new("Folder")
	var3.Name = "IceMeshes_" .. arg1.name
	var3.Parent = arg2
	var1.folder = var3
	task.spawn(function()
		var1:_worker()
	end)

	return var1
end

tbl1.markAll = function(arg1)
	for i1 = 0, arg1.grid.chunkCount - 1 do
		arg1.dirty[i1] = true
	end
end

tbl1.markChunkAndNeighbours = function(arg1, arg2)
	local var1 = arg1.grid
	local var2, var3, var4 = var1:chunkCoords(arg2)
	for i1 = -1, 1 do
		for i2 = -1, 1 do
			for i3 = -1, 1 do
				local var5 = var2 + i3
				local var6 = var3 + i2
				local var7 = var4 + i1
				if 0 > var5 or 0 > var6 or 0 > var7 then
					continue
				end

				if var5 >= var1.cnx then
					continue
				end

				if var6 >= var1.cny then
					continue
				end

				if var7 >= var1.cnz then
					continue
				end

				arg1.dirty[var5 + var1.cnx * (var6 + var1.cny * var7)] = true
			end
		end
	end
end

local tbl3 = { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 } }
tbl1._faceChunks = function(arg1, arg2)
	local var2 = arg1.faceChunks[arg2]
	if var2 then
		return var2
	end

	local var3 = arg1.grid
	local var4, var5, var6 = var3:chunkCoords(arg2)
	local var7 = table.create(6)
	for k1, v1 in ipairs(tbl3) do
		local var11 = var4 + v1[1]
		local var12 = var5 + v1[2]
		local var13 = var6 + v1[3]
		local bool2 = false
		if 0 <= var11 then
			bool2 = false
			if 0 <= var12 then
				bool2 = false
				if 0 <= var13 then
					bool2 = false
					if var11 < var3.cnx then
						bool2 = false
						if var12 < var3.cny then
							bool2 = var13 < var3.cnz
						end
					end
				end
			end
		end

		var7[k1] = if bool2 then var11 + var3.cnx * (var12 + var3.cny * var13) else -1
	end

	arg1.faceChunks[arg2] = var7
	return var7
end

local var7 = buffer.readu16
tbl1._hashBox = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var1 = arg1.grid
	local var2 = var1.density
	local var3 = var1.nx
	local var4 = var1.ny
	local num1 = 5381
	for i1 = math.max(arg6, 0), math.min(arg7, var1.nz - 1) do
		for i2 = math.max(arg4, 0), math.min(arg5, var1.ny - 1) do
			for i3 = math.max(arg2, 0), math.min(arg3, var3 - 1) do
				local var5 = var3 * (i2 + var4 * i1)
				num1 = (num1 * 33 + var7(var2, (i3 + var5) * 2)) % 4294967296
			end
		end
	end

	return num1
end

tbl1._faceHashes = function(arg1, arg2)
	local var1 = arg1.grid
	local var2, var3, var4 = var1:chunkCoords(arg2)
	local var5 = var1.chunkSize
	local var6 = var2 * var5
	local var7 = var3 * var5
	local var8 = var4 * var5
	local var9 = table.create(6)
	local tbl1 = { { var6 + var5, var6 }, { var7 + var5, var7 }, { var8 + var5, var8 } }
	for i1 = 1, 3 do
		for i2 = 1, 2 do
			local var10 = tbl1[i1][i2]
			local tbl2 = {
				var6 - 1,
				var6 + var5 + 1,
				var7 - 1,
				var7 + var5 + 1,
				var8 - 1,
				var8 + var5 + 1,
				[i1 * 2 - 1] = var10 - 1,
				[i1 * 2] = var10 + 1,
			}

			var9[(i1 - 1) * 2 + i2] = arg1:_hashBox(tbl2[1], tbl2[2], tbl2[3], tbl2[4], tbl2[5], tbl2[6])
		end
	end

	return var9
end

local tbl4 = { 2, 1, 4, 3, 6, 5 }
tbl1._meets = function(arg1, arg2, arg3, arg4)
	local var1 = arg1:_faceChunks(arg2)
	for i1 = 1, 6 do
		local var2 = var1[i1]
		if var2 == -1 then
			continue
		end

		local var3 = arg4
		var3 = var3 and arg4[var2]
		local var4 = arg1.entries[var2]
		var3 = var3 or var4.hashes
		if not var3 then
			continue
		end

		if var3[tbl4[i1]] == arg3[i1] then
			continue
		end

		return false
	end

	return true
end

tbl1._markSphere = function(arg1, arg2, arg3)
	local var1 = arg1.grid
	local var2 = (arg2 - var1.origin) / var1.spacing
	local var3 = arg3 / var1.spacing + 1
	local var4 = var1.chunkSize
	for i1 = math.max(0, (math.floor((var2.Z - var3) / var4))), math.min(var1.cnz - 1, (math.floor((var2.Z + var3) / var4))) do
		for i2 = math.max(0, (math.floor((var2.Y - var3) / var4))), math.min(var1.cny - 1, (math.floor((var2.Y + var3) / var4))) do
			for i3 = math.max(0, (math.floor((var2.X - var3) / var4))), math.min(var1.cnx - 1, (math.floor((var2.X + var3) / var4))) do
				arg1.dirty[i3 + var1.cnx * (i2 + var1.cny * i1)] = true
			end
		end
	end
end

tbl1.setGlows = function(arg1, arg2)
	for k1, v1 in ipairs(arg1.glows) do
		arg1:_markSphere(v1.position, v1.radius)
	end

	arg1.glows = arg2
	arg1.shading:setGlows(arg2)
	for k2, v2 in ipairs(arg2) do
		arg1:_markSphere(v2.position, v2.radius)
	end
end

tbl1.restyle = function(arg1)
	arg1.shading:setLook(var4.IceLook)
	for k1, v1 in pairs(arg1.entries) do
		local var1 = v1.part
		var1.Material = var4.IceLook.Material
		var1.Reflectance = var4.IceLook.Reflectance
	end

	arg1:markAll()
end

tbl1.step = function(arg1, arg2, arg3)
	arg1.budget = arg2
	arg1.focus = arg3
end

tbl1.idle = function(arg1)
	local var2 = not arg1.building
	if var2 then
		var2 = false
		if next(arg1.dirty) == nil then
			var2 = next(arg1.pending) == nil
		end
	end

	return var2
end

tbl1._center = function(arg1, arg2)
	local var1 = arg1.size / 2
	return arg1.grid:chunkOrigin(arg2) + Vector3.new(var1, var1, var1)
end

tbl1._fill = function(arg1, arg2, arg3)
	local var1 = arg1.grid
	local var2, var3, var4 = var1:chunkCoords(arg3)
	local var5 = var1.chunkSize
	local var6 = arg1.out
	local var7 = arg1.shade
	local var8 = arg1.shading
	local var9 = var1.spacing
	local var10 = var2 * var5
	local var11 = var3 * var5
	local var12 = var4 * var5
	for k1, v1 in ipairs(arg2:GetFaces()) do
		arg2:RemoveFace(v1)
	end

	arg2:RemoveUnused()
	local var13 = arg1.half.X
	local var14 = arg1.half.Y
	local var15 = arg1.half.Z
	local var16 = Vector3.new(-var13, -var14, 0.002 - var15)
	arg2:AddTriangle(arg2:AddVertex((Vector3.new(-var13, -var14, -var15))), arg2:AddVertex((Vector3.new(0.002 - var13, -var14, -var15))), arg2:AddVertex(var16))
	var16 = Vector3.new(var13 - 0.002, var14, var15)
	arg2:AddTriangle(arg2:AddVertex((Vector3.new(var13, var14, var15))), arg2:AddVertex((Vector3.new(var13, var14, var15 - 0.002))), arg2:AddVertex(var16))
	local var17 = var1:chunkOrigin(arg3) - (var1.origin + arg1.half)
	var8:beginChunk()
	local var18 = var17.X
	local var19 = var17.Y
	local var20 = var17.Z
	local var21 = var6.px
	local var22 = var6.py
	var16 = var6.pz
	local var23 = var6.qx
	local var24 = var6.qy
	local var25 = var6.qz
	local var26 = var7.r
	local var27 = var7.g
	local var28 = var7.b
	local var29 = table.create(var6.vertexCount)
	local var30 = table.create(var6.vertexCount)
	local var31 = table.create(var6.vertexCount)
	for i1 = 1, var6.vertexCount do
		local var32, var33, var34 = var8:vertex(var10 + var21[i1] / var9, var11 + var22[i1] / var9, var12 + var16[i1] / var9, var24[i1])
		var26[i1] = var32
		var27[i1] = var33
		var28[i1] = var34
		var29[i1] = arg2:AddVertex((Vector3.new(var18 + var21[i1], var19 + var22[i1], var20 + var16[i1])))
		var30[i1] = arg2:AddNormal((Vector3.new(var23[i1], var24[i1], var25[i1])))
		var31[i1] = arg2:AddColor(Color3.new(var26[i1], var27[i1], var28[i1]), 1)
	end

	local var35 = var6.tris
	local tbl1 = { 0, 0, 0 }
	local tbl2 = { 0, 0, 0 }
	for i2 = 0, var6.triCount - 1 do
		local var36 = var35[i2 * 3 + 1]
		local var37 = var35[i2 * 3 + 2]
		local var38 = var35[i2 * 3 + 3]
		local var39 = arg2:AddTriangle(var29[var36], var29[var37], var29[var38])
		tbl1[1] = var30[var36]
		tbl1[2] = var30[var37]
		tbl1[3] = var30[var38]
		arg2:SetFaceNormals(var39, tbl1)
		tbl2[1] = var31[var36]
		tbl2[2] = var31[var37]
		tbl2[3] = var31[var38]
		arg2:SetFaceColors(var39, tbl2)
	end
end

tbl1._drop = function(arg1, arg2)
	local var2 = arg1.pending[arg2]
	if var2 then
		if var2.part then
			var2.part:Destroy()
		end

		if var2.clone then
			var2.clone:Destroy()
		end

		arg1.pending[arg2] = nil
	end
end

tbl1._hold = function(arg1, arg2, arg3)
	arg1:_drop(arg2)
	arg3.since = os.clock()
	arg1.pending[arg2] = arg3
	local var1 = arg1.stats
	local var2 = var1.gated + 1
	var1.gated = var2
	arg1:_flush()
end

tbl1._release = function(arg1, arg2)
	arg1:_drop(arg2)
	local var2 = arg1.entries[arg2]
	if var2 then
		var2.part:Destroy()
		var2.clone:Destroy()
		arg1.entries[arg2] = nil
	end
end

tbl1._display = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var2 = arg1.entries[arg2]
	if var2 and var2.part.Parent then
		arg4:Destroy()
		if not pcall(function()
			var2.part:ApplyMesh(arg4)
		end) then

			arg3:Destroy()
			if not tbl2.apply then
				tbl2.apply = true
				warn("[FrozenHouse] MeshPart:ApplyMesh failed for an ice chunk: replacing its part instead (its frost pattern may jump).")
			end

			arg1:_release(arg2)
			arg1.dirty[arg2] = true
			return
		end

		var2.clone:Destroy()
		var2.clone = arg3
		var2.tris = arg5
		var2.hashes = arg6
		var2.builtAt = os.clock()
		local var3 = arg1.stats
		local var5 = var3.applied + 1
		var3.applied = var5
		return
	end

	arg4.Name = "IceChunk_" .. arg2
	arg4.Anchored = true
	arg4.CanCollide = false
	arg4.CanQuery = false
	arg4.CanTouch = false
	arg4.AudioCanCollide = false
	arg4.EnableFluidForces = false
	arg4.CastShadow = true
	arg4.DoubleSided = false
	arg4.Transparency = 0
	arg4.Color = Color3.new(1, 1, 1)
	arg4.CFrame = arg1.frame
	arg4.Material = var4.IceLook.Material
	arg4.Reflectance = var4.IceLook.Reflectance
	arg4.Parent = arg1.folder
	local tbl1 = { clone = arg3, part = arg4, tris = arg5, builtAt = os.clock() }
	tbl1.hashes = arg6
	arg1.entries[arg2] = tbl1
	if var2 then
		var2.part:Destroy()
		var2.clone:Destroy()
	end
end

tbl1._show = function(arg1, arg2)
	arg1.pending[arg2] = nil
	local var2 = arg1.pending[arg2]
	if not var2 then
		return
	end

	if var2.empty then
		arg1:_release(arg2)
		return
	end

	arg1:_display(arg2, var2.clone, var2.part, var2.tris, var2.hashes)
end

tbl1._flush = function(arg1)
	local tbl1 = {}
	local num1 = 0
	for k1, v1 in pairs(arg1.pending) do
		local var1 = v1.hashes
		tbl1[k1] = var1
		num1 = num1 + 1
	end

	local bool1 = false
	while not bool1 do
		for k2, v2 in pairs(tbl1) do
			local var2 = k2
			if arg1:_meets(var2, v2, tbl1) then
				continue
			end

			tbl1[k2] = nil
			local bool2 = true
			bool2 = false
		end
	end

	local var3
	if next(tbl1) == nil and 0 < num1 then
		local var4 = os.clock()
		local var5 = nil
		local var6 = nil
		for k3, v3 in pairs(arg1.pending) do
			if 0.3 <= var4 - v3.since then
				tbl1[k3] = v3.hashes
			end

			if not var6 or v3.since < var6 then
				var5 = k3
				var6 = v3.since
			end
		end

		if next(tbl1) == nil and 24 <= num1 then
			tbl1[var5] = arg1.pending[var5].hashes
		end

		for k4 in pairs(tbl1) do
			local var7 = arg1.stats
			local var8 = var7.seams + 1
			var7.seams = var8
		end
	end

	for k5 in pairs(tbl1) do
		arg1:_show(k5)
	end
end

tbl1._evictFor = function(arg1, arg2)
	local var1 = (arg1:_center(arg2) - arg1.focus).Magnitude + 12
	local var2 = nil
	local var3 = nil
	for k1 in pairs(arg1.entries) do
		if k1 == arg2 then
			continue
		end

		local var4 = (arg1:_center(k1) - arg1.focus).Magnitude
		if var1 >= var4 then
			continue
		end

		if not var2 or var3 < var4 then
			var2 = k1
		end

		local var5 = var4
	end

	if not var2 then
		return false
	end

	arg1:_release(var2)
	arg1.dirty[var2] = true
	arg1.retryAt[var2] = os.clock() + 2
	local var6 = arg1.stats
	local var7 = var6.evictions + 1
	var6.evictions = var7
	if not tbl2.evict then
		tbl2.evict = true
		warn("[FrozenHouse] EditableMesh memory budget reached: distant ice chunks are released and redrawn when budget allows.")
	end

	return true
end

tbl1._withBudget = function(arg1, arg2, arg3)
	for i1 = 1, 4 do
		local success, result = pcall(arg3)
		if success and result then
			return result
		end

		if not arg1:_evictFor(arg2) then
			return nil
		end

		task.wait()
	end

	return nil
end

tbl1._build = function(arg1, arg2)
	local var1 = var5.extract(arg1.grid, arg2, arg1.out)
	local var4 = arg1:_faceHashes(arg2)
	if var1.triCount == 0 then
		if arg1.entries[arg2] and (not arg1:_meets(arg2, var4)) then
			arg1:_hold(arg2, { empty = true, hashes = var4 })
			return
		end

		arg1:_release(arg2)
		return
	end

	if not arg1.builder then
		local var6 = arg1:_withBudget(arg2, function()
			local tbl1 = {}
			return var2:CreateEditableMesh(tbl1)
		end)

		arg1.builder = var6
		if not arg1.builder then
			var6 = arg1.stats
			local var7 = var6.failures + 1
			var6.failures = var7
			if not tbl2.builder then
				tbl2.builder = true
				warn("[FrozenHouse] Could not create an EditableMesh to build ice meshes (memory budget, or mesh APIs unavailable).")
			end

			arg1.dirty[arg2] = true
			arg1.retryAt[arg2] = os.clock() + 2
			return
		end
	end

	arg1:_fill(arg1.builder, arg2)
	local var8 = arg1.stats
	local var9 = var8.shadeSeconds + (os.clock() - os.clock())
	var8.shadeSeconds = var9
	var8 = arg1:_withBudget(arg2, function()
		local var1 = Content.fromObject(arg1.builder)
		local tbl1 = { FixedSize = true }
		return var2:CreateEditableMeshAsync(var1, tbl1)
	end)

	if not var8 then
		var9 = arg1.stats
		local var10 = var9.failures + 1
		var9.failures = var10
		if not tbl2.clone then
			tbl2.clone = true
			warn("[FrozenHouse] Ice chunk could not be drawn: the EditableMesh memory budget is exhausted near the camera.")
		end

		arg1.dirty[arg2] = true
		arg1.retryAt[arg2] = os.clock() + 2
		return
	end

	local success, result = pcall(function()
		local var1 = Content.fromObject(var8)
		local tbl1 = {
			CollisionFidelity = Enum.CollisionFidelity.Box,
			RenderFidelity = Enum.RenderFidelity.Precise,
		}

		return var2:CreateMeshPartAsync(var1, tbl1)
	end)

	if not success or (not result or (not arg1.alive)) then
		var8:Destroy()
		if result and typeof(result) == "Instance" then
			result:Destroy()
		end

		if arg1.alive then
			local var12 = arg1.stats
			local var13 = var12.failures + 1
			var12.failures = var13
			var12 = "CreateMeshPartAsync failed for an ice chunk: " .. tostring(result)
			if not tbl2.part then
				tbl2.part = true
				warn("[FrozenHouse] " .. var12)
			end

			arg1.dirty[arg2] = true
			arg1.retryAt[arg2] = os.clock() + 2
		end

		return
	end

	if arg1:_meets(arg2, var4) then
		arg1:_display(arg2, var8, result, var1.triCount, var4)
		return
	end

	arg1:_hold(arg2, { clone = var8, part = result, tris = var1.triCount, hashes = var4 })
end

tbl1._next = function(arg1)
	local var1 = os.clock()
	local var2 = nil
	local var3 = nil
	for k1 in pairs(arg1.dirty) do
		local var5 = arg1.entries[k1]
		local var6 = (arg1:_center(k1) - arg1.focus).Magnitude
		if var5 and 0.1 <= var1 - var5.builtAt or (arg1.retryAt[k1] or 0) <= var1 and (not var2 or var6 < var3) then
			var2 = k1
		end

		local var7 = var6
	end

	return var2
end

tbl1._worker = function(arg1)
	local var1 = os.clock()
	while true do
		if not arg1.alive then
			break
		end

		local var4 = arg1:_next()
		if var4 then
			if arg1.budget <= os.clock() - var1 then
				if next(arg1.pending) ~= nil then
					arg1:_flush()
				end

				var3.Heartbeat:Wait()
			else
				local var5 = os.clock()
				arg1.dirty[var4] = nil
				arg1.retryAt[var4] = nil
				arg1.building = true
				local var6 = os.clock()
				local success, result = pcall(arg1._build, arg1, var4)
				arg1.building = false
				if not success then
					local var8 = arg1.stats
					local var9 = var8.failures + 1
					var8.failures = var9
					var8 = "Ice chunk build error: " .. tostring(result)
					if not tbl2.build then
						tbl2.build = true
						warn("[FrozenHouse] " .. var8)
					end
				end

				local var10 = arg1.stats
				local var11 = (os.clock() - var6) * 1000
				local var12 = var10.builds + 1
				var10.builds = var12
				var10 = arg1.stats
				var12 = var10.seconds + var11 / 1000
				var10.seconds = var12
				arg1.stats.maxMs = math.max(arg1.stats.maxMs, var11)
			end
		end
	end
end

tbl1.tornPairs = function(arg1)
	local num1 = 0
	for k1, v1 in pairs(arg1.entries) do
		local var1 = arg1:_faceChunks(k1)
		for i1 = 1, 6 do
			local var3 = var1[i1]
			local bool2 = false
			if var3 ~= -1 then
				bool2 = arg1.entries[var3]
			end

			if not bool2 then
				continue
			end

			if bool2.hashes[tbl4[i1]] == v1.hashes[i1] then
				continue
			end

			num1 = num1 + 1
		end
	end

	return num1 // 2
end

tbl1.summary = function(arg1)
	local num1 = 0
	local num2 = 0
	for k1, v1 in pairs(arg1.entries) do
		num1 = num1 + 1
		num2 = num2 + v1.tris
	end

	local num3 = 0
	for k2 in pairs(arg1.dirty) do
		num3 = num3 + 1
	end

	local num4 = 0
	for k3 in pairs(arg1.pending) do
		num4 = num4 + 1
	end

	local var1 = arg1.stats.builds
	return {
		chunks = num1,
		parts = num1,
		tris = num2,
		pending = num3,
		builds = var1,
		avgMs = if 0 < var1 then arg1.stats.seconds * 1000 / var1 else 0,
		avgFillMs = if 0 < var1 then arg1.stats.shadeSeconds * 1000 / var1 else 0,
		maxMs = arg1.stats.maxMs,
		shadingSetupMs = arg1.shadingSetupMs,
		failures = arg1.stats.failures,
		evictions = arg1.stats.evictions,
		applied = arg1.stats.applied,
		held = num4,
		seams = arg1.stats.seams,
		gated = arg1.stats.gated,
	}
end

tbl1.destroy = function(arg1)
	arg1.alive = false
	for k1 in pairs(arg1.pending) do
		arg1:_drop(k1)
	end

	for k2 in pairs(arg1.entries) do
		arg1:_release(k2)
	end

	if arg1.builder then
		arg1.builder:Destroy()
		arg1.builder = nil
	end

	arg1.folder:Destroy()
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.IceWorld [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local var3 = require(var2.IceGrid)
local var4 = require(script.Parent.Signal)
local var5 = game:GetService("HttpService")
local var6 = game:GetService("Players")
local var7 = game:GetService("RunService")
local var8 = require(var2.Config)
local var9 = require(var2.IceCodec)
local var10 = require(var2.Layout)
local var11 = require(var2.Net)
local var12 = require(script.Parent.IceRenderer)
local tbl1 = { burst = var4.new() }
tbl1.changed = var4.new()
local var13 = nil
local var14 = nil
local tbl2 = {}
local var15 = nil
local function watchDoors(arg1)
	local var1 = arg1.folder
	local str1 = "Door_"
	local var2 = var14:FindFirstChild("House")
	for k1, v1 in pairs(var3.boxesFromFolder(var1, str1)) do
		local var4 = var2
		var4 = var4 and var2:FindFirstChild(k1)
		if not var4 then
			continue
		end

		local function check()
			if var4:GetAttribute("Open") ~= true then
				return
			end

			local var1 = arg1.grid
			local var2 = var1:openDoor(v1.min, v1.max)
			for k1, v2 in ipairs(var2) do
				local var3, var5, var6 = var1:coords(v2)
				var1:renderChunksAround(var3, var5, var6, arg1.renderer.dirty)
			end

			if 0 < (#var2) then
				tbl1.changed:Fire(var1.fieldId)
			end
		end

		local var5 = check
		table.insert(arg1.connections, var4:GetAttributeChangedSignal("Open"):Connect(var5))
		check()
	end
end

local function watchGlows(arg1)
	if arg1.grid.fieldId ~= 1 then
		return
	end

	local var1 = var14:FindFirstChild("Props")
	local var2 = var8.IceLook
	local tbl1 = {}
	for k1, v1 in ipairs(var10.KeyPieces) do
		local var3 = var1
		var3 = var3 and var1:FindFirstChild(v1.Folder)
		local var4 = var3
		var4 = var4 and var3:FindFirstChild("KeyPiece_" .. v1.Id)
		if not var4 then
			continue
		end

		local var5 = var4:FindFirstChildWhichIsA("PointLight", true)
		local tbl2 = { model = var4, position = var4:GetPivot().Position }
		tbl2.color = if var5 then var5.Color else var8.Palette.WarmLight
		table.insert(tbl1, tbl2)
	end

	local function refresh()
		local tbl2 = {}
		for k1, v1 in ipairs(tbl1) do
			if not v1.model:IsDescendantOf(var14) then
				continue
			end

			table.insert(tbl2, {
				position = v1.position,
				radius = var2.GlowRadius,
				color = v1.color,
				strength = var2.GlowStrength,
			})

		end

		arg1.renderer:setGlows(tbl2)
	end

	for k2, v2 in ipairs(tbl1) do
		local function fn3()
			if not v2.model:IsDescendantOf(var14) then
				refresh()
			end
		end

		table.insert(arg1.connections, v2.model.AncestryChanged:Connect(fn3))
	end

	refresh()
end

local function load(arg1)
	local success, result = pcall(var3.fromFolder, arg1)
	local var1
	if not success then
		var1 = tostring(result)
		warn("[FrozenHouse] Could not load ice field " .. arg1.Name .. ": " .. var1)
		return
	end

	local var4 = tbl2[result.fieldId]
	if var4 then
		var4.renderer:destroy()
		for k1, v1 in ipairs(var4.connections) do
			v1:Disconnect()
		end
	end

	local tbl1 = {
		grid = result,
		renderer = var12.new(result, var15),
		joined = false,
		joinAt = 0,
		lastResync = 0,
	}

	tbl1.folder = arg1
	tbl1.needsResync = {}
	tbl1.connections = {}
	tbl2[result.fieldId] = tbl1
	watchDoors(tbl1)
	watchGlows(tbl1)
	tbl1.renderer:markAll()
	tbl1.joinAt = os.clock()
	var13:FireServer(tbl1.grid.fieldId)
	return tbl1
end

local var16 = var3.ISO
local var17 = nil
tbl1.raycast = function(arg1, arg2, arg3)
	local var1 = var17
	var1 = var1 and workspace:Raycast(arg1, arg2 * arg3, var17)
	local var2 = var1 and var1.Distance or arg3
	local var3 = nil
	for k1, v1 in pairs(tbl2) do
		local var4, var5, var6 = v1.grid:raycast(arg1, arg2, var2)
		if not var4 then
			continue
		end

		if not var3 or var4 < var3.distance then
			var3 = { fieldId = k1, distance = var4, position = var5, normal = var6 }
		end
	end

	return var3, var1
end

tbl1.remainingClusters = function(arg1)
	local var2 = tbl2[1]
	if not var2 then
		return {}
	end

	local var4 = var2.grid
	local var5 = var4.density
	local var6 = var4.flags
	local var7 = var4.region
	local tbl1 = {}
	local tbl3 = {}
	for i1 = 0, var4.count - 1 do
		local var8 = var16
		if var8 > buffer.readu16(var5, i1 * 2) then
			continue
		end

		var8 = buffer.readu8(var6, i1)
		if bit32.band(var8, var3.REQUIRED) == 0 then
			continue
		end

		if arg1 ~= nil then
			var8 = var7
			if buffer.readu8(var8, i1) ~= arg1 then
				continue
			end
		end

		local var9, var10, var11 = var4:coords(i1)
		local var12 = var4:position(var9, var10, var11)
		local var13 = var12.X // 6 * 1000000 + var12.Y // 6 * 1000 + var12.Z // 6
		local var15 = tbl1[var13]
		if not var15 then
			var15 = { sum = Vector3.new(0, 0, 0), count = 0, min = var12, max = var12 }
			tbl1[var13] = var15
			table.insert(tbl3, var15)
		end

		local var17 = var15.sum + var12
		var15.sum = var17
		var17 = var15.count + 1
		var15.count = var17
		var17 = var15.min:Min(var12)
		var15.min = var17
		var17 = var15.max:Max(var12)
		var15.max = var17
	end

	for k1, v1 in ipairs(tbl3) do
		v1.center = v1.sum / v1.count
	end

	return tbl3
end

tbl1.requiredIceIn = function(arg1, arg2, arg3)
	local var2 = tbl2[1]
	if not var2 then
		return false
	end

	local var4 = var2.grid
	local var5 = (arg1 - var4.origin) / var4.spacing
	local var6 = (arg2 - var4.origin) / var4.spacing
	local var7 = var4.density
	local var8 = var4.flags
	local var9 = var4.region
	local var10 = math.max(0, (math.floor(var5.X)))
	local var11 = math.min(var4.nx - 1, (math.ceil(var6.X)))
	local var12 = math.max(0, (math.floor(var5.Y)))
	local var13 = math.min(var4.ny - 1, (math.ceil(var6.Y)))
	for i1 = math.max(0, (math.floor(var5.Z))), math.min(var4.nz - 1, (math.ceil(var6.Z))) do
		for i2 = var12, var13 do
			local var14 = var4.nx * (i2 + var4.ny * i1)
			for i3 = var10, var11 do
				local var15 = i3 + var14
				if var16 > buffer.readu16(var7, var15 * 2) then
					continue
				end

				if bit32.band(buffer.readu8(var8, var15), var3.REQUIRED) == 0 then
					continue
				end

				if arg3 == nil or buffer.readu8(var9, var15) == arg3 then
					return true
				end
			end
		end
	end

	return false
end

tbl1.field = function(arg1)
	return tbl2[arg1]
end

tbl1.summary = function()
	local tbl1 = {}
	for k1, v1 in pairs(tbl2) do
		local num1 = 0
		for k2, v2 in ipairs(v1.grid.chunkVersion) do
			num1 = num1 + v2
		end

		local var1 = tostring(k1)
		local tbl3 = { name = v1.grid.name, joined = v1.joined, hash = v1.grid:hash() }
		tbl3.versions = num1
		tbl3.render = v1.renderer:summary()
		tbl1[var1] = tbl3
	end

	return tbl1
end

local function onStream(arg1)
	local var2 = var9.decode(arg1)
	if not var2 then
		return
	end

	local var4 = tbl2[var2.fieldId]
	if not var4 then
		return
	end

	local var5 = var4.grid
	local var6 = var4.renderer
	local num1 = 0
	local var7 = Vector3.new(0, 0, 0)
	local var8 = var9.apply(var5, var2, var4.joined, var4.needsResync, function(arg1, arg2, arg3)
		local var1, var2, var3 = var5:coords(arg1)
		var5:renderChunksAround(var1, var2, var3, var6.dirty)
		if var16 <= arg2 and arg3 < var16 then
			local var4 = num1 + 1
			num1 = var4
			var4 = var7 + var5:position(var1, var2, var3)
			var7 = var4
		end
	end, function(arg1)
		var6:markChunkAndNeighbours(arg1)
	end)

	if var2.kind == var9.JOIN then
		var4.joined = true
	end

	if var8 then
		var4.lastResync = 0
	end

	if 0 < num1 then
		tbl1.burst:Fire(var7 / num1, num1)
	end

	tbl1.changed:Fire(var2.fieldId)
end

local function addField(arg1)
	if not arg1:IsA("Folder") then
		return
	end

	task.spawn(function()
		if arg1:GetAttribute("Ready") ~= true then
			arg1:GetAttributeChangedSignal("Ready"):Wait()
		end

		if arg1.Parent then
			load(arg1)
		end
	end)
end

local function removeField(arg1)
	for k1, v1 in pairs(tbl2) do
		if v1.folder ~= arg1 then
			continue
		end

		v1.renderer:destroy()
		for k2, v2 in ipairs(v1.connections) do
			v2:Disconnect()
		end

		tbl2[k1] = nil
	end
end

local function heartbeat()
	local var1 = os.clock()
	for k1, v1 in pairs(tbl2) do
		local var2
		if not v1.joined and 3 < var1 - v1.joinAt then
			v1.joinAt = os.clock()
			var2 = v1.grid.fieldId
			var13:FireServer(var2)
		end

		if not next(v1.needsResync) then
			continue
		end

		if 0.5 >= var1 - v1.lastResync then
			continue
		end

		v1.lastResync = var1
		local tbl1 = {}
		for k2 in pairs(v1.needsResync) do
			table.insert(tbl1, k2)
			if 64 <= (#tbl1) then
				break
			end
		end

		local var3 = tbl1
		var13:FireServer(v1.grid.fieldId, var3)
	end

	local var4 = workspace.CurrentCamera
	local var5 = var4 and var4.CFrame.Position or Vector3.new(0, 0, 0)
	local var6 = var8.Ice.RenderBudgetMs / 1000
	for k3, v2 in pairs(tbl2) do
		v2.renderer:step(var6, var5)
	end
end

tbl1.init = function()
	var15 = Instance.new("Folder")
	var15.Name = "FrozenHouseIceMeshes"
	var15.Parent = workspace
	var14 = workspace:WaitForChild("FrozenHouse"):WaitForChild("World")
	var17 = RaycastParams.new()
	var17.FilterType = Enum.RaycastFilterType.Include
	var17.FilterDescendantsInstances = { var14 }
	var17.IgnoreWater = true
	var17.CollisionGroup = var8.Physics.HeatRayGroup
	var13 = var11.get("IceResync")
	var11.get("IceStream").OnClientEvent:Connect(onStream)
	local var2 = var1:WaitForChild("FrozenHouseIce")
	var2.ChildAdded:Connect(addField)
	var2.ChildRemoved:Connect(removeField)
	for k1, v1 in ipairs(var2:GetChildren()) do
	if not not v1:IsA("Folder") then
			task.spawn(function()
				if v1:GetAttribute("Ready") ~= true then
					v1:GetAttributeChangedSignal("Ready"):Wait()
				end

				if v1.Parent then
					load(v1)
				end
			end)

		end
	end

	var7.Heartbeat:Connect(heartbeat)
	if var7:IsStudio() then
		local var3 = Instance.new("BindableFunction")
		var3.Name = "FrozenHouseIceHook"
		local function dispatch(arg1, arg2)
			if arg1 == "summary" then
				return tbl1.summary()
			end

			if arg1 == "rejoin" then
				local var2 = tbl2[arg2 or 1]
				if not var2 then
					return "no field"
				end

				if load(var2.folder) then
					return "reloaded initial data, join requested"
				end

				return "failed"
			end

			local var4
			local var5
			local var6
			local var9
			if arg1 == "renderAll" then
				local var10 = os.clock()
				local var11 = var10 + (arg2 or 30)
				repeat
					task.wait(0.1)
					local bool1 = true
					for k1, v1 in pairs(tbl2) do
						var5 = bool1
						var5 = var5 and v1.renderer:idle()
						bool1 = var5
					end
				until bool1 or var11 < os.clock()

				return os.clock() - var10
			end

			if arg1 == "torn" then
				local var12 = os.clock()
				local var13 = var12 + (if typeof(arg2) == "number" then arg2 else 0)
				var12 = {}
				local num1 = 0
				var9 = 0
				repeat
					num1 = num1 + 1
					var4 = 0
					for k2, v2 in pairs(tbl2) do
						local var14 = v2.renderer:tornPairs()
						local var15 = tostring(k2)
						local var17 = math.max(var12[tostring(k2)] or 0, var14)
						var12[var15] = var17
						var4 = var4 + var14
					end

					if 0 < var4 then
						var9 = var9 + 1
					end

					if os.clock() < var13 then
						var7.Heartbeat:Wait()
					end
				until var13 <= os.clock()

				return { worst = var12, frames = num1, framesTorn = var9 }
			end

			if arg1 == "raycast" then
				local var20 = tbl1.raycast(arg2.origin, arg2.direction.Unit, arg2.distance or 100)
				if var20 then
					local tbl3 = {
						position = var20.position,
						normal = var20.normal,
						distance = var20.distance,
						fieldId = var20.fieldId,
					}

					tbl3 = tbl3 or false
				end

				return false
			end

			if arg1 == "probe" then
				local var22 = tbl2[arg2.field or 1]
				if not var22 then
					return "no field"
				end

				local var23 = arg2.distance or 30
				var4 = arg2.step or 0.25
				local var24 = var22.grid
				local var25 = Vector3.new(arg2.origin[1], arg2.origin[2], arg2.origin[3])
				var9 = Vector3.new(arg2.direction[1], arg2.direction[2], arg2.direction[3]).Unit
				local tbl4 = {}
				local var26 = nil
				local var27 = nil
				for i1 = 0, var23, var4 do
					local var29 = var24:densityAt(var25 + var9 * i1)
					if var16 <= var29 then
						var26 = var26 or i1
						var27 = i1
					end

					local str1 = "%.2f:%d"
					local var30 = i1
					local var31 = math.round(var29)
					table.insert(tbl4, string.format(str1, var30, var31))
				end

				local var32 = tbl1.raycast(var25, var9, var23)
				return {
					iso = var16,
					firstSolid = var26,
					lastSolid = var27,
					hit = var32 and var32.distance,
					samples = table.concat(tbl4, " "),
				}

			end

			if arg1 == "look" then
				local var33 = arg2
				for k3, v3 in pairs(var33 or {}) do
					var8.IceLook[k3] = v3
				end

				for k4, v4 in pairs(tbl2) do
					v4.renderer:restyle()
				end

				return "restyled"
			end

			return "unknown command"
		end

		var3.OnInvoke = dispatch
		var3.Parent = var6.LocalPlayer:WaitForChild("PlayerScripts")
		local var4 = var6.LocalPlayer
		var4:GetAttributeChangedSignal("FrozenHouseIceCommand"):Connect(function()
			local var1 = var4:GetAttribute("FrozenHouseIceCommand")
			if typeof(var1) ~= "string" or var1 == "" then
				return
			end

			var4:SetAttribute("FrozenHouseIceCommand", "")
			task.spawn(function()
				local var2 = nil
				local success, result = pcall(function()
					local var3 = var5:JSONDecode(var1)
					var2 = var3.id
					local var4 = var3.command
					local var6 = var3.args
					return dispatch(var4, var6)
				end)

				local var3, var6 = pcall(function()
					local var1 = var5
					local var3 = if success then result else tostring(result)
					local tbl1 = { id = var2, ok = success, result = var3 }
					return var1:JSONEncode(tbl1)
				end)

				if not var3 then
					var6 = var5:JSONEncode({ id = var2, ok = false, result = "unencodable result" })
				end

				var4:SetAttribute("FrozenHouseIceResult", var6)
			end)
		end)

	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Battery [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = require(var1.Config)
local var3 = game:GetService("Players")
local var4 = require(var1.ToolStats)
local var5 = nil
local tbl1 = { changed = require(script.Parent.Signal).new() }
tbl1.state = function()
	return var5
end

local str1 = "charge"
local num1 = -math.huge
tbl1.noteLocal = function(arg1)
	if arg1 ~= str1 then
		str1 = arg1
		local var1 = workspace:GetServerTimeNow()
		num1 = var1
	end
end

local var6 = var2.Battery
tbl1.read = function()
	if not var5 then
		local var3 = var2.Upgrades.BatteryCapacity[0]
		return var3, var3, "full"
	end

	local var7 = workspace:GetServerTimeNow()
	local var8 = var5.capacity
	local var11 = if var5.mode == "full" then "charge" else var5.mode
	local var12 = nil
	local var13 = nil
	if var5.at < num1 then
		if var7 - num1 < 0.6 then
			if str1 ~= var11 then
				local var20 = var4.batteryAt(var5, num1)
				local var21 = var7 - num1
				if str1 == "run" then
					var12 = math.max(0, var20 - var6.DrainPerSecond * var21)
				else
					var12 = if str1 == "charge" then math.min(var8, var20 + var4.rechargeRate(var8) * var21) else var20
				end

				var13 = str1
			else
				var12 = var4.batteryAt(var5, var7)
				var13 = var5.mode
			end
		else
			var12 = var4.batteryAt(var5, var7)
			var13 = var5.mode
		end
	else
		var12 = var4.batteryAt(var5, var7)
		var13 = var5.mode
	end

	if var13 == "charge" and var8 <= var12 then
		var13 = "full"
	end

	return var12, var8, var13
end

tbl1.energy = function()
	return (tbl1.read())
end

tbl1.init = function()
	local var1 = var3.LocalPlayer
	var1:GetAttributeChangedSignal("Battery"):Connect(function()
		local str1 = "Battery"
		var5 = var4.decodeBattery(var1:GetAttribute(str1))
		tbl1.changed:Fire(var5)
	end)

	local str1 = "Battery"
	var5 = var4.decodeBattery(var1:GetAttribute(str1))
	tbl1.changed:Fire(var5)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.IconData [ModuleScript]
-- y u r i

return {
	Battery = {
		Width = 128,
		Height = 128,
		Pixels = "KLUv/WAA/z2GAOqAGB8rYLQHeb694hzZ9osLLY39aWlpjf8dtbdt2/+2iDg4OHeRNvxFJvxF2vAFBd0B5AHpAaupp5eVkHNsZVXz/JmQHKSd/18epTZh3+9nz6uqp2fHsRJFEA+4yLgjolYthvWF2ePAQxBDPTfxC+uTcfipTAgyf1Zl2Yux4ryqlO5ggcu55IceJ3kxrz67QxIH7wu/z6PWb6SSerwt6BAmyj4E3LOUEPpp98BgGGfFtTzmyVIaRRTzH2SPcwdd/r8/4kH/Obb0X56cFX1IslsuX84n/6pq6o8/Kn61WNZHm4S/NT06cjVYZi+ymP8dYn9pD7VEkXJj/oPVa+K9SAghqvm+5WqJJtVXl/0IY/6Hj7AS0uCfJfOjy3uEsec8EjgK6bNL0dGSKke6JuX/DrhJcz/CMfGyzf6bPJI09v9jTXFtZRbYiuOqA00GjEfYqDuSYZokjv0XJ2HdvKBP0pxo9v7LyElE/uy/7E/JEm0Ks+Sx/98XtJah/ytwkDa6dRhoCateNC9x9wIid5MzkX1a5/9p+/8o8JKOqW1XK8bZQ0l+958EUdtBlTayzNL84BsfbQKJoD0l3n+zzjTP/2kkPxne/5A3xfQXBl2G/98FCd8/vOQ8qtJH5fj/ZMXUz2HBUA+gC+P4lMVCS2OROEUT+f8kepMC3K7WBPJ/L0pZwKp+DzgyB6TNdO+/TmsBNh4GApuUl5SPHBULXzy3GULYgogfr2f/tqSsXkspbMxx3XzrZ1lpzGNOS/gXtc/RJt/vUhlSfBwm47HBMHTcgdPWmMedl3I1GBW3pJwSZpn/ZHbHOqwl+IDsG/YjjytnXOtl5OJnZuQv/cQEtV+O+U6nJNM/bq/QFdXUx6Hb59UuV5cqCtWc/KagmVJIOmEuv5pGfAch3aZIF6H9/qFztYpTc4lyzv9dVFOka56OYezorpzn6nzck1OfETLpL8aJXjvrBJZ+0N+R7UfaSf+oo5yrqKMdfqdA76nJvEch/ovTPzYjn6Psb99sg/W06/Gvae+Okkkbb2ZO5NhqOzASvjyy7vCDkiJ+WVjPux87uj4ZV3TYbT5JFsnzHob4D2b6Z1xIH9b01PGTtP1DSxH//dT9Z1fpsJ948X7nTPZ4WcSLXR56/IklWDErf6xoYOxn3u9lUX8e9h22isuam2XmP887/8HGf+9MjyMgViyoHuXRfTW1FPB+486bedHHZog6LNzY0L0/i/r++djDALhj2w/vrctyJkHE/zFMmMb8xyH+bzvAdrmabCjfx6/O1WFWXlVJedjRj0eNf1nSwnsmnfjLzwgSijL/0cb/sFOZ2ZWNrGjfnzVtf7yqpOrPy5rNfnhwJ4ofgQHl32bXoFJ6pQ2+3BlW2+8NUDaVki8Nh0P7vXSmXz7Zv4XhsUFHINYJ/b+3G68w8R3gSWrlVx9beu+CCkIElPuRjIKyqZWf7qyuVxtkW/CHgix+XF4ZLxAltTIsIFxxoChI9ycdB4diutybpD5ZOT2TPMGU1LmY6ZZxbfcpHwlT54FsPhxi8P/WmX69X+3yOEFvUGUMpoTrWIj3K9+Gs6qWoHCuAu+ZXPZzp6a8e+sVVUuyPvaU+8jW+3P44VCMt/tz5YdegeAjbFGll53J3Xe7D5Eu2AbEMQaDt+bzloRc7lDoK3RZpafv3Xji37+ETFS9DJV/fdWQ4T8oOBZyg5/hy+qlGbrshVwM/JiSizjmjC7QFRjP9G9ULODMUPyxz6uYZ6jeyMbB2VXM37Ylsx2Dw4Czv4ujRHZGAniIZsVUm3wnHwm/ZuXjZ6b7d1gYgNEgw2A4TZayQ2A7Bq2XTY05+Va62X/T0r1zJvEmkYkDZ9fgUgIRZ1gz1U7AlvD2t9Phc2pfW5LyV6svqEdDMJGGtb6mKoMSpssTfyemHJRzHo7TFNQ75VvHDCrWtNbZUMKYnpmRO+cSr1KZ2BsUBSVeL960aratzqSI65ONH1RTck4NbDw4+8NymycfDISMOK2bbinizUr3Dw3p+tH7/qZ7Y/CIYQy1USz8i/QoxtLe1/jQZpyRLtheA85G/0Xb68eQYten2Bk+YlYYbWQYDIwNjYoMKrabGo3UtJeBRprxhlNlxQXPACGPcaw04GDvGl3xuCM3bcINXT3HSoNl551ey4HB2rpXfA72b6yRrgXSQWMbV4dzOlZmmSYcdLF0OWFn3htRL4Qsh4b1OzAU0kCFHGeZ2zolN9XReYiZjENobCZJ7cV0D+ijK9vaiZD3PmnMXVJBdEjD7VvpVpWULnAuc7dTfHdah6BvgXci33ZoTMqoRu3VdHMinphdxZy/+7hwpVy82LexpNhTef419H/W4QFafKv9u3oGinUyQv0XEIgtFV8Xj+O9N3QKeQU7mmiks3KTpkceVo5dDYFwoMDEnUZifVVMto9v7czDin45NC2AdVvOpytX2s2j4rtB0d4js9SdcMW+tatnmWfj1C97GbhVfN1tj9VdUuuzas6NuoKur4ZCtjVJXr2RubKXupvp2+FQ98ktyXzCHUYk1dLMz61mzlTd5hG5KPTx/kzo+kp+X6D5a76bUCe5fqtdz2Vk40sZ2eBZN92GQN2utndP9nfL5B8cBZGMQ3V+5N8Zl+o662FJtVtOPmy+ti9P9EOlBMrRbm2SvFynt7PZQS8wxe4vhD+oM1XLlEVIJy0d8/JDCTBIIJoR5h6SB8PiGAQQFASCAAPCQDBwHAIMGghBYjQIhCEIBCIIhjAQRyHJtNbldgUa73SS03+oDfItqujcB1nvA7DS/3fRA5k98352MTwQZ8Jw19/S8Efq+ph/T110qIeILXZCPNzpaPthivucK0JdfD44+D+kWs8v+QCf0X4oM+tm7nfAJa0we79X/6QjIb56v4n+qNxTicE2J5ddwtZ+WKX9esryz2qQ06V9kf3ilMWw9w8nM54fbrn2Axxd6T5an+ymmYhywHPkKGVTeZQf8K5GHfVkuWxpYqqvxCBdvbXo94Plwx0wDva9KjKenr6I/6cN45O1HxUIuNu4y/00BmjOQ3HUfbF47O0nP8IY3/WEMz8jeWILXzDVyzQUUzu/33ljHZRhFwgdTb3wCPwGtc8Pk50HM3Gh68qg82YgICLMHgP0tW5WgRrMYlfeBpcjqHvrv7aI2u/07ZsBpWSGknOA9h+mFVXGkF/7ocABE70f/EcN2zFHiLxzeHxAd/M/1H7CR16nn65HVr5BuF/2wMOQLKbfmbBe8hvzgreYA/x5+HHsPbvRLaq/HHcxc5058d8oOcCgC8ZygFJ8n7vzxj+v/YinyxsQwibuIEWa47nMdCvBv64JsMINJw//BPUZZe23xx5QTySZA+3dSHii3Sr1N4Tdj/7SgDL7X6nxE+T+YOO7bh38yFyFJe9/C7ME+7WC3el/fiAUfGgXBt4/0ByH+ep3z2MEQwQ7YPPP3wiHjR1A9f8MMw0LD9QAx36XkgFAf3qsKz2u88R+FgVzXc47IN1FPe3X2/uGy+klQKA4MSdB3nqf2ZwJ+/f7K03mSvi+ovJg/MORUv9HKC+L2ggnAym64E/+97330wlEa5mvYDNf+z8vTuZs3gQeZ9wyVyIykLnRi8aL+Cn+f8hOots/cz9LekG7m/yRL6oa9p8CG/7M8y2A5Tw9oIZKZf/iBuTLHYr/Kmc31vA7GdVycQWUKtyCD3H98wYw1k9AjNbnnopW+j/t90TTrxAY/h+JoXUQMdRPcPv+yABdph+Prr4s9tuG/ltMxOEicsuliAV98gzY2w9itG8cy/85evLNHHepN5tAC2mX8euQpspV2KAdvBMsbbpzRfyvK4uIAZ5Qbxj/mXBIzzXMZb3kJu04YEB//9N0hOfH/tMk9MA8CfvVr8HD7iyNrTpl5BuHn1SpeoDUzsX1gT/gDkJyP8nsv/41EiBSlktYK8tF++YfVAOOHVhexTbz3rIRBzhVy2fkI37OpIQ/BxCkEkSOwoLS2xOGAdrCa/iR0gOC/Urx1i9UwGvJopmsT7YIPO+UNCBLDnonmOIZgFquN2q34jMMeCVPe64c/3w0bY0N59Dp/DDrY1J/E1FVXG8/wL8PemG/X6Jhm28TX1i+DGmWh+FnSMqB4z86pk+GUYGXx5Sssv/Py7HjP5vAb6BZIfxhwLbYuj83L/+IzHYzwGIbg00xwAfM1M/VM9IUsCf1DKu+fx0GoIgn+WH9PI+weVue2c24g/diFgO6vud+nr1fmP2URvPZSt/36bmErw4DNPXCp1M89Pt5YZrgimHdJ906BGtvEgO0svf90fP0neWdSQnfgKHqMMBTnORn9KdOuu5vw49lzuBglyADiAFJ9tg//p7Q7UiPNCwu/2sruhncB5qtp7WQNkBJz0W6Mt+v6KlhFFg7JU6tdDra5M3vU2+7UuFhQw+Y/pFhDeifG1f7dYXR+fLlzh+zXDIDLAfOJA5InB2ZWa+TH7ZV63ahjUEGuOswjXC+xtwHuavZMJbM+f7kAB2Eq//R96eEpRslUbop2vVEifLuPvRKi69dn/RsiQMEugMfmnY/Yz0BO9GgnocDZKu4T1p6GcLnA6HUgxGsHhsAO8GjHsN4FB32pNspvw3hJH6zUg6AVAYI+2etQ8k8dSvm/wRO03afBvePWdr/TmjeT1UWNisOrC/3D8Su9nODrnw4AoYBFr/+pRM9e716H0CZruGC7drbhFyuTMJ5B7I6MO1NcBk/jCCmuwGQ7CLzTUfFGfz9umEXjNQDPgm46dMekOr3/wE3aT8XHhAwARcbIds8Of6lDsTDxxpDJX3SAmPoFobeFrxMUdsL/X+acx6vptz4ei3hIyC1cKBxgitTGBU6vzC/Z9T/jhUDk0g4OHd4AO6jCM7TA8aY3yhnj2wlkIDoBzERH+txn8JwtxD2n6qXiHL0xJQn29XCoQe9Ydc17DjfxTg/sown2WLPXZ+kTF+WHQ9yMvVz/Hy2CP+rbIo97D4q/CfsfLlmau03t+o/+Pchji/6HMYrO6DI/UP4gsPNhAFK7rP7uNzv32Yvn2TpDCFLcCDkTH7xNY7bL/PwLgf96HqwTv+9/gmjAQtxAL5DzDWUe01A55M7wT0Cer3M4CX4H7faH28M/5i0X+h+fZ4Dfu/hmx8D8UnLC2rM9rWXZ+g2/U/W/13Gm5e9KM71Hesma+BqUmIH2m5MBascnGf+dyfFAD7OU41WbCKsBvVo6ozs/0zsHUA/6PgD93z9f4THND/cKBanedz/xu8BRABTZjjzdL2vQHGIUk7GjcZPiP/NWa5qNg5CtQTARgCsQJj21eNW/3n6xx2az46tNNwKyV/v4CObmbEJzv0/NKhd9XRO23lSxCGeYR9MIZziPeX891KsqPwogO4XJ/aBnAdaIJA6u3uakwZk8ZUXhtWidE6l+hb3P8RZWaL//dl9lOAD7X+Y/PJlAMO+l5/VQfP+mzGlv2cMHOUXx3jeh+0J98Mq939XT3j/3sn3EfcJi5r3P2vW87e33QCwon2f1gQAc/nyR9F/tt3objU5vylm3keogvM5RcAhG6bP+zQtcr8uYpu+NP+bRV259/s8kND9sJcspgY4ibU8gWiEdiFNYZpF3xzO4R5itKPmCPdJEvFLXX6K+zX8J/+MD2JnwPHDeVsj02sr6EfM9R9LdPss2tUtKwfo6Tx5Mb/zQmHkepbXDxeB/DpaWykHEvG5Pi9S0q9X6KjUAy3SP1c28dxlD/Cu74p1K+RjMGRw0ueAGULospEL",
	},
	Size = {
		Width = 128,
		Height = 128,
		Pixels = "KLUv/WAA/6WAAPpoEBktcLQHIQnDskWrQFNV5ixWKiNCiRYUpDYghARoACE6AzOgeNwbKFkbhuRIjmSOfgGHAYQBPOZ3E2vChjn5f69/u9yUzmf+ScY6vksqrrvNv5XOeu9V6ezNT54EzPh8WvLer9571DKn4AYJWz1ph5O6f6td/lvr8H+nt/99vq63yZ9MOWjiaP8mhyBPOi0aP/3prbN6fkov96178L2EcHZ3OcoE8Xv4fL/3PwLHl2UZfXbppd0N+tNl8CfCMSnBy0w4SeQBCLlo9rf5t00x/xvZlIcJIPqjgGFEIj4hNy3T/j5/NWh46oDEAuFrPfnQ3eHo3z7dVPtQQ1iQf6LIozzef4fLSVHOyX8rq/qOhnXtNec9PvrVoeI/BgN+Qr21X6aV9HVcOE5QPn6OsFEcJSEfpctOgbz/kCiwKO0Gx/WbcDVFsrZaXoDPHpwMolPC3RHzWIstmXvsCozsmbdRASqR9+4HkIo4IEDjqiAiBWai0si+Zn8HSNDRF5kC+yNb2xM6yBXJ1h+SVJXFbrceLy6fwyQEKyDAX80HXT7qYCSK/+avxR4cYKO03W++jlwBMhgGAuHBrwOVa1ytuNiGlZ+C4aOCf93J5eXrx1JLN24VxeB8HTZFi9HgpIU0Hfb4KVqcFk8b/qEajzmqOJWMt9n4xlG6GE8j/heQBnkpYyCYyneup/WuGlcn/nPl3Rw1Mq/Ir0skFEwWL+3+yMOzrlnUkitHbZNVPffGhGF+Wx10VlB56eIHnLvqLvaBjf+c8KiuP6xH9ctivk9+rPuNc0Wjk25zuWnjF6viGbPiQUR7+Xuitz/lp97rSM6KhV1+6h5FvKkEhLrT56ffnxp6GBCAxvSjtz15TM3DLNJxXJ86Cf6BdFrj8d2a1DxV7Cbtfs/GsM/ohvO5VhV1Tw7fj8vjg+mCvjmsZo+XzteQ/yloRZsFeehXL3vVyjlq+KM1AwUU3+pvdJ8q/luwJPMekY1IrzpevaSzO/tUyb8q2vhJKgyykl05eWi/atmrUn63MKWAl5CHuvtM5y/R9HZnv1r5RzkNAwC2XTcxpvpb1D5/n+usn6N3On3V8hPdjFy32ElGulZ7nM7WpAdy5C2bEy1Mq0GkrUv9Gnz9zyAicZ/77j0fipf205RiARMJGSEgX8OmqO35VoeTsjvXvpqSDOKqqES+Dtvl6w9XK7bJbF89Lvs4KBFbnJQIOGtZbvs/v18CZTAY3X2+92y+tqfbR6RbmpNnEeuYen7zLepXZ2x/wn0wqJcLbNGnaFt/jI+PACEsRs9zus16b9G/1nq8kfUzbk0iofxIFjf11t3nvTcakLU89/vajLCMUnp2Zx7df/lYAA2f2eepc9UxK2jd99sifaGZjLlqZVpyrOufXqrB04nu0Ltvmvn2SSgKBPzclM5gr+8IZ3PV+OG6nr++ZHujA1lJ3Wa8j3WksjXVlOtVL3ny3O+uwVDuEcnXkHF1123m/kS8KaEZjft89fermOnJs8OyFLo6PP3p7bL7rCegZePiiZcy8p51v09r433m+0IzGyPhQS86m7zIFoMp6CQ/fXyL9n02rh7+lPPODleLhsfYn3h01tCe13yj/75i3tXeVy6nM/FqnjoJRwP+AVne3HPzYVJQPiRI8RbFv/Hc/oaaXGVnZ5gfnxvvoQfrR9xMcxklHUXdH7HLDO2Ldv9ETnXKx4SedxKs2Ol1lvY4+i7VAv3gPHZVUkAmSMk8nyMlZBr+Fz1Nf4z5Cy3NExtOxz8jho6U3OJI7V8EeX2MmaJfWFmOVMdPfxAQjrbubc3lvch6fa4j1fLf9x1nMUxaGsWlcrUAC7vuwfVDXDpfY69Y3jyy9ZZR/8CVXd6LOxqsdvwlTecfLA3Dy3uxFoodT5r23xEU9WeBMJLW8Mgsf0bGRNY8CfhoOYEhpJW7mUiQ+YamUp72P0xtLW/+MdKsXL5jnlHWKubX1DeMC/pfTCcf58RhBYQSHJqacz1pmUPNxlz/HtrOJ43cWs0E++TFqj+npQEHQl5+FZArd241FGIl9r9cpJ+NoXg0q47X9C+2xrYNrcnKUHxPxitec+x/9ZS+i4cClgXkdzPPXyhIR5uRcWapZyhHVPbVrmJGQOhQPb1Z/KbZ/+4xEQhogDlq7LXLAYR6qONHW1RRpEmiFIYx0/LRCAYOhQX0Qa7dBnNhQxAgBIIAA0EhgGASQCB4IAZi4AiCcAjCsAiCUIghUjHEWM8BkoUd9P8rlt4DDOgX4AiwLxId5rbMdrlPtXQ1aLZIs20M5SDXG4V1QtMkt26THHJioxhwdlMlt05NzVX6jUAHvC29P3JM4+Ecs5x13o8rj01TwCo+3kvKyQN7H9fw0ZBzP5rag4wcCDCKhpGT2pP+NfkD1FBWhmClJXd9rOhgBDpgWJ4BlY7aL9tyXeSGFw9ICHzA1EX6SM1wval7EWg8YEXWAVE3jJGY/hS+OYRnOqlzQNu+UK4Bj3ThX5lu9rU62+UBTbvKPy1G/gGpkv/Z4Tm40xH7kRqwqMm/VHp3cDtl0gDzsfc3v8tAX7zN1XbTx4Qj8O1+180fr/FywBzDcLMmXe4hCgbUcpIT0sWqp3/c3RH/bpkDsEyftM1nW/oB9GQ+v6mX6PBf8g8MhLTp+aSO/biBAbXa2v43x8xizIACX0Ba/fM7cHSFTV90FgPNV2rhADifqfz/VrwY+s9Tvj4iMJXJiEZ0iEX6r/TAF/JiGLtkvlIbgDt3+jVP8FFYHI/4fXF5U8iCf9aBJxa3OOZD0AOw2809He82gD4jyT/1eYr49QDa7oBTgZyv7EhWTBWdXlUZTLRn+/bfAdb64e81dJX50OYBGFknHdjYs0LTdPn+MwLc+yrywJV7uvks7BxA84htJk24A8V3H3A+OLpTJgC0Zzvws795KfNIzpuvGGO1L80NKH7Teteai9aOJhDSS3FgCOwfCPONK62w4sOXrfl/mDf7NISKGuIOcoBB+J35KI2NqIXQywp813+zy/PexDfRfsBx3q8rN2LQPgBfBx4OJBHuf2ZRt5g3SWuHBxi9LS7hgEAt0x7gx3kdPQmR19O8EKR9YIyve/EHR0AMVmoHEGu8/6hS24e4321GJdQEf64HeiD+tq75W3tkcsTWLXP0HiD//+R+78i5P8bxr3uCDzGk3M7Uz1MGcwAjpdb35JQrxITXf7kAN86WeY9k7M0VUa93OBh3wOF/JrpgQOGfJ+vT02O3uNJM0jaWA3Dvv4cPGDCe075oTkDne8UUUFTrOQ7sY/Slug/c2r8A9QcEGsOgPCG8I5Ij8109m0B2u1fjHLQPKAbm+W80esCjKP+h2Dwy8bnBTykf79zy3w/R32ZxHmMu10IPGP5lUvGs9rM9iwB8K79sBpD39IwHxn/u4I7iXg58AY84TDpgfwx1Y1j+X2IK+PF/i9P2t5SXCJ18gQZ/rPrnZgX/S0uPPY3PfALUlsUWjBXhnOT3dq5Kh2qzr/9fd8F+XFyxiflvMuHpx80lpL1eLO/3ULNHfoFXmPD/o97T/g7jH3XxKy7v3p+f2bUGHkOb14KYZ0YX/G+uhv91iJ4XYDC7n9hj94bLi45MIN+10UZ9AWmEvT//hY0HVXGA1mQeYC2vug975t+WgoHcvX/mUQ6MDI6VBxeL+aeMPW151P/W4SXD5AdYkDWp+PkPmPTKg/E8zWiT0APwMOVsMNe29ExdPzdow4C9ijlpPFALGQPC/1sn0X8SniO+rxywIrhF/9IMpZhw/qwpp6S3A5f+LDF43ls9UN0bBrx43DDD1vRe+fzABrTjN/zmYstaB4yabdQeUFum/6Xei/rk0cosPGYYcyfe+X88FJ2bbWh+3WU8TH39Gt8YmEdd2qxBA0BuVXq38L7wfuA6n28R1Xp/YwD9Brbhgy7atO61nflfvv/8+WPvuR8G/odzwKu6m0rCA+Z/lHlhLyHmOoT1818zv4d1+I8j8GN1r2eMMSNOwoKMM7eDQ+ElYIn7etbu3wnkOOM3feEYreEztQKH9iO3Nms8eWfOJ2mkyRTs4t0r7iK+n4KOQfwh1yOX/RVvHpjw5QcQkC7cTqBlhBnLqav2e+x/aRJ8EPlc5/uEDwWk0CGC2tR6IGN+kpNbxAMcNX3jJtzX33f7BoOQ7twHK3u6ja/tPfu+Z5GcN6Xb5r/Dk9xfNXZPDNvGiznANHSSTIrA4sDXixMAH7t17wtccvwL2l9Lp+SCMR63PNBWvnHYm8/2AdOe3YvvHUePQ/+v+tE8jAjAsQFbIj+W04/zwPiMGwBdhGQxkP2fQdczsIOkBmCAL14ANn61N5m8APx8ILLozvsxSk6TE/AB0HoP+M4WXYGTb9cf6J5H5Zx7/z3zqruTFW4BUIRWB/C3+V8e9gVyntc5nTUbHao4C3pnWNgYgZhD6X2Y+piE5/T7ylMdgOV+e79UUGRAUvg8H93eLl4uiRdc5oOYH4JHOxEfJ7Nh+rPpHnPgCymHzsoNbUYfe7R7grwBD5mKFscJM6joPcGhsxqu70AurAzdeJ3pwUCPo7ZPYYV9m9NKs97Ux6ne1fZ/xAnXMdiG0qtVld9buTvE8xJkIzs++T9yuLOzIGHGoYrFr9hwoeaP4IVaM/DhyTqXfGCAoN+MoTH9uYwXav+/2R0cGLzZ/8sf3rvlNUZx4AQ2x/y/i3HznX8xzfD5jb4Meif/al0qY9+NAwiA+P/6w/xy/6df+ae/B4hJjo6PAnumgYpnfffsrydE/zYOBOpfmx1AQHHA4APi+c9RB+5HMHDOa+F+4HSthb1ywMva/rB4wd6us4pncUNU7wFbaZ7vSwZbdOZPt3/u57R9jMQBrIj9DzNFH4sW/Z7z7rUnOAeacIrjP763qXlkpbgZidHyvV4fwy62c8ZA7jLuSJywOoHLyBv/5Rr7A8N38CoPoJXYRNAet4CO8592D+As6Tja87fSqV/7O9LB8/NrI7uPBP+vnrAI5+KE9lG9mwljxhll/qrsACqLZ9sBfKj7H+aEE7tu9l8eJg3ePwhaMR8wm8rPfLZWHWyAovbJ97ztt8QrH8Iter1PuwMbwCh1ghuaJ/+KG172wC5ABp3k0Ga+24cdCIHT3LQnB3Aod+no9VNrOn/TzpY6ifekWlmfPhu/+RxIszfjgJ/mkzLuwHPvxGTH+EGCMXb5Ee9/Vg3jAPycP902juuMjOCgN1Cs7VsxG3Juv9H6n3N86nnPcRv51zb7iwh+815t/8WPfd6Az3Xdn7B3BjD+FK2ypW6A0YD4y1BvTzoax10KV/0H2wHQpi92chqO2PhS8o8nIWqAremlaEPPQOIueHvOum93henywrAN6mnAFyaPI4eypMdRUy/dRtYun3XGSflP8uxKWRMAnn2Pn3W8BgEJeFyhbtp7NI57JSw4F4fe/jzZgVR2oUJ2pk/9oKeMMIHwO0FkftlB09iPoucmPWCEt9u+6sywNvZPyzdYtuE3y/1v0C8ywtjzwPmTphnQXJdSYg==",
	},
	Power = {
		Width = 128,
		Height = 128,
		Pixels = "KLUv/WAA/4WVAGqiQCVBYJLzsMnrRVdVzfhM7/vU8NngSdQYD6klUqPbnh6xYXF2yeXood1/ecEqOmzdda4irFudWbjlL9KGfyQ+nZl4QAMxAkUCSQINwmaAdTXhPT4njke16Cg5TgJF/cSr8CccZhwlTAMD3+PFAs1af+ZXwIP8Tgofb7lhQRm5MkjqKVp+RxGj8ZQOMOIcn8rzIWh+h8HIMBZg5JH0zBeyMz9nBeRfXKK0VmyGnrTgdhUPNa5CZuPJMhsxInQcaUWPd/1BEkZ+zIWLrMHzwYToWwmir+R3vtLf+UuA6C+R0Wcip88UKJh+06D6XkL1g/5YUH1+zkT5krt1pRfglWY3rvxw40sQVhE7PjTu8So+yIcNRnp48eNkMM4RANVavR7hafQrS2JfdkD8yhmOr6Cl5Zh54/Htisdb4DN/ixx5ssLzywxjoG92iNbIvpOL9cst5uhl0eacicR1ZljgmWo6zrKm4022HW+Kd+CMHy9UB3kkFuZTAf54luD5HQzRiOl/KKdBJCqqzxaPxrh+2eL6OHw0gfeWGn0zaOnN79ibYoN3hhDh+OcIHoeS4PFoiR4xY/N37iLPg5f34z16LM732WuB/g9fX/pAfulr92jI/4wJwhCruJly546EO42o/sSA4tC1xkdN9LjU7c3Hp3AnHk+Ng3xVDnKGb30HfX7sZ//a1wK2fx2Lu1N54LcKyZ0yM3/2FB2KZPXolNmnYHOfaph7CwrzW1KYbx3PRd5FxY+/rPhxmLrzYezOj7nDQ/+alz5WL30ZFurL7Kk/02J97AnFx4DA+/UM71Yo8KHRZMhdFtn6+YF4xyC348VJkKQ3PH557L0JAdAsCRAu2CREaiNQgC/ZengDHKcrpzBfWZ78Jjljo71hsM9TgkOFYCrwC5JE/ETFQVDZKrLtYYICF7K/VYm+NGBq+7Il5iK3hK3wliH7UHKDIlw37zYZ4tSGd5N5XGgKfCq8RQwx2F8YJlctvmK9ggN56Bh1uw7bR1rqu4AnGCpEYKnyQFJY7dZp8kqPMQNi+1dslQBT3wdAFXbBuFInCQSqRN6xMtWdbver3D7VnJLF+QJNfScQVYgC7vvKDIRkkBOUlIm8a3G0WXuMGhTbr1Kxojz5SPftBKQMk1Ju5fvIK3ytFozHidBz1A1bbP9qxeClywPMA0VrL2DBUEkhfOYLNgxB6GeLjzHM2P7S2FrJj9cNXIihnHo7Cww2nAQBMPZBOhJrbJ8GgvYka3QDUzEuQnW4/CKf6aM0Ir65tyLjZJcf45iMvwoub9l0/oD37iJVh0wpths/60/SEdmM/4GjyBV0xR+xYilLPIvT2Js0Om+mkICUb74AG38VlxdGoeme5ArxJFhlLbk7uVR3YmdCkkAUjl6Tox0vnc8rYJL7gbsM5UpxqFTZn0RNIiIsJyNv8IN1BFmJRwBO1Gp7lMLVpRWuHgWacKgDB9nsodrsozTZtzhlveWb9RcuNZer8KU1WseQMoiSGvMSKb0n2JopQTi+2Z4E3VeAQfEKuBajMdUnb0SW1ZibLLW9pGvxC7wYw2K/cTgkqY1wBlV7X5CB8Qy+kio9UDfZenETsMYdtx3XAAh5Lj/Ia9sOqDQJcid/om6iYYOMBzApMkBXcBSCw+GXVHBfVsF9xerqxJlYJ85yx50lK+7NLLk3wVso1BpxstKK7NQfg7Gek8E+F4lku3YFPl03qfHexMb7EiCvJ+CygdO4d+r1nJBRXluiip2cobXAIz31lUgorlCCImILTFpqoX6JRRpgPULk9XP+JIgDKzSZWDxdjTsbPfSJ/tJch+uXMX4CIbQoRKCSkxtjXQ32jd1TIPpbhWkvxbYfV0QgE19W2FjbIvtvdlxmNynGj8eZe7wPHeSTWEQ+aS/yVeTzhkK0jBnsq81o/6kwajRC0Nu3PtgL9l3NDHQtx6lYPKZpSERywe62CTr9rU92yL5jyxt8dVkCgeojRm8RUPDAYKg+1Qv1KQg+ikRC8AlwfRONbLymKKgUa80X6FgdAZeN54TjBsP0tVyg/yWjn6OHbRuk9vw82+PzHSjwJXSAu1HaXRR5/bkadTbaz8NSk1OYBUVkR/DFmzDX41R7LSCt+PrMt/Iz/+ov8mhCnvk5dObr1Jkfc1Wh4zBmd9IH2juTJNga7bM+PueJAh+oq4Z3prFileBaD0f7Kmq0H7YQuL5YHF5KzdFPgLDOQGnESxvirV9upzbdl+r0/AlNBt0cvljkaN/uRvtniRcE2e+RAi+vNyncDUdxInGUbwnqBhWfQoFdqoT1dJkmseGZldlHU2QfywXVIPs2Rd0EPFwpLQ+uZ7pgV3gofEVoZcgC0YUztxfOImHqLEVTb07gGnWr/hxikpm506kSYqGFoxUh+zILcqqOcv0Rg3jFUiXJVcnxfZepZenXXFWq5AVikYlDtAUT+Ym5CM8gXbuwSdfsa9BGLpvX4y9YYceW761P4E9BrMwhmOzTnY9P6T0+mTIwxW6cWUV3gxBhsYD48SZMNsSbQnLn2I2zH3de0Y1EAd5eKNo57IzJRslwRNPOf0rA2kKTNlzKAfFPmp5nDneqdn7UyyKNQoOcpll01DBile18qdPZ85qlgun+pFKjOlyreMoE1RrifBcAL2c4qk9n0h0ujIjzp9zbZasuBg3Hq0b3YTwgXkeg/2yqpFQftCxtwLah/4Khrjr0nSGBfkv3ZkC1t91mS6BP5eE2OPoA4lQhoXFDX5qy81SmCZHjwRv6U5lsAqvBrzyf3ttBhjovnlr9HRs49F223xIvijvkekSX/tsIxLUa5wT62qewELGjlzqTfctNz2OS7mOdwk4DVnebtLIPHNsThLj0M8gJnuR8vY7aLbc/0GCnI5e+OMaaRHl9OBoZqsuPkcw37FcK9604Pbe17L0hI/OgSL/sxfqEIvtJ3ycSKfLLKiTHKSP7jNMHx3WtwSUbHEFQB8exY1VC9zAZ1rBqedIamhwz8s9c+hf41HKL7JN44Xjq8iTmB2jK43NrFYdjr/OBHKQifaOmGwOINTlG9p2uwMzlCbX7vVUL7TFvic8aoRXpF7EdrlFcqUmToS8FV4M3QYlwP5mNwFxBmS5hvSWDibugAdpgoQ3RqT9BjJiikX0xuAJJdDBP8JR3YmEuqQSK+rJGCOpT9GiS1aVfsOqa4c2dtq0zK1yPv1jgk4PYqALrTiQISSJCQZIkGQ7ikRZhEAQheVBKSQ8yGRpBEAhhEARBYAZBEAZBGA4REEIIIYgQYwwySqFT51IIDdTmP5j0tok57g8oJV+ilUDGBaQdMJJX7BZtxXg+z21kAKMHqAFfX2e9HmgW0Auwy9W6n14xAPwVRx3iPI4CcR+w9ZuXXmoJAQOyeM6RaA24eB7swfABO+oDKiGW+DUTB0z6Kg1gWvEZEF0MMK5tHP91GvAwpHCYYBg2GtB0znw4eP0w4YDl1weUe2YGcB4dEF1MKFrtHTwgCWVlYlv/BzxMkFgNGnBcXqWN8kDH5QHNKQMYjR+DmhZ+d8I0oDiTGbBo9AAmpiM6eYFrwoOChn7AcJg1INH5/yn675PAgIALD4gxgIhjhf0NOBpxAPOgSf6vXg34PAYQjZZN34CCQgYwG5vQ/wvzr2YcQJwaMKhlG9Cz4UEOnBr//xd7Ch77/geQgQFaS0XlAIJWHxAcJBywq9L9j7hukw//X6zqgLzLP7AMfSzjhp4bBo+LA25X1s3M/Sp+MGhZUy5Qwv4HVGeL+8ff8bBfZsD0zDHlBQ7UF7NjCxkwazrIxiMJHS27ft9vZhkQv0zygBPu24qb/ce3mfwBT3LcAzZrduR5UdCpS+AHB7QzlDfX+5eXyL0XEperbXaZtWPAcufHFzEHzF6tcmK8YFKMsLnLp+JDfjVjeq6Z/aI6A9IVmqt9ryeHlnP8nTZHaed/sZ8jhAGHRYL/OZyy5cDZJGbgZoExoMjzFHEdcuJ/7m9ibcAo+pOVTbG/AwNWj8vZ38XsAUDlAO6m+/7GMTLQ0vidd+T0bmF/UTIHHH8+CEsNyC+Cl39vQMcG3J3rAAPaNWBCePdA+PTfKvNgf9n5uP0svB3QMvodS+8n0RD/E4+FWeabNb+bDM+6v1WUAaw04OH+0Qr3JuBu5hcEqs3w5vnnuHhrD7DzrQbjkvcBTDXgKOg/q1F/tXAZML+0RG03DMN7fsOA2+cL5/skj8cgdQDjl2cHcD7r52h+QTlgXB2s87HvOl1Zxt+7kWdjAA97/5ra4VM5fhpz7KJbQTfnFLQDzBVJ9/Q1gC39Ty8K477wnpDt14/7PQNHgBrwwuCBirSP9z0fb94wb0HRAw4YYOT2KdSUwleFZp4bK7guoy5sKEsc0HkdgIku4z09GgoEfc43oIzW/2OrffUhegCgZ+gzwPmCERple6BN0cr+1z9gzNQu2Yqt73tbR0EvasX/z+lb3Q9BHUBea0CR84sQ2j4hoAPDAM3vEYCfGNeP/4KGF0IbDhhkwwB5/jf2/h8JPCFv2BYAAQ4A6mNAv/mlAjqw3DT5fj7RIGntAPa/X7TxAu+0AQQGPEE369dzyeKYNgCAGXC72wDf++G+OND7f+aD+56ejbuPO1MHQMl8O+l1zqqO+KjMezqBHfCUigeeoWMAxfdJqAcY1HkuwudpgS88oVwGSJhftuSGDkMtyOCJw8B/28jPAR5S/I+v1326YceB3GA52uEXNMprgOT55MIt/UdSNPmVn04bYyzwDiIDyGGAX/fzyzrf+o+DQo+l/xkNvmuJBR6rMIC0D/BEOZwa0OfS/HJn4f7Dr2Attv+eH27hKK8FBuwbzT+A49QAMqXseYDt+SWe72L+ewR3btjxpy92gOgDtcIBPZIDhB9wOGwANA68BnT3WZDC/t/81DLe53Y+iNj8ePX7uT16hf/mXmEtsMQ/gFIQHBDU0cMBogi0zEzsv3iAk/vkx1sxto8OOWF2tR4Q+wu8NcDQB+DvHKQPEGyAmHwX8rFSv2JMDeju+eW5vHCp/01hzrgx5xM/xcD9wga8v941oEs8B4SSNAAUHBiVD4gyOUCH9gClz9DC4jL7v7cm/g4Y8LTUgFiICwN8Bm8AYHnAzzRg8IADboABpmECYHK9/4E+VJExxMvwuS44XyndByYaqwGSFAwa8B7u8HzGA02wIx3Qis+AwKnDaRpgGhpQqnEelLpgRx4qE4AZxjeiR5zrd6SDZD1QY07bgNKn5hfmdsjoWi5XenHmEQFskBoQ3IBv7AlzHagZDLDlPIDgxM8PGEX8+YXXF2GYTakb43WbuF8HiP7HpPs2PDBbKPw+1ijIGCBuBPgRON8iq611zyn+f8EYbi3/wXLLfCrwTcPrLgvR4z6AIAOSwfMhK+BxcPcxpgFkyQ8VUvDB9O6+Za67UBsgbPeMTacS3tbL2RxcugxpV9MDpPtvhAOS6gUk239TEITYvbRu6zJJfETdA7YoLMlDssvfD8cJWqLDwz6XVRQDygcI+XzgZ48eZk85+p+tNyOdmw/pAaY9oBwyALxdYAHgfzTuojle2O+/jbQi6cnfDOkAs2zA+O18Sm9qCcEzA61DRBVP2DbS9feBsv4GNG6nBIcfyaLKJ4zRAW7Gxxmt/3+g63VAe7aBr/BdoUDffjssaX7Wf3mgiz6gni1wl99D94DoAGL7fdum64GSC3RCDIBYk1L6zhYQtXTgeQO8p+/pjG0GGNF+0TXZ8BqKe21AXnzzkliwe1Y7zQAPNsCNAeZ8tL6VYZUGaTe+qGUjjhAhAz4ASfN2uTjSDfDYf64pE8joV4QSrb2evgOwfFL43zsLE4KwRuCADhoLZuM4MPQ6E4/5Az6u/78mOlVyD1Cyj3Bg8XbJiRQFegCxGXUTchPDABT/73n/nqWv4oDaygF75b8HZMetWAa0T+fXWoV0bl18wMssr7cB4l6IMQVDyBMWiY0e0J0DHRFf8bn3ytLhB5aXXYoO1GT+A3D4B4hgxKFfiEQ8APPABOsAoUGeBGBCYA1zPbD4HwMPsAIGzf18r5fRzl64J7GYAyDXgLFzw+mIbPonwHLmJ2VC7fFOcDRA5bJacUJiID9UYBjeuji8HeDBZd05uiKGfGEiXuAO6ArOTz4krwE+3gfgce6Gc7nyJIYOoN7EBdBK9oQBXeyv7l4BJriz/gF0eQNEIZJJ9P8yQMj/A01wAp5VH/zryr3QlVaXmm/mpg6Zf47mMCxo/2V6qSM9xJEWODcaBTJKwY/gAQX7Zy7FjkKPeOgW2bm8IrF/DsbPLHKA5b8njgWVfboPbRTK1gAjoVkXxPJAQ763wdQWw3JYlEZjLOza+b8biGkdE9Rias1cKzixMYYk+zNsC6Zlgwz7gJG9sKgP8VEfzHojx5iaYpjCzgFDco9DteLz",
	},
	Lock = {
		Width = 96,
		Height = 96,
		Pixels = "KLUv/WAAj806AOY76DKAsgcGewNhkKEoo4MMo+rQuCzRiEJLXBJlB62lwdAqOhkbMjQm3XPsDcN0n8thmO75CtsA3ADXAIR7cn9JqCbenkr6PDIlRDotf23sKs439/fo1Ab4MJGOS2Hf+49oZJ9wMi0pw7+6T7TjctbdytqHgPBP1XR2ls20EAPvflWTkN6/nXElCuJ9Kyd0WetA8LusmhQH875RT8xPGWUxvvcF9eT6rzVjId9/Otrh4SUb258Gxm407PvspyJne7cqfCiknr/3XnM8/Ptza2EfqCblax8IygBjD2/0B9WQP1bUEV8d2yMi4KdjE/tqYlgfKsnn37CA/K91QX+enf3X21/OP5/w3w47nWU+/uH9eawDSBwEBP9f9Im/C1X2szA3P+pgwIfF+/Skg6uLdyrWE5F3euAzU/KZhMxMcDcxu7cx6p2bTP9W8eDMvlMABFzNizv7Y1lpgBBwFciMojeH9rfUSXJnmVbUHl3aR/KJObfTRjnvtrDeucF94Hur/RgTjbHMOJzjErLm0X51a9+Cqmf1Afgb2Yc/5SIY1z842z/rUn85O030tW7SPns7dxmgndvXeREB4Mkf3qj+qyoQ7+1nw3F9l082DcxKMM/9pZJ6aFA41MLWGdifJ9cP6sUh8Gph7KGcln9RTejoRvwsKaRZp7et2nZMLt1eJ9asMmi2/at9cnPL5Nw2zen3e51Bb6HcFG469fvF7jhF9YIPVrtDdrju2+Z/WklWvnSqT2A/lgb9yXGT6ymPd9e9+blfh/Hf7SfDdJvrdOG8Im7zb5fI+n7LRDZix06ce+U2/5Xl5uwBAlYjHhHOzbUVY4hffDf/T4dsxflHis8/xtuCbv63RVdV8NfiPf/etskf1Q3C2pqhi7p5fOIIa4fP/3W8wuvZl5vd7v8LN+WvYnypFNjv3f9cJCydn1L1v8UZ+hVsuL/HUYLxAgAE+pOH92e9LA/L43q7bLVCoQ0b5A/Rw+ag5h8/hM3Xh+4fn48Qm/9D+pGq8j8oDX4odx/jgEFUVf4Ik6BPII8osoOwmrHqc8Ai1iBmOTTEzL5e2wwFHzoFeWX5oWc2voOMZQmnghRqy0o5pwklGtrotp4Ae5Xo7lpWkfKKPUo+S7miHirSm/W061Kqcp4atXlV7FMjN+oXVR2P6lWwqHcP8+5Sb4uQVQxzKlah7qyvY1cuyem4hmyfhsVVcxO2zKLaw8ZeFZ5JqSAqWbRslmFUqmv7TGzaxTeBw6gBTaeJyJKUhjHxVCYQkcKa5jIJKAIEQRCChAChEISAZBACGiFoEIQAQggQBMEggoiRJNcaYVENSSHP26q4greL8/m4GHV5tqDURb1wZtsImHtFMfAaKl83/xcHY/9Hx2+84QHzcIefTmlwb5yLcllai4CYJ5a2fj/c2CG05JFZyp85aUVbJtHlUNkeA9KOS+gg72rBmrAnvmiLdb9q/2MLvZKRCXYUqh86XZjn+szbn9PJQfbNl8Em9NC81PPHe3HJ33F/09703Zx7xQNSiw3eLvK/96b5B30bYiF5IuaV8meT8zdkwMAcu7j8aYkXhyigQzAbMnoANYh/jGUk+2yiv11CmM7M434zglTkByB8MER1+YUYqDdjvpeCU2bm98dcLtdPxItETGD322yWkSBy+cEFnUs/eEvKhsANH6rbAakbj/7oDp8M+eVPc3gHYooaPsrFJcAjj32GfZci/MY3/AeBwee6jbi+NWymXcIHeRKfEApinzx9Kj1YtNkQk+t5JhqbQTMVAr+Je3kCoBVOLMZkxxWSOxjx/0gl8nBe/abbssvdMNFtk0XkNfKGK0Ar3CBmHenCrINKKui9l4egaj49OZV+EKcs8t4Ril++2sWf+J9sccGDv7TfwDRYst77zXQHZ26uJ/6TcWiq+HD7uDL4XvvzCW0O3p2HEF9CafmI8m551CC46PZOdPkLfxGJmT8Q2htYFQ6b8gfUtoPDX13m6AxG/+FDnhtZP5ppP+Pmnuu5t7kYqJL5pxE6EeexJehTv30MdbB4yUmMzOnwIWbx4Bgy+TTMOZSyknsfiUFSmlnl4GL5wNHk7YGMOb+RUjEJ9MPmYXkxh3SRy5Mhg+RG2cXlYQZWdZ9ImfErp0uXQAK9PHsoK+xhKJFmsveeoHTIoHPyxGP5hAD8Px/ap7bAhhmk7KU+nt9XkcbeB1tfgT9aKeLZpokMou9nlrugywGchj9OHRck9vOX2ENyjwFw2/C8M/zeRfc98rgOonz6p7q4Szxq1l1v4mmruYOncM+j3XT8h1r6P2rIwiCvn7m5RlD9LsG0kuW12kv5zugVxXaYSfMeywJ0sFxyGQ1G/VlFRIwvRjOsUgS3Py9cz3XjG92FcuD/UMWH9jSHZxOMP07wQ9Sem9b6OM/EvfpDa0VP8mXzXc/8mzEtBpPS6V8MocuCSouR58vPf91dw4ReIyafkQkWWdL69qyD0L/DJ/4xACQO/64o7mKWJ5/mW/5DFxoo+ESYcTnR6LaBitYRBQ==",
	},
	Manual = {
		Width = 96,
		Height = 96,
		Pixels = "KLUv/WAAj41gADpOFBMnULYHfZL0rNdade9n5z/n7eFzLl0Kyvqf6weMwygAAABRAAAAAIAFJgElAScBXm1+f3x0c3Cdl9BH2Ct3EuxtL6fFd4rG9qm3vD/27ov4VXZT4mCrx7/JiOezpY19yktLUdchz1e7KO6X2xLH6Ctu3rSO/030pNtPafGjsr3I29IY0s8PMvdXEYx0Fm/zxjQmotWt95un9T9fDDOD0u2RpbqlkbF9XncRzdSBWouXy/Zfcl7/f5yqdZWmXw9z/mt3gd/13Lzrnffb7v7yMoqNMHQ0FfXC88GNYyQ36YYP5+Txp3Aq/k+Kw09rFGi+80p9VTwQftsl4m/5YPy7KXLmzkt8U68O/uW/wm64G8pUTgoc4MfZ3ls7De7UvPxwwiZRfPPh/8eem5c/jm3sG/G8nHxAfPcRz++zg39UU9J4/LvF99UfAFYSIDDz7oy7AwBCKAYC8vrfTIXdTek4QOEb/SNs9hkI6avEcVcshX9KoesgOqNArfVG6RtduRT+JmyJSm2eWFVOev8bG0Hr+FhCrQ8R8/ivPOKyYAp/dFIVGtrYKu78Nv/rvF0+FTfstFpKLHM4HiTbmYc5lyXcGlpxKHGstPTiqjKjpFs0h79J2Vo9Fs2U1/J+VpAhFodVl83hzyKJ+8tjMDEvTVe7Z+ts4RqSBmtt78I5fB6LP7yRM9We74v3v7S9XBpLbZ515/BHDyE5ZW2NyuJh++9aS+Zbe/7vUtl/Ehj2zQ0MqNDr56thDVsSSQyb/fk/ChqfZmqsraNp3bbrvPDbktaX/Qvo/y5x+leJU/zqpqpf7oDAYaf/q21PBy2dxd/mD71CFjaYXm97O+s9bw/pcbtF/L18Jj586YKPSsMOKsPwtP/f8pT+9wxRxgY/R73w3TUQv2yIggnGQeR8+PtFdI4KIy3/Ghz+j4h4vkv67PUzQXUXpVEuQYu0rH+5jEacX87pn+9Q8WNpVX2fNRmhr2rDjKgCHXj7z2uTiTuhqLlVCVI2ESNEVD8taE8rpqb6zYwotCFdnMkOGWtEOdYhCGWOh5+eC1U3An8zz2i9V7XK2plAlx2WxIFX8X8oHQYkbSrHniPSH9bxWfvi4Zsc2k0eSwGvjtYOkMF/xAdpLdu3quGUJ5HBH331ZsNOf/lsZyz+Z7666gZiddCQKKBIBv8SuMoTM8YX1DwttWy1z18DzSfolMnFu9w2D5TjqZlC+cnIiHr/pQtmeaQ03k3kKlUqheUBM2Al77tbTD6f/8cR28dW5AfRkfpkMkeAXe/3gNN+Mo0RCBLbx13vJ6918PL/I442j60jHnqTa4xA9FxADmYEAuJ7+U8mAgsDkmjwGxrbGPHlt/CiLqpuHr7PSXzs9rtP9NXVus01WXwunoivxEZYfQ+JBcDiPycLH60oxO9FJ08sSOJD4dzHJUpcPRF/rlz+8/0hN0YOem6M/5YkBihJa1M4lX+mRABnHsaCJsRfxnwXKGqhe7oQqcoLbMsUsbyVLPSkMn5au+Jb4UD8HxSG/y4DTZkFfX8Zh/OX4v4/aUr/eYW/BydqTGgi49c9YSy9dLqQD0YGf3+ZZp2WC0Ja/rR3w+/qkdhTM6pYIiDModS7ykorfDfNwycTopgiIyk0JVQzagmDzqjiC0+UEQVJIY0BApoYQSCQZbZqDFIRGGEQhmF4BsEQDCGEEUIMIYYQRAwxhBBkrIhErQFGaAHb+zIBm1e8VKQKdEcONh9D0Hk4FBXPn4PPlax8ofD8jQve4FWoeyiMySR7Hf/xA+abBNPtaY8YQ2g7v8y74qu3t4zuOyvn/JFs6Oe3J/nKU1pZ/MOEkWwQj9W31+7CjT6RnZXZMykHZWcQ9bcLbiCMisA3lmr+nEy9ZRfPgwbhYU5yzHlIb8me5SNhIywtc+Ph+6v4uT3+L8yuyx3j/5otJU6evP7jJSv4tSub73RS+se7k+oLdp3Dqb+t73QGbXjmp54q/fMZbxmnCwlGkwD2d3hNOeIB9ivCzhX78Rb/0Zjzl8ZyfjJ7/W12aiZUcosi/P8fotbyI6j1vl68LDuEwv8RmyW/AKbS++XxEPiOV3f0qBiuv3yy+LC/m/KXeasxmIEimJ65Y1tVetW/T7InS2yHDj45uGmSPmSCt0jxdbw0dBHnTdkBEakd+Ffa+SeCkwBVSjqx85fleJ8OrasSeRcGqKBxZKhG/77uGXQMOYlWOWK4Je+o11F1sRAGL6bfOj0OlYr030GgFfB78CS613AO0ugTq/Ot/aYf5yAGLr6af9J3Ga9cj+LJz2E8SYfDTwfXbyea4wdC9iCLXO/9ewbjsw07DkEXJwuTXLPEGRoMputluOu//k4BPtlga5bv32Aw/tN6nXw9ly8R8UFCU6JCW/4MWPZ+Bu9l26LdvbpTj1Hpy+fg/ZTjm5Cq9ubG1IcE8S5/Hskn25hzZs/8ZEv+tx9Ud+LU5z30Y0HhD4yvjkLmptc/H+iskIMLHosORunGV46QrfJfCJMoFCr8Uge7mJrz/O4nLApzW93+yrHc5lk7eLOpzEuRUBf9v5/6R+YSDhKINBjkn9JP0SC6lb9/I25STpi2MraD9KZMAVF8mJ+V/2f+J8bqPYFIgbvAB10HGuE62YSUf909CX7BDE7NMsYUZ4H5dqU/U4562xMLP1j039mXR6Dnus//DiY5eoPvHAx/7aSCqbxffza+HmMWawiC2009iwQYZCF7TGqytWRFY+PBFtCBC3hbBCs41vd64B9WxJrpUhUDPjlUs4J8cXDmLP0HRwwW9S7mHAtA4uRGwfE49sOoU1CPqmufsZCcdw65J6VBo42ffN0XRlYyiX5FV4e8V74rZiXXPFA0f9Vb+S/mg4w7GXxxrmr28+LBoIxWnp9FlMUhovJkB/WkNxsxmoxuNsozhbYTtoXlj2JVJk81JSEKM4M7vls8fE7C9a/GyOKD0b9dOPvJB2c25H/FyEZ8ifzghrkLzNeMY9rXZ3EJ5SQGOaZ0baIjHmHYS9TPgf3fyNmI4EFyZ+duDcbsv/kl3hefSg0PdVPTbZT84LqpZoeveUtpkgY/Y3fvavR8687kl+tKTGEM8unekKMniUkJg3/CYIiptTna8T/xnGMfyjHVGuEHOw+3JUTcujOJrKk4tbhTAT11DNL6CJstO/1G3Wn/O52lf0vRYAm6k78n3YFYQmuJawK6KWzQ6ujeDVg+abLdyIATQ53YGuRIRionk188xJj7be/gsalqwmiYA3kp1q91b/gv+hltR82gOD1pN8/PTc6/6JUAoZdoLopgPCXgZ4Q3ywgl6R6L4T1rxqIG02iOi5mJJj7ZndlSznhS+arPip0qD67PaHCySuw7NfyMNbQFDTqk/5NLuLEEc0B/qYM7DqPZLxB+Nym41uAFemIC/73BMKZCNNgzUmLs1DkoTl/NLc+p2QKhUdeGRcjBFVt/rL64KOwek41wmc8UoIRTD1ZNTXIU+el9gPLDGC4PimKC16zGu527g5E/ouQfNwz7YFaTG9IV3P0WDVZN3RhVzK9nj0ihcWQ76Jaw4mS5nptW0DbVGDyx8w4vuwPir0z3GDza2aiBG5OZn4tjGZFh8kqAg3xTtsVNk1rGc8YxmsWnse2FiYy/XJKkyrDuBHx2+ygaNEtnHQx+INcOh9JhyUfIc3BtKu9o/weJpt3H7aV9migYDJjk+bX6KMrEIEbnfiSs3Pf8U9ogiAnwZu3o3Bk9mg4+pHppoCZv6uQ/BdCcHyPFQQ89qmWm+8x7w7nw9b8G5LPI4I+q57QX9lcY+6AvQ3wx9b7Kiv5ro373wXVPCX+MPLqU5/bxo9vuuZ5SRlv2K4lzMHhP7XeidEZKH89UhWkrxhZ7ffBY9tmLyDlqh00+k7z9OGiLbqG/DVCz0MTcRmgyFJRtzh00kZ5ePofHqydDzpwVNFleGwwebJbHPYo3F7zbmPyJ7tMbMyXoDb4NkDym7Vyo55/7TWOaxCMYrq/7YKAGGCHZufbqTfq1K/+gXDnxcZkb9snh+Hu3B+cjab25nc4AJo8mJpFBjCCqn3OUzu0M6zpS4w9vu5Ny3h/zVLZzhedJps6ABMagyUoxJzQ/CVqPrqOJF+dMRslbgbhZh6EJSJjzPIzVUtsD",
	},
	Frost = {
		Width = 96,
		Height = 96,
		Pixels = "KLUv/WAAj+09AELMKCWQTQfwt+Bo7Dcnno/1oEIjSp1SRMGyUdIZZSrGUpRzUixmZAYSnq+p8+Uvv11ZVAY/+ZvZeu97yyJ7CFnbaVtvHX31Ut66TLkVvXX3NW19CuaU6ey540htQki9s7qWUfmx3kQKazU4sdzHmRh6enZn/dLos5oUqt5TQbwzAhyJ4T+XBIeqx2sghG6AFHEkmYbgMaQwCveVY/AdyuFBvviRxxKDNKhy1kEqbQeSQCiCQBSExUDa84IQFAFEJugIEAIaIUhgQuIEVVCUgBAlECkZGqs1cXOjRtCdcRyKG1l4/aNu6x11OgQj8XQqLFkde/Q6YO+S32Kt6gYRG+jwwib0MI3t8Cspq4eoCN0bgUm+xhrsI6n+olAWdO6tP7cPg4CKEdBZfkLxeqjShh29UU0+kJHQPPyAN6D/RsBEe/W0DeWgb05jwRNw/hGsBvGHGk/CD3QRZpBv5UOJX/feR4SWFvvVYC8MfhD3IENpPy8th8RGjC4sN1AGGSpmI+RY4Yf49/zz8sYQG7kV5qJaYWrOITtIL04bkzKn6QM6JnoILA4a75e2N9F1X9ChaSOPtocyWqIsbq3n0GFP33chobEE4XWHOUPH13fYW5fA9kcLpX2h3j0tfPW01xQYPt8YPn+QbihjCbv3kFr9rd7d6DGRNevjIGH86JDebfw9e6nisxtOp8k/xmkUnXY5lHXG0Wo3qaPAfbtHu+dM/7tkP+HXwJtDGuIVIYKjTS/O+rrhIMb7MEkOBfEc4ZRo8M90g3coQTEdmmseJnrqVpP2ob42JgYLRs+dGj9M8KZZ78ypypWjIrZj4Leb6N9FEB92V8R7/ye3gbu2id7HSOdpuxlM2O+9/RFpEhoWZ+jFm8GGbCIYrBzmsKH9fsHzmuTuwfzFHVUGp8E/UrhZuXG/sb8g6YDAkssOmSXU6fj/+Y/IjnlwGmjRlW8PcL+XqPjcIxGvbDUPBdUrnNCx+vzh72Db8rAiHuq5PPnXKFhn7gyyc1zhlQ/qMm721w8686H4IahLDf4eRs98TrdXnu4II6M+Q2gM0EYi67H/46o+0htW/pkjnvDkYfhH65mMd/hDLNYAPOx1qQ3rzI0HiX3lcr72YGzGYryaGQThOdO5rocizkbmFC1YeT9InbX/bj3snu38VzqDiwGyRHK11q7cvAl6j3tk0OJQh8hzU7+TPosjR3Dl7e2BumGZpV96P3fn2uAwT8z8HiLr7f3Uunrz+siDqR7sT7j5zqB0mHVu38u5t0PgQWa0txz89xp9tTkYf0+K+Hc3dbfHm04Y/NtM9KvkM9v/6ADe9YNngM5GaJVBxQzQz2/qAS+GJSw4y2rGMjUy5cPod2Rj5Z7Bt3Pi+/g9FM2LHXrr2HlBK5+N8zii7AD4oW6XUBegXtyD8qOKUfDoebJceTutfH/dgdjLIw/Fz95CmXu66tBxsD6SbHgcz2IMZ7gekFUwZdeCh0gHpbeeBdMz0XMTvof4nd+vbd7KjW7t0z7UNIR7vVkFuhNIucCYa70Zjz1fObnCiOca6uzCn31ET9/k2FOcw4LM1QjrUDrz44qgZ9ZPkutefznStIpkKKLMTHm1Dt9P8C5/7RB/D3chdZYkVT0/SzY+Vuiy2hHCvFh9Mx5n4TQhtqbsMyJdP4d8xy7SmDNofZUZzOxlznay3L8ZfU/vPshDCZwwwGQZv7Goi+3PV/4bCdXkT1q2tu7L+z9jGO0ulXScVG7+3RNah84PUidm+B45xKuBAIxbwHGwNK0KNZfwM7tmGu+8J/3ndjEBC27O8TDki77DP2emh9MPiFrKcHB5a8jpuhN6wvWMe4jfLq1MNK+bPXExiJcroMfPh2O40+NbWH1tc5Dh4lLiWIQ/LIOb2gn9RkUdWA+Ba0qufg69rz0cMuPLRYPcBeGjm9ku0pfI9uU3oTsuYKcZM9gHo+TAmIh9bGMjAiknew8px0H6IvAn0u+TFoYfIBpMv5m7qfOgO4DTBcWTSdP5O7UzF8D3B9wg9UnPjdPcHjy/+AGWy8bdy/qODhPzrQm7GDiHyPZ3UB/G2xiPH61ucQp2O9lU5LS58EvADclczZ+4F/r4Ye1xyHm6TcZlzeW50GNEnHYx18r96TfXi+t1PKcfStPv2Z/AbTJYvua312XHheSJ4FVTsAvjv0K33vxD4MmwyGBKZ8AEnd10vtLv3xEZXzTuwS6f6wDHQzsNngDkDH6+OFfI5rznt/p34iPN6Qa6HzLfG8HQol+Um+/LaQ4TQImpLvrcwczpD/LS2xclBtQf+MTD6tfB5i2QvwG67RBFqHCtMsIw053j46uBnlZyLdAxlL0F4y/sos4A5v36ZfMm+8m+5cyK9S9y0iKmRe7fdXezua7eElx8cZe7FyQXHvD2wFtL/mVOWQe/DUfEapO+1QP/wv8X5yQM47VG8STpGXmLsmcW3L/J5snjfX24fvux/JNvVjis87q7UE+uSR8U+kLTcqNfwB7zvVzf5i9Dr4AzjVw80qy29jNNG+9jUvYnMDRbGjwueOa/zk7SS4G6ex3/Je/dc7InGBt64yDe73yDdv3j93vjuZBgaiCM3X0TQ2InGDr5rG9SWczweX/0hw9m75OK+RnMcIhkdOOHQSGRJCS/UvHdrSzjQws=",
	},
	CrystalOn = {
		Width = 40,
		Height = 40,
		Pixels = "KLUv/WAAGF0NAPQKmmoeAEBQEDDP/+9QYP+PEJ/MrGv/38WH/6ByKM8g5c2R//7ut/LepP+tgzv/s4tE//jmrsakYSBAgID613f//uyw+9yF/7KDL7/2xEX/98dM/OSb//fJU7GBKPjMWv3pqf/50WnssP/62X773oz84ZT95qL/+M9i4cR+/+HHh//51HDWpTf/1qY8UMiXMtmoOf+gcCCPEPC+Q8KRL0DfrjvruUD/q3slYNyqOiCAQH6oADGQgmoNkM4EIlNVbNIIcAQQSpBABEpCgBA8QnBWmDHGSIe1NQX55hhwNs44JD97ZDvGdPtrZqAB7+SXn8aO2PkW4x3y6d5HrPn29fWKaWOUm7c57rr95kE90q11qisv99KR0JMz37yoP8gpaV3NBgNl1xQoLKybT/jAaDKzwcq99hcdHUbiPX99Iu0u3BvaKBQWe37UXi+n1411mcnGGo7gUNsCX2+N+vEmgLyVkVb2DVHPOy9EM++uLcdjMB489eAM8HQ337HoMsPTQPOtq7MZTaNKnO/Knnd4uqKinigJ4RFDV4fwRPdPiQVMDMY4gA9nbBlIgn8=",
	},
	CrystalOff = {
		Width = 40,
		Height = 40,
		Pixels = "KLUv/WAAGEUNAIQKmqexAEBQEDDP/+9QYP+PEJ/Dy9L/0tnf/5+stc8g197j/+zw8+Hn6/+ptb3/rrnC/+br777HziBAgIDf5er/6u/y4ujs/6q2v7/V3eP/1t7k2N/lqbS92eHm6e7x/9zj6ODm6+Pp7eTq7ufs8P/b4ufS2d7/09rg/93k6cDK0v/By9JQt8LKw8zT/56qtI8Q0drgtL/HQMbQ187W3f+lsbpgxM7VIIBAfqgQMVCp1nDOBCJjptjCCIgEEEyQQAQ6QoAQPEJwVlAExhDLuLYGhXyjOKxv6HXgfWC7FsC0XdO64PQEf8dMp42YeRTiHYJpKEbLeYPx+u10YMSZRzmuGP7moR5119zFleV76Xpo5ewRL7oFyhppXJYIwz3zKAgttk6G+QOgziUNF/r9v38rjF5+tvpE6h7vD3zURdARWN+4vTAnmClqxObprt5/zbJH4nsmP6jcZ2RZFaaMtNr5jzCcc6U4y8W9dxgZyVCkhEWLpxPzXc8uM542mG99+2Y+beQ435A3cPF0aAA7iahmK/yBtoYnPR9O4EDEYi5e+Mt4cQ30MzY=",
	},
	Bolt = {
		Width = 48,
		Height = 48,
		Pixels = "KLUv/WAAI6UYAFQaJTdGAIDP/9+fEACf/89AQN+ShVH//9Jcd3FOYIBASkn/8cha///RWzNBRyAQ77ugVP//0Fqtl1O/W11L//7PWtWxVf/+zlnju1fvz4R4Tv/+zVifi1CfcDNAR//wwlb//sxYQEpIUKyTUf/+ylfVr1TfXEr//clWhHdNjzCtU//9yFYzQEcwv3ZtTP/9x1W5mlBgMu+9U//9xlRoZEpwnodO//3FVO+8U++vj01RSP/8w1Osj04gxp9P//zCUoBrSv/8wVKQfEyP7rdQ//zAUdOmT9+DTP/8v1CvSEf/+75QkHpLIJtN//u9T9OkTVBoYEn/+7tOTVBIr6uJS//FmkzTokz/+7pNkHlKr/+CcEn/+7lN0qFM77iQSv/6uExNT0eAv//fp0v/+reQd0kQP0b/+rZL0p5KUGdeR//6tUqPdUj/+rNJgm1IxJNI//mySeypsUBGRk1ORv/5sEeCbEffdGSvR//EkUefqYGu66ZG/z/RlkX/+KyBakb/+KtFw45FWlSqRP/ro0T/P0WOcKlD/4FpRbaFRP/DjETQkkNnRD6/AICyqJCQnLSGMYCYBJJIlAcCCRiEgGcIaoigoQgQAg4hQGiCJdwJa0LQDy1763KG9mOHh7nUHXZDUe0w9PRmFkTXmqN4p3riaAotz7gZkvxq5DL2tZssXEuSHI5XOde/yAM6vM5oc2MjqzLZ4ZAMUy79HDZGkr1+uMQPLvkd2ln6Dv7wmfmSHJjaueMNh7RJ5eF9B7qXUat/WLWyDWXYtr1uOy3wvdQwB9eG8WNXlU7nVtDHbYEdKNijh+PdWjLteF/RfHo7Js10uyvfM0NoduEcgj3qKFZuQ5dHrd3fi03K7xcWOgi23/DMabUtER3+ZxTDHyCxMziX5PClmQ2pr6IrWjLVuZyUuG3mcND2ZSv0ZN64h2ZuQQA6gdm3AmCHENwdD/48vmvclkyOSDLh5WsPQkYM1f7Ty/sv3Ab/8fXn7hW5bcJfs4g3n4DnkHlfAGHBCASH+Cm854h4PXHITzVGLETq/f+ZBbYIIEB1",
	},
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Icons [ModuleScript]
-- y u r i

local var1 = require(script.Parent.IconData)
local var2 = game:GetService("EncodingService")
local var3 = game:GetService("AssetService")
local bool1 = false
local tbl1 = {}
local function create(arg1)
	local var5 = var1[arg1]
	if not var5 then
		return nil
	end

	local success, result = pcall(function()
		local var1 = var5.Pixels
		local var4 = Vector2.new(var5.Width, var5.Height)
		local var6 = var2:DecompressBuffer(var2:Base64Decode(buffer.fromstring(var1)), Enum.CompressionAlgorithm.Zstd)
		local var8 = var3:CreateEditableImage({ Size = var4 })
		if var8 then
			var8:WritePixelsBuffer(Vector2.zero, var4, var6)
		end

		return var8
	end)

	if success and result then
		return result
	end

	if not bool1 then
		bool1 = true
		warn("[FrozenHouse] Icons: could not create an EditableImage (" .. tostring(result) .. "); icons show as text.")
	end

	return nil
end

local tbl2 = { content = function(arg1)
	local var2 = tbl1[arg1]
	if var2 == nil then
		var2 = create(arg1) or false
		tbl1[arg1] = var2
	end

	return var2 and Content.fromObject(var2) or nil
end }

tbl2.label = function(arg1, arg2, arg3)
	local var3 = tbl2.content(arg1)
	local var4 = nil
	if var3 then
		var4 = Instance.new("ImageLabel")
		var4.BackgroundTransparency = 1
		var4.ImageContent = var3
		var4.ScaleType = Enum.ScaleType.Fit
	else
		var4 = Instance.new("TextLabel")
		var4.BackgroundTransparency = 1
		var4.Text = arg3 or ""
		var4.TextScaled = true
		var4.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
		var4.TextColor3 = Color3.fromHex("#253746")
	end

	local var5 = arg2
	for k1, v1 in pairs(var5 or {}) do
		if k1 == "Parent" then
			continue
		end

		if var3 ~= nil or k1 ~= "ImageColor3" and (k1 ~= "ImageTransparency" and k1 ~= "ScaleType") then
			var4[k1] = v1
		end
	end

	if arg2 and arg2.Parent then
		var4.Parent = arg2.Parent
	end

	return var4
end

tbl2.set = function(arg1, arg2)
	local var1 = tbl2.content(arg2)
	if arg1:IsA("ImageLabel") and var1 then
		arg1.ImageContent = var1
	end
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ToolShed [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local str1 = "ClassPerks"
local str2 = "Products"
local var3 = require(var1:WaitForChild("MeltShared"):WaitForChild(str1))
local str3 = "GamePasses"
local var4 = require(var1:WaitForChild("MeltShared"):WaitForChild(str2))
local var5 = require(var1:WaitForChild("MeltShared"):WaitForChild(str3))
local var6 = require(var2.Config)
str3 = require(script.Parent.UIKit)
local var7 = game:GetService("HttpService")
local var8 = game:GetService("MarketplaceService")
local var9 = game:GetService("Players")
local var10 = game:GetService("ProximityPromptService")
local var11 = game:GetService("RunService")
local var12 = game:GetService("UserInputService")
local var13 = require(var2.Layout)
local var14 = require(var2.Net)
local var15 = require(var2.ToolStats)
str1 = require(script.Parent.ClientState)
str2 = require(script.Parent.Focus)
local var16 = Color3.fromHex("#21625E")
local var17 = Color3.fromHex("#B8452F")
local tbl1 = {}
local tbl2 = {}
local var18 = nil
local tbl3 = {}
local function stateOf(arg1, arg2)
	local var2 = arg1.product
	local var3 = arg1.def
	if var2 then
		if var2.ToolId then
			if arg2.owned[var2.ToolId] then
				if arg2.equipped == var2.ToolId then
					return "equipped"
				end

				return "owned"
			end
		end

		if 1 < var4.batteryMultiplier(var2) and 1 < arg2.boost then
			return "active"
		end

		if not arg2.available[var2.Key] then
			return "unavailable"
		end

		local var5 = tbl2[var2.Key]
		if not (var5 and (var5.forSale and var5.price) or nil) then
			return "loading"
		end

		return "product"
	end

	if arg2.owned[var3.Id] then
		if arg2.equipped == var3.Id then
			return "equipped"
		end

		return "owned"
	end

	local var8 = var3.Requires and (arg2.owned[var3.Requires] or var6.ToolById[var3.Requires]) or nil
	if var8 then
		return "requires", var8
	end

	if arg2.coins < var15.toolPrice(var3.Id, arg2.perks) then
		return "coins"
	end

	return "buy"
end

local var19 = str3.new
local var20 = str3.Fonts
local function checkMark(arg1, arg2)
	local var1 = var19("Frame", { Name = "Check", BackgroundTransparency = 1, Size = UDim2.fromOffset(arg1, arg1) })
	local var2 = math.max(3, (math.floor(arg1 * 0.16)))
	local tbl1 = {
		BackgroundColor3 = arg2,
		BorderSizePixel = 0,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Rotation = 45,
	}

	tbl1.Position = UDim2.fromScale(0.3, 0.62)
	tbl1.Size = UDim2.fromOffset(math.floor(arg1 * 0.42), var2)
	tbl1.Parent = var1
	local var3 = var2
	var19("Frame", tbl1, { str3.corner(var3) })
	tbl1 = {
		BackgroundColor3 = arg2,
		BorderSizePixel = 0,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Rotation = -50,
	}

	tbl1.Position = UDim2.fromScale(0.62, 0.48)
	tbl1.Size = UDim2.fromOffset(math.floor(arg1 * 0.74), var2)
	tbl1.Parent = var1
	var3 = var2
	var19("Frame", tbl1, { str3.corner(var3) })
	return var1
end

local var21 = var6.Palette
local tbl4 = { pending = false }
local var22 = nil
local bool1 = false
local function invoke(arg1, arg2, arg3)
	local var1 = var7:GenerateGUID(false)
	local function call()
		local var2 = arg1
		local var3 = arg2
		local var4 = nil
		local var5 = nil
		local var6 = var1
		local var7 = arg3
		return var14.get("Shop"):InvokeServer(var2, var3, var4, var5, var6, var7)
	end

	local success, result = pcall(call)
	if not success then
		task.wait(0.3)
		local success, result = pcall(call)
		success = success
		result = result
	end

	if success and typeof(result) == "table" then
		return result
	end

	return { ok = false, reason = "error" }
end

local var23 = nil
local num1 = 0
local function snapshot()
	local var1 = str1.ownedTools()
	for k1 in pairs(tbl1) do
		var1[k1] = true
	end

	local tbl2 = { coins = str1.coins() }
	tbl2.owned = var1
	local var2 = str1.playerAttr("EquippedTool")
	tbl2.equipped = var2 or var6.StarterToolId
	tbl2.perks = str1.perks()
	tbl2.grenades = str1.grenades()
	tbl2.boost = str1.batteryBoost()
	tbl2.available = str1.productsAvailable()
	return tbl2
end

local var24 = nil
var22 = function()
	if not tbl4.display then
		return
	end

	tbl4.display = nil
	tbl4.root.Visible = false
	if str1.menuOpen == "ToolShed" then
		str1.setMenu(nil)
	end

	str2.close("FrozenHouseShedCard")
end

local function celebrate(arg1)
	arg1.celebrating = true
	local var1 = arg1.highlight
	var1.FillColor = var21.Orange
	var1.OutlineTransparency = 0
	var1.Enabled = true
	if str1.settings.ReducedEffects then
		var1.FillTransparency = 1
	else
		var1.FillTransparency = 0.4
		str3.tween(var1, 1.6, { FillTransparency = 1, OutlineTransparency = 0.15 })
	end

	task.delay(1.7, function()
		arg1.celebrating = false
		var1.FillTransparency = 1
		var1.OutlineTransparency = 0.15
	end)

	if arg1.product and (not arg1.product.ToolId) then
		return
	end

	if not arg1.product then
		var23.HUD.toast(string.format(var6.Text.ToolUnlocked, arg1.def.Name), 2.4)
	end

	task.delay(2.5, function()
		local var2 = str2.Controls.mode()
		local var3
		if var2 == str2.Mode.Touch then
			var3 = "touch"
		else
			var3 = if var2 == str2.Mode.Gamepad then "gamepad" else "keyboard"
		end

		var23.HUD.toast(var3 == "touch" and var6.Text.NewUpgradesTouch or (var3 == "gamepad" and var6.Text.NewUpgradesGamepad or var6.Text.NewUpgradesKeyboard), 3.5)
	end)
end

local tbl5 = {
	coins = "Not enough coins yet.",
	far = "Walk up to the display to buy it.",
	blocked = "Walk up to the display to buy it.",
	unavailable = "The Tool Shed opens when the run starts.",
	owned = "You already own this tool.",
	busy = "One moment\226\128\166",
}

local tbl6 = { display = nil, product = nil, state = nil, at = 0 }
local tbl7 = {
	unavailable = var6.Text.PurchaseNotSetUp,
	checking = "Still checking whether you own it\226\128\166",
	closed = var6.Text.PurchaseClosed,
	pending = var6.Text.PurchaseOpen,
	owned = "You already have it for this run.",
	far = "Walk up to the display to buy it.",
	blocked = "Walk up to the display to buy it.",
	busy = "One moment\226\128\166",
}

local function passFor(arg1)
	if not arg1 then
		return nil
	end

	local var1
	if arg1.product then
		var1 = arg1.product.ToolId
	else
		var1 = arg1.def
		var1 = var1 and arg1.def.Id
	end

	local var3 = if var1 then var5.forTool(var1) else nil
	if not var3 then
		if arg1.product then
			return (var5.forProduct(arg1.product.Key))
		end

		var3 = nil
	end

	return var3
end

local tbl8 = {}
local function buyProduct(arg1)
	local var1 = arg1
	local var2 = tbl4.display
	arg1 = var1 or var2 and var2.product
	if not var2 or (not arg1 or (tbl6.state or (os.clock() < num1 or (not tbl4.inReach)))) then
		return
	end

	tbl6.display = var2
	local var3 = os.clock()
	tbl6.product = arg1
	tbl6.state = "requesting"
	tbl6.at = var3
	tbl4.message = nil
	var24()
	task.spawn(function()
		local var1 = invoke("product", arg1.Key, var2.id)
		if tbl6.display ~= var2 or (tbl6.product ~= arg1 or tbl6.state ~= "requesting") then
			return
		end

		if var1.ok then
			tbl6.state = "prompt"
			local var3 = os.clock()
			tbl6.at = var3
			var24()
			return
		end

		tbl6.state = nil
		local var4 = os.clock()
		tbl4.message = tbl7[var1.reason] or "That didn't work. Try again."
		tbl4.messageAt = var4
		task.delay(2.5, function()
			if tbl4.messageAt == var4 then
				tbl4.message = nil
				var24()
			end
		end)

		var24()
	end)
end

local function updatePackRow(arg1, arg2)
	local var1 = snapshot()
	tbl4.pass.Visible = true
	tbl4.passNote.Visible = true
	local var2 = tbl2[arg2.Key]
	local var3 = var2 and (var2.forSale and var2.price) or nil
	var2 = tbl2[arg1.product.Key]
	local var5 = var2 and (var2.forSale and var2.price) or nil
	var2 = var4.grenadeCount(arg2)
	local var8 = if var3 and var5 then var5 * var2 - var3 else 0
	local var9 = tbl4.passNote
	local var10 = if 0 < var8 then "Save " .. var4.priceText(var8) else string.format("%d grenades in one go \226\128\162 this run only", var2)
	var9.Text = var10
	var9 = if tbl6.display == arg1 then tbl6.state else nil
	var10 = false
	if var9 ~= nil then
		var10 = tbl6.product == arg2
	end

	local var11 = string.format("Buy %d \226\128\148 %s", var2, var4.priceText(var3) or "")
	if var10 then
		local var12 = tbl4.pass
		local var13
		if var9 == "requesting" then
			var13 = "One moment\226\128\166"
		elseif var9 == "prompt" then
			var13 = var6.Text.PurchaseWaiting
		else
			var13 = var6.Text.PurchaseConfirming
		end

		var12.Text = var13
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if not var1.available[arg2.Key] then
		tbl4.pass.Text = var6.Text.PurchaseNotSetUp
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if not var3 then
		tbl4.pass.Text = "Checking the price\226\128\166"
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if var9 or (str1.phase() ~= "Running" or (not tbl4.inReach)) then
		tbl4.pass.Text = var11
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	tbl4.pass.Text = var11
	tbl4.passAction = function()
		buyProduct(arg2)
	end

	str3.setButtonStyle(tbl4.pass, "action")
end

local tbl9 = {
	PermanentFlamethrower = "Unlocked in every run, for good.",
	PermanentHeatGun = "Yours in every run, for good \226\128\148 no coins needed.",
	PermanentSteamBlaster = "Yours in every run, for good \226\128\148 no coins needed.",
	PermanentDoubleBattery = "Double battery in every run, for good.",
}

local function fetchPassPrice(arg1, arg2)
	if not var5.configured(arg1) then
		return
	end

	local var2 = tbl3[arg1.Key]
	if not var2 then
		var2 = {}
		tbl3[arg1.Key] = var2
	end

	if var2.pending or not arg2 and (var2.fetchedAt and os.clock() - var2.fetchedAt < 120) then
		return
	end

	var2.pending = true
	task.spawn(function()
		local success, result = pcall(function()
			local var1 = arg1.GamePassId
			local var2 = Enum.InfoType.GamePass
			return var8:GetProductInfo(var1, var2)
		end)

		var2.pending = false
		var2.fetchedAt = os.clock()
		if success and (typeof(result) == "table" and typeof(result.PriceInRobux) == "number") then
			var2.price = result.PriceInRobux
			var2.forSale = result.IsForSale == true
		end

		if var18 then
			var18()
		end
	end)
end

local function buyPass()
	local var1 = tbl4.display
	local var3 = passFor(var1)
	if not var3 or (tbl8.state or (os.clock() < num1 or (not tbl4.inReach))) then
		return
	end

	tbl8.display = var1
	local var4 = os.clock()
	tbl8.state = "requesting"
	tbl8.at = var4
	tbl4.message = nil
	var24()
	task.spawn(function()
		local var2 = invoke("pass", var3.Key, var1.id)
		if tbl8.display ~= var1 or tbl8.state ~= "requesting" then
			return
		end

		if var2.ok then
			tbl8.state = "prompt"
			local var4 = os.clock()
			tbl8.at = var4
			var24()
			return
		end

		tbl8.state = nil
		local var5 = os.clock()
		tbl4.message = tbl7[var2.reason] or "That didn't work. Try again."
		tbl4.messageAt = var5
		task.delay(2.5, function()
			if tbl4.messageAt == var5 then
				tbl4.message = nil
				var24()
			end
		end)

		var24()
	end)
end

local tbl10 = {
	FireGrenade = "Throw it to melt a pocket of ice three seconds later.",
	Flamethrower = "The strongest melting tool, with its own upgrades.",
	DoubleBattery = "Every tool you own runs twice as long, starting full.",
}

local function updatePassRow(arg1)
	local var1 = passFor(arg1)
	tbl4.passAction = nil
	if not var1 then
		local var3 = if not arg1 or (not arg1.product) then nil else var4.alsoAt(arg1.product.Key)[1]
		if var3 then
			updatePackRow(arg1, var3)
			return
		end

		tbl4.pass.Visible = false
		tbl4.passNote.Visible = false
		return
	end

	tbl4.pass.Visible = true
	tbl4.passNote.Visible = true
	tbl4.passNote.Text = tbl9[var1.Key] or ""
	fetchPassPrice(var1)
	local var7 = var9.LocalPlayer:GetAttribute("PermanentTools")
	local var10 = var1.ToolId
	local var11
	if typeof(var7) ~= "string" or (not var10) then
		var11 = false
	else
		var11 = table.find(string.split(var7, ","), var10) ~= nil
	end

	local var12
	if var11 then
		var12 = true
	else
		local var13 = var1
		var11 = var9.LocalPlayer:GetAttribute(var5.attribute(var13))
		if var11 == "yes" then
			var12 = true
		elseif var11 == "no" then
			var12 = false
		else
			var12 = nil
		end
	end

	local var14 = tbl3[var1.Key]
	var11 = if tbl8.display == arg1 then tbl8.state else nil
	var10 = var4.priceText(var14 and (var14.forSale and var14.price) or nil)
	if var12 == true then
		tbl4.pass.Text = "Unlocked for good"
		str3.setButtonStyle(tbl4.pass, "done")
		return
	end

	if var11 then
		var7 = tbl4.pass
		var7.Text = if var11 == "requesting" then "One moment\226\128\166" else var6.Text.PurchaseWaiting
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if var12 == nil then
		tbl4.pass.Text = "Checking\226\128\166"
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if not var10 then
		tbl4.pass.Text = var6.Text.PurchaseNotSetUp
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	if str1.phase() ~= "Running" or (not tbl4.inReach) then
		tbl4.pass.Text = "Unlock forever \226\128\148 " .. var10
		str3.setButtonStyle(tbl4.pass, "secondary")
		return
	end

	tbl4.pass.Text = "Unlock forever \226\128\148 " .. var10
	tbl4.passAction = buyPass
	str3.setButtonStyle(tbl4.pass, "done")
end

local function updateProductCard(arg1, arg2, arg3)
	local var1 = arg1.product
	local var2 = tbl2[var1.Key]
	local var3 = var4.priceText(var2 and (var2.forSale and var2.price) or nil)
	local bool2 = true
	if arg3 ~= "owned" then
		bool2 = arg3 == "equipped"
	end

	tbl4.name.Text = var1.Name
	tbl4.tagline.Text = tbl10[var1.Key] or ""
	tbl4.coin.Visible = false
	tbl4.check.Visible = arg3 == "equipped"
	var2 = tbl4.amount
	local var7
	if arg3 == "equipped" then
		var7 = "EQUIPPED"
	elseif arg3 == "owned" then
		var7 = "OWNED"
	elseif arg3 == "active" then
		var7 = "ACTIVE"
	else
		var7 = var3 or ""
	end

	var2.Text = var7
	var2 = tbl4.amount
	var2.TextColor3 = if bool2 or arg3 == "active" then var16 else str3.Colors.Text
	var2 = tbl4.coins
	if var1.Key == "FireGrenade" then
		var7 = string.format
		local str2 = "You have %d grenade%s"
		local var8 = arg2.grenades
		var7 = var7(str2, var8, if arg2.grenades == 1 then "" else "s")
	else
		var7 = ""
	end

	var2.Text = var7
	tbl4.action = nil
	var2 = var4.RunOnlyNotice
	var7 = if tbl6.display == arg1 and tbl6.product == var1 then tbl6.state else nil
	local bool4 = false
	if tbl6.display == arg1 then
		bool4 = false
		if tbl6.state ~= nil then
			bool4 = not var7
		end
	end

	if arg3 == "equipped" then
		tbl4.buy.Text = "Equipped"
		str3.setButtonStyle(tbl4.buy, "done")
		var2 = ""
	elseif arg3 == "owned" then
		tbl4.buy.Text = "Equip"
		str3.setButtonStyle(tbl4.buy, "action")
		tbl4.action = function()
			local var1 = arg1
			if bool1 then
				return
			end

			bool1 = true
			task.spawn(function()
				local var2 = invoke("equip", var1.def.Id)
				bool1 = false
				if var2.ok then
					var23.Audio.play("UITick", 0.05)
					var23.HUD.toast(string.format(var6.Text.ToolEquipped, var1.def.Name), 2)
				end

				var18()
			end)
		end

		var2 = ""
	elseif arg3 == "active" then
		local var13 = passFor(arg1)
		local bool5 = false
		if var13 ~= nil then
			local var14 = var13
			local var19 = var9.LocalPlayer:GetAttribute(var5.attribute(var14))
			local var20
			if var19 == "yes" then
				var20 = true
			elseif var19 == "no" then
				var20 = false
			else
				var20 = nil
			end

			bool5 = var20 == true
		end

		var20 = tbl4.buy
		var20.Text = if bool5 then "Yours for good" else "Active this run"
		str3.setButtonStyle(tbl4.buy, "done")
		if bool5 then
			var2 = "Every tool's battery is doubled in every run."
		else
			var2 = "Every tool's battery is doubled until this run ends."
		end
	elseif var7 then
		local var21 = tbl4.buy
		local var22
		if var7 == "requesting" then
			var22 = "One moment\226\128\166"
		elseif var7 == "prompt" then
			var22 = var6.Text.PurchaseWaiting
		else
			var22 = var6.Text.PurchaseConfirming
		end

		var21.Text = var22
		str3.setButtonStyle(tbl4.buy, "secondary")
	elseif arg3 == "unavailable" then
		tbl4.buy.Text = var6.Text.PurchaseNotSetUp
		str3.setButtonStyle(tbl4.buy, "secondary")
	elseif arg3 == "loading" then
		tbl4.buy.Text = "Checking the price\226\128\166"
		str3.setButtonStyle(tbl4.buy, "secondary")
	else
		tbl4.buy.Text = "Buy \226\128\148 " .. tostring(var3)
		if str1.phase() ~= "Running" then
			var2 = var6.Text.PurchaseClosed
		else
			if not tbl4.inReach then
				var2 = "Move closer to buy."
			elseif not bool4 then
				tbl4.action = function()
					buyProduct(var1)
				end

			end
		end

		local var24 = str3.setButtonStyle
		var22 = tbl4.buy
		var24(var22, if tbl4.action then "action" else "secondary")
	end

	tbl4.status.Text = tbl4.message or var2
	local var25 = tbl4.status
	var25.TextColor3 = if tbl4.message == nil and (var2 == var4.RunOnlyNotice or arg3 == "active") then str3.Colors.SubText else var17
	updatePassRow(arg1)
end

local function buyTool()
	local var2 = tbl4.display
	if not var2 or (tbl4.pending or (os.clock() < num1 or (stateOf(var2, (snapshot())) ~= "buy" or (not tbl4.inReach)))) then
		return
	end

	tbl4.pending = true
	tbl4.message = nil
	var24()
	task.spawn(function()
		local var1 = invoke("buy", var2.def.Id, var2.id)
		tbl4.pending = false
		if var1.ok then
			num1 = os.clock() + 0.5
			tbl1[var2.def.Id] = true
			if tbl4.display == var2 then
				var22()
			end

			if var23.Manual and var23.Manual.noteOwned then
				var23.Manual.noteOwned(var2.def.Id)
			end

			var18()
			celebrate(var2)
			return
		end

		local var4 = tbl5[var1.reason] or "That didn't work. Try again."
		if var1.reason == "requires" and var2.def.Requires then
			var4 = string.format(var6.Text.ShedRequires, var6.ToolById[var2.def.Requires].Name)
		end

		local var5 = os.clock()
		tbl4.message = var4
		tbl4.messageAt = var5
		task.delay(2.5, function()
			if tbl4.messageAt == var5 then
				tbl4.message = nil
				var24()
			end
		end)

		var24()
	end)
end

local function fetchPrice(arg1, arg2)
	if not var4.configured(arg1) then
		return
	end

	local var2 = tbl2[arg1.Key]
	if not var2 then
		var2 = {}
		tbl2[arg1.Key] = var2
	end

	if var2.pending or not arg2 and (var2.fetchedAt and os.clock() - var2.fetchedAt < 120) then
		return
	end

	var2.pending = true
	task.spawn(function()
		local success, result = pcall(function()
			local var1 = arg1.ProductId
			local var2 = Enum.InfoType.Product
			return var8:GetProductInfoAsync(var1, var2)
		end)

		var2.pending = false
		var2.fetchedAt = os.clock()
		if success and (typeof(result) == "table" and typeof(result.PriceInRobux) == "number") then
			var2.price = result.PriceInRobux
			var2.forSale = result.IsForSale == true
		end

		if var18 then
			var18()
		end
	end)
end

var24 = function()
	local var2 = tbl4.display
	if not var2 then
		return
	end

	local var3 = snapshot()
	local var7, var8 = stateOf(var2, var3)
	local var9 = var2.def
	local bool2 = true
	if var7 ~= "owned" then
		bool2 = var7 == "equipped"
	end

	if var2.product then
		updateProductCard(var2, var3, var7)
		return
	end

	updatePassRow(var2)
	tbl4.status.TextColor3 = var17
	tbl4.name.Text = var9.Name
	tbl4.tagline.Text = var9.Tagline
	tbl4.coins.Text = "Your coins: " .. tostring(var3.coins)
	tbl4.coin.Visible = not bool2
	tbl4.check.Visible = var7 == "equipped"
	local var10 = var15.toolPrice(var9.Id, var3.perks)
	local var11 = tbl4.amount
	local var12
	if var7 == "equipped" then
		var12 = "EQUIPPED"
	elseif var7 == "owned" then
		var12 = "OWNED"
	else
		var12 = tostring(var10)
	end

	var11.Text = var12
	tbl4.amount.TextColor3 = bool2 and var16 or str3.Colors.Text
	tbl4.action = nil
	var11 = ""
	if tbl4.pending then
		tbl4.buy.Text = "Buying\226\128\166"
		str3.setButtonStyle(tbl4.buy, "secondary")
	elseif var7 == "equipped" then
		tbl4.buy.Text = "Equipped"
		str3.setButtonStyle(tbl4.buy, "done")
	elseif var7 == "owned" then
		tbl4.buy.Text = "Equip"
		str3.setButtonStyle(tbl4.buy, "action")
		tbl4.action = function()
			local var1 = var2
			if bool1 then
				return
			end

			bool1 = true
			task.spawn(function()
				local var2 = invoke("equip", var1.def.Id)
				bool1 = false
				if var2.ok then
					var23.Audio.play("UITick", 0.05)
					var23.HUD.toast(string.format(var6.Text.ToolEquipped, var1.def.Name), 2)
				end

				var18()
			end)
		end

	else
		tbl4.buy.Text = string.format("Buy \226\128\148 %d coins", var10)
		if var7 == "requires" then
			var11 = string.format(var6.Text.ShedRequires, var8.Name)
		elseif var7 == "coins" then
			var12 = var10 - var3.coins
			local var13 = string.format
			local str1 = "Need %d more coin%s"
			local var14 = var12
			var11 = var13(str1, var14, if var12 == 1 then "" else "s")
		else
			if not tbl4.inReach then
				var11 = "Move closer to buy."
			else
				tbl4.action = buyTool
			end
		end

		var12 = str3.setButtonStyle
		local var19 = tbl4.buy
		var12(var19, if tbl4.action then "action" else "secondary")
	end

	tbl4.status.Text = tbl4.message or var11
end

local var25 = var6.ToolShed
local tbl11 = {}
local function updateHeader(arg1, arg2)
	if not arg1.amount then
		return
	end

	local var5 = arg1.def
	local var7, var8 = stateOf(arg1, arg2)
	if arg1.product then
		local bool1 = true
		if var7 ~= "owned" then
			bool1 = var7 == "equipped"
		end

		arg1.coin.Visible = false
		arg1.check.Visible = var7 == "equipped"
		local var9 = arg1.amount
		local var10
		if var7 == "equipped" then
			var10 = "EQUIPPED"
		elseif var7 == "owned" then
			var10 = "OWNED"
		elseif var7 == "active" then
			var10 = "ACTIVE"
		elseif var7 == "unavailable" then
			var10 = "NOT AVAILABLE"
		elseif var7 == "loading" then
			var10 = "\226\128\166"
		else
			local var11 = tbl2[arg1.product.Key]
			var10 = var4.priceText(var11 and (var11.forSale and var11.price) or nil) or ""
		end

		var9.Text = var10
		var9 = arg1.amount
		if bool1 or var7 == "active" then
			var10 = var16
		elseif var7 == "unavailable" then
			var10 = str3.Colors.SubText
		else
			var10 = str3.Colors.Text
		end

		var9.TextColor3 = var10
		if arg1.note then
			var9 = arg1.note
			var10 = if arg1.product.Key == "FireGrenade" and 0 < arg2.grenades then string.format("You have %d", arg2.grenades) else ""
			var9.Text = var10
		end

		return
	end

	local bool2 = true
	if var7 ~= "owned" then
		bool2 = var7 == "equipped"
	end

	arg1.coin.Visible = not bool2
	arg1.check.Visible = var7 == "equipped"
	local var12 = var15.toolPrice(var5.Id, arg2.perks)
	var10 = arg1.amount
	local var13
	if var7 == "equipped" then
		var13 = "EQUIPPED"
	elseif var7 == "owned" then
		var13 = "OWNED"
	else
		var13 = string.format("%d COINS", var12)
	end

	var10.Text = var13
	arg1.amount.TextColor3 = bool2 and var16 or str3.Colors.Text
	if arg1.note then
		if var7 == "requires" then
			arg1.note.Text = string.format(var6.Text.ShedRequires, var8.Name)
			return
		end

		if not bool2 and var12 < var5.Price then
			local var17 = arg2.perks.bp.SteamDiscount
			arg1.note.Text = string.format(var6.Text.ClassDiscount, var3.percent(var17))
			return
		end

		if var5.Price == 0 then
			arg1.note.Text = "Starter tool"
			return
		end

		arg1.note.Text = ""
	end
end

local tbl12 = {}
local var26 = nil
local var27 = nil
local var28 = nil
local function openCard(arg1)
	if tbl4.display or str1.menuOpen ~= nil then
		return
	end

	tbl4.display = arg1
	tbl4.message = nil
	tbl4.inReach = true
	if arg1.product then
		fetchPrice(arg1.product, true)
		local var1 = arg1.product.Key
		for k1, v1 in ipairs(var4.alsoAt(var1)) do
			fetchPrice(v1, true)
		end
	end

	if tbl4.preview then
		tbl4.preview:Destroy()
	end

	local num1 = 0.92
	local num2 = 0.92
	tbl4.preview = str3.toolPreview(arg1.def.Id, UDim2.fromScale(num1, num2))
	tbl4.preview.AnchorPoint = Vector2.new(0.5, 0.5)
	tbl4.preview.Position = UDim2.fromScale(0.5, 0.5)
	tbl4.preview.Parent = tbl4.tile
	str1.setMenu("ToolShed")
	var24()
	tbl4.root.Visible = true
	if str1.settings.ReducedEffects then
		tbl4.pop.Scale = 1
	else
		tbl4.pop.Scale = 0.92
		str3.tween(tbl4.pop, 0.16, { Scale = 1 }, Enum.EasingStyle.Back)
	end

	var23.Audio.play("UITick", 0.05)
	local tbl1 = { root = tbl4.root, hints = str2.basic(var6.Text.HintClose), lockControls = false }
	tbl1.initial = function()
		if tbl4.action and (tbl4.buy and (tbl4.buy.Visible and tbl4.buy.Selectable)) then
			return tbl4.buy
		end

		return tbl4.cancel
	end

	tbl1.back = var22
	str2.open("FrozenHouseShedCard", tbl1)
end

var18 = function()
	local var1 = snapshot()
	for k1, v1 in ipairs(tbl11) do
		local var3 = stateOf(v1, var1)
		local var4
		if var3 == "equipped" then
			var4 = nil
		elseif var3 == "owned" then
			var4 = "Equip"
		else
			var4 = "View"
		end

		v1.action = var4
		if v1.action then
			v1.prompt.ActionText = v1.action
		end

		updateHeader(v1, var1)
	end

	var24()
end

local tbl13 = { session = 0, active = false }
local function pickTarget()
	if #tbl11 ~= 0 then
		if str1.menuOpen == nil then
			if not str1.cinematic then
				if str1.canPlay() then
					local var6 = str1.humanoid()
					local bool1 = false
					if var6 ~= nil then
						bool1 = 0 < var6.Health
					end

					if not bool1 then
						return nil
					end
				end
			end
		end
	end

	local var7 = str1.character()
	local var8 = var7
	var8 = var8 and var7:FindFirstChild("HumanoidRootPart")
	if not var8 or (not var13.insideShed(var8.Position)) then
		return nil
	end

	var7 = workspace.CurrentCamera
	local var9 = var7.CFrame.Position
	local var10 = var7.CFrame.LookVector
	local var11 = nil
	local var12 = var25.FacingDot
	for k1, v1 in ipairs(tbl11) do
		if (v1.point.Position - var8.Position).Magnitude > var25.InteractDistance then
			continue
		end

		local var14 = v1.point.Position - var9
		if 0.01 >= var14.Magnitude then
			continue
		end

		local var15 = var10:Dot(var14.Unit)
		if var12 > var15 then
			continue
		end

		var11 = v1
		local var16 = var15
	end

	return var11
end

local function renderPrompt()
	local var1 = var28
	var1 = var1 and var28.display
	local var2 = var1 ~= nil and (var1 == var27 and var1.action) or nil
	local bool1 = false
	if var28 ~= nil then
		bool1 = var28.inputType == Enum.ProximityPromptInputType.Touch
	end

	local var3 = tbl12.pill
	local bool3 = false
	if var2 ~= nil then
		bool3 = not bool1
	end

	var3.Visible = bool3
	var3 = tbl12.button
	bool3 = false
	if var2 ~= nil then
		bool3 = bool1
	end

	var3.Visible = bool3
	if var2 then
		var3 = var2 .. " " .. var1.def.Name
		tbl12.text.Text = var3
		tbl12.button.Text = var3
		bool3 = true
		if var28.inputType ~= Enum.ProximityPromptInputType.Gamepad then
			bool3 = str2.Controls.isGamepad()
		end

		local var4 = bool3 and str2.Controls.glyphImage("Interact") or nil
		tbl12.glyph.Visible = var4 ~= nil
		tbl12.key.Visible = var4 == nil
		if var4 then
			tbl12.glyph.Image = var4
			return
		end

		local var5 = tbl12.key
		var5.Text = if bool3 then "X" else "E"
	end
end

local function checkCard()
	local var1 = tbl4.display
	if tbl6.state and 90 < os.clock() - tbl6.at then
		tbl6.state = nil
		var24()
	end

	local var2 = str1.character()
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("HumanoidRootPart")
	if var3 then
		local var6 = str1.humanoid()
		var2 = false
		if var6 ~= nil then
			var2 = 0 < var6.Health
		end

		if not var2 or (str1.cinematic or (not str1.canPlay() or (not var13.insideShed(var3.Position)))) then
			var22()
			return
		end
	end

	var2 = (var1.point.Position - var3.Position).Magnitude
	if var25.CloseDistance < var2 then
		var22()
		return
	end

	local var8 = var2 <= var25.InteractDistance
	if var8 ~= tbl4.inReach then
		tbl4.inReach = var8
		var24()
	end
end

local function updateWay(arg1)
	local var1 = tbl13
	local var2 = var1.clock + arg1
	var1.clock = var2
	tbl13.bb.StudsOffsetWorldSpace = Vector3.new(0, math.sin(tbl13.clock * 4) * 0.8, 0)
	var1 = workspace.CurrentCamera
	local var3, var4 = var1:WorldToViewportPoint(tbl13.position)
	local var6 = var4
	var2 = var1.ViewportSize
	if var6 then
		var6 = false
		if 0 < var3.Z then
			var6 = false
			if 60 < var3.X then
				var6 = false
				if var3.X < var2.X - 60 then
					var6 = false
					if 60 < var3.Y then
						var6 = var3.Y < var2.Y - 60
					end
				end
			end
		end
	end

	tbl13.arrow.Visible = not var6
	if var6 then
		return
	end

	local var7 = var1.CFrame:PointToObjectSpace(tbl13.position)
	local var8 = Vector2.new(var7.X, -var7.Y)
	if 0 < var7.Z then
		local var9 = Vector2.new
		var8 = var9(if 0 <= var7.X then 1 else -1, 0)
	end

	if var8.Magnitude < 0.001 then
		var8 = Vector2.new(0, 1)
	end

	var8 = var8.Unit
	local var10 = math.min((var2.X / 2 - 60) / math.max(math.abs(var8.X), 0.001), (var2.Y / 2 - 60) / math.max(math.abs(var8.Y), 0.001))
	tbl13.arrow.Position = UDim2.fromOffset(var2.X / 2 + var8.X * var10, var2.Y / 2 + var8.Y * var10)
	tbl13.arrow.Rotation = math.deg((math.atan2(var8.Y, var8.X))) + 90
end

local function buildPrompt()
	local var1 = str3.screen("FrozenHouseShedPrompt", 6)
	str3.autoScale(var1)
	local tbl1 = {
		Name = "Pill",
		BackgroundColor3 = var21.DeepBlue,
		AnchorPoint = Vector2.new(0.5, 0),
		Visible = false,
	}

	tbl1.Position = UDim2.new(0.5, 0, 0.5, 34)
	tbl1.Size = UDim2.fromOffset(0, 54)
	tbl1.AutomaticSize = Enum.AutomaticSize.X
	tbl1.Parent = var1
	local var2 = str3.corner(27)
	local var3 = var19("UIStroke", { Color = var21.White, Thickness = 3 })
	local tbl2 = { PaddingLeft = UDim.new(0, 8) }
	tbl2.PaddingRight = UDim.new(0, 22)
	local str1 = "UIPadding"
	local var4 = var19("Frame", tbl1, { var2, var3, var19(str1, tbl2) })
	local tbl3 = {
		FillDirection = Enum.FillDirection.Horizontal,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 12),
	}

	tbl3.SortOrder = Enum.SortOrder.LayoutOrder
	tbl3.Parent = var4
	var19("UIListLayout", tbl3)
	tbl3 = {
		Name = "Key",
		BackgroundColor3 = var21.Cream,
		Size = UDim2.fromOffset(40, 40),
		LayoutOrder = 1,
	}

	tbl3.Parent = var4
	var3 = str3.corner(10)
	str1 = "UIStroke"
	tbl2 = { Color = var21.Text, Thickness = 2 }
	local var5 = var19("Frame", tbl3, { var3, var19(str1, tbl2) })
	var2 = { Text = "E", FontFace = var20.Display, TextSize = 26, Size = UDim2.fromScale(1, 1) }
	var2.Parent = var5
	tbl12.key = str3.label(var2)
	var3 = {
		Name = "Glyph",
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
	}

	var3.Position = UDim2.fromScale(0.5, 0.5)
	var3.Size = UDim2.fromOffset(34, 34)
	var3.Parent = var5
	tbl12.glyph = var19("ImageLabel", var3)
	var2 = {
		Name = "Action",
		Text = "",
		FontFace = var20.Display,
		TextSize = 26,
		TextColor3 = var21.Cream,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 40),
		LayoutOrder = 2,
	}

	var2.Parent = var4
	tbl12.text = str3.label(var2)
	tbl12.pill = var4
	var2 = {
		Name = "TouchPrompt",
		Text = "",
		TextSize = 30,
		AnchorPoint = Vector2.new(0.5, 0),
		Radius = 41,
	}

	var2.Position = UDim2.new(0.5, 0, 0.5, 56)
	var2.Size = UDim2.fromOffset(330, 82)
	var2.Parent = var1
	var2.OnClick = function()
		var26(var27)
	end

	tbl12.button = str3.button(var2)
	tbl12.button.Visible = false
end

local function buildCard()
	local var1 = str3.screen("FrozenHouseShedCard", 21)
	str3.autoScale(var1)
	tbl4.gui = var1
	local tbl1 = {
		Name = "Root",
		BackgroundTransparency = 1,
		Size = UDim2.fromScale(1, 1),
		Visible = false,
	}

	tbl1.Parent = var1
	tbl4.root = var19("Frame", tbl1)
	local tbl2 = { Name = "Card", AnchorPoint = Vector2.new(0.5, 0.5), Radius = 26 }
	tbl2.Position = UDim2.fromScale(0.5, 0.5)
	tbl2.Size = UDim2.fromOffset(520, 402)
	tbl2.Parent = tbl4.root
	local var2 = str3.panel(tbl2)
	tbl2 = var2:FindFirstChildOfClass("UIStroke")
	tbl2.Color = var21.DeepBlue
	tbl2.Thickness = 4
	tbl4.pop = var19("UIScale", { Parent = var2 })
	local tbl3 = {
		Name = "Title",
		Text = "",
		FontFace = var20.Display,
		TextSize = 34,
		TextColor3 = var21.DeepBlue,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(26, 14),
	}

	tbl3.Size = UDim2.fromOffset(420, 44)
	tbl3.Parent = var2
	tbl4.name = str3.label(tbl3)
	tbl3 = {
		Name = "Close",
		AutoButtonColor = false,
		Text = "X",
		FontFace = var20.Display,
		TextSize = 30,
		TextColor3 = var21.White,
		BackgroundColor3 = var21.Coral,
		AnchorPoint = Vector2.new(0.5, 0.5),
		ZIndex = 3,
	}

	tbl3.Position = UDim2.new(1, -14, 0, 14)
	tbl3.Size = UDim2.fromOffset(54, 54)
	tbl3.Parent = var2
	local var3 = str3.corner(16)
	local str1 = "UIStroke"
	local tbl5 = { Color = var21.Text, Thickness = 3, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }
	local var4 = var19("TextButton", tbl3, { var3, var19(str1, tbl5) })
	str3.fitText(var4)
	var4.Activated:Connect(function()
		var22()
	end)

	var3 = { Name = "Tile", BackgroundColor3 = var21.White, Position = UDim2.fromOffset(26, 70) }
	var3.Size = UDim2.fromOffset(170, 170)
	var3.Parent = var2
	tbl4.tile = var19("Frame", var3, { str3.corner(18), str3.stroke() })
	local tbl6 = {
		Name = "Tagline",
		Text = "",
		FontFace = var20.Body,
		TextSize = 21,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Top,
		Position = UDim2.fromOffset(214, 72),
	}

	tbl6.Size = UDim2.fromOffset(282, 50)
	tbl6.Parent = var2
	tbl4.tagline = str3.label(tbl6)
	tbl6 = { Name = "Price", BackgroundTransparency = 1, Position = UDim2.fromOffset(214, 122) }
	tbl6.Size = UDim2.fromOffset(282, 48)
	tbl6.Parent = var2
	tbl1 = var19("Frame", tbl6)
	var3 = {
		FillDirection = Enum.FillDirection.Horizontal,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 8),
	}

	var3.SortOrder = Enum.SortOrder.LayoutOrder
	var3.Parent = tbl1
	var19("UIListLayout", var3)
	tbl4.coin = str3.coin(34)
	tbl4.coin.LayoutOrder = 1
	tbl4.coin.Parent = tbl1
	var3 = {
		Name = "Amount",
		Text = "",
		FontFace = var20.Display,
		TextSize = 36,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromScale(0, 1),
		LayoutOrder = 2,
	}

	var3.Parent = tbl1
	tbl4.amount = str3.label(var3)
	tbl4.check = checkMark(36, var21.Teal)
	tbl4.check.LayoutOrder = 3
	tbl4.check.Parent = tbl1
	var3 = {
		Name = "Coins",
		Text = "",
		FontFace = var20.Bold,
		TextSize = 19,
		TextColor3 = str3.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(214, 172),
	}

	var3.Size = UDim2.fromOffset(282, 24)
	var3.Parent = var2
	tbl4.coins = str3.label(var3)
	var3 = {
		Name = "Status",
		Text = "",
		FontFace = var20.Bold,
		TextSize = 19,
		TextColor3 = var17,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Top,
		Position = UDim2.fromOffset(214, 200),
	}

	var3.Size = UDim2.fromOffset(282, 44)
	var3.Parent = var2
	tbl4.status = str3.label(var3)
	var3 = {
		Name = "Buy",
		Text = "",
		TextSize = 26,
		Position = UDim2.fromOffset(26, 252),
		Radius = 16,
	}

	var3.Size = UDim2.fromOffset(330, 54)
	var3.Parent = var2
	var3.OnClick = function()
		if tbl4.action then
			tbl4.action()
		end
	end

	tbl4.buy = str3.button(var3)
	var3 = {
		Name = "Pass",
		Text = "",
		TextSize = 22,
		Secondary = true,
		Position = UDim2.fromOffset(26, 332),
		Radius = 16,
		Visible = false,
	}

	var3.Size = UDim2.fromOffset(468, 50)
	var3.Parent = var2
	var3.OnClick = function()
		if tbl4.passAction then
			tbl4.passAction()
		end
	end

	tbl4.pass = str3.button(var3)
	var3 = {
		Name = "PassNote",
		Text = "",
		FontFace = var20.Bold,
		TextSize = 16,
		TextColor3 = str3.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Center,
		Position = UDim2.fromOffset(26, 310),
		Visible = false,
	}

	var3.Size = UDim2.fromOffset(468, 20)
	var3.Parent = var2
	tbl4.passNote = str3.label(var3)
	var3 = {
		Name = "Cancel",
		Text = "Cancel",
		TextSize = 24,
		Secondary = true,
		Position = UDim2.fromOffset(368, 252),
		Radius = 16,
	}

	var3.Size = UDim2.fromOffset(126, 54)
	var3.Parent = var2
	var3.OnClick = function()
		var22()
	end

	tbl4.cancel = str3.button(var3)
end

local function buildWay()
	local var1 = var19("ScreenGui", {
		Name = "FrozenHouseShedWay",
		ResetOnSpawn = false,
		IgnoreGuiInset = true,
		ScreenInsets = Enum.ScreenInsets.None,
		DisplayOrder = 7,
		Parent = var9.LocalPlayer:WaitForChild("PlayerGui"),
	})

	local tbl1 = {
		Name = "Arrow",
		BackgroundColor3 = var21.DeepBlue,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Visible = false,
	}

	tbl1.Size = UDim2.fromOffset(66, 66)
	tbl1.Parent = var1
	local var2 = str3.corner(33)
	local str1 = "UIStroke"
	local tbl2 = { Color = var21.White, Thickness = 3 }
	local var3 = var19("Frame", tbl1, { var2, var19(str1, tbl2) })
	local num1 = 1
	for k1, v1 in ipairs({ -1, num1 }) do
		local tbl3 = {
			BackgroundColor3 = var21.Orange,
			BorderSizePixel = 0,
			AnchorPoint = Vector2.new(0.5, 0.5),
		}

		tbl3.Position = UDim2.fromOffset(33 + v1 * 8, 30)
		tbl3.Size = UDim2.fromOffset(28, 8)
		tbl3.Rotation = v1 * 45
		tbl3.Parent = var3
		local num2 = 4
		var19("Frame", tbl3, { str3.corner(num2) })
	end

	tbl13.gui = var1
	tbl13.arrow = var3
end

local tbl14 = {}
local function step(arg1)
	var27 = pickTarget()
	for k1, v1 in ipairs(tbl11) do
		local bool1 = false
		if v1 == var27 then
			bool1 = v1.action ~= nil
		end

		if v1.prompt.Enabled ~= bool1 then
			v1.prompt.Enabled = bool1
		end

		local var2 = bool1
		if not var2 then
			var2 = v1.celebrating == true
		end

		if v1.highlight.Enabled == var2 then
			continue
		end

		v1.highlight.Enabled = var2
	end

	renderPrompt()
	if tbl4.display then
		checkCard()
	end

	if tbl13.active then
		updateWay(arg1)
	end
end

local function decorateHeader(arg1)
	local var1 = arg1.model:FindFirstChild("Header")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Label")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Status")
	if not var3 then
		return
	end

	var3:ClearAllChildren()
	local tbl1 = {
		FillDirection = Enum.FillDirection.Horizontal,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 10),
	}

	tbl1.SortOrder = Enum.SortOrder.LayoutOrder
	tbl1.Parent = var3
	var19("UIListLayout", tbl1)
	arg1.coin = str3.coin(40)
	arg1.coin.LayoutOrder = 1
	arg1.coin.Parent = var3
	local tbl2 = {
		Name = "Amount",
		Text = "",
		FontFace = var20.Display,
		TextSize = 46,
		TextWrapped = false,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromScale(0, 1),
		LayoutOrder = 2,
	}

	tbl2.Parent = var3
	arg1.amount = str3.label(tbl2)
	arg1.check = checkMark(46, var21.Teal)
	arg1.check.LayoutOrder = 3
	arg1.check.Parent = var3
	arg1.note = var2:FindFirstChild("Note")
end

var26 = function(arg1)
	if not arg1 or arg1 ~= var27 then
		return
	end

	if arg1.action == "View" then
		openCard(arg1)
		return
	end

	if arg1.action == "Equip" then
		if bool1 then
			return
		end

		bool1 = true
		task.spawn(function()
			local var1 = invoke("equip", arg1.def.Id)
			bool1 = false
			if var1.ok then
				var23.Audio.play("UITick", 0.05)
				var23.HUD.toast(string.format(var6.Text.ToolEquipped, arg1.def.Name), 2)
			end

			var18()
		end)

	end
end

local function adaptPoster(arg1)
	local var1 = arg1:FindFirstChild("Decorations")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Poster")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Label")
	local var4 = var3
	local var5 = var3
	var4 = var4 and var3:FindFirstChild("Upgrade")
	var5 = var5 and var3:FindFirstChild("Alternative")
	if not var4 or (not var5) then
		return
	end

	local var7 = str2.Controls.mode()
	local function apply()
		local var2 = str2.Controls.mode()
		local var3
		if var2 == str2.Mode.Touch then
			var3 = "touch"
		else
			var3 = if var2 == str2.Mode.Gamepad then "gamepad" else "keyboard"
		end

		if var3 == "touch" then
			var4.Text = "UPGRADE THEM: TAP UPGRADES"
			var5.Text = "The button on the left of your screen"
			return
		end

		if var3 == "gamepad" then
			var4.Text = "UPGRADE THEM: D-PAD LEFT"
			var5.Text = "Anywhere, any time"
			return
		end

		var4.Text = "UPGRADE THEM WITH TAB"
		var5.Text = "or click the Upgrades button"
	end

	local var8
	if var7 == str2.Mode.Touch then
		var8 = "touch"
	else
		var8 = if var7 == str2.Mode.Gamepad then "gamepad" else "keyboard"
	end

	if var8 == "touch" then
		var4.Text = "UPGRADE THEM: TAP UPGRADES"
		var5.Text = "The button on the left of your screen"
	elseif var8 == "gamepad" then
		var4.Text = "UPGRADE THEM: D-PAD LEFT"
		var5.Text = "Anywhere, any time"
	else
		var4.Text = "UPGRADE THEM WITH TAB"
		var5.Text = "or click the Upgrades button"
	end

	var12.LastInputTypeChanged:Connect(apply)
end

return {
	showWay = function()
		tbl13.active = false
		if tbl13.anchor then
			tbl13.anchor:Destroy()
			tbl13.anchor = nil
		end

		if tbl13.arrow then
			tbl13.arrow.Visible = false
		end

		local var1 = tbl13
		local var2 = var1.session + 1
		var1.session = var2
		local var3 = str1.character()
		var2 = var3
		var2 = var2 and var3:FindFirstChild("HumanoidRootPart")
		var1 = tbl13.session
		if var2 and var13.insideShed(var2.Position) then
			var23.HUD.toast(var6.Text.ShedHere, 3)
			return
		end

		var3 = var13.ToolShed
		local var4 = var13.shedPoint((Vector3.new(0, var3.MarkerHeight, -var3.HalfDepth)))
		local var5 = Instance.new("Part")
		var5.Name = "ToolShedMarker"
		var5.Anchored = true
		var5.CanCollide = false
		var5.CanQuery = false
		var5.CanTouch = false
		var5.Transparency = 1
		var5.Size = Vector3.new(0.2, 0.2, 0.2)
		var5.CFrame = CFrame.new(var4)
		var5.Parent = workspace
		local var7 = Instance.new("BillboardGui")
		var7.Size = UDim2.fromOffset(190, 120)
		var7.AlwaysOnTop = true
		var7.MaxDistance = 2000
		var7.LightInfluence = 0
		var7.Parent = var5
		local tbl1 = { BackgroundColor3 = var21.DeepBlue, Size = UDim2.fromScale(1, 0.5) }
		tbl1.Parent = var7
		local var8 = str3.corner(20)
		local str2 = "UIStroke"
		local tbl2 = { Color = var21.White, Thickness = 3 }
		local var9 = var19("Frame", tbl1, { var8, var19(str2, tbl2) })
		tbl1 = {
			Text = "TOOL SHED",
			FontFace = var20.Display,
			TextScaled = true,
			TextColor3 = var21.Cream,
			Position = UDim2.fromScale(0.08, 0.14),
		}

		tbl1.Size = UDim2.fromScale(0.84, 0.72)
		tbl1.Parent = var9
		str3.label(tbl1)
		local tbl3 = { BackgroundTransparency = 1, ClipsDescendants = true, AnchorPoint = Vector2.new(0.5, 0) }
		tbl3.Position = UDim2.fromScale(0.5, 0.56)
		tbl3.Size = UDim2.fromOffset(64, 40)
		tbl3.Parent = var7
		local var10 = var19("Frame", tbl3)
		var8 = { BackgroundColor3 = var21.Orange, AnchorPoint = Vector2.new(0.5, 0.5), Rotation = 45 }
		var8.Position = UDim2.new(0.5, 0, 0, -6)
		var8.Size = UDim2.fromOffset(44, 44)
		var8.Parent = var10
		tbl2 = "UIStroke"
		local tbl4 = { Color = var21.Text, Thickness = 3 }
		var19("Frame", var8, { var19(tbl2, tbl4) })
		tbl13.anchor = var5
		tbl13.bb = var7
		tbl13.position = var4
		tbl13.clock = 0
		tbl13.active = true
		var23.HUD.toast(var6.Text.ShedWay, 3)
		task.delay(var25.ShowSeconds, function()
			if tbl13.session == var1 then
				tbl13.active = false
				if tbl13.anchor then
					tbl13.anchor:Destroy()
					tbl13.anchor = nil
				end

				if tbl13.arrow then
					tbl13.arrow.Visible = false
				end
			end
		end)
	end,
	init = function(arg1)
		var23 = arg1
		buildPrompt()
		buildCard()
		buildWay()
		var10.PromptShown:Connect(function(arg1, arg2)
			local var2 = tbl14[arg1]
			if var2 then
				var28 = { display = var2, inputType = arg2 }
			end
		end)

		var10.PromptHidden:Connect(function(arg1)
			if var28 and var28.display.prompt == arg1 then
				var28 = nil
			end
		end)

		var12.InputBegan:Connect(function(arg1)
			if tbl4.display and arg1.KeyCode == Enum.KeyCode.Escape then
				var22()
			end
		end)

		str1.cinematicChanged:Connect(function(arg1)
			if arg1 then
				var22()
			end
		end)

		str1.on("LobbyTeleporting", function()
			var22()
		end)

		var9.LocalPlayer.CharacterRemoving:Connect(function()
			var22()
		end)

		local str2 = "OwnedTools"
		for k1, v1 in ipairs({ "Coins", str2, "EquippedTool", "RunClass", "Grenades", "BatteryBoost" }) do
			local var1 = v1
			str1.onPlayerAttr(var1, function()
				var18()
			end)

		end

		var8.PromptGamePassPurchaseFinished:Connect(function(arg1, arg2, arg3)
			local var2 = passFor(tbl8.display)
			if arg1 ~= var9.LocalPlayer or (not tbl8.state or (not var2 or var2.GamePassId ~= arg2)) then
				return
			end

			tbl8.state = nil
			if arg3 then
				var24()
				return
			end

			local var3 = os.clock()
			tbl4.message = var6.Text.PurchaseCancelled
			tbl4.messageAt = var3
			task.delay(2.5, function()
				if tbl4.messageAt == var3 then
					tbl4.message = nil
					var24()
				end
			end)

			var24()
		end)

		local function productDisplay(arg1)
			local var2 = var4.ByKey[arg1]
			local var3 = if var2 then var4.displayKey(var2) else arg1
			for k1, v1 in ipairs(tbl11) do
				if not v1.product then
					continue
				end

				if v1.product.Key ~= var3 then
					continue
				end

				return v1
			end

			return nil
		end

		for k2, v2 in ipairs(var5.List) do
			if not var5.configured(v2) then
				continue
			end

			local var2 = v2
			var9.LocalPlayer:GetAttributeChangedSignal(var5.attribute(var2)):Connect(function()
				var18()
			end)

		end

		var9.LocalPlayer:GetAttributeChangedSignal("PermanentTools"):Connect(function()
			var18()
		end)

		var8.PromptProductPurchaseFinished:Connect(function(arg1, arg2, arg3)
			local var2 = tbl6.product
			if arg1 ~= var9.LocalPlayer.UserId or (not tbl6.state or (not var2 or var2.ProductId ~= arg2)) then
				return
			end

			if arg3 then
				tbl6.state = "confirming"
				local var3 = os.clock()
				tbl6.at = var3
				var24()
				return
			end

			tbl6.state = nil
			local var4 = os.clock()
			tbl4.message = var6.Text.PurchaseCancelled
			tbl4.messageAt = var4
			task.delay(2.5, function()
				if tbl4.messageAt == var4 then
					tbl4.message = nil
					var24()
				end
			end)

			var24()
		end)

		str1.on("PurchaseConfirming", function(arg1)
			local bool2 = false
			local var1 = arg1.product
			if tbl6.state ~= nil then
				bool2 = false
				if tbl6.product ~= nil then
					bool2 = tbl6.product.Key == var1
				end
			end

			if bool2 and tbl6.state == "prompt" then
				tbl6.state = "confirming"
				local var2 = os.clock()
				tbl6.at = var2
				var24()
			end
		end)

		str1.on("PurchaseCancelled", function(arg1)
			local bool2 = false
			local var1 = arg1.product
			if tbl6.state ~= nil then
				bool2 = false
				if tbl6.product ~= nil then
					bool2 = tbl6.product.Key == var1
				end
			end

			if bool2 then
				tbl6.state = nil
				var1 = os.clock()
				tbl4.message = var6.Text.PurchaseCancelled
				tbl4.messageAt = var1
				task.delay(2.5, function()
					if tbl4.messageAt == var1 then
						tbl4.message = nil
						var24()
					end
				end)

				var24()
			end
		end)

		str1.on("PurchasePending", function(arg1)
			local bool2 = false
			local var1 = arg1.product
			if tbl6.state ~= nil then
				bool2 = false
				if tbl6.product ~= nil then
					bool2 = tbl6.product.Key == var1
				end
			end

			if bool2 then
				tbl6.state = nil
				var24()
			end
		end)

		str1.on("PurchaseDelivered", function(arg1)
			local var2 = productDisplay(arg1.product)
			if not var2 then
				return
			end

			local bool2 = false
			local var3 = arg1.product
			if tbl6.state ~= nil then
				bool2 = false
				if tbl6.product ~= nil then
					bool2 = tbl6.product.Key == var3
				end
			end

			if bool2 then
				tbl6.state = nil
			end

			num1 = os.clock() + 0.5
			if arg1.product == "Flamethrower" then
				tbl1.Flamethrower = true
				if var23.Manual and var23.Manual.noteOwned then
					var23.Manual.noteOwned("Flamethrower")
				end

				if tbl4.display == var2 then
					var22()
				end
			end

			var18()
			celebrate(var2)
		end)

		str1.onAttr("ProductsAvailable", function()
			for k1, v1 in ipairs(var4.List) do
				fetchPrice(v1)
			end

			var18()
		end)

		str1.onAttr("GodlyCount", function()
			var18()
		end)

		var11.RenderStepped:Connect(step)
		task.spawn(function()
			local var2 = workspace:WaitForChild("FrozenHouse"):WaitForChild("World"):WaitForChild("Grounds"):WaitForChild("ToolShed", 60)
			if not var2 then
				warn("[FrozenHouse] The Tool Shed was not found; tools cannot be bought on this client.")
				return
			end

			local var3 = var2:WaitForChild("InteractionPoints")
			local var7 = var2:WaitForChild("Displays")
			local tbl1 = {}
			for k1, v1 in ipairs(var13.ToolShed.Displays) do
				table.insert(tbl1, { id = "Display_" .. v1.ToolId, def = var6.ToolById[v1.ToolId] })
			end

			for k2, v2 in ipairs(var13.ToolShed.ProductDisplays) do
				local var8 = var4.ByKey[v2.Key]
				local var10 = var6.ToolById[var8.ToolId or ""]
				local tbl2 = { id = "Display_" .. v2.Key, product = var8 }
				if not var10 then
					local var11 = var8.Model
					var10 = { Id = var11 or var6.Grenade.ToolId }
					var10.Name = var8.Name
				end

				tbl2.def = var10
				table.insert(tbl1, tbl2)
				fetchPrice(var8)
				tbl2 = var8.Key
				for k3, v3 in ipairs(var4.alsoAt(tbl2)) do
					fetchPrice(v3)
				end

				local var12 = var5.forTool(var8.ToolId)
				var12 = var12 or var5.forProduct(var8.Key)
				if not var12 then
					continue
				end

				fetchPassPrice(var12)
			end

			for k4, v4 in ipairs(tbl1) do
				local var14 = v4.id
				local var15 = var3:WaitForChild(var14)
				local tbl3 = {
					id = var14,
					def = v4.def,
					product = v4.product,
					point = var15,
					prompt = var15:WaitForChild("ShedPrompt"),
				}

				tbl3.model = var7:WaitForChild(var14)
				tbl3.prompt.Enabled = false
				local var16 = Instance.new("Highlight")
				var16.Name = "ShedTarget"
				var16.Adornee = tbl3.model:WaitForChild("Tool")
				var16.FillColor = var21.Orange
				var16.FillTransparency = 1
				var16.OutlineColor = var21.Orange
				var16.OutlineTransparency = 0.15
				var16.DepthMode = Enum.HighlightDepthMode.Occluded
				var16.Enabled = false
				var16.Parent = tbl3.model
				tbl3.highlight = var16
				decorateHeader(tbl3)
				tbl14[tbl3.prompt] = tbl3
				tbl3.prompt.Triggered:Connect(function()
					var26(tbl3)
				end)

				table.insert(tbl11, tbl3)
			end

			adaptPoster(var2)
			var18()
		end)
	end,
	describe = function()
		local var1 = var27
		local tbl1 = { target = var1 and var27.id }
		var1 = tbl4.display
		tbl1.card = var1 and tbl4.display.id
		var1 = tbl4.amount
		tbl1.cardAmount = var1 and tbl4.amount.Text
		var1 = tbl4.buy
		tbl1.cardButton = var1 and tbl4.buy.Text
		var1 = tbl4.status
		tbl1.cardStatus = var1 and tbl4.status.Text
		var1 = tbl4.coins
		tbl1.cardCoins = var1 and tbl4.coins.Text
		if tbl12.pill then
			if tbl12.pill.Visible then
				var1 = (if tbl12.glyph.Visible then "[glyph]" else tbl12.key.Text) .. " " .. tbl12.text.Text
				var1 = var1 or (tbl12.button.Visible and tbl12.button.Text or nil)
			end

			var1 = tbl12.button.Visible and tbl12.button.Text or nil
		end

		tbl1.prompt = nil
		tbl1.purchase = tbl6.state
		tbl1.passButton = if tbl4.pass and tbl4.pass.Visible then tbl4.pass.Text else nil
		tbl1.passNote = if tbl4.passNote and tbl4.passNote.Visible then tbl4.passNote.Text else nil
		tbl1.passAction = tbl4.passAction ~= nil
		tbl1.passPurchase = tbl8.state
		var1 = {}
		for k1, v1 in ipairs(var5.List) do
			if not var5.configured(v1) then
				continue
			end

			local var2 = v1
			local var4 = var9.LocalPlayer:GetAttribute(var5.attribute(var2))
			local var6 = v1.Key
			local var7 = string.format
			local str2 = "owned=%s price=%s"
			local var8
			if var4 == "yes" then
				var8 = true
			elseif var4 == "no" then
				var8 = false
			else
				var8 = nil
			end

			local var10 = tbl3[v1.Key]
			local var11 = tostring(var8)
			var1[var6] = var7(str2, var11, (tostring(var10 and (var10.forSale and var10.price) or nil)))
		end

		tbl1.passes = var1
		tbl1.prices = {}
		tbl1.way = tbl13.active
		var1 = tbl13.arrow
		tbl1.arrow = var1 and tbl13.arrow.Visible
		tbl1.menu = str1.menuOpen
		tbl1.displays = {}
		for k2, v2 in pairs(tbl2) do
			tbl1.prices[k2] = v2.price
		end

		for k3, v3 in ipairs(tbl11) do
			local var12 = tbl1.displays
			local var13 = string.format
			local str3 = "%s: %s%s | note=%q | action=%s | prompt on=%s | outline=%s"
			local var14 = v3.id
			var8 = v3.amount and v3.amount.Text or "?"
			local var15 = if v3.check and v3.check.Visible then " +check" else ""
			local var16 = v3.note and v3.note.Text or ""
			local var17 = tostring(v3.action)
			local var18 = tostring(v3.prompt.Enabled)
			local var19 = tostring(v3.highlight.Enabled)
			table.insert(var12, var13(str3, var14, var8, var15, var16, var17, var18, var19))
		end

		return tbl1
	end,
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Quests [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = require(var1.Layout)
local var3 = require(script.Parent.ClientState)
local var4 = require(var1.Config).Text
local var5 = var2.Y
local tbl1 = { box = var2.box(1.5, var5.Floor1 - 1, -17.5, 9.5, var5.Floor1 + 9, -11.5) }
tbl1.text = string.format(var4.LockedBasement, #var2.KeyPieces)
tbl1.locked = function()
	local var2 = not (var3.attr("BasementKeyFound") == true)
	if var2 then
		var2 = not (var3.attr("BasementOpen") == true)
	end

	return var2
end

local var6 = Vector3.new(0, 3, 0)
local tbl2 = {
	tbl1,
	{
		at = var2.Freezer.OffSwitch.Position + var6,
		radius = 12,
		text = var4.LockedFreezer,
		locked = function()
			local var2 = var3.attr("BasementOpen") == true
			if var2 then
				var2 = not (var3.attr("FreezerReady") == true)
			end

			return var2
		end,
	},
}

local tbl3 = { current = function()
	local var5 = var3.phase()
	if var5 == "Complete" then
		return var4.QuestDone
	end

	if var5 ~= "Running" then
		return ""
	end

	if var3.attr("FreezerReady") == true then
		return var4.QuestTurnOff
	end

	if not (var3.attr("FrontDoorOpen") == true) then
		return var4.QuestFrontDoor
	end

	local var6
	if not (var3.attr("BasementKeyFound") == true) then
		local tbl1 = {}
		for k1, v1 in ipairs(var2.KeyPieces) do
			if var3.attr("KeyPiece_" .. v1.Id) == true then
				continue
			end

			table.insert(tbl1, v1.Name)
		end

		local var7 = #var2.KeyPieces
		local var8 = tbl1
		local str1 = ", "
		local var9 = var4.QuestKeyPiecesLeft
		return string.format(var4.QuestFindKeyPieces, var7 - #tbl1, var7), string.format(var9, table.concat(var8, str1))
	end

	if not (var3.attr("BasementOpen") == true) then
		return var4.QuestUnlockBasement
	end

	if not (var3.attr("FreezerFound") == true) then
		return var4.QuestFindFreezer
	end

	local tbl2 = {}
	for k2, v2 in ipairs(var2.Regions) do
		if var3.attr("Region" .. v2.Id .. "Cleared") == true then
			continue
		end

		table.insert(tbl2, v2.Short)
	end

	local var11 = var4.QuestThawHouse
	if 0 < (#tbl2) then
		local var12 = tbl2
		local str3 = ", "
		return var11, (string.format(var4.QuestStillFrozen, table.concat(var12, str3)))
	end

	return var11, nil
end }

for k1, v1 in ipairs(var2.KeyPieces) do
	table.insert(tbl2, {
		at = v1.CFrame.Position,
		radius = 10,
		text = var4.FrozenKeyPiece,
		locked = function()
			local var2 = var3.attr("FrontDoorOpen") == true
			if var2 then
				var2 = not (var3.attr("Reveal_KeyPiece_" .. v1.Id) == true)
				if var2 then
					var2 = not (var3.attr("KeyPiece_" .. v1.Id) == true)
				end
			end

			return var2
		end,
	})

end

tbl3.callout = function(arg1)
	if var3.phase() ~= "Running" then
		return nil
	end

	for k1, v1 in ipairs(tbl2) do
		local var1
		if v1.box then
			var1 = var2.inside(v1.box, arg1)
		else
			var1 = (arg1 - v1.at).Magnitude <= v1.radius
		end

		if not var1 then
			continue
		end

		if not v1.locked() then
			continue
		end

		return v1.text
	end

	return nil
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ClassInfo [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("MeltShared")
local str1 = "Classes"
local str2 = "ClassIcons"
local str3 = "ClassPerks"
local var3 = require(var2:WaitForChild(str1))
local var4 = require(var2:WaitForChild(str2))
local var5 = require(var2:WaitForChild(str3))
local var6 = require(var1:WaitForChild("FrozenHouse").Config)
str3 = require(script.Parent.UIKit)
str1 = require(script.Parent.ClientState)
local var7 = nil
local var8 = nil
local var9 = nil
local var10 = nil
local var11 = nil
local var12 = var6.Palette
local var13 = nil
local var14 = var6.Text
local var15 = nil
local var16 = str3.new
local var17 = nil
local var18 = nil
local var19 = nil
local var20 = nil
local var21 = game:GetService("UserInputService")
str2 = require(script.Parent.Focus)
local tbl1 = { isOpen = function()
	local bool2 = false
	if var7 ~= nil then
		bool2 = var7.Visible
	end

	return bool2
end }

local function refresh()
	if not var7 or (not var7.Visible) then
		return
	end

	local var1 = str1.playerAttr("RunClass")
	local var2 = str1.playerAttr("ProfileClass")
	local var6
	local var21
	if typeof(var1) == "string" and var3.ById[var1] then
		var21 = var1
		var6 = true
	else
		if typeof(var2) == "string" and var3.ById[var2] then
			var21 = var2
			var6 = false
		else
			var21 = var3.StarterId
			var6 = false
		end
	end

	var1 = var3.ById[var21]
	var2 = str1.perks()
	if var8 ~= var21 then
		var8 = var21
		var9:ClearAllChildren()
		local tbl1 = { Size = UDim2.fromScale(1, 1) }
		tbl1.Parent = var9
		var4.build(var21, tbl1)
	end

	var10.Text = var1.Name
	var11.Text = var1.Tier .. "  \194\183  " .. var3.oddsText(var21)
	var11.TextColor3 = var1.Color:Lerp(var12.Text, 0.3)
	local var22 = var13
	var22.Text = if var6 then var14.ClassForRun else var14.ClassTitle
	var15:ClearAllChildren()
	local num1 = 0
	local num2 = 6
	local tbl2 = { Padding = UDim.new(num1, num2) }
	tbl2.SortOrder = Enum.SortOrder.LayoutOrder
	tbl2.Parent = var15
	var16("UIListLayout", tbl2)
	var22 = var5.lines(var2)
	if #var22 == 0 then
		var22 = { var14.ClassNoPerks }
	end

	for k1, v1 in ipairs(var22) do
		local tbl3 = {
			Text = "\226\128\162  " .. v1,
			TextSize = 19,
			TextXAlignment = Enum.TextXAlignment.Left,
			TextYAlignment = Enum.TextYAlignment.Top,
			AutomaticSize = Enum.AutomaticSize.Y,
			Size = UDim2.fromScale(1, 0),
		}

		tbl3.LayoutOrder = k1
		tbl3.Parent = var15
		str3.label(tbl3)
	end

	var17.Visible = var2.team
	if var2.team then
		local tbl4 = {}
		if var2.fromTeam then
			table.insert(tbl4, var14.TeamFromGodly)
		end

		if 100 < var2.amp then
			local var27 = 5000 * var2.amp // 100
			local var28 = var14.TeamBonusExplain
			local var29 = var2.godlies
			local var30 = var2.amp - 100
			table.insert(tbl4, string.format(var28, var29, var30, var5.percent(var27)))
		end

		tbl2 = var18
		local var31 = if 100 < var2.amp then var14.TeamPerks .. "  \194\183  " .. string.format(var14.TeamBonus, var2.amp - 100) else var14.TeamPerks
		tbl2.Text = var31
		var19.Text = table.concat(tbl4, [[
]])

		var19.Visible = 0 < (#tbl4)
	end

	local var33 = str1.playerAttr("ClassStatus") or "Off"
	tbl2 = var20
	local var34
	if var33 == "Loading" then
		var34 = var14.ClassLoading
	elseif var33 == "Unavailable" or var33 == "Outdated" then
		var34 = var14.ClassUnavailable
	elseif var33 == "Off" then
		var34 = var14.ClassOff
	else
		var34 = ""
	end

	tbl2.Text = var34
	var20.Visible = var20.Text ~= ""
end

local var22 = nil
local var23 = nil
tbl1.open = function()
	if str1.menuOpen and str1.menuOpen ~= "ClassInfo" then
		return
	end

	if tbl1.isOpen() then
		return
	end

	var7.Visible = true
	str1.setMenu("ClassInfo")
	refresh()
	if str1.settings.ReducedEffects then
		var22.Scale = 1
	else
		var22.Scale = 0.94
		str3.tween(var22, 0.16, { Scale = 1 }, Enum.EasingStyle.Back)
	end

	local tbl2 = { root = var7, hints = str2.basic(var6.Text.HintClose), lockControls = false }
	tbl2.initial = function()
		return var23
	end

	tbl2.back = tbl1.close
	str2.open("FrozenHouseClassInfo", tbl2)
end

tbl1.close = function()
	if not tbl1.isOpen() then
		return
	end

	var7.Visible = false
	if str1.menuOpen == "ClassInfo" then
		str1.setMenu(nil)
	end

	str2.close("FrozenHouseClassInfo")
end

tbl1.toggle = function()
	if tbl1.isOpen() then
		tbl1.close()
		return
	end

	tbl1.open()
end

tbl1.describe = function()
	local tbl2 = {}
	for k1, v1 in ipairs(var15 and var15:GetChildren() or {}) do
		if not v1:IsA("TextLabel") then
			continue
		end

		table.insert(tbl2, v1.Text)
	end

	local var1 = var10
	local tbl3 = { open = tbl1.isOpen() }
	tbl3.name = var1 and var10.Text
	var1 = var11
	tbl3.tier = var1 and var11.Text
	var1 = var13
	tbl3.heading = var1 and var13.Text
	tbl3.perks = tbl2
	tbl3.team = var17 and (var17.Visible and var18.Text) or nil
	tbl3.teamText = var17 and (var17.Visible and var19.Text) or nil
	tbl3.status = var20 and (var20.Visible and var20.Text) or nil
	return tbl3
end

local var24 = nil
local var25 = nil
tbl1.init = function(arg1)
	var24 = arg1
	var25 = str3.screen("FrozenHouseClassInfo", 22)
	str3.autoScale(var25)
	local tbl2 = {
		Name = "Root",
		BackgroundTransparency = 1,
		Size = UDim2.fromScale(1, 1),
		Visible = false,
	}

	tbl2.Parent = var25
	var7 = var16("Frame", tbl2)
	str3.backdrop({ Name = "Dim", BackgroundTransparency = 0.55, Parent = var7 }).Activated:Connect(tbl1.close)
	tbl2 = { Name = "Panel", AnchorPoint = Vector2.new(0.5, 0.5), Radius = 24 }
	tbl2.Position = UDim2.fromScale(0.5, 0.52)
	tbl2.Size = UDim2.fromOffset(560, 540)
	tbl2.Parent = var7
	local var1 = str3.panel(tbl2)
	var22 = var16("UIScale", { Parent = var1 })
	local tbl3 = { Name = "Insignia", BackgroundTransparency = 1, Position = UDim2.fromOffset(26, 24) }
	tbl3.Size = UDim2.fromOffset(96, 96)
	tbl3.Parent = var1
	var9 = var16("Frame", tbl3)
	local tbl4 = {
		Name = "ClassName",
		Text = "",
		FontFace = str3.Fonts.Display,
		TextSize = 34,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = false,
		Position = UDim2.fromOffset(138, 30),
	}

	tbl4.Size = UDim2.new(1, -210, 0, 44)
	tbl4.Parent = var1
	var10 = str3.label(tbl4)
	tbl4 = {
		Name = "Tier",
		Text = "",
		FontFace = str3.Fonts.Bold,
		TextSize = 18,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(138, 76),
	}

	tbl4.Size = UDim2.new(1, -210, 0, 24)
	tbl4.Parent = var1
	var11 = str3.label(tbl4)
	tbl4 = {
		Name = "Close",
		Text = "X",
		TextSize = 26,
		Secondary = true,
		AnchorPoint = Vector2.new(1, 0),
		Radius = 26,
	}

	tbl4.Position = UDim2.new(1, -18, 0, 16)
	tbl4.Size = UDim2.fromOffset(52, 52)
	tbl4.Parent = var1
	tbl4.OnClick = function()
		if var24 and var24.Audio then
			var24.Audio.play("UITick", 0.05)
		end

		tbl1.close()
	end

	var23 = str3.button(tbl4)
	tbl4 = {
		Name = "Heading",
		Text = "",
		FontFace = str3.Fonts.Bold,
		TextSize = 17,
		TextColor3 = str3.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(26, 134),
	}

	tbl4.Size = UDim2.new(1, -52, 0, 22)
	tbl4.Parent = var1
	var13 = str3.label(tbl4)
	tbl3 = {
		Name = "Body",
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Position = UDim2.fromOffset(26, 162),
		ScrollBarThickness = 5,
	}

	tbl3.Size = UDim2.new(1, -40, 1, -250)
	tbl3.CanvasSize = UDim2.new()
	tbl3.AutomaticCanvasSize = Enum.AutomaticSize.Y
	tbl3.ScrollingDirection = Enum.ScrollingDirection.Y
	tbl3.Parent = var1
	local tbl5 = { Padding = UDim.new(0, 12) }
	tbl5.SortOrder = Enum.SortOrder.LayoutOrder
	local str2 = "UIListLayout"
	tbl2 = var16("ScrollingFrame", tbl3, { var16(str2, tbl5) })
	local tbl6 = {
		Name = "Perks",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, -12, 0, 0),
		LayoutOrder = 1,
	}

	tbl6.Parent = tbl2
	var15 = var16("Frame", tbl6)
	tbl6 = {
		Name = "Team",
		BackgroundColor3 = Color3.fromHex("#DDF1EE"),
		LayoutOrder = 2,
		Visible = false,
	}

	tbl6.AutomaticSize = Enum.AutomaticSize.Y
	tbl6.Size = UDim2.new(1, -12, 0, 0)
	tbl6.Parent = tbl2
	str2 = str3.corner(14)
	tbl5 = str3.padding(12)
	local tbl7 = { Padding = UDim.new(0, 4) }
	tbl7.SortOrder = Enum.SortOrder.LayoutOrder
	local str4 = "UIListLayout"
	var17 = var16("Frame", tbl6, { str2, tbl5, var16(str4, tbl7) })
	tbl3 = {
		Name = "Title",
		Text = "",
		FontFace = str3.Fonts.Bold,
		TextSize = 18,
		TextColor3 = Color3.fromHex("#21625E"),
		LayoutOrder = 1,
	}

	tbl3.TextXAlignment = Enum.TextXAlignment.Left
	tbl3.AutomaticSize = Enum.AutomaticSize.Y
	tbl3.Size = UDim2.fromScale(1, 0)
	tbl3.Parent = var17
	var18 = str3.label(tbl3)
	tbl3 = {
		Name = "Text",
		Text = "",
		TextSize = 16,
		TextXAlignment = Enum.TextXAlignment.Left,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.fromScale(1, 0),
		LayoutOrder = 2,
	}

	tbl3.Parent = var17
	var19 = str3.label(tbl3)
	tbl3 = {
		Name = "Status",
		Text = "",
		FontFace = str3.Fonts.Bold,
		TextSize = 16,
		TextColor3 = Color3.fromHex("#B8452F"),
		LayoutOrder = 3,
		Visible = false,
	}

	tbl3.TextXAlignment = Enum.TextXAlignment.Left
	tbl3.AutomaticSize = Enum.AutomaticSize.Y
	tbl3.Size = UDim2.new(1, -12, 0, 0)
	tbl3.Parent = tbl2
	var20 = str3.label(tbl3)
	tbl3 = {
		Name = "Lobby",
		Text = var14.ClassChangeInLobby,
		TextSize = 16,
		TextColor3 = str3.Colors.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		AnchorPoint = Vector2.new(0, 1),
	}

	tbl3.Position = UDim2.new(0, 26, 1, -20)
	tbl3.Size = UDim2.new(1, -52, 0, 44)
	tbl3.Parent = var1
	str3.label(tbl3)
	str2 = "ProfileClass"
	for k1, v1 in ipairs({ "RunClass", str2, "ClassStatus" }) do
		str1.onPlayerAttr(v1, refresh)
	end

	str1.onAttr("GodlyCount", refresh)
	var21.InputBegan:Connect(function(arg1)
		if tbl1.isOpen() and arg1.KeyCode == Enum.KeyCode.Escape then
			tbl1.close()
		end
	end)

	str1.cinematicChanged:Connect(function(arg1)
		if arg1 then
			tbl1.close()
		end
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Grenades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("MeltShared")
local str1 = "SkinArt"
local str2 = "SkinFx"
local var2 = require(var1:WaitForChild(str2))
local var3 = require(var1:WaitForChild(str1))
local var4 = game:GetService("ReplicatedStorage")
local var5 = var4:WaitForChild("FrozenHouse")
local var6 = require(var5.Config)
local var7 = require(script.Parent.ClientState)
local var8 = var6.Grenade
local var9 = nil
local var10 = require(script.Parent.IceWorld)
local var11 = game:GetService("HttpService")
local var12 = require(var5.Net)
local bool1 = false
local function invoke(arg1, arg2)
	local var1 = var11:GenerateGUID(false)
	local success, result = pcall(function()
		local var2 = arg1
		local var3 = arg2
		local var4 = nil
		local var5 = nil
		local var6 = var1
		return var12.get("Shop"):InvokeServer(var2, var3, var4, var5, var6)
	end)

	if success and typeof(result) == "table" then
		return result
	end

	return { ok = false, reason = "error" }
end

local var13 = nil
local var14 = game:GetService("Players")
str1 = game:GetService("RunService")
str2 = game:GetService("TweenService")
local var15 = game:GetService("UserInputService")
local var16 = require(var5.GrenadeFlight)
local var17 = require(script.Parent.Input)
local bool2 = false
local tbl1 = { none = var6.Text.NoGrenades, closed = "Grenades work while the run is on.", busy = nil }
local var18 = var6.Palette
local var19 = nil
local var20 = nil
local function cast(arg1, arg2)
	local var1 = arg2 - arg1
	local var3 = var1.Magnitude
	if var3 < 1e-06 then
		return nil
	end

	local var6 = workspace:Spherecast(arg1, var8.Radius, var1, var9)
	local var7 = var1 / var3
	local var11 = nil
	local num2 = math.huge
	if var6 then
		var11 = { position = arg1 + var7 * var6.Distance, normal = var6.Normal }
		num2 = var6.Distance
	end

	local var13 = var10.raycast(arg1, var7, var3 + var8.Radius)
	local var14 = math.max(0, var13.distance - var8.Radius)
	if var13 and (var13.normal and var14 < num2) then
		var11 = { position = arg1 + var7 * var14, normal = var13.normal }
	end

	return var11
end

local function canisterModel()
	local var1 = var4:FindFirstChild("FrozenHouseAssets")
	local var2 = var1
	var2 = var2 and (var1:FindFirstChild("Tools") and var1.Tools:FindFirstChild(var8.ToolId))
	if not var2 then
		return nil
	end

	local var3 = Instance.new("Model")
	var3.Name = "ThrownFireGrenade"
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local var5 = v1:Clone()
		for k2, v2 in ipairs(var5:GetDescendants()) do
			if not v2:IsA("WeldConstraint") then
				continue
			end

			v2:Destroy()
		end

		var5.Anchored = true
		var5.CanCollide = false
		var5.CanQuery = false
		var5.CanTouch = false
		var5.Parent = var3
	end

	local var6 = var3:FindFirstChild("Handle")
	var3.PrimaryPart = var6
	return var3
end

local function reduced()
	return var7.settings.ReducedEffects
end

local tbl2 = {}
local function burstEffect(arg1, arg2)
	local var1 = Instance.new("Part")
	var1.Name = "GrenadeBurst"
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.CFrame = CFrame.new(arg1)
	var1.Parent = var19
	local var2 = Instance.new("Part")
	var2.Name = "HeatWave"
	var2.Shape = Enum.PartType.Ball
	var2.Material = Enum.Material.Neon
	var2.Color = Color3.fromHex("#FFB46B")
	var2.Anchored = true
	var2.CanCollide = false
	var2.CanQuery = false
	var2.CanTouch = false
	var2.CastShadow = false
	var2.Size = Vector3.new(1.2, 1.2, 1.2)
	local var4 = var7.settings.ReducedEffects
	var2.Transparency = if var4 then 0.7 else 0.35
	var2.CFrame = CFrame.new(arg1)
	var2.Parent = var1
	local var5 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	str2:Create(var2, var5, { Size = Vector3.new(1, 1, 1) * (arg2 * (if var4 then 1.1 else 1.5)), Transparency = 1 }):Play()
	if not var4 then
		local var8 = Instance.new("PointLight")
		var8.Color = Color3.fromHex("#FF9A4D")
		var8.Range = arg2 * 2.2
		var8.Brightness = 2.5
		var8.Shadows = false
		var8.Parent = var1
		str2:Create(var8, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Brightness = 0 }):Play()
	end

	local var9 = Instance.new("ParticleEmitter")
	var9.Texture = "rbxasset://textures/particles/smoke_main.dds"
	var5 = 245
	local num1 = 250
	local num2 = 255
	var9.Color = ColorSequence.new(Color3.fromRGB(var5, num1, num2))
	var9.LightEmission = 0.1
	num2 = 1
	local num3 = 3.2
	var9.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(num2, num3) })
	num2 = 1
	num3 = 1
	var9.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(num2, num3) })
	var9.Lifetime = NumberRange.new(0.5, 0.8)
	var9.Speed = NumberRange.new(4, 9)
	var9.SpreadAngle = Vector2.new(180, 180)
	var9.Drag = 4
	var9.Acceleration = Vector3.new(0, 4, 0)
	var9.Rate = 0
	var9.Parent = var1
	var9:Emit(if var4 then 8 else 22)
	local var10 = Instance.new("ParticleEmitter")
	var10.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	var10.Color = ColorSequence.new(var6.IceLook.Edge)
	var10.LightEmission = 0.3
	var10.Size = NumberSequence.new(0.22, 0.06)
	var10.Transparency = NumberSequence.new(0.1, 0.9)
	var10.Lifetime = NumberRange.new(0.5, 0.8)
	var10.Speed = NumberRange.new(6, 12)
	var10.SpreadAngle = Vector2.new(70, 70)
	var10.EmissionDirection = Enum.NormalId.Top
	var10.Acceleration = Vector3.new(0, -40, 0)
	var10.Rate = 0
	var10.Parent = var1
	if not var4 then
		var10:Emit(14)
	end

	var13.Audio.playAt("GrenadeBurst", arg1, 0.05)
	task.delay(1.2, function()
		var1:Destroy()
	end)
end

local function updatePreview()
	local var1 = var7.character()
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Head")
	if var2 then
		if not var7.holdingGrenade() or (var7.menuOpen ~= nil or (var7.cinematic or var7.phase() ~= "Running")) then
			if var20 and var20.shown then
				var20.shown = false
				for k1, v1 in ipairs(var20.dots) do
					v1.Transparency = 1
				end

				var20.ring.Visible = false
			end

			return
		end
	end

	local var3 = workspace.CurrentCamera.CFrame.LookVector
	local var4 = var2.Position
	local var5 = var4 + var3 * var8.SpawnForward
	local var9 = cast(var4, var5)
	if var9 then
		var5 = var9.position
	end

	local var10 = var16.simulate(var5, var16.velocity(var3), cast, var8.PreviewSeconds, true)
	local var11 = var10.points
	local var12 = #var20.dots
	for k2, v2 in ipairs(var20.dots) do
		local var14 = math.floor(3 + (k2 - 1) * math.max(#var11 - 3, 0) / var12) + 1
		if var14 <= (#var11) and 4 < (#var11) then
			v2.CFrame = CFrame.new(var11[var14])
			v2.Transparency = 0.25 + 0.55 * (k2 / var12)
		else
			v2.Transparency = 1
		end
	end

	if var10.firstHit then
		var20.anchor.CFrame = CFrame.new(var10.firstHit) * CFrame.Angles(-1.5707963267948966, 0, 0)
		var20.ring.Visible = true
	else
		var20.ring.Visible = false
	end

	var20.shown = true
end

local function setWindows(arg1, arg2)
	for k1, v1 in ipairs(arg1.windows) do
		v1.Material = if arg2 then Enum.Material.Neon else Enum.Material.SmoothPlastic
	end
end

local function buildPreview()
	local tbl1 = {}
	for i1 = 1, var8.PreviewDots do
		local var1 = Instance.new("Part")
		var1.Name = "ArcDot"
		var1.Shape = Enum.PartType.Ball
		var1.Size = Vector3.new(0.2, 0.2, 0.2)
		var1.Material = Enum.Material.SmoothPlastic
		var1.Color = var18.Cream
		var1.Anchored = true
		var1.CanCollide = false
		var1.CanQuery = false
		var1.CanTouch = false
		var1.CastShadow = false
		var1.Transparency = 1
		var1.Parent = var19
		tbl1[i1] = var1
	end

	local var2 = Instance.new("Part")
	var2.Name = "LandingMarker"
	var2.Anchored = true
	var2.CanCollide = false
	var2.CanQuery = false
	var2.CanTouch = false
	var2.Transparency = 1
	var2.Size = Vector3.new(0.2, 0.2, 0.2)
	var2.Parent = var19
	local var3 = Instance.new("CylinderHandleAdornment")
	var3.Name = "Ring"
	var3.Adornee = var2
	var3.Height = 0.05
	var3.Radius = 0.9
	var3.InnerRadius = 0.72
	var3.Color3 = var18.Orange
	var3.Transparency = 0.35
	var3.Visible = false
	var3.Parent = var2
	var20 = { dots = tbl1, anchor = var2, ring = var3, shown = false }
end

local tbl3 = {
	toggle = function()
		if bool1 or (not var7.canPlay() or (var7.cinematic or var7.menuOpen ~= nil)) then
			return
		end

		if var7.holdingGrenade() then
			bool1 = true
			task.spawn(function()
				local var1 = var7.playerAttr("EquippedTool")
				invoke("hold", var1 or var6.StarterToolId)
				bool1 = false
			end)

			return
		end

		if var7.grenades() < 1 then
			var13.HUD.toast(var6.Text.NoGrenades .. ". " .. var6.Text.GrenadesInShed, 3)
			return
		end

		bool1 = true
		task.spawn(function()
			local var1 = invoke("hold", var8.ToolId)
			bool1 = false
			if var1.ok then
				var13.Audio.play("UITick", 0.05)
			end
		end)
	end,
	throw = function()
		if bool2 or (not var7.holdingGrenade() or (var7.menuOpen ~= nil or var7.cinematic)) then
			return
		end

		local var1 = var11:GenerateGUID(false)
		bool2 = true
		local var2 = workspace.CurrentCamera.CFrame.LookVector
		task.spawn(function()
			local success, result = pcall(function()
				local var3 = var1
				local var4 = var2
				return var12.get("Throw"):InvokeServer(var3, var4)
			end)

			bool2 = false
			if success then
				if typeof(result) == "table" then
					if result.ok then
						if var13.FirstPerson.throwKick then
							var13.FirstPerson.throwKick()
						end

						return
					end
				end
			end

			local var4 = tbl1[if success and typeof(result) == "table" then result.reason else nil]
			if var4 then
				var13.HUD.toast(var4, 2)
			end
		end)
	end,
}

local function onThrown(arg1)
	if typeof(arg1) ~= "table" or (typeof(arg1.id) ~= "string" or (typeof(arg1.points) ~= "table" or #arg1.points == 0)) then
		return
	end

	for k1, v1 in ipairs(arg1.points) do
		if typeof(v1) == "Vector3" then
			continue
		end

		return
	end

	local var4 = canisterModel()
	if not var4 or (not var4.PrimaryPart) then
		return
	end

	local var5 = arg1.points[1]
	var4:PivotTo(CFrame.new(var5))
	local var6 = if typeof(arg1.userId) == "number" then var14:GetPlayerByUserId(arg1.userId) else nil
	local var7 = var6
	var7 = var7 and var6:GetAttribute("GrenadeSkin")
	local var9 = nil
	if typeof(var7) == "string" then
		var4:SetAttribute("ToolId", var8.ToolId)
		local success, result = pcall(var3.apply, var4, var7)
		if success and result then
			var9 = var2.attach(var4, {
				mode = "world",
				reduced = reduced,
				active = function()
					return true
				end,
			})

		else
			pcall(var3.remove, var4)
			var7 = nil
		end
	end

	var4.Parent = var19
	local var11 = var4:FindFirstChild("Window" .. 1)
	success = {}
	if var11 then
		table.insert(success, var11)
	end

	var11 = var4:FindFirstChild("Window" .. 2)
	if var11 then
		table.insert(success, var11)
	end

	var11 = var4:FindFirstChild("Window" .. 3)
	if var11 then
		table.insert(success, var11)
	end

	var11 = Instance.new("BillboardGui")
	var11.Name = "Fuse"
	var11.Size = UDim2.fromOffset(44, 34)
	var11.StudsOffsetWorldSpace = Vector3.new(0, 1.1, 0)
	var11.MaxDistance = var8.LabelDistance
	var11.LightInfluence = 0
	var11.Adornee = var4.PrimaryPart
	local var12 = Instance.new("TextLabel")
	var12.BackgroundTransparency = 1
	var12.Size = UDim2.fromScale(1, 1)
	var12.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
	var12.TextScaled = true
	var12.TextColor3 = var18.Cream
	var12.TextStrokeColor3 = var18.Text
	var12.TextStrokeTransparency = 0.3
	var12.Text = tostring((math.ceil(var8.FuseSeconds)))
	var12.Parent = var11
	var11.Parent = var4.PrimaryPart
	local var15 = tbl2
	local var16 = arg1.id
	local var17 = if typeof(arg1.startedAt) == "number" then arg1.startedAt else workspace:GetServerTimeNow()
	local tbl3 = { model = var4, points = arg1.points, startedAt = var17, lastSecond = -1 }
	if typeof(arg1.fuse) == "number" then
		var17 = arg1.fuse
	else
		var17 = var8.FuseSeconds
	end

	tbl3.fuse = var17
	tbl3.label = var12
	tbl3.windows = success
	tbl3.skinId = var7
	tbl3.skinFx = var9
	tbl3.spin = math.random() * 3.1415926535897931 * 2
	var15[var16] = tbl3
	var13.Audio.playAt("GrenadeThrow", arg1.points[1], 0.1)
end

local function onBurst(arg1)
	if typeof(arg1) ~= "table" or typeof(arg1.position) ~= "Vector3" then
		return
	end

	local var2
	if typeof(arg1.id) == "string" then
		local var4 = arg1.id
		var2 = tbl2[var4]
		if var2 then
			tbl2[var4] = nil
			if var2.skinFx then
				var2.skinFx:destroy()
			end

			var2.model:Destroy()
		end
	else
		var2 = nil
	end

	local var5 = if typeof(arg1.radius) == "number" then arg1.radius else var8.BurstRadius
	burstEffect(arg1.position, var5)
	if var2 and var2.skinId then
		pcall(var3.grenadeBurst, var2.skinId, arg1.position, var5, var19, var7.settings.ReducedEffects)
	end
end

local function hidePreview()
	if var20 and var20.shown then
		var20.shown = false
		for k1, v1 in ipairs(var20.dots) do
			v1.Transparency = 1
		end

		var20.ring.Visible = false
	end
end

local function step(arg1)
	updatePreview()
	local var1 = workspace:GetServerTimeNow()
	for k1, v1 in pairs(tbl2) do
		local var3 = var1 - v1.startedAt
		if v1.fuse + 2 < var3 then
			local var4 = tbl2[k1]
			if not var4 then
				continue
			end

			tbl2[k1] = nil
			if var4.skinFx then
				var4.skinFx:destroy()
			end

			var4.model:Destroy()
		else
			local var5 = v1.spin + arg1 * 6
			v1.spin = var5
			var5 = var16.positionAt(v1.points, var3)
			local var7 = var3 < (#v1.points - 1) / var8.SampleHz
			local var9 = v1.model
			local var10 = CFrame.new(var5)
			local var11 = CFrame.Angles
			local var12 = if var7 then v1.spin else 0
			var9:PivotTo(var10 * var11(var12, if var7 then v1.spin * 0.6 else 0, 0))
			if v1.skinFx then
				v1.skinFx:_update(os.clock())
			end

			var9 = math.max(0, v1.fuse - var3)
			local var14 = math.floor(var3)
			v1.label.Text = tostring((math.max(1, (math.ceil(var9)))))
			setWindows(v1, var3 % 1 < 0.25)
			if var14 == v1.lastSecond or 0.05 >= var9 then
				continue
			end

			v1.lastSecond = var14
			var13.Audio.playAt("GrenadeTick", var5, 0.05)
		end
	end
end

tbl3.init = function(arg1)
	var13 = arg1
	var19 = Instance.new("Folder")
	var19.Name = "FrozenHouseGrenades"
	var19.Parent = workspace
	local var1 = workspace:WaitForChild("FrozenHouse"):WaitForChild("World")
	var9 = RaycastParams.new()
	var9.FilterType = Enum.RaycastFilterType.Include
	var9.FilterDescendantsInstances = { var1 }
	var9.IgnoreWater = true
	buildPreview()
	var17.onThrow = tbl3.throw
	var12.get("GrenadeFx").OnClientEvent:Connect(function(arg1, arg2)
		if arg1 == "thrown" then
			onThrown(arg2)
			return
		end

		if arg1 == "burst" then
			onBurst(arg2)
		end
	end)

	var15.InputBegan:Connect(function(arg1, arg2)
		if arg2 or var15:GetFocusedTextBox() then
			return
		end

		if arg1.KeyCode == var6.Keys.Grenade then
			tbl3.toggle()
		end
	end)

	var14.LocalPlayer.CharacterRemoving:Connect(hidePreview)
	str1.RenderStepped:Connect(step)
end

tbl3.describe = function()
	local num1 = 0
	for k1 in pairs(tbl2) do
		num1 = num1 + 1
	end

	local tbl1 = { holding = var7.holdingGrenade() }
	tbl1.grenades = var7.grenades()
	local bool2 = false
	if var20 ~= nil then
		bool2 = var20.shown
	end

	tbl1.preview = bool2
	bool2 = false
	if var20 ~= nil then
		bool2 = var20.ring.Visible
	end

	tbl1.ring = bool2
	tbl1.flights = num1
	return tbl1
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ClassLook [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("FrozenHouse")
local var3 = var1:WaitForChild("MeltShared")
local str1 = "ClassLooks"
local str2 = "ClassPerks"
local var4 = require(var3:WaitForChild(str1))
local var5 = require(var3:WaitForChild(str2))
str1 = require(script.Parent.ClientState)
local var6 = game:GetService("Players")
local tbl1 = {}
str2 = {}
local function refresh(arg1)
	local var2 = arg1.Character
	if not var2 or (not var2.Parent) then
		return
	end

	local var3 = arg1:GetAttribute("RunClass")
	if typeof(var3) ~= "string" or (var3 == "" or (not var4.has(var3))) then
		var4.clear(var2)
		return
	end

	local bool1 = false
	if var2 ~= nil then
		bool1 = var2:FindFirstChild("FlamethrowerPack") ~= nil
	end

	local var7 = var4.find(var2)
	if var7 and (var7:GetAttribute("ClassId") == var3 and var7:GetAttribute("Compact") == bool1) then
		return
	end

	local var8 = arg1 == var6.LocalPlayer
	local var11 = var4.apply(var2, var3, { compact = bool1, local_ = var8, reduced = str1.settings.ReducedEffects == true })
	if not var11 then
		local var13 = tbl1[arg1]
		if var13 and (not var13.retrying) then
			var13.retrying = true
			task.delay(0.4, function()
				local var2 = tbl1[arg1]
				if var2 then
					var2.retrying = false
					refresh(arg1)
				end
			end)

		end

		return
	end

	if not var8 then
		var4.setCharge(var11, nil)
	end

	str2.updateTeam()
end

local var7 = game:GetService("RunService")
local var8 = require(var2.IceCodec)
local var9 = require(var2.Net)
local var10 = require(script.Parent.Battery)
str2.updateTeam = function()
	local var1 = str1.attr("GodlyCount") or 0
	for k1, v1 in ipairs(var6:GetPlayers()) do
		local var2 = var4.find(v1.Character)
		if not var2 then
			continue
		end

		local var3 = var2:GetAttribute("ClassId")
		local var5 = var4.setTeamMark
		local var7 = var2
		local bool1 = false
		if 0 < var1 then
			bool1 = var3 ~= "Godly"
		end

		var5(var7, bool1)
	end
end

str2.describe = function()
	local tbl1 = { players = {}, godlies = str1.attr("GodlyCount") or 0 }
	tbl1.reduced = str1.settings.ReducedEffects == true
	for k1, v1 in ipairs(var6:GetPlayers()) do
		local var1 = v1.Character
		local var2 = var4.find(var1)
		local num1 = 0
		local num2 = 0
		local num3 = 0
		if var1 then
			for k2, v2 in ipairs(var1:GetChildren()) do
				if v2.Name ~= var4.ModelName then
					continue
				end

				num1 = num1 + 1
			end
		end

		if var2 then
			for k3, v3 in ipairs(var2:GetDescendants()) do
				if v3:IsA("BasePart") then
					num2 = num2 + 1
				else
					if not v3:IsA("ParticleEmitter") then
						continue
					end

					num3 = num3 + 1
				end
			end
		end

		local var3 = var2
		local tbl2 = { runClass = v1:GetAttribute("RunClass") }
		var3 = var3 and var2:GetAttribute("ClassId")
		tbl2.wearing = var3
		var3 = var2
		var3 = var3 and var2:GetAttribute("Compact")
		tbl2.compact = var3
		local var5 = tbl1.players
		local var7 = v1.Name
		var3 = false
		if var1 ~= nil then
			var3 = var1:FindFirstChild("FlamethrowerPack") ~= nil
		end

		tbl2.toolPack = var3
		tbl2.models = num1
		tbl2.parts = num2
		tbl2.emitters = num3
		if not var2 then
			var3 = nil
		else
			for k4, v4 in ipairs(var2:GetDescendants()) do
				if v4.Name ~= "TeamMark" then
					continue
				end

				var3 = v4.Transparency < 1
			end

			var3 = nil
		end

		tbl2.teamMark = var3
		var5[var7] = tbl2
	end

	return tbl1
end

local function track(arg1)
	if tbl1[arg1] then
		return
	end

	local tbl2 = {
		connections = {},
		retrying = false,
		coins = arg1:GetAttribute("Coins") or 0,
		lastGlint = 0,
		lastVent = 0,
	}

	tbl1[arg1] = tbl2
	local function fn2()
		refresh(arg1)
	end

	table.insert(tbl2.connections, arg1:GetAttributeChangedSignal("RunClass"):Connect(fn2))
	fn2 = function()
		local var1 = arg1:GetAttribute("Coins") or 0
		tbl2.coins = var1
		if tbl2.coins < var1 then
			if str1.settings.ReducedEffects == true then
				return
			end
		end

		local var2 = os.clock()
		if var2 - tbl2.lastGlint < 1.5 then
			return
		end

		tbl2.lastGlint = var2
		local var3 = var4.find(arg1.Character)
		local var5 = var3
		var5 = var5 and var3:GetAttribute("ClassId")
		if var5 ~= "NoviceCollector" then
			if var5 ~= "ExpertCollector" then
				return
			end
		end

		var4.glint(var3, var5 == "ExpertCollector")
	end

	table.insert(tbl2.connections, arg1:GetAttributeChangedSignal("Coins"):Connect(fn2))
	fn2 = function(arg1)
		refresh(arg1)
		local function fn2(arg1)
			if arg1.Name == "FlamethrowerPack" then
				refresh(arg1)
			end
		end

		table.insert(tbl2.connections, arg1.ChildAdded:Connect(fn2))
		fn2 = function(arg1)
			if arg1.Name == "FlamethrowerPack" then
				task.defer(refresh, arg1)
			end
		end

		table.insert(tbl2.connections, arg1.ChildRemoved:Connect(fn2))
	end

	table.insert(tbl2.connections, arg1.CharacterAdded:Connect(fn2))
	local var2 = arg1.Character
	if var2 then
		local function fn6(arg1)
			if arg1.Name == "FlamethrowerPack" then
				refresh(arg1)
			end
		end

		table.insert(tbl2.connections, var2.ChildAdded:Connect(fn6))
		fn6 = function(arg1)
			if arg1.Name == "FlamethrowerPack" then
				task.defer(refresh, arg1)
			end
		end

		table.insert(tbl2.connections, var2.ChildRemoved:Connect(fn6))
	end

	refresh(arg1)
end

local function untrack(arg1)
	local var2 = tbl1[arg1]
	if not var2 then
		return
	end

	for k1, v1 in ipairs(var2.connections) do
		v1:Disconnect()
	end

	tbl1[arg1] = nil
end

local num1 = 0
local function updateLive()
	local var8 = var4.find(var6.LocalPlayer.Character)
	if var8 then
		local var13 = var8:GetAttribute("ClassId")
		local var14, var15 = var10.read()
		if var13 == "Powerbank" then
			local var16 = var4.setCharge
			local var17 = var8
			var16(var17, if 0 < var15 then var14 / var15 else nil)
		elseif var13 == "Technician" then
			local var18 = str1.perks()
			local var20 = var18.bp.Technician / var5.BP
			local var21 = var5.technicianBonus(var18, var14, var15)
			local var22 = var4.setTechnician
			local var23 = var8
			var22(var23, if 0 < var20 then var21 / var20 else 0)
		end
	end

	if str1.settings.ReducedEffects == true then
		return
	end

	for k1, v1 in ipairs(var6:GetPlayers()) do
		local var24 = tbl1[v1]
		local var25 = var4.find(v1.Character)
		if not var24 or (not var25) then
			continue
		end

		if var25:GetAttribute("ClassId") ~= "SteamSpecialist" then
			continue
		end

		if v1:GetAttribute("Melting") ~= true then
			continue
		end

		local var26 = os.clock()
		if 2.5 > var26 - var24.lastVent then
			continue
		end

		var24.lastVent = var26
		var4.vent(var25)
	end
end

local num2 = 0
local num3 = 0
str2.init = function()
	for k1, v1 in ipairs(var6:GetPlayers()) do
		track(v1)
	end

	var6.PlayerAdded:Connect(track)
	var6.PlayerRemoving:Connect(untrack)
	str1.onAttr("GodlyCount", function()
		str2.updateTeam()
	end)

	str1.settingsChanged:Connect(function(arg1)
		if arg1 ~= "ReducedEffects" then
			return
		end

		local var1 = str1.settings.ReducedEffects == true
		for k1, v1 in ipairs(var6:GetPlayers()) do
			var4.setReduced(var4.find(v1.Character), var1)
		end
	end)

	var9.get("HeatFx").OnClientEvent:Connect(function(arg1)
		if str1.settings.ReducedEffects == true then
			return
		end

		local var1 = arg1
		for k1, v1 in ipairs(var8.decodeImpacts(var1)) do
			if v1.tool ~= 0 then
				continue
			end

			local var2 = var6:GetPlayerByUserId(v1.userId)
			local var3 = var2
			var3 = var3 and var4.find(var2.Character)
			if not var3 then
				continue
			end

			if var3:GetAttribute("ClassId") ~= "HumanTorch" then
				continue
			end

			var4.flare(var3)
		end
	end)

	var7.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if 0.1 <= num1 then
			num1 = 0
			updateLive()
		end

		var1 = num2 + arg1
		num2 = var1
		if num2 < 0.05 then
			return
		end

		var1 = num3 + num2
		num3 = var1
		num2 = 0
		if str1.settings.ReducedEffects == true then
			return
		end

		for k1, v1 in ipairs(var6:GetPlayers()) do
			local var2 = var4.find(v1.Character)
			if not var2 then
				continue
			end

			local str2 = "ClassId"
			if not var4.drifts(var2:GetAttribute(str2)) then
				continue
			end

			var4.shards(var2, num3)
		end
	end)
end

return str2

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Tutorial [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse").Config)
local var2 = require(script.Parent.UIKit)
local var3 = game:GetService("Players")
local var4 = nil
local var5 = nil
local var6 = var1.Tutorial.CoinTarget
local var7 = nil
local var8 = nil
local var9 = var1.Text
local var10 = nil
local var11 = nil
local var12 = nil
local var13 = nil
local var14 = nil
local var15 = nil
local var16 = nil
local num1 = 0
local function setArrow(arg1, arg2)
	local var1 = var10.HUD.upgradesButton
	var1 = var1 and var10.HUD.upgradesButton()
	if not arg1 or (not var1 or var1.AbsoluteSize.X == 0) then
		var11.Visible = false
		return
	end

	local var2 = var1.AbsolutePosition
	local var3 = var1.AbsoluteSize
	local var4 = math.max(var12.Scale, 0.01)
	var11.Position = UDim2.fromOffset((var2.X + var3.X) / var4 + 10 + (arg2 or 0), (var2.Y + var3.Y / 2) / var4)
	var11.Visible = true
end

local var17 = require(script.Parent.ClientState)
local var18 = nil
local var19 = var2.new
local var20 = var1.Palette
local function apply(arg1)
	var5 = arg1.step
	local var10 = arg1.target
	var6 = var10 or var1.Tutorial.CoinTarget
	var13.Text = var9.TutorialTag
	var14.Text = arg1.title or ""
	var15.Text = arg1.detail or ""
	var16.Visible = var5 == "coins"
	var10 = var4
	local var11 = UDim2.fromOffset
	local num2 = 470
	var10.Size = var11(num2, if var5 == "coins" then 92 else 68)
	if var5 == "coins" then
		if var5 ~= "coins" then
		else
			num2 = var3.LocalPlayer
			var11 = num2 and num2:GetAttribute("Coins") or 0
			var10 = math.min(var11, var6)
			var7.set(var10 / math.max(var6, 1))
			var8.Text = string.format(var9.TutorialCoinsProgress, var10, var6)
		end
	end

	if var5 == "done" then
		num2 = arg1.seconds
		num1 = os.clock() + (num2 or var1.Tutorial.DoneSeconds)
		var13.Text = ""
	end

	var4.Visible = true
	var4.GroupTransparency = 1
	var2.tween(var4, 0.25, { GroupTransparency = 0 })
	var10 = setArrow
	var11 = false
	if var5 == "upgrade" then
		var11 = not var17.menuOpen
	end

	var10(var11, 0)
end

local function refreshBar()
	if var5 ~= "coins" then
		return
	end

	local var1 = var3.LocalPlayer
	local var2 = var1 and var1:GetAttribute("Coins") or 0
	local var4 = math.min(var2, var6)
	var7.set(var4 / math.max(var6, 1))
	var8.Text = string.format(var9.TutorialCoinsProgress, var4, var6)
end

local var21 = game:GetService("RunService")
return {
	init = function(arg1)
		var10 = arg1
		var18 = var2.screen("FrozenHouseTutorial", 24)
		var12 = var2.autoScale(var18)
		local tbl1 = {
			Name = "Card",
			BackgroundColor3 = var20.DeepBlue,
			BackgroundTransparency = 0.1,
			AnchorPoint = Vector2.new(0.5, 1),
			Visible = false,
		}

		tbl1.Position = UDim2.new(0.5, 0, 1, -134)
		tbl1.Size = UDim2.fromOffset(470, 92)
		tbl1.Parent = var18
		local num2 = 16
		var4 = var19("CanvasGroup", tbl1, { var2.corner(num2) })
		local tbl2 = {
			Name = "Tag",
			Text = var9.TutorialTag,
			FontFace = var2.Fonts.Display,
			TextSize = 14,
			TextColor3 = var20.Orange,
			TextXAlignment = Enum.TextXAlignment.Left,
			Position = UDim2.fromOffset(16, 8),
		}

		tbl2.Size = UDim2.new(1, -32, 0, 16)
		tbl2.Parent = var4
		var13 = var2.label(tbl2)
		tbl2 = {
			Name = "Title",
			Text = "",
			FontFace = var2.Fonts.Display,
			TextSize = 20,
			TextColor3 = var20.White,
			TextXAlignment = Enum.TextXAlignment.Left,
			TextTruncate = Enum.TextTruncate.AtEnd,
			Position = UDim2.fromOffset(16, 24),
		}

		tbl2.Size = UDim2.new(1, -32, 0, 24)
		tbl2.Parent = var4
		var14 = var2.label(tbl2)
		tbl2 = { Name = "Detail", Text = "", TextSize = 15, TextColor3 = Color3.fromHex("#CBE3F2") }
		tbl2.TextXAlignment = Enum.TextXAlignment.Left
		tbl2.TextTruncate = Enum.TextTruncate.AtEnd
		tbl2.Position = UDim2.fromOffset(16, 46)
		tbl2.Size = UDim2.new(1, -32, 0, 18)
		tbl2.Parent = var4
		var15 = var2.label(tbl2)
		tbl1 = {
			Name = "BarHolder",
			BackgroundTransparency = 1,
			Position = UDim2.fromOffset(16, 66),
			Visible = false,
		}

		tbl1.Size = UDim2.new(1, -32, 0, 20)
		tbl1.Parent = var4
		var16 = var19("Frame", tbl1)
		tbl2 = { Name = "Coins", Size = UDim2.fromScale(1, 1), Radius = 10 }
		tbl2.Color = var20.Orange
		tbl2.Parent = var16
		var7 = var2.progressBar(tbl2)
		tbl2 = {
			Name = "Label",
			Text = "",
			FontFace = var2.Fonts.Bold,
			TextSize = 14,
			TextColor3 = var20.Text,
			Size = UDim2.fromScale(1, 1),
			ZIndex = 3,
		}

		tbl2.Parent = var7.track
		var8 = var2.label(tbl2)
		tbl1 = {
			Name = "Arrow",
			BackgroundTransparency = 1,
			AnchorPoint = Vector2.new(0, 0.5),
			Visible = false,
		}

		tbl1.Size = UDim2.fromOffset(34, 52)
		tbl1.Parent = var18
		var11 = var19("Frame", tbl1)
		local tbl3 = { "Lower", 45, 37 }
		for k1, v1 in ipairs({ { "Upper", -45, 15 }, tbl3 }) do
			local tbl4 = { Name = v1[1], BackgroundColor3 = var20.Orange, AnchorPoint = Vector2.new(0.5, 0.5) }
			tbl4.Position = UDim2.fromOffset(15, v1[3])
			tbl4.Size = UDim2.fromOffset(30, 9)
			tbl4.Rotation = v1[2]
			tbl4.Parent = var11
			local var1 = var2.corner(4)
			local str1 = "UIStroke"
			local tbl5 = { Color = var20.Text, Thickness = 3 }
			var19("Frame", tbl4, { var1, var19(str1, tbl5) })
		end

		var17.on("Tutorial", apply)
		var17.onPlayerAttr("Coins", refreshBar)
		var21.RenderStepped:Connect(function()
			if not var4.Visible then
				return
			end

			if var5 == "upgrade" then
				local var1 = var17.menuOpen ~= nil
				setArrow(not var1, math.sin(os.clock() * 5) * 5)
				if not var1 then
					return
				end

				var15.Text = var9.TutorialUpgradePick
				return
			end

			if var5 == "done" and num1 <= os.clock() then
				var5 = nil
				var2.tween(var4, 0.3, { GroupTransparency = 1 })
				task.delay(0.32, function()
					if 0.99 < var4.GroupTransparency then
						var4.Visible = false
					end
				end)

				var1 = var10.HUD.upgradesButton and var10.HUD.upgradesButton()
				var11.Visible = false
			end
		end)
	end,
	describe = function()
		return {
			step = var5,
			visible = var4.Visible,
			title = var14.Text,
			detail = var15.Text,
			bar = var16.Visible and var8.Text or nil,
			arrow = var11.Visible,
		}
	end,
}

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.Focus [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("MeltShared")
local str1 = "ControlHints"
local str2 = "Controls"
local str3 = "UiFocus"
local var3 = require(var2:WaitForChild(str1))
local var4 = require(var2:WaitForChild(str2))
local var5 = require(var1:WaitForChild("FrozenHouse").Config)
local var6 = require(var2:WaitForChild(str3))
str1 = require(script.Parent.UIKit)
str2 = var5.Palette
str3 = var5.Text
local var7 = nil
local tbl1 = {
	Controls = var4,
	UiFocus = var6,
	Mode = var4.Mode,
	basic = function(arg1)
		local var1 = arg1
		return {
			{ action = "Confirm", label = str3.HintSelect },
			{ action = "Back", label = var1 or str3.HintBack },
		}
	end,
	isGamepad = function()
		return var4.isGamepad()
	end,
	open = function(arg1, arg2)
		local var1 = arg1
		local var2 = arg2
		return var6.open(var1, var2)
	end,
	close = function(arg1)
		var6.close(arg1)
	end,
	blocked = function()
		return var6.blocked()
	end,
}

tbl1.setIdleHints = function(arg1)
	var7 = arg1
	if tbl1.refreshHints then
		tbl1.refreshHints()
	end
end

local var8 = nil
tbl1.describe = function()
	local var1 = var6.describe()
	local var2 = if var8 then var8:describe() else nil
	var1.hints = var2
	return var1
end

local var9 = nil
local tbl2 = {
	Font = str1.Fonts.Bold,
	BoldFont = str1.Fonts.Display,
	TextColor = str2.White,
	GlyphTextColor = str2.Text,
	GlyphBackground = str2.White,
	Background = str2.Text,
}

tbl1.init = function(arg1)
	var9 = arg1
	var6.init()
	local var1 = str1.screen("FrozenHouseControlHints", 40)
	str1.autoScale(var1)
	local tbl3 = { Parent = var1, AnchorPoint = Vector2.new(0, 1), ZIndex = 5 }
	tbl3.Position = UDim2.new(0, 18, 1, -18)
	tbl3.Alignment = Enum.HorizontalAlignment.Left
	var8 = var3.new(tbl3, tbl2)
	local function follow()
		local var1 = var6.hints()
		var8:set(var1 or var7)
	end

	tbl1.refreshHints = follow
	var6.topChanged:Connect(follow)
	var4.changed:Connect(follow)
	local var2 = var6.hints()
	var8:set(var2 or var7)
	tbl3 = game:GetService("GuiService")
	tbl3:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		if tbl3.SelectedObject and (var4.isGamepad() and (var9 and var9.Audio)) then
			var9.Audio.playTuned("UITick", 0.3, 1.5, 0.06)
		end
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.FrozenHouseClient.ToolCycle [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("FrozenHouse")
local var2 = game:GetService("HttpService")
local var3 = require(var1.Net)
local var4 = require(script.Parent.ClientState)
local var5 = require(var1.Config)
local var6 = game:GetService("Players")
local var7 = game:GetService("StarterGui")
local bool1 = false
local tbl1 = {
	items = function()
		local var1 = var4.ownedTools()
		local tbl1 = {}
		for k1, v1 in ipairs(var5.Tools) do
			if not var1[v1.Id] then
				continue
			end

			table.insert(tbl1, v1.Id)
		end

		if 0 < var4.grenades() then
			table.insert(tbl1, "FireGrenade")
		end

		return tbl1
	end,
	current = function()
		if var4.holdingGrenade() then
			return "FireGrenade"
		end

		local var1 = var4.heldTool()
		local var2 = var1
		var2 = var2 and var1:GetAttribute("ToolId")
		if typeof(var2) == "string" then
			return var2
		end

		local var3 = var4.playerAttr("EquippedTool")
		if typeof(var3) == "string" then
			return var3
		end

		return var5.StarterToolId
	end,
}

local function invoke(arg1, arg2)
	local var1 = var2:GenerateGUID(false)
	local success, result = pcall(function()
		local var2 = arg1
		local var4 = arg2
		local var5 = nil
		local var6 = nil
		local var7 = var1
		return var3.get("Shop"):InvokeServer(var2, var4, var5, var6, var7)
	end)

	if success and typeof(result) == "table" then
		return result
	end

	return { ok = false, reason = "error" }
end

local var8 = nil
tbl1.cycle = function(arg1)
	local var2 = not bool1
	if var2 then
		var2 = var4.canPlay()
		if var2 then
			var2 = not var4.cinematic
			if var2 then
				var2 = false
				if var4.menuOpen == nil then
					var2 = not var4.freeCursor
				end
			end
		end
	end

	if not var2 then
		return nil
	end

	var2 = tbl1.items()
	if #var2 < 2 then
		return nil
	end

	local var3 = tbl1.current()
	local num1 = 1
	for k1, v1 in ipairs(var2) do
		if v1 ~= var3 then
			continue
		end

		num1 = k1
		break
	end

	local var7 = var2[(num1 - 1 + arg1) % #var2 + 1]
	if var7 == var3 then
		return nil
	end

	bool1 = true
	task.spawn(function()
		local var1 = invoke("hold", var7)
		bool1 = false
		if var1.ok then
			if not (var8 and var8.Audio) then
				return
			end

			if not var8.Audio then
				return
			end

			var8.Audio.play("UITick", 0.05)
			return
		end

		if var8 then
			if var8.HUD then
				local var3 = if var1.reason == "none" then var5.Text.NoGrenades else nil
				if var3 then
					var8.HUD.toast(var3, 2.5)
				end
			end
		end
	end)

	return var7
end

tbl1.next = function()
	local num1 = 1
	return tbl1.cycle(num1)
end

tbl1.previous = function()
	local num1 = -1
	return tbl1.cycle(num1)
end

tbl1.describe = function()
	local bool2 = true
	pcall(function()
		bool2 = var7:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack)
	end)

	local tbl2 = { items = tbl1.items() }
	tbl2.current = tbl1.current()
	local var2 = not bool1
	if var2 then
		var2 = var4.canPlay()
		if var2 then
			var2 = not var4.cinematic
			if var2 then
				var2 = false
				if var4.menuOpen == nil then
					var2 = not var4.freeCursor
				end
			end
		end
	end

	tbl2.canSwap = var2
	tbl2.pending = bool1
	tbl2.grenades = var4.grenades()
	tbl2.backpackCoreGuiEnabled = bool2
	return tbl2
end

tbl1.init = function(arg1)
	var8 = arg1
	var6.LocalPlayer.CharacterAdded:Connect(function()
		bool1 = false
	end)
end

return tbl1

--- ReplicatedStorage.FrozenHouse.Config [ModuleScript]
-- y u r i

local tbl1 = { Ice = Color3.fromHex("#B9E9FA") }
tbl1.IceDeep = Color3.fromHex("#8FD3EE")
tbl1.IceFrost = Color3.fromHex("#E4F6FD")
tbl1.DeepBlue = Color3.fromHex("#397EA8")
tbl1.Orange = Color3.fromHex("#F7A541")
tbl1.OrangeDark = Color3.fromHex("#D9822B")
tbl1.Cream = Color3.fromHex("#FFF0D6")
tbl1.Teal = Color3.fromHex("#58B8AF")
tbl1.Coral = Color3.fromHex("#E97B72")
tbl1.Text = Color3.fromHex("#253746")
tbl1.White = Color3.fromHex("#FFFFFF")
tbl1.Mustard = Color3.fromHex("#E3B23C")
tbl1.Mint = Color3.fromHex("#A8DCC5")
tbl1.Wood = Color3.fromHex("#C98E5A")
tbl1.WoodDark = Color3.fromHex("#8C5A3C")
tbl1.Steel = Color3.fromHex("#A7B6C2")
tbl1.Charcoal = Color3.fromHex("#3B4652")
tbl1.Grass = Color3.fromHex("#9CC98A")
tbl1.Snow = Color3.fromHex("#F4F8FB")
tbl1.WarmLight = Color3.fromHex("#FFC98A")
tbl1.ColdLight = Color3.fromHex("#A9D8FF")
tbl1.Focus = Color3.fromHex("#19C6F0")
tbl1.FocusGlow = Color3.fromHex("#B8F2FF")
local tbl2 = { Title = "MELT ALL THE ICE!", LevelName = "The Frozen House", Palette = tbl1 }
tbl1 = {
	ColdBrightness = 0.22,
	ColdRange = 18,
	WarmBrightness = 0.3,
	WarmRange = 18,
	WarmDiffuser = Color3.fromHex("#FFE3BF"),
}

tbl1.WarmLightColor = Color3.fromHex("#FFEBD2")
tbl2.Lighting = tbl1
tbl2.Ice = {
	TickSeconds = 0.1,
	MaxCatchUpTicks = 3,
	Spacing = 1,
	ChunkSize = 12,
	SurfaceBand = 1,
	ResidualDensity = 0.15,
	ClearFraction = 0.025,
	MaxCleanupIsland = 6,
	ChipMaxSamples = 12,
	FloatingChipMaxSamples = 64,
	RevealFraction = 0.1,
	SweepMaxGap = 0.3,
	SweepMaxRadii = 3,
	VisibilityLift = 0.45,
	CollisionBlock = 8,
	CollisionBlocksPerTick = 6,
	CollisionMinInterval = 0.25,
	RenderBudgetMs = 4,
	StandardMass = 1,
}

tbl1 = {
	Material = Enum.Material.Ice,
	Reflectance = 0.05,
	Edge = Color3.fromHex("#E6FAFF"),
	BodyNoiseStuds = 14,
	BodyMain = 0.3,
	BodyNoise = 0.35,
	CreaseDeep = 1.2,
	CreaseMax = 0.45,
	RimEdge = 1.6,
	RimMax = 0.5,
	CarveStart = 1,
	CarveFull = 2.6,
	CarvedRich = 0.45,
	FrostAmount = 0.28,
	FrostUp = 0.2,
	GlowRadius = 7,
	GlowStrength = 0.75,
	ContactLightBrightness = 1,
	ContactLightRange = 4,
	ContactLightOffset = 1.1,
	ContactGlowTransparency = 0.45,
	ContactGlowEmission = 0.25,
	ContactFadeIn = 14,
	ContactFadeOut = 10,
	ReducedLight = 0.5,
}

tbl1.Face = Color3.fromHex("#A5DDF2")
tbl1.Main = Color3.fromHex("#62B6DA")
tbl1.Deep = Color3.fromHex("#327FA7")
tbl1.FrostColor = Color3.fromHex("#EEF9FD")
tbl1.ContactLightColor = Color3.fromHex("#FF9A4D")
tbl2.IceLook = tbl1
local tbl3 = {
	Id = "Hairdryer",
	Name = "Hairdryer",
	Price = 0,
	Radius = 2.2,
	HeatRate = 1.2,
	MaxExcavation = 9,
	Range = 14,
	Benefits = { "Gentle warm air", "Free starter tool" },
	Tagline = "Your trusty starter.",
	AirColor = Color3.fromHex("#FFE2B8"),
}

local tbl4 = {
	Id = "HeatGun",
	Name = "Heat Gun",
	Price = 160,
	Radius = 2.8,
	HeatRate = 1.4,
	MaxExcavation = 20,
	Range = 17,
	Benefits = { "Melts faster", "Wider airflow" },
	Tagline = "Faster, focused melting.",
	AirColor = Color3.fromHex("#FFB36B"),
}

local tbl5 = {
	Id = "SteamBlaster",
	Name = "Steam Blaster",
	Price = 650,
	Requires = "HeatGun",
	Radius = 3.6,
	HeatRate = 1.5,
	MaxExcavation = 33,
	Range = 20,
	Benefits = { "Clears big patches", "Longer reach" },
	Tagline = "Wide, powerful steam.",
	AirColor = Color3.fromHex("#F2FBFF"),
}

local tbl6 = {
	Id = "Flamethrower",
	Name = "Flamethrower",
	Product = "Flamethrower",
	Price = 0,
	Radius = 5,
	HeatRate = 4,
	MaxExcavation = 175,
	Range = 21,
	Benefits = { "Strongest melting", "Unlocked for this run" },
	Tagline = "Heavy-duty thermal clearing.",
	AirColor = Color3.fromHex("#FFB14A"),
}

tbl6.Upgrades = {
	BatteryCapacity = { 176, 192, 208, 224, 240, [0] = 160 },
	SizeMultiplier = { 1.02, 1.04, 1.06, 1.08, 1.1, [0] = 1 },
	PowerMultiplier = { 1.03, 1.06, 1.09, 1.12, 1.15, [0] = 1 },
}

tbl2.Tools = { tbl3, tbl4, tbl5, tbl6 }
tbl2.ToolById = {}
for k1, v1 in ipairs(tbl2.Tools) do
	v1.Index = k1
	tbl2.ToolById[v1.Id] = v1
end

tbl2.StarterToolId = "Hairdryer"
tbl2.Upgrades = {
	Tracks = { "Battery", "Size", "Power" },
	MaxLevel = 5,
	BatteryCapacity = { 120, 140, 160, 180, 200, [0] = 100 },
	SizeMultiplier = { 1.1, 1.2, 1.3, 1.4, 1.5, [0] = 1 },
	PowerMultiplier = { 1.15, 1.3, 1.45, 1.6, 1.75, [0] = 1 },
	Prices = {
		Hairdryer = {
			Battery = { 5, 10, 15, 20, 25 },
			Size = { 5, 10, 15, 20, 25 },
			Power = { 5, 10, 15, 20, 25 },
		},
		HeatGun = {
			Battery = { 25, 40, 60, 85, 115 },
			Size = { 30, 45, 65, 90, 120 },
			Power = { 30, 45, 65, 90, 120 },
		},
		SteamBlaster = {
			Battery = { 40, 60, 85, 115, 150 },
			Size = { 45, 65, 90, 120, 155 },
			Power = { 45, 65, 90, 120, 155 },
		},
		Flamethrower = {
			Battery = { 40, 60, 85, 115, 150 },
			Size = { 45, 65, 90, 120, 155 },
			Power = { 45, 65, 90, 120, 155 },
		},
	},
}

tbl2.Battery = {
	DrainPerSecond = 10,
	FullRechargeSeconds = 3,
	RestartEnergy = 10,
	LowFraction = 0.2,
	ReadyCueBelow = 0.5,
	HeartbeatSeconds = 1,
}

tbl2.ToolShed = {
	InteractDistance = 8,
	DistanceTolerance = 3,
	PromptDistance = 10,
	FacingDot = 0.55,
	CloseDistance = 10.5,
	ShowSeconds = 8,
}

tbl2.Grenade = {
	ToolId = "FireGrenade",
	FuseSeconds = 3,
	ThrowSpeed = 52,
	UpBias = 0.25,
	Gravity = 70,
	Radius = 0.35,
	Restitution = 0.3,
	Friction = 0.5,
	RestSpeed = 3,
	MaxBounces = 8,
	MinY = -40,
	SampleHz = 30,
	SpawnForward = 1.2,
	ThrowCooldown = 0.8,
	BurstRadius = 7,
	BurstBudget = 470,
	BurstStrength = 1.8,
	BurstStages = 3,
	LabelDistance = 45,
	PreviewSeconds = 1.6,
	PreviewDots = 14,
}

tbl2.Economy = {
	BaseRewardUnits = 2400,
	RegionBonus = 27,
	CompletionBonus = 100,
	MaxPartyMultiplier = 4,
	NormalReferenceMass = 16888,
}

tbl2.HumanTorch = {
	BudgetPerSecond = 3.7,
	HeatRate = 2.5,
	ContactTolerance = 0.5,
	FxInterval = 0.2,
	BodyParts = {
		"Head",
		"UpperTorso",
		"LowerTorso",
		"LeftUpperArm",
		"LeftLowerArm",
		"LeftHand",
		"RightUpperArm",
		"RightLowerArm",
		"RightHand",
		"LeftUpperLeg",
		"LeftLowerLeg",
		"LeftFoot",
		"RightUpperLeg",
		"RightLowerLeg",
		"RightFoot",
		"Torso",
		"Left Arm",
		"Right Arm",
		"Left Leg",
		"Right Leg",
	},
}

tbl2.Firing = {
	AimSendHz = 10,
	MaxAimMessagesPerSecond = 24,
	MaxStateMessagesPerSecond = 12,
	AimStaleSeconds = 0.4,
	RangeTolerance = 1.5,
	MinFacingDot = -0.2,
	MaxTargetDistance = 600,
}

tbl2.Camera = {
	FieldOfView = 76,
	ViewmodelScale = 0.45,
	ViewmodelOffset = Vector3.new(1, -1.1, -2.3),
	ViewmodelReach = 3,
	ViewmodelJetOpacity = 1.9,
	TouchAimSensitivity = 0.009,
	MaxTouchPitchDegrees = 80,
}

tbl2.Keys = {
	Upgrades = Enum.KeyCode.Tab,
	Settings = Enum.KeyCode.M,
	FindIce = Enum.KeyCode.F,
	ClassInfo = Enum.KeyCode.C,
	Grenade = Enum.KeyCode.G,
	ReturnToEntrance = Enum.KeyCode.Z,
	ReturnToEntranceGamepad = Enum.KeyCode.DPadDown,
	FreeCursor = { Enum.KeyCode.LeftAlt, Enum.KeyCode.RightAlt },
}

tbl2.Arrival = {
	DifficultyWaitSeconds = 10,
	PartyWaitSeconds = 12,
	EstablishingSeconds = 2,
	StartBannerSeconds = 3,
	ArrowSeconds = 8,
}

tbl2.Finale = {
	TotalSeconds = 7.5,
	MotorWindDown = { 0, 2.2 },
	GaugeSwing = { 0.6, 2.6 },
	LightsWarm = 2.4,
	MistClear = 3,
	HouseShot = 4,
	SavedTitle = 4.4,
}

tbl2.Helper = { FindIceThreshold = 0.9, MaxMarkers = 12, MaxHighlightedCells = 80, ShowSeconds = 14 }
tbl2.Recovery = { ReturnToEntranceCooldown = 4 }
tbl2.Tutorial = { Enabled = true, CoinTarget = 5, DoneSeconds = 7 }
tbl2.Text = {
	StartBanner = "Melt the ice. Save the house!",
	HintSelect = "Select",
	HintBack = "Back",
	HintClose = "Close",
	HintAdjust = "Adjust",
	HintUseTool = "Melt",
	HintThrow = "Throw",
	HintTools = "Swap tool",
	HintMenu = "Upgrades",
	HintInteract = "Interact",
	MenuSettings = "Settings",
	MenuClassInfo = "Your class",
	MenuFindIce = "Find ice",
	ReturnToEntrance = "Return to entrance",
	Waiting = "Waiting for your group\226\128\166 %d/%d",
	QuestLabel = "QUEST",
	QuestFrontDoor = "Melt the ice around the front door",
	QuestFindKeyPieces = "Find the pieces of the basement key (%d/%d)",
	QuestKeyPiecesLeft = "Still to find: %s",
	QuestUnlockBasement = "Use the key to unlock the basement door",
	QuestFindFreezer = "Go down to the basement and find the freezer",
	QuestThawHouse = "Thaw the entire house to turn off the freezer!",
	QuestStillFrozen = "Still frozen: %s",
	QuestTurnOff = "Turn off the freezer!",
	QuestDone = "House saved! Keep exploring or return to the lobby.",
	LockedBasement = "Find all %d key pieces to unlock",
	FrozenKeyPiece = "Melt the ice to free the key piece",
	LockedFreezer = "Thaw the entire house to turn off the freezer!",
	RoomCleared = "%s cleared!",
	KeyPieceFound = "Key piece found! %d/%d",
	KeyPieceFoundBy = "%s found a key piece!",
	KeyComplete = "Basement key complete!",
	BasementOpen = "Basement door unlocked!",
	FreezerFound = "You found the freezer!",
	ToolReady = "%s ready in the Tool Shed!",
	ToolEquipped = "%s equipped!",
	ToolUnlocked = "%s unlocked!",
	NewUpgradesKeyboard = "New upgrades available [TAB]",
	NewUpgradesTouch = "New upgrades available!",
	NewUpgradesGamepad = "New upgrades available!",
	ShedFindTool = "Find the %s in the Tool Shed to unlock these upgrades.",
	ShedRequires = "Get the %s first.",
	ShedShowButton = "Show Tool Shed",
	ShedWay = "The Tool Shed is beside the driveway.",
	ShedHere = "You're in the Tool Shed. Walk up to a tool!",
	ShedFindProductTool = "Find the %s in the Tool Shed.",
	ShedProductTool = "Unlocked for one run at its display in the Tool Shed.",
	PurchaseWaiting = "Waiting for Roblox\226\128\166",
	PurchaseConfirming = "Confirming your purchase\226\128\166",
	PurchaseCancelled = "Purchase cancelled.",
	PurchaseNotSetUp = "Not available right now.",
	PurchaseClosed = "Purchases are closed for this run.",
	PurchaseOpen = "Finish the purchase that's already open first.",
	GrenadeAdded = "Fire Grenade added! You have %d.",
	GrenadesAdded = "%d Fire Grenades added! You have %d.",
	BatteryPackFitted = "Battery Pack fitted! Double battery for this run.",
	FlamethrowerUnlocked = "Flamethrower unlocked for this run!",
	PurchasePending = "Your %s is saved for your next run.",
	PurchaseRecovered = "Your earlier %s purchase arrived for this run!",
	RunItemsExpired = "The run is over, so its run items have expired.",
	NoGrenades = "No grenades",
	GrenadesInShed = "Fire Grenades are available in the Tool Shed.",
	GrenadeCount = "Fire Grenade x%d",
	ThrowHintKeyboard = "Click to throw",
	ThrowHintTouch = "Tap THROW",
	ThrowHintGamepad = "Pull the trigger to throw",
	GrenadeBack = "Press 1 for your tool",
	GrenadeInfo = "Consumable: no upgrades. Each grenade melts a pocket of ice three seconds after it's thrown.",
	RunOnly = "Tools, upgrades and coins are for this run.",
	NewPersonalBest = "NEW PERSONAL BEST \226\128\162 %s",
	HouseSaved = "HOUSE SAVED!",
	HardBadge = "HARD",
	HardBanner = "HARD MODE",
	HardDetail = "More ice \194\183 40% fewer coins \194\183 1,500 Gems",
	HardComplete = "HARD MODE COMPLETE!",
	TutorialTag = "TUTORIAL",
	TutorialCoinsTitle = "Melt ice and collect %d coins",
	TutorialCoinsDetail = "Hold click on the ice to melt it.",
	TutorialCoinsProgress = "%d / %d coins",
	TutorialUpgradeTitle = "Open Upgrades and pick an upgrade",
	TutorialUpgradeDetail = "Your first upgrade costs %d coins.",
	TutorialUpgradePick = "Choose any upgrade to buy it.",
	TutorialDoneTitle = "You've got the hang of it now!",
	TutorialDoneDetail = "Don't forget to buy stronger weapons when you get enough coins to help you!",
	StatusCold = "TOO COLD",
	StatusNormal = "NORMAL",
	ChooseUpgrade = "Choose an upgrade!",
	UpgradeReadyKeyboard = "Upgrade your tool! [TAB]",
	UpgradeReadyTouch = "Upgrade your tool! Tap Upgrades.",
	UpgradeReadyGamepad = "Upgrade your tool!",
	BatteryHint = "Your tool uses battery.",
	ReleaseHint = "Release to recharge!",
	ClassTitle = "Your class",
	ClassForRun = "Your class for this run",
	ClassNoPerks = "No boosts.",
	ClassChangeInLobby = "Classes are spun and equipped in the lobby. Your class stays the same for the whole run.",
	ClassLoading = "Loading your class\226\128\166",
	ClassUnavailable = "Couldn't load your class yet, so you're playing without perks. Still trying\226\128\166",
	ClassOff = "Classes aren't connected in this place, so everyone plays without perks.",
	TeamPerks = "Team perks active",
	TeamBonus = "Team perk bonuses: +%d%%",
	TeamBonusExplain = "%d Godly players: every perk bonus is %d%% stronger (for example +50%% battery becomes +%s%%). It is not a flat boost to every stat.",
	TeamFromGodly = "A Godly teammate shares every Ascendant perk with the team.",
	TechnicianActive = "Technician: +%d%% power",
	ClassDiscount = "Class discount: %s%% off",
	GemsEarned = "+%d Gems",
	GemsSpins = "Enough for %d class spins!",
	GemsBreakdown = "%d base + %d bonus",
	GemsBreakdownVip = "%d base + %d bonus \194\183 VIP +50%%",
	GemsBaseVip = "%d base \194\183 VIP +50%%",
	GemsSaving = "Saving your gems\226\128\166",
	GemsSaved = "Gems saved. Spend them in the lobby.",
	GemsAlready = "Gems for this run were already saved.",
	GemsRetrying = "Couldn't save your gems yet. Trying again\226\128\166",
	GemsFailed = "Your gems couldn't be saved right now.",
}

tbl2.Physics = { MovementOnlyGroup = "FrozenHouseMovementOnly", HeatRayGroup = "FrozenHouseHeatRays" }
tbl2.DefaultSettings = { MusicVolume = 0.5, EffectsVolume = 0.8, ReducedEffects = false, ToggleMelting = false }
return tbl2

--- ReplicatedStorage.FrozenHouse.Layout [ModuleScript]
-- y u r i

local tbl1 = {
	Y = {
		Lawn = 0,
		Floor1 = 1,
		Ceil1 = 13,
		Floor2 = 14,
		Ceil2 = 26,
		AtticTop = 27,
		BasementFloor = -13,
		BasementCeil = -1,
	},
	Property = { MinX = -55, MaxX = 55, MinZ = -48, MaxZ = 52 },
	box = function(arg1, arg2, arg3, arg4, arg5, arg6)
		local tbl1 = { Min = Vector3.new(math.min(arg1, arg4), math.min(arg2, arg5), (math.min(arg3, arg6))) }
		tbl1.Max = Vector3.new(math.max(arg1, arg4), math.max(arg2, arg5), (math.max(arg3, arg6)))
		return tbl1
	end,
}

local var1 = tbl1.Y
local var2 = var1.Floor1
local var3 = var1.Ceil1
local tbl2 = { Min = Vector3.new(-9, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(9, math.max(var2, var3), 13)
local tbl3 = { Porch = { Min = Vector3.new(-10, 0, 14), Max = Vector3.new(10, 12, 23) }, Hall = tbl2 }
var2 = var1.Floor1
var3 = var1.Ceil1
tbl2 = { Min = Vector3.new(-27, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(-10, math.max(var2, var3), 13)
tbl3.Living = tbl2
var2 = var1.Floor1
var3 = var1.Ceil1
tbl2 = { Min = Vector3.new(10, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(27, math.max(var2, var3), 13)
tbl3.Kitchen = tbl2
var2 = var1.Floor2
var3 = var1.Ceil2
tbl2 = { Min = Vector3.new(-27, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(-10, math.max(var2, var3), 13)
tbl3.Bedroom = tbl2
var2 = var1.Floor2
var3 = var1.Ceil2
tbl2 = { Min = Vector3.new(-9, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(9, math.max(var2, var3), 13)
tbl3.UpperHall = tbl2
var2 = var1.Floor1
var3 = var1.Ceil1
tbl2 = { Min = Vector3.new(2, math.min(var2, var3), -35) }
tbl2.Max = Vector3.new(17, math.max(var2, var3), -18)
tbl3.Annex = tbl2
var2 = var1.BasementFloor
var3 = var1.BasementCeil
tbl2 = { Min = Vector3.new(0, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(27, math.max(var2, var3), 0)
tbl3.Utility = tbl2
var2 = var1.BasementFloor
var3 = var1.BasementCeil
tbl2 = { Min = Vector3.new(-27, math.min(var2, var3), -17) }
tbl2.Max = Vector3.new(-1, math.max(var2, var3), 13)
tbl3.Freezer = tbl2
tbl1.Rooms = tbl3
tbl1.UpperStairs = {
	MinX = -3.5,
	MaxX = 3.5,
	StartZ = 7.5,
	Direction = -1,
	StartY = var1.Floor1,
	Rise = 1,
	Run = 1.5,
	Steps = 13,
}

tbl1.BasementStairs = {
	MinX = 10,
	MaxX = 17,
	StartZ = -33,
	Direction = 1,
	StartY = var1.Floor1,
	Rise = -1,
	Run = 1.5,
	Steps = 14,
}

tbl3 = { Center = Vector3.new(0, var1.Floor1 + 4.5, 13.5), Width = 7, Height = 9, HingeX = -3.5 }
tbl1.FrontDoor = tbl3
tbl3 = { Center = Vector3.new(5.5, var1.Floor1 + 4.5, -17.5), Width = 7, Height = 9, HingeX = 9 }
tbl1.BasementDoor = tbl3
local var4 = var1.Ceil1
local var5 = var1.Floor2
local tbl4 = { Min = Vector3.new(-3.5, math.min(var4, var5), -12) }
tbl4.Max = Vector3.new(3.5, math.max(var4, var5), 7.5)
var2 = {
	Id = 7,
	Key = "Entrance",
	Name = "Entrance hall",
	Short = "Entrance hall",
	Share = 0.084,
	Zones = { tbl1.Rooms.Hall, tbl4 },
}

local var6 = var1.Floor1
local tbl5 = { Min = Vector3.new(10, math.min(-10.5, var6), -33) }
tbl5.Max = Vector3.new(17, math.max(-10.5, var6), -17)
var5 = {
	Id = 9,
	Key = "Annex",
	Name = "Back annex",
	Short = "Back annex",
	Share = 0.062,
	Zones = { tbl1.Rooms.Annex, tbl5 },
}

local tbl6 = {
	Id = 3,
	Key = "Kitchen",
	Name = "Kitchen",
	Short = "Kitchen",
	Share = 0.14,
	Zones = { tbl1.Rooms.Kitchen },
}

tbl1.Regions = {
	{
		Id = 1,
		Key = "Porch",
		Name = "Front porch",
		Short = "Porch",
		Share = 0.063,
		Zones = { { Min = Vector3.new(-10, 0, 14), Max = Vector3.new(10, 13, 24) } },
	},
	var2,
	{
		Id = 2,
		Key = "Living",
		Name = "Living room",
		Short = "Living room",
		Share = 0.158,
		Zones = { tbl1.Rooms.Living },
	},
	tbl6,
	{
		Id = 8,
		Key = "Landing",
		Name = "Upstairs landing",
		Short = "Landing",
		Share = 0.083,
		Zones = { tbl1.Rooms.UpperHall },
	},
	{
		Id = 4,
		Key = "Bedroom",
		Name = "Bedroom",
		Short = "Bedroom",
		Share = 0.126,
		Zones = { tbl1.Rooms.Bedroom },
	},
	var5,
	{
		Id = 5,
		Key = "Utility",
		Name = "Utility room",
		Short = "Utility room",
		Share = 0.098,
		Zones = { tbl1.Rooms.Utility },
	},
	{
		Id = 6,
		Key = "Freezer",
		Name = "Freezer chamber",
		Short = "Freezer chamber",
		Share = 0.186,
		Zones = { tbl1.Rooms.Freezer },
	},
}

tbl1.RegionByKey = {}
tbl1.RegionById = {}
for k1, v1 in ipairs(tbl1.Regions) do
	tbl1.RegionByKey[v1.Key] = v1
	tbl1.RegionById[v1.Id] = v1
end

tbl2 = {
	Id = "Living",
	Name = "Living room",
	Region = 2,
	Folder = "LivingRoom",
	Floor = var1.Floor1,
	Part = "Bow",
	CFrame = CFrame.new(-18.82, var1.Floor1 + 1.78, 8) * CFrame.Angles(0, 1.5707963267948966, 0),
}

var2 = {
	Id = "Kitchen",
	Name = "Kitchen",
	Region = 3,
	Folder = "Kitchen",
	Floor = var1.Floor1,
	Part = "Shaft",
	CFrame = CFrame.new(16.9, var1.Floor1 + 3.38, 7.6) * CFrame.Angles(0, -0.26179938779914941, 0),
}

local var7 = CFrame.new(-19.4, var1.Floor2 + 3.08, 11)
tbl1.KeyPieces = {
	tbl2,
	var2,
	{
		Id = "Bedroom",
		Name = "Bedroom",
		Region = 4,
		Folder = "Bedroom",
		Floor = var1.Floor2,
		Part = "Teeth",
		CFrame = var7,
	},
}

tbl1.KeyPieceById = {}
for k2, v2 in ipairs(tbl1.KeyPieces) do
	tbl1.KeyPieceById[v2.Id] = v2
end

tbl3 = function(arg1, arg2)
	local bool2 = false
	if arg1.Min.X <= arg2.X then
		bool2 = false
		if arg2.X <= arg1.Max.X then
			bool2 = false
			if arg1.Min.Y <= arg2.Y then
				bool2 = false
				if arg2.Y <= arg1.Max.Y then
					bool2 = false
					if arg1.Min.Z <= arg2.Z then
						bool2 = arg2.Z <= arg1.Max.Z
					end
				end
			end
		end
	end

	return bool2
end

tbl1.inside = tbl3
tbl1.regionAt = function(arg1)
	for k1, v1 in ipairs(tbl1.Regions) do
		for k2, v2 in ipairs(v1.Zones) do
			if not tbl3(v2, arg1) then
				continue
			end

			return v1.Id
		end
	end

	return nil
end

var4 = Vector3.new(4, 3.5, 44)
var5 = Vector3.new(4, 3.5, 0)
tbl2 = {
	CFrame.lookAt(Vector3.new(-4, 3.5, 40), Vector3.new(-4, 3.5, 0)),
	CFrame.lookAt(Vector3.new(4, 3.5, 40), Vector3.new(4, 3.5, 0)),
	CFrame.lookAt(Vector3.new(-4, 3.5, 44), Vector3.new(-4, 3.5, 0)),
	CFrame.lookAt(var4, var5),
}

tbl1.SpawnPoints = tbl2
tbl1.EntranceRecovery = CFrame.lookAt(Vector3.new(0, 3.5, 30), Vector3.new(0, 3.5, 0))
tbl1.FallRecoveryY = -40
tbl1.EntranceArrowTarget = Vector3.new(0, 7, 17)
tbl2 = {
	CFrame = CFrame.lookAt(Vector3.new(40.5, 0, 33.5), Vector3.new(0, 0, 33.5)),
	FloorY = 0.5,
	HalfWidth = 13.5,
	HalfDepth = 10.9,
	WallHeight = 15,
	StandZ = 6,
	ProductStandInset = 5,
	MarkerHeight = 18,
}

tbl2.Displays = {
	{ ToolId = "Hairdryer", X = 8.6 },
	{ ToolId = "HeatGun", X = 0 },
	{ ToolId = "SteamBlaster", X = -8.6 },
}

tbl2.ProductDisplays = {
	{ Key = "Flamethrower", Wall = -1, Z = 4.2, Width = 5 },
	{ Key = "FireGrenade", Wall = 1, Z = 4.6, Width = 3.6 },
	{ Key = "DoubleBattery", Wall = 1, Z = -1.2, Width = 3.6 },
}

tbl1.ToolShed = tbl2
tbl1.shedPoint = function(arg1)
	return tbl1.ToolShed.CFrame * arg1
end

tbl1.shedStand = function(arg1)
	local var1 = tbl1.ToolShed
	for k1, v1 in ipairs(var1.Displays) do
		if v1.ToolId ~= arg1 then
			continue
		end

		local var2 = Vector3.new(v1.X, var1.FloorY + 3, var1.StandZ)
		return tbl1.shedPoint(var2)
	end

	return nil
end

tbl1.shedProductStand = function(arg1)
	local var1 = tbl1.ToolShed
	for k1, v1 in ipairs(var1.ProductDisplays) do
		if v1.Key ~= arg1 then
			continue
		end

		local var2 = Vector3.new(v1.Wall * (var1.HalfWidth - var1.ProductStandInset), var1.FloorY + 3, v1.Z)
		return tbl1.shedPoint(var2)
	end

	return nil
end

tbl1.insideShed = function(arg1)
	local var1 = tbl1.ToolShed
	local var2 = var1.CFrame:PointToObjectSpace(arg1)
	local bool2 = false
	if math.abs(var2.X) <= var1.HalfWidth then
		bool2 = false
		if math.abs(var2.Z) <= var1.HalfDepth then
			bool2 = false
			if -1 <= var2.Y then
				bool2 = var2.Y <= var1.WallHeight + 1
			end
		end
	end

	return bool2
end

tbl2 = { Body = CFrame.lookAt(Vector3.new(-23, -13, -2), Vector3.new(0, -13, -2)) }
tbl2.OffSwitch = CFrame.lookAt(Vector3.new(-15.4, -13, 6.6), Vector3.new(-1, -13, -8))
tbl1.Freezer = tbl2
tbl2 = { EstablishingFrom = CFrame.lookAt(Vector3.new(34, 34, 92), Vector3.new(0, 16, 0)) }
tbl2.EstablishingTo = CFrame.lookAt(Vector3.new(0, 14, 62), Vector3.new(0, 12, 0))
tbl2.HouseSaved = CFrame.lookAt(Vector3.new(-38, 26, 70), Vector3.new(0, 14, -2))
tbl2.FreezerView = CFrame.lookAt(Vector3.new(-6, -5, 8), Vector3.new(-21, -7, -2))
tbl1.Cameras = tbl2
return tbl1

--- ReplicatedStorage.FrozenHouse.IceCodec [ModuleScript]
-- y u r i

local var1 = game:GetService("EncodingService")
local tbl1 = { DELTA = 1, SNAPSHOT = 2, JOIN = 3 }
tbl1.encodeDelta = function(arg1, arg2, arg3)
	local num1 = 8
	for k1, v1 in ipairs(arg3) do
		local var1 = #v1.locals * 4
		num1 = num1 + (var1 + 8)
	end

	local var2 = buffer.create(num1)
	buffer.writeu8(var2, 0, tbl1.DELTA)
	buffer.writeu8(var2, 1, arg1)
	buffer.writeu32(var2, 2, arg2)
	buffer.writeu16(var2, 6, #arg3)
	local num2 = 8
	for k2, v2 in ipairs(arg3) do
		buffer.writeu16(var2, num2, v2.chunk)
		buffer.writeu32(var2, num2 + 2, v2.version)
		local var3 = v2.locals
		buffer.writeu16(var2, num2 + 6, #var3)
		num2 = num2 + 8
		local var4 = v2.values
		for k3, v3 in ipairs(v2.locals) do
			buffer.writeu16(var2, num2, v3)
			buffer.writeu16(var2, num2 + 2, var4[k3])
			num2 = num2 + 4
		end
	end

	return var2
end

tbl1.encodeSnapshot = function(arg1, arg2, arg3, arg4)
	local tbl1 = {}
	local num1 = 8
	for k1, v1 in ipairs(arg4) do
		tbl1[k1] = var1:CompressBuffer(v1.raw, Enum.CompressionAlgorithm.Zstd, 3)
		local num2 = 10
		local var2 = num2 + buffer.len(tbl1[k1])
		num1 = num1 + var2
	end

	local var3 = buffer.create(num1)
	buffer.writeu8(var3, 0, arg1)
	buffer.writeu8(var3, 1, arg2)
	buffer.writeu32(var3, 2, arg3)
	buffer.writeu16(var3, 6, #arg4)
	local num3 = 8
	for k2, v2 in ipairs(arg4) do
		buffer.writeu16(var3, num3, v2.chunk)
		buffer.writeu32(var3, num3 + 2, v2.version)
		local var4 = tbl1[k2]
		buffer.writeu32(var3, num3 + 6, (buffer.len(var4)))
		buffer.copy(var3, num3 + 10, var4)
		num3 = num3 + (10 + buffer.len(var4))
	end

	return var3
end

tbl1.decode = function(arg1)
	if typeof(arg1) ~= "buffer" or buffer.len(arg1) < 8 then
		return nil
	end

	local var2 = buffer.len(arg1)
	local var3 = buffer.readu8(arg1, 0)
	local tbl2 = { kind = var3, fieldId = buffer.readu8(arg1, 1) }
	tbl2.seq = buffer.readu32(arg1, 2)
	local var5 = buffer.readu16(arg1, 6)
	local num1 = 8
	if var3 == tbl1.DELTA then
		local tbl3 = {}
		for i1 = 1, var5 do
			if var2 < num1 + 8 then
				return nil
			end

			local var6 = buffer.readu16(arg1, num1 + 6)
			local tbl4 = { chunk = buffer.readu16(arg1, num1) }
			tbl4.version = buffer.readu32(arg1, num1 + 2)
			tbl4.locals = table.create(var6)
			tbl4.values = table.create(var6)
			num1 = num1 + 8
			if var2 < num1 + var6 * 4 then
				return nil
			end

			for i2 = 1, var6 do
				tbl4.locals[i2] = buffer.readu16(arg1, num1)
				tbl4.values[i2] = buffer.readu16(arg1, num1 + 2)
				num1 = num1 + 4
			end

			table.insert(tbl3, tbl4)
		end

		tbl2.deltas = tbl3
		return tbl2
	end

	if var3 == tbl1.SNAPSHOT or var3 == tbl1.JOIN then
		local tbl5 = {}
		for i3 = 1, var5 do
			if var2 < num1 + 10 then
				return nil
			end

			local var7 = buffer.readu32(arg1, num1 + 6)
			if var2 < num1 + 10 + var7 then
				return nil
			end

			local var8 = buffer.create(var7)
			buffer.copy(var8, 0, arg1, num1 + 10, var7)
			local success, result = pcall(function()
				local var2 = var8
				local var3 = Enum.CompressionAlgorithm.Zstd
				return var1:DecompressBuffer(var2, var3)
			end)

			if not success then
				return nil
			end

			local tbl6 = { chunk = buffer.readu16(arg1, num1) }
			tbl6.version = buffer.readu32(arg1, num1 + 2)
			tbl6.data = result
			table.insert(tbl5, tbl6)
			num1 = num1 + (var7 + 10)
		end

		tbl2.snapshots = tbl5
		return tbl2
	end

	return nil
end

tbl1.apply = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = arg1.chunkVersion
	local var2
	if arg2.deltas then
		if not arg3 then
			return false
		end

		local bool1 = false
		for k1, v1 in ipairs(arg2.deltas) do
			local var3 = v1.chunk
			if var3 >= arg1.chunkCount then
				continue
			end

			local var4 = var1[var3 + 1]
			local var5
			local var6
			if v1.version == var4 + 1 and (not arg4[var3]) then
				var1[var3 + 1] = v1.version
				local var7 = v1.values
				for k2, v2 in ipairs(v1.locals) do
					local var8 = arg1:ownedIndex(var3, v2)
					local var9 = arg1:get(var8)
					local var10 = var7[k2]
					if var9 == var10 then
						continue
					end

					arg1:set(var8, var10)
					arg5(var8, var9, var10)
				end
			else
				if var4 >= v1.version then
					continue
				end

				arg4[var3] = true
				bool1 = true
			end
		end

		return bool1
	end

	local var11 = arg2.snapshots
	for k3, v3 in ipairs(var11 or {}) do
		local var12 = v3.chunk
		if var12 >= arg1.chunkCount then
			continue
		end

		if (var1[var12 + 1] <= v3.version or arg4[var12]) and arg1:writeChunk(var12, v3.data) then
			var1[var12 + 1] = v3.version
			arg4[var12] = nil
			arg6(var12)
		end
	end

	return false
end

tbl1.encodeImpacts = function(arg1)
	local var1 = math.min(#arg1, 40)
	local var2 = buffer.create(var1 * 24 + 1)
	buffer.writeu8(var2, 0, var1)
	for i1 = 1, var1 do
		local var3 = arg1[i1].position
		local var4 = (i1 - 1) * 24 + 1
		buffer.writef32(var2, var4, var3.X)
		buffer.writef32(var2, var4 + 4, var3.Y)
		buffer.writef32(var2, var4 + 8, var3.Z)
		local var5 = arg1[i1].normal
		buffer.writei8(var2, var4 + 12, (math.clamp(math.round(var5.X * 127), -127, 127)))
		buffer.writei8(var2, var4 + 13, (math.clamp(math.round(var5.Y * 127), -127, 127)))
		buffer.writei8(var2, var4 + 14, (math.clamp(math.round(var5.Z * 127), -127, 127)))
		buffer.writef64(var2, var4 + 15, arg1[i1].userId)
		buffer.writeu8(var2, var4 + 23, arg1[i1].tool)
	end

	return var2
end

tbl1.decodeImpacts = function(arg1)
	local tbl1 = {}
	if typeof(arg1) ~= "buffer" or buffer.len(arg1) < 1 then
		return tbl1
	end

	local var1 = buffer.readu8(arg1, 0)
	if buffer.len(arg1) < var1 * 24 + 1 then
		return tbl1
	end

	for i1 = 1, var1 do
		local var2 = (i1 - 1) * 24 + 1
		local var3 = Vector3.new(buffer.readi8(arg1, var2 + 12), buffer.readi8(arg1, var2 + 13), (buffer.readi8(arg1, var2 + 14)))
		local tbl2 = { position = Vector3.new(buffer.readf32(arg1, var2), buffer.readf32(arg1, var2 + 4), (buffer.readf32(arg1, var2 + 8))) }
		tbl2.normal = 0 < var3.Magnitude and var3.Unit or Vector3.new(0, 1, 0)
		tbl2.userId = buffer.readf64(arg1, var2 + 15)
		tbl2.tool = buffer.readu8(arg1, var2 + 23)
		table.insert(tbl1, tbl2)
	end

	return tbl1
end

return tbl1

--- ReplicatedStorage.FrozenHouse.Net [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("ReplicatedStorage")
local tbl1 = {
	"ClientReady",
	"MeltState",
	"SaveSettings",
	"RequestEntrance",
	"RequestLobby",
	"IceResync",
	"IceStream",
	"RunEvent",
	"SettingsLoaded",
	"GrenadeFx",
}

local tbl2 = {}
local tbl3 = { "MeltAim", "HeatFx" }
local tbl4 = { "Shop", "Throw" }
local tbl5 = {}
tbl5.init = function()
	if var1:IsServer() then
		local var4 = var2:FindFirstChild("FrozenHouseNet")
		if not var4 then
			var4 = Instance.new("Folder")
			var4.Name = "FrozenHouseNet"
			var4.Parent = var2
		end

		for k1, v1 in ipairs(tbl1) do
			local var6 = var4:FindFirstChild(v1)
			local var7 = tbl2
			local var8
			if var6 and var6.ClassName == "RemoteEvent" then
				var8 = var6
			elseif var6 then
				var6:Destroy()
			end

			var7[v1] = var8
		end

		for k2, v2 in ipairs(tbl3) do
			local var10 = var4:FindFirstChild(v2)
			local var11 = tbl2
			if var10 and var10.ClassName == "UnreliableRemoteEvent" then
				var8 = var10
			elseif var10 then
				var10:Destroy()
			end

			var11[v2] = var8
		end

		for k3, v3 in ipairs(tbl4) do
			local var13 = var4:FindFirstChild(v3)
			local var14 = tbl2
			if var13 and var13.ClassName == "RemoteFunction" then
				var8 = var13
			elseif var13 then
				var13:Destroy()
			end

			var14[v3] = var8
		end
	else
		local var15 = tbl3
		local var16 = var2:WaitForChild("FrozenHouseNet")
		for k4, v4 in ipairs({ tbl1, var15, tbl4 }) do
			for k5, v5 in ipairs(v4) do
				tbl2[v5] = var16:WaitForChild(v5)
			end
		end
	end

	return tbl5
end

tbl5.get = function(arg1)
	local var1 = tbl2[arg1]
	assert(var1, "Net: unknown or uninitialised remote " .. arg1)
	return var1
end

return tbl5

--- ReplicatedStorage.FrozenHouse.AudioConfig [ModuleScript]
-- y u r i

local tbl1 = {
	Id = "rbxassetid://" .. tostring(9114742693),
	Volume = 0.32,
	Speed = 1,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Hair Dryer 1 (SFX)",
}

tbl1.Region = { 2, 9 }
local tbl2 = { Hairdryer = tbl1 }
tbl1 = {
	Id = "rbxassetid://" .. tostring(9114742693),
	Volume = 0.3,
	Speed = 0.8,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Hair Dryer 1 (SFX), pitched down",
}

tbl1.Region = { 2, 9 }
tbl2.HeatGunMotor = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9120192302),
	Volume = 0.16,
	Speed = 1,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Torch Lighter 1 (SFX)",
}

tbl1.Region = { 2.5, 8.5 }
tbl2.HeatGunHiss = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9116496074),
	Volume = 0.28,
	Speed = 0.9,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Medium Pressure Air Release 6 (SFX)",
}

tbl1.Region = { 0.4, 4.2 }
tbl2.SteamJet = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9125446543),
	Volume = 0.12,
	Speed = 1.3,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Command Room Tone Deep Air Conditioning Hum (SFX)",
}

tbl2.SteamHum = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9116496050),
	Volume = 0.3,
	Speed = 1.1,
	Group = "Effects",
	Source = "ProSoundEffects: Medium Pressure Air Release 7 (SFX), the start",
}

tbl1.Region = { 0, 0.9 }
tbl2.SteamRelease = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9120192076),
	Volume = 0.26,
	Speed = 0.75,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Torch Lighter 2 (SFX), the steady flame, pitched down",
}

tbl1.Region = { 3, 12 }
tbl2.FlameLoop = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9120192076),
	Volume = 0.3,
	Speed = 0.85,
	Group = "Effects",
	Source = "ProSoundEffects: Torch Lighter 2 (SFX), click on",
}

tbl1.Region = { 0, 1.4 }
tbl2.FlameIgnite = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9120192302),
	Volume = 0.22,
	Speed = 0.85,
	Group = "Effects",
	Source = "ProSoundEffects: Torch Lighter 1 (SFX), click off",
}

tbl1.Region = { 8.5, 10.5 }
tbl2.FlameStop = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9120972444),
	Volume = 0.35,
	Group = "Effects",
	Source = "ProSoundEffects: Wood Whoosh Slicing Air Quick Swings 1 (SFX)",
}

tbl2.GrenadeThrow = tbl1
tbl2.GrenadeTick = {
	Id = "rbxasset://sounds/volume_slider.ogg",
	Volume = 0.22,
	Speed = 1.5,
	Group = "Effects",
	Source = "Roblox client bundled sound, pitched up",
}

tbl1 = {
	Id = "rbxassetid://" .. tostring(9125579780),
	Volume = 0.34,
	Speed = 0.85,
	Group = "Effects",
	Source = "ProSoundEffects: Giant Steam Chuff Air Burst Through The Tube 2 (SFX), the start, pitched down",
}

tbl1.Region = { 0, 1.3 }
tbl2.GrenadeBurst = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9114858178),
	Volume = 0.22,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Ice Crack And Sizzle 1 (SFX)",
}

tbl1.Region = { 0.5, 13 }
tbl2.Sizzle = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9114858761),
	Volume = 0.3,
	Group = "Effects",
	Source = "ProSoundEffects: Ice Cracks 2 (SFX)",
}

tbl2.Crack = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9125610574),
	Volume = 0.2,
	Group = "Effects",
	Source = "ProSoundEffects: Ice Break Small Pieces Break Fall To Concrete (SFX)",
}

tbl1.Region = { 0, 1.2 }
tbl2.CellFinish = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9112903083),
	Volume = 0.18,
	Group = "Effects",
	Source = "ProSoundEffects: Water Drip Single Drops Into Tin Bucket 3 (SFX)",
}

tbl2.Drips = tbl1
tbl2.UITick = {
	Id = "rbxasset://sounds/volume_slider.ogg",
	Volume = 0.4,
	Group = "Effects",
	Source = "Roblox client bundled sound",
}

tbl1 = {
	Id = "rbxassetid://" .. tostring(9116394545),
	Volume = 0.5,
	Speed = 1.15,
	Group = "Effects",
	Source = "ProSoundEffects: Magic Glows Soft Clusters Of Chiming Hits 1 (SFX)",
}

tbl2.Purchase = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9116395089),
	Volume = 0.5,
	Group = "Effects",
	Source = "ProSoundEffects: Magic Glows Soft Clusters Of Chiming Hits 4 (SFX)",
}

tbl2.RoomClear = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9116395089),
	Volume = 0.28,
	Speed = 1.25,
	Group = "Effects",
	Source = "ProSoundEffects: Magic Glows Soft Clusters Of Chiming Hits 4 (SFX)",
}

tbl2.Reveal = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(365950085),
	Volume = 0.5,
	Group = "Effects",
	Source = "Roblox: ToasterUp",
}

tbl2.ToastPop = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9040193225),
	Volume = 0.55,
	Group = "Music",
	Source = "APMOfficial: SOS (sting)",
}

tbl2.Jingle = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9114057104),
	Volume = 0.14,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Desert Wind Whistley Light Gusts 1 (SFX)",
}

tbl2.Wind = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9125446543),
	Volume = 0.05,
	Speed = 0.9,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Command Room Tone Deep Air Conditioning Hum (SFX)",
}

tbl2.RoomTone = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(9125446564),
	Volume = 0.22,
	Speed = 0.8,
	Loop = true,
	Group = "Effects",
	Source = "ProSoundEffects: Command Room Tone Deep Air Conditioning Hum (SFX)",
}

tbl2.FreezerHum = tbl1
tbl1 = {
	Id = "rbxassetid://" .. tostring(84799695883181),
	Volume = 0.22,
	Loop = true,
	Group = "Music",
	Source = "DistrokidOfficial: Cozy Booth, Calm Progressions",
}

tbl2.Music = tbl1
return tbl2

--- ReplicatedStorage.FrozenHouse.IceGrid [ModuleScript]
-- y u r i

local var1 = game:GetService("EncodingService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.ISO = 32768
tbl1.FULL = 65535
tbl1.BLOCKED = 1
tbl1.REQUIRED = 2
tbl1.DOOR = 4
tbl1.BLOCK_CAP = 37000
tbl1.new = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = setmetatable({}, tbl1)
	var1.origin = arg1
	var1.spacing = arg2
	var1.nx = arg3
	var1.ny = arg4
	var1.nz = arg5
	var1.nxy = arg3 * arg4
	var1.count = arg3 * arg4 * arg5
	var1.chunkSize = arg6
	var1.cnx = math.max(1, (math.ceil((arg3 - 1) / arg6)))
	var1.cny = math.max(1, (math.ceil((arg4 - 1) / arg6)))
	var1.cnz = math.max(1, (math.ceil((arg5 - 1) / arg6)))
	var1.chunkCount = var1.cnx * var1.cny * var1.cnz
	var1.density = buffer.create(var1.count * 2)
	var1.flags = buffer.create(var1.count)
	var1.region = buffer.create(var1.count)
	var1.chunkVersion = table.create(var1.chunkCount, 0)
	var1.fieldId = 0
	var1.name = "Field"
	return var1
end

tbl1.clone = function(arg1)
	local var1 = tbl1.new(arg1.origin, arg1.spacing, arg1.nx, arg1.ny, arg1.nz, arg1.chunkSize)
	buffer.copy(var1.density, 0, arg1.density)
	buffer.copy(var1.flags, 0, arg1.flags)
	buffer.copy(var1.region, 0, arg1.region)
	var1.chunkVersion = table.clone(arg1.chunkVersion)
	var1.fieldId = arg1.fieldId
	var1.name = arg1.name
	return var1
end

tbl1.index = function(arg1, arg2, arg3, arg4)
	return arg2 + arg1.nx * (arg3 + arg1.ny * arg4)
end

tbl1.coords = function(arg1, arg2)
	local var1 = arg1.nx
	local var2 = arg2 // var1
	return arg2 % var1, var2 % arg1.ny, var2 // arg1.ny
end

tbl1.position = function(arg1, arg2, arg3, arg4)
	return arg1.origin + Vector3.new(arg2, arg3, arg4) * arg1.spacing
end

tbl1.inBounds = function(arg1, arg2, arg3, arg4)
	local bool2 = false
	if 0 <= arg2 then
		bool2 = false
		if 0 <= arg3 then
			bool2 = false
			if 0 <= arg4 then
				bool2 = false
				if arg2 < arg1.nx then
					bool2 = false
					if arg3 < arg1.ny then
						bool2 = arg4 < arg1.nz
					end
				end
			end
		end
	end

	return bool2
end

local var2 = buffer.readu16
tbl1.get = function(arg1, arg2)
	return (var2(arg1.density, arg2 * 2))
end

local var3 = buffer.writeu16
tbl1.set = function(arg1, arg2, arg3)
	var3(arg1.density, arg2 * 2, arg3)
end

local var4 = buffer.readu8
tbl1.flagsAt = function(arg1, arg2)
	return (var4(arg1.flags, arg2))
end

tbl1.regionAt = function(arg1, arg2)
	return (var4(arg1.region, arg2))
end

local var5 = bit32.band
tbl1.render = function(arg1, arg2, arg3, arg4)
	local var7 = arg1.nx
	local var8 = arg1.ny
	local var9 = arg1.nz
	if arg2 <= 0 or (arg3 <= 0 or (arg4 <= 0 or (var7 - 1 <= arg2 or (var8 - 1 <= arg3 or var9 - 1 <= arg4)))) then
		return 0
	end

	local var10 = arg1.flags
	local var11 = arg2 + var7 * (arg3 + var8 * arg4)
	if var5(var4(var10, var11), 1) == 0 then
		return (var2(arg1.density, var11 * 2))
	end

	local var12 = arg1.density
	local num1 = 0
	local var13 = arg1.nxy
	if 0 < arg2 then
		if var5(var4(var10, var11 - 1), 1) == 0 then
			num1 = math.max(num1, (var2(var12, (var11 - 1) * 2)))
		end
	end

	if arg2 < var7 - 1 then
		if var5(var4(var10, var11 + 1), 1) == 0 then
			num1 = math.max(num1, (var2(var12, (var11 + 1) * 2)))
		end
	end

	if 0 < arg3 then
		if var5(var4(var10, var11 - var7), 1) == 0 then
			num1 = math.max(num1, (var2(var12, (var11 - var7) * 2)))
		end
	end

	if arg3 < var8 - 1 then
		if var5(var4(var10, var11 + var7), 1) == 0 then
			num1 = math.max(num1, (var2(var12, (var11 + var7) * 2)))
		end
	end

	if 0 < arg4 then
		if var5(var4(var10, var11 - var13), 1) == 0 then
			num1 = math.max(num1, (var2(var12, (var11 - var13) * 2)))
		end
	end

	if arg4 < var9 - 1 and var5(var4(var10, var11 + var13), 1) == 0 then
		num1 = math.max(num1, (var2(var12, (var11 + var13) * 2)))
	end

	return (math.min(num1, 37000))
end

tbl1.densityAt = function(arg1, arg2)
	local var1 = (arg2 - arg1.origin) / arg1.spacing
	local var2 = math.floor(var1.X)
	local var3 = math.floor(var1.Y)
	local var4 = math.floor(var1.Z)
	local var5 = arg1:render(var2, var3, var4)
	local var6 = var1.X - var2
	local var7 = arg1:render(var2, var3 + 1, var4)
	local var8 = arg1:render(var2, var3, var4 + 1)
	local var9 = arg1:render(var2, var3 + 1, var4 + 1)
	local var10 = var5 + (arg1:render(var2 + 1, var3, var4) - var5) * var6
	local var11 = var1.Y - var3
	local var12 = var8 + (arg1:render(var2 + 1, var3, var4 + 1) - var8) * var6
	local var13 = var10 + (var7 + (arg1:render(var2 + 1, var3 + 1, var4) - var7) * var6 - var10) * var11
	return var13 + (var12 + (var9 + (arg1:render(var2 + 1, var3 + 1, var4 + 1) - var9) * var6 - var12) * var11 - var13) * (var1.Z - var4)
end

tbl1.normalAt = function(arg1, arg2)
	local var1 = arg1.spacing * 0.5
	local var2 = Vector3.new(-(arg1:densityAt(arg2 + Vector3.new(var1, 0, 0)) - arg1:densityAt(arg2 - Vector3.new(var1, 0, 0))), -(arg1:densityAt(arg2 + Vector3.new(0, var1, 0)) - arg1:densityAt(arg2 - Vector3.new(0, var1, 0))), -(arg1:densityAt(arg2 + Vector3.new(0, 0, var1)) - arg1:densityAt(arg2 - Vector3.new(0, 0, var1))))
	if var2.Magnitude < 0.001 then
		return nil
	end

	return var2.Unit
end

tbl1.raycast = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.spacing
	local str1 = "Y"
	local var2 = arg1.origin
	local var3 = arg1.origin + Vector3.new(arg1.nx - 1, arg1.ny - 1, arg1.nz - 1) * var1
	local num1 = 0
	local var4 = arg4
	for k1, v1 in ipairs({ "X", str1, "Z" }) do
		local var5 = arg3[v1]
		local var9 = arg2[v1]
		local var10 = var2[v1]
		local var11 = var3[v1]
		if math.abs(var5) < 1e-09 then
			if var9 < var10 or var11 < var9 then
				return nil
			end
		else
			local var15 = (var11 - var9) / var5
			local var16 = (var10 - var9) / var5
			if var15 < var16 then
				local var17 = var15
				var15 = var16
				var16 = var17
			end

			num1 = math.max(num1, var16)
			var4 = math.min(var4, var15)
		end
	end

	if var4 < num1 then
		return nil
	end

	local var18 = var1 * 0.3
	local var19 = num1
	if 32768 <= arg1:densityAt(arg2 + arg3 * num1) then
		return num1, arg2 + arg3 * num1, -arg3
	end

	local var20 = num1
	var20 = math.min(var20 + var18, var4)
	while var20 >= var4 and 32768 <= arg1:densityAt(arg2 + arg3 * var20) do
	end

	return nil
end

tbl1.openDoor = function(arg1, arg2, arg3)
	local var1 = (arg2 - arg1.origin) / arg1.spacing
	local var2 = (arg3 - arg1.origin) / arg1.spacing
	local var3 = arg1.flags
	local tbl2 = {}
	for i1 = math.max(math.ceil(var1.Z), 0), math.min(math.floor(var2.Z), arg1.nz - 1) do
		for i2 = math.max(math.ceil(var1.Y), 0), math.min(math.floor(var2.Y), arg1.ny - 1) do
			for i3 = math.max(math.ceil(var1.X), 0), math.min(math.floor(var2.X), arg1.nx - 1) do
				local var6 = i3 + arg1.nx * (i2 + arg1.ny * i1)
				local var7 = var4(var3, var6)
				if var5(var7, tbl1.DOOR) == 0 then
					continue
				end

				if var5(var7, tbl1.BLOCKED) == 0 then
					continue
				end

				buffer.writeu8(var3, var6, var7 - tbl1.BLOCKED)
				table.insert(tbl2, var6)
			end
		end
	end

	return tbl2
end

tbl1.boxesFromFolder = function(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in pairs(arg1:GetAttributes()) do
		if string.sub(k1, 1, #arg2) == arg2 then
			local var1 = string.sub(k1, #arg2 + 1)
			var1 = var1 or nil
		end

		local var2 = nil
		if not var2 or var2 == "" then
			continue
		end

		if typeof(v1) ~= "string" then
			continue
		end

		local tbl2 = {}
		for k2 in string.gmatch(v1, "[^,]+") do
			table.insert(tbl2, (tonumber(k2)))
		end

		if #tbl2 ~= 6 then
			continue
		end

		local var3 = tbl2[5]
		local tbl3 = { min = Vector3.new(tbl2[1], tbl2[2], tbl2[3]) }
		tbl3.max = Vector3.new(tbl2[4], var3, tbl2[6])
		tbl1[var2] = tbl3
	end

	return tbl1
end

tbl1.chunkCoords = function(arg1, arg2)
	local var1 = arg1.cnx
	local var2 = arg1.cny
	return arg2 % var1, arg2 // var1 % var2, arg2 // (var1 * var2)
end

tbl1.chunkOrigin = function(arg1, arg2)
	local var1, var2, var3 = arg1:chunkCoords(arg2)
	local var4 = var1 * arg1.chunkSize
	local var5 = var2 * arg1.chunkSize
	local var6 = var3 * arg1.chunkSize
	return arg1:position(var4, var5, var6)
end

tbl1.owner = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.chunkSize
	local var2 = math.min(arg4 // var1, arg1.cnz - 1)
	local var3 = math.min(arg3 // var1, arg1.cny - 1)
	local var4 = math.min(arg2 // var1, arg1.cnx - 1)
	local var5 = var1 + 1
	return var4 + arg1.cnx * (var3 + arg1.cny * var2), arg2 - var4 * var1 + var5 * (arg3 - var3 * var1 + var5 * (arg4 - var2 * var1))
end

tbl1.ownedIndex = function(arg1, arg2, arg3)
	local var1 = arg1.chunkSize
	local var2 = var1 + 1
	local var3, var4, var5 = arg1:chunkCoords(arg2)
	local var6 = arg3 // var2
	local var7 = var3 * var1 + arg3 % var2
	local var8 = var4 * var1 + var6 % var2
	local var9 = var5 * var1 + var6 // var2
	return arg1:index(var7, var8, var9)
end

tbl1.ownedRange = function(arg1, arg2)
	local var1, var2, var3 = arg1:chunkCoords(arg2)
	local var4 = arg1.chunkSize
	return var1 * var4, var1 == arg1.cnx - 1 and arg1.nx - 1 or var1 * var4 + var4 - 1, var2 * var4, var2 == arg1.cny - 1 and arg1.ny - 1 or var2 * var4 + var4 - 1, var3 * var4, var3 == arg1.cnz - 1 and arg1.nz - 1 or var3 * var4 + var4 - 1
end

tbl1.renderChunksAround = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.chunkSize
	local var2 = math.clamp(arg2 - 3, 0, arg1.nx - 2) // var1
	local var3 = math.min(math.clamp(arg2 + 2, 0, arg1.nx - 2) // var1, arg1.cnx - 1)
	local var4 = math.clamp(arg3 - 3, 0, arg1.ny - 2) // var1
	local var5 = math.min(math.clamp(arg3 + 2, 0, arg1.ny - 2) // var1, arg1.cny - 1)
	for i1 = math.clamp(arg4 - 3, 0, arg1.nz - 2) // var1, math.min(math.clamp(arg4 + 2, 0, arg1.nz - 2) // var1, arg1.cnz - 1) do
		for i2 = var4, var5 do
			for i3 = var2, var3 do
				arg5[i3 + arg1.cnx * (i2 + arg1.cny * i1)] = true
			end
		end
	end
end

tbl1.readChunk = function(arg1, arg2)
	local var1, var4, var5, var6, var7, var8 = arg1:ownedRange(arg2)
	local var9 = buffer.create((var4 - var1 + 1) * (var6 - var5 + 1) * (var8 - var7 + 1) * 2)
	local num1 = 0
	local var10 = arg1.density
	local var11 = arg1.nx
	local var12 = arg1.ny
	for i1 = var7, var8 do
		for i2 = var5, var6 do
			for i3 = var1, var4 do
				local var13 = var11 * (i2 + var12 * i1)
				var3(var9, num1, (var2(var10, (i3 + var13) * 2)))
				num1 = num1 + 2
			end
		end
	end

	return var9
end

tbl1.writeChunk = function(arg1, arg2, arg3)
	local var1, var4, var5, var6, var7, var8 = arg1:ownedRange(arg2)
	if buffer.len(arg3) ~= (var4 - var1 + 1) * (var6 - var5 + 1) * (var8 - var7 + 1) * 2 then
		return false
	end

	local num1 = 0
	local var9 = arg1.density
	local var10 = arg1.nx
	local var11 = arg1.ny
	for i1 = var7, var8 do
		for i2 = var5, var6 do
			for i3 = var1, var4 do
				local var12 = var10 * (i2 + var11 * i1)
				var3(var9, (i3 + var12) * 2, (var2(arg3, num1)))
				num1 = num1 + 2
			end
		end
	end

	return true
end

tbl1.hash = function(arg1)
	local num1 = 2166136261
	local var1 = arg1.density
	for i1 = 0, arg1.count - 1 do
		num1 = bit32.bxor(num1, (var2(var1, i1 * 2))) * 16777619 % 4294967296
	end

	return num1
end

tbl1.pack = function(arg1)
	local var2 = var1:CompressBuffer(arg1, Enum.CompressionAlgorithm.Zstd, 9)
	return buffer.tostring(var1:Base64Encode(var2))
end

tbl1.unpack = function(arg1)
	local var2 = arg1
	local var3 = var1:Base64Decode(buffer.fromstring(var2))
	local var4 = Enum.CompressionAlgorithm.Zstd
	return var1:DecompressBuffer(var3, var4)
end

tbl1.fromFolder = function(arg1)
	local var2 = arg1:GetAttribute("Dims")
	local var3 = tbl1.new(arg1:GetAttribute("Origin"), arg1:GetAttribute("Spacing"), var2.X, var2.Y, var2.Z, (arg1:GetAttribute("ChunkSize")))
	var3.fieldId = arg1:GetAttribute("FieldId") or 0
	var3.name = arg1.Name
	local str1 = "Flags"
	for k1, v1 in ipairs({ "Density", str1, "Region" }) do
		local var4 = arg1:WaitForChild(v1, 10).Value
		local var5 = var1:DecompressBuffer(var1:Base64Decode(buffer.fromstring(var4)), Enum.CompressionAlgorithm.Zstd)
		local var6 = string.lower(v1)
		assert(buffer.len(var5) == buffer.len(var3[var6]), "IceGrid: " .. v1 .. " has the wrong size")
		var3[var6] = var5
	end

	return var3
end

tbl1.writeFolder = function(arg1, arg2)
	arg2:SetAttribute("Origin", arg1.origin)
	arg2:SetAttribute("Spacing", arg1.spacing)
	arg2:SetAttribute("Dims", (Vector3.new(arg1.nx, arg1.ny, arg1.nz)))
	arg2:SetAttribute("ChunkSize", arg1.chunkSize)
	arg2:SetAttribute("FieldId", arg1.fieldId)
	local str1 = "Flags"
	local tbl1 = {}
	for k1, v1 in ipairs({ "Density", str1, "Region" }) do
		local var2 = arg2:FindFirstChild(v1)
		var2 = var2 or Instance.new("StringValue")
		var2.Name = v1
		local var3 = var1:CompressBuffer(arg1[string.lower(v1)], Enum.CompressionAlgorithm.Zstd, 9)
		var2.Value = buffer.tostring(var1:Base64Encode(var3))
		var2.Parent = arg2
		tbl1[v1] = #var2.Value
	end

	return tbl1
end

return tbl1

--- ReplicatedStorage.FrozenHouse.IceMesher [ModuleScript]
-- y u r i

local var1 = require(script.Parent.MarchingCubesTable)
local var2 = require(script.Parent.IceGrid).ISO
local function gather(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.chunkSize
	local var3 = var1 + 3
	local var4 = arg1.nx
	local var5 = arg1.ny
	local var6 = arg1.nz
	local var7 = arg1.density
	local var8 = arg1.flags
	local var9 = arg5.values
	local num1 = 0
	local bool1 = false
	local bool2 = false
	for i1 = 0, var3 - 1 do
		local var10 = arg4 * var1 - 1
		local var12 = var10 + i1
		local var13 = arg2 * var1 - 1
		local var14 = arg3 * var1 - 1
		local var15 = buffer.readu8
		local var16 = buffer.readu16
		local bool3 = false
		if 0 < var12 then
			bool3 = var12 < var6 - 1
		end

		for i2 = 0, var3 - 1 do
			local var19 = bool3
			local var20 = var14 + i2
			if var19 then
				var19 = false
				if 0 < var20 then
					var19 = var20 < var5 - 1
				end
			end

			for i3 = 0, var3 - 1 do
				num1 = num1 + 1
				local num2 = 0
				if var19 then
					local var25 = var13 + i3
					if 0 < var25 then
						if var25 < var4 - 1 then
							local var27 = var4 * (var20 + var5 * var12)
							local var28 = var25 + var27
							num2 = if bit32.band(var15(var8, var28), 1) == 0 then var16(var7, var28 * 2) else arg1:render(var25, var20, var12)
						end
					end
				end

				var9[num1] = num2
				if var2 <= num2 then
					bool1 = true
				else
					bool2 = true
				end
			end
		end
	end

	return bool1 and bool2
end

local tbl1 = { 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0 }
local tbl2 = { 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1 }
local tbl3 = { 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0 }
local tbl4 = { 0, 1, 0, 1, 0, 1, 0, 1, 2, 2, 2, 2 }
return {
	newOutput = function(arg1)
		local var1 = arg1 + 3
		local tbl1 = {
			chunkSize = arg1,
			values = table.create(var1 * var1 * var1, 0),
			vertexCount = 0,
			triCount = 0,
		}

		tbl1.edgeVert = {}
		tbl1.gx = {}
		tbl1.gy = {}
		tbl1.gz = {}
		tbl1.px = {}
		tbl1.py = {}
		tbl1.pz = {}
		tbl1.qx = {}
		tbl1.qy = {}
		tbl1.qz = {}
		tbl1.tris = {}
		return tbl1
	end,
	extract = function(arg1, arg2, arg3)
		local var3 = arg1.chunkSize
		local var4 = var3 + 3
		local var5, var6, var7 = arg1:chunkCoords(arg2)
		arg3.vertexCount = 0
		arg3.triCount = 0
		local var8 = var4 * var4
		local var9 = arg1.spacing
		if not gather(arg1, var5, var6, var7, arg3) then
			return arg3
		end

		local var10 = arg3.edgeVert
		table.clear(var10)
		local var11 = arg3.gx
		table.clear(var11)
		local var12 = arg3.gy
		table.clear(var12)
		local var13 = arg3.gz
		table.clear(var13)
		local tbl5 = { 1, 2, 1 }
		local var14 = arg3.values
		local var15 = math.min(var3, arg1.nx - 1 - var5 * var3)
		local var16 = math.min(var3, arg1.ny - 1 - var6 * var3)
		local var17 = math.min(var3, arg1.nz - 1 - var7 * var3)
		local var18 = arg3.px
		local var19 = arg3.py
		local var20 = arg3.pz
		local var21 = arg3.qx
		local var22 = arg3.qy
		local var23 = arg3.qz
		local var24 = arg3.tris
		local num1 = 0
		local num2 = 0
		local function gradient(arg1)
			local var2 = var11[arg1]
			if var2 then
				return var2, var12[arg1], var13[arg1]
			end

			local num1 = 0
			local num2 = 0
			local num3 = 0
			for i1 = -1, 1 do
				local var3 = tbl5[i1 + 2]
				for i2 = -1, 1 do
					local var5 = arg1 + i1 * var4 + i2 * var8
					local var6 = var3 * tbl5[i2 + 2]
					local var7 = arg1 + i1 + i2 * var8
					local var9 = arg1 + i1 + i2 * var4
					num1 = num1 + var6 * (var14[var5 + 1] - var14[var5 - 1])
					num2 = num2 + var6 * (var14[var7 + var4] - var14[var7 - var4])
					num3 = num3 + var6 * (var14[var9 + var8] - var14[var9 - var8])
				end
			end

			var11[arg1] = num1
			var12[arg1] = num2
			var13[arg1] = num3
			return num1, num2, num3
		end

		local var25 = table.create(12, 0)
		local var26 = table.create(12, 0)
		for i1 = 1, 12 do
			var25[i1] = tbl1[i1] + tbl2[i1] * var4 + tbl3[i1] * var8
			local var28 = tbl4[i1]
			local var29
			if var28 == 0 then
				var29 = 1
			elseif var28 == 1 then
				var29 = var4
				var29 = var29 or var8
			end

			var26[i1] = var29
		end

		for i2 = 1, var17 do
			for i3 = 1, var16 do
				for i4 = 1, var15 do
					local var30 = i2 * var8 + i3 * var4 + 1
					local var31 = var30 + i4
					local var32 = var14[var31 + 1]
					local var33 = var14[var31 + var4]
					local var34 = var14[var31 + var4 + 1]
					local var35 = var14[var31 + var8]
					local var36 = var14[var31 + var8 + 1]
					local var37 = var14[var31 + var8 + var4]
					local var38 = var14[var31 + var8 + var4 + 1]
					local num3 = 0
					if var2 <= var14[var31] then
						num3 = num3 + 1
					end

					if var2 <= var32 then
						num3 = num3 + 2
					end

					if var2 <= var34 then
						num3 = num3 + 4
					end

					if var2 <= var33 then
						num3 = num3 + 8
					end

					if var2 <= var35 then
						num3 = num3 + 16
					end

					if var2 <= var36 then
						num3 = num3 + 32
					end

					if var2 <= var38 then
						num3 = num3 + 64
					end

					if var2 <= var37 then
						num3 = num3 + 128
					end

					if num3 == 0 or num3 == 255 then
						continue
					end

					local var39 = var1[num3 + 1]
					for i5 = 1, #var39 do
						local var40 = var39[i5] + 1
						local var41 = var31 + var25[var40]
						local var42 = var41 * 3 + tbl4[var40]
						local var48 = var10[var42]
						if not var48 then
							local var49 = var41 + var26[var40]
							local var50 = var14[var41]
							local var53 = tbl4[var40]
							local var54 = (var2 - var50) / (var14[var49] - var50)
							local var55 = i4 - 1 + tbl1[var40]
							local var56 = i3 - 1 + tbl2[var40]
							local var57 = i2 - 1 + tbl3[var40]
							if var53 == 0 then
								var55 = var55 + var54
							elseif var53 == 1 then
								var56 = var56 + var54
							else
								var57 = var57 + var54
							end

							local var58, var59, var60 = gradient(var49)
							local var61, var62, var63 = gradient(var41)
							local var64 = var61 + (var58 - var61) * var54
							local var65 = var62 + (var59 - var62) * var54
							local var66 = var63 + (var60 - var63) * var54
							num1 = num1 + 1
							local var67 = math.sqrt(var64 * var64 + var65 * var65 + var66 * var66)
							var48 = num1
							var10[var42] = var48
							var18[var48] = var55 * var9
							var19[var48] = var56 * var9
							var20[var48] = var57 * var9
							if 1e-06 < var67 then
								var21[var48] = -var64 / var67
								var22[var48] = -var65 / var67
								var23[var48] = -var66 / var67
							else
								var21[var48] = 0
								var22[var48] = 1
								var23[var48] = 0
							end
						end

						num2 = num2 + 1
						var24[num2] = var48
					end
				end
			end
		end

		arg3.vertexCount = num1
		arg3.triCount = num2 // 3
		return arg3
	end,
}

--- ReplicatedStorage.FrozenHouse.MarchingCubesTable [ModuleScript]
-- y u r i

return {
	{},
	{ 8, 0, 3 },
	{ 1, 0, 9 },
	{ 8, 1, 3, 8, 9, 1 },
	{ 10, 2, 1 },
	{ 8, 0, 3, 10, 2, 1 },
	{ 10, 0, 9, 10, 2, 0 },
	{ 8, 2, 3, 8, 10, 2, 8, 9, 10 },
	{ 3, 2, 11 },
	{ 8, 2, 11, 8, 0, 2 },
	{ 3, 2, 11, 1, 0, 9 },
	{ 8, 2, 11, 8, 1, 2, 8, 9, 1 },
	{ 3, 10, 11, 3, 1, 10 },
	{ 8, 10, 11, 8, 1, 10, 8, 0, 1 },
	{ 3, 10, 11, 3, 9, 10, 3, 0, 9 },
	{ 8, 10, 11, 8, 9, 10 },
	{ 7, 4, 8 },
	{ 7, 0, 3, 7, 4, 0 },
	{ 7, 4, 8, 1, 0, 9 },
	{ 7, 1, 3, 7, 9, 1, 7, 4, 9 },
	{ 7, 4, 8, 10, 2, 1 },
	{ 7, 0, 3, 7, 4, 0, 10, 2, 1 },
	{ 7, 4, 8, 10, 0, 9, 10, 2, 0 },
	{ 7, 2, 3, 7, 10, 2, 7, 9, 10, 7, 4, 9 },
	{ 7, 4, 8, 3, 2, 11 },
	{ 7, 2, 11, 7, 0, 2, 7, 4, 0 },
	{ 7, 4, 8, 3, 2, 11, 1, 0, 9 },
	{ 7, 2, 11, 7, 1, 2, 7, 9, 1, 7, 4, 9 },
	{ 7, 4, 8, 3, 10, 11, 3, 1, 10 },
	{ 7, 10, 11, 7, 1, 10, 7, 0, 1, 7, 4, 0 },
	{ 7, 4, 8, 3, 10, 11, 3, 9, 10, 3, 0, 9 },
	{ 7, 10, 11, 7, 9, 10, 7, 4, 9 },
	{ 9, 4, 5 },
	{ 8, 0, 3, 9, 4, 5 },
	{ 1, 4, 5, 1, 0, 4 },
	{ 8, 1, 3, 8, 5, 1, 8, 4, 5 },
	{ 10, 2, 1, 9, 4, 5 },
	{ 8, 0, 3, 10, 2, 1, 9, 4, 5 },
	{ 10, 4, 5, 10, 0, 4, 10, 2, 0 },
	{ 8, 2, 3, 8, 10, 2, 8, 5, 10, 8, 4, 5 },
	{ 3, 2, 11, 9, 4, 5 },
	{ 8, 2, 11, 8, 0, 2, 9, 4, 5 },
	{ 3, 2, 11, 1, 4, 5, 1, 0, 4 },
	{ 8, 2, 11, 8, 1, 2, 8, 5, 1, 8, 4, 5 },
	{ 3, 10, 11, 3, 1, 10, 9, 4, 5 },
	{ 8, 10, 11, 8, 1, 10, 8, 0, 1, 9, 4, 5 },
	{ 3, 10, 11, 3, 5, 10, 3, 4, 5, 3, 0, 4 },
	{ 8, 10, 11, 8, 5, 10, 8, 4, 5 },
	{ 7, 9, 8, 7, 5, 9 },
	{ 7, 0, 3, 7, 9, 0, 7, 5, 9 },
	{ 7, 0, 8, 7, 1, 0, 7, 5, 1 },
	{ 7, 1, 3, 7, 5, 1 },
	{ 7, 9, 8, 7, 5, 9, 10, 2, 1 },
	{ 7, 0, 3, 7, 9, 0, 7, 5, 9, 10, 2, 1 },
	{ 7, 0, 8, 7, 2, 0, 7, 10, 2, 7, 5, 10 },
	{ 7, 2, 3, 7, 10, 2, 7, 5, 10 },
	{ 7, 9, 8, 7, 5, 9, 3, 2, 11 },
	{ 7, 2, 11, 7, 0, 2, 7, 9, 0, 7, 5, 9 },
	{ 7, 0, 8, 7, 1, 0, 7, 5, 1, 3, 2, 11 },
	{ 7, 2, 11, 7, 1, 2, 7, 5, 1 },
	{ 7, 9, 8, 7, 5, 9, 3, 10, 11, 3, 1, 10 },
	{ 7, 10, 11, 7, 1, 10, 7, 0, 1, 7, 9, 0, 7, 5, 9 },
	{ 0, 11, 3, 0, 10, 11, 0, 5, 10, 0, 7, 5, 0, 8, 7 },
	{ 7, 10, 11, 7, 5, 10 },
	{ 5, 6, 10 },
	{ 8, 0, 3, 5, 6, 10 },
	{ 5, 6, 10, 1, 0, 9 },
	{ 8, 1, 3, 8, 9, 1, 5, 6, 10 },
	{ 5, 2, 1, 5, 6, 2 },
	{ 8, 0, 3, 5, 2, 1, 5, 6, 2 },
	{ 5, 0, 9, 5, 2, 0, 5, 6, 2 },
	{ 8, 2, 3, 8, 6, 2, 8, 5, 6, 8, 9, 5 },
	{ 3, 2, 11, 5, 6, 10 },
	{ 8, 2, 11, 8, 0, 2, 5, 6, 10 },
	{ 3, 2, 11, 5, 6, 10, 1, 0, 9 },
	{ 8, 2, 11, 8, 1, 2, 8, 9, 1, 5, 6, 10 },
	{ 3, 6, 11, 3, 5, 6, 3, 1, 5 },
	{ 8, 6, 11, 8, 5, 6, 8, 1, 5, 8, 0, 1 },
	{ 3, 6, 11, 3, 5, 6, 3, 9, 5, 3, 0, 9 },
	{ 8, 6, 11, 8, 5, 6, 8, 9, 5 },
	{ 7, 4, 8, 5, 6, 10 },
	{ 7, 0, 3, 7, 4, 0, 5, 6, 10 },
	{ 7, 4, 8, 5, 6, 10, 1, 0, 9 },
	{ 7, 1, 3, 7, 9, 1, 7, 4, 9, 5, 6, 10 },
	{ 7, 4, 8, 5, 2, 1, 5, 6, 2 },
	{ 7, 0, 3, 7, 4, 0, 5, 2, 1, 5, 6, 2 },
	{ 7, 4, 8, 5, 0, 9, 5, 2, 0, 5, 6, 2 },
	{ 3, 6, 2, 3, 5, 6, 3, 9, 5, 3, 4, 9, 3, 7, 4 },
	{ 7, 4, 8, 3, 2, 11, 5, 6, 10 },
	{ 7, 2, 11, 7, 0, 2, 7, 4, 0, 5, 6, 10 },
	{ 7, 4, 8, 3, 2, 11, 5, 6, 10, 1, 0, 9 },
	{ 7, 2, 11, 7, 1, 2, 7, 9, 1, 7, 4, 9, 5, 6, 10 },
	{ 7, 4, 8, 3, 6, 11, 3, 5, 6, 3, 1, 5 },
	{ 11, 5, 6, 11, 1, 5, 11, 0, 1, 11, 4, 0, 11, 7, 4 },
	{ 7, 4, 8, 3, 6, 11, 3, 5, 6, 3, 9, 5, 3, 0, 9 },
	{ 11, 5, 6, 11, 9, 5, 11, 4, 9, 11, 7, 4 },
	{ 9, 6, 10, 9, 4, 6 },
	{ 8, 0, 3, 9, 6, 10, 9, 4, 6 },
	{ 1, 6, 10, 1, 4, 6, 1, 0, 4 },
	{ 8, 1, 3, 8, 10, 1, 8, 6, 10, 8, 4, 6 },
	{ 9, 2, 1, 9, 6, 2, 9, 4, 6 },
	{ 8, 0, 3, 9, 2, 1, 9, 6, 2, 9, 4, 6 },
	{ 4, 2, 0, 4, 6, 2 },
	{ 8, 2, 3, 8, 6, 2, 8, 4, 6 },
	{ 3, 2, 11, 9, 6, 10, 9, 4, 6 },
	{ 8, 2, 11, 8, 0, 2, 9, 6, 10, 9, 4, 6 },
	{ 3, 2, 11, 1, 6, 10, 1, 4, 6, 1, 0, 4 },
	{ 8, 2, 11, 8, 1, 2, 8, 10, 1, 8, 6, 10, 8, 4, 6 },
	{ 3, 6, 11, 3, 4, 6, 3, 9, 4, 3, 1, 9 },
	{ 11, 4, 6, 11, 9, 4, 11, 1, 9, 11, 0, 1, 11, 8, 0 },
	{ 3, 6, 11, 3, 4, 6, 3, 0, 4 },
	{ 8, 6, 11, 8, 4, 6 },
	{ 7, 9, 8, 7, 10, 9, 7, 6, 10 },
	{ 7, 0, 3, 7, 9, 0, 7, 10, 9, 7, 6, 10 },
	{ 7, 0, 8, 7, 1, 0, 7, 10, 1, 7, 6, 10 },
	{ 7, 1, 3, 7, 10, 1, 7, 6, 10 },
	{ 7, 9, 8, 7, 1, 9, 7, 2, 1, 7, 6, 2 },
	{ 7, 0, 3, 7, 9, 0, 7, 1, 9, 7, 2, 1, 7, 6, 2 },
	{ 7, 0, 8, 7, 2, 0, 7, 6, 2 },
	{ 7, 2, 3, 7, 6, 2 },
	{ 7, 9, 8, 7, 10, 9, 7, 6, 10, 3, 2, 11 },
	{ 7, 2, 11, 7, 0, 2, 7, 9, 0, 7, 10, 9, 7, 6, 10 },
	{ 7, 0, 8, 7, 1, 0, 7, 10, 1, 7, 6, 10, 3, 2, 11 },
	{ 7, 2, 11, 7, 1, 2, 7, 10, 1, 7, 6, 10 },
	{ 9, 3, 1, 9, 11, 3, 9, 6, 11, 9, 7, 6, 9, 8, 7 },
	{ 7, 6, 11, 9, 0, 1 },
	{ 0, 11, 3, 0, 6, 11, 0, 7, 6, 0, 8, 7 },
	{ 7, 6, 11 },
	{ 11, 6, 7 },
	{ 11, 6, 7, 8, 0, 3 },
	{ 11, 6, 7, 1, 0, 9 },
	{ 11, 6, 7, 8, 1, 3, 8, 9, 1 },
	{ 11, 6, 7, 10, 2, 1 },
	{ 11, 6, 7, 8, 0, 3, 10, 2, 1 },
	{ 11, 6, 7, 10, 0, 9, 10, 2, 0 },
	{ 11, 6, 7, 8, 2, 3, 8, 10, 2, 8, 9, 10 },
	{ 3, 6, 7, 3, 2, 6 },
	{ 8, 6, 7, 8, 2, 6, 8, 0, 2 },
	{ 3, 6, 7, 3, 2, 6, 1, 0, 9 },
	{ 8, 6, 7, 8, 2, 6, 8, 1, 2, 8, 9, 1 },
	{ 3, 6, 7, 3, 10, 6, 3, 1, 10 },
	{ 8, 6, 7, 8, 10, 6, 8, 1, 10, 8, 0, 1 },
	{ 3, 6, 7, 3, 10, 6, 3, 9, 10, 3, 0, 9 },
	{ 8, 6, 7, 8, 10, 6, 8, 9, 10 },
	{ 11, 4, 8, 11, 6, 4 },
	{ 11, 0, 3, 11, 4, 0, 11, 6, 4 },
	{ 11, 4, 8, 11, 6, 4, 1, 0, 9 },
	{ 11, 1, 3, 11, 9, 1, 11, 4, 9, 11, 6, 4 },
	{ 11, 4, 8, 11, 6, 4, 10, 2, 1 },
	{ 11, 0, 3, 11, 4, 0, 11, 6, 4, 10, 2, 1 },
	{ 11, 4, 8, 11, 6, 4, 10, 0, 9, 10, 2, 0 },
	{ 3, 10, 2, 3, 9, 10, 3, 4, 9, 3, 6, 4, 3, 11, 6 },
	{ 3, 4, 8, 3, 6, 4, 3, 2, 6 },
	{ 0, 6, 4, 0, 2, 6 },
	{ 3, 4, 8, 3, 6, 4, 3, 2, 6, 1, 0, 9 },
	{ 1, 4, 9, 1, 6, 4, 1, 2, 6 },
	{ 3, 4, 8, 3, 6, 4, 3, 10, 6, 3, 1, 10 },
	{ 10, 0, 1, 10, 4, 0, 10, 6, 4 },
	{ 3, 4, 8, 3, 6, 4, 3, 10, 6, 3, 9, 10, 3, 0, 9 },
	{ 10, 4, 9, 10, 6, 4 },
	{ 11, 6, 7, 9, 4, 5 },
	{ 11, 6, 7, 8, 0, 3, 9, 4, 5 },
	{ 11, 6, 7, 1, 4, 5, 1, 0, 4 },
	{ 11, 6, 7, 8, 1, 3, 8, 5, 1, 8, 4, 5 },
	{ 11, 6, 7, 10, 2, 1, 9, 4, 5 },
	{ 11, 6, 7, 8, 0, 3, 10, 2, 1, 9, 4, 5 },
	{ 11, 6, 7, 10, 4, 5, 10, 0, 4, 10, 2, 0 },
	{ 11, 6, 7, 8, 2, 3, 8, 10, 2, 8, 5, 10, 8, 4, 5 },
	{ 3, 6, 7, 3, 2, 6, 9, 4, 5 },
	{ 8, 6, 7, 8, 2, 6, 8, 0, 2, 9, 4, 5 },
	{ 3, 6, 7, 3, 2, 6, 1, 4, 5, 1, 0, 4 },
	{ 8, 6, 7, 8, 2, 6, 8, 1, 2, 8, 5, 1, 8, 4, 5 },
	{ 3, 6, 7, 3, 10, 6, 3, 1, 10, 9, 4, 5 },
	{ 8, 6, 7, 8, 10, 6, 8, 1, 10, 8, 0, 1, 9, 4, 5 },
	{ 3, 6, 7, 3, 10, 6, 3, 5, 10, 3, 4, 5, 3, 0, 4 },
	{ 8, 6, 7, 8, 10, 6, 8, 5, 10, 8, 4, 5 },
	{ 11, 9, 8, 11, 5, 9, 11, 6, 5 },
	{ 11, 0, 3, 11, 9, 0, 11, 5, 9, 11, 6, 5 },
	{ 11, 0, 8, 11, 1, 0, 11, 5, 1, 11, 6, 5 },
	{ 11, 1, 3, 11, 5, 1, 11, 6, 5 },
	{ 11, 9, 8, 11, 5, 9, 11, 6, 5, 10, 2, 1 },
	{ 11, 0, 3, 11, 9, 0, 11, 5, 9, 11, 6, 5, 10, 2, 1 },
	{ 8, 2, 0, 8, 10, 2, 8, 5, 10, 8, 6, 5, 8, 11, 6 },
	{ 3, 10, 2, 3, 5, 10, 3, 6, 5, 3, 11, 6 },
	{ 3, 9, 8, 3, 5, 9, 3, 6, 5, 3, 2, 6 },
	{ 9, 6, 5, 9, 2, 6, 9, 0, 2 },
	{ 8, 1, 0, 8, 5, 1, 8, 6, 5, 8, 2, 6, 8, 3, 2 },
	{ 1, 6, 5, 1, 2, 6 },
	{ 3, 9, 8, 3, 5, 9, 3, 6, 5, 3, 10, 6, 3, 1, 10 },
	{ 0, 5, 9, 0, 6, 5, 0, 10, 6, 0, 1, 10 },
	{ 3, 0, 8, 10, 6, 5 },
	{ 10, 6, 5 },
	{ 11, 5, 7, 11, 10, 5 },
	{ 11, 5, 7, 11, 10, 5, 8, 0, 3 },
	{ 11, 5, 7, 11, 10, 5, 1, 0, 9 },
	{ 11, 5, 7, 11, 10, 5, 8, 1, 3, 8, 9, 1 },
	{ 11, 5, 7, 11, 1, 5, 11, 2, 1 },
	{ 11, 5, 7, 11, 1, 5, 11, 2, 1, 8, 0, 3 },
	{ 11, 5, 7, 11, 9, 5, 11, 0, 9, 11, 2, 0 },
	{ 5, 8, 9, 5, 3, 8, 5, 2, 3, 5, 11, 2, 5, 7, 11 },
	{ 3, 5, 7, 3, 10, 5, 3, 2, 10 },
	{ 8, 5, 7, 8, 10, 5, 8, 2, 10, 8, 0, 2 },
	{ 3, 5, 7, 3, 10, 5, 3, 2, 10, 1, 0, 9 },
	{ 8, 5, 7, 8, 10, 5, 8, 2, 10, 8, 1, 2, 8, 9, 1 },
	{ 3, 5, 7, 3, 1, 5 },
	{ 8, 5, 7, 8, 1, 5, 8, 0, 1 },
	{ 3, 5, 7, 3, 9, 5, 3, 0, 9 },
	{ 8, 5, 7, 8, 9, 5 },
	{ 11, 4, 8, 11, 5, 4, 11, 10, 5 },
	{ 11, 0, 3, 11, 4, 0, 11, 5, 4, 11, 10, 5 },
	{ 11, 4, 8, 11, 5, 4, 11, 10, 5, 1, 0, 9 },
	{ 11, 1, 3, 11, 9, 1, 11, 4, 9, 11, 5, 4, 11, 10, 5 },
	{ 11, 4, 8, 11, 5, 4, 11, 1, 5, 11, 2, 1 },
	{ 11, 0, 3, 11, 4, 0, 11, 5, 4, 11, 1, 5, 11, 2, 1 },
	{ 11, 4, 8, 11, 5, 4, 11, 9, 5, 11, 0, 9, 11, 2, 0 },
	{ 11, 2, 3, 5, 4, 9 },
	{ 3, 4, 8, 3, 5, 4, 3, 10, 5, 3, 2, 10 },
	{ 5, 2, 10, 5, 0, 2, 5, 4, 0 },
	{ 3, 4, 8, 3, 5, 4, 3, 10, 5, 3, 2, 10, 1, 0, 9 },
	{ 2, 9, 1, 2, 4, 9, 2, 5, 4, 2, 10, 5 },
	{ 3, 4, 8, 3, 5, 4, 3, 1, 5 },
	{ 5, 0, 1, 5, 4, 0 },
	{ 3, 4, 8, 3, 5, 4, 3, 9, 5, 3, 0, 9 },
	{ 5, 4, 9 },
	{ 11, 4, 7, 11, 9, 4, 11, 10, 9 },
	{ 11, 4, 7, 11, 9, 4, 11, 10, 9, 8, 0, 3 },
	{ 11, 4, 7, 11, 0, 4, 11, 1, 0, 11, 10, 1 },
	{ 4, 3, 8, 4, 1, 3, 4, 10, 1, 4, 11, 10, 4, 7, 11 },
	{ 11, 4, 7, 11, 9, 4, 11, 1, 9, 11, 2, 1 },
	{ 11, 4, 7, 11, 9, 4, 11, 1, 9, 11, 2, 1, 8, 0, 3 },
	{ 11, 4, 7, 11, 0, 4, 11, 2, 0 },
	{ 4, 3, 8, 4, 2, 3, 4, 11, 2, 4, 7, 11 },
	{ 3, 4, 7, 3, 9, 4, 3, 10, 9, 3, 2, 10 },
	{ 7, 9, 4, 7, 10, 9, 7, 2, 10, 7, 0, 2, 7, 8, 0 },
	{ 7, 0, 4, 7, 1, 0, 7, 10, 1, 7, 2, 10, 7, 3, 2 },
	{ 8, 4, 7, 1, 2, 10 },
	{ 3, 4, 7, 3, 9, 4, 3, 1, 9 },
	{ 7, 9, 4, 7, 1, 9, 7, 0, 1, 7, 8, 0 },
	{ 3, 4, 7, 3, 0, 4 },
	{ 8, 4, 7 },
	{ 11, 9, 8, 11, 10, 9 },
	{ 11, 0, 3, 11, 9, 0, 11, 10, 9 },
	{ 11, 0, 8, 11, 1, 0, 11, 10, 1 },
	{ 11, 1, 3, 11, 10, 1 },
	{ 11, 9, 8, 11, 1, 9, 11, 2, 1 },
	{ 11, 0, 3, 11, 9, 0, 11, 1, 9, 11, 2, 1 },
	{ 11, 0, 8, 11, 2, 0 },
	{ 11, 2, 3 },
	{ 3, 9, 8, 3, 10, 9, 3, 2, 10 },
	{ 9, 2, 10, 9, 0, 2 },
	{ 8, 1, 0, 8, 10, 1, 8, 2, 10, 8, 3, 2 },
	{ 1, 2, 10 },
	{ 3, 9, 8, 3, 1, 9 },
	{ 9, 0, 1 },
	{ 3, 0, 8 },
	{},
}

--- ReplicatedStorage.FrozenHouse.ToolStats [ModuleScript]
-- y u r i

local str1 = "ClassPerks"
local var1 = require(script.Parent.Config)
local var2 = require(game:GetService("ReplicatedStorage"):WaitForChild("MeltShared"):WaitForChild(str1))
local var3 = var1.Upgrades
str1 = { upgradeTable = function(arg1, arg2)
	local var2 = arg1
	var2 = var2 and var1.ToolById[arg1]
	return var2 and (var2.Upgrades and var2.Upgrades[arg2]) or var3[arg2]
end }

str1.isProduct = function(arg1)
	local var2 = arg1
	var2 = var2 and var1.ToolById[arg1]
	local bool1 = false
	if var2 ~= nil then
		bool1 = var2.Product ~= nil
	end

	return bool1
end

str1.TrackInfo = {
	Battery = {
		Card = "Battery",
		Heading = "Battery Capacity",
		Description = "Use your tool for longer before recharging.",
	},
	Size = { Card = "Size", Heading = "Size", Description = "Melt a wider patch of ice." },
	Power = { Card = "Power", Heading = "Power", Description = "Melt through ice faster." },
}

str1.defaultLevels = function()
	return { Battery = 0, Size = 0, Power = 0 }
end

str1.isTrack = function(arg1)
	local bool2 = true
	if arg1 ~= "Battery" then
		bool2 = true
		if arg1 ~= "Size" then
			bool2 = arg1 == "Power"
		end
	end

	return bool2
end

str1.clampLevel = function(arg1)
	if typeof(arg1) ~= "number" or arg1 ~= arg1 then
		return 0
	end

	return (math.clamp(math.floor(arg1), 0, var3.MaxLevel))
end

local var4 = str1.upgradeTable
local var5 = var1.Battery
str1.capacity = function(arg1, arg2, arg3)
	local var1 = arg1
	local var3 = var2.capacity(var4(arg3, "BatteryCapacity")[str1.clampLevel(var1 and arg1.Battery)], arg2)
	return (var3 + var5.DrainPerSecond * var2.permanentBatterySeconds(arg2)) * var2.batteryBoost(arg2)
end

str1.rechargeRate = function(arg1)
	return arg1 / var5.FullRechargeSeconds
end

str1.useSeconds = function(arg1)
	return arg1 / var5.DrainPerSecond
end

local tbl1 = {}
str1.effective = function(arg1, arg2, arg3)
	local var5 = var1.ToolById[arg1]
	if not var5 then
		return nil
	end

	local var6 = arg2
	local var7 = str1.clampLevel(var6 and arg2.Battery)
	local var8 = arg2
	var6 = str1.clampLevel(var8 and arg2.Size)
	local var9 = arg2
	var8 = str1.clampLevel(var9 and arg2.Power)
	local var10 = arg1
	local var11 = var7 * 36 + var6 * 6 + var8
	var9 = var10 .. var11 .. (if arg3 then "|" .. arg3.key else "")
	var10 = tbl1[var9]
	if not var10 then
		var11 = var4(arg1, "SizeMultiplier")[var6]
		local var12 = var4(arg1, "PowerMultiplier")[var8]
		local var13 = 1 + var2.toolPowerBonus(arg1, arg3)
		local tbl2 = {
			Id = var5.Id,
			Name = var5.Name,
			Index = var5.Index,
			Radius = var5.Radius * var11,
			HeatRate = var5.HeatRate * var12 * var13,
			MaxExcavation = var5.MaxExcavation * var12 * var11 * var11 * var13,
			Range = var5.Range,
			Capacity = var2.capacity(var4(arg1, "BatteryCapacity")[var7], arg3) * var2.batteryBoost(arg3),
		}

		tbl2.ClassPower = var13
		tbl2.Levels = { Battery = var7, Size = var6, Power = var8 }
		var10 = tbl2
		tbl1[var9] = var10
	end

	return var10
end

str1.withTechnician = function(arg1, arg2)
	if arg2 <= 0 then
		return arg1
	end

	local var1 = table.clone(arg1)
	var1.HeatRate = arg1.HeatRate * (arg2 + 1)
	var1.MaxExcavation = arg1.MaxExcavation * (arg2 + 1)
	var1.TechnicianBonus = arg2
	return var1
end

str1.clearCache = function()
	table.clear(tbl1)
end

str1.price = function(arg1, arg2, arg3, arg4)
	local var1 = var3.Prices[arg1]
	local var4 = var1
	var4 = var4 and var1[arg2]
	if not var4 or var3.MaxLevel < arg3 + 1 then
		return nil
	end

	local var5 = var4[arg3 + 1]
	local var6 = arg4
	return var2.upgradePrice(var5, var6)
end

str1.toolPrice = function(arg1, arg2)
	local var4 = var1.ToolById[arg1]
	if not var4 then
		return 0
	end

	local var5 = arg1
	local var6 = var4.Price
	local var7 = arg2
	return var2.toolPrice(var5, var6, var7)
end

str1.trackValue = function(arg1, arg2, arg3, arg4)
	local var5 = var1.ToolById[arg1]
	if arg2 == "Battery" then
		local var6 = var2.capacity(var4(arg1, "BatteryCapacity")[arg3], arg4) * var2.batteryBoost(arg4)
		return str1.useSeconds(var6)
	end

	if arg2 == "Size" then
		return var5.Radius * 2 * var4(arg1, "SizeMultiplier")[arg3]
	end

	return var4(arg1, "PowerMultiplier")[arg3] * (1 + var2.toolPowerBonus(arg1, arg4)) * 100
end

local function formatValue(arg1, arg2)
	if arg1 == "Battery" then
		local var1 = math.floor(arg2 * 10 + 0.5) / 10
		if var1 % 1 == 0 then
			return (string.format("%ds", var1))
		end

		return (string.format("%.1fs", var1))
	end

	if arg1 == "Size" then
		local str2 = "%.1f"
		local var3 = arg2
		return string.format(str2, var3)
	end

	local str3 = "%d%%"
	local var4 = math.floor(arg2 + 0.5)
	return string.format(str3, var4)
end

local tbl2 = { Battery = " of use", Size = " studs wide", Power = " power" }
str1.compare = function(arg1, arg2, arg3, arg4)
	local var1 = arg1
	local var2 = arg2
	local var4 = arg3
	local var6 = arg4
	local var7 = formatValue(arg2, str1.trackValue(var1, var2, var4, var6))
	local var8 = arg2 == "Battery" and string.format("Full recharge: %ds", var5.FullRechargeSeconds) or nil
	if var3.MaxLevel <= arg3 then
		local tbl1 = { levels = string.format("Level %d (max)", arg3) }
		tbl1.value = var7 .. tbl2[arg2]
		tbl1.extra = var8
		return tbl1
	end

	var4 = arg1
	var6 = arg2
	local var9 = arg3 + 1
	local var10 = arg4
	local var11 = formatValue(arg2, str1.trackValue(var4, var6, var9, var10))
	var1 = { levels = string.format("Level %d \226\134\146 Level %d", arg3, arg3 + 1) }
	var1.value = var7 .. " \226\134\146 " .. var11 .. tbl2[arg2]
	var1.extra = var8
	return var1
end

str1.totalCost = function()
	local num1 = 0
	local num2 = 0
	for k1, v1 in ipairs(var1.Tools) do
		if v1.Product then
			continue
		end

		num2 = num2 + v1.Price
		for k2, v2 in ipairs(var3.Tracks) do
			for i1 = 1, var3.MaxLevel do
				num1 = num1 + var3.Prices[v1.Id][v2][i1]
			end
		end
	end

	return num1, num1 + num2
end

str1.encodeLevels = function(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(var1.Tools) do
		local var2 = arg1[v1.Id]
		if not var2 then
			continue
		end

		if not var2.owned then
			continue
		end

		local var3 = var2.levels
		local str1 = "%s=%d.%d.%d"
		local var4 = v1.Id
		local var5 = var3.Battery
		local var6 = var3.Size
		local var7 = var3.Power
		table.insert(tbl1, string.format(str1, var4, var5, var6, var7))
	end

	local var8 = tbl1
	local str2 = ";"
	return table.concat(var8, str2)
end

str1.decodeLevels = function(arg1)
	local tbl1 = {}
	if typeof(arg1) ~= "string" then
		return tbl1
	end

	for k1, v1, v2, v3 in string.gmatch(arg1, "([%w_]+)=(%d+)%.(%d+)%.(%d+)") do
		if not var1.ToolById[k1] then
			continue
		end

		local tbl2 = { Battery = str1.clampLevel((tonumber(v1))) }
		tbl2.Size = str1.clampLevel((tonumber(v2)))
		tbl2.Power = str1.clampLevel((tonumber(v3)))
		tbl1[k1] = tbl2
	end

	return tbl1
end

str1.encodeBattery = function(arg1, arg2, arg3, arg4, arg5)
	local str1 = "%s|%.3f|%.2f|%s|%.3f"
	local var1 = arg1
	local var2 = arg2
	local var3 = arg3
	local var4 = arg4
	local var5 = arg5
	return string.format(str1, var1, var2, var3, var4, var5)
end

str1.decodeBattery = function(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	local var6, var7, var8, var9, var10 = string.match(arg1, "^([%w_]+)|([%d%.]+)|([%d%.]+)|(%a+)|([%d%.]+)$")
	if not var6 then
		return nil
	end

	local tbl1 = { toolId = var6, energy = tonumber(var7) }
	tbl1.capacity = tonumber(var8)
	tbl1.mode = var9
	tbl1.at = tonumber(var10)
	return tbl1
end

str1.batteryAt = function(arg1, arg2)
	local var2 = math.max(0, arg2 - arg1.at)
	if arg1.mode == "run" then
		return (math.max(0, arg1.energy - var5.DrainPerSecond * var2))
	end

	if arg1.mode == "charge" then
		return (math.min(arg1.capacity, arg1.energy + str1.rechargeRate(arg1.capacity) * var2))
	end

	return arg1.energy
end

return str1

--- ReplicatedStorage.FrozenHouse.FreezerStatus [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Config)
local tbl1 = { Text = var1.Text.StatusCold, Lit = Color3.fromHex("#2F72B0") }
tbl1.Ink = Color3.fromHex("#FFFFFF")
local tbl2 = { Cold = tbl1 }
tbl1 = { Text = var1.Text.StatusNormal, Lit = Color3.fromHex("#F0A63A") }
tbl1.Ink = Color3.fromHex("#253746")
tbl2.Normal = tbl1
local tbl3 = { Rows = tbl2 }
tbl2 = Color3.fromHex("#36404B")
tbl1 = Color3.fromHex("#7F8B97")
tbl3.paint = function(arg1, arg2)
	for k1, v1 in pairs(tbl3.Rows) do
		local var1 = arg1:FindFirstChild(k1, true)
		if not var1 then
			continue
		end

		if not var1:IsA("GuiObject") then
			continue
		end

		local var2 = if k1 == "Cold" then 1 - arg2 else arg2
		var1.BackgroundColor3 = tbl2:Lerp(v1.Lit, var2)
		for k2, v2 in ipairs(var1:GetDescendants()) do
			if v2:IsA("TextLabel") then
				v2.TextColor3 = tbl1:Lerp(v1.Ink, var2)
			else
				if not v2:IsA("Frame") then
					continue
				end

				if v2.Name ~= "Ink" then
					continue
				end

				v2.BackgroundColor3 = tbl1:Lerp(v1.Ink, var2)
			end
		end
	end
end

tbl3.pointerPivot = function(arg1, arg2)
	local var1 = arg1:GetAttribute("BasePivot")
	local var2 = arg1:GetAttribute("Drop")
	if typeof(var1) ~= "CFrame" or typeof(var2) ~= "number" then
		return nil
	end

	return var1 * CFrame.new(0, -var2 * arg2, 0)
end

return tbl3

--- ReplicatedStorage.FrozenHouse.IceShading [ModuleScript]
-- y u r i

local var1 = require(script.Parent.IceGrid)
local tbl1 = {}
tbl1.__index = tbl1
local var2 = var1.ISO
local var3 = var1.BLOCKED
local var4 = buffer.readu8
local var5 = buffer.readu16
local var6 = buffer.writeu8
local var7 = bit32.band
local tbl2 = { 32, 45, 55 }
local tbl3 = {}
for i1 = -1, 0 do
	for i2 = -1, 1 do
		for i3 = -1, 1 do
			if i1 < 0 or i1 == 0 and (i2 < 0 or i2 == 0 and i3 < 0) then
				table.insert(tbl3, { i3, i2, i1, tbl2[math.abs(i3) + math.abs(i2) + math.abs(i1)] })
			end
		end
	end
end

local tbl4 = {}
for i4 = -1, 1 do
	for i5 = -1, 1 do
		for i6 = -1, 1 do
			if i6 ~= 0 or (i5 ~= 0 or i4 ~= 0) then
				table.insert(tbl4, { i6, i5, i4 })
			end
		end
	end
end

local tbl5 = { -2, 0, 0 }
for k1, v1 in ipairs({ { 2, 0, 0 }, tbl5, { 0, 2, 0 }, { 0, -2, 0 }, { 0, 0, 2 }, { 0, 0, -2 } }) do
	table.insert(tbl4, v1)
end

local num1 = 2
for k2, v2 in ipairs({ -2, num1 }) do
	local num2 = 2
	for k3, v3 in ipairs({ -2, num2 }) do
		local num3 = 2
		for k4, v4 in ipairs({ -2, num3 }) do
			table.insert(tbl4, { v2, v3, v4 })
		end
	end
end

local function transform(arg1, arg2, arg3, arg4)
	local var1 = arg1.nx
	local var2 = arg1.ny
	local var3 = arg1.nz
	local var5 = var1 * var2
	for i1 = 0, arg1.count - 1 do
		var6(arg2, i1, if arg4(i1) then 0 else arg3)
	end

	for i2 = 1, 2 do
		local var7 = if i2 == 1 then 1 else -1
		local tbl1 = {}
		local tbl2 = {}
		local tbl4 = {}
		local tbl5 = {}
		local tbl6 = {}
		for k1, v1 in ipairs(tbl3) do
			tbl2[k1] = v1[1] * var7
			tbl4[k1] = v1[2] * var7
			tbl5[k1] = v1[3] * var7
			tbl6[k1] = v1[4]
			tbl1[k1] = tbl2[k1] + var1 * tbl4[k1] + var5 * tbl5[k1]
		end

		local var8 = if i2 == 1 then 0 else var3 - 1
		local var9 = if i2 == 1 then var3 - 1 else 0
		local var10 = if i2 == 1 then 0 else var2 - 1
		local var11 = if i2 == 1 then var2 - 1 else 0
		local var12 = if i2 == 1 then 0 else var1 - 1
		for i3 = var8, var9, var7 do
			for i4 = var10, var11, var7 do
				local var13 = if i2 == 1 then var1 - 1 else 0
				for i5 = var12, var13, var7 do
					local var14 = var1 * (i4 + var2 * i3)
					local var15 = i5 + var14
					local var16 = var4(arg2, var15)
					if 0 >= var16 then
						continue
					end

					local bool2 = false
					if 0 < i5 then
						bool2 = false
						if 0 < i4 then
							bool2 = false
							if 0 < i3 then
								bool2 = false
								if i5 < var1 - 1 then
									bool2 = false
									if i4 < var2 - 1 then
										bool2 = i3 < var3 - 1
									end
								end
							end
						end
					end

					for i6 = 1, 13 do
						local var20 = i5 + tbl2[i6]
						local var21 = i4 + tbl4[i6]
						local var22 = i3 + tbl5[i6]
						local var23 = var4(arg2, var15 + tbl1[i6]) + tbl6[i6]
						if (bool2 or 0 <= var20 and (0 <= var21 and (0 <= var22 and (var20 < var1 and (var21 < var2 and var22 < var3))))) and var23 < var16 then
							var16 = var23
						end
					end

					var6(arg2, var15, var16)
				end
			end
		end
	end
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	var1.grid = arg1
	var1.occCache = {}
	var1.glows = {}
	var1.stencilDelta = {}
	local var6 = arg1.nx
	local var8 = arg1.ny
	for k1, v1 in ipairs(tbl4) do
		var1.stencilDelta[k1] = v1[1] + var6 * v1[2] + var6 * var8 * v1[3]
	end

	var1.carve = buffer.create(arg1.count)
	local var9 = arg1.flags
	local var10 = arg1.density
	transform(arg1, var1.carve, 192, function(arg1)
		local bool1 = false
		if var7(var4(var9, arg1), var3) == 0 then
			bool1 = var5(var10, arg1 * 2) < var2
		end

		return bool1
	end)

	var1:setLook(arg2)
	return var1
end

tbl1.setLook = function(arg1, arg2)
	arg1.look = arg2
	arg1.er = arg2.Edge.R
	arg1.eg = arg2.Edge.G
	arg1.eb = arg2.Edge.B
	arg1.fr = arg2.Face.R
	arg1.fg = arg2.Face.G
	arg1.fb = arg2.Face.B
	arg1.mr = arg2.Main.R
	arg1.mg = arg2.Main.G
	arg1.mb = arg2.Main.B
	arg1.dr = arg2.Deep.R
	arg1.dg = arg2.Deep.G
	arg1.db = arg2.Deep.B
	arg1.sr = arg2.FrostColor.R
	arg1.sg = arg2.FrostColor.G
	arg1.sb = arg2.FrostColor.B
end

tbl1.setGlows = function(arg1, arg2)
	table.clear(arg1.glows)
	for k1, v1 in ipairs(arg2) do
		table.insert(arg1.glows, {
			x = v1.position.X,
			y = v1.position.Y,
			z = v1.position.Z,
			radius = v1.radius,
			r2 = v1.radius * v1.radius,
			strength = v1.strength,
			cr = v1.color.R,
			cg = v1.color.G,
			cb = v1.color.B,
		})

	end
end

tbl1.beginChunk = function(arg1)
	table.clear(arg1.occCache)
end

tbl1._occlusionAt = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.grid
	local var2 = var1.ny
	local var6 = var1.nx
	local var8 = arg2 + var6 * (arg3 + var2 * arg4)
	local var10 = arg1.occCache[var8]
	local var11 = var1.nz
	if var10 then
		return var10
	end

	local var12 = var1.density
	local var13 = var1.flags
	local bool2 = false
	if 2 <= arg2 then
		bool2 = false
		if 2 <= arg3 then
			bool2 = false
			if 2 <= arg4 then
				bool2 = false
				if arg2 < var6 - 2 then
					bool2 = false
					if arg3 < var2 - 2 then
						bool2 = arg4 < var11 - 2
					end
				end
			end
		end
	end

	local var14 = arg1.stencilDelta
	local num1 = 0
	for i1 = 1, #tbl4 do
		local num3 = -1
		if bool2 then
			num3 = var8 + var14[i1]
		else
			local var15 = tbl4[i1]
			local var19 = arg2 + var15[1]
			local var20 = arg3 + var15[2]
			local var21 = arg4 + var15[3]
			if 0 <= var19 and (0 <= var20 and (0 <= var21 and (var19 < var6 and (var20 < var2 and var21 < var11)))) then
				num3 = var19 + var6 * (var20 + var2 * var21)
			end
		end

		if 0 > num3 then
			continue
		end

		if var7(var4(var13, num3), var3) ~= 0 then
			num1 = num1 + 1
		else
			local var23 = var5(var12, num3 * 2)
			if 49152 <= var23 then
				num1 = num1 + 1
			else
				if 16384 >= var23 then
					continue
				end

				num1 = num1 + (var23 - 16384) / 32768
			end
		end
	end

	local var24 = num1 / #tbl4
	arg1.occCache[var8] = var24
	return var24
end

tbl1.occlusion = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.grid
	arg2 = math.clamp(arg2, 0, var1.nx - 1.000001)
	arg3 = math.clamp(arg3, 0, var1.ny - 1.000001)
	arg4 = math.clamp(arg4, 0, var1.nz - 1.000001)
	local var2 = math.floor(arg2)
	local var3 = math.floor(arg3)
	local var4 = math.floor(arg4)
	local num1 = 0
	for i1 = 0, 1 do
		local var6 = arg2 - var2
		local var7 = arg3 - var3
		local var8 = arg4 - var4
		local var9 = if i1 == 1 then var8 else 1 - var8
		if 1e-06 >= var9 then
			continue
		end

		for i2 = 0, 1 do
			local var10 = if i2 == 1 then var7 else 1 - var7
			if 1e-06 >= var10 then
				continue
			end

			for i3 = 0, 1 do
				local var11 = (if i3 == 1 then var6 else 1 - var6) * var10 * var9
				if 1e-06 >= var11 then
					continue
				end

				num1 = num1 + var11 * arg1:_occlusionAt(var2 + i3, var3 + i2, var4 + i1)
			end
		end
	end

	return num1
end

local function sampleDistance(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.nx
	local var2 = arg1.ny
	arg3 = math.clamp(arg3, 0, var1 - 1.000001)
	arg4 = math.clamp(arg4, 0, var2 - 1.000001)
	arg5 = math.clamp(arg5, 0, arg1.nz - 1.000001)
	local var3 = math.floor(arg3)
	local var5 = math.floor(arg4)
	local var6 = math.floor(arg5)
	local var7 = var1 * var2
	local var8 = var3 + var1 * var5 + var7 * var6
	local var9 = var4(arg2, var8)
	local var10 = arg3 - var3
	local var11 = var4(arg2, var8 + var1)
	local var12 = var4(arg2, var8 + var7)
	local var13 = var4(arg2, var8 + var7 + var1)
	local var14 = var9 + (var4(arg2, var8 + 1) - var9) * var10
	local var15 = arg4 - var5
	local var16 = var12 + (var4(arg2, var8 + var7 + 1) - var12) * var10
	local var17 = var14 + (var11 + (var4(arg2, var8 + var1 + 1) - var11) * var10 - var14) * var15
	return (var17 + (var16 + (var13 + (var4(arg2, var8 + var7 + var1 + 1) - var13) * var10 - var16) * var15 - var17) * (arg5 - var6)) / 32
end

tbl1.carveDepth = function(arg1, arg2, arg3, arg4)
	return sampleDistance(arg1.grid, arg1.carve, arg2, arg3, arg4) * arg1.grid.spacing
end

tbl1.vertex = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.grid
	local var2 = var1.origin
	local var3 = var1.spacing
	local var4 = arg1.look
	local var5 = var2.X + arg2 * var3
	local var6 = var4.BodyNoiseStuds
	local var7 = var2.Y + arg3 * var3
	local var8 = var2.Z + arg4 * var3
	local var9 = math.clamp(var4.BodyMain + (math.noise(var5 / var6 + 3.3, var7 / var6 + 1.1, var8 / var6 + 7.7) + 0.35 * math.noise(var5 / 5.3 + 9.1, var7 / 5.3, var8 / 5.3 + 2.3)) * var4.BodyNoise, 0, 1)
	local var10 = math.clamp((arg1:carveDepth(arg2, arg3, arg4) - var4.CarveStart) / (var4.CarveFull - var4.CarveStart), 0, 1)
	local var11 = var10 * var10 * (3 - var10 * 2)
	local var12 = arg1.fr + (arg1.mr - arg1.fr) * var9
	var10 = var11 * var4.CarvedRich
	local var13 = arg1.fg + (arg1.mg - arg1.fg) * var9
	local var14 = arg1.fb + (arg1.mb - arg1.fb) * var9
	local var15 = arg1:occlusion(arg2, arg3, arg4)
	var12 = var12 + (arg1.mr - var12) * var10
	local var16 = math.clamp((var15 - 0.5) * var4.CreaseDeep, 0, var4.CreaseMax)
	var13 = var13 + (arg1.mg - var13) * var10
	var14 = var14 + (arg1.mb - var14) * var10
	var12 = var12 + (arg1.dr - var12) * var16
	local var17 = math.clamp((0.5 - var15) * var4.RimEdge, 0, var4.RimMax)
	var13 = var13 + (arg1.dg - var13) * var16
	var14 = var14 + (arg1.db - var14) * var16
	local var18 = var4.FrostUp
	var12 = var12 + (arg1.er - var12) * var17
	local var19 = math.clamp((var4.FrostAmount + var18 * math.max(arg5, 0)) * (1 - var11), 0, 1)
	var13 = var13 + (arg1.eg - var13) * var17
	var14 = var14 + (arg1.eb - var14) * var17
	var12 = var12 + (arg1.sr - var12) * var19
	var13 = var13 + (arg1.sg - var13) * var19
	var14 = var14 + (arg1.sb - var14) * var19
	for k1, v1 in ipairs(arg1.glows) do
		local var20 = var5 - v1.x
		local var21 = var7 - v1.y
		local var22 = var8 - v1.z
		local var23 = var20 * var20 + var21 * var21 + var22 * var22
		if var23 >= v1.r2 then
			continue
		end

		local var24 = v1.strength * (1 - math.sqrt(var23) / v1.radius)
		var12 = var12 + (v1.cr - var12) * var24
		var13 = var13 + (v1.cg - var13) * var24
		var14 = var14 + (v1.cb - var14) * var24
	end

	return var12, var13, var14
end

return tbl1

--- ReplicatedStorage.FrozenHouse.GrenadeFlight [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Config).Grenade
local tbl1 = {
	STEP = 0.016666666666666666,
	finite = function(arg1)
		if typeof(arg1) ~= "Vector3" then
			return false
		end

		local var1 = arg1.Y
		for k1, v1 in ipairs({ arg1.X, var1, arg1.Z }) do
			if v1 ~= v1 or 100000 < math.abs(v1) then
				return false
			end
		end

		return true
	end,
	velocity = function(arg1)
		return arg1 * var1.ThrowSpeed + Vector3.new(0, var1.ThrowSpeed * var1.UpBias, 0)
	end,
}

tbl1.simulate = function(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg4
	local var3 = 1 / var1.SampleHz
	var2 = var2 or var1.FuseSeconds
	local var4 = tbl1.STEP
	local var5 = arg1
	local var6 = arg2
	local tbl2 = { arg1 }
	local num1 = 0
	local var7 = var3
	local num2 = 0
	local var8 = nil
	local var9 = nil
	while true do
		if num1 >= var2 - 1e-09 then
			break
		end

		var6 = var6 + Vector3.new(0, -var1.Gravity * var4, 0)
		local var10 = var5 + var6 * var4
		local var15 = arg3(var5, var10)
		if var15 then
			local var16 = var9
			var9 = var16 or var15.position
			var16 = var15.normal
			local var19 = var6:Dot(var16)
			var5 = var15.position + var16 * 0.02
			if var19 < 0 then
				local var20 = var16 * var19
				var6 = (var6 - var20) * (1 - var1.Friction) - var20 * var1.Restitution
			end

			num2 = num2 + 1
			if arg5 or (0.6 < var16.Y and var6.Magnitude < var1.RestSpeed or var1.MaxBounces <= num2) then
				var8 = num1 + var4
			end
		else
			var5 = var10
			if var5.Y < var1.MinY then
				var8 = num1 + var4
			end
		end

		num1 = num1 + var4
		if var8 then
			table.insert(tbl2, var5)
			break
		end

		while var7 - 1e-09 <= num1 do
			table.insert(tbl2, var5)
			var7 = var7 + var3
		end
	end

	return { points = tbl2, final = var5, restedAt = var8, bounces = num2, firstHit = var9 }
end

tbl1.positionAt = function(arg1, arg2)
	local var2 = math.max(0, arg2) * var1.SampleHz
	local var4 = math.floor(var2)
	if #arg1 - 1 <= var4 then
		return arg1[#arg1]
	end

	local var5 = arg1[var4 + 2]
	local var6 = var2 - var4
	return arg1[var4 + 1]:Lerp(var5, var6)
end

return tbl1

--- ReplicatedStorage.MeltShared.ClassIcons [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local function frame(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
	local var1 = Instance.new("Frame")
	var1.Name = arg2
	var1.BorderSizePixel = 0
	var1.BackgroundColor3 = arg3
	var1.BackgroundTransparency = arg10 or 0
	var1.AnchorPoint = Vector2.new(0.5, 0.5)
	var1.Position = UDim2.fromScale(arg4, arg5)
	var1.Size = UDim2.fromScale(arg6, arg7)
	var1.Rotation = arg9 or 0
	if arg8 and 0 < arg8 then
		local var2 = Instance.new("UICorner")
		var2.CornerRadius = UDim.new(arg8, 0)
		var2.Parent = var1
	end

	var1.Parent = arg1
	return var1
end

local var2 = var1("#16344B")
local var3 = var1("#8FA3B3")
local var4 = Color3.new(1, 1, 1)
local var5 = var1("#C9D6E0")
local var6 = var1("#DDF4FB")
local var7 = require(script.Parent.Classes)
local var8 = var1("#102F49")
local var9 = var1("#A9DDF0")
local var10 = var1("#6FC3E3")
local var11 = var1("#FFC845")
local var12 = var1("#FFE08A")
local var13 = var1("#D9951E")
local var14 = var1("#FFD23F")
local var15 = var1("#FF9A4D")
local var16 = var1("#FFD2A1")
local var17 = var1("#FFC48A")
local var18 = var1("#FF7A59")
local var19 = var1("#FFF0D6")
local var20 = var1("#EFDDBF")
local var21 = var1("#F7A541")
local var22 = var1("#3A434C")
local var23 = var1("#3FA39A")
local var24 = var1("#2E7E79")
local var25 = var1("#24466B")
local var26 = var1("#C9773E")
local function render(arg1, arg2)
	for k1, v1 in ipairs(arg2) do
		for k2, v2 in ipairs(v1) do
			if v2.bare then
				continue
			end

			local var1 = math.min(v2.w, v2.h)
			frame(arg1, "Outline", var2, v2.x, v2.y, v2.w + 0.068, v2.h + 0.068, ((v2.r or 0) * var1 + 0.034) / (var1 + 0.068), v2.rot)
		end

		for k3, v3 in ipairs(v1) do
			frame(arg1, "Shape", v3.color, v3.x, v3.y, v3.w, v3.h, v3.r, v3.rot, v3.alpha)
		end
	end
end

local function applyProps(arg1, arg2, arg3)
	if not arg2 then
		return
	end

	for k1, v1 in pairs(arg2) do
		if k1 == "Parent" then
			continue
		end

		if arg3[k1] then
			continue
		end

		arg1[k1] = v1
	end

	local var1 = arg1.ZIndex
	for k2, v2 in ipairs(arg1:GetDescendants()) do
		if not v2:IsA("GuiObject") then
			continue
		end

		v2.ZIndex = var1
	end

	if arg2.Parent then
		arg1.Parent = arg2.Parent
	end
end

local function badgeColors(arg1)
	if arg1.Id == "Godly" then
		return var13, var1("#2A5A80"), var8
	end

	local var2 = var8
	local num1 = 0.1
	return arg1.Color:Lerp(var8, 0.4), arg1.Color:Lerp(var4, 0.28), arg1.Color:Lerp(var2, num1)
end

local tbl1 = {
	Starter = function()
		return {
			{
				{ color = var3, x = 0.4, y = 0.66, w = 0.15, h = 0.34, r = 0.45, rot = -10, alpha = nil },
				{ color = var4, x = 0.24, y = 0.42, w = 0.32, h = 0.32, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.48, y = 0.42, w = 0.5, h = 0.26, r = 0.5, rot = nil, alpha = nil },
				{ color = var5, x = 0.76, y = 0.42, w = 0.12, h = 0.2, r = 0.3, rot = nil, alpha = nil },
			},
			{
				{
					color = var5,
					x = 0.24,
					y = 0.42,
					w = 0.15,
					h = 0.15,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var5,
					x = 0.5,
					y = 0.35,
					w = 0.28,
					h = 0.045,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
			},
			{ { color = var6, x = 0.76, y = 0.77, w = 0.2, h = 0.2, r = 0.15, rot = 45, alpha = nil } },
			{ {
				color = var4,
				x = 0.735,
				y = 0.735,
				w = 0.06,
				h = 0.06,
				r = 0.2,
				rot = 45,
				alpha = nil,
				bare = true,
			} },
		}
	end,
	Powerbank = function(arg1)
		local var1 = arg1.Color:Lerp(var8, 0.25)
		local tbl1 = { color = var1, x = 0.5, y = 0.58, w = 0.38, h = 0.56, r = 0.14, rot = nil, alpha = nil }
		tbl1.bare = true
		local tbl2 = { tbl1 }
		return {
			{
				{ color = var5, x = 0.5, y = 0.15, w = 0.24, h = 0.12, r = 0.3, rot = nil, alpha = nil },
				{ color = var4, x = 0.5, y = 0.56, w = 0.54, h = 0.72, r = 0.2, rot = nil, alpha = nil },
			},
			tbl2,
			{
				{ color = var14, x = 0.555, y = 0.43, w = 0.13, h = 0.3, r = 0.2, rot = 22, alpha = nil },
				{ color = var14, x = 0.5, y = 0.57, w = 0.3, h = 0.1, r = 0.3, rot = nil, alpha = nil },
				{ color = var14, x = 0.445, y = 0.71, w = 0.13, h = 0.3, r = 0.2, rot = 22, alpha = nil },
			},
		}
	end,
	NoviceCollector = function()
		return {
			{ { color = var11, x = 0.5, y = 0.42, w = 0.54, h = 0.54, r = 0.5, rot = 0, alpha = nil } },
			{
				{
					color = var13,
					x = 0.5,
					y = 0.42,
					w = 0.38,
					h = 0.38,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var11,
					x = 0.5,
					y = 0.425,
					w = 0.32,
					h = 0.32,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var4,
					x = 0.37,
					y = 0.3,
					w = 0.07,
					h = 0.13,
					r = 0.5,
					rot = 35,
					alpha = 0.25,
					bare = true,
				},
			},
			{
				{ color = var6, x = 0.5, y = 0.76, w = 0.84, h = 0.34, r = 0.2, rot = nil, alpha = nil },
				{ color = var6, x = 0.18, y = 0.6, w = 0.14, h = 0.14, r = 0.12, rot = 45, alpha = nil },
				{ color = var6, x = 0.84, y = 0.62, w = 0.11, h = 0.11, r = 0.12, rot = 45, alpha = nil },
			},
			{
				{
					color = var4,
					x = 0.46,
					y = 0.65,
					w = 0.6,
					h = 0.05,
					r = 0.5,
					rot = 0,
					alpha = 0.2,
					bare = true,
				},
				{
					color = var9,
					x = 0.3,
					y = 0.8,
					w = 0.16,
					h = 0.05,
					r = 0.5,
					rot = -18,
					alpha = nil,
					bare = true,
				},
				{
					color = var9,
					x = 0.66,
					y = 0.85,
					w = 0.12,
					h = 0.05,
					r = 0.5,
					rot = 14,
					alpha = nil,
					bare = true,
				},
			},
		}
	end,
	HairStylist = function()
		return {
			{
				{
					color = var22,
					x = 0.34,
					y = 0.66,
					w = 0.15,
					h = 0.34,
					r = 0.45,
					rot = -10,
					alpha = nil,
				},
				{ color = var21, x = 0.16, y = 0.4, w = 0.3, h = 0.3, r = 0.5, rot = 0, alpha = nil },
				{ color = var19, x = 0.4, y = 0.4, w = 0.46, h = 0.3, r = 0.5, rot = nil, alpha = nil },
				{ color = var20, x = 0.65, y = 0.4, w = 0.14, h = 0.2, r = 0.25, rot = nil, alpha = nil },
				{ color = var21, x = 0.73, y = 0.4, w = 0.06, h = 0.25, r = 0.3, rot = nil, alpha = nil },
			},
			{
				{
					color = var22,
					x = 0.16,
					y = 0.4,
					w = 0.16,
					h = 0.16,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var19,
					x = 0.16,
					y = 0.4,
					w = 0.06,
					h = 0.06,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var21,
					x = 0.345,
					y = 0.74,
					w = 0.16,
					h = 0.06,
					r = 0.3,
					rot = -10,
					alpha = nil,
					bare = true,
				},
				{
					color = var4,
					x = 0.42,
					y = 0.31,
					w = 0.26,
					h = 0.045,
					r = 0.5,
					rot = 0,
					alpha = 0.2,
					bare = true,
				},
			},
			{
				{
					color = var15,
					x = 0.89,
					y = 0.26,
					w = 0.11,
					h = 0.055,
					r = 0.5,
					rot = -22,
					alpha = nil,
				},
				{ color = var15, x = 0.92, y = 0.4, w = 0.12, h = 0.055, r = 0.5, rot = nil, alpha = nil },
				{ color = var15, x = 0.89, y = 0.54, w = 0.11, h = 0.055, r = 0.5, rot = 22, alpha = nil },
			},
		}
	end,
	SteamSpecialist = function()
		return {
			{
				{ color = var25, x = 0.3, y = 0.84, w = 0.13, h = 0.2, r = 0.3, rot = nil, alpha = nil },
				{ color = var23, x = 0.4, y = 0.72, w = 0.56, h = 0.16, r = 0.4, rot = nil, alpha = nil },
				{ color = var19, x = 0.36, y = 0.56, w = 0.48, h = 0.26, r = 0.5, rot = nil, alpha = nil },
				{ color = var24, x = 0.7, y = 0.62, w = 0.16, h = 0.26, r = 0.2, rot = nil, alpha = nil },
				{ color = var19, x = 0.79, y = 0.62, w = 0.06, h = 0.32, r = 0.3, rot = nil, alpha = nil },
			},
			{
				{
					color = var26,
					x = 0.27,
					y = 0.56,
					w = 0.05,
					h = 0.26,
					r = 0.3,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var26,
					x = 0.46,
					y = 0.56,
					w = 0.05,
					h = 0.26,
					r = 0.3,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var4,
					x = 0.36,
					y = 0.48,
					w = 0.3,
					h = 0.04,
					r = 0.5,
					rot = 0,
					alpha = 0.25,
					bare = true,
				},
			},
			{
				{ color = var4, x = 0.87, y = 0.44, w = 0.15, h = 0.15, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.76, y = 0.3, w = 0.19, h = 0.19, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.87, y = 0.15, w = 0.14, h = 0.14, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.62, y = 0.17, w = 0.11, h = 0.11, r = 0.5, rot = 0, alpha = nil },
			},
		}
	end,
	Technician = function(arg1)
		local var1 = arg1.Color:Lerp(var4, 0.24)
		local var2 = arg1.Color:Lerp(var8, 0.35)
		local tbl1 = { color = var2, x = 0.44, y = 0.56, w = 0.54, h = 0.26, r = 0.14, rot = nil, alpha = nil }
		tbl1.bare = true
		local tbl2 = {
			tbl1,
			{
				color = var18,
				x = 0.24,
				y = 0.56,
				w = 0.12,
				h = 0.2,
				r = 0.2,
				rot = nil,
				alpha = nil,
				bare = true,
			},
		}

		return {
			{
				{ color = var4, x = 0.44, y = 0.56, w = 0.66, h = 0.38, r = 0.22, rot = nil, alpha = nil },
				{ color = var5, x = 0.81, y = 0.56, w = 0.08, h = 0.17, r = 0.3, rot = nil, alpha = nil },
			},
			tbl2,
			{
				{ color = var5, x = 0.56, y = 0.44, w = 0.1, h = 0.62, r = 0.5, rot = 45, alpha = nil },
				{ color = var5, x = 0.79, y = 0.21, w = 0.26, h = 0.26, r = 0.5, rot = 0, alpha = nil },
				{ color = var11, x = 0.22, y = 0.82, w = 0.2, h = 0.2, r = 0.5, rot = 0, alpha = nil },
			},
			{
				{
					color = var1,
					x = 0.86,
					y = 0.14,
					w = 0.11,
					h = 0.11,
					r = 0.1,
					rot = 45,
					alpha = nil,
					bare = true,
				},
				{
					color = var13,
					x = 0.22,
					y = 0.82,
					w = 0.08,
					h = 0.08,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
			},
		}
	end,
	ExpertCollector = function()
		return {
			{
				{ color = var6, x = 0.16, y = 0.62, w = 0.19, h = 0.19, r = 0.12, rot = 45, alpha = nil },
				{ color = var6, x = 0.21, y = 0.39, w = 0.13, h = 0.13, r = 0.12, rot = 45, alpha = nil },
				{ color = var6, x = 0.84, y = 0.58, w = 0.21, h = 0.21, r = 0.12, rot = 45, alpha = nil },
				{ color = var6, x = 0.79, y = 0.34, w = 0.12, h = 0.12, r = 0.12, rot = 45, alpha = nil },
				{ color = var6, x = 0.5, y = 0.15, w = 0.12, h = 0.12, r = 0.12, rot = 45, alpha = nil },
			},
			{
				{
					color = var4,
					x = 0.14,
					y = 0.59,
					w = 0.06,
					h = 0.06,
					r = 0.2,
					rot = 45,
					alpha = 0.1,
					bare = true,
				},
				{
					color = var4,
					x = 0.82,
					y = 0.54,
					w = 0.07,
					h = 0.07,
					r = 0.2,
					rot = 45,
					alpha = 0.1,
					bare = true,
				},
			},
			{
				{ color = var11, x = 0.5, y = 0.79, w = 0.5, h = 0.17, r = 0.5, rot = nil, alpha = nil },
				{ color = var11, x = 0.5, y = 0.66, w = 0.5, h = 0.17, r = 0.5, rot = nil, alpha = nil },
				{ color = var11, x = 0.5, y = 0.53, w = 0.5, h = 0.17, r = 0.5, rot = nil, alpha = nil },
				{ color = var11, x = 0.5, y = 0.4, w = 0.5, h = 0.19, r = 0.5, rot = nil, alpha = nil },
			},
			{
				{
					color = var13,
					x = 0.5,
					y = 0.74,
					w = 0.44,
					h = 0.035,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var13,
					x = 0.5,
					y = 0.61,
					w = 0.44,
					h = 0.035,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var13,
					x = 0.5,
					y = 0.48,
					w = 0.44,
					h = 0.035,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var13,
					x = 0.5,
					y = 0.4,
					w = 0.3,
					h = 0.08,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var12,
					x = 0.4,
					y = 0.36,
					w = 0.1,
					h = 0.035,
					r = 0.5,
					rot = nil,
					alpha = nil,
					bare = true,
				},
			},
		}
	end,
	HumanTorch = function()
		return {
			{
				{
					color = var15,
					x = 0.44,
					y = 0.66,
					w = 0.78,
					h = 0.78,
					r = 0.5,
					rot = 0,
					alpha = 0.55,
					bare = true,
				},
				{
					color = var16,
					x = 0.44,
					y = 0.68,
					w = 0.54,
					h = 0.54,
					r = 0.5,
					rot = 0,
					alpha = 0.45,
					bare = true,
				},
			},
			{
				{ color = var17, x = 0.29, y = 0.53, w = 0.09, h = 0.22, r = 0.5, rot = nil, alpha = nil },
				{ color = var17, x = 0.39, y = 0.49, w = 0.09, h = 0.28, r = 0.5, rot = nil, alpha = nil },
				{ color = var17, x = 0.49, y = 0.49, w = 0.09, h = 0.28, r = 0.5, rot = nil, alpha = nil },
				{ color = var17, x = 0.59, y = 0.53, w = 0.09, h = 0.22, r = 0.5, rot = nil, alpha = nil },
				{ color = var17, x = 0.2, y = 0.71, w = 0.09, h = 0.24, r = 0.5, rot = -42, alpha = nil },
				{ color = var17, x = 0.44, y = 0.73, w = 0.4, h = 0.3, r = 0.4, rot = nil, alpha = nil },
			},
			{
				{ color = var4, x = 0.74, y = 0.22, w = 0.055, h = 0.36, r = 0.5, rot = nil, alpha = nil },
				{ color = var4, x = 0.74, y = 0.22, w = 0.055, h = 0.36, r = 0.5, rot = 60, alpha = nil },
				{ color = var4, x = 0.74, y = 0.22, w = 0.055, h = 0.36, r = 0.5, rot = 120, alpha = nil },
				{ color = var6, x = 0.74, y = 0.47, w = 0.08, h = 0.08, r = 0.5, rot = 0, alpha = nil },
			},
			{
				{
					color = var10,
					x = 0.74,
					y = 0.22,
					w = 0.08,
					h = 0.08,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
				{
					color = var4,
					x = 0.725,
					y = 0.455,
					w = 0.03,
					h = 0.03,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
			},
		}
	end,
	Ascendant = function(arg1)
		local tbl1 = {}
		for i1 = 0, 3 do
			table.insert(tbl1, {
				color = var4,
				x = 0.5,
				y = 0.5,
				w = 0.05,
				h = 1,
				r = 0.5,
				rot = i1 * 45 + 22.5,
				alpha = 0.55,
				bare = true,
			})

		end

		local var1 = arg1.Color:Lerp(var4, 0.3)
		local tbl2 = { { color = var1, x = 0.5, y = 0.5, w = 0.38, h = 0.38, r = 0.12, rot = 45, alpha = nil } }
		return {
			tbl1,
			{ { color = var6, x = 0.5, y = 0.5, w = 0.56, h = 0.56, r = 0.14, rot = 45, alpha = nil } },
			tbl2,
			{ { color = var11, x = 0.5, y = 0.5, w = 0.24, h = 0.24, r = 0.5, rot = 0, alpha = nil } },
			{
				{
					color = var2,
					x = 0.52,
					y = 0.455,
					w = 0.045,
					h = 0.11,
					r = 0.3,
					rot = 22,
					alpha = nil,
					bare = true,
				},
				{
					color = var2,
					x = 0.5,
					y = 0.5,
					w = 0.1,
					h = 0.035,
					r = 0.3,
					rot = nil,
					alpha = nil,
					bare = true,
				},
				{
					color = var2,
					x = 0.48,
					y = 0.545,
					w = 0.045,
					h = 0.11,
					r = 0.3,
					rot = 22,
					alpha = nil,
					bare = true,
				},
			},
			{
				{ color = var11, x = 0.5, y = 0.1, w = 0.12, h = 0.12, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.9, y = 0.5, w = 0.09, h = 0.14, r = 0.25, rot = nil, alpha = nil },
				{ color = var15, x = 0.5, y = 0.9, w = 0.12, h = 0.12, r = 0.5, rot = 0, alpha = nil },
				{ color = var9, x = 0.1, y = 0.5, w = 0.1, h = 0.1, r = 0.12, rot = 45, alpha = nil },
			},
		}
	end,
	Godly = function()
		return {
			{
				{ color = var11, x = 0.5, y = 0.53, w = 0.54, h = 0.54, r = 0.1, rot = nil, alpha = nil },
				{ color = var11, x = 0.5, y = 0.53, w = 0.54, h = 0.54, r = 0.1, rot = 45, alpha = nil },
			},
			{
				{
					color = var12,
					x = 0.5,
					y = 0.5,
					w = 0.4,
					h = 0.4,
					r = 0.1,
					rot = 0,
					alpha = 0.35,
					bare = true,
				},
				{
					color = var12,
					x = 0.5,
					y = 0.5,
					w = 0.4,
					h = 0.4,
					r = 0.1,
					rot = 45,
					alpha = 0.35,
					bare = true,
				},
			},
			{ { color = var6, x = 0.5, y = 0.53, w = 0.32, h = 0.32, r = 0.5, rot = 0, alpha = nil } },
			{
				{
					color = var4,
					x = 0.5,
					y = 0.53,
					w = 0.12,
					h = 0.12,
					r = 0.15,
					rot = 45,
					alpha = nil,
					bare = true,
				},
				{
					color = var10,
					x = 0.44,
					y = 0.6,
					w = 0.05,
					h = 0.05,
					r = 0.5,
					rot = 0,
					alpha = nil,
					bare = true,
				},
			},
			{
				{ color = var4, x = 0.5, y = 0.05, w = 0.1, h = 0.1, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.5, y = 0.13, w = 0.18, h = 0.08, r = 0.5, rot = nil, alpha = nil },
				{ color = var4, x = 0.12, y = 0.8, w = 0.1, h = 0.1, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.12, y = 0.88, w = 0.18, h = 0.08, r = 0.5, rot = nil, alpha = nil },
				{ color = var4, x = 0.88, y = 0.8, w = 0.1, h = 0.1, r = 0.5, rot = 0, alpha = nil },
				{ color = var4, x = 0.88, y = 0.88, w = 0.18, h = 0.08, r = 0.5, rot = nil, alpha = nil },
			},
		}
	end,
}

return {
	gem = function(arg1)
		local var2 = Instance.new("Frame")
		var2.Name = "Gem"
		var2.BackgroundTransparency = 1
		var2.Size = UDim2.fromOffset(28, 28)
		Instance.new("UIAspectRatioConstraint").Parent = var2
		local var3 = var1("#43C6DA")
		local tbl1 = { { color = var3, x = 0.5, y = 0.5, w = 0.6, h = 0.6, r = 0.16, rot = 45, alpha = nil } }
		local var5 = var1("#1F8FA6")
		var3 = { color = var5, x = 0.58, y = 0.58, w = 0.3, h = 0.3, r = 0.1, rot = 45, alpha = nil }
		var3.bare = true
		local var6 = var1("#9BE6F2")
		var5 = { color = var6, x = 0.42, y = 0.42, w = 0.28, h = 0.28, r = 0.1, rot = 45, alpha = nil }
		var5.bare = true
		local tbl2 = { var3, var5 }
		render(var2, {
			tbl1,
			tbl2,
			{ {
				color = var4,
				x = 0.38,
				y = 0.37,
				w = 0.1,
				h = 0.1,
				r = 0.2,
				rot = 45,
				alpha = 0.1,
				bare = true,
			} },
		})

		applyProps(var2, arg1, {})
		return var2
	end,
	build = function(arg1, arg2)
		local var1 = var7.ById[arg1]
		local var2 = Instance.new("Frame")
		var2.Name = "ClassIcon"
		var2.BorderSizePixel = 0
		var2.BackgroundTransparency = 1
		var2.Size = UDim2.fromOffset(64, 64)
		Instance.new("UIAspectRatioConstraint").Parent = var2
		var1 = var1 or var7.ById[var7.StarterId]
		local bool1 = false
		if arg2 ~= nil then
			bool1 = arg2.plain == true
		end

		if not bool1 then
			local var8, var9, var10 = badgeColors(var1)
			frame(var2, "Rim", var8, 0.5, 0.5, 1, 1, 0.3)
			local var11 = frame(var2, "Face", var4, 0.5, 0.5, 0.86, 0.86, 0.27)
			local var12 = Instance.new("UIGradient")
			var12.Color = ColorSequence.new(var9, var10)
			var12.Rotation = 90
			var12.Parent = var11
			frame(var2, "Gloss", var4, 0.42, 0.22, 0.58, 0.16, 0.5, -8, 0.8)
		end

		local var13 = Instance.new("Frame")
		var13.Name = "Glyph"
		var13.BackgroundTransparency = 1
		var13.AnchorPoint = Vector2.new(0.5, 0.5)
		var13.Position = UDim2.fromScale(0.5, 0.5)
		local var14 = UDim2.fromScale
		local var15 = if bool1 then 1 else 0.74
		var13.Size = var14(var15, if bool1 then 1 else 0.74)
		var13.Parent = var2
		var14 = tbl1[var1.Id]
		if var14 then
			local var17 = var1
			render(var13, var14(var17))
		end

		applyProps(var2, arg2, { plain = true })
		var2:SetAttribute("ClassId", var1.Id)
		return var2
	end,
}

--- ReplicatedStorage.MeltShared.ClassPerks [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Classes)
local var2 = require(script.Parent.Upgrades)
local tbl1 = {
	BP = 10000,
	Keys = {
		"Battery",
		"Coins",
		"HairdryerPower",
		"UpgradeDiscount",
		"SteamDiscount",
		"SteamPower",
		"Technician",
		"HumanTorch",
	},
	amplification = function(arg1)
		local var2 = math.clamp(math.floor(arg1 or 0), 0, 4)
		if var2 <= 1 then
			return 100
		end

		return (var2 - 1) * 10 + 100
	end,
}

tbl1.resolve = function(arg1, arg2)
	local var2 = var1.ById[arg1 or ""]
	local var3 = math.max(0, (math.floor(arg2 or 0)))
	var2 = var2 or var1.ById[var1.StarterId]
	local var4 = 0 < var3
	local var5 = tbl1.amplification(var3)
	local tbl2 = {}
	local tbl3 = { var2.Id, (tostring(var3)) }
	for k1, v1 in ipairs(tbl1.Keys) do
		local var6 = var2.Perks[v1] or 0
		local var7 = math.max(var6, if var4 then var1.AscendedPerks[v1] or 0 else 0) * var5 // 100
		tbl2[v1] = var7
		table.insert(tbl3, (tostring(var7)))
	end

	local var9 = var4
	local tbl4 = { classId = var2.Id, godlies = var3, amp = var5, team = var4 }
	if var9 then
		var9 = var2.TeamShare ~= true
	end

	tbl4.fromTeam = var9
	tbl4.bp = tbl2
	tbl4.key = table.concat(tbl3, ":")
	return tbl4
end

tbl1.countGodlies = function(arg1)
	local num1 = 0
	for k1, v1 in ipairs(arg1) do
		if v1 ~= "Godly" then
			continue
		end

		num1 = num1 + 1
	end

	return num1
end

tbl1.none = function()
	local var2 = var1.StarterId
	local num1 = 0
	return tbl1.resolve(var2, num1)
end

tbl1.withPermanent = function(arg1, arg2)
	local var1 = arg1
	var1 = var1 or tbl1.none()
	local var3 = var2.sanitise(arg2)
	local var4 = table.clone(var1)
	var4.permanent = var3
	local tbl2 = { var1.key }
	for k1, v1 in ipairs(var2.List) do
		table.insert(tbl2, (tostring(var3[v1.Id])))
	end

	var4.key = table.concat(tbl2, "|")
	return var4
end

tbl1.withBatteryBoost = function(arg1, arg2)
	local var1 = arg1
	var1 = var1 or tbl1.none()
	if typeof(arg2) ~= "number" or arg2 <= 1 then
		return var1
	end

	local var2 = table.clone(var1)
	var2.batteryBoost = arg2
	var2.key = var1.key .. "|B" .. tostring(arg2)
	return var2
end

tbl1.batteryBoost = function(arg1)
	local var1 = if arg1 then arg1.batteryBoost else nil
	if typeof(var1) == "number" and 1 < var1 then
		return var1
	end

	return 1
end

tbl1.permanent = function(arg1)
	local var3 = if arg1 then arg1.permanent else nil
	if var3 then
		return var3
	end

	return (var2.zero())
end

tbl1.permanentBatterySeconds = function(arg1)
	local var1 = arg1
	return var2.batterySeconds(tbl1.permanent(var1))
end

tbl1.iceCoinMultiplier = function(arg1)
	local var1 = arg1
	return tbl1.coinMultiplier(arg1) * var2.iceCoinMultiplier(tbl1.permanent(var1))
end

tbl1.permanentToolDiscount = function(arg1)
	local var1 = arg1
	return var2.toolDiscount(tbl1.permanent(var1))
end

tbl1.capacity = function(arg1, arg2)
	if not arg2 or arg2.bp.Battery <= 0 then
		return arg1
	end

	return arg1 * (10000 + arg2.bp.Battery) / 10000
end

tbl1.coinMultiplier = function(arg1)
	if not arg1 then
		return 1
	end

	return (10000 + arg1.bp.Coins) / 10000
end

tbl1.toolPowerBonus = function(arg1, arg2)
	if not arg2 then
		return 0
	end

	if arg1 == "Hairdryer" then
		return arg2.bp.HairdryerPower / 10000
	end

	if arg1 == "SteamBlaster" then
		return arg2.bp.SteamPower / 10000
	end

	return 0
end

tbl1.technicianBonus = function(arg1, arg2, arg3)
	if not arg1 or (arg1.bp.Technician <= 0 or arg3 <= 0) then
		return 0
	end

	return arg1.bp.Technician / 10000 * (1 - math.clamp(arg2 / arg3, 0, 1))
end

tbl1.torchRate = function(arg1)
	if not arg1 then
		return 0
	end

	return arg1.bp.HumanTorch / 10000
end

tbl1.discounted = function(arg1, arg2)
	if arg2 <= 0 then
		return arg1
	end

	return (arg1 * (10000 - arg2) + 10000 - 1) // 10000
end

tbl1.upgradePrice = function(arg1, arg2)
	if arg2 then
		return (tbl1.discounted(arg1, arg2.bp.UpgradeDiscount))
	end

	return arg1
end

tbl1.toolPrice = function(arg1, arg2, arg3)
	local var3 = if arg3 and arg1 == "SteamBlaster" then arg3.bp.SteamDiscount else 0
	local var4 = tbl1.permanentToolDiscount(arg3)
	if var3 <= 0 and var4 <= 0 then
		return arg2
	end

	return (math.ceil(arg2 * (10000 - var3) / 10000 * (1 - var4) - 1e-09))
end

tbl1.percent = function(arg1)
	if arg1 % 100 == 0 then
		return (tostring(arg1 // 100))
	end

	local str1 = "%.1f"
	local var1 = arg1 / 100
	return string.format(str1, var1)
end

tbl1.lines = function(arg1)
	local var1 = arg1.bp
	local var3 = tbl1.percent
	local tbl2 = {}
	if 0 < var1.Battery then
		table.insert(tbl2, "+" .. var3(var1.Battery) .. "% battery capacity")
	end

	if 0 < var1.Coins then
		table.insert(tbl2, "+" .. var3(var1.Coins) .. "% run coins")
	end

	if 0 < var1.HairdryerPower then
		table.insert(tbl2, "Hairdryer +" .. var3(var1.HairdryerPower) .. "% power")
	end

	if 0 < var1.UpgradeDiscount then
		table.insert(tbl2, "Upgrades " .. var3(var1.UpgradeDiscount) .. "% cheaper")
	end

	if 0 < var1.SteamDiscount then
		table.insert(tbl2, "Steam Blaster " .. var3(var1.SteamDiscount) .. "% cheaper")
	end

	if 0 < var1.SteamPower then
		table.insert(tbl2, "Steam Blaster +" .. var3(var1.SteamPower) .. "% power")
	end

	if 0 < var1.Technician then
		table.insert(tbl2, "Up to +" .. var3(var1.Technician) .. "% power as the battery drains")
	end

	if 0 < var1.HumanTorch then
		table.insert(tbl2, if 10000 < var1.HumanTorch then "Melts ice you touch, " .. var3(var1.HumanTorch - 10000) .. "% faster" else "Melts ice you touch")
	end

	return tbl2
end

return tbl1

--- ReplicatedStorage.MeltShared.Classes [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local tbl1 = { Name = "Common", Color = var1("#7C8FA0") }
local tbl2 = { Name = "Uncommon", Color = var1("#3FA65A") }
local tbl3 = { Name = "Rare", Color = var1("#3C82D6") }
local tbl4 = { Name = "Epic", Color = var1("#A447C9") }
local tbl5 = { Name = "Legendary", Color = var1("#F0861C") }
local tbl6 = { Name = "Mythic", Color = var1("#DE3F52") }
local tbl7 = { Name = "Ascendant", Color = var1("#7F56C2") }
local tbl8 = { tbl1, tbl2, tbl3, tbl4, tbl5, tbl6, tbl7, { Name = "Godly", Color = var1("#C9951F") } }
local tbl9 = {
	TotalWeight = 100000,
	SpinCost = 100,
	CompletionGems = 500,
	StarterId = "Starter",
	RevealSeconds = 4,
	Tiers = tbl8,
}

tbl9.TierByName = {}
for k1, v1 in ipairs(tbl9.Tiers) do
	v1.Order = k1
	v1.Accent = v1.Color:Lerp(Color3.new(1, 1, 1), 0.85)
	tbl9.TierByName[v1.Name] = v1
end

tbl8 = {
	Battery = 5000,
	Coins = 4000,
	HairdryerPower = 2500,
	UpgradeDiscount = 2000,
	SteamDiscount = 2500,
	SteamPower = 2500,
	Technician = 7500,
	HumanTorch = 10000,
}

tbl9.AscendedPerks = tbl8
tbl5 = {
	Id = "HairStylist",
	Name = "Hair Stylist",
	Weight = 9000,
	Tier = "Epic",
	Perks = { HairdryerPower = 2500, UpgradeDiscount = 2000 },
	Summary = "Stronger Hairdryer, cheaper upgrades.",
	Lines = {
		"Hairdryer is 25% stronger.",
		"Battery, Size and Power upgrades cost 20% less on every tool.",
	},
}

tbl6 = {
	Id = "SteamSpecialist",
	Name = "Steam Specialist",
	Weight = 7000,
	Tier = "Epic",
	Perks = { SteamDiscount = 2500, SteamPower = 2500 },
	Summary = "Cheaper, stronger Steam Blaster.",
	Lines = {
		"Steam Blaster costs 25% less.",
		"Steam Blaster is 25% stronger.",
		"You still need the Heat Gun first.",
	},
}

tbl9.List = {
	{
		Id = "Starter",
		Name = "Starter",
		Weight = 40889,
		Tier = "Common",
		Perks = {},
		Summary = "No boosts.",
		Lines = { "No boosts. Every player starts with this class." },
	},
	{
		Id = "Powerbank",
		Name = "Powerbank",
		Weight = 25000,
		Tier = "Uncommon",
		Perks = { Battery = 5000 },
		Summary = "+50% battery capacity.",
		Lines = { "50% more battery capacity on every tool.", "A full recharge still takes 3 seconds." },
	},
	{
		Id = "NoviceCollector",
		Name = "Novice Ice Collector",
		Weight = 14000,
		Tier = "Rare",
		Perks = { Coins = 2000 },
		Summary = "+20% run coins.",
		Lines = { "Earn 20% more run coins." },
	},
	tbl5,
	tbl6,
	{
		Id = "Technician",
		Name = "Technician",
		Weight = 3000,
		Tier = "Legendary",
		Perks = { Technician = 7500 },
		Summary = "More power as the battery drains.",
		Lines = {
			"The lower your battery, the stronger your tool: up to +75% power.",
			"An empty battery still stops the tool.",
		},
	},
	{
		Id = "ExpertCollector",
		Name = "Expert Ice Collector",
		Weight = 1000,
		Tier = "Legendary",
		Perks = { Coins = 4000 },
		Summary = "+40% run coins.",
		Lines = { "Earn 40% more run coins." },
	},
	{
		Id = "HumanTorch",
		Name = "Human Torch",
		Weight = 100,
		Tier = "Mythic",
		Perks = { HumanTorch = 10000 },
		Summary = "Melts ice you touch.",
		Lines = { "Ice melts where your body touches it.", "No tool or battery needed." },
	},
	{
		Id = "Ascendant",
		Name = "Ascendant",
		Weight = 10,
		Tier = "Ascendant",
		Perks = tbl8,
		Summary = "Every perk at once.",
		Lines = { "Every perk: Powerbank, Expert coin bonus, Hair Stylist, Steam Specialist, Technician and Human Torch." },
	},
	{
		Id = "Godly",
		Name = "Godly",
		Weight = 1,
		Tier = "Godly",
		Perks = tbl8,
		TeamShare = true,
		Summary = "Every perk, for the whole team.",
		Lines = {
			"Every Ascendant perk, for you and every teammate in your Level 1 run.",
			"Each extra Godly on the team makes every perk bonus 10% stronger.",
		},
	},
}

tbl9.ById = {}
tbl1 = 0
for k2, v2 in ipairs(tbl9.List) do
	tbl7 = tbl9.TierByName[v2.Tier]
	assert(tbl7, "Classes: unknown tier " .. tostring(v2.Tier))
	v2.Order = k2
	v2.Color = tbl7.Color
	v2.Accent = tbl7.Accent
	tbl9.ById[v2.Id] = v2
	tbl1 = tbl1 + v2.Weight
end

assert(tbl1 == tbl9.TotalWeight, "Classes: weights must total " .. tbl9.TotalWeight)
tbl9.LuckMultiplier = 2
tbl9.LuckTiers = { Legendary = true, Mythic = true, Ascendant = true, Godly = true }
tbl9.LuckDonors = {
	{ Tier = "Common", Share = 76 },
	{ Tier = "Uncommon", Share = 15 },
	{ Tier = "Rare", Share = 9 },
}

tbl2 = function(arg1, arg2)
	local num1 = 0
	for k1, v1 in ipairs(arg2) do
		num1 = num1 + v1.share
	end

	assert(0 < num1, "Classes: allocate with no share to divide")
	local tbl1 = {}
	local num2 = 0
	local tbl2 = {}
	for k2, v2 in ipairs(arg2) do
		local var1 = arg1 * v2.share / num1
		local var2 = math.floor(var1)
		tbl1[v2.key] = var2
		table.insert(tbl2, { key = v2.key, frac = var1 - var2 })
		num2 = num2 + var2
	end

	table.sort(tbl2, function(arg1, arg2)
		if arg1.frac == arg2.frac then
			return arg1.key < arg2.key
		end

		return arg2.frac < arg1.frac
	end)

	local num3 = 1
	while num2 < arg1 do
		local var3 = tbl2[num3].key
		local var4 = tbl1[var3] + 1
		tbl1[var3] = var4
		num2 = num2 + 1
		num3 = if #tbl2 <= num3 then 1 else num3 + 1
	end

	return tbl1
end

local var2 = nil
local function computeLuckWeights()
	local tbl1 = {}
	local num1 = 0
	for k1, v1 in ipairs(tbl9.List) do
		tbl1[v1.Id] = v1.Weight
		local var1 = tbl9.LuckTiers[v1.Tier]
		if not var1 then
			continue
		end

		var1 = v1.Weight
		num1 = num1 + var1
	end

	local var2 = num1 * (tbl9.LuckMultiplier - 1)
	for k2, v2 in ipairs(tbl9.List) do
		local var3 = tbl9.LuckTiers[v2.Tier]
		if not var3 then
			continue
		end

		var3 = v2.Id
		tbl1[var3] = v2.Weight * tbl9.LuckMultiplier
	end

	local tbl3 = {}
	for k3, v3 in ipairs(tbl9.LuckDonors) do
		table.insert(tbl3, { key = v3.Tier, share = v3.Share })
	end

	local var4 = var2
	local var5 = tbl2(var4, tbl3)
	for k4, v4 in pairs(var5) do
		local tbl4 = {}
		for k5, v5 in ipairs(tbl9.List) do
			if v5.Tier ~= k4 then
				continue
			end

			table.insert(tbl4, { key = v5.Id, share = v5.Weight })
		end

		assert(0 < (#tbl4), "Classes: 2x Luck donor tier has no classes: " .. tostring(k4))
		local var6 = v4
		local var7 = tbl2(var6, tbl4)
		for k6, v6 in pairs(var7) do
			local var8 = tbl1[k6] - v6
			tbl1[k6] = var8
			assert(1 <= tbl1[k6], "Classes: 2x Luck would leave " .. k6 .. " unrollable")
		end
	end

	local num2 = 0
	for k7, v7 in ipairs(tbl9.List) do
		num2 = num2 + tbl1[v7.Id]
	end

	assert(num2 == tbl9.TotalWeight, "Classes: 2x Luck weights must total " .. tbl9.TotalWeight .. ", got " .. num2)
	return tbl1
end

tbl9.weights = function(arg1)
	if arg1 then
		if not var2 then
			var2 = computeLuckWeights()
		end

		return var2
	end

	local tbl1 = {}
	for k1, v1 in ipairs(tbl9.List) do
		tbl1[v1.Id] = v1.Weight
	end

	return tbl1
end

tbl9.weightOf = function(arg1, arg2)
	local var2 = tbl9.ById[arg1]
	if not var2 then
		return 0
	end

	if arg2 then
		return tbl9.weights(true)[var2.Id]
	end

	return var2.Weight
end

tbl9.isClass = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl9.ById[arg1] ~= nil
	end

	return bool1
end

tbl9.intervals = function(arg1)
	local var1 = tbl9.weights(arg1)
	local tbl1 = {}
	local num1 = 1
	for k1, v1 in ipairs(tbl9.List) do
		local var2 = var1[v1.Id]
		table.insert(tbl1, { id = v1.Id, from = num1, to = num1 + var2 - 1 })
		num1 = num1 + var2
	end

	return tbl1
end

tbl9.pick = function(arg1, arg2)
	if typeof(arg1) ~= "number" or (arg1 ~= math.floor(arg1) or (arg1 < 1 or tbl9.TotalWeight < arg1)) then
		return nil
	end

	local var1 = tbl9.weights(arg2)
	local num1 = 0
	for k1, v1 in ipairs(tbl9.List) do
		num1 = num1 + var1[v1.Id]
		if arg1 > num1 then
			continue
		end

		return v1.Id
	end

	return nil
end

tbl9.oddsText = function(arg1, arg2)
	if not tbl9.ById[arg1] then
		return ""
	end

	local var1 = tbl9.weightOf(arg1, arg2)
	return string.gsub(string.gsub(string.format("%d.%03d", var1 // 1000, var1 % 1000), "0+$", ""), "%.$", "") .. "%"
end

tbl9.chanceText = function(arg1, arg2)
	local var2 = tbl9.weightOf(arg1, arg2)
	if not tbl9.ById[arg1] or 3000 < var2 then
		return nil
	end

	local var3 = tbl9.TotalWeight / var2
	if var3 ~= math.floor(var3) then
		return nil
	end

	return "1 in " .. string.gsub(string.reverse((string.gsub(string.reverse((tostring((math.floor(var3))))), "(%d%d%d)", "%1,"))), "^,", "")
end

return tbl9

--- ReplicatedStorage.MeltShared.Products [ModuleScript]
-- y u r i

local tbl1 = {
	RunOnlyNotice = "For this run only. Unused items expire when the run ends.",
	RobuxGlyph = utf8.char(57346),
}

local tbl2 = {
	Key = "RailgunFree",
	ProductId = 3715389099,
	Name = "Free Railgun Shot",
	BasePrice = 30,
	Kind = "TeamRun",
	Effect = "FreeShots",
	Description = "Pays for one railgun shot in your current Level 4 run, for your whole team: the next shot costs 0 coins. Buy again for another free shot. It does not upgrade the railgun, skip the cooldown or melt any ice by itself.",
	DisplayLines = { "The next railgun shot costs 0 coins", "One shot per purchase" },
}

tbl1.List = {
	{
		Key = "FireGrenade",
		ProductId = 3712929716,
		Name = "Fire Grenade",
		BasePrice = 6,
		Kind = "Consumable",
		Grenades = 1,
		Description = "One throwable Fire Grenade for your current Level 1 run. It melts a pocket of ice three seconds after you throw it. Unused grenades expire when the run ends.",
		DisplayLines = { "1 grenade \226\128\162 This run only" },
	},
	{
		Key = "FireGrenade5",
		ProductId = 3713336377,
		Name = "Fire Grenade x5",
		BasePrice = 26,
		Kind = "Consumable",
		Grenades = 5,
		Display = "FireGrenade",
		Description = "Five throwable Fire Grenades for your current Level 1 run. Each melts a pocket of ice three seconds after you throw it. Unused grenades expire when the run ends.",
		DisplayLines = { "5 grenades \226\128\162 This run only" },
	},
	{
		Key = "Flamethrower",
		ProductId = 3712929693,
		Name = "Flamethrower",
		BasePrice = 149,
		Kind = "RunUnlock",
		ToolId = "Flamethrower",
		Description = "Unlocks the Flamethrower, the strongest melting tool, for your current Level 1 run. It does not carry into your next run.",
		DisplayLines = { "Unlock for this run", "Does not carry into your next run" },
	},
	{
		Key = "DoubleBattery",
		ProductId = 3714479516,
		Name = "Battery Pack",
		BasePrice = 19,
		Kind = "RunBoost",
		BatteryMultiplier = 2,
		Model = "BatteryPack",
		Description = "Doubles the battery of every tool you own for your current Level 1 run, and fills them. It does not carry into your next run.",
		DisplayLines = { "Double battery on every tool", "This run only" },
	},
	{
		Key = "DoubleRunGems",
		ProductId = 3713336138,
		Name = "Double gems earnings [One Time]",
		BasePrice = 40,
		Kind = "RunBonus",
		Description = "Pays the gems for one finished run a second time. The run's own reward is already yours; this adds the same amount again, once, to that one run.",
		DisplayLines = { "Doubles one run's reward", "Offered when you get back to the lobby" },
	},
	{
		Key = "Gems100",
		ProductId = 3713335682,
		Name = "100 Gems",
		BasePrice = 19,
		Kind = "Gems",
		Gems = 100,
		Description = "Adds 100 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "100 gems" },
	},
	{
		Key = "Gems500",
		ProductId = 3713335698,
		Name = "500 Gems",
		BasePrice = 59,
		Kind = "Gems",
		Gems = 500,
		Description = "Adds 500 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "500 gems" },
	},
	{
		Key = "Gems1000",
		ProductId = 3713335717,
		Name = "1,000 Gems",
		BasePrice = 99,
		Kind = "Gems",
		Gems = 1000,
		Description = "Adds 1,000 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "1,000 gems" },
	},
	{
		Key = "Gems2000",
		ProductId = 3713335735,
		Name = "2,000 Gems",
		BasePrice = 149,
		Kind = "Gems",
		Gems = 2000,
		Description = "Adds 2,000 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "2,000 gems" },
	},
	{
		Key = "Gems3500",
		ProductId = 3713335766,
		Name = "3,500 Gems",
		BasePrice = 199,
		Kind = "Gems",
		Gems = 3500,
		Description = "Adds 3,500 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "3,500 gems" },
	},
	{
		Key = "Gems5000",
		ProductId = 3713335775,
		Name = "5,000 Gems",
		BasePrice = 299,
		Kind = "Gems",
		Gems = 5000,
		Description = "Adds 5,000 gems to your balance. Gems buy class spins, and they stay with you for good.",
		DisplayLines = { "5,000 gems" },
	},
	{
		Key = "StarterPack",
		ProductId = 3714384378,
		Name = "Starter Pack",
		BasePrice = 89,
		Kind = "Bundle",
		Gems = 1000,
		PermanentTools = { "HeatGun" },
		Description = "1,000 gems for your balance, and the Heat Gun in every run you play, for good.",
		DisplayLines = { "1,000 gems", "Heat Gun in every run" },
	},
	{
		Key = "LimitedBundle1",
		ProductId = 3715185720,
		Name = "Limited Time Bundle 1",
		BasePrice = 360,
		Kind = "Bundle",
		Gems = 0,
		Skins = { "darkmatter" },
		EndsAt = 1791248400,
		Description = "The Dark Matter skin collection: every weapon and your Fire Grenades. Only in this bundle.",
		DisplayLines = { "Dark Matter skins", "Limited time only" },
	},
	{
		Key = "MythicBox",
		ProductId = 3714576378,
		Name = "Mythic Drop",
		BasePrice = 18,
		Kind = "SkinBox",
		Crate = "mythic",
		Description = "One Mythic Drop: an Epic skin or better, once a day.",
		DisplayLines = { "One Epic-or-better skin" },
	},
	{
		Key = "MythicBox10",
		ProductId = 3715112404,
		Name = "Mythic Drop 10x Luck",
		BasePrice = 135,
		Kind = "SkinBox",
		Crate = "mythic10",
		Description = "One Mythic Drop with 10x Luck: Legendary or better every time, once a day.",
		DisplayLines = { "Legendary or better" },
	},
	{
		Key = "LevelSlot",
		ProductId = 3715096159,
		Name = "Extra level slot",
		BasePrice = 45,
		Kind = "LevelSlot",
		Description = "One more slot for your own community levels.",
		DisplayLines = { "One more level slot" },
	},
	{
		Key = "BuildBudget",
		ProductId = 3715137549,
		Name = "Increase build budget",
		BasePrice = 36,
		Kind = "MapBoost",
		Description = "Raises this map's build budget by half. For this map only; once per map.",
		DisplayLines = { "Build budget +50%", "This map only" },
	},
	{
		Key = "ElecCapacity",
		ProductId = 3715794145,
		Name = "5x Electronic capacity",
		BasePrice = 18,
		Kind = "MapBoost",
		MapField = "elecBoost",
		Description = "Five times the electronics this map can hold. For this map only; once per map.",
		DisplayLines = { "Electronics x5", "This map only" },
	},
	{
		Key = "RailgunMax",
		ProductId = 3715389021,
		Name = "Max Out Railgun",
		BasePrice = 400,
		Kind = "TeamRun",
		Effect = "MaxLevel",
		Description = "Unlocks every railgun level for your current Level 4 run, for your whole team. No upgrade plans needed. Shots still cost coins, and it does not melt any ice by itself. It does not carry into your next run.",
		DisplayLines = { "Every railgun level, this run", "Shots still cost coins" },
	},
	tbl2,
}

tbl1.ByKey = {}
for k1, v1 in ipairs(tbl1.List) do
	tbl1.ByKey[v1.Key] = v1
end

tbl1.gemsPerRobux = function(arg1)
	if tbl1.configured(arg1) and 0 < arg1.BasePrice then
		return (arg1.Gems or 0) / arg1.BasePrice
	end

	return 0
end

tbl1.GemPacks = {}
for k2, v2 in ipairs(tbl1.List) do
	if v2.Kind ~= "Gems" then
		continue
	end

	table.insert(tbl1.GemPacks, v2)
end

table.sort(tbl1.GemPacks, function(arg1, arg2)
	return (arg1.Gems or 0) < (arg2.Gems or 0)
end)

tbl1.isGems = function(arg1)
	local bool2 = false
	if arg1 ~= nil then
		bool2 = false
		if arg1.Kind == "Gems" then
			bool2 = false
			if typeof(arg1.Gems) == "number" then
				bool2 = 0 < arg1.Gems
			end
		end
	end

	return bool2
end

tbl1.featuredGemPack = function()
	local var1 = nil
	local num1 = 0
	local num2 = 0
	for k1, v1 in ipairs(tbl1.GemPacks) do
		if not tbl1.configured(v1) then
			continue
		end

		local var3 = tbl1.gemsPerRobux(v1)
		num2 = num2 + 1
		if not var1 or (num1 < var3 or var3 == num1 and (var1.Gems or 0) < (v1.Gems or 0)) then
			var1 = v1
		end

		local var4 = var3
	end

	if 2 <= num2 then
		return var1
	end

	return nil
end

tbl1.packForShortfall = function(arg1)
	if typeof(arg1) ~= "number" or (arg1 ~= arg1 or arg1 <= 0) then
		return nil
	end

	local var1 = nil
	local var2 = nil
	for k1, v1 in ipairs(tbl1.GemPacks) do
		if not tbl1.configured(v1) then
			continue
		end

		if var2 then
			if (var2.Gems or 0) < (v1.Gems or 0) then
				var2 = v1
			end
		end

		if arg1 > (v1.Gems or 0) then
			continue
		end

		if not var1 or v1.BasePrice < var1.BasePrice then
			var1 = v1
		end
	end

	return var1 or var2
end

tbl1.DoubleRunGemsKey = "DoubleRunGems"
tbl1.isBundle = function(arg1)
	if arg1 == nil or (arg1.Kind ~= "Bundle" or typeof(arg1.Gems) ~= "number") then
		return false
	end

	local bool2 = true
	if 0 >= arg1.Gems then
		bool2 = false
		if typeof(arg1.Skins) == "table" then
			bool2 = 0 < (#arg1.Skins)
		end
	end

	return bool2
end

tbl1.creditExtras = function(arg1)
	if not tbl1.isBundle(arg1) then
		return nil
	end

	local var1 = arg1.PermanentTools
	local tbl2 = { tools = table.clone(var1 or {}) }
	tbl2.pack = arg1.Key
	var1 = arg1.Skins
	tbl2.skins = table.clone(var1 or {})
	return tbl2
end

tbl1.LimitedBundleKey = "LimitedBundle1"
tbl1.limitedBundle = function()
	local var1 = tbl1.ByKey[tbl1.LimitedBundleKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.onSale = function(arg1, arg2)
	if not tbl1.configured(arg1) then
		return false
	end

	local var2 = arg1.EndsAt
	local bool1 = true
	if var2 ~= nil then
		bool1 = arg2 < var2
	end

	return bool1
end

tbl1.StarterPackKey = "StarterPack"
tbl1.starterPack = function()
	local var1 = tbl1.ByKey[tbl1.StarterPackKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.grenadeCount = function(arg1)
	if arg1 == nil or arg1.Kind ~= "Consumable" then
		return 0
	end

	local var1 = arg1.Grenades
	if typeof(var1) == "number" and 1 <= var1 then
		return (math.floor(var1))
	end

	return 0
end

tbl1.displayKey = function(arg1)
	local var1 = arg1.Display
	return var1 or arg1.Key
end

tbl1.alsoAt = function(arg1)
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1.List) do
		if v1.Display ~= arg1 then
			continue
		end

		if v1.Key == arg1 then
			continue
		end

		table.insert(tbl2, v1)
	end

	return tbl2
end

tbl1.batteryMultiplier = function(arg1)
	if arg1 == nil or arg1.Kind ~= "RunBoost" then
		return 1
	end

	local var1 = arg1.BatteryMultiplier
	if typeof(var1) == "number" and 1 < var1 then
		return var1
	end

	return 1
end

tbl1.isSkinBox = function(arg1)
	local bool2 = false
	if arg1 ~= nil then
		bool2 = false
		if arg1.Kind == "SkinBox" then
			bool2 = typeof(arg1.Crate) == "string"
		end
	end

	return bool2
end

tbl1.MythicBoxKey = "MythicBox"
tbl1.LevelSlotKey = "LevelSlot"
tbl1.isLevelSlot = function(arg1)
	local bool1 = false
	if arg1 ~= nil then
		bool1 = arg1.Kind == "LevelSlot"
	end

	return bool1
end

tbl1.levelSlot = function()
	local var1 = tbl1.ByKey[tbl1.LevelSlotKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.BuildBudgetKey = "BuildBudget"
tbl1.isMapBoost = function(arg1)
	local bool1 = false
	if arg1 ~= nil then
		bool1 = arg1.Kind == "MapBoost"
	end

	return bool1
end

tbl1.buildBudget = function()
	local var1 = tbl1.ByKey[tbl1.BuildBudgetKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.ElecCapacityKey = "ElecCapacity"
tbl1.elecCapacity = function()
	local var1 = tbl1.ByKey[tbl1.ElecCapacityKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.mapField = function(arg1)
	if arg1 and arg1.MapField == "elecBoost" then
		return "elecBoost"
	end

	return "boost"
end

tbl1.MythicLuckBoxKey = "MythicBox10"
tbl1.mythicLuckBox = function()
	local var1 = tbl1.ByKey[tbl1.MythicLuckBoxKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.mythicBox = function()
	local var1 = tbl1.ByKey[tbl1.MythicBoxKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.isTeamRun = function(arg1)
	local bool2 = false
	if arg1 ~= nil then
		bool2 = false
		if arg1.Kind == "TeamRun" then
			bool2 = typeof(arg1.Effect) == "string"
		end
	end

	return bool2
end

tbl1.isRunBonus = function(arg1)
	local bool1 = false
	if arg1 ~= nil then
		bool1 = arg1.Kind == "RunBonus"
	end

	return bool1
end

tbl1.doubleRunGems = function()
	local var1 = tbl1.ByKey[tbl1.DoubleRunGemsKey]
	if tbl1.configured(var1) then
		return var1
	end

	return nil
end

tbl1.byProductId = function(arg1)
	if typeof(arg1) ~= "number" or arg1 <= 0 then
		return nil
	end

	for k1, v1 in ipairs(tbl1.List) do
		if v1.ProductId ~= arg1 then
			continue
		end

		return v1
	end

	return nil
end

tbl1.configured = function(arg1)
	local bool2 = false
	if arg1 ~= nil then
		bool2 = false
		if typeof(arg1.ProductId) == "number" then
			bool2 = 0 < arg1.ProductId
		end
	end

	return bool2
end

tbl1.productIds = function()
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1.List) do
		if not tbl1.configured(v1) then
			continue
		end

		table.insert(tbl2, v1.ProductId)
	end

	return tbl2
end

tbl1.priceText = function(arg1)
	if typeof(arg1) ~= "number" or (arg1 ~= arg1 or arg1 < 0) then
		return nil
	end

	return tbl1.RobuxGlyph .. " " .. tostring((math.floor(arg1)))
end

return tbl1

--- ReplicatedStorage.MeltShared.ClassLooks [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local var2 = var1("#F3E6CC")
local var3 = var1("#22375A")
local var4 = var1("#FFFFFF")
local var5 = var1("#2E8C8A")
local var6 = var1("#1F6566")
local var7 = var1("#2A8084")
local var8 = var1("#1B5A5F")
local var9 = var1("#2F363E")
local var10 = var1("#4A545E")
local var11 = var1("#FFC93C")
local var12 = var1("#3A4148")
local var13 = var1("#FF6F4F")
local var14 = var1("#467A3E")
local var15 = var1("#30562F")
local var16 = var1("#8C5B33")
local var17 = var1("#654022")
local var18 = var1("#C8994A")
local var19 = var1("#9BE7F5")
local var20 = var1("#E4776C")
local var21 = var1("#BF5850")
local var22 = var1("#233252")
local var23 = var1("#F6E8D6")
local var24 = var1("#CDD3DB")
local var25 = var1("#FFB067")
local var26 = var1("#22566A")
local var27 = var1("#173D4C")
local var28 = var1("#B8733A")
local var29 = var1("#DB9A5B")
local var30 = var1("#F2E8D5")
local var31 = var1("#FFB547")
local var32 = var1("#1B1F24")
local var33 = var1("#2B3036")
local var34 = var1("#434A53")
local var35 = var1("#D9A42B")
local var36 = var1("#A3ACB6")
local var37 = var1("#4FE3F0")
local var38 = var1("#FF9F3A")
local var39 = var1("#1F3157")
local var40 = var1("#15213D")
local var41 = var1("#DDAE45")
local var42 = var1("#F6D57E")
local var43 = var1("#71472A")
local var44 = var1("#4D301B")
local var45 = var1("#86EAF7")
local var46 = var1("#2C2828")
local var47 = var1("#1C1919")
local var48 = var1("#FF6A1F")
local var49 = var1("#8E1F14")
local var50 = var1("#E7A93A")
local var51 = var1("#FFB347")
local var52 = var1("#F1EFEA")
local var53 = var1("#C5D0DB")
local var54 = var1("#8C9CAD")
local var55 = var1("#141E3C")
local var56 = var1("#22305A")
local var57 = var1("#6FF0FF")
local var58 = var1("#A77BFF")
local var59 = var1("#CFF8FF")
local var60 = var1("#FFF4DE")
local var61 = var1("#E3B143")
local var62 = var1("#FFE08A")
local var63 = var1("#B7862A")
local var64 = var1("#1A1F2E")
local var65 = var1("#1E2A48")
local var66 = var1("#7FF3FF")
local var67 = CFrame.new
local tbl1 = {
	UpperTorso = { "UpperTorso", "Torso" },
	LowerTorso = { "LowerTorso", "Torso" },
	Head = { "Head" },
	LeftArm = { "LeftUpperArm", "Left Arm" },
	RightArm = { "RightUpperArm", "Right Arm" },
	LeftForearm = { "LeftLowerArm", "Left Arm" },
	RightForearm = { "RightLowerArm", "Right Arm" },
	LeftThigh = { "LeftUpperLeg", "Left Leg" },
	RightThigh = { "RightUpperLeg", "Right Leg" },
	LeftShin = { "LeftLowerLeg", "Left Leg" },
	RightShin = { "RightLowerLeg", "Right Leg" },
}

local tbl2 = {
	ModelName = "ClassLook",
	MinScale = 0.7,
	MaxScale = 1.35,
	MinFeature = 0.12,
	MinThickness = 0.04,
	MaxHeadroom = 1.1,
}

local function handleOn(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("Attachment") then
			continue
		end

		if not arg2[v1.Name] then
			continue
		end

		return true
	end

	return false
end

local tbl3 = { HatAttachment = true, HairAttachment = true }
local var68 = Vector3.new
local tbl4 = {
	Torso = {
		anchor = "UpperTorso",
		at = function()
			return var67()
		end,
	},
	Back = {
		anchor = "UpperTorso",
		at = function(arg1)
			local num1 = 0
			local var1 = 0.08 * arg1.Size.Y
			local var2 = arg1.Size.Z / 2
			return var67(num1, var1, var2)
		end,
	},
	Chest = {
		anchor = "UpperTorso",
		at = function(arg1)
			local num1 = 0
			local var1 = 0.14 * arg1.Size.Y
			local var2 = -arg1.Size.Z / 2
			return var67(num1, var1, var2)
		end,
	},
	Collar = {
		anchor = "UpperTorso",
		at = function(arg1)
			local num1 = 0
			local var1 = 0.42 * arg1.Size.Y
			local var2 = -arg1.Size.Z / 2
			return var67(num1, var1, var2)
		end,
	},
	Crest = {
		anchor = "UpperTorso",
		at = function(arg1)
			local num1 = 0
			local var1 = 0.44 * arg1.Size.Y
			local var2 = arg1.Size.Z / 2
			return var67(num1, var1, var2)
		end,
	},
	Neck = {
		anchor = "UpperTorso",
		at = function(arg1)
			local num1 = 0
			local var1 = arg1.Size.Y / 2
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	ShoulderLeft = {
		anchor = "UpperTorso",
		at = function(arg1)
			local var1 = -arg1.Size.X / 2
			local var2 = 0.34 * arg1.Size.Y
			local num1 = 0
			return var67(var1, var2, num1)
		end,
	},
	ShoulderRight = {
		anchor = "UpperTorso",
		at = function(arg1)
			local var1 = arg1.Size.X / 2
			local var2 = 0.34 * arg1.Size.Y
			local num1 = 0
			return var67(var1, var2, num1)
		end,
	},
	PauldronLeft = {
		anchor = "LeftArm",
		at = function(arg1)
			local num1 = 0
			local var1 = arg1.Size.Y / 2
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	PauldronRight = {
		anchor = "RightArm",
		at = function(arg1)
			local num1 = 0
			local var1 = arg1.Size.Y / 2
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	Waist = {
		anchor = "LowerTorso",
		at = function(arg1)
			local var1
			local var2
			if arg1.Name == "Torso" then
				var1 = -arg1.Size.Y * 0.4
				var2 = arg1.Size.Y * 0.2
			else
				var1 = 0
				var2 = arg1.Size.Y
			end

			local num1 = 0
			local var3 = var1 + 0.16 * var2
			local num2 = 0
			return var67(num1, var3, num2)
		end,
	},
	HipLeft = {
		anchor = "LowerTorso",
		at = function(arg1)
			local var1
			local var2
			if arg1.Name == "Torso" then
				var1 = -arg1.Size.Y * 0.4
				var2 = arg1.Size.Y * 0.2
			else
				var1 = 0
				var2 = arg1.Size.Y
			end

			local var3 = -arg1.Size.X / 2
			local var4 = var1 - 0.04 * var2
			local num1 = 0
			return var67(var3, var4, num1)
		end,
	},
	HipRight = {
		anchor = "LowerTorso",
		at = function(arg1)
			local var1
			local var2
			if arg1.Name == "Torso" then
				var1 = -arg1.Size.Y * 0.4
				var2 = arg1.Size.Y * 0.2
			else
				var1 = 0
				var2 = arg1.Size.Y
			end

			local var3 = arg1.Size.X / 2
			local var4 = var1 - 0.04 * var2
			local num1 = 0
			return var67(var3, var4, num1)
		end,
	},
	HipBack = {
		anchor = "LowerTorso",
		at = function(arg1)
			local var1
			local var2
			if arg1.Name == "Torso" then
				var1 = -arg1.Size.Y * 0.4
				var2 = arg1.Size.Y * 0.2
			else
				var1 = 0
				var2 = arg1.Size.Y
			end

			local num1 = 0
			local var3 = var1 - 0.04 * var2
			local var4 = arg1.Size.Z / 2
			return var67(num1, var3, var4)
		end,
	},
	HipFront = {
		anchor = "LowerTorso",
		at = function(arg1)
			local var1
			if arg1.Name == "Torso" then
				var1 = -arg1.Size.Y * 0.4
				local var2 = arg1.Size.Y * 0.2
			else
				var1 = 0
				local var3 = arg1.Size.Y
			end

			local num1 = 0
			local var4 = var1
			local var5 = -arg1.Size.Z / 2
			return var67(num1, var4, var5)
		end,
	},
	Crown = {
		anchor = "Head",
		at = function(_, arg2)
			local num1 = 0
			local var1 = arg2.headTop()
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	Halo = {
		anchor = "Head",
		at = function(arg1)
			local num1 = 0
			local var1 = arg1.Size.Y / 2 + 0.52
			local num2 = 0.22
			return var67(num1, var1, num2)
		end,
	},
	LeftArm = {
		anchor = "LeftArm",
		at = function()
			return var67()
		end,
	},
	RightArm = {
		anchor = "RightArm",
		at = function()
			return var67()
		end,
	},
	LeftWrist = {
		anchor = "LeftForearm",
		at = function(arg1)
			local num1 = 0
			local var1 = -0.3 * arg1.Size.Y
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	RightWrist = {
		anchor = "RightForearm",
		at = function(arg1)
			local num1 = 0
			local var1 = -0.3 * arg1.Size.Y
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	LeftForearm = {
		anchor = "LeftForearm",
		at = function()
			return var67()
		end,
	},
	RightForearm = {
		anchor = "RightForearm",
		at = function()
			return var67()
		end,
	},
	LeftThigh = {
		anchor = "LeftThigh",
		at = function()
			return var67()
		end,
	},
	RightThigh = {
		anchor = "RightThigh",
		at = function()
			return var67()
		end,
	},
	LeftShin = {
		anchor = "LeftShin",
		at = function()
			return var67()
		end,
	},
	RightShin = {
		anchor = "RightShin",
		at = function()
			return var67()
		end,
	},
	LeftAnkle = {
		anchor = "LeftShin",
		at = function(arg1)
			local num1 = 0
			local var1 = -0.32 * arg1.Size.Y
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
	RightAnkle = {
		anchor = "RightShin",
		at = function(arg1)
			local num1 = 0
			local var1 = -0.32 * arg1.Size.Y
			local num2 = 0
			return var67(num1, var1, num2)
		end,
	},
}

local var69 = Enum.Material
local var70 = CFrame.Angles
local function cyl(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	local var1
	if arg9 == "Y" then
		var1 = var70(0, 0, 1.5707963267948966)
	elseif arg9 == "Z" then
		var1 = var70(0, 1.5707963267948966, 0)
	else
		var1 = var67()
	end

	local var2 = var68(arg5, arg6, arg6)
	local var3 = arg8
	local var4 = table.clone(var3 or {})
	local var5 = arg1.piece
	local var6 = arg2
	local var7 = arg3
	local var8 = arg4 * var1
	local var9 = arg7
	for k1, v1 in pairs({ Shape = Enum.PartType.Cylinder }) do
		var4[k1] = v1
	end

	return var5(var6, var7, var8, var2, var9, var4)
end

local function pyramid(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	for i1 = 0, 3 do
		local var1 = arg8
		local var2 = table.clone(var1 or {})
		local var3 = arg1.piece
		local var4 = arg2
		local var5 = arg3
		local var6 = arg4 * var70(0, i1 * 3.1415926535897931 / 2, 0) * var67(-arg5 / 4, 0, arg5 / 4)
		local var7 = var68(arg5 / 2, arg6, arg5 / 2)
		local var8 = arg7
		for k1, v1 in pairs({ Class = "CornerWedge", Fine = true }) do
			var2[k1] = v1
		end

		var3(var4, var5, var6, var7, var8, var2)
	end
end

local var71 = math.rad
local function band(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var2 = arg1.limb(arg2)
	if not var2 then
		return
	end

	local var3 = var2.Size.Z / arg1.scale + 2 * arg5
	local var4 = var2.Size.X / arg1.scale + 2 * arg5
	local var5 = 2 * arg5
	arg1.piece(arg2, arg3, var67(0, arg4, -var3 / 2 + arg5), var68(var4, arg6, var5), arg7, arg8)
	arg1.piece(arg2, arg3, var67(0, arg4, var3 / 2 - arg5), var68(var4, arg6, var5), arg7, arg8)
	arg1.piece(arg2, arg3, var67(-var4 / 2 + arg5, arg4, 0), var68(var5, arg6, var3), arg7, arg8)
	arg1.piece(arg2, arg3, var67(var4 / 2 - arg5, arg4, 0), var68(var5, arg6, var3), arg7, arg8)
end

local function emitter(arg1, arg2, arg3)
	local var1 = Instance.new("ParticleEmitter")
	var1.Name = arg2
	var1.Texture = arg3.Texture or "rbxasset://textures/particles/sparkles_main.dds"
	local var2 = arg3.Color
	local num1 = 1
	local num2 = 1
	local num3 = 1
	var2 = var2 or ColorSequence.new(Color3.new(num1, num2, num3))
	var1.Color = var2
	var1.LightEmission = arg3.LightEmission or 0.6
	var1.LightInfluence = 0
	var2 = arg3.Size
	var2 = var2 or NumberSequence.new(0.2, 0)
	var1.Size = var2
	var2 = arg3.Transparency
	var2 = var2 or NumberSequence.new(0.2, 1)
	var1.Transparency = var2
	var2 = arg3.Lifetime
	var2 = var2 or NumberRange.new(0.3, 0.5)
	var1.Lifetime = var2
	var2 = arg3.Speed
	var2 = var2 or NumberRange.new(0.4, 1)
	var1.Speed = var2
	var2 = arg3.SpreadAngle
	var2 = var2 or Vector2.new(18, 18)
	var1.SpreadAngle = var2
	var1.Acceleration = arg3.Acceleration or Vector3.new(0, 1.2, 0)
	var1.Rate = arg3.Rate or 0
	var1.Drag = arg3.Drag or 2
	var1.LockedToPart = arg3.LockedToPart == true
	if arg3.EmissionDirection then
		var1.EmissionDirection = arg3.EmissionDirection
	end

	var2 = false
	if arg3.Rate ~= nil then
		var2 = 0 < arg3.Rate
	end

	var1.Enabled = var2
	var1.Parent = arg1
	return var1
end

local tbl5 = { slot = "Chest", offset = var67(0.34, -0.26, -0.06) }
local function ringY(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13)
	local tbl1 = {}
	if arg10 then
		if arg10.Stagger then
			local var3 = 180 / arg6
			local var4 = arg10
			arg10 = table.clone(var4 or {})
			arg11 = (arg11 or 0) + var3
			arg12 = (arg12 or 360) + var3
			for k1, v1 in pairs({ Stagger = false }) do
				arg10[k1] = v1
			end
		end
	end

	arg12 = arg12 or 360
	arg11 = arg11 or 0
	local var5 = (arg12 - arg11) / arg6
	local var6 = 2 * arg5 * math.tan(var71(var5) / 2) * 1.08
	for i1 = 0, (if 359 <= arg12 - arg11 then arg6 else arg6 + 1) - 1 do
		local var7 = arg2
		local var8 = arg3
		local var9 = arg4 * var70(0, -var71(arg11 + i1 * var5), 0) * var67(0, 0, -arg5) * var70(var71(arg13 or 0), 0, 0)
		local var10 = var68(var6, arg7, arg8)
		local var11 = arg9
		local var12 = arg10
		table.insert(tbl1, arg1.piece(var7, var8, var9, var10, var11, var12))
	end

	return tbl1
end

local function cuffs(arg1, arg2, arg3, arg4, arg5)
	local str1 = "RightWrist"
	for k1, v1 in ipairs({ "LeftWrist", str1 }) do
		band(arg1, v1, arg2, 0.04, 0.07, 0.3, arg3)
		band(arg1, v1, arg2 .. "Trim", -0.14, 0.105, 0.12, arg4)
		if not arg5 then
			continue
		end

		arg5(v1, (arg1.half(v1)))
	end
end

local function box(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg7 or 0.05
	local var2 = if arg8 and arg8.Fine then 0.03 else tbl2.MinFeature
	local var3 = math.clamp((arg5.Y - var2) / 2, 0, var1)
	local var4 = math.clamp((arg5.Z - var2) / 2, 0, var1)
	arg1.piece(arg2, arg3, arg4, var68(arg5.X, arg5.Y - var3 * 2, arg5.Z - var4 * 2), arg6, arg8)
	local var5 = math.clamp((arg5.X - var2) / 2, 0, var1)
	arg1.piece(arg2, arg3, arg4, var68(arg5.X - var5 * 2, arg5.Y, arg5.Z - var4 * 2), arg6, arg8)
	local var6 = arg2
	local var7 = arg3
	local var8 = arg4
	local var9 = var68(arg5.X - var5 * 2, arg5.Y - var3 * 2, arg5.Z)
	local var10 = arg6
	local var11 = arg8
	return arg1.piece(var6, var7, var8, var9, var10, var11)
end

local tbl6 = { Mark = tbl5 }
tbl6.build = function(arg1)
	local var1 = arg1.headWidth() * 0.5 + 0.04
	local var4 = arg1.half("Torso")
	local var7 = var67(0, 0.05, 0)
	ringY(arg1, "Neck", "Warmer", var7, var1, 14, 0.24, 0.2, var5, { Material = var69.Fabric })
	var7 = var67(0, 0.18, 0)
	ringY(arg1, "Neck", "WarmerRib", var7, var1 + 0.035, 14, 0.12, 0.22, var6, { Material = var69.Fabric, Stagger = true })
	var7 = var67(0, -0.07, 0)
	ringY(arg1, "Neck", "WarmerRib", var7, var1 + 0.05, 14, 0.12, 0.22, var6, { Material = var69.Fabric, Stagger = true })
	local var8 = var67(0.31, var4.Y - 0.15, -var4.Z - 0.21)
	arg1.piece("Torso", "Knot", var8, Vector3.new(0.32, 0.26, 0.2), var5, { Material = var69.Fabric })
	var8 = var67(0.36, var4.Y - 0.44, -var4.Z - 0.08) * var70(0, 0, -0.13962634015954636)
	arg1.piece("Torso", "Tail", var8, Vector3.new(0.26, 0.5, 0.12), var5, { Material = var69.Fabric })
	var8 = var67(0.39, var4.Y - 0.58, -var4.Z - 0.16) * var70(0, 0, -0.13962634015954636)
	arg1.piece("Torso", "TailStripe", var8, Vector3.new(0.27, 0.12, 0.04), var2, { Material = var69.Fabric })
	var8 = var67(0.2, var4.Y - 0.36, -var4.Z - 0.1) * var70(0, 0, 0.20943951023931956)
	arg1.piece("Torso", "Tail", var8, Vector3.new(0.22, 0.36, 0.12), var6, { Material = var69.Fabric })
	local var9 = var67(-0.46, 0.2, -var4.Z - 0.04)
	cyl(arg1, "Torso", "BadgeRim", var9, 0.08, 0.5, var3, nil, "Z")
	cyl(arg1, "Torso", "Badge", var9 * var67(0, 0, -0.04), 0.06, 0.4, var2, nil, "Z")
	for i1 = 0, 2 do
		arg1.piece("Torso", "Flake", var9 * var67(0, 0, -0.08) * var70(0, 0, (var71(i1 * 60))), Vector3.new(0.07, 0.3, 0.04), var6)
	end

	cuffs(arg1, "Cuff", var5, var2)
	local var10 = var67(0.56, -0.02, -0.14)
	box(arg1, "HipFront", "Pouch", var10, Vector3.new(0.36, 0.34, 0.24), var6, 0.04, { Material = var69.Fabric })
	arg1.piece("HipFront", "PouchFlap", var67(0.56, 0.12, -0.2), Vector3.new(0.42, 0.14, 0.2), var2)
	arg1.piece("HipFront", "PouchSnap", var67(0.56, 0.06, -0.32), Vector3.new(0.1, 0.1, 0.04), var3)
	arg1.piece("HipFront", "PouchLoop", var67(0.56, 0.2, -0.05), Vector3.new(0.16, 0.16, 0.1), var3)
end

local tbl7 = { Starter = tbl6 }
tbl5 = { slot = "Chest", offset = var67(-0.36, -0.36, -0.14) }
local function overShoulder(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg1.half("Torso")
	arg1.piece("Torso", arg2, var67(arg3, var1.Y + 0.06, 0), var68(arg4, 0.12, 2 * var1.Z + 0.24), arg7, arg8)
	arg1.piece("Torso", arg2, var67(arg3, var1.Y - arg5 / 2, -var1.Z - 0.06), var68(arg4, arg5, 0.12), arg7, arg8)
	arg1.piece("Torso", arg2, var67(arg3, var1.Y - arg6 / 2, var1.Z + 0.06), var68(arg4, arg6, 0.12), arg7, arg8)
end

tbl6 = { Mark = tbl5, Back = true, Animated = true }
tbl6.build = function(arg1)
	local num1 = 1
	local var3 = arg1.half("Torso")
	for k1, v1 in ipairs({ -1, num1 }) do
		overShoulder(arg1, "Strap", v1 * 0.5, 0.24, 0.72, 0.4, var9, { Material = var69.Fabric })
	end

	local var4 = var67(0, var3.Y - 0.72, -var3.Z - 0.08)
	arg1.piece("Torso", "ChestStrap", var4, Vector3.new(1.06, 0.18, 0.12), var9, { Material = var69.Fabric })
	local var5 = var67(0.6, var3.Y - 0.5, -var3.Z - 0.16)
	box(arg1, "Torso", "Module", var5, Vector3.new(0.38, 0.34, 0.16), var8, 0.04)
	local var6 = var5 * var67(0, -0.03, -0.08)
	local tbl1 = { A = var11, B = var1("#FFE9A6"), W = 2.2 }
	arg1.piece("Torso", "ModuleWindow", var6, Vector3.new(0.22, 0.12, 0.04), var11, { Material = var69.Neon, Fx = "Breathe", FxArgs = tbl1 })
	arg1.piece("Torso", "ModuleCap", var5 * var67(0, 0.2, -0.01), Vector3.new(0.22, 0.08, 0.13), var2)
	cuffs(arg1, "Cuff", var9, var7, function(arg1, arg2)
		box(arg1, arg1, "CuffPlate", var67(0, 0.04, -arg2.Z - 0.1), Vector3.new(0.4, 0.26, 0.1), var8, 0.03)
		local var1 = var67(0, 0.04, -arg2.Z - 0.16)
		arg1.piece(arg1, "CuffLight", var1, Vector3.new(0.18, 0.08, 0.04), var11, { Material = var69.Neon })
	end)

	if arg1.compact then
		local var13 = var67(0.62, 0, 0.3)
		box(arg1, "HipBack", "Cradle", var13, Vector3.new(0.46, 0.46, 0.26), var9, 0.04)
		local num2 = -0.1
		local num3 = 0.1
		for k2, v2 in ipairs({ num2, num3 }) do
			cyl(arg1, "HipBack", "Cell", var13 * var67(v2, 0.02, 0.1), 0.4, 0.18, var7, nil, "Y")
			local var14 = var13 * var67(v2, -0.12, 0.2)
			arg1.piece("HipBack", "Charge" .. k2, var14, Vector3.new(0.12, 0.12, 0.04), var11, { Material = var69.Neon, Fx = "Charge", FxArgs = { Index = k2 } })
		end

		local var15 = var13 * var67(0, 0.18, 0.18)
		arg1.piece("HipBack", "Charge3", var15, Vector3.new(0.26, 0.12, 0.04), var11, { Material = var69.Neon, Fx = "Charge", FxArgs = { Index = 3 } })
		return
	end

	local var16 = var67(0, -0.04, 0.3)
	box(arg1, "Back", "BackPlate", var16 * var67(0, 0, -0.18), Vector3.new(1, 1, 0.14), var9, 0.05)
	box(arg1, "Back", "Tray", var16 * var67(0, -0.5, 0.04), Vector3.new(1.06, 0.2, 0.5), var10, 0.06)
	box(arg1, "Back", "TopBracket", var16 * var67(0, 0.52, 0.04), Vector3.new(1.06, 0.14, 0.5), var10, 0.05)
	arg1.piece("Back", "TrayStripe", var16 * var67(0, -0.5, 0.29), Vector3.new(0.9, 0.06, 0.04), var11)
	local num4 = 1
	for k3, v3 in ipairs({ -1, num4 }) do
		box(arg1, "Back", "SideRail", var16 * var67(v3 * 0.5, 0.01, 0.04), Vector3.new(0.1, 0.9, 0.48), var9, 0.03)
	end

	local num5 = 1
	for k4, v4 in ipairs({ -1, num5 }) do
		local var17 = var16 * var67(v4 * 0.27, 0.01, 0.06)
		cyl(arg1, "Back", "Cell", var17, 0.84, 0.44, var7, nil, "Y")
		local num6 = 0.22
		for k5, v5 in ipairs({ -0.24, num6 }) do
			local str1 = "Y"
			cyl(arg1, "Back", "Clamp", var17 * var67(0, v5, 0), 0.08, 0.48, var9, nil, str1)
		end

		cyl(arg1, "Back", "CellCap", var17 * var67(0, 0.42, 0), 0.06, 0.38, var2, nil, "Y")
		local var18 = var17 * var67(0, 0.52, 0)
		tbl1 = cyl
		local var19 = arg1
		local str2 = "Back"
		local str3 = "Terminal"
		local num7 = 0.12
		local num8 = 0.16
		local var20 = var11
		local var21 = table.clone({})
		local var22 = var11
		for k6, v6 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var21[k6] = v6
		end

		tbl1(var19, str2, str3, var18, num7, num8, var20, var21, "Y")
		arg1.piece("Back", "CellShine", var17 * var67(v4 * 0.1, 0, 0.19), Vector3.new(0.05, 0.36, 0.04), var1("#5FB3B3"), { Fine = true })
	end

	arg1.piece("Back", "Handle", var16 * var67(0, 0.72, 0.04), Vector3.new(0.44, 0.1, 0.12), var2)
	local num9 = 1
	for k7, v7 in ipairs({ -1, num9 }) do
		arg1.piece("Back", "Handle", var16 * var67(v7 * 0.21, 0.64, 0.04), Vector3.new(0.1, 0.18, 0.12), var2)
	end

	box(arg1, "Back", "Display", var16 * var67(0, 0.01, 0.26), Vector3.new(0.2, 0.7, 0.1), var9, 0.03)
	local var23 = var16 * var67(0, 0.3, 0.32) * var70(0, 0, -0.3490658503988659)
	arg1.piece("Back", "DisplayBolt", var23, Vector3.new(0.06, 0.14, 0.03), var11, { Material = var69.Neon, Fine = true })
	for i1 = 1, 3 do
		tbl1 = var16 * var67(0, (i1 - 1) * 0.17 + -0.24, 0.32)
		arg1.piece("Back", "Charge" .. i1, tbl1, Vector3.new(0.13, 0.13, 0.04), var11, { Material = var69.Neon, Fx = "Charge", FxArgs = { Index = i1 } })
	end

	box(arg1, "Torso", "CablePort", var67(0.58, var3.Y - 0.3, var3.Z + 0.24), Vector3.new(0.16, 0.18, 0.2), var10, 0.03)
	var4 = var3.Y + 0.14
	local var24 = var3.Z + 0.18
	arg1.piece("Torso", "Cable", var67(0.66, (var4 + var3.Y - 0.3) / 2, var24), var68(0.12, var4 - var3.Y + 0.3, 0.12), var10)
	var23 = -var3.Z - 0.14
	arg1.piece("Torso", "Cable", var67(0.66, var4, (var24 + var23) / 2), var68(0.12, 0.12, var24 - var23), var10)
	local var25 = var3.Y - 0.28
	arg1.piece("Torso", "Cable", var67(0.66, (var4 + var25) / 2, var23), var68(0.12, var4 - var25, 0.12), var10)
	local var26 = var67(0.66, var4, 0)
	local tbl2 = { Material = var69.Neon, Hub = var67(), Fx = "Pulse" }
	local tbl3 = { P1 = var67(0.66, var3.Y - 0.3, var24), W = 0.4 }
	tbl3.P2 = var67(0.66, var4, var24)
	tbl3.P3 = var67(0.66, var4, var23)
	tbl3.P4 = var67(0.66, var25, var23)
	tbl2.FxArgs = tbl3
	arg1.piece("Torso", "CablePulse", var26, Vector3.new(0.15, 0.15, 0.15), var11, tbl2)
end

tbl7.Powerbank = tbl6
tbl5 = { slot = "Chest", offset = var67(-0.4, 0.08, -0.12) }
local function strap(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
	local var1 = (arg4 + arg5) / 2
	local var2 = arg5 - arg4
	local var3 = arg2
	local var4 = arg3
	local var5 = var67(var1.X, var1.Y, arg6) * var70(0, 0, (math.atan2(var2.Y, var2.X)))
	local var6 = var68(var2.Magnitude, arg7, arg8)
	local var7 = arg9
	local var8 = arg10
	return arg1.piece(var3, var4, var5, var6, var7, var8)
end

tbl6 = { Mark = tbl5 }
tbl6.build = function(arg1)
	local var2 = arg1.headWidth() * 0.5 + 0.06
	local var3 = arg1.half("Torso")
	local var4 = var67(0, 0.08, 0)
	ringY(arg1, "Neck", "Collar", var4, var2, 14, 0.26, 0.14, var14, { Material = var69.Fabric }, nil, nil, -16)
	var4 = var67(0, 0.22, 0)
	ringY(arg1, "Neck", "CollarEdge", var4, var2 + 0.05, 14, 0.12, 0.17, var15, { Material = var69.Fabric, Stagger = true }, nil, nil, -16)
	local var5 = var67(-var3.X - 0.14, var3.Y - 0.02, 0)
	local var6 = var68(0.8, 0.36, 2 * var3.Z + 0.2)
	local tbl1 = { Material = var69.Fabric }
	local var7 = table.clone(tbl1 or {})
	var4 = arg1.piece
	local str1 = "Torso"
	local str2 = "Shoulder"
	local var8 = var5
	local var9 = var6
	local var10 = var14
	for k1, v1 in pairs({ Mesh = "Sphere" }) do
		var7[k1] = v1
	end

	var4(str1, str2, var8, var9, var10, var7)
	local var11 = var67(-0.52, var3.Y + 0.06, 0)
	var4 = var68(0.26, 0.12, 2 * var3.Z + 0.24)
	arg1.piece("Torso", "Harness", var11, var4, var16, { Material = var69.Leather })
	var4 = Vector2.new(-0.52, var3.Y)
	str1 = Vector2.new(0.78, -var3.Y - 0.1)
	strap(arg1, "Torso", "Harness", var4, str1, -var3.Z - 0.06, 0.26, 0.12, var16, { Material = var69.Leather })
	var4 = Vector2.new(-0.52, var3.Y)
	str1 = Vector2.new(0.78, -var3.Y - 0.1)
	strap(arg1, "Torso", "Harness", var4, str1, var3.Z + 0.06, 0.26, 0.12, var16, { Material = var69.Leather })
	var5 = (Vector2.new(0.78, -var3.Y - 0.1) - Vector2.new(-0.52, var3.Y)).Unit
	str1 = 0.62
	str2 = 1.02
	for k2, v2 in ipairs({ str1, str2 }) do
		var9 = Vector2.new(-0.52, var3.Y) + var5 * v2
		var8 = var67(var9.X, var9.Y, -var3.Z - 0.2)
		local var12 = var8 * var67(0, 0, 0.08)
		arg1.piece("Torso", "VialClip", var12, Vector3.new(0.24, 0.14, 0.1), var17, { Material = var69.Leather })
		local var13 = var8 * var67(0, 0.02, -0.02)
		cyl(arg1, "Torso", "Vial", var13, 0.34, 0.18, var19, { Material = var69.Glass, Transparency = 0.25 }, "Y")
		var9 = cyl
		var10 = arg1
		var7 = "Torso"
		var12 = "VialLid"
		var13 = var8 * var67(0, 0.22, -0.02)
		tbl1 = 0.08
		local num1 = 0.2
		local tbl2 = { Material = var69.Metal, Reflectance = 0.06 }
		local var20 = if k2 == 1 then var18 else var17
		local var21 = table.clone({})
		local var22 = var18
		for k3, v3 in pairs(tbl2) do
			var21[k3] = v3
		end

		var22 = "Y"
		var9(var10, var7, var12, var13, tbl1, num1, var20, var21, var22)
	end

	var4 = Vector2.new(-0.52, var3.Y) + var5 * 1.5
	var11 = var67(var4.X, var4.Y, -var3.Z - 0.2)
	local var23 = var11 * var67(0.02, 0.04, -0.06)
	local var24 = var23 * var67(0, 0, 0.14)
	arg1.piece("Torso", "CanisterClip", var24, Vector3.new(0.34, 0.2, 0.1), var17, { Material = var69.Leather })
	var7 = var1("#E6F7FB")
	cyl(arg1, "Torso", "Canister", var23, 0.46, 0.3, var7, { Material = var69.Glass, Transparency = 0.45 }, "Y")
	var8 = var23 * var67(0, 0.26, 0)
	var11 = cyl
	var4 = arg1
	local str3 = "Torso"
	var24 = "CanisterCap"
	var9 = 0.08
	var10 = 0.34
	var7 = var18
	local var25 = table.clone({})
	local var26 = var18
	for k4, v4 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var25[k4] = v4
	end

	var11(var4, str3, var24, var8, var9, var10, var7, var25, "Y")
	var8 = var23 * var67(0, -0.26, 0)
	var11 = cyl
	var4 = arg1
	str3 = "Torso"
	var24 = "CanisterCap"
	var9 = 0.08
	var10 = 0.34
	var7 = var18
	var25 = table.clone({})
	var26 = var18
	for k5, v5 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var25[k5] = v5
	end

	var11(var4, str3, var24, var8, var9, var10, var7, var25, "Y")
	arg1.piece("Torso", "Specimen", var23 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.14, 0.14, 0.14), var19, { Material = var69.Neon, Transparency = 0.1 })
	var24 = var67(0.7, -var3.Y + 0.02, -var3.Z - 0.12)
	var11 = arg1.piece
	var4 = "Torso"
	str3 = "Buckle"
	var8 = Vector3.new(0.22, 0.2, 0.08)
	var9 = var18
	var10 = table.clone({})
	var7 = var18
	for k6, v6 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var10[k6] = v6
	end

	var11(var4, str3, var24, var8, var9, var10)
	var11 = var67(0.6, -0.1, 0.2) * var70(0, 0.52359877559829882, 0)
	box(arg1, "HipBack", "Satchel", var11, Vector3.new(0.64, 0.56, 0.3), var16, 0.06, { Material = var69.Leather })
	var8 = var11 * var67(0, 0.16, 0.1)
	arg1.piece("HipBack", "Flap", var8, Vector3.new(0.68, 0.28, 0.32), var15, { Material = var69.Fabric })
	var8 = var11 * var67(0, 0.31, 0.02)
	arg1.piece("HipBack", "FlapFold", var8, Vector3.new(0.7, 0.12, 0.34), var17, { Material = var69.Leather })
	var8 = var11 * var67(0, 0.04, 0.19)
	var4 = arg1.piece
	str3 = "HipBack"
	var24 = "Clasp"
	var9 = Vector3.new(0.16, 0.16, 0.08)
	var10 = var18
	var7 = table.clone({})
	var25 = var18
	for k7, v7 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var7[k7] = v7
	end

	var4(str3, var24, var8, var9, var10, var7)
	arg1.piece("HipBack", "SatchelStitch", var11 * var67(0, -0.2, 0.155), Vector3.new(0.5, 0.04, 0.02), var18, { Fine = true })
	var8 = var67(0.46, 0.3, 0.04) * var70(0, 0, -0.52359877559829882)
	arg1.piece("HipBack", "SatchelStrap", var8, Vector3.new(0.16, 0.44, 0.12), var16, { Material = var69.Leather })
end

tbl7.NoviceCollector = tbl6
tbl5 = { slot = "HipFront", offset = var67(-0.3, 0.2, -0.16) }
local function ringZ(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
	local tbl1 = {}
	if arg10 then
		if arg10.Stagger then
			local var3 = 180 / arg6
			local var4 = arg10
			arg10 = table.clone(var4 or {})
			arg11 = (arg11 or 0) + var3
			arg12 = (arg12 or 360) + var3
			for k1, v1 in pairs({ Stagger = false }) do
				arg10[k1] = v1
			end
		end
	end

	arg12 = arg12 or 360
	arg11 = arg11 or 0
	local var5 = (arg12 - arg11) / arg6
	local var6 = 2 * arg5 * math.tan(var71(var5) / 2) * 1.08
	for i1 = 0, (if 359 <= arg12 - arg11 then arg6 else arg6 + 1) - 1 do
		local var7 = arg2
		local var8 = arg3
		local var9 = arg4 * var70(0, 0, -var71(arg11 + i1 * var5)) * var67(0, arg5, 0)
		local var10 = var68(var6, arg7, arg8)
		local var11 = arg9
		local var12 = arg10
		table.insert(tbl1, arg1.piece(var7, var8, var9, var10, var11, var12))
	end

	return tbl1
end

tbl6 = { Mark = tbl5 }
tbl6.build = function(arg1)
	local var1 = arg1.headWidth() * 0.5 + 0.03
	local var2 = arg1.half("Torso")
	local var3 = var67(0, 0.04, 0)
	ringY(arg1, "Neck", "Scarf", var3, var1, 14, 0.16, 0.14, var20, { Material = var69.Fabric })
	var3 = var67(0, -0.07, 0)
	ringY(arg1, "Neck", "ScarfEdge", var3, var1 + 0.03, 14, 0.06, 0.16, var23, { Material = var69.Fabric, Fine = true, Stagger = true })
	local var4 = var67(-0.34, var2.Y - 0.06, -var2.Z - 0.14)
	box(arg1, "Torso", "BowKnot", var4, Vector3.new(0.16, 0.16, 0.14), var21, 0.03, { Material = var69.Fabric })
	local num1 = 1
	for k1, v1 in ipairs({ -1, num1 }) do
		local var5 = var4 * var67(v1 * 0.19, 0.02, 0.01) * var70(0, 0, (var71(v1 * -12)))
		local var6 = var5 * var67(0, 0.06, 0) * var70(0, v1 * 3.1415926535897931 / 2, 0)
		arg1.piece("Torso", "BowLoop", var6, Vector3.new(0.14, 0.12, 0.26), var20, { Class = "Wedge", Material = var69.Fabric })
		var6 = var5 * var67(0, -0.06, 0) * var70(3.1415926535897931, v1 * 3.1415926535897931 / 2, 0)
		arg1.piece("Torso", "BowLoop", var6, Vector3.new(0.14, 0.12, 0.26), var20, { Class = "Wedge", Material = var69.Fabric })
		local var7 = v1 * 14
		local var8 = var71(var7)
		var6 = var4 * var67(v1 * 0.07, -0.24, 0.02) * var70(0, 0, var8)
		arg1.piece("Torso", "BowTail", var6, Vector3.new(0.12, 0.34, 0.06), var20, { Material = var69.Fabric })
	end

	band(arg1, "Waist", "Waistband", 0, 0.085, 0.22, var22, { Material = var69.Fabric })
	local var9 = var67(0, 0.07, -0.12)
	local var10 = box
	local var11 = arg1
	local str1 = "HipFront"
	local str2 = "Buckle"
	local var12 = Vector3.new(0.26, 0.2, 0.06)
	local var13 = var24
	local num2 = 0.03
	local var14 = table.clone({})
	local var15 = var24
	for k2, v2 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var14[k2] = v2
	end

	var10(var11, str1, str2, var9, var12, var13, num2, var14)
	var10 = var67(0, -0.3, -0.09)
	arg1.piece("HipFront", "Apron", var10, Vector3.new(1.5, 0.66, 0.08), var23, { Material = var69.Fabric })
	var9 = var10 * var67(0, -0.33, 0)
	arg1.piece("HipFront", "ApronHem", var9, Vector3.new(1.52, 0.12, 0.1), var20, { Material = var69.Fabric })
	var12 = 1
	for k3, v3 in ipairs({ -1, var12 }) do
		var15 = var10 * var67(v3 * 0.75, 0, 0)
		arg1.piece("HipFront", "ApronEdge", var15, Vector3.new(0.12, 0.6, 0.12), var20, { Material = var69.Fabric })
	end

	local var16 = var10 * var67(-0.4, -0.06, -0.06)
	box(arg1, "HipFront", "Pocket", var16, Vector3.new(0.44, 0.34, 0.06), var20, 0.03, { Material = var69.Fabric })
	local var17 = var10 * var67(-0.4, 0.1, -0.09)
	arg1.piece("HipFront", "PocketLip", var17, Vector3.new(0.46, 0.08, 0.04), var22, { Material = var69.Fabric, Fine = true })
	var11 = var67(0, 0.06, 0.1)
	box(arg1, "HipBack", "TieKnot", var11, Vector3.new(0.14, 0.14, 0.12), var21, 0.03, { Material = var69.Fabric })
	var13 = 1
	for k4, v4 in ipairs({ -1, var13 }) do
		local var18 = var11 * var67(v4 * 0.16, 0.03, -0.035) * var70(0, 0, (var71(v4 * 20)))
		arg1.piece("HipBack", "TieLoop", var18, Vector3.new(0.24, 0.12, 0.08), var20, { Material = var69.Fabric })
		local var19 = v4 * 12
		var18 = var11 * var67(v4 * 0.08, -0.2, 0.01) * var70(0, 0, (var71(var19)))
		arg1.piece("HipBack", "TieEnd", var18, Vector3.new(0.1, 0.3, 0.06), var20, { Material = var69.Fabric })
	end

	str1 = var10 * var67(0.36, 0.02, -0.1)
	box(arg1, "HipFront", "Holster", str1, Vector3.new(0.48, 0.44, 0.14), var22, 0.04, { Material = var69.Leather })
	local var26 = str1 * var67(0, -0.12, -0.08)
	local tbl1 = { Fine = true }
	var15 = table.clone(tbl1 or {})
	str2 = arg1.piece
	var17 = "HipFront"
	local str3 = "HolsterRivet"
	num2 = Vector3.new(0.08, 0.08, 0.04)
	var14 = var24
	local var27 = var24
	for k5, v5 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var15[k5] = v5
	end

	str2(var17, str3, var26, num2, var14, var15)
	arg1.piece("HipFront", "Comb", str1 * var67(-0.14, 0.34, 0), Vector3.new(0.1, 0.4, 0.1), var21)
	for i1 = 0, 5 do
		arg1.piece("HipFront", "CombTooth", str1 * var67(-0.05, i1 * 0.058 + 0.25, 0), Vector3.new(0.12, 0.03, 0.08), var21, { Fine = true })
	end

	var26 = str1 * var67(0.12, 0.24, 0) * var70(0, 0, -0.069813170079773182)
	str2 = arg1.piece
	var17 = "HipFront"
	local str4 = "Scissors"
	num2 = Vector3.new(0.1, 0.3, 0.1)
	var14 = var24
	var15 = table.clone({})
	var27 = var24
	for k6, v6 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var15[k6] = v6
	end

	str2(var17, str4, var26, num2, var14, var15)
	num2 = 0.21
	for k7, v7 in ipairs({ 0.05, num2 }) do
		local var28 = str1 * var67(v7, 0.6, 0)
		local tbl2 = { Fine = true }
		local var29 = table.clone(tbl2 or {})
		var14 = ringZ
		var15 = arg1
		var27 = "HipFront"
		local str5 = "ScissorRing"
		local num3 = 0.08
		tbl1 = 6
		local num4 = 0.05
		local num5 = 0.06
		local var30 = var24
		local var31 = var24
		for k8, v8 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var29[k8] = v8
		end

		var14(var15, var27, str5, var28, num3, tbl1, num4, num5, var30, var29)
	end

	str2 = var67(-0.6, -0.08, 0.24) * var70(0, -0.95993108859688125, 0)
	arg1.piece("HipBack", "DryerLoop", str2 * var67(0, 0.24, 0), Vector3.new(0.3, 0.12, 0.14), var22)
	cyl(arg1, "HipBack", "Dryer", str2 * var67(0, 0.06, 0), 0.52, 0.32, var20, nil, "Z")
	cyl(arg1, "HipBack", "DryerNozzle", str2 * var67(0, 0.06, -0.32), 0.14, 0.2, var23, nil, "Z")
	var14 = str2 * var67(0, 0.06, 0.27)
	var17 = cyl
	str4 = arg1
	local str6 = "HipBack"
	local str7 = "DryerVent"
	var15 = 0.04
	var27 = 0.26
	local var32 = var24
	local var33 = table.clone({})
	local var34 = var24
	for k9, v9 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var33[k9] = v9
	end

	var17(str4, str6, str7, var14, var15, var27, var32, var33, "Z")
	box(arg1, "HipBack", "DryerGrip", str2 * var67(0, -0.2, 0.08) * var70(0.24434609527920614, 0, 0), Vector3.new(0.14, 0.36, 0.16), var22, 0.03)
	cuffs(arg1, "Cuff", var23, var20, function(arg1, arg2)
		local var1 = var67(0, 0.04, -arg2.Z - 0.1)
		arg1.piece(arg1, "CuffAccent", var1, Vector3.new(0.12, 0.12, 0.06), var25, { Material = var69.Neon })
	end)
end

tbl7.HairStylist = tbl6
tbl5 = { slot = "Chest", offset = var67(0.4, -0.38, -0.16) }
local function tank(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg6 - arg5 * 0.5
	cyl(arg1, arg2, arg3, arg4, var1, arg5, arg7, arg8, "Y")
	local var2 = arg8
	local var3 = table.clone(var2 or {})
	local var4 = arg1.piece
	local var5 = arg2
	local var6 = arg3
	local var7 = arg4 * var67(0, var1 / 2, 0)
	local var8 = var68(arg5, arg5 * 0.55, arg5)
	local var9 = arg7
	for k1, v1 in pairs({ Mesh = "Sphere" }) do
		var3[k1] = v1
	end

	var4(var5, var6, var7, var8, var9, var3)
	var2 = arg8
	var3 = table.clone(var2 or {})
	var4 = arg1.piece
	var5 = arg2
	var6 = arg3
	var7 = arg4 * var67(0, -var1 / 2, 0)
	var8 = var68(arg5, arg5 * 0.55, arg5)
	var9 = arg7
	for k2, v2 in pairs({ Mesh = "Sphere" }) do
		var3[k2] = v2
	end

	var4(var5, var6, var7, var8, var9, var3)
end

tbl6 = { Mark = tbl5, Back = true, Animated = true }
tbl6.build = function(arg1)
	local num1 = 1
	local var2 = arg1.half("Torso")
	for k1, v1 in ipairs({ -1, num1 }) do
		overShoulder(arg1, "Strap", v1 * 0.46, 0.26, 0.9, 0.5, var27, { Material = var69.Leather })
		local var3 = var67(v1 * 0.46, var2.Y - 0.62, -var2.Z - 0.14)
		local var4 = arg1.piece
		local str1 = "Torso"
		local str2 = "Buckle"
		local var5 = Vector3.new(0.24, 0.18, 0.06)
		local var6 = var28
		local var7 = table.clone({})
		local var8 = var28
		for k2, v2 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var7[k2] = v2
		end

		var4(str1, str2, var3, var5, var6, var7)
	end

	local var9 = var67(0, var2.Y - 0.62, -var2.Z - 0.08)
	arg1.piece("Torso", "ChestStrap", var9, Vector3.new(1, 0.2, 0.12), var27, { Material = var69.Leather })
	local var10 = var67(-0.46, var2.Y - 0.3, -var2.Z - 0.2)
	local var11 = var10 * var67(0, 0, 0.06)
	local var12 = cyl
	local var13 = arg1
	var9 = "Torso"
	local str3 = "GaugeBody"
	local num2 = 0.14
	local num3 = 0.42
	local var14 = var28
	local var15 = table.clone({})
	local var16 = var28
	for k3, v3 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var15[k3] = v3
	end

	var12(var13, var9, str3, var11, num2, num3, var14, var15, "Z")
	cyl(arg1, "Torso", "GaugeFace", var10 * var67(0, 0, -0.02), 0.04, 0.34, var30, nil, "Z")
	var11 = var10 * var67(0, 0, -0.05)
	ringZ(arg1, "Torso", "GaugeArc", var11, 0.12, 3, 0.05, 0.03, var31, { Material = var69.Neon }, 25, 85)
	var16 = 0
	var15 = var67(var16, 0, -0.075)
	str3 = var10 * var67(0, 0.06, -0.075)
	arg1.piece("Torso", "Needle", str3, Vector3.new(0.04, 0.14, 0.03), var32, {
		Hub = var10 * var15,
		Fx = "Needle",
		FxArgs = { Base = -0.3490658503988659, A = 0.48869219055841229, W = 0.9 },
	})

	var12 = var10 * var67(0, 0, -0.09)
	var13 = var28
	var9 = table.clone({})
	str3 = var28
	for k4, v4 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var9[k4] = v4
	end

	local var17 = var9
	local var18 = table.clone(var17 or {})
	str3 = arg1.piece
	var11 = "Torso"
	num2 = "NeedleHub"
	num3 = var12
	var14 = Vector3.new(0.12, 0.12, 0.12)
	local var19 = var13
	for k5, v5 in pairs({ Shape = Enum.PartType.Ball }) do
		var18[k5] = v5
	end

	str3(var11, num2, num3, var14, var19, var18)
	str3 = var67(-0.46, var2.Y + 0.05, -var2.Z - 0.14)
	var12 = arg1.piece
	var13 = "Torso"
	var9 = "GaugePipe"
	var11 = Vector3.new(0.12, 0.2, 0.12)
	num2 = var28
	num3 = table.clone({})
	var14 = var28
	for k6, v6 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		num3[k6] = v6
	end

	var12(var13, var9, str3, var11, num2, num3)
	cuffs(arg1, "Guard", var26, var28, function(arg1, arg2)
		box(arg1, arg1, "GuardPlate", var67(0, 0.1, -arg2.Z - 0.1), Vector3.new(0.44, 0.36, 0.1), var30, 0.04)
		local var1 = var67(0, 0.08, -arg2.Z - 0.16)
		arg1.piece(arg1, "GuardLight", var1, Vector3.new(0.14, 0.14, 0.04), var31, { Material = var69.Neon })
	end)

	if arg1.compact then
		var12 = var67(-0.62, 0, 0.4)
		tank(arg1, "HipBack", "Tank", var12, 0.28, 0.5, var26)
		var13 = cyl
		var9 = arg1
		str3 = "HipBack"
		var11 = "TankBand"
		num2 = var12
		num3 = 0.08
		var14 = 0.32
		var19 = var28
		var18 = table.clone({})
		local var20 = var28
		for k7, v7 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var18[k7] = v7
		end

		var13(var9, str3, var11, num2, num3, var14, var19, var18, "Y")
		var11 = var12 * var67(0, 0.32, 0)
		local tbl1 = { Fx = "Exhaust" }
		var14 = table.clone(tbl1 or {})
		var13 = arg1.piece
		var9 = "HipBack"
		str3 = "Exhaust"
		num2 = Vector3.new(0.14, 0.14, 0.14)
		num3 = var28
		var19 = var28
		for k8, v8 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var14[k8] = v8
		end

		var13(var9, str3, var11, num2, num3, var14)
		return
	end

	var12 = var67(0, -0.08, 0.3)
	box(arg1, "Back", "BackPlate", var12 * var67(0, 0, -0.18), Vector3.new(0.94, 1.06, 0.12), var27, 0.05)
	num2 = 1
	for k9, v9 in ipairs({ -1, num2 }) do
		num3 = var12 * var67(v9 * 0.23, 0, 0.04)
		tank(arg1, "Back", "Tank", num3, 0.42, 0.96, var26)
		local num4 = 0.2
		for k10, v10 in ipairs({ -0.22, num4 }) do
			local var21 = num3 * var67(0, v10, 0)
			local var22 = cyl
			local var23 = arg1
			local str4 = "Back"
			local str5 = "TankBand"
			local num5 = 0.08
			local num6 = 0.46
			local var24 = var28
			local var25 = table.clone({})
			local var33 = var28
			for k11, v11 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
				var25[k11] = v11
			end

			var22(var23, str4, str5, var21, num5, num6, var24, var25, "Y")
		end

		local str6 = "#4C8CA2"
		arg1.piece("Back", "TankShine", num3 * var67(-v9 * 0.08, 0.02, 0.2), Vector3.new(0.06, 0.4, 0.04), var1(str6))
		local var34 = num3 * var67(0, 0.54, 0)
		var14 = cyl
		var19 = arg1
		var18 = "Back"
		local str7 = "Pipe"
		local num7 = 0.24
		str6 = 0.12
		local var35 = var28
		local var36 = table.clone({})
		local var37 = var28
		for k12, v12 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var36[k12] = v12
		end

		var37 = "Y"
		var14(var19, var18, str7, var34, num7, str6, var35, var36, var37)
		var14 = num3 * var67(0, 0.68, 0)
		var19 = var29
		var18 = table.clone({})
		str7 = var29
		for k13, v13 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var18[k13] = v13
		end

		local var38 = var18
		local var39 = table.clone(var38 or {})
		str7 = arg1.piece
		var34 = "Back"
		num7 = "Elbow"
		str6 = var14
		var35 = Vector3.new(0.16, 0.16, 0.16)
		local var40 = var19
		for k14, v14 in pairs({ Shape = Enum.PartType.Ball }) do
			var39[k14] = v14
		end

		str7(var34, num7, str6, var35, var40, var39)
	end

	local var41 = var12 * var67(0, 0.6, 0.04)
	var13 = cyl
	var9 = arg1
	str3 = "Back"
	local str8 = "Manifold"
	num3 = 0.46
	var14 = 0.12
	var19 = var28
	var18 = table.clone({})
	local var42 = var28
	for k15, v15 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var18[k15] = v15
	end

	var13(var9, str3, str8, var41, num3, var14, var19, var18)
	var41 = var12 * var67(0, 0.6, 0.14)
	var13 = cyl
	var9 = arg1
	str3 = "Back"
	str8 = "Valve"
	num3 = 0.06
	var14 = 0.24
	var19 = var31
	var18 = table.clone({})
	var42 = var31
	for k16, v16 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var18[k16] = v16
	end

	var13(var9, str3, str8, var41, num3, var14, var19, var18, "Z")
	cyl(arg1, "Back", "ValveStem", var12 * var67(0, 0.6, 0.1), 0.08, 0.08, var32, nil, "Z")
	var41 = 1
	for k17, v17 in ipairs({ -1, var41 }) do
		num3 = var67(v17 * 0.7, var2.Y + 0.12, var2.Z + 0.2) * var70(-0.43633231299858238, 0, 0)
		var14 = cyl
		var19 = arg1
		var18 = "Torso"
		var42 = "Stack"
		local var43 = num3
		local num8 = 0.34
		local num9 = 0.16
		local var44 = var28
		local var45 = table.clone({})
		local var46 = var28
		for k18, v18 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var45[k18] = v18
		end

		var14(var19, var18, var42, var43, num8, num9, var44, var45, "Y")
		var43 = num3 * var67(0, 0.16, 0)
		var14 = cyl
		var19 = arg1
		var18 = "Torso"
		var42 = "StackCollar"
		num8 = 0.08
		num9 = 0.2
		var44 = var29
		var45 = table.clone({})
		var46 = var29
		for k19, v19 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var45[k19] = v19
		end

		var14(var19, var18, var42, var43, num8, num9, var44, var45, "Y")
		cyl(arg1, "Torso", "StackMouth", num3 * var67(0, 0.2, 0), 0.02, 0.12, var32, nil, "Y")
		var42 = var67(v17 * 0.45, var2.Y + 0.02, var2.Z + 0.22)
		var14 = arg1.piece
		var19 = "Torso"
		var18 = "StackPipe"
		var43 = Vector3.new(0.4, 0.12, 0.12)
		num8 = var28
		num9 = table.clone({})
		var44 = var28
		for k20, v20 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			num9[k20] = v20
		end

		var14(var19, var18, var42, var43, num8, num9)
		var14 = arg1.piece("Torso", "Exhaust", num3 * var67(0, 0.24, 0), Vector3.new(0.12, 0.12, 0.12), var32, { Transparency = 1, Fx = "Exhaust" })
		if not var14 then
			continue
		end

		var44 = "#F5FBFF"
		var43 = {
			Texture = "rbxasset://textures/particles/smoke_main.dds",
			Color = ColorSequence.new(var1(var44)),
			LightEmission = 0.15,
			Acceleration = Vector3.new(0, 1.5, 0),
			Drag = 3,
		}

		var46 = 1
		local num10 = 0.55
		var43.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.14), NumberSequenceKeypoint.new(var46, num10) })
		var46 = 1
		num10 = 1
		var43.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(var46, num10) })
		var43.Lifetime = NumberRange.new(0.35, 0.6)
		var43.Speed = NumberRange.new(1.2, 2)
		var43.SpreadAngle = Vector2.new(12, 12)
		emitter(var14, "Steam", var43)
	end
end

tbl7.SteamSpecialist = tbl6
tbl5 = { slot = "Chest", offset = var67(0.42, -0.4, -0.16) }
tbl6 = { Mark = tbl5, Back = true, Animated = true }
tbl6.build = function(arg1)
	local num1 = 1
	local var1 = arg1.half("Torso")
	for k1, v1 in ipairs({ -1, num1 }) do
		overShoulder(arg1, "Strap", v1 * 0.48, 0.26, 1.2, 0.5, var33, { Material = var69.Fabric })
		arg1.piece("Torso", "StrapEdge", var67(v1 * 0.48, var1.Y - 0.62, -var1.Z - 0.14), Vector3.new(0.28, 0.9, 0.04), var35)
		local var2 = var67(v1 * 0.48, var1.Y - 0.5, -var1.Z - 0.18)
		local var3 = box
		local var4 = arg1
		local str1 = "Torso"
		local str2 = "Fastener"
		local var5 = Vector3.new(0.3, 0.2, 0.08)
		local var6 = var36
		local num2 = 0.03
		local var7 = table.clone({})
		local var8 = var36
		for k2, v2 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var7[k2] = v2
		end

		var3(var4, str1, str2, var2, var5, var6, num2, var7)
	end

	local var9 = var67(0, var1.Y - 0.5, -var1.Z - 0.1)
	arg1.piece("Torso", "CrossStrap", var9, Vector3.new(0.72, 0.16, 0.1), var33, { Material = var69.Fabric })
	local var10 = arg1.headWidth() * 0.5 + 0.06
	ringY(arg1, "Neck", "Collar", var67(0, 0.12, 0.04), var10, 10, 0.3, 0.14, var34, nil, 100, 260, -8)
	ringY(arg1, "Neck", "CollarEdge", var67(0, 0.3, 0.04), var10 + 0.03, 8, 0.12, 0.17, var35, nil, 106, 254, -8)
	local var11 = arg1.half("PauldronRight")
	local var12 = arg1.piece
	local str3 = "PauldronRight"
	local str4 = "Guard"
	local var13 = var67(0.04, 0.04, 0)
	local var14 = var68(2 * var11.X + 0.16, 0.42, 2 * var11.Z + 0.16)
	local var15 = var34
	local var16 = table.clone({})
	for k3, v3 in pairs({ Mesh = "Sphere" }) do
		var16[k3] = v3
	end

	var12(str3, str4, var13, var14, var15, var16)
	box(arg1, "PauldronRight", "GuardEdge", var67(var11.X + 0.06, -0.12, 0), var68(0.12, 0.3, 2 * var11.Z + 0.1), var35, 0.03)
	box(arg1, "PauldronRight", "GuardRidge", var67(0.1, 0.24, 0), Vector3.new(0.5, 0.1, 0.16), var35, 0.03)
	var12 = var67(0.1, 0.2, -var11.Z * 0.6)
	arg1.piece("PauldronRight", "GuardLight", var12, Vector3.new(0.16, 0.08, 0.1), var37, { Material = var69.Neon, Fx = "Indicator", FxArgs = { Phase = 0 } })
	band(arg1, "Waist", "Belt", 0, 0.08, 0.26, var33)
	str3 = var67(0, 0.07, -0.12)
	local var17 = box
	var9 = arg1
	local str5 = "HipFront"
	var12 = "BeltBuckle"
	str4 = Vector3.new(0.28, 0.24, 0.08)
	var13 = var36
	var14 = 0.03
	var15 = table.clone({})
	var16 = var36
	for k4, v4 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var15[k4] = v4
	end

	var17(var9, str5, var12, str3, str4, var13, var14, var15)
	var17 = var67(0.62, -0.1, 0.18) * var70(0, 0.69813170079773179, 0.17453292519943295)
	var9 = arg1.piece
	str5 = "HipBack"
	var12 = "Wrench"
	str3 = var17
	str4 = Vector3.new(0.1, 0.44, 0.06)
	var13 = var36
	var14 = table.clone({})
	var15 = var36
	for k5, v5 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var14[k5] = v5
	end

	var9(str5, var12, str3, str4, var13, var14)
	str3 = var17 * var67(0, 0.24, 0)
	var9 = arg1.piece
	str5 = "HipBack"
	var12 = "WrenchJaw"
	str4 = Vector3.new(0.22, 0.12, 0.06)
	var13 = var36
	var14 = table.clone({})
	var15 = var36
	for k6, v6 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var14[k6] = v6
	end

	var9(str5, var12, str3, str4, var13, var14)
	arg1.piece("HipBack", "WrenchLoop", var67(0.6, 0.06, 0.1), Vector3.new(0.2, 0.14, 0.12), var33)
	var9 = var67(-0.6, -0.08, -0.12)
	box(arg1, "HipFront", "ProbeHolster", var9, Vector3.new(0.2, 0.32, 0.18), var34, 0.03)
	cyl(arg1, "HipFront", "Probe", var9 * var67(0, 0.24, 0), 0.24, 0.1, var35, nil, "Y")
	str4 = var9 * var67(0, 0.38, 0)
	arg1.piece("HipFront", "ProbeTip", str4, Vector3.new(0.06, 0.1, 0.06), var37, { Material = var69.Neon })
	band(arg1, "LeftForearm", "ModuleBand", -0.08, 0.06, 0.3, var33)
	var12 = var67(-arg1.half("LeftForearm").X - 0.08, -0.02, 0)
	box(arg1, "LeftForearm", "Module", var12, Vector3.new(0.14, 0.56, 0.62), var35, 0.03)
	var14 = var12 * var67(-0.075, 0.04, 0)
	arg1.piece("LeftForearm", "Screen", var14, Vector3.new(0.04, 0.34, 0.44), var37, { Material = var69.Neon, Fx = "Screen" })
	var14 = var12 * var67(-0.075, -0.21, 0.14)
	arg1.piece("LeftForearm", "Cuff", var14, Vector3.new(0.04, 0.08, 0.1), var37, { Material = var69.Neon })
	band(arg1, "RightWrist", "Cuff2", 0.04, 0.07, 0.28, var33)
	band(arg1, "RightWrist", "Cuff2Trim", -0.12, 0.09, 0.12, var35)
	if arg1.compact then
		str3 = var67(0.62, 0.02, 0.36)
		cyl(arg1, "HipBack", "CoreCap", str3 * var67(0, 0.2, 0), 0.08, 0.3, var34, nil, "Y")
		cyl(arg1, "HipBack", "CoreCap", str3 * var67(0, -0.2, 0), 0.08, 0.3, var34, nil, "Y")
		cyl(arg1, "HipBack", "Core", str3, 0.34, 0.18, var37, { Material = var69.Neon, Fx = "Core" }, "Y")
		return
	end

	str3 = var67(0, 0, 0.42)
	box(arg1, "Back", "Mount", str3 * var67(0, 0, -0.32), Vector3.new(0.86, 1.06, 0.12), var33, 0.05)
	arg1.piece("Back", "MountStripe", str3 * var67(0, -0.42, -0.245), Vector3.new(0.7, 0.08, 0.04), var35, { Fine = true })
	cyl(arg1, "Back", "CoreCap", str3 * var67(0, 0.44, 0), 0.16, 0.6, var34, nil, "Y")
	cyl(arg1, "Back", "CoreCap", str3 * var67(0, -0.44, 0), 0.16, 0.6, var34, nil, "Y")
	cyl(arg1, "Back", "CoreRim", str3 * var67(0, 0.35, 0), 0.05, 0.52, var35, nil, "Y")
	cyl(arg1, "Back", "CoreRim", str3 * var67(0, -0.35, 0), 0.05, 0.52, var35, nil, "Y")
	cyl(arg1, "Back", "Core", str3, 0.7, 0.36, var37, { Material = var69.Neon, Fx = "Core" }, "Y")
	for i1 = 0, 3 do
		var15 = var71(i1 * 90 + 45)
		local var18 = str3 * var67(math.sin(var15) * 0.23, 0, math.cos(var15) * 0.23)
		var16 = arg1.piece
		local str6 = "Back"
		local str7 = "CageBar"
		local var19 = Vector3.new(0.07, 0.74, 0.07)
		local var20 = var36
		local var21 = table.clone({})
		local var22 = var36
		for k7, v7 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var21[k7] = v7
		end

		var16(str6, str7, var18, var19, var20, var21)
	end

	arg1.piece("Back", "CoreArm", str3 * var67(0, 0, -0.22), Vector3.new(0.18, 0.56, 0.2), var34)
	var16 = 1
	for k8, v8 in ipairs({ -1, var16 }) do
		local var23 = str3 * var67(v8 * 0.48, 0.02, -0.1)
		local var24 = var36
		local var25 = table.clone({})
		local var26 = var36
		for k9, v9 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var25[k9] = v9
		end

		local var27 = var25
		local var28 = table.clone(var27 or {})
		var26 = arg1.piece
		local str8 = "Back"
		local str9 = "Hinge"
		local var29 = var23
		local var30 = Vector3.new(0.2, 0.2, 0.2)
		local var31 = var24
		for k10, v10 in pairs({ Shape = Enum.PartType.Ball }) do
			var28[k10] = v10
		end

		var26(str8, str9, var29, var30, var31, var28)
		box(arg1, "Back", "Brace", var23 * var67(-v8 * 0.04, 0.27, 0) * var70(0, 0, (var71(v8 * 10))), Vector3.new(0.16, 0.52, 0.16), var35, 0.03)
		var28 = 0
		local var32 = var71(-v8 * 10)
		box(arg1, "Back", "Brace", var23 * var67(-v8 * 0.04, -0.27, 0) * var70(0, var28, var32), Vector3.new(0.16, 0.52, 0.16), var35, 0.03)
		var24 = var23 * var67(-v8 * 0.12, 0.52, 0)
		var25 = var36
		var26 = table.clone({})
		str8 = var36
		for k11, v11 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var26[k11] = v11
		end

		local var38 = var26
		local var39 = table.clone(var38 or {})
		str8 = arg1.piece
		str9 = "Back"
		var29 = "Hinge"
		var30 = var24
		var31 = Vector3.new(0.16, 0.16, 0.16)
		local var40 = var25
		for k12, v12 in pairs({ Shape = Enum.PartType.Ball }) do
			var39[k12] = v12
		end

		str8(str9, var29, var30, var31, var40, var39)
		var24 = var23 * var67(-v8 * 0.12, -0.52, 0)
		var25 = var36
		var26 = table.clone({})
		str8 = var36
		for k13, v13 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var26[k13] = v13
		end

		var38 = var26
		local var41 = table.clone(var38 or {})
		str8 = arg1.piece
		str9 = "Back"
		var29 = "Hinge"
		var30 = var24
		var31 = Vector3.new(0.16, 0.16, 0.16)
		local var42 = var25
		for k14, v14 in pairs({ Shape = Enum.PartType.Ball }) do
			var41[k14] = v14
		end

		str8(str9, var29, var30, var31, var42, var41)
		str8 = var23 * var67(v8 * 0.02, 0.27, 0.09)
		var24 = arg1.piece
		var25 = "Back"
		var26 = "BraceLight"
		str9 = Vector3.new(0.06, 0.18, 0.04)
		var29 = var37
		var42 = if v8 < 0 then 0.5 else 1.5
		var31 = { Phase = var42 }
		var24(var25, var26, str8, str9, var29, { Material = var69.Neon, Fx = "Indicator", FxArgs = var31 })
	end
end

tbl7.Technician = tbl6
tbl5 = { slot = "Chest", offset = var67(-0.44, -0.46, -0.16) }
local function mantle(arg1, arg2, arg3)
	local var1 = arg1.half("Torso")
	local var2 = arg3.thickness or 0.16
	local var3 = var1.Y
	arg1.piece("Torso", arg2, var67(0, var3 + var2 / 2, var1.Z * 0.55), var68(2 * var1.X + 0.1, var2, var1.Z * 0.9 + var2), arg3.outer, arg3.options)
	arg1.piece("Torso", arg2, var67(0, var3 + var2 / 2, -var1.Z * 0.7), var68(2 * var1.X * 0.8, var2, var1.Z * 0.6 + var2), arg3.outer, arg3.options)
	local num1 = 1
	for k1, v1 in ipairs({ -1, num1 }) do
		local var4 = arg3.options
		local var5 = table.clone(var4 or {})
		local var6 = arg1.piece
		local str1 = "Torso"
		local var7 = arg2
		local var8 = var67(v1 * (var1.X + 0.22), var3 + 0.02, 0.02)
		local var9 = var68(1.02, 0.5, 2 * var1.Z + 0.32)
		local var10 = arg3.outer
		for k2, v2 in pairs({ Mesh = "Sphere" }) do
			var5[k2] = v2
		end

		var6(str1, var7, var8, var9, var10, var5)
		if not arg3.trim then
			continue
		end

		local var11 = arg3.trimOptions
		local var12 = table.clone(var11 or {})
		str1 = arg1.piece
		var7 = "Torso"
		var8 = arg2 .. "Trim"
		var9 = var67(v1 * (var1.X + 0.22), var3 - 0.08, 0.02)
		var10 = var68(1.08, 0.3, 2 * var1.Z + 0.38)
		var5 = arg3.trim
		for k3, v3 in pairs({ Mesh = "Sphere" }) do
			var12[k3] = v3
		end

		str1(var7, var8, var9, var10, var5, var12)
	end

	local var13 = var1.X / 0.97
	local num2 = 0.41887902047863912
	local var14 = arg3.length or 1.1
	local var15 = var71(arg3.lean or 7)
	local tbl2 = {
		{ 0, 0, 1 * var13, 0 },
		{ -0.76 * var13, -0.41887902047863912, 0.62 * var13, -1 },
		{ 0.76 * var13, num2, 0.62 * var13, 1 },
	}

	if arg3.split then
		num2 = { 0.8 * var13, 0.4537856055185257, 0.46 * var13, 1 }
		tbl2 = {
			{ -0.33 * var13, -0.087266462599716474, 0.5 * var13, -0.5 },
			{ 0.33 * var13, 0.087266462599716474, 0.5 * var13, 0.5 },
			{ -0.8 * var13, -0.4537856055185257, 0.46 * var13, -1 },
			num2,
		}

	end

	for k4, v4 in ipairs(tbl2) do
		local var16 = var67(v4[1], var3 - 0.02, var1.Z + var2 / 2 + 0.02) * var70(0, v4[2], 0) * var70(-var15, 0, 0)
		local var17 = v4[3]
		arg1.piece("Torso", arg2, var16 * var67(0, -var14 / 2, 0), var68(var17, var14, var2), arg3.outer, arg3.options)
		local var18 = v4[4]
		if arg3.lining then
			arg1.piece("Torso", arg2 .. "Lining", var16 * var67(0, -var14 / 2, -var2 / 2 - 0.02), var68(var17 - 0.08, var14 - 0.16, 0.06), arg3.lining, arg3.liningOptions)
		end

		if arg3.trim then
			arg1.piece("Torso", arg2 .. "Trim", var16 * var67(0, -var14 + 0.04, 0), var68(var17 + 0.06, 0.14, var2 + 0.06), arg3.trim, arg3.trimOptions)
		end

		if not arg3.panel then
			continue
		end

		arg3.panel(var16, var17, var14, var2, var18)
	end
end

local function crystal(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg6 * 0.18
	local var2 = arg6 * 0.36
	local var3 = arg4 * var67(0, (var1 - var2) / 2, 0) * var70(0, 0.78539816339744828, 0)
	local var4 = arg6 * 0.46
	local var5 = arg8
	local var6 = table.clone(var5 or {})
	local var7 = arg1.piece
	local var8 = arg2
	local var9 = arg3
	local var10 = var3
	local var11 = var68(arg5, var4, arg5)
	local var12 = arg7
	for k1, v1 in pairs({ Fine = true }) do
		var6[k1] = v1
	end

	var7(var8, var9, var10, var11, var12, var6)
	pyramid(arg1, arg2, arg3, var3 * var67(0, var4 / 2 + var2 / 2, 0), arg5, var2, arg7, arg8)
	pyramid(arg1, arg2, arg3, var3 * var67(0, -var4 / 2 - var1 / 2, 0) * var70(3.1415926535897931, 0, 0), arg5, var1, arg7, arg8)
end

tbl6 = { Mark = tbl5, Back = true, Animated = true }
tbl6.build = function(arg1)
	local var2 = arg1.half("Torso")
	local var3 = table.clone({})
	local var5 = var41
	for k1, v1 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var3[k1] = v1
	end

	mantle(arg1, "Mantle", {
		outer = var39,
		options = { Material = var69.Fabric },
		trim = var41,
		trimOptions = var3,
		length = 0.66,
		lean = 10,
	})

	local num1 = 1
	for k2, v2 in ipairs({ -1, num1 }) do
		local var6 = var3
		local var7 = table.clone(var6 or {})
		local var8 = arg1.piece
		local str1 = "Torso"
		local str2 = "MantleEdge"
		local var9 = var67(v2 * 0.42, var2.Y + 0.1, -var2.Z * 0.7 - 0.02) * var70(0, 0, (var71(v2 * 8)))
		local var10 = Vector3.new(0.7, 0.08, 0.1)
		local var11 = var41
		for k3, v3 in pairs({ Fine = true }) do
			var7[k3] = v3
		end

		var8(str1, str2, var9, var10, var11, var7)
	end

	local num2 = 1
	for k4, v4 in ipairs({ -1, num2 }) do
		local var12 = Vector2.new(v4 * 0.56, var2.Y + 0.02)
		local var13 = Vector2.new(v4 * 0.12, var2.Y - 0.64)
		strap(arg1, "Torso", "Harness", var12, var13, -var2.Z - 0.07, 0.24, 0.12, var43, { Material = var69.Leather })
		var12 = Vector2.new(v4 * 0.12, var2.Y - 0.9)
		var13 = Vector2.new(v4 * 0.5, -var2.Y + 0.02)
		local var14 = var69.Leather
		strap(arg1, "Torso", "Harness", var12, var13, -var2.Z - 0.07, 0.24, 0.12, var43, { Material = var14 })
		arg1.piece("Torso", "HarnessRivet", var67(v4 * 0.5, var2.Y - 0.12, -var2.Z - 0.14), Vector3.new(0.12, 0.12, 0.06), var41, var3)
	end

	var5 = var67(0, var2.Y - 0.76, -var2.Z - 0.16)
	cyl(arg1, "Torso", "MedalRim", var5, 0.1, 0.76, var41, var3, "Z")
	local var15 = var3
	local var16 = table.clone(var15 or {})
	local var17 = ringZ
	local var18 = arg1
	local str3 = "Torso"
	local str4 = "MedalBead"
	local var19 = var5 * var67(0, 0, -0.07)
	local num3 = 0.34
	local num4 = 16
	local num5 = 0.06
	local num6 = 0.04
	local var20 = var42
	for k5, v5 in pairs({ Fine = true }) do
		var16[k5] = v5
	end

	var17(var18, str3, str4, var19, num3, num4, num5, num6, var20, var16)
	cyl(arg1, "Torso", "MedalField", var5 * var67(0, 0, -0.05), 0.06, 0.54, var40, nil, "Z")
	for i1 = 0, 7 do
		local var21 = i1 * 45
		str4 = i1 % 2 == 0
		var19 = arg1.piece
		num3 = "Torso"
		num4 = "MedalPoint"
		num6 = var5 * var67(0, 0, -0.08) * var70(0, 0, (var71(var21)))
		var20 = var67
		var16 = 0
		num5 = num6 * var20(var16, if str4 then 0.16 else 0.13, 0)
		var20 = 0.07
		num6 = var68(var20, if str4 then 0.2 else 0.12, 0.04)
		var19(num3, num4, num5, num6, var42, var3)
	end

	var17 = var5 * var67(0, 0, -0.12)
	arg1.piece("Torso", "MedalGem", var17 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.2, 0.2, 0.2), var45, { Material = var69.Neon })
	str4 = var5 * var67(0, 0, -0.14)
	num4 = { Material = var69.Neon, Transparency = 1, Hub = var5 * var67(0, 0, -0.14), Fx = "Glint" }
	num5 = {
		From = var67(-0.18, 0.18, 0) * var70(0, 0, -0.69813170079773179),
		Period = 9,
		Phase = 2,
	}

	num5.To = var67(0.18, -0.18, 0) * var70(0, 0, -0.69813170079773179)
	num4.FxArgs = num5
	arg1.piece("Torso", "Glint", str4, Vector3.new(0.34, 0.06, 0.03), var4, num4)
	var17 = var5 * var67(0, -0.38, -0.02)
	var19 = var17 * var67(0, -0.08, 0)
	arg1.piece("Torso", "SealRibbon", var19, Vector3.new(0.14, 0.18, 0.04), var39, { Hub = var17, Fx = "Sway", FxArgs = { A = 0.15707963267948966, W = 1.6 } })
	num3 = var17 * var67(0, -0.24, -0.01)
	local var22 = var3
	var20 = table.clone(var22 or {})
	var18 = cyl
	local var23 = arg1
	str4 = "Torso"
	var19 = "Seal"
	num4 = 0.06
	num5 = 0.2
	num6 = var42
	for k6, v6 in pairs({ Hub = var17, Fx = "Sway", FxArgs = { A = 0.15707963267948966, W = 1.6 } }) do
		var20[k6] = v6
	end

	var18(var23, str4, var19, num3, num4, num5, num6, var20, "Z")
	band(arg1, "Waist", "Belt", 0, 0.08, 0.26, var43, { Material = var69.Leather })
	box(arg1, "HipFront", "BeltBuckle", var67(0, 0.07, -0.12), Vector3.new(0.3, 0.24, 0.08), var41, 0.03, var3)
	num3 = 1
	for k7, v7 in ipairs({ -1, num3 }) do
		num4 = var67(v7 * 0.58, -0.08, -0.14)
		box(arg1, "HipFront", "Pouch", num4, Vector3.new(0.4, 0.38, 0.24), var39, 0.05, { Material = var69.Leather })
		var16 = num4 * var67(0, 0.13, -0.03)
		arg1.piece("HipFront", "PouchFlap", var16, Vector3.new(0.46, 0.16, 0.26), var43, { Material = var69.Leather })
		arg1.piece("HipFront", "PouchTrim", num4 * var67(0, 0.035, -0.135), Vector3.new(0.52, 0.06, 0.04), var41, var3)
		arg1.piece("HipFront", "Clasp", num4 * var67(0, 0.08, -0.19), Vector3.new(0.12, 0.12, 0.05), var42, var3)
	end

	local str5 = "RightForearm"
	for k8, v8 in ipairs({ "LeftForearm", str5 }) do
		num4 = arg1.half(v8)
		band(arg1, v8, "Bracer", -0.12, 0.06, 0.56, var39, { Material = var69.Leather })
		band(arg1, v8, "BracerTrim", 0.18, 0.08, 0.12, var41, var3)
		band(arg1, v8, "BracerTrim", -0.42, 0.08, 0.12, var41, var3)
		num5 = var67(0, -0.12, -num4.Z - 0.08)
		arg1.piece(v8, "Engraving", num5 * var70(0, 0, 0.78539816339744828), Vector3.new(0.24, 0.24, 0.04), var41, var3)
		num6 = num5 * var67(0, 0, -0.04)
		arg1.piece(v8, "BracerGem", num6 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.12, 0.12, 0.12), var45, { Material = var69.Neon })
	end

	var18 = var67(0, -0.46, 0.3)
	if arg1.compact then
		var23 = var67(0.6, 0.02, 0.32) * var70(0, 0.52359877559829882, 0)
		box(arg1, "HipBack", "Vault", var23, Vector3.new(0.36, 0.44, 0.26), var43, 0.04, { Material = var69.Leather })
		num4 = var23 * var67(0, 0, 0.13)
		num6 = var1("#DFF7FB")
		arg1.piece("HipBack", "VaultGlass", num4, Vector3.new(0.26, 0.34, 0.04), num6, { Material = var69.Glass, Transparency = 0.5 })
		num5 = var23 * var67(0, 0, 0.02)
		crystal(arg1, "HipBack", "VaultCrystal", num5, 0.12, 0.3, var45, { Material = var69.Neon, Transparency = 0.1 })
		return
	end

	num4 = var18 * var67(0, 0, -0.16999999999999998)
	box(arg1, "Back", "Vault", num4, Vector3.new(0.86, 0.84, 0.1), var44, 0.04, { Material = var69.Leather })
	num4 = 1
	for k9, v9 in ipairs({ -1, num4 }) do
		var16 = var18 * var67(v9 * 0.41000000000000003, 0, 0)
		arg1.piece("Back", "VaultWall", var16, Vector3.new(0.1, 0.7, 0.44), var43, { Material = var69.Leather })
	end

	local num7 = 1
	for k10, v10 in ipairs({ -1, num7 }) do
		var16 = var18 * var67(0, v10 * 0.4, 0)
		arg1.piece("Back", "VaultWall", var16, Vector3.new(0.92, 0.1, 0.44), var43, { Material = var69.Leather })
	end

	local num8 = 1
	for k11, v11 in ipairs({ -1, num8 }) do
		arg1.piece("Back", "VaultFrame", var18 * var67(0, v11 * 0.43, 0.22), Vector3.new(1.02, 0.1, 0.08), var41, var3)
	end

	local num9 = 1
	for k12, v12 in ipairs({ -1, num9 }) do
		arg1.piece("Back", "VaultFrame", var18 * var67(v12 * 0.44, 0, 0.225), Vector3.new(0.1, 0.8, 0.08), var41, var3)
	end

	local num10 = 1
	for k13, v13 in ipairs({ -1, num10 }) do
		local num11 = 1
		for k14, v14 in ipairs({ -1, num11 }) do
			var15 = "Back"
			local str6 = "VaultCorner"
			arg1.piece(var15, str6, var18 * var67(v13 * 0.46, v14 * 0.45, 0.27), Vector3.new(0.22, 0.22, 0.12), var42, var3)
		end
	end

	arg1.piece("Back", "VaultBackdrop", var18 * var67(0, 0, -0.11), Vector3.new(0.72, 0.7, 0.03), var40, { Fine = true })
	box(arg1, "Back", "Plinth", var18 * var67(0, -0.28, 0), Vector3.new(0.46, 0.14, 0.24), var39, 0.03)
	local var24 = var3
	num6 = table.clone(var24 or {})
	var23 = arg1.piece
	str4 = "Back"
	local str7 = "PlinthTrim"
	local var25 = var18 * var67(0, -0.205, 0.01)
	local var26 = Vector3.new(0.5, 0.04, 0.24)
	num5 = var41
	for k15, v15 in pairs({ Fine = true }) do
		num6[k15] = v15
	end

	var23(str4, str7, var25, var26, num5, num6)
	var26 = var18 * var67(0, 0.04, 0.02)
	crystal(arg1, "Back", "VaultCrystal", var26, 0.24, 0.56, var45, { Material = var69.Neon, Transparency = 0.05 })
	var26 = var18 * var67(-0.15, -0.08, 0.04) * var70(0, 0, 0.31415926535897931)
	var20 = var1("#BDF4FC")
	crystal(arg1, "Back", "VaultCrystal", var26, 0.14, 0.3, var20, { Material = var69.Glass, Transparency = 0.15 })
	var26 = var18 * var67(0.15, -0.1, 0.04) * var70(0, 0, -0.27925268031909273)
	var20 = var1("#BDF4FC")
	crystal(arg1, "Back", "VaultCrystal", var26, 0.14, 0.26, var20, { Material = var69.Glass, Transparency = 0.15 })
	arg1.piece("Back", "VaultGlass", var18 * var67(0, 0, 0.2), Vector3.new(0.68, 0.66, 0.03), var1("#E4F8FC"), { Transparency = 0.8, Reflectance = 0.1, Fine = true })
	var25 = var18 * var67(0, 0, 0.24)
	num6 = { Material = var69.Neon, Transparency = 1, Hub = var18 * var67(0, 0, 0.24), Fx = "Glint" }
	var20 = { From = var67(-0.32, 0, 0) * var70(0, 0, -0.31415926535897931), Period = 7, Phase = 0 }
	var20.To = var67(0.32, 0, 0) * var70(0, 0, -0.31415926535897931)
	num6.FxArgs = var20
	arg1.piece("Back", "Glint", var25, Vector3.new(0.08, 0.76, 0.03), var4, num6)
	box(arg1, "Back", "Latch", var18 * var67(0.5, 0.02, 0.08), Vector3.new(0.08, 0.22, 0.18), var42, 0.02, var3)
	arg1.piece("Back", "LatchPin", var18 * var67(0.55, 0.02, 0.08), Vector3.new(0.06, 0.08, 0.08), var44, { Fine = true })
	var26 = 1
	for k16, v16 in ipairs({ -1, var26 }) do
		local var27 = var18 * var67(v16 * 0.3, 0.61, -0.12)
		arg1.piece("Back", "VaultStrap", var27, Vector3.new(0.16, 0.36, 0.08), var43, { Material = var69.Leather })
		arg1.piece("Back", "VaultBuckle", var18 * var67(v16 * 0.3, 0.51, -0.07), Vector3.new(0.2, 0.12, 0.06), var41, var3)
	end
end

tbl7.ExpertCollector = tbl6
tbl5 = { slot = "Chest", offset = var67(0.42, -0.42, -0.14) }
local function fire(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg5
	local var3 = arg1.piece(arg2, "Ember", var1 or var67(), Vector3.new(0.12, 0.12, 0.12), var4, { Transparency = 1 })
	if not var3 then
		return nil
	end

	local num1 = 1
	local var5 = var49
	local num2 = 1
	num1 = 0
	local tbl1 = {
		Texture = "rbxasset://textures/particles/fire_main.dds",
		Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, var62),
			ColorSequenceKeypoint.new(0.3, var51),
			ColorSequenceKeypoint.new(0.7, var48),
			ColorSequenceKeypoint.new(num1, var5),
		}),
		LightEmission = 0.8,
		Acceleration = Vector3.new(0, 5, 0),
		Drag = 3,
	}

	tbl1.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, arg3 * 0.7),
		NumberSequenceKeypoint.new(0.35, arg3),
		NumberSequenceKeypoint.new(num2, num1),
	})

	num2 = 1
	num1 = 1
	tbl1.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.1),
		NumberSequenceKeypoint.new(0.6, 0.35),
		NumberSequenceKeypoint.new(num2, num1),
	})

	tbl1.Lifetime = NumberRange.new(0.28, 0.45)
	tbl1.Speed = NumberRange.new(0.4, 0.9)
	tbl1.SpreadAngle = Vector2.new(16, 16)
	tbl1.Rate = arg4
	emitter(var3, "Flame", tbl1)
	return var3
end

tbl6 = { Mark = tbl5, Animated = true }
tbl6.build = function(arg1)
	local num1 = 1
	local var1 = arg1.half("Torso")
	local function fn2(arg1)
		return {
			Material = var69.Neon,
			Fx = "Flicker",
			FxArgs = { A = var48, B = var51, W = 3.2, Phase = arg1 },
		}
	end

	for k1, v1 in ipairs({ -1, num1 }) do
		local var2 = Vector2.new(v1 * 0.6, var1.Y + 0.02)
		local var3 = Vector2.new(-v1 * 0.5, -var1.Y + 0.1)
		strap(arg1, "Torso", "Harness", var2, var3, -var1.Z - 0.07, 0.22, 0.12, var47, { Material = var69.Leather })
		var2 = Vector2.new(v1 * 0.6, var1.Y + 0.02)
		var3 = Vector2.new(-v1 * 0.5, -var1.Y + 0.1)
		local var5 = var69.Leather
		strap(arg1, "Torso", "Harness", var2, var3, var1.Z + 0.07, 0.22, 0.12, var47, { Material = var5 })
		local var6 = var1.Z
		local var7 = var67(v1 * 0.6, var1.Y + 0.06, 0)
		var2 = var68(0.24, 0.12, 2 * var6 + 0.24)
		arg1.piece("Torso", "Harness", var7, var2, var47, { Material = var69.Leather })
	end

	local var8 = var67(0, var1.Y - 0.72, -var1.Z - 0.16)
	cyl(arg1, "Torso", "CoreHousing", var8, 0.16, 0.56, var46, nil, "Z")
	local var9 = var8 * var67(0, 0, -0.02)
	local var10 = cyl
	local var11 = arg1
	local str1 = "Torso"
	local str2 = "CoreRim"
	local num2 = 0.1
	local num3 = 0.6
	local var12 = var50
	local var13 = table.clone({})
	local var14 = var50
	for k2, v2 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
		var13[k2] = v2
	end

	var10(var11, str1, str2, var9, num2, num3, var12, var13, "Z")
	var9 = var8 * var67(0, 0, -0.07)
	cyl(arg1, "Torso", "CoreHeart", var9, 0.06, 0.42, var48, { Material = var69.Neon, Fx = "Breathe", FxArgs = { A = var48, B = var51, W = 2.4 } }, "Z")
	for i1 = -1, 1, 2 do
		arg1.piece("Torso", "Grille", var8 * var67(i1 * 0.09, 0, -0.115), Vector3.new(0.035, 0.38, 0.03), var47, { Fine = true })
	end

	arg1.piece("Torso", "Grille", var8 * var67(0, 0, -0.12), Vector3.new(0.38, 0.035, 0.03), var47, { Fine = true })
	var9 = { "PauldronRight", 1 }
	for k3, v3 in ipairs({ { "PauldronLeft", -1 }, var9 }) do
		num2 = v3[1]
		num3 = v3[2]
		var12 = arg1.half(num2)
		local var15 = arg1.piece
		local var16 = num2
		local str3 = "Guard"
		local var17 = var67(num3 * 0.03, 0.04, 0)
		local var18 = var68(2 * var12.X + 0.14, 0.4, 2 * var12.Z + 0.14)
		local var19 = var46
		local var20 = table.clone({})
		for k4, v4 in pairs({ Mesh = "Sphere" }) do
			var20[k4] = v4
		end

		var15(var16, str3, var17, var18, var19, var20)
		local var21 = fn2(num3)
		local var22 = table.clone(var21 or {})
		var16 = arg1.piece
		str3 = num2
		var17 = "GuardSeam"
		var18 = var67(num3 * 0.03, -0.04, 0)
		var19 = var68(2 * var12.X + 0.18, 0.14, 2 * var12.Z + 0.18)
		var20 = var48
		for k5, v5 in pairs({ Mesh = "Sphere" }) do
			var22[k5] = v5
		end

		var16(str3, var17, var18, var19, var20, var22)
		var15 = arg1.piece
		var16 = num2
		str3 = "GuardRim"
		var17 = var67(num3 * 0.03, -0.1, 0)
		var18 = var68(2 * var12.X + 0.2, 0.12, 2 * var12.Z + 0.2)
		var19 = var47
		var20 = table.clone({})
		for k6, v6 in pairs({ Mesh = "Sphere" }) do
			var20[k6] = v6
		end

		var15(var16, str3, var17, var18, var19, var20)
		var15 = var67(num3 * 0.1, 0.24, 0) * var70(0, 0, (var71(num3 * -12)))
		var16 = var68(0.3, 0.1, 2 * var12.Z * 0.7)
		var13 = arg1.piece
		var14 = num2
		local str4 = "GuardFin"
		str3 = var50
		var17 = table.clone({})
		var18 = var50
		for k7, v7 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var17[k7] = v7
		end

		var13(var14, str4, var15, var16, str3, var17)
	end

	local str5 = "RightForearm"
	for k8, v8 in ipairs({ "LeftForearm", str5 }) do
		band(arg1, v8, "Bracer", -0.14, 0.05, 0.56, var46)
		num2 = arg1.half(v8)
		num3 = band
		var12 = arg1
		var13 = v8
		var14 = "BracerTrim"
		local num4 = -0.44
		local num5 = 0.08
		local num6 = 0.12
		local var23 = var50
		local var24 = table.clone({})
		local var25 = var50
		for k9, v9 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var24[k9] = v9
		end

		num3(var12, var13, var14, num4, num5, num6, var23, var24)
		local var26 = fn2(0.7)
		num6 = table.clone(var26 or {})
		num3 = arg1.piece
		var12 = v8
		var13 = "BracerSeam"
		var14 = var67(0, -0.14, -num2.Z - 0.06)
		num4 = Vector3.new(0.06, 0.48, 0.04)
		num5 = var48
		for k10, v10 in pairs({ Fine = true }) do
			num6[k10] = v10
		end

		num3(var12, var13, var14, num4, num5, num6)
		local var27 = fn2(1.9)
		var24 = table.clone(var27 or {})
		num3 = band
		var12 = arg1
		var13 = v8
		var14 = "BracerSeam"
		num4 = 0.14
		num5 = 0.06
		num6 = 0.06
		var23 = var48
		for k11, v11 in pairs({ Fine = true }) do
			var24[k11] = v11
		end

		num3(var12, var13, var14, num4, num5, num6, var23, var24)
	end

	local str6 = "RightShin"
	for k12, v12 in ipairs({ "LeftShin", str6 }) do
		num2 = arg1.half(v12)
		box(arg1, v12, "Greave", var67(0, -0.08, -num2.Z - 0.04), var68(2 * num2.X * 0.78, 0.9, 0.12), var46, 0.03)
		local var28 = fn2(2.6)
		local var29 = table.clone(var28 or {})
		num3 = arg1.piece
		var12 = v12
		var13 = "GreaveSeam"
		var14 = var67(0, -0.04, -num2.Z - 0.11)
		local var30 = Vector3.new(0.05, 0.6, 0.03)
		local var31 = var48
		for k13, v13 in pairs({ Fine = true }) do
			var29[k13] = v13
		end

		num3(var12, var13, var14, var30, var31, var29)
		var30 = var67(0, -0.5, -num2.Z - 0.05)
		var31 = var68(2 * num2.X * 0.82, 0.12, 0.14)
		num3 = box
		var12 = arg1
		var13 = v12
		var14 = "GreaveTrim"
		var29 = var50
		local num7 = 0.02
		local var32 = table.clone({})
		local var33 = var50
		for k14, v14 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var32[k14] = v14
		end

		num3(var12, var13, var14, var30, var31, var29, num7, var32)
		box(arg1, v12, "GreaveTrim", var67(0, 0.36, -num2.Z - 0.05), var68(2 * num2.X * 0.8, 0.1, 0.14), var49, 0.02)
	end

	num3 = -0.1
	var12 = 0.1
	var13 = 0.42
	fire(arg1, "PauldronLeft", 0.8, 20, var67(num3, var12, var13))
	num3 = 0.1
	var12 = 0.1
	var13 = 0.42
	fire(arg1, "PauldronRight", 0.8, 20, var67(num3, var12, var13))
	local tbl1 = { "RightForearm", 1 }
	for k15, v15 in ipairs({ { "LeftForearm", -1 }, tbl1 }) do
		num2 = v15[1]
		local var34 = v15[2] * (arg1.limbSide(num2) + 0.12)
		local num8 = -0.3
		local num9 = 0.05
		fire(arg1, num2, 0.64, 18, var67(var34, num8, num9))
	end

	var10 = arg1.piece("Crest", "Cinders", var67(0, 0, 0.18), Vector3.new(0.12, 0.12, 0.12), var4, { Transparency = 1 })
	if var10 then
		var14 = 1
		local var36 = var48
		var14 = 1
		var36 = 0
		local tbl2 = {
			Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, var51), ColorSequenceKeypoint.new(var14, var36) }),
			LightEmission = 1,
			Acceleration = Vector3.new(0, 2, 0),
			Rate = 4,
			Drag = 1.5,
		}

		tbl2.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.14), NumberSequenceKeypoint.new(var14, var36) })
		var14 = 1
		var36 = 1
		tbl2.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(var14, var36) })
		tbl2.Lifetime = NumberRange.new(0.7, 1.1)
		tbl2.Speed = NumberRange.new(0.8, 1.6)
		tbl2.SpreadAngle = Vector2.new(50, 50)
		emitter(var10, "Flame", tbl2)
		var11 = Instance.new("PointLight")
		var11.Name = "Warm"
		var11.Color = var51
		var11.Brightness = 0.6
		var11.Range = 7
		var11.Shadows = false
		var11.Parent = var10
	end
end

tbl7.HumanTorch = tbl6
local function motes(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var2 = arg1.piece(arg2, arg3, arg4, Vector3.new(0.12, 0.12, 0.12), var4, { Transparency = 1 })
	if not var2 then
		return nil
	end

	local num1 = 1
	local num2 = 0
	local tbl1 = {
		Color = ColorSequence.new(arg5[1], arg5[2]),
		LightEmission = 0.7,
		Acceleration = Vector3.new(0, 0.25, 0),
		Drag = 1.5,
	}

	tbl1.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.3, arg7),
		NumberSequenceKeypoint.new(num1, num2),
	})

	local num3 = 1
	num1 = 1
	tbl1.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(num3, num1) })
	tbl1.Lifetime = NumberRange.new(1.2, 2)
	tbl1.Speed = NumberRange.new(0.1, 0.3)
	tbl1.SpreadAngle = Vector2.new(180, 180)
	tbl1.Rate = arg6
	emitter(var2, "Motes", tbl1)
	return var2
end

tbl7.Ascendant = {
	Mark = nil,
	Back = true,
	Animated = true,
	build = function(arg1)
		local var1 = arg1.half("Torso")
		local var2 = table.clone({})
		local var3 = var53
		for k1, v1 in pairs({ Material = var69.Metal, Reflectance = 0.06 }) do
			var2[k1] = v1
		end

		mantle(arg1, "Mantle", {
			outer = var55,
			options = { Material = var69.Fabric },
			trim = var53,
			trimOptions = var2,
			length = 0.9,
			lean = 9,
			split = true,
			panel = function(arg1, arg2, arg3, arg4, arg5)
				local var1 = if math.abs(arg5) < 1 then var57 else var58
				local var2 = arg1 * var67(0, -arg3 * 0.55, arg4 / 2 + 0.02)
				local var3 = var68(arg2 * 0.6, arg3 * 0.7, 0.04)
				local var4 = arg1.piece
				local str1 = "Torso"
				local str2 = "Aurora"
				local var5 = var1
				var4(str1, str2, var2, var3, var5, {
					Material = var69.ForceField,
					Fx = "Breathe",
					FxArgs = { A = var1, B = if var1 == var57 then var58 else var57, W = 0.5, Phase = arg5 },
				})
			end,
		})

		local tbl1 = { "PauldronRight", 1 }
		var3 = { Material = var69.Neon }
		for k2, v2 in ipairs({ { "PauldronLeft", -1 }, tbl1 }) do
			local var4 = v2[1]
			local tbl2 = { var53, 0, 0.12 }
			local var5 = v2[2]
			local var6 = arg1.half(var4)
			for k3, v3 in ipairs({ { var56, -0.12, 0.2 }, tbl2, { var52, 0.12, 0.04 } }) do
				local var7 = v3[3]
				local var9 = v3[1]
				local var10 = var67(var5 * 0.06, v3[2], 0)
				local var11 = var68(2 * var6.X + var7, 0.3, 2 * var6.Z + var7)
				local var12 = if var9 == var53 then var2 else nil
				local var13 = table.clone(var12 or {})
				local var14 = arg1.piece
				local var15 = var4
				local str1 = "Plate"
				local var16 = var10
				local var17 = var11
				local var18 = var9
				for k4, v4 in pairs({ Mesh = "Sphere" }) do
					var13[k4] = v4
				end

				var14(var15, str1, var16, var17, var18, var13)
			end

			local var19 = var67(var5 * (var6.X - 0.02), 0.28, 0) * var70(0, 0, (var71(var5 * -28)))
			crystal(arg1, var4, "PlateFin", var19, 0.16, 0.5, var59, { Material = var69.Glass, Transparency = 0.1 })
			local num1 = 0.61540309425320061
			local var20 = var3
			arg1.piece(var4, "PlateGem", var67(var5 * 0.08, 0.2, -var6.Z * 0.62) * var70(0.78539816339744828, 0, num1), Vector3.new(0.14, 0.14, 0.14), var57, var20)
		end

		local str2 = "RightForearm"
		for k5, v5 in ipairs({ "LeftForearm", str2 }) do
			band(arg1, v5, "Guard", -0.12, 0.06, 0.56, var52)
			band(arg1, v5, "GuardTrim", 0.18, 0.08, 0.12, var53, var2)
			band(arg1, v5, "GuardTrim", -0.42, 0.08, 0.12, var53, var2)
			local var21 = var67(0, -0.12, -arg1.half(v5).Z - 0.08)
			arg1.piece(v5, "GuardLine", var21, Vector3.new(0.08, 0.4, 0.04), var57, { Material = var69.Neon, Fx = "Breathe", FxArgs = { A = var57, B = var58, W = 0.7 } })
		end

		local var22 = var67(0, var1.Y - 0.08, -var1.Z - 0.1)
		arg1.piece("Torso", "Clasp", var22 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.2, 0.2, 0.2), var57, var3)
		local num2 = 1
		for k6, v6 in ipairs({ -1, num2 }) do
			arg1.piece("Torso", "ClaspChain", var22 * var67(v6 * 0.24, 0.02, 0.02) * var70(0, 0, (var71(v6 * 12))), Vector3.new(0.3, 0.08, 0.06), var53, var2)
		end

		local var23 = var67(0, 0.42, 0.34)
		local var24 = var23 * var67(0, 0.18, 0)
		local tbl3 = { Hub = var23, Fx = "Bob", FxArgs = { A = 0.05, W = 1.2 } }
		local var25 = tbl3
		local var26 = table.clone(var25 or {})
		local var27 = crystal
		local var28 = arg1
		local str3 = "Crown"
		local str4 = "Crest"
		local num3 = 0.32
		local num4 = 0.86
		local var29 = var59
		for k7, v7 in pairs({ Material = var69.Glass, Transparency = 0.12 }) do
			var26[k7] = v7
		end

		var27(var28, str3, str4, var24, num3, num4, var29, var26)
		local var30 = tbl3
		var26 = table.clone(var30 or {})
		var27 = crystal
		var28 = arg1
		str3 = "Crown"
		str4 = "Crest"
		var24 = var23 * var67(0, 0.18, 0.02)
		num3 = 0.16
		num4 = 0.54
		var29 = var57
		for k8, v8 in pairs(var3) do
			var26[k8] = v8
		end

		var27(var28, str3, str4, var24, num3, num4, var29, var26)
		var24 = 1
		for k9, v9 in ipairs({ -1, var24 }) do
			var30 = var23 * var67(v9 * 0.34, 0.02, 0.02) * var70(0, 0, (var71(v9 * -24)))
			local var31 = tbl3
			local var32 = table.clone(var31 or {})
			num3 = crystal
			num4 = arg1
			var29 = "Crown"
			var26 = "Crest"
			local num5 = 0.22
			var25 = 0.56
			local var33 = var59
			for k10, v10 in pairs({ Material = var69.Glass, Transparency = 0.12 }) do
				var32[k10] = v10
			end

			num3(num4, var29, var26, var30, num5, var25, var33, var32)
			local var34 = tbl3
			var32 = table.clone(var34 or {})
			num3 = crystal
			num4 = arg1
			var29 = "Crown"
			var26 = "Crest"
			var30 = var23 * var67(v9 * 0.62, -0.1, 0.04) * var70(0, 0, (var71(v9 * -46)))
			num5 = 0.16
			var25 = 0.36
			var33 = var58
			for k11, v11 in pairs(var3) do
				var32[k11] = v11
			end

			num3(num4, var29, var26, var30, num5, var25, var33, var32)
		end

		var25 = tbl3
		local var35 = table.clone(var25 or {})
		var27 = ringZ
		var28 = arg1
		str3 = "Crown"
		local str5 = "CrestArc"
		local var36 = var23 * var67(0, -0.16, 0.12)
		num3 = 0.54
		num4 = 10
		var29 = 0.08
		var26 = 0.08
		var30 = var53
		for k12, v12 in pairs(var2) do
			var35[k12] = v12
		end

		var27(var28, str3, str5, var36, num3, num4, var29, var26, var30, var35, -84, 84)
		var27 = var67(0, 0.54, 0.46)
		if arg1.compact then
			var27 = var67(0, 0.62, 0.92)
		end

		arg1.piece("Back", "CoreMount", var67(0, var27.Y, (var27.Z + 0.04) / 2), var68(0.16, 0.16, var27.Z - 0.04), var54, var2)
		ringZ(arg1, "Back", "CoreRing", var27, 0.36, 12, 0.08, 0.08, var53, var2)
		ringZ(arg1, "Back", "CoreRingInner", var27 * var67(0, 0, 0.02), 0.28, 12, 0.05, 0.05, var52, { Fine = true })
		crystal(arg1, "Back", "Core", var27, 0.32, 0.66, var59, { Material = var69.Glass, Transparency = 0.1 })
		crystal(arg1, "Back", "CoreHeart", var27, 0.16, 0.4, var57, { Material = var69.Neon, Fx = "Breathe", FxArgs = { A = var57, B = var58, W = 0.8 } })
		for i1 = 1, 3 do
			num3 = var27 * var67(0, 0, 0.08) * var70(0, 0, (i1 - 1) * 2 * 3.1415926535897931 / 3) * var67(0.58, 0, 0)
			num4 = if i1 == 2 then var58 else var59
			var29 = {
				Material = if i1 == 2 then var69.Neon else var69.Glass,
				Transparency = if i1 == 2 then 0 else 0.1,
				Hub = var27 * var67(0, 0, 0.08),
				Fx = "Orbit",
			}

			var29.FxArgs = { W = 0.55, Spin = 1.2 }
			arg1.piece("Back", "Fragment", num3 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.24, 0.24, 0.24), num4, var29)
		end

		motes(arg1, "Back", "Aurora", var27 * var67(0, 0, 0.1), { var57, var58 }, 2, 0.14)
	end,
}

tbl7.Godly = {
	Mark = nil,
	Back = true,
	Animated = true,
	build = function(arg1)
		local var1 = arg1.half("Torso")
		local tbl1 = { Material = var69.Metal, Reflectance = 0.12 }
		mantle(arg1, "Mantle", {
			outer = var60,
			options = { Material = var69.Fabric },
			trim = var61,
			trimOptions = tbl1,
			lining = var64,
			length = 0.96,
			lean = 9,
		})

		local tbl2 = { "PauldronRight", 1 }
		local tbl3 = { Material = var69.Neon }
		for k1, v1 in ipairs({ { "PauldronLeft", -1 }, tbl2 }) do
			local var2 = v1[1]
			local var3 = v1[2]
			local var5 = arg1.half(var2)
			local var6 = tbl1
			local var7 = table.clone(var6 or {})
			local var8 = arg1.piece
			local var9 = var2
			local str1 = "Pauldron"
			local var10 = var67(var3 * 0.06, 0.08, 0)
			local var11 = var68(2 * var5.X + 0.36, 0.56, 2 * var5.Z + 0.36)
			local var12 = var61
			for k2, v2 in pairs({ Mesh = "Sphere" }) do
				var7[k2] = v2
			end

			var8(var9, str1, var10, var11, var12, var7)
			var8 = arg1.piece
			var9 = var2
			str1 = "PauldronLayer"
			var10 = var67(var3 * 0.1, -0.1, 0)
			var11 = var68(2 * var5.X + 0.44, 0.34, 2 * var5.Z + 0.42)
			var12 = var60
			var7 = table.clone({})
			for k3, v3 in pairs({ Mesh = "Sphere" }) do
				var7[k3] = v3
			end

			var8(var9, str1, var10, var11, var12, var7)
			var6 = tbl1
			var7 = table.clone(var6 or {})
			var8 = arg1.piece
			var9 = var2
			str1 = "PauldronRim"
			var10 = var67(var3 * 0.12, -0.22, 0)
			var11 = var68(2 * var5.X + 0.46, 0.18, 2 * var5.Z + 0.44)
			var12 = var63
			for k4, v4 in pairs({ Mesh = "Sphere" }) do
				var7[k4] = v4
			end

			var8(var9, str1, var10, var11, var12, var7)
			arg1.piece(var2, "PauldronGem", var67(var3 * 0.14, 0.3, 0) * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.16, 0.16, 0.16), var66, tbl3)
		end

		local str2 = "RightForearm"
		for k5, v5 in ipairs({ "LeftForearm", str2 }) do
			band(arg1, v5, "Guard", -0.12, 0.06, 0.58, var61, tbl1)
			band(arg1, v5, "GuardBand", -0.12, 0.08, 0.16, var60)
			band(arg1, v5, "GuardTrim", -0.44, 0.09, 0.12, var63, tbl1)
			arg1.piece(v5, "GuardGem", var67(0, -0.12, -arg1.half(v5).Z - 0.12) * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.14, 0.14, 0.14), var66, tbl3)
		end

		local var13 = var67(0, var1.Y - 0.62, -var1.Z - 0.08)
		cyl(arg1, "Torso", "EmblemPlate", var13, 0.08, 0.66, var64, nil, "Z")
		cyl(arg1, "Torso", "EmblemRing", var13 * var67(0, 0, -0.04), 0.06, 0.5, var61, tbl1, "Z")
		cyl(arg1, "Torso", "EmblemField", var13 * var67(0, 0, -0.07), 0.04, 0.36, var65, nil, "Z")
		for i1 = 0, 7 do
			local var14 = Vector3.new(0.08, 0.16, 0.05)
			local var15 = var62
			arg1.piece("Torso", "EmblemRay", var13 * var67(0, 0, -0.06) * var70(0, 0, (var71(i1 * 45 + 22.5))) * var67(0, 0.3, 0), var14, var15, tbl1)
		end

		local var16 = var13 * var67(0, 0, -0.11)
		local var17 = tbl3
		local var18 = table.clone(var17 or {})
		local var19 = var66
		for k6, v6 in pairs({ Fx = "Breathe", FxArgs = { A = var66, B = var4, W = 1.1 } }) do
			var18[k6] = v6
		end

		arg1.piece("Torso", "EmblemHeart", var16 * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.18, 0.18, 0.18), var19, var18)
		local num1 = 1
		for k7, v7 in ipairs({ -1, num1 }) do
			strap(arg1, "Torso", "EmblemChain", Vector2.new(v7 * 0.3, var1.Y - 0.44), Vector2.new(v7 * 0.72, var1.Y + 0.02), -var1.Z - 0.08, 0.1, 0.06, var61, tbl1)
		end

		var16 = arg1.headWidth() * 0.5 + 0.06
		ringY(arg1, "Crown", "CrownBand", var67(0, 0, 0), var16, 16, 0.16, 0.1, var61, tbl1)
		ringY(arg1, "Crown", "CrownInlay", var67(0, -0.005, 0), var16 + 0.05, 16, 0.11, 0.06, var60, { Stagger = true })
		local tbl4 = { 0, 0.52 }
		var17 = { -32, 0.4 }
		for k8, v8 in ipairs({
			tbl4,
			var17,
			{ 32, 0.4 },
			{ -64, 0.32 },
			{ 64, 0.32 },
			{ -100, 0.26 },
			{ 100, 0.26 },
			{ 180, 0.3 },
			{ -140, 0.22 },
			{ 140, 0.22 },
		}) do

			local var20 = v8[2]
			local var21 = pyramid
			local var22 = arg1
			local str3 = "Crown"
			local str4 = "CrownRay"
			local var23 = var67(0, 0.08 + var20 / 2, 0) * var70(0, -var71(v8[1]), 0) * var67(0, 0, -var16) * var70(-0.13962634015954636, 0, 0)
			local num2 = 0.16
			local var24 = var20
			local var25 = if k8 == 1 then var62 else var61
			local var26 = tbl1
			var21(var22, str3, str4, var23, num2, var24, var25, var26)
		end

		arg1.piece("Crown", "CrownGem", var67(0, 0.02, -var16 - 0.07) * var70(0.78539816339744828, 0, 0.61540309425320061), Vector3.new(0.16, 0.16, 0.16), var66, tbl3)
		var19 = var67(0, var1.Y + 0.86, var1.Z + 0.48)
		if arg1.compact then
			var19 = var67(0, var1.Y + 0.86, var1.Z + 0.88)
		end

		box(arg1, "Torso", "DiscMount", var67(0, var1.Y + 0.3, var1.Z + 0.18), Vector3.new(0.44, 1.24, 0.14), var64, 0.04)
		arg1.piece("Torso", "DiscMountTrim", var67(0, var1.Y + 0.3, var1.Z + 0.26), Vector3.new(0.26, 1.08, 0.04), var61, tbl1)
		var18 = var1.Z + 0.24
		arg1.piece("Torso", "DiscStem", var67(0, var19.Position.Y, (var18 + var19.Position.Z) / 2), var68(0.16, 0.16, var19.Position.Z - var18), var61, tbl1)
		cyl(arg1, "Torso", "DiscHub", var19, 0.12, 0.62, var61, tbl1, "Z")
		cyl(arg1, "Torso", "DiscHubInlay", var19 * var67(0, 0, 0.05), 0.06, 0.46, var60, nil, "Z")
		ringZ(arg1, "Torso", "DiscHubRim", var19 * var67(0, 0, 0.08), 0.21, 10, 0.06, 0.06, var62, tbl1)
		local var27 = var19 * var67(0, 0, 0.12)
		crystal(arg1, "Torso", "SunCrystal", var27, 0.2, 0.42, var66, { Material = var69.Glass, Transparency = 0.05 })
		var27 = var19 * var67(0, 0, 0.12)
		local var28 = tbl3
		local var29 = table.clone(var28 or {})
		local var30 = crystal
		local var31 = arg1
		local str5 = "Torso"
		local str6 = "SunHeart"
		local num3 = 0.12
		local num4 = 0.26
		local var32 = var66
		for k9, v9 in pairs({ Fx = "Breathe", FxArgs = { A = var66, B = var4, W = 0.9 } }) do
			var29[k9] = v9
		end

		var30(var31, str5, str6, var27, num3, num4, var32, var29)
		for i2 = 0, 7 do
			str6 = var71(i2 * 45)
			var32 = var19 * var70(0, 0, -str6) * var67(0, 0.46, 0.02)
			local tbl5 = { Hub = var19 * var67(0, 0, 0.02), Fx = "Spin" }
			tbl5.FxArgs = { W = -0.12, Arrive = -2.2 }
			arg1.piece("Torso", "Petal", var32, Vector3.new(0.18, 0.26, 0.08), var60, tbl5)
			local num5 = 0
			local num6 = 0.02
			var29 = var19 * var70(0, 0, -str6) * var67(0, 0.66, 0.02)
			local tbl6 = { Hub = var19 * var67(0, num5, num6), Fx = "Spin" }
			tbl6.FxArgs = { W = -0.12, Arrive = -2.2 }
			local var33 = tbl1
			local var34 = table.clone(var33 or {})
			var27 = pyramid
			num3 = arg1
			num4 = "Torso"
			var32 = "PetalTip"
			local num7 = 0.18
			tbl5 = 0.16
			var28 = var62
			for k10, v10 in pairs(tbl6) do
				var34[k10] = v10
			end

			var27(num3, num4, var32, var29, num7, tbl5, var28, var34)
		end

		local num8 = 0
		local num9 = -0.04
		var27 = var19 * var67(0, 0, -0.04)
		var28 = { Hub = var19 * var67(0, num8, num9), Fx = "Spin" }
		var28.FxArgs = { W = 0.07, Arrive = 1.6 }
		local var35 = tbl1
		local var36 = table.clone(var35 or {})
		var30 = ringZ
		var31 = arg1
		local str7 = "Torso"
		str6 = "DiscRing"
		num3 = 0.96
		num4 = 28
		var32 = 0.1
		var29 = 0.08
		local var37 = var61
		for k11, v11 in pairs(var28) do
			var36[k11] = v11
		end

		var30(var31, str7, str6, var27, num3, num4, var32, var29, var37, var36)
		for i3 = 0, 11 do
			str6 = i3 % 2 == 0
			var27 = var71(i3 * 30 + 15)
			num3 = if str6 then 0.4 else 0.24
			num4 = pyramid
			var32 = arg1
			var29 = "Torso"
			var37 = "Ray"
			var36 = var19 * var67(0, 0, -0.04) * var70(0, 0, -var27) * var67(0, num3 / 2 + 1.01, 0)
			var28 = if str6 then 0.22 else 0.16
			local var38 = num3
			local num10 = 0
			local num11 = -0.04
			local tbl7 = { Hub = var19 * var67(0, num10, num11), Fx = "Spin" }
			tbl7.FxArgs = { W = 0.07, Arrive = 1.6 }
			local var39 = tbl1
			local var40 = table.clone(var39 or {})
			var35 = if str6 then var61 else var63
			for k12, v12 in pairs(tbl7) do
				var40[k12] = v12
			end

			num4(var32, var29, var37, var36, var28, var38, var35, var40)
		end

		var30 = motes(arg1, "Torso", "Radiance", var19 * var67(0, 0, 0.1), { var62, var60 }, 2.5, 0.14)
		if var30 then
			var37 = 1
			var36 = 0
			var27 = {
				Color = ColorSequence.new(var62, var61),
				LightEmission = 0.8,
				Acceleration = Vector3.new(0, 0, 0),
				Drag = 4,
			}

			var27.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.22), NumberSequenceKeypoint.new(var37, var36) })
			var37 = 1
			var36 = 1
			var27.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(var37, var36) })
			var27.Lifetime = NumberRange.new(0.6, 1)
			var27.Speed = NumberRange.new(2, 3.5)
			var27.SpreadAngle = Vector2.new(180, 180)
			emitter(var30, "Arrive", var27)
		end
	end,
}

tbl2.Looks = tbl7
tbl2.has = function(arg1)
	return tbl7[arg1] ~= nil
end

tbl2.find = function(arg1)
	if not arg1 then
		return nil
	end

	local var2 = arg1:FindFirstChild(tbl2.ModelName)
	if var2 and var2:IsA("Model") then
		return var2
	end

	return nil
end

tbl2.PlaneGap = 0.012
tbl2.PlaneLift = 0.03
tbl6 = function(arg1)
	local var2 = arg1:IsA("Part")
	if var2 then
		var2 = arg1.Shape == Enum.PartType.Cylinder
	end

	local var4 = arg1:IsA("Part")
	if var4 then
		var4 = false
		if arg1.Shape == Enum.PartType.Block then
			var4 = not arg1:FindFirstChildOfClass("SpecialMesh")
		end
	end

	if (var2 or (not var4)) and 1 <= arg1.Transparency then
		return nil
	end

	local var5 = arg1.CFrame
	local var6 = arg1.Size / 2
	local tbl1 = { var5.RightVector, var5.UpVector, -var5.LookVector }
	local tbl2 = { var6.X, var6.Y, var6.Z }
	local tbl3 = {}
	for i1 = 1, 3 do
		if not var2 or i1 == 1 then
			local num1 = 1
			for k1, v1 in ipairs({ -1, num1 }) do
				local var7 = i1 % 3 + 1
				local var8 = (i1 + 1) % 3 + 1
				local var9 = tbl1[i1] * v1
				local var10 = tbl2[var7]
				local var11 = tbl2[var8]
				if var2 then
					var10 = math.min(var6.Y, var6.Z) * 0.7
					var11 = var10
				end

				local tbl4 = { axis = i1, n = var9, d = var9:Dot(var5.Position) + tbl2[i1] }
				tbl4.c = var5.Position + var9 * tbl2[i1]
				tbl4.u = tbl1[var7]
				tbl4.v = tbl1[var8]
				tbl4.hu = var10
				tbl4.hv = var11
				tbl4.area = var10 * var11
				table.insert(tbl3, tbl4)
			end
		end
	end

	return tbl3
end

tbl5 = function(arg1, arg2)
	for i1 = -2, 2 do
		for i2 = -2, 2 do
			local var1 = arg2.c + arg2.u * (arg2.hu * i1 / 2.2) + arg2.v * (arg2.hv * i2 / 2.2) - arg1.c
			if math.abs((var1:Dot(arg1.u))) >= arg1.hu - 0.005 then
				continue
			end

			if math.abs((var1:Dot(arg1.v))) >= arg1.hv - 0.005 then
				continue
			end

			return true
		end
	end

	return false
end

local function clashes(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local var1 = tbl6(v1)
		if not var1 then
			continue
		end

		local var2 = v1:FindFirstChildWhichIsA("WeldConstraint")
		var2 = var2 or v1:FindFirstChildWhichIsA("Weld")
		local var3 = var2
		table.insert(tbl1, { part = v1, faces = var1, radius = v1.Size.Magnitude / 2, anchor = var3 and var2.Part0 })
	end

	local tbl3 = {}
	for i1 = 1, #tbl1 do
		local var4 = tbl1[i1]
		for i2 = i1 + 1, #tbl1 do
			local var5 = tbl1[i2]
			if var4.anchor ~= var5.anchor then
				continue
			end

			local var7 = var5.radius
			local var8
			if var4.part.Color == var5.part.Color and var4.part.Material ~= var5.part.Material or (var4.part.Position - var5.part.Position).Magnitude <= var4.radius + var7 + tbl2.PlaneGap then
				for k2, v2 in ipairs(var4.faces) do
					for k3, v3 in ipairs(var5.faces) do
						if 0.999 >= v2.n:Dot(v3.n) then
							continue
						end

						if math.abs(v2.d - v3.d) >= tbl2.PlaneGap then
							continue
						end

						if tbl5(v2, v3) or tbl5(v3, v2) then
							table.insert(tbl3, { var4.part, v2, var5.part, v3 })
						end
					end
				end
			end
		end
	end

	return tbl3
end

tbl2.clashCount = function(arg1)
	if arg1 then
		return #clashes(arg1)
	end

	return 0
end

local tbl8 = { BodyBackAttachment = true }
local function restoreAccessories(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		local var3 = v1:IsA("Accessory")
		if var3 then
			local var5 = v1:FindFirstChild("Handle")
			var3 = if var5 and var5:IsA("BasePart") then var5 else nil
		end

		if not var3 then
			continue
		end

		if var3:GetAttribute("ClassLookHid") == nil then
			continue
		end

		local var6 = var3:GetAttribute("ClassLookHid")
		var3.Transparency = var6
		var3:SetAttribute("ClassLookHid", nil)
	end
end

tbl2.clear = function(arg1)
	if not arg1 then
		return
	end

	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= tbl2.ModelName then
			continue
		end

		v1:Destroy()
	end

	restoreAccessories(arg1)
end

local function makeContext(arg1, arg2, arg3)
	local tbl5 = {}
	local function anchor(arg1)
		if tbl5[arg1] == nil then
			local bool1 = false
			for k1, v1 in ipairs(tbl1[arg1]) do
				local var1 = arg1:FindFirstChild(v1)
				if not var1 then
					continue
				end

				if not var1:IsA("BasePart") then
					continue
				end

				tbl5[arg1] = var1
				bool1 = true
				break
			end

			if not bool1 then
				tbl5[arg1] = false
			end
		end

		return tbl5[arg1] or nil
	end

	local var2 = anchor("UpperTorso")
	local var3 = math.clamp(if var2 then var2.Size.X / 2 else 1, tbl2.MinScale, tbl2.MaxScale)
	local var4 = nil
	local tbl6 = {
		model = arg2,
		scale = var3,
		compact = arg3,
		anchor = anchor,
		character = arg1,
		headTop = function()
			if var4 then
				return var4
			end

			local var2 = anchor("Head")
			if not var2 then
				var4 = 0.6
				return var4
			end

			local var3 = if var2.Size.Y * 1.5 < var2.Size.X then var2.Size.Y * 0.62 else var2.Size.Y / 2
			local var5 = var3
			for k1, v1 in ipairs(arg1:GetChildren()) do
				local var8 = v1:IsA("Accessory")
				if var8 then
					local var10 = v1:FindFirstChild("Handle")
					var8 = if var10 and var10:IsA("BasePart") then var10 else nil
				end

				if not var8 then
					continue
				end

				if not handleOn(var8, tbl3) then
					continue
				end

				if var8.Transparency >= 1 then
					continue
				end

				local num1 = 1
				local var11 = var2.CFrame:ToObjectSpace(var8.CFrame)
				local var12 = var8.Size / 2
				for k2, v2 in ipairs({ -1, num1 }) do
					local num2 = 1
					for k3, v3 in ipairs({ -1, num2 }) do
						local num3 = 1
						for k4, v4 in ipairs({ -1, num3 }) do
							var5 = math.max(var5, (var11 * var68(v2 * var12.X, v3 * var12.Y, v4 * var12.Z)).Y)
						end
					end
				end
			end

			local var13 = if var5 - var3 < 0.12 then var3 - 0.1 else math.min(var5 - 0.06, var3 + tbl2.MaxHeadroom)
			var4 = var13
			arg2:SetAttribute("HeadTop", var4)
			return var4
		end,
		headWidth = function()
			local var2 = anchor("Head")
			if not var2 then
				return 1.2
			end

			local var4 = var2.Size.X
			local var5 = var2.Size.Z * 1.3
			local var6 = math.min(var4, var5, (if var2.Size.Y * 1.5 < var2.Size.X then var2.Size.Y * 0.62 else var2.Size.Y / 2) * 2.1)
			return var6 / var3
		end,
	}

	tbl6.piece = function(arg1, arg2, arg3, arg4, arg5, arg6)
		local var1 = tbl4[arg1]
		local var2 = var1
		var2 = var2 and tbl6.anchor(var1.anchor)
		if not var2 then
			return nil
		end

		local var3 = arg6
		arg6 = var3 or {}
		var3 = nil
		if arg6.Class == "Wedge" then
			var3 = Instance.new("WedgePart")
		else
			if arg6.Class == "CornerWedge" then
				var3 = Instance.new("CornerWedgePart")
			else
				local var4 = arg6.Shape
				var3 = Instance.new("Part")
				var3.Shape = var4 or Enum.PartType.Block
			end
		end

		var3.Name = arg2
		local tbl1 = { arg4.X, arg4.Y, arg4.Z }
		local num1 = 1
		local var5 = if arg6.Fine then 0.03 else tbl2.MinFeature
		if tbl1[2] < tbl1[num1] then
			num1 = 2
		end

		if tbl1[3] < tbl1[num1] then
			num1 = 3
		end

		for i1 = 1, 3 do
			local var6 = tbl1[i1]
			tbl1[i1] = math.max(var6, if i1 == num1 then math.min(var5, tbl2.MinThickness) else var5)
		end

		var3.Size = var68(tbl1[1], tbl1[2], tbl1[3]) * tbl6.scale
		var3.Color = arg5
		local var7 = arg6.Material
		var3.Material = var7 or var69.SmoothPlastic
		var3.Transparency = arg6.Transparency or 0
		var3.Reflectance = arg6.Reflectance or 0
		var3.CanCollide = false
		var3.CanTouch = false
		var3.CanQuery = false
		var3.Massless = true
		var3.CastShadow = false
		var3.TopSurface = Enum.SurfaceType.Smooth
		var3.BottomSurface = Enum.SurfaceType.Smooth
		if arg6.Mesh == "Sphere" then
			var7 = Instance.new("SpecialMesh")
			var7.MeshType = Enum.MeshType.Sphere
			var7.Parent = var3
		end

		var7 = var1.at(var2, tbl6)
		local var8 = arg3.Position
		local var9 = tbl6.scale
		var3.CFrame = var2.CFrame * var7 * (var67(var8.X * var9, var8.Y * var9, var8.Z * var9) * (arg3 - var8))
		var3.Parent = arg2
		if arg6.Animated or arg6.Hub then
			local var10 = Instance.new("Weld")
			var10.Name = "Drift"
			var10.Part0 = var2
			var10.Part1 = var3
			var10.C0 = var2.CFrame:ToObjectSpace(var3.CFrame)
			var10.Parent = var3
			var8 = var10.C0
			var3:SetAttribute("Rest", var8)
			if arg6.Hub then
				var9 = arg6.Hub
				local var13 = var9.Position
				var8 = tbl6.scale
				local var14 = var7 * (var67(var13.X * var8, var13.Y * var8, var13.Z * var8) * (var9 - var13))
				var3:SetAttribute("Hub", var14)
				local var15 = var10.C0
				var8 = "Local"
				var3:SetAttribute(var8, var14:ToObjectSpace(var15))
			end
		else
			local var16 = Instance.new("WeldConstraint")
			var16.Part0 = var2
			var16.Part1 = var3
			var16.Parent = var3
		end

		if arg6.Fx then
			var9 = arg6.Fx
			var3:SetAttribute("Fx", var9)
			local var17 = arg6.FxArgs
			for k1, v1 in pairs(var17 or {}) do
				var3:SetAttribute(k1, v1)
			end
		end

		return var3
	end

	tbl6.limb = function(arg1)
		local var2 = tbl4[arg1]
		if var2 then
			return (tbl6.anchor(var2.anchor))
		end

		return nil
	end

	tbl6.half = function(arg1)
		local var2 = tbl6.limb(arg1)
		if var2 then
			return var2.Size / 2 / tbl6.scale
		end

		return Vector3.new(0.5, 0.5, 0.5)
	end

	tbl6.limbTop = function(arg1)
		return tbl6.half(arg1).Y
	end

	tbl6.limbSide = function(arg1)
		return tbl6.half(arg1).X
	end

	return tbl6
end

local function hideBackAccessories(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		local var3 = v1:IsA("Accessory")
		if var3 then
			local var5 = v1:FindFirstChild("Handle")
			var3 = if var5 and var5:IsA("BasePart") then var5 else nil
		end

		if not var3 then
			continue
		end

		if var3:GetAttribute("ClassLookHid") ~= nil then
			continue
		end

		if not handleOn(var3, tbl8) then
			continue
		end

		var3:SetAttribute("ClassLookHid", var3.Transparency)
		var3.Transparency = 1
	end
end

local function liftClashes(arg1)
	for i1 = 1, 6 do
		local var1 = clashes(arg1)
		if #var1 == 0 then
			return
		end

		local tbl1 = {}
		for k1, v1 in ipairs(arg1:GetChildren()) do
			local var2 = v1:IsA("BasePart")
			if not var2 then
				continue
			end

			var2 = v1.Name .. tostring(v1.Position)
			local var3 = tbl1[var2]
			tbl1[var2] = var3 or {}
			table.insert(tbl1[var2], v1)
		end

		local tbl3 = {}
		for k2, v2 in ipairs(var1) do
			local var4 = v2[4]
			local var5 = v2[2]
			local var9 = v2[1]
			local var10 = v2[3]
			local var11 = var4
			local var12 = var5
			if var5.area * 3 < var4.area then
				var10 = var9
				var11 = var5
				var12 = var4
			end

			local var13 = tbl3[var10]
			if (var13 or {})[var11.axis] then
				continue
			end

			local var14 = var11.d - var12.d
			local var15 = tbl2.PlaneLift - math.abs(var14)
			local var16
			if var11.axis == 1 then
				var16 = var10.Size.X
			else
				var16 = if var11.axis == 2 then var10.Size.Y else var10.Size.Z
			end

			local var17 = if 0 <= var14 or var16 - 2 * var15 < 0.02 then 2 * (var15 + math.max(0, -var14)) else -2 * var15
			local var18
			if var11.axis == 1 then
				var18 = var68(var17, 0, 0)
			else
				var18 = if var11.axis == 2 then var68(0, var17, 0) else var68(0, 0, var17)
			end

			local var19 = var10.Name
			local var21 = tbl1[var19 .. tostring(var10.Position)]
			local var22 = ipairs
			if not var21 then
				var21 = { var10 }
			end

			for k3, v3 in var22(var21) do
				if v3.CFrame.Rotation ~= var10.CFrame.Rotation then
					continue
				end

				local var23 = tbl3[v3]
				var23 = var23 or {}
				tbl3[v3] = var23
				var23[var11.axis] = true
				local var24 = v3.Size + var18
				v3.Size = var24
			end
		end
	end
end

tbl2.apply = function(arg1, arg2, arg3)
	tbl2.clear(arg1)
	if not arg1 or (not arg2) then
		return nil
	end

	local var2 = tbl7[arg2]
	if not var2 then
		return nil
	end

	local var3 = arg3
	arg3 = var3 or {}
	var3 = Instance.new("Model")
	var3.Name = tbl2.ModelName
	var3:SetAttribute("ClassId", arg2)
	var3:SetAttribute("Compact", arg3.compact == true)
	local var4 = makeContext(arg1, var3, arg3.compact == true)
	var3:SetAttribute("Scale", var4.scale)
	if not var4.anchor("UpperTorso") then
		var3:Destroy()
		return nil
	end

	var2.build(var4)
	if var2.Mark then
		local var6 = var4.piece(var2.Mark.slot, "TeamMark", var2.Mark.offset, Vector3.new(0.16, 0.16, 0.12), var62, { Material = var69.Neon, Transparency = 1 })
		if var6 then
			var6:SetAttribute("Hidden", true)
		end
	end

	if var2.Back and (not arg3.compact) then
		hideBackAccessories(arg1)
	end

	liftClashes(var3)
	var3.Parent = arg1
	tbl2.setReduced(var3, arg3.reduced == true)
	tbl2.setLocal(var3, arg3.local_ == true)
	if arg3.arrive and (not arg3.reduced) then
		var3:SetAttribute("ArriveAt", os.clock())
		for k1, v1 in ipairs(var3:GetDescendants()) do
			if not v1:IsA("ParticleEmitter") then
				continue
			end

			if v1.Name ~= "Arrive" then
				continue
			end

			if v1:GetAttribute("Muted") then
				continue
			end

			v1:Emit(16)
		end
	end

	return var3
end

tbl2.fits = function(arg1, arg2)
	if not arg1 or (not arg2) then
		return true
	end

	local var2 = arg2:GetAttribute("HeadTop")
	if var2 == nil then
		return true
	end

	return math.abs(makeContext(arg1, Instance.new("Model"), false).headTop() - var2) < 0.08
end

local function eachNamed(arg1, arg2, arg3)
	if not arg1 then
		return
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1.Name ~= arg2 then
			continue
		end

		arg3(v1)
	end
end

tbl2.setCharge = function(arg1, arg2)
	local var2 = if arg2 == nil then 1 else math.clamp(arg2, 0, 1)
	if arg1 then
		arg1:SetAttribute("Charge", var2)
	end

	for i1 = 1, 3 do
		eachNamed(arg1, "Charge" .. i1, function(arg1)
			local var1 = var2
			local var3
			local var4
			if not ((i1 - 1) / 3 + 0.02 <= var1) then
				var3 = var12
				var4 = false
			elseif var1 <= 0.25 then
				var3 = var13
			else
				var3 = var11
			end

			arg1.Color = var3
			arg1.Material = if var4 then var69.Neon else var69.SmoothPlastic
		end)

	end
end

tbl2.setTechnician = function(arg1, arg2)
	local var2 = math.clamp(arg2 or 0, 0, 1)
	if arg1 then
		arg1:SetAttribute("Activity", var2)
	end

	eachNamed(arg1, "Cuff", function(arg1)
		if arg1.Material == var69.Neon then
			arg1.Color = var37:Lerp(var38, var2)
		end
	end)
end

tbl2.glint = function(arg1, arg2)
	eachNamed(arg1, "Clasp", function(arg1)
		local var3 = arg1:FindFirstChild("Glint")
		if not var3 then
			local var4 = emitter
			local var5 = arg1
			local str1 = "Glint"
			local var6 = ColorSequence.new
			local var7 = ColorSequenceKeypoint.new
			local num1 = 0
			var7 = var7(num1, if arg2 then var62 else var2)
			num1 = ColorSequenceKeypoint.new
			local num2 = 1
			local var8 = if arg2 then var61 else var18
			local tbl1 = { Color = var6({ var7, num1(num2, var8) }) }
			num2 = 1
			var8 = 0
			tbl1.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.16), NumberSequenceKeypoint.new(num2, var8) })
			tbl1.Lifetime = NumberRange.new(0.3, 0.5)
			tbl1.Speed = NumberRange.new(0.6, 1.2)
			tbl1.SpreadAngle = Vector2.new(50, 50)
			var3 = var4(var5, str1, tbl1)
		end

		if var3:IsA("ParticleEmitter") then
			if not var3:GetAttribute("Muted") then
				var3:Emit(if arg2 then 5 else 3)
			end
		end
	end)
end

tbl2.flare = function(arg1)
	eachNamed(arg1, "Flame", function(arg1)
		if arg1:IsA("ParticleEmitter") and (not arg1:GetAttribute("Muted")) then
			arg1:Emit(3)
		end
	end)
end

tbl2.vent = function(arg1)
	eachNamed(arg1, "Steam", function(arg1)
		if arg1:IsA("ParticleEmitter") and (not arg1:GetAttribute("Muted")) then
			arg1:Emit(3)
		end
	end)
end

tbl2.setTeamMark = function(arg1, arg2)
	eachNamed(arg1, "TeamMark", function(arg1)
		arg1.Transparency = if arg2 then 0 else 1
		arg1:SetAttribute("Hidden", not arg2)
	end)
end

local var72 = setmetatable({}, { __mode = "k" })
local function collect(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		local var1 = v1:IsA("BasePart")
		var1 = var1 and v1:GetAttribute("Fx")
		if not var1 then
			continue
		end

		local var2 = v1:FindFirstChild("Drift")
		local var3 = if var2 and var2:IsA("Weld") then var2 else nil
		local tbl2 = { part = v1, fx = var1, weld = var3, next = 0 }
		tbl2.hub = v1:GetAttribute("Hub")
		tbl2.loc = v1:GetAttribute("Local")
		tbl2.a = v1:GetAttribute("A")
		tbl2.b = v1:GetAttribute("B")
		tbl2.w = v1:GetAttribute("W") or 1
		tbl2.phase = v1:GetAttribute("Phase") or 0
		tbl2.base = v1:GetAttribute("Base") or 0
		tbl2.index = v1:GetAttribute("Index") or 1
		tbl2.arrive = v1:GetAttribute("Arrive") or 0
		tbl2.spin = v1:GetAttribute("Spin") or 0
		tbl2.period = v1:GetAttribute("Period") or 8
		tbl2.from = v1:GetAttribute("From")
		tbl2.to = v1:GetAttribute("To")
		local str1 = "P4"
		var3 = {
			v1:GetAttribute("P1"),
			v1:GetAttribute("P2"),
			v1:GetAttribute("P3"),
			v1:GetAttribute(str1),
		}

		tbl2.path = var3
		tbl2.color = v1.Color
		table.insert(tbl1, tbl2)
	end

	return tbl1
end

tbl2.animate = function(arg1, arg2)
	if not arg1 or (not arg1.Parent) then
		return
	end

	local var3 = var72[arg1]
	if not var3 then
		var3 = collect(arg1)
		var72[arg1] = var3
	end

	local var5 = arg1:GetAttribute("ArriveAt")
	local var7 = if typeof(var5) == "number" then 1 - (1 - math.clamp((os.clock() - var5) / 1.6, 0, 1)) ^ 3 else 1
	local var8 = arg1:GetAttribute("Charge")
	local var9 = arg1:GetAttribute("Activity") or 0
	local var10 = arg1:GetAttribute("Reduced") == true
	for k1, v1 in ipairs(var3) do
		local var15 = v1.fx
		local var16 = v1.part
		local var17
		if var15 == "Spin" and (v1.weld and v1.hub) then
			var17 = 0
			v1.weld.C0 = v1.hub * var70(var17, 0, v1.w * arg2 + v1.arrive * (var7 - 1)) * v1.loc
		else
			if var15 == "Orbit" and (v1.weld and v1.hub) then
				var17 = v1.spin * arg2
				v1.weld.C0 = v1.hub * var70(0, 0, v1.w * arg2 + v1.phase) * v1.loc * var70(0, var17, 0)
			else
				if var15 == "Bob" and (v1.weld and v1.hub) then
					var17 = 0
					v1.weld.C0 = v1.hub * var67(var17, v1.a * math.sin(v1.w * arg2), 0) * v1.loc
				else
					if var15 == "Sway" and (v1.weld and v1.hub) then
						var17 = 0
						v1.weld.C0 = v1.hub * var70(var17, 0, v1.a * math.sin(v1.w * arg2)) * v1.loc
					else
						if var15 == "Needle" and (v1.weld and v1.hub) then
							var17 = var70(0, 0, v1.base + v1.a * math.sin(v1.w * arg2) + math.noise(arg2 * 3, 0.5) * 0.087266462599716474)
							v1.weld.C0 = v1.hub * var17 * v1.loc
						else
							if var15 == "Pulse" and (v1.weld and (v1.hub and v1.path[1])) then
								local var18 = if var7 < 1 then 1 - var7 else 0
								local tbl1 = {}
								for k2, v2 in ipairs(v1.path) do
									table.insert(tbl1, v2)
								end

								local var19 = (arg2 * v1.w + v1.phase) % 1
								local var20 = math.clamp(var19, 0, 0.9999) * (#tbl1 - 1)
								local var21 = math.floor(var20)
								local var22 = tbl1[var21 + 1].Position:Lerp(tbl1[var21 + 2].Position, var20 - var21)
								local var23 = var22 * (arg1:GetAttribute("Scale") or 1)
								var20 = v1.hub
								v1.weld.C0 = var20 * var67(var23)
								var16.Transparency = if var19 < 0.08 or 0.92 < var19 then 0.7 else 0
							elseif var15 == "Glint" then
								if v1.weld then
									if v1.hub then
										if v1.from then
											if v1.to then
												local var35 = (arg2 + v1.phase) % v1.period / 0.6
												if var35 < 1 then
													local var36 = v1.from
													v1.weld.C0 = v1.hub * var67(var36.Position:Lerp(v1.to.Position, var35) * (arg1:GetAttribute("Scale") or 1)) * (var36 - var36.Position)
													var20 = math.abs(var35 - 0.5) * 0.7 * 2 + 0.15
													var16.Transparency = var20
												else
													if var16.Transparency >= 1 then
														continue
													end

													var16.Transparency = 1
													continue
												end
											elseif var15 == "Breathe" then
												local var39 = v1.a
												local var40 = v1.b
												var20 = math.sin(v1.w * arg2 + v1.phase) * 0.5 + 0.5 + var18
												var16.Color = (var39 or v1.color):Lerp(var40 or var4, (math.clamp(var20, 0, 1)))
											elseif var15 == "Flicker" then
												var20 = math.noise(arg2 * v1.w, v1.phase)
												local var41 = v1.a
												local var42 = v1.b
												var16.Color = (var41 or v1.color):Lerp(var42 or var4, (math.clamp(0.5 + 0.9 * var20, 0, 1)))
											elseif var15 == "Charge" then
												var20 = (v1.index - 1) / 3 + 0.02
												local var43 = if typeof(var8) == "number" then var8 else 1
												local var44
												local var45
												if not (var20 <= var43) then
													var44 = var12
													var45 = false
												else
													var20 = 0.25
													var44 = if var43 <= var20 then var13 else var11
													var45 = true
												end

												if var45 then
													var44 = var44:Lerp(var1("#FFF6CF"), math.max(0, (math.sin(arg2 * 1.8 - v1.index * 0.9))) * 0.75)
												end

												var16.Color = var44
											elseif var15 == "Core" then
												var20 = var4
												var16.Color = var37:Lerp(var38, var9):Lerp(var20, (math.sin(arg2 * (1.2 + var9 * 4.5)) * 0.5 + 0.5) * (0.25 + var9 * 0.25))
											elseif var15 == "Indicator" then
												var20 = v1.phase
												if 0.2 - var9 * 0.9 < math.sin(arg2 * (0.8 + var9 * 5) + var20) then
													var20 = var9
													var45 = var37:Lerp(var38, var20)
												else
													var45 = var34
												end

												var16.Color = var45
											elseif var15 == "Screen" then
												var16.Color = var37:Lerp(var38, var9):Lerp(var4, (math.sin(arg2 * 0.9) * 0.5 + 0.5) * 0.2)
											elseif var15 == "Exhaust" then
												if var10 then
													continue
												end

												if v1.next == 0 then
													v1.next = arg2 + 2 + v1.part.Position.X % 1 * 3
												else
													if v1.next > arg2 then
														continue
													end

													v1.next = arg2 + 4 + math.random() * 3
													local var46 = var16:FindFirstChild("Steam")
													if not var46 then
														continue
													end

													if not var46:IsA("ParticleEmitter") then
														continue
													end

													if var46:GetAttribute("Muted") then
														continue
													end

													var46:Emit(4)
												end
											end
										elseif var15 == "Breathe" then
											var44 = v1.a
											local var47 = v1.b
											var20 = math.sin(v1.w * arg2 + v1.phase) * 0.5 + 0.5 + var18
											var16.Color = (var44 or v1.color):Lerp(var47 or var4, (math.clamp(var20, 0, 1)))
										elseif var15 == "Flicker" then
											var20 = math.noise(arg2 * v1.w, v1.phase)
											var44 = v1.a
											local var48 = v1.b
											var16.Color = (var44 or v1.color):Lerp(var48 or var4, (math.clamp(0.5 + 0.9 * var20, 0, 1)))
										elseif var15 == "Charge" then
											var20 = (v1.index - 1) / 3 + 0.02
											local var49 = if typeof(var8) == "number" then var8 else 1
											if not (var20 <= var49) then
												var44 = var12
												var45 = false
											else
												var20 = 0.25
												var44 = if var49 <= var20 then var13 else var11
												var45 = true
											end

											if var45 then
												var44 = var44:Lerp(var1("#FFF6CF"), math.max(0, (math.sin(arg2 * 1.8 - v1.index * 0.9))) * 0.75)
											end

											var16.Color = var44
										elseif var15 == "Core" then
											var20 = var4
											var16.Color = var37:Lerp(var38, var9):Lerp(var20, (math.sin(arg2 * (1.2 + var9 * 4.5)) * 0.5 + 0.5) * (0.25 + var9 * 0.25))
										elseif var15 == "Indicator" then
											var20 = v1.phase
											if 0.2 - var9 * 0.9 < math.sin(arg2 * (0.8 + var9 * 5) + var20) then
												var20 = var9
												var45 = var37:Lerp(var38, var20)
											else
												var45 = var34
											end

											var16.Color = var45
										elseif var15 == "Screen" then
											var16.Color = var37:Lerp(var38, var9):Lerp(var4, (math.sin(arg2 * 0.9) * 0.5 + 0.5) * 0.2)
										elseif var15 == "Exhaust" then
											if var10 then
												continue
											end

											if v1.next == 0 then
												v1.next = arg2 + 2 + v1.part.Position.X % 1 * 3
											else
												if v1.next > arg2 then
													continue
												end

												v1.next = arg2 + 4 + math.random() * 3
												local var50 = var16:FindFirstChild("Steam")
												if not var50 then
													continue
												end

												if not var50:IsA("ParticleEmitter") then
													continue
												end

												if var50:GetAttribute("Muted") then
													continue
												end

												var50:Emit(4)
											end
										end
									elseif var15 == "Breathe" then
										var44 = v1.a
										local var51 = v1.b
										var20 = math.sin(v1.w * arg2 + v1.phase) * 0.5 + 0.5 + var18
										var16.Color = (var44 or v1.color):Lerp(var51 or var4, (math.clamp(var20, 0, 1)))
									elseif var15 == "Flicker" then
										var20 = math.noise(arg2 * v1.w, v1.phase)
										var44 = v1.a
										local var52 = v1.b
										var16.Color = (var44 or v1.color):Lerp(var52 or var4, (math.clamp(0.5 + 0.9 * var20, 0, 1)))
									elseif var15 == "Charge" then
										var20 = (v1.index - 1) / 3 + 0.02
										local var53 = if typeof(var8) == "number" then var8 else 1
										if not (var20 <= var53) then
											var44 = var12
											var45 = false
										else
											var20 = 0.25
											var44 = if var53 <= var20 then var13 else var11
											var45 = true
										end

										if var45 then
											var44 = var44:Lerp(var1("#FFF6CF"), math.max(0, (math.sin(arg2 * 1.8 - v1.index * 0.9))) * 0.75)
										end

										var16.Color = var44
									elseif var15 == "Core" then
										var20 = var4
										var16.Color = var37:Lerp(var38, var9):Lerp(var20, (math.sin(arg2 * (1.2 + var9 * 4.5)) * 0.5 + 0.5) * (0.25 + var9 * 0.25))
									elseif var15 == "Indicator" then
										var20 = v1.phase
										if 0.2 - var9 * 0.9 < math.sin(arg2 * (0.8 + var9 * 5) + var20) then
											var20 = var9
											var45 = var37:Lerp(var38, var20)
										else
											var45 = var34
										end

										var16.Color = var45
									elseif var15 == "Screen" then
										var16.Color = var37:Lerp(var38, var9):Lerp(var4, (math.sin(arg2 * 0.9) * 0.5 + 0.5) * 0.2)
									elseif var15 == "Exhaust" then
										if var10 then
											continue
										end

										if v1.next == 0 then
											v1.next = arg2 + 2 + v1.part.Position.X % 1 * 3
										else
											if v1.next > arg2 then
												continue
											end

											v1.next = arg2 + 4 + math.random() * 3
											local var54 = var16:FindFirstChild("Steam")
											if not var54 then
												continue
											end

											if not var54:IsA("ParticleEmitter") then
												continue
											end

											if var54:GetAttribute("Muted") then
												continue
											end

											var54:Emit(4)
										end
									end
								elseif var15 == "Breathe" then
									var44 = v1.a
									local var55 = v1.b
									var20 = math.sin(v1.w * arg2 + v1.phase) * 0.5 + 0.5 + var18
									var16.Color = (var44 or v1.color):Lerp(var55 or var4, (math.clamp(var20, 0, 1)))
								elseif var15 == "Flicker" then
									var20 = math.noise(arg2 * v1.w, v1.phase)
									var44 = v1.a
									local var56 = v1.b
									var16.Color = (var44 or v1.color):Lerp(var56 or var4, (math.clamp(0.5 + 0.9 * var20, 0, 1)))
								elseif var15 == "Charge" then
									var20 = (v1.index - 1) / 3 + 0.02
									local var57 = if typeof(var8) == "number" then var8 else 1
									if not (var20 <= var57) then
										var44 = var12
										var45 = false
									else
										var20 = 0.25
										var44 = if var57 <= var20 then var13 else var11
										var45 = true
									end

									if var45 then
										var44 = var44:Lerp(var1("#FFF6CF"), math.max(0, (math.sin(arg2 * 1.8 - v1.index * 0.9))) * 0.75)
									end

									var16.Color = var44
								elseif var15 == "Core" then
									var20 = var4
									var16.Color = var37:Lerp(var38, var9):Lerp(var20, (math.sin(arg2 * (1.2 + var9 * 4.5)) * 0.5 + 0.5) * (0.25 + var9 * 0.25))
								elseif var15 == "Indicator" then
									var20 = v1.phase
									if 0.2 - var9 * 0.9 < math.sin(arg2 * (0.8 + var9 * 5) + var20) then
										var20 = var9
										var45 = var37:Lerp(var38, var20)
									else
										var45 = var34
									end

									var16.Color = var45
								elseif var15 == "Screen" then
									var16.Color = var37:Lerp(var38, var9):Lerp(var4, (math.sin(arg2 * 0.9) * 0.5 + 0.5) * 0.2)
								elseif var15 == "Exhaust" then
									if var10 then
										continue
									end

									if v1.next == 0 then
										v1.next = arg2 + 2 + v1.part.Position.X % 1 * 3
									else
										if v1.next > arg2 then
											continue
										end

										v1.next = arg2 + 4 + math.random() * 3
										local var58 = var16:FindFirstChild("Steam")
										if not var58 then
											continue
										end

										if not var58:IsA("ParticleEmitter") then
											continue
										end

										if var58:GetAttribute("Muted") then
											continue
										end

										var58:Emit(4)
									end
								end
							elseif var15 == "Breathe" then
								var44 = v1.a
								local var59 = v1.b
								var20 = math.sin(v1.w * arg2 + v1.phase) * 0.5 + 0.5 + var18
								var16.Color = (var44 or v1.color):Lerp(var59 or var4, (math.clamp(var20, 0, 1)))
							elseif var15 == "Flicker" then
								var20 = math.noise(arg2 * v1.w, v1.phase)
								var44 = v1.a
								local var60 = v1.b
								var16.Color = (var44 or v1.color):Lerp(var60 or var4, (math.clamp(0.5 + 0.9 * var20, 0, 1)))
							elseif var15 == "Charge" then
								var20 = (v1.index - 1) / 3 + 0.02
								local var61 = if typeof(var8) == "number" then var8 else 1
								if not (var20 <= var61) then
									var44 = var12
									var45 = false
								else
									var20 = 0.25
									var44 = if var61 <= var20 then var13 else var11
									var45 = true
								end

								if var45 then
									var44 = var44:Lerp(var1("#FFF6CF"), math.max(0, (math.sin(arg2 * 1.8 - v1.index * 0.9))) * 0.75)
								end

								var16.Color = var44
							elseif var15 == "Core" then
								var20 = var4
								var16.Color = var37:Lerp(var38, var9):Lerp(var20, (math.sin(arg2 * (1.2 + var9 * 4.5)) * 0.5 + 0.5) * (0.25 + var9 * 0.25))
							elseif var15 == "Indicator" then
								var20 = v1.phase
								if 0.2 - var9 * 0.9 < math.sin(arg2 * (0.8 + var9 * 5) + var20) then
									var20 = var9
									var45 = var37:Lerp(var38, var20)
								else
									var45 = var34
								end

								var16.Color = var45
							elseif var15 == "Screen" then
								var16.Color = var37:Lerp(var38, var9):Lerp(var4, (math.sin(arg2 * 0.9) * 0.5 + 0.5) * 0.2)
							elseif var15 == "Exhaust" then
								if var10 then
									continue
								end

								if v1.next == 0 then
									v1.next = arg2 + 2 + v1.part.Position.X % 1 * 3
								else
									if v1.next > arg2 then
										continue
									end

									v1.next = arg2 + 4 + math.random() * 3
									local var62 = var16:FindFirstChild("Steam")
									if not var62 then
										continue
									end

									if not var62:IsA("ParticleEmitter") then
										continue
									end

									if var62:GetAttribute("Muted") then
										continue
									end

									var62:Emit(4)
								end
							end
						end
					end
				end
			end
		end
	end
end

tbl2.drifts = function(arg1)
	local var1 = arg1
	var1 = var1 and tbl7[arg1]
	local bool1 = false
	if var1 ~= nil then
		bool1 = var1.Animated == true
	end

	return bool1
end

tbl2.shards = function(arg1, arg2)
	tbl2.animate(arg1, arg2)
end

tbl2.setLocal = function(arg1, arg2)
	if not arg1 then
		return
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("ParticleEmitter") then
			v1:SetAttribute("Muted", arg2 == true)
			if arg2 then
				v1.Enabled = false
			else
				if not v1:GetAttribute("BaseRate") then
					continue
				end

				v1.Enabled = 0 < v1.Rate
				continue
			end
		else
			if not v1:IsA("Light") then
				continue
			end

			v1.Enabled = not arg2
		end
	end
end

tbl2.setReduced = function(arg1, arg2)
	if not arg1 then
		return
	end

	arg1:SetAttribute("Reduced", arg2 == true)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("ParticleEmitter") then
			local var3 = v1:GetAttribute("BaseRate")
			if var3 == nil then
				var3 = v1.Rate
				v1:SetAttribute("BaseRate", var3)
			end

			v1.Rate = if arg2 then var3 * 0.3 else var3
			if v1:GetAttribute("Muted") then
				continue
			end

			v1.Enabled = 0 < v1.Rate
		else
			if not v1:IsA("Light") then
				continue
			end

			local var5 = v1:GetAttribute("BaseBrightness")
			if var5 == nil then
				var5 = v1.Brightness
				v1:SetAttribute("BaseBrightness", var5)
			end

			v1.Brightness = if arg2 then var5 * 0.5 else var5
		end
	end
end

return tbl2

--- ReplicatedStorage.MeltShared.Difficulty [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local tbl1 = {
	Id = "normal",
	Name = "NORMAL",
	Order = 1,
	RequiresNormalCompletion = false,
	CoinMultiplier = 1,
	CompletionGems = 500,
	IceLayout = "normal",
	Color = var1("#3E7FB8"),
}

tbl1.Accent = var1("#8FC4EC")
tbl1.Summary = { "Reward: 500 Gems" }
local tbl2 = {
	Id = "hard",
	Name = "HARD",
	Order = 2,
	RequiresNormalCompletion = true,
	CoinMultiplier = 0.8,
	CompletionGems = 1500,
	IceLayout = "hard",
	Color = var1("#C4562F"),
}

tbl2.Accent = var1("#F09A5E")
local str1 = "Reward: 1,500 Gems"
tbl2.Summary = { str1 }
local tbl3 = {
	Default = "normal",
	LockedLabel = "Beat Normal to unlock",
	LockedJoin = "Beat Level 1 on Normal to join Hard Mode.",
	LoadingLabel = "Loading unlocks\226\128\166",
	List = { tbl1, tbl2 },
	ById = {},
}

for k1, v1 in ipairs(tbl3.List) do
	tbl3.ById[v1.Id] = v1
end

tbl3.LevelEconomy = {
	polarmaxTower = {
		normal = { CompletionGems = 1000 },
		hard = { CompletionGems = 3000, CoinMultiplier = 0.6 },
	},
	funfair = {
		normal = { CompletionGems = 1500 },
		hard = { CompletionGems = 4500, CoinMultiplier = 0.6 },
	},
	bulwark = {
		normal = { CompletionGems = 2000 },
		hard = { CompletionGems = 6000, CoinMultiplier = 0.6 },
	},
}

local function grouped(arg1)
	local var1 = tostring((math.floor(arg1)))
	repeat
		local var2, var3 = string.gsub(var1, "^(-?%d+)(%d%d%d)", "%1,%2")
		local var4 = nil
		var1 = var2
	until var3 == 0

	return var1
end

tbl3.forLevel = function(arg1, arg2)
	local var2 = tbl3.get(arg2)
	if not var2 then
		return nil
	end

	local var3 = if typeof(arg1) == "string" then tbl3.LevelEconomy[arg1] else nil
	local var4 = var3
	var4 = var4 and var3[var2.Id]
	if not var4 then
		return var2
	end

	local var5 = var4.CompletionGems
	local var6 = table.clone(var2)
	var6.CompletionGems = var5 or var2.CompletionGems
	var5 = var4.CoinMultiplier
	var6.CoinMultiplier = var5 or var2.CoinMultiplier
	var5 = { "Reward: " .. grouped(var6.CompletionGems) .. " Gems" }
	var6.Summary = var5
	return var6
end

tbl3.isDifficulty = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl3.ById[arg1] ~= nil
	end

	return bool1
end

tbl3.get = function(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	return tbl3.ById[arg1]
end

tbl3.resolve = function(arg1)
	if arg1 == nil then
		return tbl3.ById[tbl3.Default], "missing"
	end

	local var2 = tbl3.get(arg1)
	if var2 then
		return var2, "ok"
	end

	return tbl3.ById[tbl3.Default], "invalid"
end

tbl3.requiresUnlock = function(arg1)
	local var2 = tbl3.get(arg1)
	local bool2 = false
	if var2 ~= nil then
		bool2 = var2.RequiresNormalCompletion
	end

	return bool2
end

tbl3.allows = function(arg1, arg2)
	local var2 = tbl3.get(arg1)
	if not var2 then
		return false
	end

	local var4 = not var2.RequiresNormalCompletion
	if not var4 then
		var4 = arg2 == true
	end

	return var4
end

return tbl3

--- ReplicatedStorage.MeltShared.Upgrades [ModuleScript]
-- y u r i

local tbl1 = {
	Id = "cheaperWeapons",
	Title = "CHEAPER WEAPONS",
	Description = "Pay less for coin-priced tools.",
	Note = "Does not affect Robux items or tool upgrades.",
	Icon = "CheaperWeapons",
	Costs = { 75, 150, 300, 600, 1200 },
	PerLevel = 0.05,
	Unit = "fraction",
}

local tbl2 = {
	MaxLevel = 5,
	List = {
		{
			Id = "battery",
			Title = "BATTERY",
			Description = "Melt for longer before recharging.",
			Icon = "Battery",
			Costs = { 50, 100, 200, 400, 800 },
			PerLevel = 0.5,
			Unit = "seconds",
		},
		{
			Id = "iceValue",
			Title = "ICE VALUE",
			Description = "Earn more coins from melting ice.",
			Icon = "IceValue",
			Costs = { 100, 200, 400, 800, 1600 },
			PerLevel = 0.1,
			Unit = "fraction",
		},
		{
			Id = "gemValue",
			Title = "GEM VALUE",
			Description = "Earn more gems when you finish a run.",
			Icon = "GemValue",
			Costs = { 150, 300, 600, 1200, 2400 },
			PerLevel = 0.05,
			Unit = "fraction",
		},
		tbl1,
	},
	ById = {},
}

for k1, v1 in ipairs(tbl2.List) do
	tbl2.ById[v1.Id] = v1
end

tbl2.isUpgrade = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.ById[arg1] ~= nil
	end

	return bool1
end

tbl2.clampLevel = function(arg1)
	if typeof(arg1) ~= "number" or arg1 ~= arg1 then
		return 0
	end

	return (math.clamp(math.floor(arg1), 0, tbl2.MaxLevel))
end

tbl2.nextCost = function(arg1, arg2)
	local var1 = tbl2.ById
	local var3 = var1[if typeof(arg1) == "string" then arg1 else ""]
	if not var3 then
		return nil
	end

	var1 = tbl2.clampLevel(arg2) + 1
	if var1 <= tbl2.MaxLevel then
		return var3.Costs[var1]
	end

	return nil
end

tbl2.totalCost = function(arg1)
	local var2 = tbl2.ById[arg1]
	local num1 = 0
	if var2 then
		for k1, v1 in ipairs(var2.Costs) do
			num1 = num1 + v1
		end
	end

	return num1
end

tbl2.effect = function(arg1, arg2)
	local var1 = tbl2.ById
	local var3 = var1[if typeof(arg1) == "string" then arg1 else ""]
	if not var3 then
		return 0
	end

	return var3.PerLevel * tbl2.clampLevel(arg2)
end

tbl2.sanitise = function(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.List) do
		local var1 = v1.Id
		local var2 = tbl2.clampLevel
		tbl1[var1] = var2(if typeof(arg1) == "table" then arg1[v1.Id] else nil)
	end

	return tbl1
end

tbl2.zero = function()
	local var1 = nil
	return tbl2.sanitise(var1)
end

tbl2.batterySeconds = function(arg1)
	local var1 = arg1
	local str1 = "battery"
	var1 = var1 and arg1.battery
	return tbl2.effect(str1, var1)
end

tbl2.iceCoinMultiplier = function(arg1)
	local var1 = arg1
	return 1 + tbl2.effect("iceValue", var1 and arg1.iceValue)
end

tbl2.gemRewardMultiplier = function(arg1)
	local var1 = arg1
	return 1 + tbl2.effect("gemValue", var1 and arg1.gemValue)
end

tbl2.toolDiscount = function(arg1)
	local var1 = arg1
	local str1 = "cheaperWeapons"
	var1 = var1 and arg1.cheaperWeapons
	return tbl2.effect(str1, var1)
end

tbl2.benefitText = function(arg1, arg2)
	local var1 = tbl2.ById
	local var3 = var1[if typeof(arg1) == "string" then arg1 else ""]
	if not var3 then
		return ""
	end

	var1 = tbl2.effect(arg1, arg2)
	if var3.Unit == "seconds" then
		local str2 = "+%.1fs"
		local var5 = var1
		return string.format(str2, var5)
	end

	if var3.Id == "cheaperWeapons" then
		local str3 = "%d%% off"
		local var6 = math.floor(var1 * 100 + 0.5)
		return string.format(str3, var6)
	end

	local str4 = "+%d%%"
	local var7 = math.floor(var1 * 100 + 0.5)
	return string.format(str4, var7)
end

tbl2.stepText = function(arg1, arg2)
	local var2 = tbl2.clampLevel(arg2)
	if tbl2.MaxLevel <= var2 then
		return nil
	end

	return tbl2.benefitText(arg1, var2) .. "  \226\134\146  " .. tbl2.benefitText(arg1, var2 + 1)
end

return tbl2

--- ReplicatedStorage.MeltShared.Leaderboards [ModuleScript]
-- y u r i

local tbl1 = {
	Id = "bulwark",
	Number = 4,
	Name = "The Great Wall",
	Destination = "Bulwark",
	Blurb = "Carve a route through the containment wall. Reach the other side.",
	RequiresLevel = "funfair",
	RequiresDifficulty = "normal",
}

local tbl2 = {
	Version = 1,
	Prefix = "MeltLB_v1",
	TopCount = 50,
	RefreshSeconds = 60,
	RefreshJitter = 12,
	StaleSeconds = 600,
	Levels = {
		{
			Id = "frozenHouse",
			Number = 1,
			Name = "Frozen House",
			Destination = "FrozenHouse",
			Blurb = "Melt the house and free the freezer.",
		},
		{
			Id = "polarmaxTower",
			Number = 2,
			Name = "Polarmax Tower",
			Destination = "PolarmaxTower",
			Blurb = "Melt five floors and shut down the rooftop freezer.",
			RequiresLevel = "frozenHouse",
			RequiresDifficulty = "normal",
		},
		{
			Id = "funfair",
			Number = 3,
			Name = "Melt the Funfair!",
			Destination = "Funfair",
			Blurb = "Bring a frozen funfair back to life and ride the wheel to Polarmax.",
			RequiresLevel = "polarmaxTower",
			RequiresDifficulty = "normal",
		},
		tbl1,
	},
	DefaultLevel = "frozenHouse",
	LevelById = {},
}

for k1, v1 in ipairs(tbl2.Levels) do
	tbl2.LevelById[v1.Id] = v1
end

tbl2.isLevel = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.LevelById[arg1] ~= nil
	end

	return bool1
end

tbl2.requirement = function(arg1)
	local var1 = tbl2.LevelById
	local var3 = var1[if typeof(arg1) == "string" then arg1 else ""]
	if not var3 or (not var3.RequiresLevel) then
		return nil, nil
	end

	return var3.RequiresLevel, var3.RequiresDifficulty or "normal"
end

tbl2.level = function(arg1)
	local var1 = tbl2.LevelById
	local var2 = var1[if typeof(arg1) == "string" then arg1 else ""]
	return var2 or tbl2.LevelById[tbl2.DefaultLevel]
end

tbl2.Boards = {
	{
		Id = "time",
		Title = "FASTEST TIME",
		Caption = "Best completion time \226\128\162 Solo & co-op",
		Ascending = true,
		Filtered = true,
		Personal = "YOUR BEST",
		Empty = "No records yet \226\128\148 set the first one!",
		Unit = "milliseconds of one completed run",
	},
	{
		Id = "wins",
		Title = "TOTAL WINS",
		Caption = "Completed runs \226\128\162 every level and difficulty",
		Ascending = false,
		Filtered = false,
		Personal = "YOUR WINS",
		Empty = "No wins yet \226\128\148 be the first!",
		Unit = "completed runs",
	},
	{
		Id = "ice",
		Title = "ICE MELTED",
		Caption = "Gameplay ice removed \226\128\162 1 unit = 1 cubic stud",
		Ascending = false,
		Filtered = false,
		Personal = "YOUR ICE MELTED",
		Empty = "No ice melted yet \226\128\148 go and melt some!",
		Unit = "cubic studs of gameplay ice",
	},
}

tbl2.BoardById = {}
for k2, v2 in ipairs(tbl2.Boards) do
	tbl2.BoardById[v2.Id] = v2
end

tbl2.isBoard = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.BoardById[arg1] ~= nil
	end

	return bool1
end

tbl2.board = function(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	return tbl2.BoardById[arg1]
end

tbl2.category = function(arg1, arg2, arg3, arg4)
	local var2 = tbl2.board(arg1)
	if not var2 then
		return nil, nil
	end

	if not var2.Filtered then
		return var2.Id, { board = var2.Id }
	end

	if not tbl2.isLevel(arg2) or (not arg4.isDifficulty(arg3)) then
		return nil, nil
	end

	local var3 = string.format("%s:%s:%s", var2.Id, arg2, arg3)
	return var3, { board = var2.Id, level = arg2, difficulty = arg3 }
end

tbl2.storeName = function(arg1)
	if arg1.level and arg1.difficulty then
		local str2 = "%s_%s_%s_%s"
		local var5 = tbl2.Prefix
		local var6 = arg1.board
		local var7 = arg1.level
		local var8 = arg1.difficulty
		return string.format(str2, var5, var6, var7, var8)
	end

	local str3 = "%s_%s"
	local var9 = tbl2.Prefix
	local var10 = arg1.board
	return string.format(str3, var9, var10)
end

tbl2.allCategories = function(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.Boards) do
		local var1
		local var2
		if v1.Filtered then
			for k2, v2 in ipairs(tbl2.Levels) do
				for k3, v3 in ipairs(arg1.List) do
					table.insert(tbl1, { board = v1.Id, level = v2.Id, difficulty = v3.Id })
				end
			end
		else
			table.insert(tbl1, { board = v1.Id })
		end
	end

	return tbl1
end

tbl2.MaxValue = 9007199254740992
tbl2.MaxTimeMs = 86400000
tbl2.IceUnitStuds = 1
tbl2.iceUnits = function(arg1)
	if typeof(arg1) ~= "number" or (arg1 ~= arg1 or arg1 <= 0) then
		return 0
	end

	return (math.min(math.floor(arg1 / tbl2.IceUnitStuds), tbl2.MaxValue))
end

tbl2.validValue = function(arg1, arg2)
	if typeof(arg2) ~= "number" or (arg2 ~= arg2 or arg2 ~= math.floor(arg2)) then
		return false
	end

	if arg1 == "time" then
		local bool1 = false
		if 0 < arg2 then
			bool1 = arg2 <= tbl2.MaxTimeMs
		end

		return bool1
	end

	local bool2 = false
	if 0 < arg2 then
		bool2 = arg2 <= tbl2.MaxValue
	end

	return bool2
end

tbl2.formatTime = function(arg1)
	if typeof(arg1) ~= "number" or (arg1 ~= arg1 or arg1 <= 0) then
		return "--:--.--"
	end

	local var1 = math.floor(arg1 + 0.5)
	local var10 = math.floor(var1 / 3600000)
	local var11 = math.floor(var1 / 10) % 100
	local var12 = math.floor(var1 / 1000) % 60
	local var13 = math.floor(var1 / 60000) % 60
	if 0 < var10 then
		local str2 = "%d:%02d:%02d.%02d"
		local var14 = var10
		local var15 = var13
		local var16 = var12
		local var17 = var11
		return string.format(str2, var14, var15, var16, var17)
	end

	local str3 = "%02d:%02d.%02d"
	local var18 = var13
	local var19 = var12
	local var20 = var11
	return string.format(str3, var18, var19, var20)
end

tbl2.formatCount = function(arg1)
	if typeof(arg1) ~= "number" or arg1 ~= arg1 then
		return "0"
	end

	local var1 = tostring((math.floor((math.abs(arg1)))))
	local str1 = ""
	while 3 < (#var1) do
		str1 = "," .. string.sub(var1, -3) .. str1
		var1 = string.sub(var1, 1, #var1 - 3)
	end

	str1 = var1 .. str1
	if arg1 < 0 then
		return "-" .. str1
	end

	return str1
end

tbl2.abbreviate = function(arg1)
	if typeof(arg1) ~= "number" or arg1 ~= arg1 then
		return "0"
	end

	local var1 = math.floor((math.abs(arg1)))
	local tbl1 = { 1000000000, "B" }
	local var2 = if arg1 < 0 then "-" else ""
	for k1, v1 in ipairs({ { 1000000000000, "T" }, tbl1, { 1000000, "M" }, { 1000, "K" } }) do
		local var3 = v1[1]
		if var3 > var1 then
			continue
		end

		local var5 = var1 / var3
		local var6 = v1[2]
		if var5 < 100 then
			local str1 = "%s%.1f%s"
			local var7 = var2
			local var8 = math.floor(var5 * 10) / 10
			local var9 = var6
			return string.format(str1, var7, var8, var9)
		end

		local str2 = "%s%d%s"
		local var10 = var2
		local var11 = math.floor(var5)
		local var12 = var6
		return string.format(str2, var10, var11, var12)
	end

	return var2 .. tbl2.formatCount(var1)
end

tbl2.formatValue = function(arg1, arg2)
	if arg1 == "time" then
		local var2 = arg2
		return tbl2.formatTime(var2)
	end

	local var3 = arg2
	return tbl2.formatCount(var3)
end

tbl2.subtitle = function(arg1, arg2)
	if not arg1.level or (not arg1.difficulty) then
		return "ALL LEVELS"
	end

	local var2 = arg2.get(arg1.difficulty)
	local var3 = string.format
	local str1 = "LEVEL %d \226\128\162 %s"
	local var4 = tbl2.level(arg1.level).Number
	local var5 = if var2 then var2.Name else "?"
	return var3(str1, var4, var5)
end

tbl2.outsideRanking = function(arg1, arg2)
	local bool2 = false
	if typeof(arg1) == "number" then
		bool2 = false
		if tbl2.TopCount <= arg1 then
			bool2 = arg2 ~= true
		end
	end

	return bool2
end

local tbl3 = { Name = "Gold", Color = Color3.fromHex("#F2C14E") }
tbl3.Edge = Color3.fromHex("#B8860B")
local tbl4 = { tbl3 }
tbl3 = { Name = "Silver", Color = Color3.fromHex("#D5DDE5") }
tbl3.Edge = Color3.fromHex("#8D9BA8")
tbl4[2] = tbl3
tbl3 = { Name = "Bronze", Color = Color3.fromHex("#D08A52") }
tbl3.Edge = Color3.fromHex("#96603A")
tbl4[3] = tbl3
tbl2.Medals = tbl4
tbl2.medal = function(arg1)
	return tbl2.Medals[arg1]
end

return tbl2

--- ReplicatedStorage.MeltShared.GamePasses [ModuleScript]
-- y u r i

local tbl1 = {
	Key = "PermanentSteamBlaster",
	GamePassId = 1994324356,
	Name = "Permanent Steam Blaster",
	BasePrice = 149,
	ToolId = "SteamBlaster",
	Description = "The Steam Blaster in every run, for good, without buying it with coins each time.",
	DisplayLines = { "Yours in every run", "Never expires" },
}

local tbl2 = {
	List = {
		{
			Key = "PermanentFlamethrower",
			GamePassId = 1985895297,
			Name = "Permanent Flamethrower",
			BasePrice = 225,
			ToolId = "Flamethrower",
			Description = "Unlocks the Flamethrower in every run, for good. The one-run unlock sold beside it is for a single run; this one never expires.",
			DisplayLines = { "Yours in every run", "Never expires" },
		},
		{
			Key = "DoubleLuck",
			GamePassId = 1986891118,
			Name = "2x Luck",
			BasePrice = 180,
			Description = "Doubles the chance of spinning a Legendary class or better. The extra chance comes out of the commonest classes, mostly the Starter.",
			DisplayLines = { "Double Legendary+ odds", "On every spin, for good" },
		},
		{
			Key = "PermanentHeatGun",
			GamePassId = 1995386335,
			Name = "Permanent Heat Gun",
			BasePrice = 69,
			ToolId = "HeatGun",
			Description = "The Heat Gun in every run, for good, without buying it with coins each time.",
			DisplayLines = { "Yours in every run", "Never expires" },
		},
		tbl1,
		{
			Key = "PermanentDoubleBattery",
			GamePassId = 1996022352,
			Name = "Permanent Double Battery",
			BasePrice = 199,
			ProductKey = "DoubleBattery",
			BatteryMultiplier = 2,
			Description = "Every tool's battery doubled in every run, for good.",
			DisplayLines = { "Double battery in every run", "Never expires" },
		},
		{
			Key = "InstantSpin",
			GamePassId = 1993574254,
			Name = "Instant Spin",
			BasePrice = 169,
			Description = "Skips the rolling animation: your class spin lands on its result straight away.",
			DisplayLines = { "Skip the rolling animation", "On every spin, for good" },
		},
		{
			Key = "ClassSlot",
			GamePassId = 1999101043,
			Name = "New class slot",
			BasePrice = 110,
			Description = "A second class slot: keep your best class safe in one and spin with the other.",
			DisplayLines = { "A second class slot", "For good" },
		},
		{
			Key = "VIP",
			GamePassId = 2002022578,
			Name = "VIP",
			BasePrice = 249,
			Description = "+50% gems from every level you finish, 500 free gems every day, and a golden VIP aura in the lobby.",
			DisplayLines = { "+50% gems from runs", "500 gems every day", "Lobby aura" },
		},
	},
	ByKey = {},
}

for k1, v1 in ipairs(tbl2.List) do
	tbl2.ByKey[v1.Key] = v1
end

tbl2.DoubleLuckKey = "DoubleLuck"
tbl2.doubleLuck = function()
	local var1 = tbl2.ByKey[tbl2.DoubleLuckKey]
	if tbl2.configured(var1) then
		return var1
	end

	return nil
end

tbl2.InstantSpinKey = "InstantSpin"
tbl2.ClassSlotKey = "ClassSlot"
tbl2.classSlot = function()
	local var1 = tbl2.ByKey[tbl2.ClassSlotKey]
	if tbl2.configured(var1) then
		return var1
	end

	return nil
end

tbl2.VipKey = "VIP"
tbl2.vip = function()
	local var1 = tbl2.ByKey[tbl2.VipKey]
	if tbl2.configured(var1) then
		return var1
	end

	return nil
end

tbl2.instantSpin = function()
	local var1 = tbl2.ByKey[tbl2.InstantSpinKey]
	if tbl2.configured(var1) then
		return var1
	end

	return nil
end

tbl2.configured = function(arg1)
	local bool2 = false
	if arg1 ~= nil then
		bool2 = false
		if typeof(arg1.GamePassId) == "number" then
			bool2 = 0 < arg1.GamePassId
		end
	end

	return bool2
end

tbl2.forTool = function(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	for k1, v1 in ipairs(tbl2.List) do
		if v1.ToolId ~= arg1 then
			continue
		end

		if not tbl2.configured(v1) then
			continue
		end

		return v1
	end

	return nil
end

tbl2.forProduct = function(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	for k1, v1 in ipairs(tbl2.List) do
		if v1.ProductKey ~= arg1 then
			continue
		end

		if not tbl2.configured(v1) then
			continue
		end

		return v1
	end

	return nil
end

tbl2.batteryMultiplier = function(arg1)
	local var1 = if arg1 then arg1.BatteryMultiplier else nil
	if typeof(var1) == "number" and 1 < var1 then
		return var1
	end

	return 1
end

tbl2.byId = function(arg1)
	if typeof(arg1) ~= "number" or arg1 <= 0 then
		return nil
	end

	for k1, v1 in ipairs(tbl2.List) do
		if v1.GamePassId ~= arg1 then
			continue
		end

		return v1
	end

	return nil
end

tbl2.ids = function()
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.List) do
		if not tbl2.configured(v1) then
			continue
		end

		table.insert(tbl1, v1.GamePassId)
	end

	return tbl1
end

tbl2.attribute = function(arg1)
	return "Pass_" .. arg1.Key
end

return tbl2

--- ReplicatedStorage.MeltShared.ControlHints [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Controls)
local tbl1 = {}
tbl1.__index = tbl1
local function new(arg1, arg2, arg3)
	local var1 = arg2
	local var2 = Instance.new(arg1)
	for k1, v1 in pairs(var1 or {}) do
		if k1 == "Parent" then
			continue
		end

		var2[k1] = v1
	end

	var1 = arg3
	for k2, v2 in ipairs(var1 or {}) do
		v2.Parent = var2
	end

	if arg2 and arg2.Parent then
		var2.Parent = arg2.Parent
	end

	return var2
end

tbl1.new = function(arg1, arg2)
	local var2 = setmetatable({}, tbl1)
	var2.theme = arg2
	var2.chips = {}
	var2.entries = {}
	local var3 = arg2.Background
	var3 = var3 or Color3.new(0, 0, 0)
	local var4 = new
	local str1 = "Frame"
	local tbl3 = { Name = "ControlHints", BackgroundColor3 = var3, BorderSizePixel = 0, Visible = false }
	if arg1.Transparency ~= nil then
		var3 = arg1.Transparency
	else
		var3 = 0.35
	end

	tbl3.BackgroundTransparency = var3
	var3 = arg1.AnchorPoint
	var3 = var3 or Vector2.new(0.5, 1)
	tbl3.AnchorPoint = var3
	var3 = arg1.Position
	var3 = var3 or UDim2.fromScale(0.5, 1)
	tbl3.Position = var3
	tbl3.AutomaticSize = Enum.AutomaticSize.XY
	tbl3.Size = UDim2.fromOffset(0, 0)
	tbl3.ZIndex = arg1.ZIndex or 50
	tbl3.Parent = arg1.Parent
	local var5 = new("UICorner", { CornerRadius = UDim.new(0, 16) })
	local tbl4 = { PaddingLeft = UDim.new(0, 14) }
	tbl4.PaddingRight = UDim.new(0, 14)
	tbl4.PaddingTop = UDim.new(0, 7)
	tbl4.PaddingBottom = UDim.new(0, 7)
	local var6 = new("UIPadding", tbl4)
	local var7 = arg1.Alignment
	local tbl5 = {
		FillDirection = Enum.FillDirection.Horizontal,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		HorizontalAlignment = var7 or Enum.HorizontalAlignment.Center,
	}

	tbl5.Padding = UDim.new(0, 18)
	tbl5.SortOrder = Enum.SortOrder.LayoutOrder
	var2.root = var4(str1, tbl3, { var5, var6, (new("UIListLayout", tbl5)) })
	if arg2.Stroke then
		new("UIStroke", { Color = arg2.Stroke, Thickness = 2, Parent = var2.root })
	end

	var2.connection = var1.changed:Connect(function()
		var2:_render()
	end)

	return var2
end

tbl1._chip = function(arg1, arg2)
	local tbl1 = {
		Name = "Chip" .. arg2,
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.XY,
		Size = UDim2.fromOffset(0, 28),
	}

	tbl1.LayoutOrder = arg2
	tbl1.ZIndex = arg1.root.ZIndex
	tbl1.Parent = arg1.root
	local tbl2 = {
		FillDirection = Enum.FillDirection.Horizontal,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 8),
	}

	tbl2.SortOrder = Enum.SortOrder.LayoutOrder
	local var1 = new("Frame", tbl1, { (new("UIListLayout", tbl2)) })
	local tbl3 = {
		Name = "Glyph",
		BackgroundTransparency = 1,
		Size = UDim2.fromOffset(28, 28),
		LayoutOrder = 1,
	}

	tbl3.ZIndex = arg1.root.ZIndex
	tbl3.Parent = var1
	local var2 = new("ImageLabel", tbl3)
	local var3 = arg1.theme
	local var4 = var3.GlyphBackground
	var4 = var4 or Color3.new(1, 1, 1)
	local tbl4 = {
		Name = "Letter",
		BackgroundColor3 = var4,
		TextSize = 17,
		Text = "",
		Visible = false,
		LayoutOrder = 1,
	}

	tbl4.Size = UDim2.fromOffset(28, 28)
	tbl4.FontFace = var3.BoldFont
	var4 = var3.GlyphTextColor
	var4 = var4 or Color3.new(0, 0, 0)
	tbl4.TextColor3 = var4
	tbl4.ZIndex = arg1.root.ZIndex
	tbl4.Parent = var1
	tbl1 = new("TextLabel", tbl4, { (new("UICorner", { CornerRadius = UDim.new(0.5, 0) })) })
	var4 = {
		Name = "Label",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 28),
		TextSize = 17,
		TextWrapped = false,
		Text = "",
		LayoutOrder = 2,
	}

	var4.FontFace = var3.Font
	tbl2 = var3.TextColor
	tbl2 = tbl2 or Color3.new(1, 1, 1)
	var4.TextColor3 = tbl2
	var4.TextXAlignment = Enum.TextXAlignment.Left
	var4.ZIndex = arg1.root.ZIndex
	var4.Parent = var1
	tbl3 = new("TextLabel", var4)
	return { frame = var1, image = var2, letter = tbl1, label = tbl3 }
end

tbl1._render = function(arg1)
	if not arg1.root.Parent then
		return
	end

	local var3 = var1.isGamepad()
	if var3 then
		var3 = false
		if 0 < (#arg1.entries) then
			var3 = arg1.wanted ~= false
		end
	end

	arg1.root.Visible = var3
	if not var3 then
		return
	end

	for k1, v1 in ipairs(arg1.entries) do
		local var5 = arg1.chips[k1]
		if not var5 then
			var5 = arg1:_chip(k1)
			arg1.chips[k1] = var5
		end

		var5.frame.Visible = true
		local var7 = var1.glyphImage(v1.action)
		if var7 then
			var5.image.Image = var7
			var5.image.Visible = true
			var5.letter.Visible = false
		else
			var5.image.Visible = false
			var5.letter.Text = var1.glyphText(v1.action)
			var5.letter.Visible = true
		end

		local var8 = v1.label
		var8 = var8 or var1.label(v1.action)
		var5.label.Text = var8
	end

	for i1 = #arg1.entries + 1, #arg1.chips do
		arg1.chips[i1].frame.Visible = false
	end
end

tbl1.set = function(arg1, arg2)
	local var1 = arg2
	arg1.entries = var1 or {}
	arg1:_render()
end

tbl1.setVisible = function(arg1, arg2)
	arg1.wanted = arg2 ~= false
	arg1:_render()
end

tbl1.describe = function(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1.entries) do
		local var2 = v1.label
		table.insert(tbl1, v1.action .. ":" .. (var2 or var1.label(v1.action)))
	end

	return { visible = arg1.root.Visible, entries = tbl1 }
end

tbl1.destroy = function(arg1)
	if arg1.connection then
		arg1.connection:Disconnect()
		arg1.connection = nil
	end

	arg1.root:Destroy()
end

return tbl1

--- ReplicatedStorage.MeltShared.Controls [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("UserInputService")
local tbl1 = {
	Mode = { KeyboardMouse = "KeyboardMouse", Touch = "Touch", Gamepad = "Gamepad" },
	Bindings = {
		Confirm = {
			Gamepad = Enum.KeyCode.ButtonA,
			Keyboard = Enum.KeyCode.Return,
			Label = "Select",
			Text = "A",
		},
		Back = {
			Gamepad = Enum.KeyCode.ButtonB,
			Keyboard = Enum.KeyCode.Escape,
			Label = "Back",
			Text = "B",
		},
		Interact = {
			Gamepad = Enum.KeyCode.ButtonX,
			Keyboard = Enum.KeyCode.E,
			Label = "Interact",
			Text = "X",
		},
		OpenMenu = { Gamepad = Enum.KeyCode.ButtonY, Keyboard = nil, Label = "Menu", Text = "Y" },
		UseTool = { Gamepad = Enum.KeyCode.ButtonR2, Keyboard = nil, Label = "Use", Text = "RT" },
		PreviousTool = { Gamepad = Enum.KeyCode.ButtonL1, Keyboard = nil, Label = "Prev", Text = "LB" },
		NextTool = { Gamepad = Enum.KeyCode.ButtonR1, Keyboard = nil, Label = "Next", Text = "RB" },
		Adjust = {
			Gamepad = Enum.KeyCode.DPadLeft,
			Keyboard = Enum.KeyCode.Left,
			Label = "Adjust",
			Text = "D-Pad",
		},
	},
	Order = {
		"Confirm",
		"Adjust",
		"Back",
		"Interact",
		"OpenMenu",
		"PreviousTool",
		"NextTool",
		"UseTool",
	},
}

tbl1.binding = function(arg1)
	return tbl1.Bindings[arg1]
end

tbl1.key = function(arg1)
	local var1 = tbl1.Bindings[arg1]
	local var2 = var1
	return var2 and var1.Gamepad
end

tbl1.label = function(arg1)
	local var2 = tbl1.Bindings[arg1]
	if var2 then
		return var2.Label
	end

	return arg1
end

tbl1.actionOf = function(arg1)
	for k1, v1 in pairs(tbl1.Bindings) do
		if v1.Gamepad ~= arg1 then
			continue
		end

		return k1
	end

	return nil
end

local var3 = Instance.new("BindableEvent")
tbl1.changed = var3.Event
local var4 = tbl1.Mode.KeyboardMouse
local tbl2 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true,
}

local num1 = 0
local tbl3 = {
	[Enum.UserInputType.MouseButton1] = true,
	[Enum.UserInputType.MouseButton2] = true,
	[Enum.UserInputType.MouseButton3] = true,
	[Enum.UserInputType.MouseWheel] = true,
	[Enum.UserInputType.Keyboard] = true,
}

local bool1 = false
local function consider(arg1)
	if tbl2[arg1] then
		num1 = os.clock()
		local var2 = tbl1.Mode.Gamepad
		if var2 == var4 then
			return
		end

		var4 = var2
		var3:Fire(var4)
		return
	end

	if arg1 == Enum.UserInputType.Touch then
		local var7 = tbl1.Mode.Touch
		if var7 == var4 then
			return
		end

		var4 = var7
		var3:Fire(var4)
		return
	end

	if tbl3[arg1] then
		local var10 = tbl1.Mode.KeyboardMouse
		if var10 == var4 then
			return
		end

		var4 = var10
		var3:Fire(var4)
		return
	end

	if arg1 == Enum.UserInputType.MouseMovement then
		if 0.6 <= os.clock() - num1 then
			local var14 = tbl1.Mode.KeyboardMouse
			if var14 == var4 then
				return
			end

			var4 = var14
			var3:Fire(var4)
		end
	end
end

local function start()
	if bool1 or (not var1:IsClient()) then
		return
	end

	bool1 = true
	if var2.TouchEnabled and (not var2.KeyboardEnabled) then
		var4 = tbl1.Mode.Touch
	end

	consider(var2:GetLastInputType())
	var2.LastInputTypeChanged:Connect(consider)
	var2.GamepadDisconnected:Connect(function()
		if var4 == tbl1.Mode.Gamepad and #var2:GetConnectedGamepads() == 0 then
			num1 = 0
			local var5 = if var2.TouchEnabled and (not var2.KeyboardEnabled) then tbl1.Mode.Touch else tbl1.Mode.KeyboardMouse
			if var5 == var4 then
				return
			end

			var4 = var5
			var3:Fire(var4)
		end
	end)
end

tbl1.mode = function()
	start()
	return var4
end

tbl1._feed = function(arg1)
	assert(var1:IsStudio(), "Controls._feed is a Studio testing seam")
	start()
	consider(arg1)
	return var4
end

tbl1._sinceGamepad = function()
	assert(var1:IsStudio(), "Controls._sinceGamepad is a Studio testing seam")
	return os.clock() - num1
end

tbl1.isGamepad = function()
	return tbl1.mode() == tbl1.Mode.Gamepad
end

tbl1.isTouch = function()
	return tbl1.mode() == tbl1.Mode.Touch
end

tbl1.gamepadConnected = function()
	return 0 < (#var2:GetConnectedGamepads())
end

tbl1.glyphImage = function(arg1)
	local var3 = tbl1.key(arg1)
	if not var3 then
		return nil
	end

	local success, result = pcall(function()
		local var1 = var3
		return var2:GetImageForKeyCode(var1)
	end)

	if success and (typeof(result) == "string" and result ~= "") then
		return result
	end

	return nil
end

tbl1.imageForKey = function(arg1)
	if not arg1 then
		return nil
	end

	local success, result = pcall(function()
		local var1 = arg1
		return var2:GetImageForKeyCode(var1)
	end)

	if success and (typeof(result) == "string" and result ~= "") then
		return result
	end

	return nil
end

tbl1.glyphText = function(arg1)
	local var2 = tbl1.Bindings[arg1]
	if var2 then
		return var2.Text
	end

	return "?"
end

return tbl1

--- ReplicatedStorage.MeltShared.UiFocus [ModuleScript]
-- y u r i

local function isVisible(arg1)
	local var1 = arg1
	while not var1 and (not var1:IsA("GuiObject")) and (not var1.Visible) do
	end

	if var1 and var1:IsA("LayerCollector") then
		return var1.Enabled
	end

	return var1 ~= nil
end

local var1 = game:GetService("ContextActionService")
local var2 = game:GetService("GuiService")
local var3 = game:GetService("Players")
local var4 = game:GetService("RunService")
local var5 = game:GetService("UserInputService")
local var6 = require(script.Parent.Controls)
local var7 = Instance.new("BindableEvent")
local function selectable(arg1)
	if not arg1 or (not arg1:IsA("GuiObject")) then
		return false
	end

	if not arg1.Parent or (not arg1:IsDescendantOf(game)) then
		return false
	end

	if not arg1.Selectable then
		return false
	end

	if arg1.AbsoluteSize.X <= 0 or arg1.AbsoluteSize.Y <= 0 then
		return false
	end

	return (isVisible(arg1))
end

local function scrollingAncestor(arg1)
	local var1 = arg1
	var1 = var1 and arg1.Parent
	while not var1 and var1:IsA("LayerCollector") and var1:IsA("ScrollingFrame") do
	end

	return nil
end

local function scrollIntoView(arg1)
	local var2 = scrollingAncestor(arg1)
	if not var2 or (not arg1 or (not arg1:IsA("GuiObject"))) then
		return
	end

	local var3 = var2.AbsoluteWindowSize
	if var3.X <= 0 or var3.Y <= 0 then
		return
	end

	local var4 = arg1.AbsolutePosition - var2.AbsolutePosition + var2.CanvasPosition
	local var5 = arg1.AbsoluteSize
	local var6 = var2.CanvasPosition
	local var8 = var4.Y - 12
	local var9 = var4.Y + var5.Y + 12
	if var8 < var6.Y then
		var6 = Vector2.new(var6.X, var8)
	else
		if var6.Y + var3.Y < var9 then
			var6 = Vector2.new(var6.X, var9 - var3.Y)
		end
	end

	local var11 = var4.X - 12
	local var12 = var4.X + var5.X + 12
	if var11 < var6.X then
		var6 = Vector2.new(var11, var6.Y)
	else
		if var6.X + var3.X < var12 then
			var6 = Vector2.new(var12 - var3.X, var6.Y)
		end
	end

	if var6 ~= var2.CanvasPosition then
		var2.CanvasPosition = var6
	end
end

local function tidyScrolls(arg1)
	if not arg1 then
		return
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("ScrollingFrame") then
			continue
		end

		if not v1.Selectable then
			continue
		end

		for k2, v2 in ipairs(v1:GetDescendants()) do
			if not v2:IsA("GuiObject") then
				continue
			end

			if not v2.Selectable then
				continue
			end

			v1.Selectable = false
			break
		end
	end
end

local bool1 = false
local tbl1 = {}
local num1 = 0
local bool2 = false
local function clearSelection()
	local var3 = var2.SelectedObject
	if not var3 then
		return
	end

	for k1, v1 in ipairs(tbl1) do
		local bool3 = false
		if var3 ~= nil then
			bool3 = false
			if v1.root ~= nil then
				bool3 = true
				bool3 = var3 == v1.root or var3:IsDescendantOf(v1.root)
			end
		end

		if not bool3 then
			continue
		end

		bool2 = true
		var2.SelectedObject = nil
		bool2 = false
		return
	end

	if #tbl1 == 0 then
		bool2 = true
		var2.SelectedObject = nil
		bool2 = false
	end
end

local function apply()
	local var3 = tbl1[#tbl1]
	if not var3 then
		clearSelection()
		return
	end

	if not var6.isGamepad() then
		clearSelection()
		return
	end

	local var4
	if var3.settled and selectable(var3.last) then
		var4 = var3.last
	else
		local success, result = pcall(var3.initial)
		if var3.initial and (success and selectable(result)) then
			var4 = result
		else
			var4 = if selectable(var3.last) then var3.last else nil
		end
	end

	if not var4 then
		if var3.retries == nil or var3.retries < 12 then
			local var7 = (var3.retries or 0) + 1
			var3.retries = var7
			task.defer(function()
				if tbl1[#tbl1] == var3 then
					apply()
				end
			end)

			return
		end

		clearSelection()
		return
	end

	var3.retries = nil
	if var2.SelectedObject ~= var4 then
		bool2 = true
		var2.SelectedObject = var4
		bool2 = false
	end

	var3.last = var4
	var3.settled = true
	scrollIntoView(var4)
end

local var8 = nil
local function handleBack(_, arg2)
	if arg2 ~= Enum.UserInputState.Begin then
		return Enum.ContextActionResult.Pass
	end

	local var2 = tbl1[#tbl1]
	if not var2 then
		return Enum.ContextActionResult.Pass
	end

	if var2.back then
		task.spawn(var2.back)
	end

	return Enum.ContextActionResult.Sink
end

local num2 = 0
local bool3 = false
local tbl2 = {}
tbl2.__index = tbl2
tbl2.select = function(arg1, arg2)
	if selectable(arg2) then
		arg1.last = arg2
		if tbl1[#tbl1] == arg1 then
			apply()
		end
	end
end

tbl2.reland = function(arg1)
	arg1.last = nil
	arg1.settled = false
	arg1.retries = nil
	if tbl1[#tbl1] == arg1 then
		tidyScrolls(arg1.root)
		apply()
	end
end

tbl2.refocus = function(arg1)
	if tbl1[#tbl1] == arg1 then
		tidyScrolls(arg1.root)
		if not selectable(arg1.last) then
			arg1.last = nil
		end

		apply()
	end
end

tbl2.isTop = function(arg1)
	return tbl1[#tbl1] == arg1
end

tbl2.setHints = function(arg1, arg2)
	arg1.hints = arg2
	if tbl1[#tbl1] == arg1 then
		var7:Fire(arg1)
	end
end

local tbl3 = {
	selectable = selectable,
	scrollIntoView = scrollIntoView,
	tidyScrolls = tidyScrolls,
	apply = apply,
	guardInput = function(arg1)
		num2 = os.clock() + (arg1 or 0.35)
	end,
	blocked = function()
		if not var6.isGamepad() then
			return false
		end

		local var2 = bool3
		if not var2 then
			var2 = os.clock() < num2
		end

		return var2
	end,
}

tbl2.close = function(arg1)
	tbl3.close(arg1.name)
end

tbl3.isOpen = function(arg1)
	for k1, v1 in ipairs(tbl1) do
		if v1.name ~= arg1 then
			continue
		end

		return true
	end

	return false
end

tbl3.top = function()
	return tbl1[#tbl1]
end

tbl3.reland = function(arg1)
	local var2 = tbl1[#tbl1]
	if var2 and var2.name == arg1 then
		var2:reland()
	end
end

tbl3.open = function(arg1, arg2)
	local var4 = nil
	for k1, v1 in ipairs(tbl1) do
		if v1.name ~= arg1 then
			continue
		end

		local var5 = tbl1
		table.remove(var5, k1)
		var4 = v1
		break
	end

	local var10 = var4
	if not var10 then
		var10 = setmetatable({ name = arg1 }, tbl2)
	end

	local var11 = arg2.root
	var11 = var11 or var10.root
	var10.root = var11
	var11 = arg2.initial
	var11 = var11 or var10.initial
	var10.initial = var11
	var11 = arg2.back
	var11 = var11 or var10.back
	var10.back = var11
	var10.lockControls = arg2.lockControls == true
	var11 = arg2.hints
	var11 = var11 or var10.hints
	var10.hints = var11
	var11 = arg2.onFocus
	var11 = var11 or var10.onFocus
	var10.onFocus = var11
	var10.last = nil
	var10.retries = nil
	var10.settled = false
	tidyScrolls(var10.root)
	if var10.root and var10.root:IsA("GuiObject") then
		var10.root.SelectionGroup = true
		var10.root.SelectionBehaviorUp = Enum.SelectionBehavior.Stop
		var10.root.SelectionBehaviorDown = Enum.SelectionBehavior.Stop
		var10.root.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
		var10.root.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
	end

	table.insert(tbl1, var10)
	local var12
	if #tbl1 == 1 then
		local str2 = "Back"
		var12 = Enum.ContextActionPriority.High.Value
		var1:BindActionAtPriority("MeltUiBack", handleBack, false, var12, var6.key(str2))
	end

	if not var8 then
		var8 = task.spawn(function()
			while 0 < (#tbl1) do
				task.wait(0.25)
				if #tbl1 == 0 then
					break
				end

				local var1 = tbl1[#tbl1]
				if not var6.isGamepad() or (not var1) then
					continue
				end

				local var3 = var2.SelectedObject
				if selectable(var3) then
					local bool3 = false
					if var3 ~= nil then
						bool3 = false
						if var1.root ~= nil then
							bool3 = true
							if var3 ~= var1.root then
								bool3 = var3:IsDescendantOf(var1.root)
							end
						end
					end

					if bool3 then
						continue
					end
				end

				if not selectable(var1.last) then
					var1.last = nil
				end

				apply()
			end

			var8 = nil
		end)

	end

	var11 = 0
	for k2, v2 in ipairs(tbl1) do
		if not v2.lockControls then
			continue
		end

		var11 = var11 + 1
	end

	num1 = var11
	local bool3 = false
	if 0 < num1 then
		bool3 = var6.isGamepad()
	end

	if bool1 ~= bool3 then
		bool1 = bool3
		pcall(function()
			local var1 = var3.LocalPlayer:FindFirstChild("PlayerScripts")
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("PlayerModule")
			local var4 = var2
			var4 = var4 and require(var2):GetControls()
			if var4 then
				if bool3 then
					var4:Disable()
					return
				end

				var4:Enable()
			end
		end)

	end

	if arg2.guard ~= false then
		tbl3.guardInput()
	end

	apply()
	var7:Fire(var10)
	return var10
end

local bool4 = false
tbl3.close = function(arg1)
	local bool3 = false
	for i1 = #tbl1, 1, -1 do
		if tbl1[i1].name ~= arg1 then
			continue
		end

		local var4 = i1
		table.remove(tbl1, var4)
		bool3 = true
		break
	end

	if not bool3 then
		return
	end

	bool4 = true
	bool2 = true
	if var2.SelectedObject and (not selectable(var2.SelectedObject)) then
		var2.SelectedObject = nil
	end

	bool2 = false
	bool4 = false
	if #tbl1 == 0 then
		var1:UnbindAction("MeltUiBack")
		clearSelection()
	end

	local num2 = 0
	for k1, v1 in ipairs(tbl1) do
		if not v1.lockControls then
			continue
		end

		num2 = num2 + 1
	end

	num1 = num2
	local bool6 = false
	if 0 < num1 then
		bool6 = var6.isGamepad()
	end

	if bool1 ~= bool6 then
		bool1 = bool6
		pcall(function()
			local var1 = var3.LocalPlayer:FindFirstChild("PlayerScripts")
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("PlayerModule")
			local var4 = var2
			var4 = var4 and require(var2):GetControls()
			if var4 then
				if bool6 then
					var4:Disable()
					return
				end

				var4:Enable()
			end
		end)

	end

	if 0 < (#tbl1) then
		tbl3.guardInput()
	end

	apply()
	var7:Fire(tbl1[#tbl1])
end

tbl3.closeAll = function()
	while 0 < (#tbl1) do
		table.remove(tbl1)
	end

	var1:UnbindAction("MeltUiBack")
	clearSelection()
	local num2 = 0
	for k1, v1 in ipairs(tbl1) do
		if not v1.lockControls then
			continue
		end

		num2 = num2 + 1
	end

	num1 = num2
	local bool3 = false
	if 0 < num1 then
		bool3 = var6.isGamepad()
	end

	if bool1 ~= bool3 then
		bool1 = bool3
		pcall(function()
			local var1 = var3.LocalPlayer:FindFirstChild("PlayerScripts")
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("PlayerModule")
			local var4 = var2
			var4 = var4 and require(var2):GetControls()
			if var4 then
				if bool3 then
					var4:Disable()
					return
				end

				var4:Enable()
			end
		end)

	end

	var7:Fire(nil)
end

tbl3.topChanged = var7.Event
tbl3.hints = function()
	local var1 = tbl1[#tbl1]
	local var2 = var1
	return var2 and var1.hints
end

local bool5 = false
tbl3.init = function()
	if bool5 or (not var4:IsClient()) then
		return
	end

	bool5 = true
	pcall(function()
		var2.AutoSelectGuiEnabled = false
	end)

	var2:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		if bool2 or bool4 then
			return
		end

		local var3 = tbl1[#tbl1]
		local var4 = var2.SelectedObject
		if not var3 then
			return
		end

		if var4 == nil then
			if var6.isGamepad() then
				apply()
			end

			return
		end

		local bool3 = false
		if var4 ~= nil then
			bool3 = false
			if var3.root ~= nil then
				bool3 = true
				bool3 = var4 == var3.root or var4:IsDescendantOf(var3.root)
			end
		end

		if bool3 then
			if not var3.settled then
				apply()
				return
			end

			var3.last = var4
			scrollIntoView(var4)
			if not var3.onFocus then
				return
			end

			task.spawn(var3.onFocus, var4)
			return
		end

		apply()
	end)

	var6.changed:Connect(function()
		local num2 = 0
		for k1, v1 in ipairs(tbl1) do
			if not v1.lockControls then
				continue
			end

			num2 = num2 + 1
		end

		num1 = num2
		local bool3 = false
		if 0 < num1 then
			bool3 = var6.isGamepad()
		end

		if bool1 ~= bool3 then
			bool1 = bool3
			pcall(function()
				local var1 = var3.LocalPlayer:FindFirstChild("PlayerScripts")
				local var2 = var1
				var2 = var2 and var1:FindFirstChild("PlayerModule")
				local var4 = var2
				var4 = var4 and require(var2):GetControls()
				if var4 then
					if bool3 then
						var4:Disable()
						return
					end

					var4:Enable()
				end
			end)

		end

		apply()
	end)

	var5.GamepadConnected:Connect(function()
		if 0 < (#tbl1) and var6.isGamepad() then
			apply()
		end
	end)

	var5.GamepadDisconnected:Connect(function()
		apply()
	end)

	local var1 = var6.key("Confirm")
	local tbl2 = { [var1] = true }
	tbl2[Enum.KeyCode.Return] = true
	var5.InputBegan:Connect(function(arg1)
		if tbl2[arg1.KeyCode] then
			bool3 = true
		end
	end)

	var5.InputEnded:Connect(function(arg1)
		if tbl2[arg1.KeyCode] then
			bool3 = false
		end
	end)
end

tbl3.describe = function()
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1) do
		table.insert(tbl2, v1.name)
	end

	local var1 = tbl1[#tbl1]
	local var3 = var1
	local var4 = var2.SelectedObject
	local tbl4 = { stack = tbl2, top = var3 and var1.name }
	var3 = var4
	var3 = var3 and var4:GetFullName()
	tbl4.selected = var3
	var3 = var4
	tbl4.selectedName = var3 and var4.Name
	if var1 then
		if var4 then
			var3 = false
			if var4 ~= nil then
				var3 = false
				if var1.root ~= nil then
					var3 = true
					if var4 ~= var1.root then
						var3 = var4:IsDescendantOf(var1.root)
					end
				end
			end
		else
			var3 = nil
		end
	else
		var3 = nil
	end

	tbl4.contained = var3
	tbl4.mode = var6.mode()
	tbl4.controlsLocked = bool1
	tbl4.blocked = tbl3.blocked()
	return tbl4
end

return tbl3

--- ReplicatedStorage.MeltShared.Skins [ModuleScript]
-- y u r i

local tbl1 = { Id = "Flamethrower", Name = "Flamethrower", Order = 4, Short = "Flamer" }
local tbl2 = {
	CosmeticNotice = "Skins are cosmetic only.",
	OwnedNotRunNotice = "Skin owned. Tool unlocked separately during a run.",
	AppearsWhenUnlocked = "This skin will appear when you unlock this tool.",
	DuplicateNotice = "Duplicates are possible and are kept in your inventory.",
	LuckScope = "2x Luck doubles your Legendary or better chances in every box.",
	Weapons = {
		{ Id = "Hairdryer", Name = "Hairdryer", Order = 1, Short = "Hairdryer" },
		{ Id = "HeatGun", Name = "Heat Gun", Order = 2, Short = "Heat Gun" },
		{ Id = "SteamBlaster", Name = "Steam Blaster", Order = 3, Short = "Steam" },
		tbl1,
	},
	WeaponById = {},
}

local var1 = Color3.fromHex
for k1, v1 in ipairs(tbl2.Weapons) do
	tbl2.WeaponById[v1.Id] = v1
end

local tbl3 = { Name = "Common", Rank = 1, Color = var1("#7C8FA0") }
local tbl4 = { Name = "Uncommon", Rank = 2, Color = var1("#3FA65A") }
local tbl5 = { Name = "Rare", Rank = 3, Color = var1("#3C82D6") }
local tbl6 = { Name = "Epic", Rank = 4, Color = var1("#A447C9") }
local tbl7 = { Name = "Legendary", Rank = 5, Color = var1("#F0861C") }
local tbl8 = { Name = "Mythic", Rank = 6, Color = var1("#DE3F52") }
local tbl9 = {
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	{ Name = "Ascendant", Rank = 7, Color = var1("#7F56C2") },
}

tbl2.Rarities = tbl9
tbl2.RarityByName = {}
for k2, v2 in ipairs(tbl2.Rarities) do
	v2.Accent = v2.Color:Lerp(Color3.new(1, 1, 1), 0.82)
	tbl2.RarityByName[v2.Name] = v2
end

local tbl10 = {
	Key = "inferno",
	Name = "Inferno",
	Rarity = "Ascendant",
	Line = "Obsidian with molten seams and contained flames.",
	Element = "Fire",
}

tbl2.Themes = {
	{
		Key = "cherry",
		Name = "Cherry",
		Rarity = "Common",
		Line = "Rich red housing with cream accents.",
	},
	{
		Key = "arctic",
		Name = "Arctic",
		Rarity = "Common",
		Line = "Pale icy blue with white trim.",
	},
	{
		Key = "lemon",
		Name = "Lemon",
		Rarity = "Common",
		Line = "Warm yellow with charcoal trim.",
	},
	{
		Key = "cheetah",
		Name = "Cheetah",
		Rarity = "Uncommon",
		Line = "Warm tan with dark cheetah spots.",
	},
	{
		Key = "checker",
		Name = "Checker",
		Rarity = "Uncommon",
		Line = "Black and cream checks, a touch of teal.",
	},
	{
		Key = "candystripe",
		Name = "Candy Stripe",
		Rarity = "Uncommon",
		Line = "Coral and cream diagonal stripes.",
	},
	{
		Key = "glaciervein",
		Name = "Glacier Vein",
		Rarity = "Rare",
		Line = "Deep blue with pale branching ice veins.",
	},
	{
		Key = "koi",
		Name = "Koi",
		Rarity = "Rare",
		Line = "Cream, vermilion and charcoal with wave motifs.",
	},
	{
		Key = "circuit",
		Name = "Circuit",
		Rarity = "Rare",
		Line = "Dark navy with cyan circuit lines.",
	},
	{
		Key = "aurora",
		Name = "Aurora",
		Rarity = "Epic",
		Line = "Teal-violet finish with teal and violet light strips.",
	},
	{
		Key = "emberline",
		Name = "Emberline",
		Rarity = "Epic",
		Line = "Charcoal and copper with glowing orange seams.",
	},
	{
		Key = "bubblegum",
		Name = "Bubblegum",
		Rarity = "Epic",
		Line = "Pink and cyan with a soft playful click.",
	},
	{
		Key = "brassworks",
		Name = "Brassworks",
		Rarity = "Legendary",
		Line = "Brass trim, rivets and a redesigned vent cover.",
	},
	{
		Key = "crystalbound",
		Name = "Crystalbound",
		Rarity = "Legendary",
		Line = "Crystal inlays, a faceted shroud and shards circling the muzzle.",
	},
	{
		Key = "retrorocket",
		Name = "Retro Rocket",
		Rarity = "Legendary",
		Line = "Rounded retro styling, red fins and a burning rocket tail.",
	},
	{
		Key = "dragonforge",
		Name = "Dragonforge",
		Rarity = "Mythic",
		Line = "A copper and obsidian dragon head that smokes and spits embers.",
	},
	{
		Key = "celestial",
		Name = "Celestial",
		Rarity = "Mythic",
		Line = "Pearl and midnight blue with stars and a ring.",
	},
	{
		Key = "deepcurrent",
		Name = "Deep Current",
		Rarity = "Mythic",
		Line = "A deep-sea instrument of brass and teal glass.",
	},
	{
		Key = "earthwarden",
		Name = "Earthwarden",
		Rarity = "Ascendant",
		Line = "Stone and bronze with orbiting rock fragments.",
		Element = "Earth",
	},
	tbl10,
	{
		Key = "skyweaver",
		Name = "Skyweaver",
		Rarity = "Ascendant",
		Line = "Swept white casing with floating fins and ribbons.",
		Element = "Wind",
	},
	{
		Key = "tidecaller",
		Name = "Tidecaller",
		Rarity = "Ascendant",
		Line = "Turquoise and pearl with circulating water.",
		Element = "Water",
	},
	{
		Key = "darkmatter",
		Name = "Dark Matter",
		Rarity = "Ascendant",
		Line = "Precision machinery holding a contained miniature black hole.",
		Limited = "Limited Time Bundle 1",
	},
}

tbl2.ThemeByKey = {}
for k3, v3 in ipairs(tbl2.Themes) do
	tbl2.ThemeByKey[v3.Key] = v3
end

tbl2.PreviewDefaults = {
	Hairdryer = { Yaw = 240, Pitch = 12, Zoom = 1 },
	HeatGun = { Yaw = 236, Pitch = 12, Zoom = 1 },
	SteamBlaster = { Yaw = 240, Pitch = 14, Zoom = 1 },
	Flamethrower = { Yaw = 248, Pitch = 10, Zoom = 1.02 },
	FireGrenade = { Yaw = 215, Pitch = 18, Zoom = 1.05 },
}

tbl2.List = {}
tbl2.ById = {}
tbl2.Legacy = {}
tbl2.ShowcaseWeapon = "HeatGun"
tbl9 = function(arg1, arg2, arg3)
	local var1 = tbl2.ThemeByKey[arg2]
	assert(var1, "Skins: bad entry " .. arg1)
	assert(not tbl2.ById[arg1], "Skins: duplicate id " .. arg1)
	local tbl1 = {
		Id = arg1,
		Theme = arg2,
		Collection = arg3,
		Name = var1.Name,
		FullName = var1.Name,
		Rarity = var1.Rarity,
		Rank = tbl2.RarityByName[var1.Rarity].Rank,
		Line = var1.Line,
		Element = var1.Element,
		Limited = var1.Limited,
		Asset = "SkinArt/" .. arg2,
		Order = #tbl2.List + 1,
	}

	table.insert(tbl2.List, tbl1)
	tbl2.ById[arg1] = tbl1
	if arg3 == "crate1" then
		for k1, v1 in ipairs(tbl2.Weapons) do
			tbl2.Legacy[string.lower(v1.Id) .. "_" .. arg2] = arg1
		end
	end
end

tbl9("cherry", "cherry", "crate1")
tbl9("arctic", "arctic", "crate1")
tbl9("lemon", "lemon", "crate1")
tbl9("cheetah", "cheetah", "crate1")
tbl9("checker", "checker", "crate1")
tbl9("candystripe", "candystripe", "crate1")
tbl9("glaciervein", "glaciervein", "crate1")
tbl9("koi", "koi", "crate1")
tbl9("circuit", "circuit", "crate1")
tbl9("aurora", "aurora", "crate1")
tbl9("emberline", "emberline", "crate1")
tbl9("bubblegum", "bubblegum", "crate1")
tbl9("brassworks", "brassworks", "crate1")
tbl9("crystalbound", "crystalbound", "crate1")
tbl9("retrorocket", "retrorocket", "crate1")
tbl9("dragonforge", "dragonforge", "crate1")
tbl9("celestial", "celestial", "crate1")
tbl9("deepcurrent", "deepcurrent", "crate1")
tbl9("earthwarden", "earthwarden", "crate1")
tbl9("inferno", "inferno", "crate1")
tbl9("skyweaver", "skyweaver", "crate1")
tbl9("tidecaller", "tidecaller", "crate1")
tbl9("darkmatter", "darkmatter", "limited1")
tbl2.DefaultId = "default"
tbl2.AllWeapons = "All"
tbl2.GrenadeId = "FireGrenade"
tbl2.GrenadeSkins = { darkmatter = true }
tbl2.grenadeSkin = function(arg1)
	if not arg1 then
		return nil
	end

	for k1, v1 in ipairs(tbl2.Weapons) do
		local var1 = arg1[v1.Id]
		if not var1 then
			continue
		end

		if not tbl2.GrenadeSkins[var1] then
			continue
		end

		return var1
	end

	return nil
end

tbl2.isLimited = function(arg1)
	local var2 = typeof(arg1) == "string" and tbl2.ById[arg1] or nil
	local bool1 = false
	if var2 ~= nil then
		bool1 = var2.Limited ~= nil
	end

	return bool1
end

tbl2.isSkin = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.ById[arg1] ~= nil
	end

	return bool1
end

tbl2.canonical = function(arg1)
	if typeof(arg1) == "string" and (tbl2.ById[arg1] == nil and tbl2.Legacy[arg1]) then
		return tbl2.Legacy[arg1]
	end

	return arg1
end

tbl2.isWeapon = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.WeaponById[arg1] ~= nil
	end

	return bool1
end

tbl2.forWeapon = function(_)
	local var1 = tbl2.List
	return table.clone(var1)
end

tbl2.previewFor = function(arg1)
	local var1 = arg1
	local var2 = tbl2.PreviewDefaults[var1 or tbl2.ShowcaseWeapon]
	var2 = var2 or tbl2.PreviewDefaults[tbl2.ShowcaseWeapon]
	return table.clone(var2)
end

tbl2.wornBy = function(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.Weapons) do
		if not arg1 then
			continue
		end

		if arg1[v1.Id] ~= arg2 then
			continue
		end

		table.insert(tbl1, v1.Id)
	end

	return tbl1
end

tbl2.TotalWeight = 10000
tbl2.Crates = {
	crate1 = {
		Id = "crate1",
		Name = "Mystery Box 1",
		Cost = 100,
		Collection = "crate1",
		Weights = {
			Common = 4990,
			Uncommon = 2500,
			Rare = 1500,
			Epic = 600,
			Legendary = 300,
			Mythic = 100,
			Ascendant = 10,
		},
	},
	crate2 = {
		Id = "crate2",
		Name = "Mystery Box 2",
		Cost = 250,
		Collection = "crate1",
		Weights = {
			Common = 4222,
			Uncommon = 2349,
			Rare = 1409,
			Epic = 1200,
			Legendary = 600,
			Mythic = 200,
			Ascendant = 20,
		},
	},
	mythic = {
		Id = "mythic",
		Name = "Mythic Drop",
		Product = "MythicBox",
		Collection = "crate1",
		Weights = { Epic = 6440, Legendary = 2440, Mythic = 1000, Ascendant = 120 },
		LuckDonors = { { Tier = "Epic", Share = 100 } },
	},
	mythic10 = {
		Id = "mythic10",
		Name = "Mythic Drop 10x Luck",
		Product = "MythicBox10",
		Collection = "crate1",
		Weights = { Legendary = 5000, Mythic = 4000, Ascendant = 1000 },
		NoLuck = true,
		DailyWith = "mythic",
	},
}

tbl2.DefaultCrate = "crate1"
tbl2.MythicCrate = "mythic"
tbl2.MythicLuckCrate = "mythic10"
tbl2.CrateOrder = { "crate1", "crate2", "mythic" }
tbl2.isCrate = function(arg1)
	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl2.Crates[arg1] ~= nil
	end

	return bool1
end

tbl2.isGemCrate = function(arg1)
	local var2 = tbl2.isCrate(arg1)
	if var2 then
		var2 = false
		if typeof(tbl2.Crates[arg1].Cost) == "number" then
			var2 = 0 < tbl2.Crates[arg1].Cost
		end
	end

	return var2
end

tbl2.OpenCounts = { 1, 3 }
tbl2.isOpenCount = function(arg1)
	local bool1 = false
	if typeof(arg1) == "number" then
		bool1 = table.find(tbl2.OpenCounts, arg1) ~= nil
	end

	return bool1
end

tbl2.openCost = function(arg1, arg2)
	local var1 = tbl2.Crates[arg1]
	return (var1 and var1.Cost or 0) * arg2
end

tbl2.luckApplies = function(arg1)
	local var2 = tbl2.Crates[arg1]
	local bool1 = false
	if var2 ~= nil then
		bool1 = var2.NoLuck ~= true
	end

	return bool1
end

tbl2.BoxResetHourUtc = 1
tbl2.boxDay = function(arg1)
	return (math.floor((arg1 - tbl2.BoxResetHourUtc * 3600) / 86400))
end

tbl2.nextBoxAt = function(arg1)
	return (tbl2.boxDay(arg1) + 1) * 86400 + tbl2.BoxResetHourUtc * 3600
end

tbl2.pool = function(arg1)
	local var1 = arg1
	local var2 = tbl2.Crates[arg1]
	assert(var2, "Skins: unknown crate " .. tostring(var1))
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.Rarities) do
		tbl1[v1.Name] = {}
	end

	for k2, v2 in ipairs(tbl2.List) do
		if v2.Collection ~= var2.Collection then
			continue
		end

		table.insert(tbl1[v2.Rarity], v2)
	end

	return tbl1
end

tbl2.LuckMultiplier = 2
tbl2.LuckTiers = { Legendary = true, Mythic = true, Ascendant = true }
tbl2.LuckDonors = {
	{ Tier = "Common", Share = 76 },
	{ Tier = "Uncommon", Share = 15 },
	{ Tier = "Rare", Share = 9 },
}

tbl3 = function(arg1, arg2)
	local num1 = 0
	for k1, v1 in ipairs(arg2) do
		num1 = num1 + v1.share
	end

	assert(0 < num1, "Skins: allocate with no share to divide")
	local tbl1 = {}
	local num2 = 0
	local tbl2 = {}
	for k2, v2 in ipairs(arg2) do
		local var1 = arg1 * v2.share / num1
		local var2 = math.floor(var1)
		tbl1[v2.key] = var2
		table.insert(tbl2, { key = v2.key, frac = var1 - var2 })
		num2 = num2 + var2
	end

	table.sort(tbl2, function(arg1, arg2)
		if arg1.frac == arg2.frac then
			return arg1.key < arg2.key
		end

		return arg2.frac < arg1.frac
	end)

	local num3 = 1
	while num2 < arg1 do
		local var3 = tbl2[num3].key
		local var4 = tbl1[var3] + 1
		tbl1[var3] = var4
		num2 = num2 + 1
		num3 = if #tbl2 <= num3 then 1 else num3 + 1
	end

	return tbl1
end

tbl4 = {}
local function computeLuckWeights(arg1)
	local tbl1 = {}
	local num1 = 0
	for k1, v1 in ipairs(tbl2.Rarities) do
		local var1 = arg1.Weights[v1.Name] or 0
		tbl1[v1.Name] = var1
		if not tbl2.LuckTiers[v1.Name] then
			continue
		end

		tbl1[v1.Name] = var1 * tbl2.LuckMultiplier
		num1 = num1 + var1 * (tbl2.LuckMultiplier - 1)
	end

	local var2 = arg1.LuckDonors
	local tbl4 = {}
	for k2, v2 in ipairs(var2 or tbl2.LuckDonors) do
		if 0 >= (arg1.Weights[v2.Tier] or 0) then
			continue
		end

		table.insert(tbl4, { key = v2.Tier, share = v2.Share })
	end

	local var3 = num1
	local var4 = tbl3(var3, tbl4)
	for k3, v3 in pairs(var4) do
		local var5 = tbl1[k3] - v3
		tbl1[k3] = var5
		assert(1 <= tbl1[k3], "Skins: 2x Luck would leave " .. k3 .. " unrollable in " .. arg1.Id)
	end

	local num2 = 0
	for k4, v4 in pairs(tbl1) do
		num2 = num2 + v4
	end

	assert(num2 == tbl2.TotalWeight, "Skins: 2x Luck weights for " .. arg1.Id .. " total " .. num2)
	return tbl1
end

tbl2.weights = function(arg1, arg2)
	local var1 = tbl2.Crates[arg1]
	assert(var1, "Skins: unknown crate " .. tostring(arg1))
	if not arg2 or var1.NoLuck then
		return var1.Weights
	end

	if not tbl4[arg1] then
		tbl4[arg1] = computeLuckWeights(var1)
	end

	return tbl4[arg1]
end

tbl2.rarityFor = function(arg1, arg2, arg3)
	if not tbl2.Crates[arg1] then
		return nil
	end

	local var1 = tbl2.weights(arg1, arg3)
	local num1 = 0
	for k1, v1 in ipairs(tbl2.Rarities) do
		num1 = num1 + (var1[v1.Name] or 0)
		if arg2 > num1 then
			continue
		end

		return v1.Name
	end

	return nil
end

tbl2.pick = function(arg1, arg2, arg3, arg4)
	local var2 = tbl2.rarityFor(arg1, arg2, arg4)
	if not var2 then
		return nil
	end

	local var3 = tbl2.pool(arg1)[var2]
	if #var3 == 0 then
		return nil
	end

	return var3[math.clamp(math.floor(arg3), 1, #var3)]
end

tbl2.odds = function(arg1, arg2)
	local var1 = tbl2.weights(arg1, arg2)
	local var2 = tbl2.pool(arg1)
	local tbl1 = { tiers = {}, items = {} }
	for k1, v1 in ipairs(tbl2.Rarities) do
		local var3 = var1[v1.Name] or 0
		local var6 = #var2[v1.Name]
		local var7 = var3 / tbl2.TotalWeight
		local var8 = if 0 < var6 then var7 / var6 else 0
		table.insert(tbl1.tiers, { rarity = v1.Name, weight = var3, chance = var7, count = var6, each = var8 })
		for k2, v2 in ipairs(var2[v1.Name]) do
			tbl1.items[v2.Id] = var8
		end
	end

	return tbl1
end

tbl2.formatPercent = function(arg1)
	if arg1 <= 0 then
		return "0%"
	end

	local var3 = arg1 * 100
	local var4 = nil
	var4 = if 0.001 <= var3 then string.format("%.4g", var3) else string.format("%.2g", var3)
	if string.find(var4, "e") then
		var4 = string.format("%.8f", var3):gsub("0+$", "")
	end

	if string.find(var4, "%.") then
		var4 = var4:gsub("0+$", ""):gsub("%.$", "")
	end

	return var4 .. "%"
end

tbl2.validate = function(arg1)
	local var2 = tbl2.Crates[arg1]
	if not var2 then
		return false, "unknown crate"
	end

	local num1 = 0
	local var3 = tbl2.pool(arg1)
	for k1, v1 in ipairs(tbl2.Rarities) do
		local var4 = var2.Weights[v1.Name] or 0
		if var4 ~= math.floor(var4) or var4 < 0 then
			return false, v1.Name .. " weight is not a whole number"
		end

		if 0 >= var4 then
			continue
		end

		if #var3[v1.Name] ~= 0 then
			continue
		end

		return false, v1.Name .. " has a weight and no skins"
	end

	if num1 ~= tbl2.TotalWeight then
		return false, "weights sum to " .. num1
	end

	if var2.NoLuck then
		return true, nil
	end

	local success, result = pcall(tbl2.weights, arg1, true)
	if not success then
		return false, "2x Luck: " .. tostring(result)
	end

	return true, nil
end

tbl2.formatClock = function(arg1)
	local var1 = math.max(0, (math.floor(arg1)))
	local str1 = "%02d:%02d:%02d"
	local var2 = var1 // 3600
	local var3 = var1 % 3600 // 60
	local var4 = var1 % 60
	return string.format(str1, var2, var3, var4)
end

tbl2.formatCountdown = function(arg1)
	local var1 = math.max(0, (math.floor(arg1)))
	local var6 = var1 // 86400
	local var7 = var1 % 86400 // 3600
	local var8 = var1 % 3600 // 60
	if 0 < var6 then
		local str2 = "%dd %02dh"
		local var9 = var6
		local var10 = var7
		return string.format(str2, var9, var10)
	end

	if 0 < var7 then
		local str4 = "%dh %02dm"
		local var13 = var7
		local var14 = var8
		return string.format(str4, var13, var14)
	end

	local str5 = "%dm %02ds"
	local var15 = var8
	local var16 = var1 % 60
	return string.format(str5, var15, var16)
end

tbl2.Sorts = { "RarityHigh", "RarityLow", "Newest", "Name" }
tbl2.SortNames = {
	RarityHigh = "Rarity: highest",
	RarityLow = "Rarity: lowest",
	Newest = "Newest",
	Name = "Name",
}

tbl2.sort = function(arg1, arg2, arg3)
	local var1 = arg3
	var1 = var1 or {}
	table.sort(arg1, function(arg1, arg2)
		if arg2 == "RarityLow" then
			if arg1.Rank ~= arg2.Rank then
				return arg1.Rank < arg2.Rank
			end
		else
			if arg2 == "Newest" then
				local var6 = var1[arg1.Id] or 0
				local var7 = var1[arg2.Id] or 0
				if var6 ~= var7 then
					return var7 < var6
				end
			else
				if arg2 == "Name" then
					if arg1.FullName ~= arg2.FullName then
						return arg1.FullName < arg2.FullName
					end
				else
					if arg1.Rank ~= arg2.Rank then
						return arg2.Rank < arg1.Rank
					end
				end
			end
		end

		return arg1.Order < arg2.Order
	end)

	return arg1
end

return tbl2

--- ReplicatedStorage.MeltShared.SkinModels [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local tbl1 = { Orange = var1("#F7A541") }
tbl1.Cream = var1("#FFF0D6")
tbl1.Coral = var1("#E97B72")
tbl1.White = var1("#FFFFFF")
tbl1.Steel = var1("#A7B6C2")
tbl1.Charcoal = var1("#3B4652")
local var2 = var1("#D9682B")
local var3 = var1("#B4521F")
local var4 = var1("#2B333C")
local var5 = var1("#55616C")
local var6 = var1("#7D8B96")
local var7 = var1("#FFB547")
local var8 = var1("#FF8A3D")
local var9 = var1("#3FA39A")
local var10 = var1("#2E7E79")
local var11 = var1("#24466B")
local var12 = var1("#1B3552")
local var13 = var1("#C9773E")
local var14 = var1("#BDE8FF")
local tbl2 = { Hairdryer = var1("#FFE2B8") }
tbl2.HeatGun = var1("#FFB36B")
tbl2.SteamBlaster = var1("#F2FBFF")
tbl2.Flamethrower = var1("#FFB14A")
local tbl3 = { AirColor = tbl2 }
local var15 = Enum.Material
local function part(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	local var1 = Instance.new("Part")
	var1.Name = arg3
	local var2 = arg4
	var1.Shape = var2 or Enum.PartType.Block
	var1.Size = arg6
	var1.CFrame = arg2.CFrame * arg5
	var1.Color = arg7
	var2 = arg8
	var1.Material = var2 or var15.SmoothPlastic
	var1.TopSurface = Enum.SurfaceType.Smooth
	var1.BottomSurface = Enum.SurfaceType.Smooth
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Massless = true
	var1.CastShadow = false
	local var3 = arg9
	for k1, v1 in pairs(var3 or {}) do
		var1[k1] = v1
	end

	var1.Parent = arg1
	var2 = Instance.new("WeldConstraint")
	var2.Part0 = arg2
	var2.Part1 = var1
	var2.Parent = var1
	return var1
end

local var16 = Vector3.new
local function newModel(arg1)
	local var1 = Instance.new("Model")
	var1.Name = arg1
	var1:SetAttribute("ToolId", arg1)
	local var2 = Instance.new("Part")
	var2.Name = "Handle"
	var2.CFrame = CFrame.new()
	var2.TopSurface = Enum.SurfaceType.Smooth
	var2.BottomSurface = Enum.SurfaceType.Smooth
	var2.CanCollide = false
	var2.CanQuery = false
	var2.CanTouch = false
	var2.Massless = true
	var2.CastShadow = false
	var2.Parent = var1
	var1.PrimaryPart = var2
	return var1, var2
end

local var17 = tbl1.Charcoal
local var18 = tbl1.Cream
local var19 = tbl1.Steel
tbl3.Roles = {
	Hairdryer = {
		Handle = "grip",
		HandleBand = "accent",
		Trigger = "accent",
		Body = "housing",
		RearCap = "accent",
		Intake = "dark",
		IntakeRing = "accent2",
		IntakeMesh = "dark",
		IntakeHub = "trim",
		Nozzle = "trim",
		NozzleTip = "accent",
		Cord = "dark",
	},
	HeatGun = {
		Grip = "grip",
		GripRidge = "gripDark",
		Trigger = "metalDark",
		TriggerGuard = "grip",
		Body = "housing",
		FrontHousing = "housing",
		PanelBreak = "dark",
		RearStep = "housing2",
		RearCap = "dark",
		Vent = "dark",
		SidePanel = "trim",
		HeatBadge = "accent",
		HeatLine = "trim",
		IndicatorBezel = "dark",
		Indicator = "keep",
		Collar = "dark",
		Nozzle = "metal",
		NozzleTaper = "metal",
		NozzleTip = "metalDark",
		NozzleGlow = "keep",
	},
	SteamBlaster = {
		Handle = "grip",
		GripCap = "gripDark",
		Trigger = "accent2",
		Casing = "housing",
		Body = "tank",
		ChamberEnd = "tank",
		CopperRing = "metal",
		Spine = "housing",
		Pressure1 = "keep",
		Pressure2 = "keep",
		Pressure3 = "keep",
		HandlePost = "grip",
		CarryHandle = "grip",
		FrontHousing = "housing",
		Nozzle = "housing2",
		NozzleLip = "trim",
		NozzleVent = "dark",
		PipeJoint = "metal",
		Pipe = "metal",
		ValveStem = "dark",
		ValveWheel = "metal",
		DialBezel = "metal",
		Dial = "keep",
		GaugeNeedle = "keep",
		SupportHandle = "grip",
	},
	Flamethrower = {
		Handle = "grip",
		Trigger = "metalDark",
		TriggerGuard = "dark",
		Body = "housing2",
		UpperPanel = "housing",
		SidePanel = "housing",
		Trim = "metal",
		LightStrip = "keep",
		HeatVent = "dark",
		ChargeBezel = "dark",
		Charge = "keep",
		RearStock = "grip",
		HosePort = "metal",
		HoseStub = "keep",
		FrontGrip = "grip",
		Collar = "trim",
		Barrel = "dark",
		BarrelRib = "metal",
		MuzzleRing = "accent",
		MuzzleCone = "metalDark",
		CageBar = "dark",
		MuzzleFront = "accent",
		MuzzleGlow = "keep",
	},
	FireGrenade = {
		Handle = "housing",
		Band = "dark",
		Cap = "trim",
		CapTop = "metal",
		PullRing = "metal",
		PullRingHole = "dark",
		Window1 = "keep",
		Window2 = "keep",
		Window3 = "keep",
		Emblem = "trim",
		EmblemFlame = "accent",
		EmblemFlake = "accent2",
	},
}

tbl3.Surfaces = {
	Hairdryer = { { part = "Body", faces = { "side" } }, { part = "Nozzle", faces = { "side" } } },
	HeatGun = {
		{ part = "Body", faces = { "Right", "Left", "Top" } },
		{ part = "FrontHousing", faces = { "Right", "Left", "Top" } },
		{ part = "RearStep", faces = { "Right", "Left", "Top" } },
	},
	SteamBlaster = {
		{ part = "Casing", faces = { "Right", "Left", "Front", "Back" } },
		{ part = "FrontHousing", faces = { "side" } },
		{ part = "Nozzle", faces = { "Top", "Bottom" } },
	},
	Flamethrower = {
		{ part = "UpperPanel", faces = { "Top", "Front", "Back" } },
		{ part = "SidePanel", faces = { "Right", "Left" } },
		{ part = "Body", faces = { "Bottom" } },
		{ part = "MuzzleRing", faces = { "side" } },
	},
}

tbl3.Frames = {
	Hairdryer = {
		nozzle = Vector3.new(0, 0.95, -1.45),
		muzzle = 0.7,
		axisY = 0.95,
		hull = {
			center = Vector3.new(0, 0.95, -0.08),
			size = Vector3.new(1.05, 1.05, 1.25),
			round = true,
		},
		neck = { from = -1.42, to = -0.7, diameter = 0.62 },
		rear = 0.97,
		top = 1.48,
		gripTop = 0.4,
	},
	HeatGun = {
		nozzle = Vector3.new(0, 1.04, -2.12),
		muzzle = 0.42,
		axisY = 1.04,
		hull = { center = Vector3.new(0, 1.03, -0.36), size = Vector3.new(0.96, 1.02, 2.1) },
		neck = { from = -2.08, to = -1.21, diameter = 0.54 },
		rear = 1.1,
		top = 1.54,
		gripTop = 0.57,
		readout = Vector3.new(0, 1.52, -0.36),
	},
	SteamBlaster = {
		nozzle = Vector3.new(0, 1.1, -1.5),
		muzzle = 0.9,
		axisY = 1.1,
		hull = { center = Vector3.new(0, 1.3, 0.15), size = Vector3.new(1.12, 1.12, 2.12), round = true },
		neck = { from = -1.47, to = -0.6, diameter = 0.98 },
		rear = 1.21,
		top = 2.42,
		gripTop = 0.43,
		readout = Vector3.new(0, 1.985, -0.08),
	},
	Flamethrower = {
		nozzle = Vector3.new(0, 1.05, -3.36),
		muzzle = 1.12,
		axisY = 1.05,
		hull = { center = Vector3.new(0, 1.1, -0.45), size = Vector3.new(0.84, 1, 2.3) },
		neck = { from = -3.47, to = -1.7, diameter = 0.5 },
		rear = 0.98,
		top = 1.65,
		gripTop = 0.62,
		readout = Vector3.new(0, 1.63, 0.22),
	},
}

local tbl4 = {
	Hairdryer = function()
		local var2, var3 = newModel("Hairdryer")
		var3.Size = Vector3.new(0.42, 1.3, 0.55)
		var3.Color = tbl1.Charcoal
		part(var2, var3, "HandleBand", nil, CFrame.new(0, -0.45, 0), Vector3.new(0.46, 0.25, 0.6), tbl1.Orange)
		part(var2, var3, "Trigger", nil, CFrame.new(0, 0.2, -0.32), Vector3.new(0.18, 0.36, 0.14), tbl1.Orange)
		part(var2, var3, "Body", Enum.PartType.Cylinder, CFrame.new(0, 0.95, -0.074999999999999956) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(1.25, 1.05, 1.05), tbl1.Cream, nil, nil)
		part(var2, var3, "RearCap", Enum.PartType.Cylinder, CFrame.new(0, 0.95, 0.7) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.3, 1.12, 1.12), tbl1.Orange, nil, nil)
		part(var2, var3, "Intake", Enum.PartType.Cylinder, CFrame.new(0, 0.95, 0.875) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.05, 0.9, 0.9), tbl1.Charcoal, nil, nil)
		local var4, var5, var6, var7 = var1("#E08E2E")
		part(var2, var3, "IntakeRing", Enum.PartType.Cylinder, CFrame.new(var6 or 0, 0.95, 0.91) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.02, 0.66, 0.66), var4, var5, var7)
		part(var2, var3, "IntakeMesh", Enum.PartType.Cylinder, CFrame.new(0, 0.95, 0.92999999999999994) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.02, 0.5, 0.5), tbl1.Charcoal, nil, nil)
		part(var2, var3, "IntakeHub", Enum.PartType.Cylinder, CFrame.new(0, 0.95, 0.955) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.03, 0.2, 0.2), tbl1.Cream, nil, nil)
		local var8, var9, var10, var11 = var1("#EFDDBF")
		part(var2, var3, "Nozzle", Enum.PartType.Cylinder, CFrame.new(var10 or 0, 0.95, -1.025) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.65, 0.62, 0.62), var8, var9, var11)
		part(var2, var3, "NozzleTip", Enum.PartType.Cylinder, CFrame.new(0, 0.95, -1.3599999999999999) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.12, 0.7, 0.7), tbl1.Orange, nil, nil)
		part(var2, var3, "Cord", Enum.PartType.Cylinder, CFrame.new(0, -0.8, 0.05) * CFrame.Angles(0, 0, 1.5707963267948966), Vector3.new(0.35, 0.18, 0.18), tbl1.Charcoal)
		var8 = Instance.new("Attachment")
		var8.Name = "Nozzle"
		var8.Position = Vector3.new(0, 0.95, -1.45)
		var8.Parent = var3
		return var2
	end,
	HeatGun = function()
		local var1, var9 = newModel("HeatGun")
		var9.Size = Vector3.new(0.42, 1.25, 0.56)
		var9.Color = var17
		var9.Transparency = 1
		local var10 = CFrame.new(0, -0.02, 0.06) * CFrame.Angles(-0.20943951023931956, 0, 0)
		part(var1, var9, "Grip", nil, var10, Vector3.new(0.44, 1.32, 0.56), var17)
		for i1 = 0, 2 do
			part(var1, var9, "GripRidge", nil, var10 * CFrame.new(0, i1 * 0.3 + -0.36, 0.28), Vector3.new(0.47, 0.08, 0.1), var4)
		end

		part(var1, var9, "Trigger", nil, CFrame.new(0, 0.36, -0.36), Vector3.new(0.12, 0.3, 0.14), var5)
		part(var1, var9, "TriggerGuard", nil, CFrame.new(0, 0.14, -0.3), Vector3.new(0.1, 0.07, 0.44), var17)
		part(var1, var9, "Body", nil, CFrame.new(0, 1.02, -0.12), Vector3.new(0.86, 0.9, 1.5), var2)
		part(var1, var9, "FrontHousing", nil, CFrame.new(0, 1.04, -0.9), Vector3.new(0.96, 1.02, 0.62), var2)
		part(var1, var9, "PanelBreak", nil, CFrame.new(0, 1.04, -0.6), Vector3.new(0.98, 1.04, 0.08), var17)
		part(var1, var9, "RearStep", nil, CFrame.new(0, 1, 0.78), Vector3.new(0.74, 0.74, 0.34), var3)
		part(var1, var9, "RearCap", nil, CFrame.new(0, 1, 1.02), Vector3.new(0.58, 0.56, 0.16), var17)
		local num1 = 0.44
		for k1, v1 in ipairs({ -0.44, num1 }) do
			for i2 = 0, 3 do
				part(var1, var9, "Vent", nil, CFrame.new(v1, i2 * 0.16 + 0.74, 0.36), Vector3.new(0.03, 0.08, 0.5), var4)
			end

			part(var1, var9, "SidePanel", nil, CFrame.new(v1 * 1.005, 1.1, -0.28), Vector3.new(0.03, 0.44, 0.52), var18)
		end

		part(var1, var9, "HeatBadge", Enum.PartType.Cylinder, CFrame.new(Vector3.new(0.462, 1.1, -0.28)), Vector3.new(0.03, 0.3, 0.3), var3, nil, nil)
		for i3 = -1, 1 do
			part(var1, var9, "HeatLine", nil, CFrame.new(0.48, 1.1, i3 * 0.07 + -0.28) * CFrame.Angles(math.rad(i3 * 8), 0, 0), Vector3.new(0.02, 0.16, 0.03), var18)
		end

		part(var1, var9, "IndicatorBezel", nil, CFrame.new(0, 1.49, -0.36), Vector3.new(0.32, 0.05, 0.36), var17)
		part(var1, var9, "Indicator", nil, CFrame.new(0, 1.52, -0.36), Vector3.new(0.22, 0.04, 0.26), var7)
		part(var1, var9, "Collar", Enum.PartType.Cylinder, CFrame.new(0, 1.04, -1.2850000000000001) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.15, 0.84, 0.84), var17, nil, nil)
		part(var1, var9, "Nozzle", Enum.PartType.Cylinder, CFrame.new(0, 1.04, -1.57) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.42, 0.54, 0.54), var19, var15.Metal, nil)
		part(var1, var9, "NozzleTaper", Enum.PartType.Cylinder, CFrame.new(0, 1.04, -1.8900000000000001) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.22, 0.42, 0.42), var19, var15.Metal, nil)
		part(var1, var9, "NozzleTip", Enum.PartType.Cylinder, CFrame.new(0, 1.04, -2.04) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.08, 0.34, 0.34), var6, var15.Metal, nil)
		part(var1, var9, "NozzleGlow", Enum.PartType.Cylinder, CFrame.new(0, 1.04, -2.09) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.02, 0.24, 0.24), var8, var15.Neon, { Transparency = 1 })
		local var11 = Instance.new("Attachment")
		var11.Name = "Nozzle"
		var11.Position = Vector3.new(0, 1.04, -2.12)
		var11.Parent = var9
		return var1
	end,
	SteamBlaster = function()
		local var1, var2 = newModel("SteamBlaster")
		var2.Size = Vector3.new(0.48, 1.3, 0.6)
		var2.Color = var11
		part(var1, var2, "GripCap", nil, CFrame.new(0, -0.68, 0), Vector3.new(0.52, 0.12, 0.64), var12)
		part(var1, var2, "Trigger", nil, CFrame.new(0, 0.3, -0.38), Vector3.new(0.14, 0.32, 0.16), var10)
		part(var1, var2, "Casing", nil, CFrame.new(0, 0.66, -0.15), Vector3.new(1, 0.46, 1.9), var9)
		part(var1, var2, "Body", Enum.PartType.Cylinder, CFrame.new(0, 1.3, 0.15000000000000002) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(1, 1.12, 1.12), var18, nil, nil)
		local num1 = 0.65
		for k1, v1 in ipairs({ -0.35, num1 }) do
			part(var1, var2, "ChamberEnd", Enum.PartType.Ball, CFrame.new(0, 1.3, v1), Vector3.new(1.12, 1.12, 1.12), var18)
		end

		local num2 = 0.45
		for k2, v2 in ipairs({ -0.15, num2 }) do
			local var3 = v2 + 0.04
			local var5 = v2 - 0.04
			part(var1, var2, "CopperRing", Enum.PartType.Cylinder, CFrame.new(0, 1.3, (var5 + var3) / 2) * CFrame.Angles(0, 1.5707963267948966, 0), var16(math.abs(var3 - var5), 1.2, 1.2), var13, var15.Metal, nil)
		end

		part(var1, var2, "Spine", nil, CFrame.new(0, 1.9, 0.15), Vector3.new(0.36, 0.14, 1.5), var9)
		for i1 = 1, 3 do
			part(var1, var2, "Pressure" .. i1, nil, CFrame.new(0, 1.985, (i1 - 1) * 0.24 + -0.32), Vector3.new(0.2, 0.04, 0.16), var14)
		end

		local num3 = 0.7
		for k3, v3 in ipairs({ -0.4, num3 }) do
			part(var1, var2, "HandlePost", nil, CFrame.new(0, 2.13, v3), Vector3.new(0.14, 0.34, 0.14), var11)
		end

		part(var1, var2, "CarryHandle", nil, CFrame.new(0, 2.34, 0.15), Vector3.new(0.18, 0.16, 1.26), var11)
		part(var1, var2, "FrontHousing", Enum.PartType.Cylinder, CFrame.new(0, 1.1, -0.825) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.45, 0.98, 0.98), var9, nil, nil)
		part(var1, var2, "Nozzle", nil, CFrame.new(0, 1.1, -1.22), Vector3.new(1.2, 0.7, 0.34), var10)
		part(var1, var2, "NozzleLip", nil, CFrame.new(0, 1.1, -1.42), Vector3.new(1.28, 0.78, 0.08), var18)
		for i2 = -1, 1 do
			part(var1, var2, "NozzleVent", nil, CFrame.new(0, i2 * 0.18 + 1.1, -1.47), Vector3.new(0.98, 0.07, 0.04), var4)
		end

		part(var1, var2, "PipeJoint", nil, CFrame.new(0.54, 1.02, 0.25), Vector3.new(0.2, 0.2, 0.2), var13, var15.Metal)
		part(var1, var2, "Pipe", Enum.PartType.Cylinder, CFrame.new(0.64, 1.02, -0.20500000000000002) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.91, 0.16, 0.16), var13, var15.Metal, nil)
		part(var1, var2, "PipeJoint", nil, CFrame.new(0.5, 1.02, -0.66), Vector3.new(0.2, 0.2, 0.2), var13, var15.Metal)
		part(var1, var2, "ValveStem", nil, CFrame.new(0.76, 1.02, -0.2), Vector3.new(0.16, 0.12, 0.12), var17)
		part(var1, var2, "ValveWheel", Enum.PartType.Cylinder, CFrame.new(Vector3.new(0.86, 1.02, -0.2)), Vector3.new(0.06, 0.36, 0.36), var13, var15.Metal, nil)
		part(var1, var2, "DialBezel", Enum.PartType.Cylinder, CFrame.new(Vector3.new(-0.58, 1.3, 0.15)), Vector3.new(0.04, 0.58, 0.58), var13, var15.Metal, nil)
		part(var1, var2, "Dial", Enum.PartType.Cylinder, CFrame.new(Vector3.new(-0.605, 1.3, 0.15)), Vector3.new(0.03, 0.5, 0.5), tbl1.White, nil, nil)
		part(var1, var2, "GaugeNeedle", nil, CFrame.new(-0.625, 1.3, 0.15) * CFrame.Angles(0.6108652381980153, 0, 0) * CFrame.new(0, 0.08, 0), Vector3.new(0.02, 0.18, 0.035), tbl1.Coral)
		part(var1, var2, "SupportHandle", nil, CFrame.new(0, 0.2, -0.85), Vector3.new(0.28, 0.5, 0.32), var11)
		local var6 = Instance.new("Attachment")
		var6.Name = "Nozzle"
		var6.Position = Vector3.new(0, 1.1, -1.5)
		var6.Parent = var2
		return var1
	end,
	Flamethrower = function()
		local var3, var5 = newModel("Flamethrower")
		var5.Size = Vector3.new(0.44, 1.25, 0.58)
		var5.Color = var17
		part(var3, var5, "Trigger", nil, CFrame.new(0, 0.34, -0.36), Vector3.new(0.12, 0.3, 0.14), var6)
		part(var3, var5, "TriggerGuard", nil, CFrame.new(0, 0.14, -0.3), Vector3.new(0.1, 0.06, 0.44), var4)
		part(var3, var5, "Body", nil, CFrame.new(0, 0.95, -0.55), Vector3.new(0.78, 0.66, 2.3), var4)
		part(var3, var5, "UpperPanel", nil, CFrame.new(0, 1.42, -0.45), Vector3.new(0.84, 0.36, 1.7), var2)
		local num1 = 0.42
		for k1, v1 in ipairs({ -0.42, num1 }) do
			part(var3, var5, "SidePanel", nil, CFrame.new(v1, 1.02, -0.6), Vector3.new(0.03, 0.34, 1.5), var2)
			part(var3, var5, "Trim", nil, CFrame.new(v1 * 1.02, 1.24, -0.5), Vector3.new(0.03, 0.06, 1.72), var19, var15.Metal)
			part(var3, var5, "LightStrip", nil, CFrame.new(v1 * 1.03, 0.8, -0.8), Vector3.new(0.03, 0.05, 0.8), var7)
		end

		for i1 = 0, 2 do
			part(var3, var5, "HeatVent", nil, CFrame.new(0, 1.61, i1 * 0.3 + -1), Vector3.new(0.56, 0.05, 0.13), var4)
		end

		part(var3, var5, "ChargeBezel", nil, CFrame.new(0, 1.6, 0.22), Vector3.new(0.26, 0.05, 0.42), var4)
		part(var3, var5, "Charge", nil, CFrame.new(0, 1.63, 0.22), Vector3.new(0.16, 0.04, 0.32), var7)
		part(var3, var5, "RearStock", nil, CFrame.new(0, 1.05, 0.72), Vector3.new(0.6, 0.52, 0.38), var17)
		part(var3, var5, "HosePort", Enum.PartType.Cylinder, CFrame.new(0, 0.72, 0.90999999999999992) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.14, 0.3, 0.3), var13, var15.Metal, nil)
		local var9 = Instance.new("Attachment")
		var9.Name = "HoseEnd"
		var9.Position = Vector3.new(0, 0.72, 0.98)
		var9.Parent = var5
		part(var3, var5, "FrontGrip", nil, CFrame.new(0, 0.46, -1.45) * CFrame.Angles(-0.17453292519943295, 0, 0), Vector3.new(0.3, 0.8, 0.36), var17)
		part(var3, var5, "Collar", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -1.8199999999999998) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.24, 0.82, 0.82), var1("#E7DFD0"), var15.Metal, nil)
		part(var3, var5, "Barrel", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -2.395) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.91, 0.4, 0.4), var17, var15.Metal, nil)
		local num2 = -2.5
		for k2, v2 in ipairs({ -2.2, num2 }) do
			local var10 = v2 + 0.03
			local var11 = v2 - 0.03
			part(var3, var5, "BarrelRib", Enum.PartType.Cylinder, CFrame.new(0, 1.05, (var11 + var10) / 2) * CFrame.Angles(0, 1.5707963267948966, 0), var16(math.abs(var10 - var11), 0.5, 0.5), var6, var15.Metal, nil)
		end

		part(var3, var5, "MuzzleRing", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -2.9000000000000004) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.1, 1, 1), var2, nil, nil)
		part(var3, var5, "MuzzleCone", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -3.125) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.35, 0.5, 0.5), var6, var15.Metal, nil)
		for i2 = 0, 3 do
			local var12 = math.rad(i2 * 90 + 45)
			part(var3, var5, "CageBar", nil, CFrame.new(math.cos(var12) * 0.46, math.sin(var12) * 0.46 + 1.05, -3.15), Vector3.new(0.1, 0.1, 0.42), var4)
		end

		part(var3, var5, "MuzzleFront", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -3.41) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.12, 1.12, 1.12), var2, nil, nil)
		part(var3, var5, "MuzzleGlow", Enum.PartType.Cylinder, CFrame.new(0, 1.05, -3.315) * CFrame.Angles(0, 1.5707963267948966, 0), Vector3.new(0.03, 0.36, 0.36), var8, var15.Neon, { Transparency = 1 })
		local var14 = Instance.new("Attachment")
		var14.Name = "Nozzle"
		var14.Position = Vector3.new(0, 1.05, -3.36)
		var14.Parent = var5
		return var3
	end,
	FireGrenade = function()
		local var1, var3 = newModel("FireGrenade")
		var3.Shape = Enum.PartType.Ball
		var3.Size = Vector3.new(0.7, 0.7, 0.7)
		var3.Color = var2
		local num1 = 0.15
		local var5 = CFrame.Angles(0, 0, 1.5707963267948966)
		for k1, v1 in ipairs({ -0.15, num1 }) do
			part(var1, var3, "Band", Enum.PartType.Cylinder, CFrame.new(0, v1, 0) * var5, Vector3.new(0.08, 0.66, 0.66), var17)
		end

		part(var1, var3, "Cap", Enum.PartType.Cylinder, CFrame.new(0, 0.37, 0) * var5, Vector3.new(0.14, 0.32, 0.32), var18)
		part(var1, var3, "CapTop", Enum.PartType.Cylinder, CFrame.new(0, 0.45, 0) * var5, Vector3.new(0.04, 0.2, 0.2), var6, var15.Metal)
		part(var1, var3, "PullRing", Enum.PartType.Cylinder, CFrame.new(Vector3.new(0.19, 0.46, 0)), Vector3.new(0.03, 0.22, 0.22), var19, var15.Metal, nil)
		part(var1, var3, "PullRingHole", Enum.PartType.Cylinder, CFrame.new(Vector3.new(0.2, 0.46, 0)), Vector3.new(0.035, 0.12, 0.12), var4, nil, nil)
		for i1 = 1, 3 do
			part(var1, var3, "Window" .. i1, nil, CFrame.Angles(0, math.rad((i1 - 1) * 120 + 60), 0) * CFrame.new(0, 0, -0.34), Vector3.new(0.12, 0.1, 0.04), var7)
		end

		local var8 = part(var1, var3, "Emblem", Enum.PartType.Cylinder, CFrame.new(Vector3.new(0, 0, 0)), Vector3.new(0.03, 0.26, 0.26), var18, nil, nil)
		var8.CFrame = var3.CFrame * CFrame.new(0, 0, -0.34) * CFrame.Angles(0, 1.5707963267948966, 0)
		part(var1, var3, "EmblemFlame", nil, CFrame.new(0, 0.01, -0.36) * CFrame.Angles(0, 0, 0.78539816339744828), Vector3.new(0.08, 0.08, 0.02), var2)
		for i2 = 0, 2 do
			part(var1, var3, "EmblemFlake", nil, CFrame.new(0, 0.01, -0.357) * CFrame.Angles(0, 0, (math.rad(i2 * 60))), Vector3.new(0.018, 0.2, 0.012), var14)
		end

		return var1
	end,
}

tbl3.build = function(arg1, arg2)
	local var1 = tbl4[arg1]
	assert(var1, "SkinModels: no base model for " .. tostring(arg1))
	local var3 = var1()
	if arg2 then
		for k1, v1 in ipairs(var3:GetDescendants()) do
			if not v1:IsA("BasePart") then
				continue
			end

			v1.Anchored = true
		end
	end

	return var3
end

tbl3.has = function(arg1)
	return tbl4[arg1] ~= nil
end

tbl3.add = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = Instance.new("Part")
	var1.Name = arg3
	if arg8 and arg8.Shape then
		var1.Shape = arg8.Shape
	end

	var1.Size = arg5
	var1.Color = arg6
	local var2 = arg7
	var1.Material = var2 or var15.SmoothPlastic
	var1.TopSurface = Enum.SurfaceType.Smooth
	var1.BottomSurface = Enum.SurfaceType.Smooth
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Massless = true
	var1.CastShadow = false
	if arg8 then
		for k1, v1 in pairs(arg8) do
			if k1 == "Shape" then
				continue
			end

			var1[k1] = v1
		end
	end

	var1.Anchored = arg2.Anchored
	var1.CFrame = arg2.CFrame * arg4
	var1:SetAttribute("SkinOffset", arg4)
	if not arg2.Anchored then
		var2 = Instance.new("Weld")
		var2.Name = "SkinWeld"
		var2.Part0 = arg2
		var2.Part1 = var1
		var2.C0 = arg4
		var2.Parent = var1
	end

	var1.Parent = arg1
	return var1
end

tbl3.tubeZ = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11)
	local var1 = arg11
	local var2 = CFrame.new(arg4, arg5, (arg6 + arg7) / 2) * CFrame.Angles(0, 1.5707963267948966, 0)
	var1 = var1 or {}
	var1.Shape = Enum.PartType.Cylinder
	local var3 = arg1
	local var4 = arg2
	local var5 = arg3
	local var6 = var2
	local var7 = var16(math.abs(arg7 - arg6), arg8, arg8)
	local var8 = arg9
	local var9 = arg10
	local var10 = var1
	return tbl3.add(var3, var4, var5, var6, var7, var8, var9, var10)
end

tbl3.rod = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	local var1 = arg5 - arg4
	local var2 = (arg4 + arg5) / 2
	local var3 = var1.Magnitude
	local var4 = arg9
	local var5 = CFrame.lookAt(var2, var2 + var1, if 0.95 < math.abs(var1.Unit.Y) then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)) * CFrame.Angles(0, 1.5707963267948966, 0)
	var4 = var4 or {}
	var4.Shape = Enum.PartType.Cylinder
	local var6 = arg1
	local var7 = arg2
	local var8 = arg3
	local var9 = var5
	local var10 = var16(var3, arg6, arg6)
	local var11 = arg7
	local var12 = arg8
	local var13 = var4
	return tbl3.add(var6, var7, var8, var9, var10, var11, var12, var13)
end

tbl3.ball = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg8
	var1 = var1 or {}
	var1.Shape = Enum.PartType.Ball
	local var2 = arg1
	local var3 = arg2
	local var4 = arg3
	local var5 = CFrame.new(arg4)
	local var6 = var16(arg5, arg5, arg5)
	local var7 = arg6
	local var8 = arg7
	local var9 = var1
	return tbl3.add(var2, var3, var4, var5, var6, var7, var8, var9)
end

tbl3.wedge = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = Instance.new("WedgePart")
	var1.Name = arg3
	var1.Size = arg5
	var1.Color = arg6
	local var2 = arg7
	var1.Material = var2 or var15.SmoothPlastic
	var1.TopSurface = Enum.SurfaceType.Smooth
	var1.BottomSurface = Enum.SurfaceType.Smooth
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Massless = true
	var1.CastShadow = false
	local var3 = arg8
	for k1, v1 in pairs(var3 or {}) do
		var1[k1] = v1
	end

	var1.Anchored = arg2.Anchored
	var1.CFrame = arg2.CFrame * arg4
	var1:SetAttribute("SkinOffset", arg4)
	if not arg2.Anchored then
		var2 = Instance.new("Weld")
		var2.Name = "SkinWeld"
		var2.Part0 = arg2
		var2.Part1 = var1
		var2.C0 = arg4
		var2.Parent = var1
	end

	var1.Parent = arg1
	return var1
end

tbl3.ring = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11)
	local var1 = arg9 or 16
	local tbl1 = {}
	local var2 = arg5 * 2 * math.sin(3.1415926535897931 / var1) + arg6 * 0.35
	for i1 = 0, var1 - 1 do
		local var3 = arg10
		local var4 = CFrame.new(arg4) * (var3 or CFrame.identity)
		local var5 = var4 * CFrame.Angles(0, 0, (i1 + 0.5) * 2 * 3.1415926535897931 / var1)
		var4 = tbl1
		local var6 = tbl3.add
		var3 = arg1
		local var7 = arg2
		local var8 = arg3
		local var9 = var5 * CFrame.new(arg5, 0, 0)
		local var10 = var16(arg6, var2, arg6)
		local var11 = arg7
		local var12 = arg8
		local var13 = if arg11 then table.clone(arg11) else nil
		table.insert(var4, var6(var3, var7, var8, var9, var10, var11, var12, var13))
	end

	return tbl1
end

tbl3.star = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = arg7
	local var2 = tbl3.add
	local var3 = arg1
	local var4 = arg2
	local var5 = arg3
	local var6 = arg4 * CFrame.Angles(0.78539816339744828, 0, 0)
	local var7 = var16(arg5 * 0.14, arg5, arg5 * 0.14)
	local var8 = arg6
	var1 = var1 or var15.Neon
	var2 = var2(var3, var4, var5, var6, var7, var8, var1, if arg8 then table.clone(arg8) else nil)
	local var9 = arg7
	var3 = tbl3.add
	var4 = arg1
	var5 = arg2
	var6 = arg3
	var7 = arg4 * CFrame.Angles(-0.78539816339744828, 0, 0)
	var8 = var16(arg5 * 0.14, arg5, arg5 * 0.14)
	var1 = arg6
	var9 = var9 or var15.Neon
	var3 = var3(var4, var5, var6, var7, var8, var1, var9, if arg8 then table.clone(arg8) else nil)
	local var10 = arg7
	var4 = tbl3.add
	var5 = arg1
	var6 = arg2
	var7 = arg3
	var8 = arg4
	var1 = var16(arg5 * 0.14, arg5 * 0.62, arg5 * 0.62)
	var9 = arg6
	var10 = var10 or var15.Neon
	var4 = var4(var5, var6, var7, var8, var1, var9, var10, if arg8 then table.clone(arg8) else nil)
	return { var2, var3, var4 }
end

local str1 = "#FFF4C2"
local var20 = ColorSequenceKeypoint.new(0, var1(str1))
local str2 = "#FFC24A"
local var21 = ColorSequenceKeypoint.new(0.25, var1(str2))
local str3 = "#FF7A1F"
local var22 = ColorSequenceKeypoint.new(0.65, var1(str3))
local str4 = "#B8431A"
str2 = 1
local tbl5 = {
	texture = "rbxasset://textures/particles/fire_main.dds",
	colors = ColorSequence.new({ var20, var21, var22, ColorSequenceKeypoint.new(str2, var1(str4)) }),
	light = 0.9,
	lightInfluence = 0,
	life = 0.3,
	speed = 60,
	spread = 4,
	rate = 90,
	size0 = 0.35,
	size1 = 1.5,
	alpha = 0.2,
	drag = 1,
}

local tbl6 = {
	Hairdryer = {
		light = 0.15,
		life = 0.28,
		speed = 16,
		spread = 5,
		rate = 45,
		size0 = 0.2,
		size1 = 0.9,
		alpha = 0.82,
	},
	HeatGun = {
		light = 0.3,
		life = 0.3,
		speed = 19,
		spread = 4,
		rate = 60,
		size0 = 0.25,
		size1 = 1.2,
		alpha = 0.78,
	},
	SteamBlaster = {
		light = 0.05,
		life = 0.42,
		speed = 17,
		spread = 13,
		rate = 70,
		size0 = 0.5,
		size1 = 2.6,
		alpha = 0.72,
		drag = 3,
	},
	Flamethrower = tbl5,
}

tbl3.previewAirflow = function(arg1, arg2, arg3)
	local var1 = arg1:GetAttribute("ToolId")
	local var2 = arg1:FindFirstChild("Handle")
	local var3 = var2
	local var5 = tbl6[var1]
	var3 = var3 and var2:FindFirstChild("Nozzle")
	if not var5 or (not var3) then
		return nil
	end

	local var6 = Instance.new("ParticleEmitter")
	var6.Name = "PreviewAirflow"
	var6.Enabled = false
	var6.Texture = var5.texture or "rbxasset://textures/particles/smoke_main.dds"
	local var7 = var5.colors
	var7 = var7 or ColorSequence.new(tbl3.AirColor[var1])
	var6.Color = var7
	var6.LightEmission = var5.light
	var6.LightInfluence = var5.lightInfluence or 0.4
	var6.EmissionDirection = Enum.NormalId.Front
	var6.Lifetime = NumberRange.new(var5.life * 0.8, var5.life)
	var7 = var5.speed
	if arg2 then
		var7 = math.min(var7, arg2 / var5.life)
	end

	var6.Speed = NumberRange.new(var7 * 0.8, var7)
	var6.SpreadAngle = Vector2.new(var5.spread, var5.spread)
	local num2 = 1
	local var8 = var5.alpha
	if arg3 then
		var8 = math.min(var5.alpha, 0.4)
		var6.LightEmission = math.max(var5.light, 0.5)
		num2 = 1.6
	end

	local var9 = var5.rate
	var6.Rate = var9 * (if arg3 then 1.5 else 1)
	local num3 = 1
	local var10 = var5.size1 * num2
	var6.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, var5.size0 * num2),
		NumberSequenceKeypoint.new(num3, var10),
	})

	var10 = 1
	local num4 = 1
	var6.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, var8),
		NumberSequenceKeypoint.new(0.6, (math.min(1, var8 + 0.12))),
		NumberSequenceKeypoint.new(var10, num4),
	})

	var6.RotSpeed = NumberRange.new(-60, 60)
	var6.Rotation = NumberRange.new(0, 360)
	var6.Drag = var5.drag or 2
	var6.Parent = var3
	return var6
end

return tbl3

--- ReplicatedStorage.MeltShared.SkinPatterns [ModuleScript]
-- y u r i

local str1 = "SkinModels"
local var1 = require(script.Parent:WaitForChild(str1))
local tbl1 = {
	Right = {
		n = Vector3.new(1, 0, 0),
		u = Vector3.new(0, 0, -1),
		v = Vector3.new(0, 1, 0),
		size = function(arg1)
			return arg1.Z, arg1.Y, arg1.X
		end,
	},
	Left = {
		n = Vector3.new(-1, 0, 0),
		u = Vector3.new(0, 0, 1),
		v = Vector3.new(0, 1, 0),
		size = function(arg1)
			return arg1.Z, arg1.Y, arg1.X
		end,
	},
	Top = {
		n = Vector3.new(0, 1, 0),
		u = Vector3.new(0, 0, -1),
		v = Vector3.new(-1, 0, 0),
		size = function(arg1)
			return arg1.Z, arg1.X, arg1.Y
		end,
	},
	Bottom = {
		n = Vector3.new(0, -1, 0),
		u = Vector3.new(0, 0, -1),
		v = Vector3.new(1, 0, 0),
		size = function(arg1)
			return arg1.Z, arg1.X, arg1.Y
		end,
	},
	Front = {
		n = Vector3.new(0, 0, -1),
		u = Vector3.new(1, 0, 0),
		v = Vector3.new(0, 1, 0),
		size = function(arg1)
			return arg1.X, arg1.Y, arg1.Z
		end,
	},
	Back = {
		n = Vector3.new(0, 0, 1),
		u = Vector3.new(-1, 0, 0),
		v = Vector3.new(0, 1, 0),
		size = function(arg1)
			return arg1.X, arg1.Y, arg1.Z
		end,
	},
}

local var2 = Vector3.new
local function roundSurface(arg1, arg2)
	local var1 = arg1.Size.Y / 2
	local var3 = arg1.Size.X
	return {
		part = arg1,
		local_ = arg2,
		U = 6.2831853071795862 * var1,
		V = var3,
		round = true,
		radius = var1,
		face = "side",
		at = function(arg1, arg2, arg3)
			local var4 = arg1 / var1
			return arg2 * CFrame.fromMatrix(Vector3.new(1, 0, 0) * (arg2 - var3 / 2) + var2(0, math.cos(var4), (math.sin(var4))) * (var1 + (arg3 or 0.012)), var2(0, -math.sin(var4), (math.cos(var4))), Vector3.new(1, 0, 0))
		end,
	}
end

local function blockSurface(arg1, arg2, arg3)
	local var2 = tbl1[arg3]
	if not var2 then
		return nil
	end

	local var3, var4, var5 = var2.size(arg1.Size)
	return {
		part = arg1,
		local_ = arg2,
		U = var3,
		V = var4,
		round = false,
		face = arg3,
		at = function(arg1, arg2, arg3)
			return arg2 * CFrame.fromMatrix(var2.n * (var5 / 2 + (arg3 or 0.012)) + var2.u * (arg1 - var3 / 2) + var2.v * (arg2 - var4 / 2), var2.u, var2.v)
		end,
	}
end

local function obstacles(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if v1.Transparency >= 0.95 then
			continue
		end

		local tbl2 = { part = v1, cf = arg2.CFrame:ToObjectSpace(v1.CFrame) }
		tbl2.size = v1.Size
		table.insert(tbl1, tbl2)
	end

	return tbl1
end

local function blocked(arg1, arg2, arg3, arg4)
	for k1, v1 in ipairs(arg1) do
		if v1.part == arg2 then
			continue
		end

		local var1 = v1.cf:PointToObjectSpace(arg3)
		local var2 = v1.size / 2
		if math.abs(var1.X) >= var2.X + arg4 then
			continue
		end

		if math.abs(var1.Y) >= var2.Y + arg4 then
			continue
		end

		if math.abs(var1.Z) >= var2.Z + arg4 then
			continue
		end

		return true
	end

	return false
end

str1 = Enum.Material
local tbl2 = {
	surfaces = function(arg1, arg2)
		local var2 = var1.Surfaces[arg2]
		local var3 = arg1:FindFirstChild("Handle")
		local tbl1 = {}
		for k1, v1 in ipairs(var2 or {}) do
			for k2, v2 in ipairs(arg1:GetChildren()) do
				if not v2:IsA("BasePart") then
					continue
				end

				if v2.Name ~= v1.part then
					continue
				end

				local var4 = var3.CFrame:ToObjectSpace(v2.CFrame)
				for k3, v3 in ipairs(v1.faces) do
					if v3 == "side" and (v2:IsA("Part") and v2.Shape == Enum.PartType.Cylinder) then
						table.insert(tbl1, (roundSurface(v2, var4)))
					else
						if v3 == "side" then
							continue
						end

						local var5 = blockSurface(v2, var4, v3)
						if not var5 then
							continue
						end

						table.insert(tbl1, var5)
					end
				end
			end
		end

		return tbl1
	end,
	pen = function(arg1, arg2, arg3)
		local var1 = arg1:FindFirstChild("Handle")
		local tbl1 = {
			model = arg1,
			handle = var1,
			folder = arg2,
			obstacles = obstacles(arg1, var1),
			count = 0,
		}

		tbl1.budget = arg3 or 220
		return tbl1
	end,
	rect = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
		if arg1.budget <= arg1.count then
			return nil
		end

		local var3 = arg2.at(arg3, arg4) * CFrame.Angles(0, 0, arg7)
		if blocked(arg1.obstacles, arg2.part, var3.Position, 0.005) then
			return nil
		end

		local var4 = arg1.count + 1
		arg1.count = var4
		local var5 = arg9
		local var6 = arg1.folder
		local var7 = arg1.handle
		local str2 = "Pattern"
		local var8 = var3
		local var9 = var2(arg5, arg6, 0.02)
		local var10 = arg8
		var5 = var5 or str1.SmoothPlastic
		local var11 = arg10
		return var1.add(var6, var7, str2, var8, var9, var10, var5, var11)
	end,
	dot = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
		if arg1.budget <= arg1.count then
			return nil
		end

		local var3 = arg2.at(arg3, arg4)
		if blocked(arg1.obstacles, arg2.part, var3.Position, 0.005) then
			return nil
		end

		local var4 = arg1.count + 1
		arg1.count = var4
		var4 = if arg8 then table.clone(arg8) else {}
		var4.Shape = Enum.PartType.Cylinder
		local var5 = arg7
		local var6 = arg1.folder
		local var7 = arg1.handle
		local str2 = "Pattern"
		local var8 = var3 * CFrame.Angles(0, 1.5707963267948966, 0)
		local var9 = var2(0.02, arg5, arg5)
		local var10 = arg6
		var5 = var5 or str1.SmoothPlastic
		local var11 = var4
		return var1.add(var6, var7, str2, var8, var9, var10, var5, var11)
	end,
}

tbl2.line = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
	local var1 = arg5 - arg3
	local var2 = arg6 - arg4
	local var4 = math.sqrt(var1 * var1 + var2 * var2)
	if var4 < 0.005 then
		return
	end

	local var5 = if arg2.round then math.max(1, (math.ceil(math.abs(var1) / 0.14))) else 1
	for i1 = 0, var5 - 1 do
		local var6 = i1 / var5
		local var7 = (i1 + 1) / var5
		local var8 = arg3 + var1 * var6
		local var9 = arg3 + var1 * var7
		local var10 = arg4 + var2 * var6
		local var11 = arg4 + var2 * var7
		tbl2.rect(arg1, arg2, (var8 + var9) / 2, (var10 + var11) / 2, var4 / var5 + arg7 * 0.6, arg7, math.atan2(var11 - var10, var9 - var8), arg8, arg9, arg10)
	end
end

local tbl3 = {
	cheetah = function(arg1, arg2, arg3, arg4)
		for k1, v1 in ipairs(arg2) do
			for i1 = 0.12, v1.U, 0.24 do
				for i2 = 0.12, v1.V, 0.24 do
					local var2 = i2 + arg3:NextNumber(-0.07, 0.07)
					local var3 = i1 + arg3:NextNumber(-0.08, 0.08)
					local var4
					if var2 < 0.05 or v1.V - 0.05 < var2 then
						var4 = false
					else
						if v1.round then
							var4 = true
						else
							var4 = false
							if 0.05 <= var3 then
								var4 = var3 <= v1.U - 0.05
							end
						end
					end

					if not var4 then
						continue
					end

					if arg3:NextNumber() >= 0.8 then
						continue
					end

					if arg3:NextNumber() < 0.45 then
						tbl2.dot(arg1, v1, var3, var2, arg3:NextNumber(0.06, 0.1), arg4.spot)
					else
						var4 = arg3:NextNumber(0.05, 0.065)
						tbl2.dot(arg1, v1, var3, var2, var4 * 1.3, arg4.middle)
						local var5 = arg3:NextNumber(0, 6.2831853071795862)
						for i3 = 0, 3 do
							if i3 ~= 3 or arg3:NextNumber() < 0.5 then
								local var6 = var5 + i3 * 3.1415926535897931 / 2 + arg3:NextNumber(-0.3, 0.3)
								tbl2.dot(arg1, v1, var3 + math.cos(var6) * var4, var2 + math.sin(var6) * var4, arg3:NextNumber(0.035, 0.05), arg4.spot)
							end
						end
					end
				end
			end
		end
	end,
	checker = function(arg1, arg2, _, arg4)
		for k1, v1 in ipairs(arg2) do
			local var2 = math.max(2, (math.floor(v1.U / 0.19 + 0.5)))
			local var3 = math.max(2, (math.floor(v1.V / 0.19 + 0.5)))
			if v1.round then
				var2 = math.max(4, var2 - var2 % 2)
			end

			local var4 = v1.U / var2
			local var5 = v1.V / var3
			for i1 = 0, var2 - 1 do
				for i2 = 0, var3 - 1 do
					if (i1 + i2) % 2 ~= 0 then
						continue
					end

					tbl2.rect(arg1, v1, (i1 + 0.5) * var4, (i2 + 0.5) * var5, var4 * 0.99, var5 * 0.99, 0, arg4.check)
				end
			end
		end
	end,
	candystripe = function(arg1, arg2, _, arg4)
		for k1, v1 in ipairs(arg2) do
			if v1.round then
				local var1 = math.max(1, (math.floor(v1.U / 0.34 + 0.5)))
				local var2 = v1.U / var1
				for i1 = 0, var1 - 1 do
					local var3 = math.max(2, (math.ceil(v1.V / 0.108)))
					local var4 = i1 * var2
					for i2 = 0, var3 - 1 do
						local var5 = i2 * v1.V / var3
						local var6 = (i2 + 1) * v1.V / var3
						tbl2.line(arg1, v1, var4 + var5 / 0.9, var5, var4 + var6 / 0.9, var6, 0.14, arg4.stripe)
					end
				end
			else
				local var7 = v1.U + v1.V
				local num1 = 0.17
				local var8 = math.min(num1, v1.V)
				local var9 = num1 - math.min(num1, v1.U)
				local var10 = num1 - var8
				local var11 = math.min(num1, v1.U)
				local var12 = var10 - var11
				local var13 = var8 - var9
				local var14 = math.sqrt(var12 * var12 + var13 * var13)
				while num1 >= var7 and var9 < v1.V and 0 <= var10 and 0.14 < var14 do
				end
			end
		end
	end,
	glaciervein = function(arg1, arg2, arg3, arg4)
		for k1, v1 in ipairs(arg2) do
			for i1 = 1, math.max(1, (math.floor(v1.U * v1.V * 1.6 + 0.5))) do
				local tbl1 = { u = arg3:NextNumber(0.05, v1.U - 0.05), w = 0.03 }
				tbl1.v = arg3:NextNumber(0.05, v1.V - 0.05)
				tbl1.a = arg3:NextNumber(0, 6.2831853071795862)
				tbl1.n = arg3:NextInteger(5, 8)
				local tbl3 = { tbl1 }
				while 0 < (#tbl3) do
					tbl1 = table.remove(tbl3)
					local var1 = tbl1.u
					local var2 = tbl1.v
					local var3 = tbl1.a
					for i2 = 1, tbl1.n do
						local var4 = arg3:NextNumber(0.09, 0.14)
						local var6 = var2 + math.sin(var3) * var4
						local var7 = var1 + math.cos(var3) * var4
						local var8
						if var6 < 0.03 or v1.V - 0.03 < var6 then
							var8 = false
						else
							if v1.round then
								var8 = true
							else
								var8 = false
								if 0.03 <= var7 then
									var8 = var7 <= v1.U - 0.03
								end
							end
						end

						if not var8 then
							break
						end

						tbl2.line(arg1, v1, var1, var2, var7, var6, tbl1.w, arg4.vein, str1.SmoothPlastic)
						if 0.02 >= tbl1.w then
							continue
						end

						if arg3:NextNumber() >= 0.28 then
							continue
						end

						var3 = var3 + arg3:NextNumber(-0.5, 0.5)
						var1 = var7
						var2 = var6
						local tbl4 = { u = var1, v = var2, a = var3 + (if arg3:NextNumber() < 0.5 then 0.9 else -0.9) }
						tbl4.n = arg3:NextInteger(2, 4)
						tbl4.w = tbl1.w * 0.65
						table.insert(tbl3, tbl4)
					end
				end
			end
		end
	end,
	koi = function(arg1, arg2, arg3, arg4)
		for k1, v1 in ipairs(arg2) do
			local var1 = v1.U * v1.V
			for i1 = 1, math.max(1, (math.floor(var1 * 2.2 + 0.5))) do
				local var2 = if i1 % 3 == 0 then arg4.ink else arg4.red
				local var3 = arg3:NextNumber(0.08, v1.U - 0.08)
				local var4 = arg3:NextNumber(0.08, v1.V - 0.08)
				for i2 = 1, arg3:NextInteger(3, 5) do
					local var6 = var4 + arg3:NextNumber(-0.07, 0.07)
					local var7 = var3 + arg3:NextNumber(-0.09, 0.09)
					local var8
					if var6 < 0.06 or v1.V - 0.06 < var6 then
						var8 = false
					else
						if v1.round then
							var8 = true
						else
							var8 = false
							if 0.06 <= var7 then
								var8 = var7 <= v1.U - 0.06
							end
						end
					end

					if not var8 then
						continue
					end

					tbl2.dot(arg1, v1, var7, var6, arg3:NextNumber(0.1, 0.17), var2)
				end
			end

			for i3 = 1, math.max(1, (math.floor(var1 * 1.4))) do
				local var9 = arg3:NextNumber(0.12, v1.U - 0.12)
				local var10 = arg3:NextNumber(0.1, v1.V - 0.1)
				for i4 = 0, 3 do
					local var11 = 3.1415926535897931 * (i4 / 4)
					local var12 = 3.1415926535897931 * ((i4 + 1) / 4)
					tbl2.line(arg1, v1, var9 + math.cos(var11) * 0.07, var10 + math.sin(var11) * 0.07, var9 + math.cos(var12) * 0.07, var10 + math.sin(var12) * 0.07, 0.018, arg4.wave)
				end
			end
		end
	end,
	circuit = function(arg1, arg2, arg3, arg4)
		for k1, v1 in ipairs(arg2) do
			for i1 = 1, math.max(1, (math.floor(v1.U * v1.V * 3 + 0.5))) do
				local var1 = arg3:NextNumber(0.06, v1.U - 0.06)
				local var2 = arg3:NextNumber(0.06, v1.V - 0.06)
				local var3 = arg3:NextNumber() < 0.6
				for i2 = 1, arg3:NextInteger(2, 3) do
					local var4 = arg3:NextNumber(0.12, 0.34)
					local var5 = var4 * (if arg3:NextNumber() < 0.5 then -1 else 1)
					var4 = var1
					local var6 = var2
					if var3 then
						var4 = math.clamp(var1 + var5, 0.05, v1.U - 0.05)
					else
						var6 = math.clamp(var2 + var5, 0.05, v1.V - 0.05)
					end

					tbl2.line(arg1, v1, var1, var2, var4, var6, 0.022, arg4.trace, str1.Neon)
					var1 = var4
					var2 = var6
					var3 = not var3
				end

				if arg3:NextNumber() < 0.5 then
					tbl2.rect(arg1, v1, var1, var2, 0.06, 0.06, 0, arg4.pad, str1.Metal)
				else
					tbl2.dot(arg1, v1, var1, var2, 0.055, arg4.pad, str1.Metal)
				end
			end
		end
	end,
	scales = function(arg1, arg2, _, arg4)
		for k1, v1 in ipairs(arg2) do
			local num1 = 0
			for i1 = 0.07, v1.V, 0.14 do
				for i2 = (if num1 % 2 == 0 then 0 else 0.095) + 0.095, v1.U, 0.19 do
					local var2
					if i1 < 0.03 or v1.V - 0.03 < i1 then
						var2 = false
					else
						if v1.round then
							var2 = true
						else
							var2 = false
							if 0.03 <= i2 then
								var2 = i2 <= v1.U - 0.03
							end
						end
					end

					if not var2 then
						continue
					end

					if arg1.count >= arg1.budget then
						continue
					end

					if -0.35 >= (v1.at(i2, i1, 0.1).Position - v1.at(i2, i1, 0).Position).Unit.Y then
						continue
					end

					var2 = v1.at(i2, i1, 0.015) * CFrame.Angles(-0.20943951023931956, 0, 0)
					if blocked(arg1.obstacles, v1.part, var2.Position, 0.005) then
						continue
					end

					local var3 = arg1.count + 1
					arg1.count = var3
					var3 = var1.add
					local var4 = arg1.folder
					local var5 = arg1.handle
					local str2 = "Scale"
					local var6 = var2 * CFrame.Angles(0, 1.5707963267948966, 0)
					local var7 = Vector3.new(0.02, 0.17, 0.17)
					var3(var4, var5, str2, var6, var7, if num1 % 2 == 0 then arg4.scale else arg4.scale2, str1.Metal, { Shape = Enum.PartType.Cylinder })
				end

				num1 = num1 + 1
			end
		end
	end,
	stars = function(arg1, arg2, arg3, arg4)
		for k1, v1 in ipairs(arg2) do
			for i1 = 1, math.max(2, (math.floor(v1.U * v1.V * 5 + 0.5))) do
				local var4 = arg3:NextNumber(0.05, v1.U - 0.05)
				local var5 = arg3:NextNumber(0.05, v1.V - 0.05)
				if i1 % 3 == 0 then
					local var6 = arg3:NextNumber(0.07, 0.1)
					tbl2.rect(arg1, v1, var4, var5, var6, var6 * 0.18, 0.78539816339744828, arg4.star, str1.Neon)
					tbl2.rect(arg1, v1, var4, var5, var6, var6 * 0.18, -0.78539816339744828, arg4.star, str1.Neon)
				else
					tbl2.dot(arg1, v1, var4, var5, arg3:NextNumber(0.02, 0.035), arg4.star, str1.Neon)
				end
			end
		end
	end,
	rivets = function(arg1, arg2, _, arg4)
		for k1, v1 in ipairs(arg2) do
			if v1.round then
				continue
			end

			for i1 = 0.08, v1.U - 0.06, 0.22 do
				tbl2.dot(arg1, v1, i1, 0.06, 0.045, arg4.rivet, str1.Metal)
				tbl2.dot(arg1, v1, i1, v1.V - 0.06, 0.045, arg4.rivet, str1.Metal)
			end
		end
	end,
}

tbl2.Patterns = tbl3
tbl2.draw = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = tbl3[arg1]
	assert(var1, "SkinPatterns: no pattern " .. tostring(arg1))
	local var2 = arg2
	local var3 = arg3
	local var4 = tbl2.pen(arg2, arg4, arg8)
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.surfaces(var2, var3)) do
		if not arg7 or arg7(v1) then
			table.insert(tbl1, v1)
		end
	end

	var1(var4, tbl1, Random.new(arg5), arg6)
	return var4.count
end

tbl2.seed = function(arg1)
	local num1 = 5381
	for i1 = 1, #arg1 do
		num1 = (num1 * 33 + string.byte(arg1, i1)) % 2147483647
	end

	return num1
end

return tbl2

--- ReplicatedStorage.MeltShared.SkinVariants [ModuleScript]
-- y u r i

local var1 = Vector3.new
local function disc(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	local var2 = arg3 + arg4.Unit * (arg6 / 2)
	local var3 = CFrame.lookAt(var2, var2 + arg4, if 0.9 < math.abs(arg4.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
	local var5 = var3 * CFrame.Angles(0, 1.5707963267948966, 0)
	var3 = if arg9 then table.clone(arg9) else {}
	var3.Shape = Enum.PartType.Cylinder
	local var6 = arg2
	local var7 = var5
	local var8 = var1(arg6, arg5, arg5)
	local var9 = arg7
	local var10 = arg8
	local var11 = var3
	return arg1:add(var6, var7, var8, var9, var10, var11)
end

local var2 = Enum.Material
local var3 = math.rad
local var4 = Color3.fromHex
local function seams(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg1.A
	local tbl1 = {}
	for k1, v1 in ipairs(var2.seams) do
		if v1.ring then
			local var3 = v1.y
			local str1 = "Seam"
			local var4 = var1(0, var3 or var2.axisY, v1.z)
			local var5 = v1.r
			local var6 = arg4
			local var7 = arg2
			local var8 = arg3
			local num1 = 18
			local var9 = nil
			local var10 = arg5
			for k2, v2 in ipairs(arg1:ring(str1, var4, var5, var6, var7, var8, num1, var9, var10)) do
				table.insert(tbl1, v2)
			end
		else
			local var11 = tbl1
			local str2 = "Seam"
			local var12 = CFrame.lookAt((v1.a + v1.b) / 2, v1.b)
			local var13 = var1(arg4, arg4, (v1.b - v1.a).Magnitude)
			local var14 = arg2
			local var15 = arg3
			local var16 = if arg5 then table.clone(arg5) else nil
			table.insert(var11, arg1:add(str2, var12, var13, var14, var15, var16))
		end
	end

	return tbl1
end

local function around(arg1, arg2, arg3, arg4, arg5)
	local tbl1 = {}
	for i1 = 0, arg4 - 1 do
		local var2 = var3(arg5 or 0) + i1 * 2 * 3.1415926535897931 / arg4
		local tbl2 = { point = var1(math.cos(var2) * arg3, arg1.axisY + math.sin(var2) * arg3, arg2) }
		tbl2.angle = var2
		table.insert(tbl1, tbl2)
	end

	return tbl1
end

local function gear(arg1, arg2, arg3, arg4, arg5, arg6)
	local var3 = arg1
	local str1 = "Gear"
	local var4 = arg2
	local var5 = arg3
	local var6 = arg4 * 0.78
	local num1 = 0.05
	local var7 = arg5
	local var8 = var2.Metal
	var3 = arg2 + arg3.Unit * 0.025
	local var9 = CFrame.lookAt(var3, var3 + arg3, if 0.9 < math.abs(arg3.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
	local tbl1 = { disc(var3, str1, var4, var5, var6, num1, var7, var8) }
	for i1 = 0, 7 do
		local str2 = "GearTooth"
		local var10 = var9 * CFrame.Angles(0, 0, i1 * 3.1415926535897931 / 4) * CFrame.new(0, arg4 * 0.42, 0)
		local var11 = var1(arg4 * 0.14, arg4 * 0.14, 0.05)
		local var12 = arg5
		local var13 = var2.Metal
		table.insert(tbl1, arg1:add(str2, var10, var11, var12, var13))
	end

	var5 = arg1
	var6 = "GearHub"
	num1 = arg2 + arg3.Unit * 0.04
	var7 = arg3
	var8 = arg4 * 0.26
	local num2 = 0.04
	local var14 = arg6
	local var15 = var2.Metal
	table.insert(tbl1, disc(var5, var6, num1, var7, var8, num2, var14, var15))
	return tbl1, var9
end

local function rotate(arg1, arg2, arg3, arg4, arg5, arg6)
	for k1, v1 in ipairs(arg1) do
		v1:SetAttribute("FxRotateCenter", arg2)
		v1:SetAttribute("FxRotateAxis", arg3.Unit)
		v1:SetAttribute("FxRotateSpeed", arg4)
		if arg5 then
			v1:SetAttribute("FxBob", arg5)
			v1:SetAttribute("FxBobPhase", k1 * 1.3)
		end

		if not arg6 then
			continue
		end

		v1:SetAttribute("FxTumble", arg6)
	end
end

local function plate(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11)
	local var2 = arg3 + arg4.Unit * (arg7 / 2)
	local var3 = CFrame.lookAt(var2, var2 + arg4, if 0.9 < math.abs(arg4.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
	local var4 = arg2
	local var5 = var3 * CFrame.Angles(0, 0, arg11 or 0)
	local var6 = var1(arg5, arg6, arg7)
	local var7 = arg8
	local var8 = arg9
	local var9 = arg10
	return arg1:add(var4, var5, var6, var7, var8, var9)
end

local function pulse(arg1, arg2, arg3, arg4, arg5)
	for k1, v1 in ipairs(arg1) do
		v1:SetAttribute("FxPulseA", arg2)
		v1:SetAttribute("FxPulseB", arg3)
		v1:SetAttribute("FxPulsePeriod", arg4)
		v1:SetAttribute("FxPulsePhase", k1 * 0.37)
		if not arg5 then
			continue
		end

		v1:SetAttribute("FxPulseFade", arg5)
	end
end

local function fins(arg1, arg2, arg3, arg4)
	local var2 = arg1.A
	local var4 = var2.fins
	local tbl1 = {}
	for k1, v1 in ipairs(var4.angles) do
		local var5 = var4.y
		local var6 = CFrame.new(0, var5 or var2.axisY, var4.z)
		local var7 = var6 * CFrame.Angles(0, 0, (var3(v1 - 90)))
		local str1 = "Fin"
		local var8 = var7 * CFrame.new(0, var4.r + var4.height * (arg4 or 1) / 2, 0)
		local var9 = var1(0.06, var4.height * (arg4 or 1), var4.length * (arg4 or 1))
		local var10 = arg2
		local var11 = arg3
		table.insert(tbl1, arg1:wedge(str1, var8, var9, var10, var11))
	end

	return tbl1
end

local function anchor(arg1, arg2, arg3, arg4)
	local var1 = arg4.Unit
	local var3 = arg2
	local var4 = CFrame.fromMatrix(arg3, if 0.9 < math.abs(var1.Y) then Vector3.new(1, 0, 0) else var1:Cross(Vector3.new(0, 1, 0)).Unit, var1)
	local var5 = Vector3.new(0.06, 0.06, 0.06)
	local var6 = Color3.new(1, 1, 1)
	local var7 = var2.SmoothPlastic
	local tbl1 = { Transparency = 1 }
	return arg1:add(var3, var4, var5, var6, var7, tbl1)
end

local function emitter(_, arg2, arg3, arg4)
	local var1 = Instance.new("ParticleEmitter")
	var1.Name = "SkinFx"
	var1.Enabled = false
	var1.Texture = arg3.texture or "rbxasset://textures/particles/sparkles_main.dds"
	var1.Color = arg3.color
	var1.LightEmission = arg3.light or 0.6
	var1.LightInfluence = arg3.influence or 0
	var1.EmissionDirection = Enum.NormalId.Top
	var1.Lifetime = arg3.life
	var1.Speed = arg3.speed
	local var2 = arg3.spread
	var2 = var2 or Vector2.new(20, 20)
	var1.SpreadAngle = var2
	var1.Rate = arg3.rate
	var1.Size = arg3.size
	var2 = arg3.alpha
	if not var2 then
		local num3 = 1
		local num4 = 1
		var2 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(num3, num4) })
	end

	var1.Transparency = var2
	var1.Acceleration = arg3.accel or Vector3.new(0, 0, 0)
	var1.Drag = arg3.drag or 0
	var2 = arg3.rot
	var2 = var2 or NumberRange.new(0)
	var1.RotSpeed = var2
	var1.Rotation = NumberRange.new(0, 360)
	var1.LockedToPart = arg3.locked == true
	var1.ZOffset = 0
	if arg3.shape then
		var1.Shape = arg3.shape
		var2 = arg3.shapeStyle
		var1.ShapeStyle = var2 or Enum.ParticleEmitterShapeStyle.Surface
		var1.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	end

	var1:SetAttribute("FxWhen", arg4)
	var1:SetAttribute("FxRate", arg3.rate)
	var1.Parent = arg2
	return var1
end

local function dragonHead(arg1, arg2, arg3, arg4, arg5, arg6)
	local var3 = CFrame.new(arg2)
	arg1:add("Skull", var3 * CFrame.new(0, arg3 * 0.06, arg3 * 1.02), var1(arg3 * 1, arg3 * 0.9, arg3 * 0.5), arg4, var2.SmoothPlastic)
	arg1:add("BrowPlate", var3 * CFrame.new(0, arg3 * 0.52, arg3 * 0.95) * CFrame.Angles(-0.20943951023931956, 0, 0), var1(arg3 * 0.9, arg3 * 0.08, arg3 * 0.5), arg5, var2.Metal)
	local num1 = 1
	local var5 = arg1:wedge("UpperJaw", var3 * CFrame.new(0, arg3 * 0.34, arg3 * 0.36), var1(arg3 * 0.86, arg3 * 0.32, arg3 * 0.9), arg4, var2.SmoothPlastic)
	local var6 = arg1:wedge("LowerJaw", var3 * CFrame.new(0, -arg3 * 0.3, arg3 * 0.42) * CFrame.Angles(0, 0, 3.1415926535897931), var1(arg3 * 0.7, arg3 * 0.24, arg3 * 0.78), arg4, var2.SmoothPlastic)
	for k1, v1 in ipairs({ -1, num1 }) do
		arg1:rod("Horn", arg2 + var1(v1 * arg3 * 0.3, arg3 * 0.5, arg3 * 1), arg2 + var1(v1 * arg3 * 0.46, arg3 * 0.8, arg3 * 1.62), arg3 * 0.11, arg5, var2.Metal)
		arg1:ball("HornTip", arg2 + var1(v1 * arg3 * 0.47, arg3 * 0.82, arg3 * 1.66), arg3 * 0.09, arg5, var2.Metal)
		arg1:rod("CheekFrill", arg2 + var1(v1 * arg3 * 0.5, 0, arg3 * 0.9), arg2 + var1(v1 * arg3 * 0.62, -arg3 * 0.12, arg3 * 1.35), arg3 * 0.07, arg5, var2.Metal)
		local str1 = "Eye"
		local var7 = arg2 + var1(v1 * arg3 * 0.4, arg3 * 0.26, arg3 * 0.74)
		local var8 = arg3 * 0.12
		local var9 = var4("#FFB23A")
		local var10 = var2.Neon
		table.insert(arg6, arg1:ball(str1, var7, var8, var9, var10))
		arg1:ball("Nostril", arg2 + var1(v1 * arg3 * 0.14, arg3 * 0.47, arg3 * 0.12), arg3 * 0.07, var4("#0B0809"), var2.SmoothPlastic)
		for i1 = 0, 2 do
			local str2 = "#F2E6D0"
			arg1:wedge("Tooth", var3 * CFrame.new(v1 * arg3 * (i1 * 0.1 + 0.16), arg3 * 0.14, arg3 * (i1 * 0.14 + 0.12)) * CFrame.Angles(0, 0, 3.1415926535897931), var1(arg3 * 0.05, arg3 * 0.1, arg3 * 0.06), var4(str2))
			str2 = "#F2E6D0"
			arg1:wedge("Tooth", var3 * CFrame.new(v1 * arg3 * (i1 * 0.09 + 0.14), -arg3 * 0.13, arg3 * (i1 * 0.14 + 0.18)), var1(arg3 * 0.05, arg3 * 0.09, arg3 * 0.06), var4(str2))
		end
	end

	return var5, var6
end

local function bob(arg1, arg2)
	for k1, v1 in ipairs(arg1) do
		v1:SetAttribute("FxBob", arg2)
		v1:SetAttribute("FxBobPhase", k1 * 1.7)
		v1:SetAttribute("FxRotateCenter", Vector3.new(0, 0, 0))
		v1:SetAttribute("FxRotateAxis", Vector3.new(0, 1, 0))
		v1:SetAttribute("FxRotateSpeed", 0)
	end
end

local tbl1 = {
	Anatomy = {
		Hairdryer = {
			round = true,
			axisY = 0.95,
			hullR = 0.525,
			hullFront = -0.7,
			hullBack = 0.55,
			back = 0.97,
			nozzle = Vector3.new(0, 0.95, -1.45),
			muzzle = 0.7,
			neckFront = -1.42,
			neckBack = -0.7,
			neckR = 0.35,
			nozzleParts = { "NozzleTip" },
			ventParts = { "IntakeRing", "IntakeMesh", "IntakeHub" },
			vent = { at = Vector3.new(0, 0.95, 0.975), normal = Vector3.new(0, 0, 1), size = 0.86 },
			gear = { at = Vector3.new(-0.535, 0.95, 0.02), normal = Vector3.new(-1, 0, 0), size = 0.36 },
			porthole = { at = Vector3.new(0.535, 0.98, -0.12), normal = Vector3.new(1, 0, 0), size = 0.36 },
			inlays = {
				{ Vector3.new(0.53, 1.12, -0.38), Vector3.new(1, 0.3, 0) },
				{ Vector3.new(0.53, 0.84, 0.18), Vector3.new(1, -0.2, 0) },
				{ Vector3.new(-0.53, 1.12, 0.3), Vector3.new(-1, 0.3, 0) },
				{ Vector3.new(-0.53, 0.86, -0.42), Vector3.new(-1, -0.2, 0) },
				{ Vector3.new(0, 1.482, -0.2), Vector3.new(0, 1, 0) },
			},
			spine = { Vector3.new(0, 1.475, 0.45), Vector3.new(0, 1.475, -0.62) },
			seams = {
				{ ring = true, z = -0.36, r = 0.536 },
				{ ring = true, z = 0.28, r = 0.536 },
				{ a = Vector3.new(0, 1.482, 0.52), b = Vector3.new(0, 1.482, -0.68) },
			},
			bands = { -0.46, 0.36 },
			flames = {
				{ Vector3.new(0.24, 1.36, 0.72), Vector3.new(0.3, 1, 0.3) },
				{ Vector3.new(-0.24, 1.36, 0.72), Vector3.new(-0.3, 1, 0.3) },
			},
			orbit = { center = Vector3.new(0, 0.95, -0.15), radius = 0.86 },
			fins = { z = 0.82, r = 0.55, length = 0.5, height = 0.34, angles = { 90, 210, 330 } },
			sidePlates = {},
			topY = 1.475,
			sideX = 0.525,
			sideSpan = { -0.62, 0.48 },
			sideY = { 0.72, 1.18 },
		},
		HeatGun = {
			round = false,
			axisY = 1.04,
			hullR = 0.5,
			hullFront = -1.21,
			hullBack = 0.63,
			back = 1.1,
			nozzle = Vector3.new(0, 1.04, -2.12),
			muzzle = 0.56,
			neckFront = -2.08,
			neckBack = -1.21,
			neckR = 0.27,
			nozzleParts = { "NozzleTaper", "NozzleTip" },
			ventParts = { "Vent" },
			vents = {
				{ at = Vector3.new(0.455, 0.98, 0.36), normal = Vector3.new(1, 0, 0) },
				{ at = Vector3.new(-0.455, 0.98, 0.36), normal = Vector3.new(-1, 0, 0) },
			},
			ventSize = Vector3.new(0.56, 0.54, 0),
			gear = { at = Vector3.new(-0.462, 1.1, -0.28), normal = Vector3.new(-1, 0, 0), size = 0.32 },
			porthole = { at = Vector3.new(-0.462, 1.1, -0.28), normal = Vector3.new(-1, 0, 0), size = 0.34 },
			inlays = {
				{ Vector3.new(0.487, 1.28, -0.84), Vector3.new(1, 0.2, 0) },
				{ Vector3.new(0.487, 0.78, -1), Vector3.new(1, -0.2, 0) },
				{ Vector3.new(-0.487, 1.26, -0.96), Vector3.new(-1, 0.2, 0) },
				{ Vector3.new(-0.437, 0.74, 0.18), Vector3.new(-1, -0.2, 0) },
				{ Vector3.new(0.437, 0.74, 0.22), Vector3.new(1, -0.2, 0) },
				{ Vector3.new(0, 1.555, -0.92), Vector3.new(0, 1, 0) },
			},
			spine = { Vector3.new(0, 1.47, 0.58), Vector3.new(0, 1.47, -0.12) },
			spine2 = { Vector3.new(0, 1.55, -0.66), Vector3.new(0, 1.55, -1.14) },
			seams = {
				{ a = Vector3.new(0.437, 1.43, 0.6), b = Vector3.new(0.437, 1.43, -0.58) },
				{ a = Vector3.new(-0.437, 1.43, 0.6), b = Vector3.new(-0.437, 1.43, -0.58) },
				{ a = Vector3.new(0.437, 0.62, 0.6), b = Vector3.new(0.437, 0.62, -0.58) },
				{ a = Vector3.new(-0.437, 0.62, 0.6), b = Vector3.new(-0.437, 0.62, -0.58) },
				{ a = Vector3.new(0.487, 1.5, -0.63), b = Vector3.new(0.487, 1.5, -1.18) },
				{ a = Vector3.new(-0.487, 1.5, -0.63), b = Vector3.new(-0.487, 1.5, -1.18) },
			},
			bands = {},
			flames = {
				{ Vector3.new(0.47, 1.26, 0.36), Vector3.new(1, 1.2, 0) },
				{ Vector3.new(-0.47, 1.26, 0.36), Vector3.new(-1, 1.2, 0) },
			},
			orbit = { center = Vector3.new(0, 1.03, -0.4), radius = 0.98 },
			fins = { z = 1, r = 0.36, length = 0.5, height = 0.32, angles = { 90, 215, 325 }, y = 1 },
			topY = 1.47,
			sideX = 0.43,
			sideSpan = { -0.84, 0.6 },
			sideY = { 0.62, 1.42 },
		},
		SteamBlaster = {
			round = false,
			axisY = 1.1,
			hullR = 0.6,
			hullFront = -1.05,
			hullBack = 0.8,
			back = 1.21,
			nozzle = Vector3.new(0, 1.1, -1.5),
			muzzle = 0.95,
			neckFront = -1.42,
			neckBack = -0.6,
			neckR = 0.49,
			nozzleParts = { "NozzleLip", "NozzleVent" },
			ventParts = { "NozzleVent" },
			gear = { at = Vector3.new(-0.515, 0.66, 0.34), normal = Vector3.new(-1, 0, 0), size = 0.32 },
			porthole = { at = Vector3.new(0.515, 0.66, 0.38), normal = Vector3.new(1, 0, 0), size = 0.34 },
			inlays = {
				{ Vector3.new(0.515, 0.64, -0.55), Vector3.new(1, 0, 0) },
				{ Vector3.new(-0.515, 0.64, -0.6), Vector3.new(-1, 0, 0) },
				{ Vector3.new(0.515, 0.64, -0.05), Vector3.new(1, 0, 0) },
				{ Vector3.new(0.575, 1.5, 0.6), Vector3.new(1, 0.5, 0) },
				{ Vector3.new(-0.575, 1.5, -0.3), Vector3.new(-1, 0.5, 0) },
			},
			tank = { y = 1.3, r = 0.56, front = -0.91, back = 1.21 },
			spine = nil,
			seams = {
				{ a = Vector3.new(0.505, 0.82, 0.78), b = Vector3.new(0.505, 0.82, -1.08) },
				{ a = Vector3.new(-0.505, 0.82, 0.78), b = Vector3.new(-0.505, 0.82, -1.08) },
				{ a = Vector3.new(0.505, 0.5, 0.78), b = Vector3.new(0.505, 0.5, -1.08) },
				{ a = Vector3.new(-0.505, 0.5, 0.78), b = Vector3.new(-0.505, 0.5, -1.08) },
				{ ring = true, z = -0.28, r = 0.566, y = 1.3 },
			},
			bands = {},
			flames = {
				{ Vector3.new(0.42, 0.93, 0.7), Vector3.new(0.2, 1, 0) },
				{ Vector3.new(-0.42, 0.93, 0.7), Vector3.new(-0.2, 1, 0) },
			},
			orbit = { center = Vector3.new(0, 1.15, 0.05), radius = 1.08 },
			fins = {
				z = 1.02,
				r = 0.5,
				length = 0.5,
				height = 0.34,
				angles = { 45, 135, 225, 315 },
				y = 1.3,
			},
			topY = 0.89,
			sideX = 0.5,
			sideSpan = { -1.05, 0.78 },
			sideY = { 0.45, 0.87 },
		},
		Flamethrower = {
			round = false,
			axisY = 1.05,
			hullR = 0.45,
			hullFront = -1.7,
			hullBack = 0.6,
			back = 0.98,
			nozzle = Vector3.new(0, 1.05, -3.36),
			muzzle = 1.12,
			neckFront = -3.47,
			neckBack = -1.7,
			neckR = 0.2,
			nozzleParts = { "MuzzleFront", "MuzzleCone", "CageBar", "MuzzleRing" },
			ventParts = { "HeatVent" },
			vent = {
				at = Vector3.new(0, 1.625, -0.7),
				normal = Vector3.new(0, 1, 0),
				size = Vector3.new(0.66, 0.82, 0),
			},
			gear = { at = Vector3.new(0.315, 1.05, 0.72), normal = Vector3.new(1, 0, 0), size = 0.34 },
			porthole = { at = Vector3.new(-0.437, 1.02, -1), normal = Vector3.new(-1, 0, 0), size = 0.3 },
			inlays = {
				{ Vector3.new(0.437, 1.02, -0.25), Vector3.new(1, 0, 0) },
				{ Vector3.new(-0.437, 1.02, -0.3), Vector3.new(-1, 0, 0) },
				{ Vector3.new(0.437, 1, -1.1), Vector3.new(1, 0, 0) },
				{ Vector3.new(0, 1.605, -1.2), Vector3.new(0, 1, 0) },
				{ Vector3.new(0, 1.605, 0.02), Vector3.new(0, 1, 0) },
			},
			spine = { Vector3.new(0, 1.6, -0.16), Vector3.new(0, 1.6, -1.26) },
			spineX = 0.34,
			seams = {
				{ a = Vector3.new(0.395, 0.68, 0.55), b = Vector3.new(0.395, 0.68, -1.65) },
				{ a = Vector3.new(-0.395, 0.68, 0.55), b = Vector3.new(-0.395, 0.68, -1.65) },
				{ a = Vector3.new(0.425, 1.52, 0.38), b = Vector3.new(0.425, 1.52, -1.28) },
				{ a = Vector3.new(-0.425, 1.52, 0.38), b = Vector3.new(-0.425, 1.52, -1.28) },
			},
			bands = { -2.3, -2.62 },
			barrelR = 0.2,
			flames = {
				{ Vector3.new(0.2, 1.66, -0.7), Vector3.new(0.2, 1, 0) },
				{ Vector3.new(-0.2, 1.66, -0.7), Vector3.new(-0.2, 1, 0) },
			},
			orbit = { center = Vector3.new(0, 1.1, -1), radius = 1 },
			fins = { z = 0.86, r = 0.3, length = 0.46, height = 0.3, angles = { 90, 215, 325 }, y = 1.05 },
			topY = 1.6,
			sideX = 0.42,
			sideSpan = { -1.3, 0.38 },
			sideY = { 0.66, 1.56 },
		},
	},
	Kit = {
		facing = function(arg1, arg2)
			local var1 = arg1
			local var2 = arg1 + arg2
			local var3 = if 0.9 < math.abs(arg2.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0)
			return CFrame.lookAt(var1, var2, var3)
		end,
		disc = disc,
		plate = plate,
		anchor = anchor,
		emitter = emitter,
		static = function(arg1)
			arg1:SetAttribute("FxStatic", true)
			arg1:SetAttribute("FxStaticTransparency", arg1.Transparency)
			arg1.Transparency = 1
			return arg1
		end,
		rotate = rotate,
		pulse = pulse,
		around = around,
	},
}

local tbl2 = {
	aurora = function(arg1)
		local var1 = arg1
		local var3 = seams(var1, var4("#5EF2E0"), var2.Neon, 0.03)
		local var5 = var4("#B38BFF")
		for k1, v1 in ipairs(var3) do
			if k1 % 2 ~= 0 then
				continue
			end

			v1.Color = var5
		end
	end,
	emberline = function(arg1)
		seams(arg1, var4("#FF7A1F"), var2.Neon, 0.028)
	end,
	bubblegum = function(_)
	end,
	brassworks = function(arg1)
		local var3 = arg1.A
		local var5 = var3.ventParts
		arg1:hide(table.unpack(var5))
		local var7 = arg1.pal.metal
		local var8 = var4("#6E5220")
		if arg1.weapon == "Hairdryer" then
			local var9 = var3.vent
			disc(arg1, "VentBack", var9.at - Vector3.new(0, 0, 0.03), var9.normal, var9.size, 0.04, var4("#2A241A"), var2.Metal)
			local str1 = "VentRim"
			local var10 = var9.at + Vector3.new(0, 0, 0.02)
			local var11 = var9.size / 2
			local num1 = 0.06
			local var12 = var7
			local var13 = var2.Metal
			local num2 = 16
			local var14 = nil
			for k1, v1 in ipairs(arg1:ring(str1, var10, var11, num1, var12, var13, num2, var14)) do
				v1.Name = "VentRim"
			end

			for i1 = -2, 2 do
				arg1:add("VentSlat", CFrame.new(var9.at + var1(0, i1 * 0.14, 0.03)) * CFrame.Angles(-0.43633231299858238, 0, 0), var1(math.sqrt((math.max(0.02, (var9.size / 2) ^ 2 - (i1 * 0.14) ^ 2))) * 2 - 0.06, 0.05, 0.03), var7, var2.Metal)
			end

			local var15 = var9.normal
			disc(arg1, "VentBoss", var9.at + Vector3.new(0, 0, 0.03), var15, 0.16, 0.05, var8, var2.Metal)
			for k2, v2 in ipairs(var3.bands) do
				arg1:tube("BrassBand", 0, var3.axisY, v2 - 0.035, v2 + 0.035, var3.hullR * 2 + 0.05, var7, var2.Metal)
			end

			arg1:tube("BrassTip", 0, var3.axisY, -1.44, -1.36, 0.74, var7, var2.Metal)
			local var16 = var3
			for k3, v3 in ipairs((around(var16, 0.7, 0.575, 8, 22.5))) do
				arg1:ball("Rivet", var1(v3.point.X, v3.point.Y, 0.7), 0.06, var7, var2.Metal)
			end
		else
			if arg1.weapon == "HeatGun" then
				for k4, v4 in ipairs(var3.vents) do
					local var17 = v4.normal
					local var18 = var3.ventSize.X + 0.06
					local var19 = var3.ventSize.Y + 0.06
					local var20 = var2.Metal
					local var21 = v4.at - v4.normal * 0.02 + var17.Unit * 0.015
					local var22 = CFrame.lookAt(var21, var21 + var17, if 0.9 < math.abs(var17.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
					arg1:add("VentCover", var22 * CFrame.Angles(0, 0, 0), var1(var18, var19, 0.03), var8, var20, nil)
					var18 = v4.normal
					var17 = v4.at + v4.normal * 0.02
					local var23 = CFrame.lookAt(var17, var17 + var18, if 0.9 < math.abs(var18.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
					for i2 = -2, 2 do
						arg1:add("VentLouvre", var23 * CFrame.new(0, i2 * 0.1, 0) * CFrame.Angles(0.52359877559829882, 0, 0), var1(var3.ventSize.X - 0.04, 0.035, 0.07), var7, var2.Metal)
					end

					local num3 = 1
					for k5, v5 in ipairs({ -1, num3 }) do
						local num4 = 1
						for k6, v6 in ipairs({ -1, num4 }) do
							arg1:ball("Rivet", (var23 * CFrame.new(v5 * (var3.ventSize.X / 2 + 0.01), v6 * (var3.ventSize.Y / 2 + 0.01), 0)).Position, 0.05, var7, var2.Metal)
						end
					end
				end

				local num5 = 0.44
				for k7, v7 in ipairs({ -0.44, num5 }) do
					local num6 = -0.8
					for k8, v8 in ipairs({ 0.55, num6 }) do
						arg1:add("CornerCap", CFrame.new(v7, 1.45, v8), Vector3.new(0.07, 0.07, 0.16), var7, var2.Metal)
					end
				end

				arg1:tube("BrassCollar", 0, var3.axisY, -1.37, -1.3, 0.9, var7, var2.Metal)
				arg1:tube("BrassTip", 0, var3.axisY, -2.09, -2.02, 0.4, var7, var2.Metal)
			else
				if arg1.weapon == "SteamBlaster" then
					local var24 = CFrame.new(0, 1.1, -1.455)
					for i3 = -1, 2 do
						arg1:add("VentSlat", var24 * CFrame.new(0, i3 * 0.18 + -0.27, 0) * CFrame.Angles(-0.43633231299858238, 0, 0), Vector3.new(1, 0.05, 0.05), var7, var2.Metal)
					end

					arg1:add("VentFrame", var24 * CFrame.new(0, 0.36, 0), Vector3.new(1.12, 0.05, 0.05), var7, var2.Metal)
					arg1:add("VentFrame", var24 * CFrame.new(0, -0.36, 0), Vector3.new(1.12, 0.05, 0.05), var7, var2.Metal)
					local num7 = 0.53
					for k9, v9 in ipairs({ -0.53, num7 }) do
						arg1:add("VentFrame", var24 * CFrame.new(v9, 0, 0), Vector3.new(0.05, 0.72, 0.05), var7, var2.Metal)
					end

					local num8 = 0.55
					for k10, v10 in ipairs({ -0.75, num8 }) do
						local num9 = 0.51
						for k11, v11 in ipairs({ -0.51, num9 }) do
							local num10 = 0.82
							for k12, v12 in ipairs({ 0.5, num10 }) do
								arg1:ball("Rivet", var1(v11, v12, v10), 0.05, var7, var2.Metal)
							end
						end
					end

					arg1:tube("BrassBand", 0, 1.3, -0.62, -0.55, 1.18, var7, var2.Metal)
				else
					local var25 = var3.vent
					arg1:add("VentCover", CFrame.new(var25.at), var1(var25.size.X, 0.05, var25.size.Y), var8, var2.Metal)
					for i4 = -3, 3 do
						arg1:add("VentLouvre", CFrame.new(var25.at + var1(0, 0.04, i4 * 0.1)) * CFrame.Angles(-0.52359877559829882, 0, 0), var1(var25.size.X - 0.08, 0.035, 0.08), var7, var2.Metal)
					end

					local num11 = 1
					for k13, v13 in ipairs({ -1, num11 }) do
						arg1:add("VentRail", CFrame.new(var25.at + var1(v13 * var25.size.X / 2, 0.03, 0)), var1(0.05, 0.06, var25.size.Y), var7, var2.Metal)
					end

					for k14, v14 in ipairs(var3.bands) do
						arg1:tube("BrassBand", 0, var3.axisY, v14 - 0.04, v14 + 0.04, 0.5, var7, var2.Metal)
					end

					local num12 = -0.55
					for k15, v15 in ipairs({ -1.15, num12, 0.05 }) do
						local num13 = 0.43
						for k16, v16 in ipairs({ -0.43, num13 }) do
							arg1:ball("Rivet", var1(v16, 1.3, v15), 0.05, var7, var2.Metal)
						end
					end
				end
			end
		end

		local var26 = var3.gear
		rotate(gear(arg1, var26.at, var26.normal, var26.size, var7, var8), var26.at, var26.normal, 25)
	end,
	crystalbound = function(arg1)
		local var5 = arg1.A
		local var6 = var4("#A8E8FF")
		local var7 = var4("#DDF8FF")
		local tbl1 = {}
		for k1, v1 in ipairs(var5.inlays) do
			local var8 = v1[1]
			local var9 = v1[2].Unit
			local var10 = if k1 % 2 == 0 then 0.18 else 0.24
			local var11 = var2.Glass
			local var12 = var8 + var9.Unit * 0.035
			local var13 = CFrame.lookAt(var12, var12 + var9, if 0.9 < math.abs(var9.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
			arg1:add("Crystal", var13 * CFrame.Angles(0, 0, 0.78539816339744828), var1(var10, var10, 0.07), var6, var11, { Transparency = 0.12, Reflectance = 0.2 })
			local var14 = var10 * 0.5
			local var15 = var10 * 0.5
			var13 = var2.Glass
			local var16 = var8 + Vector3.new(0.02, -0.06, 0.05) + var9.Unit * 0.025
			local var17 = CFrame.lookAt(var16, var16 + var9, if 0.9 < math.abs(var9.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
			arg1:add("CrystalChip", var17 * CFrame.Angles(0, 0, 0.3490658503988659), var1(var14, var15, 0.05), var6, var13, { Transparency = 0.15 })
			var13 = arg1
			var12 = "CrystalCore"
			local var18 = var8 + var9 * 0.02
			var17 = var9
			var16 = var10 * 0.36
			local var19 = var10 * 0.36
			local num1 = 0.06
			local var20 = var7
			local var21 = var2.Neon
			local tbl2 = { Transparency = 0.3 }
			local num2 = 0.78539816339744828
			table.insert(tbl1, plate(var13, var12, var18, var17, var16, var19, num1, var20, var21, tbl2, num2))
		end

		pulse(tbl1, var7, var4("#7FD8FF"), 3.5, 0.35)
		local var22 = var5.nozzle
		if arg1.weapon == "SteamBlaster" then
			local tbl3 = { Vector3.new(0, -0.44, 0), Vector3.new(1.34, 0.1, 0.22), 0 }
			local var23 = CFrame.new(0, 1.1, -1.43)
			for k2, v2 in ipairs({
				{ Vector3.new(0, 0.44, 0), Vector3.new(1.34, 0.1, 0.22), 0 },
				tbl3,
				{ Vector3.new(0.68, 0, 0), Vector3.new(0.1, 0.9, 0.22), 0 },
				{ Vector3.new(-0.68, 0, 0), Vector3.new(0.1, 0.9, 0.22), 0 },
			}) do

				arg1:add("Shroud", var23 * CFrame.new(v2[1]) * CFrame.Angles(0.13962634015954636, 0, 0), v2[2], var6, var2.Glass, { Transparency = 0.1, Reflectance = 0.25 })
			end

			local num3 = 0.68
			for k3, v3 in ipairs({ -0.68, num3 }) do
				local num4 = 0.44
				for k4, v4 in ipairs({ -0.44, num4 }) do
					arg1:add("ShroudCorner", var23 * CFrame.new(v3, v4, 0) * CFrame.Angles(0, 0, 0.78539816339744828), Vector3.new(0.16, 0.16, 0.24), var4("#DDF4FB"), var2.Glass, { Transparency = 0.05 })
				end
			end
		else
			local var24 = var5.muzzle / 2 + 0.07
			local num5 = 0.34
			if arg1.weapon == "Flamethrower" then
				arg1:hide("CageBar")
				var24 = 0.56
				num5 = 0.4
			end

			local var25 = var22.Z + num5 / 2 + 0.05
			for i1 = 0, 5 do
				local str1 = "Shroud"
				local var26 = CFrame.new(0, var22.Y, var25) * CFrame.Angles(0, 0, i1 * 3.1415926535897931 / 3) * CFrame.new(0, var24, 0) * CFrame.Angles(-0.17453292519943295, 0, 0)
				local var27 = var1(2 * var24 * 0.57735026918962573 + 0.02, 0.06, num5)
				arg1:add(str1, var26, var27, if i1 % 2 == 0 then var6 else var4("#CFF3FF"), var2.Glass, { Transparency = 0.1, Reflectance = 0.25 })
			end

			local str2 = "ShroudEdge"
			local var28 = var1(0, var22.Y, var22.Z + 0.06)
			local var29 = var24 - 0.02
			local num6 = 0.03
			local var30 = var7
			local var31 = var2.Neon
			local num7 = 12
			local var32 = nil
			local tbl4 = { Transparency = 0.35 }
			for k5, v5 in ipairs(arg1:ring(str2, var28, var29, num6, var30, var31, num7, var32, tbl4)) do
				table.insert(tbl1, v5)
			end
		end

		local var33
		if arg1.weapon == "SteamBlaster" then
			var33 = 0.78
		else
			var33 = if arg1.weapon == "Flamethrower" then 0.8 else var5.muzzle / 2 + 0.34
		end

		local var34 = var1(0, var22.Y, var22.Z + 0.42)
		local tbl5 = {}
		for i2 = 0, 2 do
			local var35 = i2 * 2 * 3.1415926535897931 / 3 + 0.5
			local var36 = var34 + var1(math.cos(var35) * var33, math.sin(var35) * var33, 0)
			local str3 = "Shard"
			local var37 = CFrame.new(var36) * CFrame.Angles(var3(i2 * 30), 0.78539816339744828, 0.3490658503988659)
			local var38 = Vector3.new(0.1, 0.22, 0.1)
			local var39 = arg1:add(str3, var37, var38, if i2 == 1 then var7 else var6, var2.Glass, { Transparency = 0.08, Reflectance = 0.3 })
			table.insert(tbl5, var39)
			table.insert(tbl5, (arg1:add("ShardCore", CFrame.new(var36), Vector3.new(0.045, 0.1, 0.045), var7, var2.Neon, { Transparency = 0.2 })))
		end

		rotate(tbl5, var34, Vector3.new(0, 0, 1), 40, 0.03, 70)
	end,
	retrorocket = function(arg1)
		local var3 = arg1.pal
		local var5 = var3.accent
		fins(arg1, var5, var2.SmoothPlastic)
		local var6 = arg1.A
		local var7 = var3.metal
		local var8 = var3.housing
		if arg1.weapon == "Hairdryer" then
			arg1:hide("IntakeRing", "IntakeMesh", "IntakeHub")
			arg1:ball("TailDome", var1(0, var6.axisY, 0.86), 0.96, var8, var2.SmoothPlastic)
			arg1:ball("TailTip", var1(0, var6.axisY, 1.3), 0.26, var5, var2.SmoothPlastic)
			arg1:tube("ChromeRing", 0, var6.axisY, -0.1, 0, 1.1, var7, var2.Metal, { Reflectance = 0.2 })
			arg1:tube("NoseCone", 0, var6.axisY, -1.42, -1.32, 0.72, var5, var2.SmoothPlastic)
		else
			if arg1.weapon == "HeatGun" then
				arg1:ball("TailDome", var1(0, var6.axisY - 0.04, 1.02), 0.62, var8, var2.SmoothPlastic)
				arg1:add("Stripe", CFrame.new(0, 1.475, -0.1), Vector3.new(0.22, 0.02, 1.4), var5)
				arg1:tube("ChromeRing", 0, var6.axisY, -1.33, -1.24, 0.9, var7, var2.Metal, { Reflectance = 0.2 })
				arg1:tube("NoseCone", 0, var6.axisY, -2.1, -2, 0.4, var5, var2.SmoothPlastic)
			else
				if arg1.weapon == "SteamBlaster" then
					arg1:tube("ChromeRing", 0, 1.3, -0.64, -0.56, 1.18, var7, var2.Metal, { Reflectance = 0.2 })
					arg1:tube("RedBand", 0, 1.3, 0.2, 0.36, 1.15, var5, var2.SmoothPlastic)
					arg1:ball("NoseTip", Vector3.new(0, 1.3, -0.98), 0.22, var5, var2.SmoothPlastic)
				else
					arg1:ball("TailDome", Vector3.new(0, 1.05, 0.9), 0.58, var8, var2.SmoothPlastic)
					local var9 = Vector3.new(0.14, 0.02, 1.6)
					arg1:add("Stripe", CFrame.new(0, 1.6, -0.45) * CFrame.new(0, 0.012, 0), var9, var5)
					for k1, v1 in ipairs(var6.bands) do
						arg1:tube("ChromeRing", 0, var6.axisY, v1 - 0.04, v1 + 0.04, 0.5, var7, var2.Metal, { Reflectance = 0.2 })
					end
				end
			end
		end

		local var10 = var6.porthole
		disc(arg1, "PortRim", var10.at, var10.normal, var10.size, 0.04, var7, var2.Metal, { Reflectance = 0.2 })
		pulse({ (disc(arg1, "PortGlass", var10.at + var10.normal.Unit * 0.02, var10.normal, var10.size * 0.72, 0.04, var4("#FFD28A"), var2.Neon, { Transparency = 0.25 })) }, var4("#FFD28A"), var4("#FFB05A"), 2.6, 0.2)
		local var11 = ({ Hairdryer = 1.46, HeatGun = 1.36, Flamethrower = 1.22 })[arg1.weapon]
		local var12 = var6.fins
		local var13 = var12.y
		var11 = var11 or var6.back + 0.08
		local var14 = anchor(arg1, "Exhaust", var1(0, var13 or var6.axisY, var11), Vector3.new(0, -0.25, 1))
		local str1 = "#FF5A1A"
		local tbl1 = {
			texture = "rbxasset://textures/particles/fire_main.dds",
			color = ColorSequence.new(var4("#FFC061"), var4(str1)),
			rate = 20,
			light = 1,
			locked = true,
		}

		tbl1.life = NumberRange.new(0.18, 0.26)
		tbl1.speed = NumberRange.new(0.8, 1.1)
		local num1 = 1
		local num2 = 0.06
		tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.34), NumberSequenceKeypoint.new(num1, num2) })
		tbl1.spread = Vector2.new(6, 6)
		emitter(arg1, var14, tbl1, "always")
		num2 = "#FFD27A"
		local var15 = ColorSequenceKeypoint.new(0, var4(num2))
		local str2 = "#FF8A2A"
		str1 = ColorSequenceKeypoint.new(0.4, var4(str2))
		local str3 = "#D23A12"
		num2 = 1
		tbl1 = {
			texture = "rbxasset://textures/particles/fire_main.dds",
			color = ColorSequence.new({ var15, str1, ColorSequenceKeypoint.new(num2, var4(str3)) }),
			rate = 55,
			light = 1,
		}

		tbl1.life = NumberRange.new(0.22, 0.34)
		tbl1.speed = NumberRange.new(2.2, 2.8)
		num1 = 1
		num2 = 0.14
		tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(num1, num2) })
		tbl1.spread = Vector2.new(8, 8)
		emitter(arg1, var14, tbl1, "active")
		var15 = "#9C948C"
		tbl1 = {
			texture = "rbxasset://textures/particles/smoke_main.dds",
			color = ColorSequence.new(var4(var15)),
			rate = 6,
			accel = Vector3.new(0, 0.6, 0),
			drag = 2,
			light = 0,
			influence = 1,
		}

		tbl1.life = NumberRange.new(0.6, 1)
		tbl1.speed = NumberRange.new(1.2, 1.8)
		num1 = 1
		num2 = 1
		tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(num1, num2) })
		num1 = 1
		num2 = 1
		tbl1.alpha = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(num1, num2) })
		emitter(arg1, var14, tbl1, "active")
		var15 = var12.y
		var13 = CFrame.new(0, var15 or var6.axisY, var11 + 0.02)
		tbl1 = var13 * CFrame.Angles(1.5707963267948966, 0, 0)
		local var16 = arg1:wedge("ExhaustStatic", tbl1, Vector3.new(0.08, 0.14, 0.1), var4("#FF9A3A"), var2.Neon)
		var16:SetAttribute("FxStatic", true)
		var16:SetAttribute("FxStaticTransparency", var16.Transparency)
		var16.Transparency = 1
	end,
	dragonforge = function(arg1)
		local var3 = arg1.pal
		local var5 = arg1.A
		local var6 = var5.nozzleParts
		arg1:hide(table.unpack(var6))
		local var7 = var3.housing
		local var8 = var3.accent
		local tbl1 = {}
		local var9 = if var5.muzzle < 0.8 then 0.86 else math.min(var5.muzzle, 1.05)
		if arg1.weapon == "Hairdryer" then
			arg1:hide("Nozzle")
		end

		dragonHead(arg1, var5.nozzle, var9, var7, var8, tbl1)
		pulse(tbl1, var4("#FFB23A"), var4("#FF5A1A"), 2.2)
		local var10 = var5.nozzle
		for k1, v1 in ipairs(arg1.folder:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			if v1.Name ~= "Scale" then
				continue
			end

			local var11 = arg1.handle.CFrame:PointToObjectSpace(v1.Position)
			if var11.Z >= var10.Z + var9 * 1.27 then
				continue
			end

			if math.abs(var11.X) >= var9 * 0.5 then
				continue
			end

			if math.abs(var11.Y - var10.Y) >= var9 * 0.5 then
				continue
			end

			v1:Destroy()
		end

		arg1:add("Throat", CFrame.new(var10 + var1(0, -var9 * 0.02, var9 * 0.62)), var1(var9 * 0.62, var9 * 0.44, var9 * 0.5), var4("#4A1510"), var2.SmoothPlastic)
		local var12 = var9 * 0.4
		pulse({ (arg1:ball("ThroatGlow", var10 + var1(0, 0, var12), var9 * 0.24, var4("#FF6A1A"), var2.Neon)) }, var4("#FF8A2A"), var4("#FF3A10"), 1.6)
		var6 = var5.spine
		if var6 then
			local var13
			if var5.spineX then
				var13 = { -var5.spineX, var5.spineX }
			else
				var13 = { 0 }
			end

			for k2, v2 in ipairs(var13) do
				for i1 = 0, 4 do
					local var14 = math.sin(i1 / 4 * 3.1415926535897931) * 0.06 + 0.13
					arg1:wedge("Spine", CFrame.new(var6[1]:Lerp(var6[2], i1 / 4) + var1(v2, 0, 0) + var1(0, var14 / 2, 0)), var1(0.05, var14, 0.2), var8, var2.Metal)
				end
			end

			if var5.spine2 then
				for i2 = 0, 2 do
					arg1:wedge("Spine", CFrame.new(var5.spine2[1]:Lerp(var5.spine2[2], i2 / 2) + Vector3.new(0, 0.07, 0)), Vector3.new(0.05, 0.14, 0.16), var8, var2.Metal)
				end
			end
		end

		if arg1.weapon == "SteamBlaster" then
			local num1 = 0.95
			var13 = var5.tank
			for k3, v3 in ipairs({ -0.62, num1 }) do
				arg1:tube("EggBand", 0, var13.y, v3 - 0.035, v3 + 0.035, 0.9, var8, var2.Metal)
			end

			local num2 = 1
			for k4, v4 in ipairs({ -1, num2 }) do
				arg1:wedge("Crest", CFrame.new(v4 * 0.2, var13.y + var13.r + 0.1, 0.9) * CFrame.Angles(0, 0, v4 * 0.20943951023931956), Vector3.new(0.05, 0.22, 0.4), var8, var2.Metal)
			end
		end

		local num3 = 1
		for k5, v5 in ipairs({ -1, num3 }) do
			local var15 = v5 * ((if var5.round then var5.hullR else var5.sideX) + 0.03)
			local var16 = (var5.sideY[1] + var5.sideY[2]) / 2 + 0.02
			local var17 = var5.sideSpan[2] - 0.3
			arg1:wedge("Wing", CFrame.new(var15, var16, var17), Vector3.new(0.03, 0.4, 0.62), var4("#3A2320"), var2.SmoothPlastic)
			arg1:rod("WingEdge", var1(var15 + v5 * 0.02, var16 + 0.2, var17 + 0.31), var1(var15 + v5 * 0.02, var16 - 0.18, var17 - 0.3), 0.05, var8, var2.Metal)
			for i3 = 0, 1 do
				arg1:wedge("WingClaw", CFrame.new(var15 + v5 * 0.02, var16 - 0.21 - i3 * 0.02, var17 - 0.34 + i3 * 0.1) * CFrame.Angles(3.1415926535897931, 0, 0), Vector3.new(0.03, 0.08, 0.1), var8, var2.Metal)
			end
		end

		local num4 = 1
		for k6, v6 in ipairs({ -1, num4 }) do
			local str1 = "#4A4442"
			local var18 = anchor(arg1, "Nostril", var10 + var1(v6 * var9 * 0.14, var9 * 0.5, var9 * 0.12), (var1(v6 * 0.3, 1, 0.5)))
			local tbl2 = {
				texture = "rbxasset://textures/particles/smoke_main.dds",
				color = ColorSequence.new(var4("#8A7F78"), var4(str1)),
				rate = 5,
				accel = Vector3.new(0, 0.3, 0.2),
				drag = 1,
				light = 0,
				influence = 1,
			}

			tbl2.life = NumberRange.new(0.9, 1.4)
			tbl2.speed = NumberRange.new(0.3, 0.5)
			local num5 = 1
			local num6 = 0.5
			tbl2.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.14), NumberSequenceKeypoint.new(num5, num6) })
			num5 = 1
			num6 = 1
			tbl2.alpha = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(num5, num6) })
			tbl2.rot = NumberRange.new(-40, 40)
			emitter(arg1, var18, tbl2, "always")
		end

		var13 = anchor(arg1, "Embers", var5.nozzle + var1(0, var9 * 0.3, var9 * 0.3), Vector3.new(0, 1, 0.4))
		local str2 = "#FF4A12"
		local tbl3 = {
			color = ColorSequence.new(var4("#FFD27A"), var4(str2)),
			rate = 22,
			accel = Vector3.new(0, 1.2, 0.6),
			drag = 1.5,
			light = 1,
		}

		tbl3.life = NumberRange.new(0.5, 0.9)
		tbl3.speed = NumberRange.new(1.4, 2.2)
		local num7 = 1
		local num8 = 0.04
		tbl3.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(num7, num8) })
		tbl3.spread = Vector2.new(30, 30)
		emitter(arg1, var13, tbl3, "active")
		str2 = "#E0431A"
		tbl3 = {
			texture = "rbxasset://textures/particles/fire_main.dds",
			color = ColorSequence.new(var4("#FFB347"), var4(str2)),
			rate = 16,
			light = 1,
			locked = true,
		}

		tbl3.life = NumberRange.new(0.18, 0.3)
		tbl3.speed = NumberRange.new(0.6, 1)
		num7 = 1
		num8 = 0.06
		tbl3.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.26), NumberSequenceKeypoint.new(num7, num8) })
		tbl3.spread = Vector2.new(20, 20)
		emitter(arg1, var13, tbl3, "active")
	end,
	celestial = function(arg1)
		local var5 = arg1.pal
		local var6 = var5.accent
		local tbl1 = {}
		local var7 = arg1.A
		local var8 = var5.housing2
		local function starOn(arg1, arg2, arg3)
			local var1 = ipairs
			local var3 = arg1
			local str1 = "Star"
			local var4 = arg1 + arg2.Unit * 0.015
			local var5 = CFrame.lookAt(var4, var4 + arg2, if 0.9 < math.abs(arg2.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
			local var7 = var5 * CFrame.Angles(0, 1.5707963267948966, 0)
			var5 = arg3
			var4 = var6
			local var8 = var2.Neon
			for k1, v1 in var1(var3:star(str1, var7, var5, var4, var8)) do
				table.insert(tbl1, v1)
			end
		end

		if var7.round then
			local num1 = 0.3
			for k1, v1 in ipairs({ -0.42, num1 }) do
				arg1:tube("NightBand", 0, var7.axisY, v1 - 0.13, v1 + 0.13, var7.hullR * 2 + 0.04, var8, var2.SmoothPlastic)
				for i1 = 0, 5 do
					local var9 = var3(i1 * 60 + 20)
					local var10 = var1(math.cos(var9), math.sin(var9), 0)
					starOn(var1(0, var7.axisY, v1) + var10 * (var7.hullR + 0.02), var10, 0.09)
				end
			end
		else
			if arg1.weapon == "SteamBlaster" then
				local num2 = 0.95
				for k2, v2 in ipairs({ -0.62, num2 }) do
					arg1:tube("NightBand", 0, 1.3, v2 - 0.1, v2 + 0.1, 1, var8, var2.SmoothPlastic)
				end

				local num3 = 1
				for k3, v3 in ipairs({ -1, num3 }) do
					local var11 = var1(v3, 0, 0)
					local var12 = var1(v3 * 0.5, 0.66, -0.15) + var11.Unit * 0.015
					local var13 = CFrame.lookAt(var12, var12 + var11, if 0.9 < math.abs(var11.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
					arg1:add("NightPanel", var13 * CFrame.Angles(0, 0, 0), Vector3.new(1.7, 0.38, 0.03), var8, nil, nil)
					starOn(var1(v3 * 0.53, 0.58, -0.8), var1(v3, 0, 0), 0.1)
					starOn(var1(v3 * 0.53, 0.73, -0.38000000000000006), var1(v3, 0, 0), 0.07)
					starOn(var1(v3 * 0.53, 0.58, 0.039999999999999925), var1(v3, 0, 0), 0.1)
					starOn(var1(v3 * 0.53, 0.73, 0.45999999999999996), var1(v3, 0, 0), 0.07)
				end
			else
				local num4 = 1
				for k4, v4 in ipairs({ -1, num4 }) do
					local var14 = var7.sideY[1] + 0.12
					local var15 = var1(v4, 0, 0)
					local var16 = var7.sideSpan[2] - var7.sideSpan[1]
					local var17 = var1(v4 * (var7.sideX + 0.005), var14, (var7.sideSpan[1] + var7.sideSpan[2]) / 2) + var15.Unit * 0.015
					local var18 = CFrame.lookAt(var17, var17 + var15, if 0.9 < math.abs(var15.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
					arg1:add("NightPanel", var18 * CFrame.Angles(0, 0, 0), var1(var16, 0.22, 0.03), var8, nil, nil)
					for i2 = 0, 3 do
						var18 = starOn
						local var19 = v4 * (var7.sideX + 0.035)
						var17 = var1(var19, var14 + (if i2 % 2 == 0 then 0.03 else -0.04), var7.sideSpan[1] + 0.2 + i2 * (var16 - 0.4) / 3)
						var19 = var1(v4, 0, 0)
						var18(var17, var19, if i2 % 2 == 0 then 0.1 else 0.07)
					end
				end

				arg1:add("NightSpine", CFrame.new(0, var7.topY + 0.01, (var7.sideSpan[1] + var7.sideSpan[2]) / 2 + 0.2), Vector3.new(0.16, 0.02, 0.6), var8)
			end
		end

		pulse(tbl1, var6, var4("#FFF6D0"), 2.8, 0.3)
		local var22 = nil
		local var23 = nil
		if arg1.weapon == "SteamBlaster" then
			var22 = Vector3.new(0, 1.3, 0.15)
			var23 = 0.72
		else
			if arg1.weapon == "Flamethrower" then
				var22 = var1(0, var7.axisY, -2.1)
				var23 = 0.42
			else
				if arg1.weapon == "HeatGun" then
					var22 = var1(0, var7.axisY, -1.55)
					var23 = 0.5
				else
					var22 = var1(0, var7.axisY, -1.02)
					var23 = 0.5
				end
			end
		end

		local num5 = 0.13962634015954636
		local num6 = 0
		local num7 = 0
		rotate(arg1:ring("HaloRing", var22, var23, 0.05, var6, var2.Metal, 20, CFrame.Angles(num5, num6, num7)), var22, Vector3.new(0, 0, 1), 18)
		local num8 = 0
		local var24 = var1(num8, if arg1.weapon == "SteamBlaster" then 1.3 else var7.axisY, var7.back + 0.12)
		arg1:ball("Orb", var24, 0.26, var4("#FBF8F0"), var2.SmoothPlastic, { Reflectance = 0.15 })
		num7 = 1.5707963267948966
		local num9 = 0
		local num10 = 0
		arg1:ring("OrbCradle", var24, 0.15, 0.03, var6, var2.Metal, 10, CFrame.Angles(num7, num9, num10))
		num8 = var7.nozzle
		local var25 = (if arg1.weapon == "SteamBlaster" then 0.62 else var7.muzzle / 2) + 0.06
		for i3 = 0, 3 do
			arg1:wedge("Ray", CFrame.new(num8 + Vector3.new(0, 0, 0.08)) * CFrame.Angles(0, 0, (var3(i3 * 90 + 45))) * CFrame.new(0, var25 + 0.08, 0) * CFrame.Angles(-1.5707963267948966, 0, 0), Vector3.new(0.05, 0.2, 0.16), var6, var2.Metal)
		end
	end,
	deepcurrent = function(arg1)
		local var3 = arg1.pal
		local var5 = var3.metal
		local tbl1 = {}
		local var6 = var4("#3FD6C8")
		local var7 = arg1.A
		local function porthole(arg1, arg2, arg3)
			disc(arg1, "PortBezel", arg1, arg2, arg3, 0.05, var5, var2.Metal)
			local var1 = arg1
			local str1 = "PortGlass"
			local var3 = arg1 + arg2.Unit * 0.03
			local var4 = arg2
			local var7 = arg3 * 0.7
			local num1 = 0.04
			local var8 = var6
			local var9 = var2.Glass
			local tbl2 = { Transparency = 0.2, Reflectance = 0.15 }
			table.insert(tbl1, disc(var1, str1, var3, var4, var7, num1, var8, var9, tbl2))
			local var10 = arg1 + arg2.Unit * 0.05
			local var11 = CFrame.lookAt(var10, var10 + arg2, if 0.9 < math.abs(arg2.Unit.Y) then Vector3.new(0, 0, -1) else Vector3.new(0, 1, 0))
			for i1 = 0, 5 do
				str1 = i1 * 3.1415926535897931 / 3
				arg1:ball("Bolt", (var11 * CFrame.new(math.cos(str1) * arg3 * 0.42, math.sin(str1) * arg3 * 0.42, 0)).Position, 0.045, var5, var2.Metal)
			end
		end

		if var7.round then
			arg1:hide("IntakeRing", "IntakeMesh", "IntakeHub")
			arg1:ball("PressureDome", var1(0, var7.axisY, 0.82), 1, var3.housing2, var2.SmoothPlastic)
			porthole(var1(0, var7.axisY, 1.3), Vector3.new(0, 0, 1), 0.34)
			local num1 = 0.2
			for k1, v1 in ipairs({ -0.5, num1 }) do
				arg1:tube("BrassBand", 0, var7.axisY, v1 - 0.05, v1 + 0.05, var7.hullR * 2 + 0.07, var5, var2.Metal)
				local var8 = var7
				for k2, v2 in ipairs((around(var8, v1, var7.hullR + 0.045, 8, 22.5))) do
					arg1:ball("Bolt", v2.point, 0.045, var5, var2.Metal)
				end
			end

			porthole(var1(var7.hullR + 0.005, var7.axisY + 0.05, -0.15), Vector3.new(1, 0, 0), 0.3)
			porthole(var1(-var7.hullR - 0.005, var7.axisY + 0.05, -0.15), Vector3.new(-1, 0, 0), 0.3)
		else
			if arg1.weapon == "SteamBlaster" then
				local num2 = 0.95
				local var9 = var7.tank
				for k3, v3 in ipairs({ -0.62, num2 }) do
					arg1:tube("BrassBand", 0, var9.y, v3 - 0.05, v3 + 0.05, 0.92, var5, var2.Metal)
				end

				porthole(Vector3.new(0.57, 1.36, 0.62), Vector3.new(1, 0.15, 0), 0.3)
				porthole(Vector3.new(0.515, 0.66, 0.36), Vector3.new(1, 0, 0), 0.3)
				porthole(Vector3.new(-0.515, 0.66, -0.5), Vector3.new(-1, 0, 0), 0.3)
				arg1:ball("PressureCap", Vector3.new(0, 1.3, 1.26), 0.4, var5, var2.Metal)
			else
				local num3 = 1
				for k4, v4 in ipairs({ -1, num3 }) do
					local var10 = v4 * (var7.sideX + 0.13)
					local var11 = var7.sideY[1] + 0.14
					local var12 = var7.sideSpan[1] + 0.25
					local var13 = var7.sideSpan[2] - 0.08
					arg1:tube("SideTank", var10, var11, var12, var13, 0.24, var3.housing2, var2.SmoothPlastic)
					arg1:ball("TankEnd", var1(var10, var11, var12), 0.24, var3.housing2, var2.SmoothPlastic)
					arg1:ball("TankEnd", var1(var10, var11, var13), 0.24, var5, var2.Metal)
					local var14 = var13 - 0.3
					for k5, v5 in ipairs({ var12 + 0.25, var14 }) do
						arg1:tube("Strap", var10, var11, v5 - 0.03, v5 + 0.03, 0.28, var5, var2.Metal)
					end
				end

				porthole(var7.porthole.at, var7.porthole.normal, var7.porthole.size)
				porthole(var7.porthole.at * Vector3.new(-1, 1, 1) + Vector3.new(0, 0, 0.25), var7.porthole.normal * Vector3.new(-1, 1, 1), var7.porthole.size * 0.85)
			end
		end

		local var15 = var7.nozzleParts
		arg1:hide(table.unpack(var15))
		local var16 = var7.nozzle
		if arg1.weapon == "SteamBlaster" then
			arg1:add("BellFrame", CFrame.new(0, 1.1, -1.42), Vector3.new(1.34, 0.84, 0.08), var5, var2.Metal)
			arg1:add("BellMouth", CFrame.new(0, 1.1, -1.44), Vector3.new(1.08, 0.58, 0.1), var4("#0A1E26"), var2.SmoothPlastic)
		else
			local var17 = math.max(var7.muzzle / 2, 0.3)
			local str1 = "BellRim"
			local var18 = var1(0, var16.Y, var16.Z + 0.05)
			local var19 = var17
			local num4 = 0.07
			local var20 = var5
			local var21 = var2.Metal
			local num5 = 18
			local var22 = nil
			for k6, v6 in ipairs(arg1:ring(str1, var18, var19, num4, var20, var21, num5, var22)) do
				v6.Name = "BellRim" .. k6
			end

			arg1:tube("BellThroat", 0, var16.Y, var16.Z + 0.08, var16.Z + 0.34, var17 * 1.5, var5, var2.Metal)
		end

		pulse(tbl1, var6, var4("#7FF2E6"), 3.2, 0.25)
		local var25 = tbl1[1]
		if var25 then
			local var26 = var25:GetAttribute("SkinOffset")
			local str3 = "#CFFBFF"
			local var27 = anchor(arg1, "Bubbles", var26.Position, Vector3.new(0, 1, 0))
			local tbl2 = {
				color = ColorSequence.new(var4(str3)),
				rate = 5,
				accel = Vector3.new(0, 0.7, 0),
				light = 0.3,
				influence = 0.5,
			}

			tbl2.life = NumberRange.new(1, 1.6)
			tbl2.speed = NumberRange.new(0.3, 0.5)
			local num6 = 1
			local num7 = 0.16
			tbl2.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.08), NumberSequenceKeypoint.new(num6, num7) })
			tbl2.spread = Vector2.new(15, 15)
			emitter(arg1, var27, tbl2, "always")
			var15 = arg1:ball("BubbleStatic", var26.Position + Vector3.new(0, 0.22, 0), 0.06, var4("#CFFBFF"), var2.Glass, { Transparency = 0.35 })
			var15:SetAttribute("FxStatic", true)
			var15:SetAttribute("FxStaticTransparency", var15.Transparency)
			var15.Transparency = 1
			var15 = arg1:ball("BubbleStatic", var26.Position + Vector3.new(0.05, 0.36, 0), 0.04, var4("#CFFBFF"), var2.Glass, { Transparency = 0.35 })
			var15:SetAttribute("FxStatic", true)
			var15:SetAttribute("FxStaticTransparency", var15.Transparency)
			var15.Transparency = 1
		end
	end,
	earthwarden = function(arg1)
		local var5 = arg1.pal
		local var6 = var4("#58D39A")
		pulse(seams(arg1, var6, var2.Neon, 0.026, { Transparency = 0.15 }), var6, var4("#2FA774"), 4, 0.3)
		local num1 = 1
		local var7 = arg1.A
		local var8 = var5.housing
		local var9 = var5.housing2
		local var10 = var5.metal
		local var11 = arg1.rng
		for k1, v1 in ipairs({ -1, num1 }) do
			for i1 = 0, 2 do
				local var12 = var7.sideSpan[1] + 0.2 + i1 * (var7.sideSpan[2] - var7.sideSpan[1] - 0.4) / 2
				local var13 = (var7.sideY[1] + var7.sideY[2]) / 2 + var11:NextNumber(-0.05, 0.05)
				local num2 = -0.2
				local num3 = 0.2
				local var14 = CFrame.new(v1 * ((if var7.round then var7.hullR else var7.sideX) + 0.04), var13, var12) * CFrame.Angles(var11:NextNumber(-0.15, 0.15), 0, var11:NextNumber(num2, num3))
				local num4 = 0.28
				num2 = 0.38
				local str1 = "StoneSlab"
				local var15 = var1(0.08, var11:NextNumber(0.24, 0.32), var11:NextNumber(num4, num2))
				arg1:add(str1, var14, var15, if i1 % 2 == 0 then var8 else var9, var2.Slate)
			end
		end

		if var7.spine then
			for i2 = 0, 3 do
				arg1:add("Ridge", CFrame.new(var7.spine[1]:Lerp(var7.spine[2], i2 / 3) + Vector3.new(0, 0.05, 0)) * CFrame.Angles(0, var11:NextNumber(-0.3, 0.3), 0.78539816339744828), Vector3.new(0.14, 0.14, 0.2), var9, var2.Slate)
			end
		else
			if arg1.weapon == "SteamBlaster" then
				for i3 = 0, 2 do
					arg1:add("Ridge", CFrame.new(0, 1.84, i3 * 0.7 + -0.7) * CFrame.Angles(0, 0, 0.78539816339744828), Vector3.new(0.16, 0.16, 0.26), var9, var2.Slate)
				end
			end
		end

		local var16 = var7.nozzleParts
		arg1:hide(table.unpack(var16))
		local var17 = var7.nozzle
		local var18 = (if arg1.weapon == "SteamBlaster" then 0.64 else math.max(var7.muzzle / 2, 0.28)) + 0.06
		for i4 = 0, 4 do
			local num5 = -0.2
			local num6 = 0.2
			local var19 = CFrame.new(0, var17.Y, var17.Z + 0.2) * CFrame.Angles(0, 0, (var3(i4 * 72 + 90))) * CFrame.new(0, var18, 0) * CFrame.Angles(-0.31415926535897931, 0, var11:NextNumber(num5, num6))
			local str2 = "Crown"
			local var20 = Vector3.new(0.2, 0.16, 0.36)
			arg1:add(str2, var19, var20, if i4 % 2 == 0 then var8 else var9, var2.Slate)
		end

		local str3 = "CrownBand"
		local var21 = var1(0, var17.Y, var17.Z + 0.38)
		local var22 = var18 - 0.02
		local num7 = 0.06
		local var23 = var10
		local var24 = var2.Metal
		local num8 = 14
		local var25 = nil
		for k2, v2 in ipairs(arg1:ring(str3, var21, var22, num7, var23, var24, num8, var25)) do
			v2.Name = "CrownBand"
		end

		local var26 = var7.orbit
		local tbl1 = {}
		for i5 = 0, 3 do
			var22 = i5 * 3.1415926535897931 / 2 + 0.4
			var23 = i5 % 3 * 0.03 + 0.1
			num8 = tbl1
			local str4 = "Fragment"
			local var27 = CFrame.new(var26.center + var1(math.cos(var22) * var26.radius, math.sin(var22) * var26.radius * 0.8, i5 % 2 * 0.3 - 0.15)) * CFrame.Angles(var11:NextNumber(0, 6), var11:NextNumber(0, 6), 0)
			local var28 = var1(var23, var23 * 0.8, var23 * 1.1)
			local var29 = if i5 % 2 == 0 then var8 else var4("#8A8174")
			local var30 = var2.Rock
			table.insert(num8, arg1:add(str4, var27, var28, var29, var30))
		end

		rotate(tbl1, var26.center, Vector3.new(0, 0, 1), 28, 0.04, 40)
		num8 = "#B7AE9D"
		var22 = anchor(arg1, "Dust", var17 + var1(0, var18 + 0.08, 0.3), Vector3.new(0, 1, 0.3))
		num7 = {
			texture = "rbxasset://textures/particles/smoke_main.dds",
			color = ColorSequence.new(var4(num8)),
			rate = 8,
			light = 0,
			influence = 1,
		}

		num7.life = NumberRange.new(0.4, 0.6)
		num7.speed = NumberRange.new(0.3, 0.6)
		local num9 = 1
		local num10 = 0.5
		num7.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.18), NumberSequenceKeypoint.new(num9, num10) })
		num9 = 1
		num10 = 1
		num7.alpha = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(num9, num10) })
		emitter(arg1, var22, num7, "active")
	end,
	inferno = function(arg1)
		local var5 = var4("#FF6A1A")
		local var6 = seams(arg1, var5, var2.Neon, 0.03)
		pulse(var6, var5, var4("#FFB347"), 1.8)
		local var7 = arg1.A
		local var8 = arg1.pal
		if var7.spine then
			for i1 = 0, 4 do
				local var9 = var7.spine[1]:Lerp(var7.spine[2], i1 / 4)
				local str1 = "ForgeFin"
				local var10 = CFrame.new(var9 + Vector3.new(0, 0.07, 0))
				arg1:add(str1, var10, var1(if var7.round then 0.42 else 0.5, 0.14, 0.04), var8.housing2, var2.Metal)
				str1 = "ForgeFinGlow"
				var10 = CFrame.new(var9 + Vector3.new(0, 0.145, 0))
				arg1:add(str1, var10, var1(if var7.round then 0.38 else 0.46, 0.015, 0.045), var5, var2.Neon)
			end
		else
			if arg1.weapon == "SteamBlaster" then
				arg1:tube("ForgeRing", 0, 1.3, 0.7, 0.74, 1.16, var8.housing2, var2.Metal)
				arg1:tube("ForgeRing", 0, 1.3, 0.79999999999999993, 0.84, 1.16, var8.housing2, var2.Metal)
				arg1:tube("ForgeRing", 0, 1.3, 0.89999999999999991, 0.94, 1.16, var8.housing2, var2.Metal)
				arg1:tube("ForgeRing", 0, 1.3, 1, 1.04, 1.16, var8.housing2, var2.Metal)
				arg1:tube("MoltenBand", 0, 1.3, -0.65, -0.6, 1.14, var5, var2.Neon)
			end
		end

		local var11 = var7.nozzleParts
		arg1:hide(table.unpack(var11))
		local var12 = var7.nozzle
		local var13
		if arg1.weapon == "SteamBlaster" then
			arg1:add("ForgeFrame", CFrame.new(0, 1.1, -1.42), Vector3.new(1.36, 0.86, 0.1), var8.housing2, var2.Metal)
			arg1:add("ForgeMouth", CFrame.new(0, 1.1, -1.445), Vector3.new(1.1, 0.6, 0.08), var4("#080607"), var2.SmoothPlastic)
			var13 = 0
			for k1, v1 in ipairs({ -0.2, var13, 0.2 }) do
				arg1:add("MoltenSlot", CFrame.new(0, 1.1 + v1, -1.49), Vector3.new(0.96, 0.04, 0.02), var5, var2.Neon)
			end
		else
			local var14 = math.max(var7.muzzle / 2, 0.28) + 0.04
			for i2 = 0, 3 do
				arg1:add("ForgePlate", CFrame.new(0, var12.Y, var12.Z + 0.22) * CFrame.Angles(0, 0, (var3(i2 * 90 + 45))) * CFrame.new(0, var14, 0) * CFrame.Angles(-0.3490658503988659, 0, 0), var1(var14 * 1.3, 0.08, 0.44), var8.housing2, var2.Metal)
			end

			local str2 = "MoltenRing"
			local var15 = var1(0, var12.Y, var12.Z + 0.06)
			local var16 = var14 * 0.72
			local num1 = 0.04
			local var17 = var5
			local var18 = var2.Neon
			local num2 = 14
			local var19 = nil
			for k2, v2 in ipairs(arg1:ring(str2, var15, var16, num1, var17, var18, num2, var19)) do
				table.insert(var6, v2)
			end

			local str3 = "ForgeThroat"
			local num3 = 0
			arg1:tube(str3, num3, var12.Y, var12.Z + 0.1, var12.Z + 0.42, var14 * 1.25, var4("#120E10"), var2.Metal)
		end

		for k3, v3 in ipairs(var7.flames) do
			local var20 = anchor(arg1, "Flame" .. k3, v3[1], v3[2])
			local str4 = "#FFE7A6"
			local var21 = ColorSequenceKeypoint.new(0, var4(str4))
			local str5 = "#FF8A2A"
			local var22 = ColorSequenceKeypoint.new(0.5, var4(str5))
			local str6 = "#B8330F"
			str4 = 1
			local tbl1 = {
				texture = "rbxasset://textures/particles/fire_main.dds",
				color = ColorSequence.new({ var21, var22, ColorSequenceKeypoint.new(str4, var4(str6)) }),
				rate = 16,
				light = 1,
				locked = true,
			}

			tbl1.life = NumberRange.new(0.25, 0.4)
			tbl1.speed = NumberRange.new(0.4, 0.8)
			local num4 = 1
			str4 = 0.05
			tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.26), NumberSequenceKeypoint.new(num4, str4) })
			tbl1.spread = Vector2.new(10, 10)
			emitter(arg1, var20, tbl1, "always")
			var22 = "#FF4A12"
			tbl1 = {
				color = ColorSequence.new(var4("#FFC061"), var4(var22)),
				rate = 5,
				accel = Vector3.new(0, 1, 0),
				light = 1,
			}

			tbl1.life = NumberRange.new(0.5, 0.8)
			tbl1.speed = NumberRange.new(0.6, 1.1)
			num4 = 1
			str4 = 0.02
			tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.12), NumberSequenceKeypoint.new(num4, str4) })
			emitter(arg1, var20, tbl1, "always")
			local var23 = arg1:wedge("FlameStatic", CFrame.new(v3[1] + v3[2].Unit * 0.09) * CFrame.Angles(-1.5707963267948966, 0, 0), Vector3.new(0.08, 0.1, 0.18), var4("#FF8A2A"), var2.Neon)
			var23:SetAttribute("FxStatic", true)
			var23:SetAttribute("FxStaticTransparency", var23.Transparency)
			var23.Transparency = 1
		end

		arg1:add("Vein", CFrame.new(0, var7.axisY, var7.back + 0.02) * CFrame.Angles(0, 0, 0.52359877559829882), Vector3.new(0.3, 0.025, 0.02), var5, var2.Neon)
	end,
	skyweaver = function(arg1)
		local var5 = arg1.pal
		local num1 = 1
		local var6 = arg1.A
		local var7 = var5.housing
		local var8 = var5.housing2
		local var9 = var5.accent
		for k1, v1 in ipairs({ -1, num1 }) do
			local var10 = v1 * ((if var6.round then var6.hullR else var6.sideX) + 0.1)
			local var11 = var6.sideY[1] + 0.08
			arg1:wedge("SweptFin", CFrame.new(var10, var11, var6.sideSpan[2] - 0.3) * CFrame.Angles(0, 0, v1 * -0.3490658503988659), Vector3.new(0.04, 0.24, 0.62), var8)
			arg1:add("FinEdge", CFrame.new(var10 + v1 * 0.005, var11 - 0.12, var6.sideSpan[2] - 0.3), Vector3.new(0.045, 0.02, 0.62), var9, var2.Neon, { Transparency = 0.2 })
		end

		local str1 = "TailFin"
		local var12 = CFrame.new
		local num2 = 0
		local var13 = (if arg1.weapon == "SteamBlaster" then 1.86 else var6.topY) + 0.14
		var12 = var12(num2, var13, if arg1.weapon == "SteamBlaster" then 0.95 else var6.sideSpan[2] - 0.1)
		arg1:wedge(str1, var12, Vector3.new(0.04, 0.28, 0.5), var7)
		local var14 = var6.nozzle
		if arg1.weapon ~= "SteamBlaster" then
			local var15 = math.max(var6.muzzle / 2, 0.3)
			for i1 = 0, 2 do
				local str2 = "Cowl"
				local num3 = 0
				local var16 = var14.Y
				local var17 = var14.Z + 0.12 + i1 * 0.14
				local var18 = var14.Z + 0.24 + i1 * 0.14
				local var19 = var15 * 2 * (i1 * 0.1 + 0.84)
				arg1:tube(str2, num3, var16, var17, var18, var19, if i1 == 1 then var8 else var7, var2.SmoothPlastic)
			end

			arg1:hide(var6.nozzleParts[1])
		else
			arg1:add("Cowl", CFrame.new(0, 1.1, -1.38) * CFrame.Angles(0, 0, 0), Vector3.new(1.36, 0.86, 0.1), var7)
			arg1:add("CowlEdge", CFrame.new(0, 1.1, -1.435), Vector3.new(1.2, 0.68, 0.02), var8)
		end

		str1 = var1(0, var14.Y, (var6.neckFront + var6.neckBack) / 2)
		var12 = if arg1.weapon == "SteamBlaster" then 0.7 else math.max(var6.neckR, 0.25) + 0.3
		local tbl1 = {}
		for i2 = 0, 2 do
			local var20 = var3(i2 * 120 + 90)
			local str3 = "FloatFin"
			local var21 = CFrame.new(str1 + var1(math.cos(var20) * var12, math.sin(var20) * var12, 0)) * CFrame.Angles(0, 0, var20 - 1.5707963267948966)
			local var22 = Vector3.new(0.04, 0.16, 0.34)
			local var23 = var7
			local var24 = var2.SmoothPlastic
			table.insert(tbl1, arg1:wedge(str3, var21, var22, var23, var24))
		end

		local str4 = "FloatRing"
		local var25 = str1
		local var26 = var12 - 0.12
		local num4 = 0.03
		local var27 = var9
		local var28 = var2.Neon
		local num5 = 18
		local var29 = nil
		local tbl2 = { Transparency = 0.3 }
		for k2, v2 in ipairs(arg1:ring(str4, var25, var26, num4, var27, var28, num5, var29, tbl2)) do
			table.insert(tbl1, v2)
		end

		rotate(tbl1, str1, Vector3.new(0, 0, 1), 22, 0.03)
		var13 = var6.orbit
		for i3 = 0, 1 do
			local var30 = i3 * 3.1415926535897931 + 0.6
			num4 = arg1:add("RibbonCarrier", CFrame.new(var13.center + var1(math.cos(var30) * var13.radius * 0.9, math.sin(var30) * var13.radius * 0.7, 0)), Vector3.new(0.04, 0.04, 0.04), var7, var2.SmoothPlastic, { Transparency = 1 })
			var27 = Instance.new("Attachment")
			var27.Position = Vector3.new(0, 0.03, 0)
			var27.Parent = num4
			var28 = Instance.new("Attachment")
			var28.Position = Vector3.new(0, -0.03, 0)
			var28.Parent = num4
			num5 = Instance.new("Trail")
			num5.Name = "SkinFx"
			num5.Attachment0 = var27
			num5.Attachment1 = var28
			num5.Lifetime = 0.45
			num5.MinLength = 0.02
			num5.FaceCamera = true
			num5.LightEmission = 0.6
			local str5 = "#A8DFFF"
			num5.Color = ColorSequence.new(var4("#FFFFFF"), var4(str5))
			local num6 = 1
			local num7 = 1
			num5.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(num6, num7) })
			num6 = 1
			num7 = 0.2
			num5.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(num6, num7) })
			num5.Enabled = false
			num5:SetAttribute("FxWhen", "always")
			num5.Parent = num4
			var29 = rotate
			local var31 = var13.center
			str5 = Vector3.new(0, 0, 1)
			var29({ num4 }, var31, str5, (if i3 == 0 then 1 else -1) * 110, 0.05)
			for i4 = 0, 3 do
				str5 = var30 - i4 * 0.18
				local var32 = CFrame.lookAt(var13.center + var1(math.cos(str5) * var13.radius * 0.9, math.sin(str5) * var13.radius * 0.7, 0), var13.center) * CFrame.Angles(0, 0, 1.5707963267948966)
				local var33 = var4("#D6F0FF")
				num7 = arg1:add("RibbonStatic", var32, Vector3.new(0.16, 0.012, 0.03), var33, var2.Neon, { Transparency = i4 * 0.15 + 0.2 })
				num7:SetAttribute("FxStatic", true)
				num7:SetAttribute("FxStaticTransparency", num7.Transparency)
				num7.Transparency = 1
			end
		end
	end,
	tidecaller = function(arg1)
		local var5 = arg1.pal
		local num1 = 1
		local var6 = arg1.A
		local var7 = var5.trim
		local var8 = var5.housing
		local var9 = var4("#6FE3EE")
		for k1, v1 in ipairs({ -1, num1 }) do
			local var10 = v1 * ((if var6.round then var6.hullR else var6.sideX) + 0.015)
			local var11 = var6.sideSpan[2] - var6.sideSpan[1]
			for i1 = 0, 8 do
				local var12 = disc
				local var13 = arg1
				local str1 = "WaveCrest"
				local var14 = var1(var10, var6.sideY[1] + 0.12 + (math.sin(i1 * 0.9) + 1) * 0.07, var6.sideSpan[1] + 0.08 + i1 * (var11 - 0.16) / 8)
				local var15 = var1(v1, 0, 0)
				local num2 = 0.15
				local num3 = 0.02
				var12(var13, str1, var14, var15, num2, num3, if i1 % 2 == 0 then var7 else var4("#BFF3F2"), var2.SmoothPlastic, { Reflectance = 0.1 })
			end
		end

		if arg1.weapon == "SteamBlaster" then
			local num4 = 0.95
			for k2, v2 in ipairs({ -0.62, num4 }) do
				arg1:tube("PearlBand", 0, 1.3, v2 - 0.05, v2 + 0.05, 0.94, var7, var2.SmoothPlastic, { Reflectance = 0.15 })
			end
		end

		local var16 = var6.nozzle
		local var17 = (if arg1.weapon == "SteamBlaster" then 0.66 else math.max(var6.muzzle / 2, 0.28)) + 0.04
		for i2 = 0, 5 do
			local str2 = "ShellRib"
			local var18 = CFrame.new(0, var16.Y, var16.Z + 0.16) * CFrame.Angles(0, 0, (var3(i2 * 60))) * CFrame.new(0, var17, 0) * CFrame.Angles(-0.24434609527920614, 0, 0)
			local var19 = var1(var17 * 0.9, 0.05, 0.3)
			arg1:add(str2, var18, var19, if i2 % 2 == 0 then var7 else var8, var2.SmoothPlastic, { Reflectance = 0.1 })
		end

		local var20 = var6.orbit
		local tbl1 = {}
		for i3 = 0, 4 do
			local var21 = var3(i3 * 70 + 30)
			local str3 = "Droplet"
			local var22 = var20.center + var1(math.cos(var21) * var20.radius * 0.95, math.sin(var21) * var20.radius * 0.75, (i3 - 2) * 0.22)
			local var23 = i3 % 2 * 0.03 + 0.07
			local var24 = var9
			local var25 = var2.Glass
			local tbl2 = { Transparency = 0.2, Reflectance = 0.2 }
			table.insert(tbl1, arg1:ball(str3, var22, var23, var24, var25, tbl2))
		end

		bob(tbl1, 0.05)
		local var26 = var1(0, var16.Y, (var6.neckFront + var6.neckBack) / 2 + 0.1)
		local var27 = if arg1.weapon == "SteamBlaster" then 0.62 else math.max(var6.neckR, 0.25) + 0.16
		local tbl3 = {}
		for i4 = 0, 11 do
			local var28 = i4 * 3.1415926535897931 / 6
			local str4 = "WaterBead"
			local var29 = var26 + var1(math.cos(var28) * var27, math.sin(var28) * var27, math.sin(var28 * 2) * 0.04)
			local var30 = i4 % 3 * 0.015 + 0.05
			local var31 = var9
			local var32 = var2.Glass
			local tbl4 = { Transparency = 0.3 }
			table.insert(tbl3, arg1:ball(str4, var29, var30, var31, var32, tbl4))
		end

		rotate(tbl3, var26, Vector3.new(0, 0, 1), 95, 0.015)
	end,
	darkmatter = function(arg1)
		local str1 = "SkinDarkMatter"
		require(script.Parent:WaitForChild(str1)).build(arg1, tbl1.Kit)
	end,
}

tbl1.Variants = tbl2
tbl1.has = function(arg1)
	return tbl2[arg1] ~= nil
end

tbl1.grenadeBurst = function(arg1, arg2, arg3, arg4, arg5)
	if arg1 == "darkmatter" then
		local str2 = "SkinDarkMatter"
		local var2 = require(script.Parent:WaitForChild(str2)).burst
		var2(arg2, arg3, arg4, arg5, tbl1.Kit)
	end
end

tbl1.build = function(arg1, arg2)
	local var2 = tbl2[arg1]
	if var2 then
		var2(arg2)
	end
end

return tbl1

--- ReplicatedStorage.MeltShared.SkinArt [ModuleScript]
-- y u r i

local var1 = script.Parent
local str1 = "Skins"
local str2 = "SkinModels"
local str3 = "SkinPatterns"
local var2 = require(var1:WaitForChild(str1))
local str4 = "SkinVariants"
local var3 = require(var1:WaitForChild(str2))
local var4 = require(var1:WaitForChild(str3))
str1 = require(var1:WaitForChild(str4))
str4 = Color3.fromHex
local tbl1 = { housing = str4("#C8283A") }
tbl1.housing2 = str4("#A51F30")
tbl1.trim = str4("#F4E6CC")
tbl1.accent = str4("#F4E6CC")
tbl1.accent2 = str4("#E9D3AC")
tbl1.grip = str4("#2F3338")
tbl1.dark = str4("#3A2C30")
tbl1.metal = str4("#C4CBD1")
tbl1.tank = str4("#F4E6CC")
local tbl2 = { cherry = { palette = tbl1 } }
tbl1 = { housing = str4("#CFEAF7") }
tbl1.housing2 = str4("#A9D6EC")
tbl1.trim = str4("#FFFFFF")
tbl1.accent = str4("#1F3557")
tbl1.accent2 = str4("#FFFFFF")
tbl1.grip = str4("#1B2A44")
tbl1.dark = str4("#22385A")
tbl1.metal = str4("#E6F2F8")
tbl1.metalDark = str4("#A8BCCB")
tbl1.tank = str4("#FFFFFF")
tbl2.arctic = { palette = tbl1 }
tbl1 = { housing = str4("#F5C93A") }
tbl1.housing2 = str4("#E3B12A")
tbl1.trim = str4("#33383E")
tbl1.accent = str4("#FFF4D6")
tbl1.accent2 = str4("#33383E")
tbl1.grip = str4("#33383E")
tbl1.dark = str4("#2A2E33")
tbl1.metal = str4("#D8D8D0")
tbl1.tank = str4("#FFF4D6")
tbl2.lemon = { palette = tbl1 }
tbl1 = { housing = str4("#D9A55E") }
tbl1.housing2 = str4("#C48E48")
tbl1.trim = str4("#F2DDB6")
tbl1.accent = str4("#E38B1E")
tbl1.accent2 = str4("#E38B1E")
tbl1.grip = str4("#4A3322")
tbl1.dark = str4("#2E2016")
tbl1.metal = str4("#CFC5B4")
tbl1.tank = str4("#D9A55E")
local tbl3 = { palette = tbl1, pattern = "cheetah" }
tbl1 = { spot = str4("#3B2616") }
tbl1.middle = str4("#B8813F")
tbl3.colors = tbl1
tbl2.cheetah = tbl3
tbl1 = { housing = str4("#F2E8D5") }
tbl1.housing2 = str4("#F2E8D5")
tbl1.trim = str4("#2E9C98")
tbl1.accent = str4("#2E9C98")
tbl1.accent2 = str4("#1E1F22")
tbl1.grip = str4("#1E1F22")
tbl1.dark = str4("#161719")
tbl1.metal = str4("#C9CDD1")
tbl1.tank = str4("#F2E8D5")
tbl3 = { palette = tbl1, pattern = "checker" }
tbl1 = { check = str4("#1E1F22") }
tbl3.colors = tbl1
tbl2.checker = tbl3
tbl1 = { housing = str4("#FFF1E0") }
tbl1.housing2 = str4("#FFF1E0")
tbl1.trim = str4("#EE6F61")
tbl1.accent = str4("#EE6F61")
tbl1.accent2 = str4("#EE6F61")
tbl1.grip = str4("#EE6F61")
tbl1.gripDark = str4("#C9544A")
tbl1.dark = str4("#4A3A3A")
tbl1.metal = str4("#F4E3D6")
tbl1.tank = str4("#FFF1E0")
tbl3 = { palette = tbl1, pattern = "candystripe" }
tbl1 = { stripe = str4("#EE6F61") }
tbl3.colors = tbl1
tbl2.candystripe = tbl3
tbl1 = { housing = str4("#1B3F73") }
tbl1.housing2 = str4("#16335E")
tbl1.trim = str4("#BFEAFF")
tbl1.accent = str4("#8FD3F5")
tbl1.accent2 = str4("#BFEAFF")
tbl1.grip = str4("#132A4D")
tbl1.dark = str4("#0E1F3A")
tbl1.metal = str4("#D6ECF7")
tbl1.tank = str4("#1B3F73")
tbl3 = { palette = tbl1, pattern = "glaciervein" }
str3 = Enum.Material
tbl3.materials = { housing = str3.SmoothPlastic }
tbl1 = { vein = str4("#CFF1FF") }
tbl3.colors = tbl1
tbl2.glaciervein = tbl3
tbl1 = { housing = str4("#F5EBDD") }
tbl1.housing2 = str4("#F5EBDD")
tbl1.trim = str4("#E0452B")
tbl1.accent = str4("#E0452B")
tbl1.accent2 = str4("#2B2B2E")
tbl1.grip = str4("#2B2B2E")
tbl1.dark = str4("#1F1F22")
tbl1.metal = str4("#D9CFC0")
tbl1.tank = str4("#F5EBDD")
tbl3 = { palette = tbl1, pattern = "koi" }
tbl1 = { red = str4("#E0452B") }
tbl1.ink = str4("#2B2B2E")
tbl1.wave = str4("#2B2B2E")
tbl3.colors = tbl1
tbl2.koi = tbl3
tbl1 = { housing = str4("#14203A") }
tbl1.housing2 = str4("#101A30")
tbl1.trim = str4("#C9D2DA")
tbl1.accent = str4("#3FE0F0")
tbl1.accent2 = str4("#C9D2DA")
tbl1.grip = str4("#0E1628")
tbl1.dark = str4("#0A1120")
tbl1.metal = str4("#C9D2DA")
tbl1.tank = str4("#14203A")
tbl3 = { palette = tbl1, pattern = "circuit" }
tbl1 = { trace = str4("#3FE0F0") }
tbl1.pad = str4("#C9D2DA")
tbl3.colors = tbl1
tbl2.circuit = tbl3
tbl1 = { housing = str4("#1FA39C") }
tbl1.housing2 = str4("#6E4BC4")
tbl1.trim = str4("#D6F7F2")
tbl1.accent = str4("#8A63E0")
tbl1.accent2 = str4("#1FA39C")
tbl1.grip = str4("#203049")
tbl1.dark = str4("#16203A")
tbl1.metal = str4("#BFD8E6")
tbl1.tank = str4("#6E4BC4")
tbl2.aurora = { palette = tbl1, variant = "aurora" }
tbl1 = { housing = str4("#2B2C30") }
tbl1.housing2 = str4("#B8733F")
tbl1.trim = str4("#B8733F")
tbl1.accent = str4("#C98046")
tbl1.accent2 = str4("#B8733F")
tbl1.grip = str4("#1F2024")
tbl1.dark = str4("#141518")
tbl1.metal = str4("#B8733F")
tbl1.tank = str4("#2B2C30")
tbl3 = { palette = tbl1, variant = "emberline" }
tbl3.materials = { housing2 = str3.Metal, trim = str3.Metal, accent = str3.Metal }
tbl2.emberline = tbl3
tbl1 = { housing = str4("#F59AC6") }
tbl1.housing2 = str4("#6FD9EC")
tbl1.trim = str4("#7FE3F0")
tbl1.accent = str4("#E86AA8")
tbl1.accent2 = str4("#6FD9EC")
tbl1.grip = str4("#E2779F")
tbl1.gripDark = str4("#C45E86")
tbl1.dark = str4("#3C3552")
tbl1.metal = str4("#F0F4F8")
tbl1.tank = str4("#F59AC6")
tbl3 = { palette = tbl1, variant = "bubblegum" }
tbl3.sound = { id = "rbxasset://sounds/volume_slider.ogg", volume = 0.14, speed = 0.62 }
tbl2.bubblegum = tbl3
tbl1 = { housing = str4("#24483E") }
tbl1.housing2 = str4("#1B3530")
tbl1.trim = str4("#EFE2C4")
tbl1.accent = str4("#C9A04A")
tbl1.accent2 = str4("#C9A04A")
tbl1.grip = str4("#5A3A26")
tbl1.gripDark = str4("#3F2819")
tbl1.dark = str4("#1E2624")
tbl1.metal = str4("#C9A04A")
tbl1.metalDark = str4("#8E6E2E")
tbl1.tank = str4("#EFE2C4")
tbl3 = { palette = tbl1, pattern = "rivets", variant = "brassworks" }
tbl3.materials = { accent = str3.Metal, accent2 = str3.Metal }
tbl1 = { rivet = str4("#C9A04A") }
tbl3.colors = tbl1
tbl2.brassworks = tbl3
tbl1 = { housing = str4("#394A66") }
tbl1.housing2 = str4("#2A3850")
tbl1.trim = str4("#E9F1F7")
tbl1.accent = str4("#8FD8F0")
tbl1.accent2 = str4("#E9F1F7")
tbl1.grip = str4("#283247")
tbl1.dark = str4("#1E2638")
tbl1.metal = str4("#C8D6E2")
tbl1.metalDark = str4("#8FA2B4")
tbl1.tank = str4("#E9F1F7")
tbl2.crystalbound = { palette = tbl1, variant = "crystalbound" }
tbl1 = { housing = str4("#F3E6CB") }
tbl1.housing2 = str4("#E4D3B0")
tbl1.trim = str4("#D2372B")
tbl1.accent = str4("#D2372B")
tbl1.accent2 = str4("#D7DEE3")
tbl1.grip = str4("#8E2A22")
tbl1.gripDark = str4("#6E1F1A")
tbl1.dark = str4("#2E2A2A")
tbl1.metal = str4("#D7DEE3")
tbl1.metalDark = str4("#9AA4AC")
tbl1.tank = str4("#F3E6CB")
tbl2.retrorocket = { palette = tbl1, variant = "retrorocket" }
tbl1 = { housing = str4("#221D22") }
tbl1.housing2 = str4("#16121A")
tbl1.trim = str4("#B8733F")
tbl1.accent = str4("#C98046")
tbl1.accent2 = str4("#7A3F1E")
tbl1.grip = str4("#3A261C")
tbl1.gripDark = str4("#24160F")
tbl1.dark = str4("#0F0C10")
tbl1.metal = str4("#B8733F")
tbl1.metalDark = str4("#6E3A1C")
tbl1.tank = str4("#221D22")
tbl3 = { palette = tbl1, pattern = "scales", variant = "dragonforge" }
tbl3.materials = { trim = str3.Metal, accent = str3.Metal }
tbl1 = { scale = str4("#4A2F22") }
tbl1.scale2 = str4("#33241F")
tbl3.colors = tbl1
tbl2.dragonforge = tbl3
tbl1 = { housing = str4("#F2EEE6") }
tbl1.housing2 = str4("#1C2556")
tbl1.trim = str4("#243070")
tbl1.accent = str4("#E6C46A")
tbl1.accent2 = str4("#F7E7B4")
tbl1.grip = str4("#1C2556")
tbl1.gripDark = str4("#141B40")
tbl1.dark = str4("#111733")
tbl1.metal = str4("#E6C46A")
tbl1.metalDark = str4("#B08F3F")
tbl1.tank = str4("#F2EEE6")
tbl3 = { palette = tbl1, variant = "celestial" }
tbl3.materials = { accent = str3.Metal }
tbl3.reflectance = { housing = 0.12, tank = 0.12 }
tbl2.celestial = tbl3
tbl1 = { housing = str4("#15475A") }
tbl1.housing2 = str4("#0E3342")
tbl1.trim = str4("#C9A04A")
tbl1.accent = str4("#C9A04A")
tbl1.accent2 = str4("#8C6A2E")
tbl1.grip = str4("#2E2419")
tbl1.gripDark = str4("#1E170F")
tbl1.dark = str4("#0A1E26")
tbl1.metal = str4("#C9A04A")
tbl1.metalDark = str4("#7A5C28")
tbl1.tank = str4("#1F6E73")
tbl3 = { palette = tbl1, variant = "deepcurrent" }
tbl3.materials = { trim = str3.Metal, accent = str3.Metal }
tbl2.deepcurrent = tbl3
tbl1 = { housing = str4("#6F6A60") }
tbl1.housing2 = str4("#57534B")
tbl1.trim = str4("#8C6A3A")
tbl1.accent = str4("#58D39A")
tbl1.accent2 = str4("#8C6A3A")
tbl1.grip = str4("#4A3B2B")
tbl1.gripDark = str4("#33291E")
tbl1.dark = str4("#2B2824")
tbl1.metal = str4("#8C6A3A")
tbl1.metalDark = str4("#5E4726")
tbl1.tank = str4("#6F6A60")
tbl3 = { palette = tbl1, variant = "earthwarden" }
tbl3.materials = {
	housing = str3.Slate,
	housing2 = str3.Slate,
	tank = str3.Slate,
	trim = str3.Metal,
	accent2 = str3.Metal,
	grip = str3.Wood,
}

tbl2.earthwarden = tbl3
tbl1 = { housing = str4("#1A1517") }
tbl1.housing2 = str4("#2A2224")
tbl1.trim = str4("#3A2E2E")
tbl1.accent = str4("#8A2E12")
tbl1.accent2 = str4("#3A2A26")
tbl1.grip = str4("#2A2224")
tbl1.gripDark = str4("#1A1416")
tbl1.dark = str4("#0B090A")
tbl1.metal = str4("#3A2E2E")
tbl1.metalDark = str4("#241C1C")
tbl1.tank = str4("#1A1517")
tbl3 = { palette = tbl1, pattern = "glaciervein", variant = "inferno" }
tbl3.materials = { housing = str3.Basalt, tank = str3.Basalt }
tbl1 = { vein = str4("#FF6A1A") }
tbl3.colors = tbl1
tbl3.patternMaterial = str3.Neon
tbl2.inferno = tbl3
tbl1 = { housing = str4("#F7FAFC") }
tbl1.housing2 = str4("#BFE3F5")
tbl1.trim = str4("#8FC9EA")
tbl1.accent = str4("#5FB0E0")
tbl1.accent2 = str4("#FFFFFF")
tbl1.grip = str4("#7FA9C6")
tbl1.gripDark = str4("#5E8AA8")
tbl1.dark = str4("#9DB9CE")
tbl1.metal = str4("#E8F1F7")
tbl1.metalDark = str4("#A9BFD0")
tbl1.tank = str4("#F7FAFC")
tbl3 = { palette = tbl1, variant = "skyweaver" }
tbl3.reflectance = { metal = 0.15 }
tbl2.skyweaver = tbl3
tbl1 = { housing = str4("#0E7C80") }
tbl1.housing2 = str4("#0A5A60")
tbl1.trim = str4("#F2EEE6")
tbl1.accent = str4("#4FE0E6")
tbl1.accent2 = str4("#F2EEE6")
tbl1.grip = str4("#0A4A50")
tbl1.gripDark = str4("#073A3F")
tbl1.dark = str4("#06363A")
tbl1.metal = str4("#DCE8E8")
tbl1.metalDark = str4("#9DB6B8")
tbl1.tank = str4("#F2EEE6")
tbl3 = { palette = tbl1, variant = "tidecaller" }
tbl3.reflectance = { housing = 0.08, trim = 0.12, tank = 0.12 }
tbl2.tidecaller = tbl3
tbl1 = { housing = str4("#1F1D29") }
tbl1.housing2 = str4("#282533")
tbl1.trim = str4("#2D2A40")
tbl1.accent = str4("#352F52")
tbl1.accent2 = str4("#221F30")
tbl1.grip = str4("#17161E")
tbl1.gripDark = str4("#111017")
tbl1.dark = str4("#0B0A10")
tbl1.metal = str4("#6A6A82")
tbl1.metalDark = str4("#3A3A4C")
tbl1.tank = str4("#221F32")
tbl3 = { palette = tbl1, variant = "darkmatter", grenade = true }
tbl3.materials = {
	housing = str3.Metal,
	housing2 = str3.DiamondPlate,
	trim = str3.Metal,
	accent = str3.Metal,
	accent2 = str3.Metal,
	grip = str3.Fabric,
	gripDark = str3.Fabric,
	tank = str3.Metal,
}

tbl3.reflectance = {
	housing = 0.12,
	housing2 = 0.05,
	metal = 0.2,
	metalDark = 0.14,
	trim = 0.1,
	accent = 0.08,
}

tbl2.darkmatter = tbl3
local tbl4 = {
	Color = "SkinOrigColor",
	Material = "SkinOrigMaterial",
	Reflectance = "SkinOrigReflectance",
	Transparency = "SkinOrigTransparency",
}

str2 = {
	FolderName = "SkinCosmetics",
	Themes = tbl2,
	hasArt = function(arg1, arg2)
		local var5 = var2.ById[var2.canonical(arg1)]
		if not var5 then
			return false
		end

		for k1, v1 in ipairs(var2.Weapons) do
			if (arg2 == nil or v1.Id == arg2) and (not var3.has(v1.Id)) then
				return false
			end
		end

		if arg2 and (not var2.isWeapon(arg2)) then
			return false
		end

		local var7 = tbl2[var5.Theme]
		if not var7 then
			return false
		end

		if var7.variant and (not str1.has(var7.variant)) then
			return false
		end

		if var7.pattern and (not var4.Patterns[var7.pattern]) then
			return false
		end

		return true
	end,
}

local function ownParts(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end

local function restore(arg1)
	local var2 = arg1:GetAttribute(tbl4.Color)
	if var2 == nil then
		return
	end

	arg1.Color = var2
	local var3 = arg1:GetAttribute(tbl4.Material)
	local success, result = pcall(function()
		return Enum.Material[var3]
	end)

	if success and result then
		arg1.Material = result
	end

	local var4 = arg1:GetAttribute(tbl4.Reflectance) or 0
	arg1.Reflectance = var4
	var4 = arg1:GetAttribute(tbl4.Transparency) or 0
	arg1.Transparency = var4
	for k1, v1 in pairs(tbl4) do
		arg1:SetAttribute(v1, nil)
	end
end

str2.remove = function(arg1)
	local var2 = arg1:FindFirstChild(str2.FolderName)
	if var2 then
		var2:Destroy()
	end

	local var3 = arg1
	for k1, v1 in ipairs((ownParts(var3))) do
		restore(v1)
	end

	arg1:SetAttribute("SkinId", nil)
end

tbl1 = function(arg1)
	local var1 = table.clone(arg1)
	local var2 = var1.housing2
	var2 = var2 or var1.housing:Lerp(Color3.new(0, 0, 0), 0.2)
	var1.housing2 = var2
	var2 = var1.accent2
	var1.accent2 = var2 or var1.accent
	var2 = var1.gripDark
	var2 = var2 or var1.grip:Lerp(Color3.new(0, 0, 0), 0.25)
	var1.gripDark = var2
	var2 = var1.metalDark
	var2 = var2 or var1.metal:Lerp(Color3.new(0, 0, 0), 0.3)
	var1.metalDark = var2
	var2 = var1.tank
	var1.tank = var2 or var1.trim
	var2 = var1.dark
	var2 = var2 or str4("#2B2F36")
	var1.dark = var2
	return var1
end

local function remember(arg1)
	if arg1:GetAttribute(tbl4.Color) == nil then
		arg1:SetAttribute(tbl4.Color, arg1.Color)
		arg1:SetAttribute(tbl4.Material, arg1.Material.Name)
		arg1:SetAttribute(tbl4.Reflectance, arg1.Reflectance)
		arg1:SetAttribute(tbl4.Transparency, arg1.Transparency)
	end
end

tbl3 = { metal = true, metalDark = true }
local function context(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = arg1:FindFirstChild("Handle")
	local tbl2 = {
		weapon = arg2,
		skinId = arg3,
		model = arg1,
		handle = var1,
		folder = arg5,
		pal = tbl1(arg4.palette),
	}

	tbl2.A = str1.Anatomy[arg2]
	local var2 = arg6
	tbl2.rng = Random.new(var4.seed(var2))
	tbl2.add = function(_, arg2, arg3, arg4, arg5, arg6, arg7)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		return var3.add(var2, var4, var5, var6, var7, var8, var9, var10)
	end

	tbl2.tube = function(_, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		local var11 = arg8
		local var12 = arg9
		local var13 = arg10
		return var3.tubeZ(var2, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	end

	tbl2.rod = function(_, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		local var11 = arg8
		return var3.rod(var2, var4, var5, var6, var7, var8, var9, var10, var11)
	end

	tbl2.ball = function(_, arg2, arg3, arg4, arg5, arg6, arg7)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		return var3.ball(var2, var4, var5, var6, var7, var8, var9, var10)
	end

	tbl2.wedge = function(_, arg2, arg3, arg4, arg5, arg6, arg7)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		return var3.wedge(var2, var4, var5, var6, var7, var8, var9, var10)
	end

	tbl2.ring = function(_, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		local var11 = arg8
		local var12 = arg9
		local var13 = arg10
		return var3.ring(var2, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	end

	tbl2.star = function(_, arg2, arg3, arg4, arg5, arg6, arg7)
		local var2 = arg5
		local var4 = var1
		local var5 = arg2
		local var6 = arg3
		local var7 = arg4
		local var8 = arg5
		local var9 = arg6
		local var10 = arg7
		return var3.star(var2, var4, var5, var6, var7, var8, var9, var10)
	end

	tbl2.hide = function(_, ...)
		local var1 = var3.Roles[arg2]
		for k1, v1 in ipairs({ ... }) do
			if not var1[v1] then
				continue
			end

			if var1[v1] == "keep" then
				continue
			end

			local var2 = arg1
			for k2, v2 in ipairs((ownParts(var2))) do
				if v2.Name ~= v1 then
					continue
				end

				remember(v2)
				v2.Transparency = 1
			end
		end
	end

	return tbl2
end

str2.apply = function(arg1, arg2)
	str2.remove(arg1)
	if arg2 == nil or arg2 == var2.DefaultId then
		return true, nil
	end

	arg2 = var2.canonical(arg2)
	local var5 = var2.ById[arg2]
	if not var5 then
		return false, "unknownSkin"
	end

	local var6 = arg1:GetAttribute("ToolId")
	var6 = var6 or arg1.Name
	if not var3.has(var6) then
		return false, "unknownWeapon"
	end

	if var6 == var2.GrenadeId and (not tbl2[var5.Theme] or (not tbl2[var5.Theme].grenade)) then
		return false, "noGrenadeArt"
	end

	local var8 = arg1:FindFirstChild("Handle")
	local var9 = string.lower(var6) .. "_" .. var5.Theme
	if not var8 or (not var8:IsA("BasePart")) then
		return false, "noHandle"
	end

	local var11 = tbl2[var5.Theme]
	if not var11 then
		return false, "noArt"
	end

	local success, result = pcall(function()
		local var12
		local var1 = arg1
		local var2 = tbl1(var11.palette)
		local var5 = var3.Roles[var6]
		for k1, v1 in ipairs((ownParts(var1))) do
			local var7 = var5[v1.Name]
			if not var7 or var7 == "keep" then
				continue
			end

			if not var2[var7] then
				continue
			end

			remember(v1)
			v1.Color = var2[var7]
			if var11.materials then
				local var10 = var11.materials[var7]
				if not var10 then
					var10 = if tbl3[var7] then str3.Metal else str3.SmoothPlastic
				end
			end

			v1.Material = var12
			v1.Reflectance = var11.reflectance and var11.reflectance[var7] or 0
		end

		local var13 = Instance.new("Folder")
		var13.Name = str2.FolderName
		var13.Parent = arg1
		if var11.pattern then
			local var15 = var11.colors
			local var16 = table.clone(var15 or {})
			if var11.patternMaterial then
				var4.draw(var11.pattern, arg1, var6, var13, var4.seed(var9), var16)
				for k2, v2 in ipairs(var13:GetChildren()) do
					if not v2:IsA("BasePart") then
						continue
					end

					v2.Material = var11.patternMaterial
				end
			else
				var4.draw(var11.pattern, arg1, var6, var13, var4.seed(var9), var16)
			end
		end

		local var17 = context(arg1, var6, arg2, var11, var13, var9)
		if var11.variant then
			str1.build(var11.variant, var17)
		end

		if var11.sound then
			local var18 = Instance.new("Sound")
			var18.Name = "SkinFxSound"
			var18.SoundId = var11.sound.id
			var18.Volume = var11.sound.volume
			var18.PlaybackSpeed = var11.sound.speed or 1
			var18.RollOffMaxDistance = 40
			var18:SetAttribute("FxWhen", "start")
			var18.Parent = var13
		end
	end)

	if not success then
		str2.remove(arg1)
		warn("[SkinArt] " .. tostring(arg2) .. " could not be built: " .. tostring(result))
		return false, "artError"
	end

	arg1:SetAttribute("SkinId", arg2)
	return true, nil
end

str2.grenadeBurst = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = if arg1 then var2.ById[var2.canonical(arg1)] else nil
	local var3 = var1
	var3 = var3 and tbl2[var1.Theme]
	if not var3 or (not var3.grenade or (not var3.variant)) then
		return
	end

	str1.grenadeBurst(var3.variant, arg2, arg3, arg4, arg5 == true)
end

str2.preview = function(arg1, arg2)
	local var1 = arg2
	var1 = var1 or var2.ShowcaseWeapon
	local var4 = var1
	assert(var4 and var3.has(var1), "SkinArt.preview needs a skin or a weapon")
	local var7 = if arg1 then var2.ById[var2.canonical(arg1)] else nil
	local var8 = var3.build(var1, true)
	if var7 then
		local var9, var10 = str2.apply(var8, var7.Id)
		local str1 = "SkinFallback"
		var8:SetAttribute(str1, if var9 then nil else var10)
	end

	return var8
end

str2.check = function(arg1)
	local var2 = arg1:FindFirstChild(str2.FolderName)
	local tbl1 = {}
	if var2 then
		for k1, v1 in ipairs(var2:GetDescendants()) do
			if v1:IsA("BasePart") then
				if v1.CanCollide or (v1.CanQuery or v1.CanTouch) then
					table.insert(tbl1, v1.Name .. " collides, touches or can be queried")
				end

				if v1.Massless then
					continue
				end

				table.insert(tbl1, v1.Name .. " has mass")
			else
				if v1:IsA("LuaSourceContainer") then
					table.insert(tbl1, v1.Name .. " is a script")
				else
					if not v1:IsA("Light") then
						continue
					end

					table.insert(tbl1, v1.Name .. " is a light")
				end
			end
		end
	end

	local var3 = arg1
	for k2, v2 in ipairs((ownParts(var3))) do
		if v2.CanCollide or (v2.CanQuery or v2.CanTouch) then
			table.insert(tbl1, v2.Name .. " (original) collides, touches or can be queried")
		end
	end

	return tbl1
end

str2.describe = function(arg1)
	local var2 = arg1:FindFirstChild(str2.FolderName)
	local num1 = 0
	local num2 = 0
	local num3 = 0
	local num4 = 0
	local num5 = 0
	if var2 then
		for k1, v1 in ipairs(var2:GetDescendants()) do
			if v1:IsA("BasePart") then
				num1 = num1 + 1
				if v1:GetAttribute("FxStatic") then
					num2 = num2 + 1
				end

				if not v1:GetAttribute("FxRotateCenter") then
					continue
				end

				num4 = (v1:GetAttribute("FxRotateCenter") or v1:GetAttribute("FxPulseA")) and num4 + 1
				num5 = num5 + 1
			else
				num3 = (v1:IsA("ParticleEmitter") or v1:IsA("Trail")) and num3 + 1
			end
		end
	end

	local var3 = arg1
	local num6 = 0
	local num7 = 0
	for k2, v2 in ipairs((ownParts(var3))) do
		if v2:GetAttribute(tbl4.Color) == nil then
			continue
		end

		if 1 > v2.Transparency then
			continue
		end

		if (v2:GetAttribute(tbl4.Transparency) or 0) >= 1 then
			continue
		end

		num6 = num6 + 1
		num7 = num7 + 1
	end

	local tbl1 = { skinId = arg1:GetAttribute("SkinId") }
	tbl1.cosmetic = num1
	tbl1.statics = num2
	tbl1.emitters = num3
	tbl1.animated = num4
	tbl1.moving = num5
	tbl1.hidden = num6
	tbl1.recoloured = num7
	return tbl1
end

str2.Skins = var2
str2.Models = var3
return str2

--- ReplicatedStorage.MeltShared.SkinFx [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.ActiveBoost = 2.5
tbl1.EquipSeconds = 0.7
tbl1.InspectSeconds = 3.2
tbl1.FarDistance = 70
tbl1.SurgeSeconds = 1.7
tbl1.SurgeEvery = NumberRange.new(11, 18)
local num1 = -math.huge
local bool1 = false
local tbl2 = {}
local var2 = nil
local function step()
	local var1 = os.clock()
	for k1 in pairs(tbl2) do
		k1:_update(var1)
	end
end

local function effectsGroup()
	for k1, v1 in ipairs(game:GetService("SoundService"):GetDescendants()) do
		if not v1:IsA("SoundGroup") then
			continue
		end

		if string.sub(v1.Name, -7) ~= "Effects" then
			continue
		end

		return v1
	end

	return nil
end

tbl1.attach = function(arg1, arg2)
	local var3 = arg2
	local var4 = setmetatable({}, tbl1)
	var4.model = arg1
	var4.handle = arg1:FindFirstChild("Handle")
	var3 = var3 or {}
	var4.mode = var3.mode or "world"
	local var5 = var3.reduced
	var4.reduced = var5 or function()
		return false
	end

	var5 = var3.active
	local var6 = arg1:FindFirstChild("Handle")
	local var7 = var6:FindFirstChild("Nozzle")
	local var8 = var7:FindFirstChild("Airflow")
	var4.activeFn = var5 or function()
		local bool1 = false
		if var8 ~= nil then
			bool1 = var8.Enabled == true
		end

		return bool1
	end

	var4.silent = var3.silent == true
	var4.camera = var3.camera
	var4.rng = Random.new()
	var4.surgeAt = nil
	var4.hasSurge = false
	var4.forced = false
	var4.wasActive = false
	var4.phase = 0
	var4.extra = 0
	var4.spinUp = 0
	var4.boost = 1
	var4.energy = 0
	var4.lastT = nil
	var4.lastFull = -math.huge
	var4.shownAt = os.clock()
	var4.inspectAt = nil
	var4.animated = {}
	var4.emitters = {}
	var4.bursts = {}
	var4.statics = {}
	var4.sounds = {}
	var4.cues = { equip = {}, stop = {}, inspect = {}, loop = {}, surge = {} }
	var5 = arg1:FindFirstChild("SkinCosmetics")
	if var4.mode == "world" then
		var6 = var3.soundGroup
		if not var6 then
			var6 = effectsGroup()
		end
	else
		var6 = nil
	end

	local var9
	if var5 then
		for k1, v1 in ipairs(var5:GetDescendants()) do
			if v1:IsA("BasePart") then
				if v1:GetAttribute("FxRotateCenter") ~= nil or (v1:GetAttribute("FxPulseA") ~= nil or v1:GetAttribute("FxEnergyLow") ~= nil) then
					local var10 = v1:GetAttribute("FxSurge")
					local var11 = v1:GetAttribute("FxSurgeDim")
					local var12 = v1:GetAttribute("SkinOffset")
					local tbl3 = { part = v1, offset = var12 or CFrame.identity }
					tbl3.weld = v1:FindFirstChild("SkinWeld")
					tbl3.baseTransparency = v1.Transparency
					tbl3.baseColor = v1.Color
					var12 = v1:GetAttribute("FxDetail") == true
					tbl3.detail = var12
					tbl3.face = v1:GetAttribute("FxFace")
					tbl3.surge = var10
					tbl3.surgeDim = var11
					table.insert(var4.animated, tbl3)
					if var10 ~= nil or var11 ~= nil then
						var4.hasSurge = true
					end
				end

				if not v1:GetAttribute("FxStatic") then
					continue
				end

				table.insert(var4.statics, v1)
			else
				if not v1:IsA("ParticleEmitter") then
					if v1:IsA("Trail") then
						local var13 = v1:GetAttribute("FxWhen")
						if typeof(var13) == "string" and string.sub(var13, 1, 6) == "burst:" then
							table.insert(var4.bursts, v1)
						else
							table.insert(var4.emitters, v1)
							continue
						end
					else
						if not v1:IsA("Sound") then
							continue
						end

						local var14 = v1:GetAttribute("FxWhen")
						if var6 and v1.SoundGroup == nil then
							v1.SoundGroup = var6
						end

						if var14 == "start" then
							table.insert(var4.sounds, v1)
						else
							if not var4.cues[var14] then
								continue
							end

							table.insert(var4.cues[var14], v1)
						end
					end
				end
			end
		end
	end

	for k2, v2 in ipairs(var4.statics) do
		local var15 = if var4.mode == "viewport" then v2:GetAttribute("FxStaticTransparency") or 0 else 1
		v2.Transparency = var15
	end

	var4.ancestry = arg1.AncestryChanged:Connect(function()
		if not arg1:IsDescendantOf(game) then
			var4:destroy()
		end
	end)

	local num1 = 4
	var4.nextSurge = os.clock() + var4.rng:NextNumber(num1, tbl1.SurgeEvery.Max)
	tbl2[var4] = true
	if not var2 then
		var2 = var1.Heartbeat:Connect(step)
	end

	if var4.mode == "world" then
		var4:_cue("equip")
		var4:_burst("burst:equip")
	end

	if var4.mode == "world" and (not var4.silent) then
		for k3, v3 in ipairs(var4.cues.loop) do
			v3.Looped = true
			local var16 = v3:GetAttribute("FxBaseVolume")
			v3:SetAttribute("FxBaseVolume", var16 or v3.Volume)
			v3.Volume = 0
			v3:Play()
		end
	end

	var4:_update(os.clock())
	return var4
end

tbl1.setActive = function(arg1, arg2)
	arg1.forced = arg2
end

tbl1.inspect = function(arg1)
	arg1.inspectAt = os.clock()
	arg1:_burst("burst:inspect")
	arg1:_cue("inspect")
end

tbl1.surge = function(arg1)
	if not arg1.hasSurge then
		return
	end

	arg1.surgeAt = os.clock()
	arg1.surgeFlared = false
	arg1:_cue("surge")
end

tbl1._cue = function(arg1, arg2)
	if arg1.mode ~= "world" or arg1.silent then
		return
	end

	local var1 = arg1.cues[arg2]
	for k1, v1 in ipairs(var1 or {}) do
		v1.TimePosition = 0
		v1:Play()
	end
end

tbl1._burst = function(arg1, arg2)
	if arg1.mode ~= "world" or arg1.far then
		return
	end

	local var3 = arg1.reduced()
	local var4
	if not var3 then
		local var5 = os.clock()
		if 2 < var5 - num1 then
			num1 = var5
			local success, result = pcall(function()
				return UserSettings():GetService("UserGameSettings").SavedQualityLevel.Value
			end)

			local var7 = success
			if var7 then
				var4 = typeof(result)
				var7 = false
				if var4 == "number" then
					var4 = 1
					var7 = false
					if var4 <= result then
						var4 = 4
						var7 = result <= var4
					end
				end
			end

			bool1 = var7
		end

		var3 = bool1
	end

	for k1, v1 in ipairs(arg1.bursts) do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		if v1:GetAttribute("FxWhen") ~= arg2 then
			continue
		end

		if not v1.Parent then
			continue
		end

		local var8 = v1:GetAttribute("FxBurst") or 8
		local num2 = 1
		v1:Emit((math.max(num2, (math.floor(var8 * (if var3 then 0.35 else 1))))))
	end
end

tbl1._update = function(arg1, arg2)
	if not arg1.handle or (not arg1.handle.Parent) then
		arg1:destroy()
		return
	end

	local var3 = arg1.handle.CFrame
	local var4 = arg1.far
	if arg1.mode == "world" then
		local var6 = workspace.CurrentCamera
		local bool2 = false
		if var6 ~= nil then
			bool2 = tbl1.FarDistance < (var6.CFrame.Position - var3.Position).Magnitude
		end

		arg1.far = bool2
	else
		arg1.far = false
	end

	if arg1.far and (var4 and arg2 - arg1.lastFull < 0.1) then
		return
	end

	arg1.lastFull = arg2
	local var8 = arg1.reduced()
	if not var8 then
		if 2 < arg2 - num1 then
			num1 = arg2
			local success, result = pcall(function()
				return UserSettings():GetService("UserGameSettings").SavedQualityLevel.Value
			end)

			local var10 = success
			if var10 then
				var10 = false
				if typeof(result) == "number" then
					var10 = false
					if 1 <= result then
						var10 = result <= 4
					end
				end
			end

			bool1 = var10
		end

		var8 = bool1
	end

	local var11 = arg1.model
	local success, result = pcall(function()
		return var11:GetScale()
	end)

	local var12 = if var11:IsA("Model") and (success and typeof(result) == "number") then result else 1
	success = arg1.forced
	var11 = if var8 then 0.35 else 1
	success = success or arg1.activeFn()
	result = if arg1.lastT then math.clamp(arg2 - arg1.lastT, 0, 0.25) else 0
	arg1.lastT = arg2
	local var13 = arg2 - arg1.shownAt
	local var14
	if arg1.mode == "world" then
		local var15 = math.clamp(var13 / tbl1.EquipSeconds, 0, 1)
		var14 = 1 - var15 * var15 * (3 - var15 * 2)
	else
		var14 = 0
	end

	local var16 = arg1.boost
	var16 = var16 + ((if success then tbl1.ActiveBoost else 1) - arg1.boost) * math.min(1, result * 3)
	arg1.boost = var16
	var16 = arg1.phase + result * var11
	arg1.phase = var16
	var16 = arg1.extra + result * var11 * (arg1.boost - 1)
	arg1.extra = var16
	var16 = arg1.spinUp + result * var11 * var14 * 3
	arg1.spinUp = var16
	var16 = arg1.phase
	local num2 = 0
	if arg1.inspectAt then
		local var19 = (arg2 - arg1.inspectAt) / tbl1.InspectSeconds
		if 1 <= var19 then
			arg1.inspectAt = nil
		else
			local var20 = math.clamp(math.min(var19 / 0.2, 1), 0, 1)
			local var21 = math.clamp(math.min((1 - var19) / 0.3, 1), 0, 1)
			local var22 = var20 * var20 * (3 - var20 * 2)
			num2 = var22 * (var21 * var21 * (3 - var21 * 2))
		end
	end

	local num3 = 0
	local num4 = 0
	if arg1.hasSurge then
		if not arg1.surgeAt then
			if arg1.nextSurge <= arg2 then
				if success or (0 < num2 or (0 < var14 or arg1.far)) then
					arg1.nextSurge = arg2 + 2
				else
					arg1:surge()
				end
			end
		end

		if arg1.surgeAt then
			local var25 = (arg2 - arg1.surgeAt) / tbl1.SurgeSeconds
			if 1 <= var25 then
				arg1.surgeAt = nil
				arg1.nextSurge = arg2 + arg1.rng:NextNumber(tbl1.SurgeEvery.Min, tbl1.SurgeEvery.Max)
			else
				local var26 = math.clamp(var25 / 0.4, 0, 1)
				local var27 = math.clamp((var25 - 0.52) / 0.12, 0, 1)
				local var28 = var26 * var26 * (3 - var26 * 2)
				num3 = var28 * (1 - var27 * var27 * (3 - var27 * 2))
				var26 = math.clamp((var25 - 0.52) / 0.07, 0, 1)
				var27 = math.clamp((var25 - 0.6) / 0.4, 0, 1)
				var28 = var26 * var26 * (3 - var26 * 2)
				num4 = var28 * (1 - var27 * var27 * (3 - var27 * 2))
				if 0.52 <= var25 and (not arg1.surgeFlared) then
					arg1.surgeFlared = true
					arg1:_burst("burst:surge")
				end
			end
		end
	end

	local var29 = math.max(if success then 1 else 0, var14, num2 * 0.8, num4 * 0.9)
	local var31 = arg1.energy
	local var32 = arg1.energy
	local var33 = var29 - arg1.energy
	local num5 = 1
	arg1.energy = var32 + var33 * math.min(num5, result * (if var31 < var29 then 8 else 2.2))
	var33 = arg1.camera
	var33 = var33 or workspace.CurrentCamera
	var32 = arg1.energy
	local var35 = nil
	if var33 then
		var35 = var3:PointToObjectSpace(var33.CFrame.Position) / var12
	end

	for k1, v1 in ipairs(arg1.animated) do
		local var36 = v1.part
		if not var36.Parent then
			continue
		end

		if arg1.far then
			if v1.detail then
				continue
			end
		end

		local var41 = var36:GetAttribute("FxRotateSpeed")
		if var41 ~= nil then
			local var43 = var36:GetAttribute("FxBoost")
			local var44 = var36:GetAttribute("FxRotateCenter") or Vector3.new(0, 0, 0)
			local var45 = var36:GetAttribute("FxRotateAxis") or Vector3.new(0, 0, 1)
			local var47 = var36:GetAttribute("FxInspect")
			local var48 = math.rad(var41 * (if var43 then var16 + (arg1.extra + arg1.spinUp) * var43 else var16 + arg1.extra))
			local var49 = v1.offset
			if var47 then
				if 0 < num2 then
					var49 = CFrame.new(var47 * num2) * var49
				end
			end

			local var51 = var36:GetAttribute("FxEquip")
			if var51 then
				if 0 < var14 then
					var49 = CFrame.new(var51 * var14 * var14) * var49
				end
			end

			if v1.surge then
				if 0 < num3 then
					var49 = CFrame.new(v1.surge * num3) * var49
				end
			end

			local var52 = nil
			if v1.face then
				local var53 = if var35 then var35 - var44 else v1.face
				if var53.Magnitude < 0.001 then
					var53 = v1.face
				end

				var53 = var53.Unit
				var52 = CFrame.new(var44) * CFrame.lookAt(Vector3.new(0, 0, 0), -var53, if 0.95 < math.abs(var53.Y) then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)) * CFrame.fromAxisAngle(Vector3.new(0, 0, 1), var48) * CFrame.new(-var44) * var49
			else
				var52 = CFrame.new(var44) * CFrame.fromAxisAngle(var45, var48) * CFrame.new(-var44) * var49
			end

			local var55 = var36:GetAttribute("FxBob")
			if var55 then
				var52 = CFrame.new(0, var55 * math.sin(var16 * 1.7 + (var36:GetAttribute("FxBobPhase") or 0)), 0) * var52
			end

			local var57 = var36:GetAttribute("FxTumble")
			if var57 then
				local var58 = math.rad(var57 * var16)
				var52 = var52 * CFrame.Angles(var58, var58 * 0.7, 0)
			end

			if v1.weld then
				v1.weld.C0 = var52
			elseif var12 == 1 then
				var59 = var52
			else
				var59 = var52 - var52.Position + var52.Position * var12
			end
		end

		local var61 = var36:GetAttribute("FxPulseA")
		if var61 then
			local var62 = (math.sin(arg2 * 2 * 3.1415926535897931 / ((var36:GetAttribute("FxPulsePeriod") or 3) / var11) + (var36:GetAttribute("FxPulsePhase") or 0)) + 1) / 2
			local var63 = var61:Lerp(var36:GetAttribute("FxPulseB") or var61, var62)
			var36.Color = var63
			var63 = var36:GetAttribute("FxPulseFade")
			if var63 then
				var36.Transparency = math.clamp(v1.baseTransparency + var63 * var62, 0, 1)
			end
		end

		local var65 = var36:GetAttribute("FxEnergyLow")
		if var65 then
			local var66 = var65:Lerp(var36:GetAttribute("FxEnergyHigh") or var65, var32)
			var36.Color = var66
			var66 = var36:GetAttribute("FxEnergyFadeLow")
			if var66 then
				local var67 = math.clamp(var66 + ((var36:GetAttribute("FxEnergyFadeHigh") or var66) - var66) * var32, 0, 1)
				var36.Transparency = var67
			end
		end

		if not v1.surgeDim or 0 >= num3 then
			continue
		end

		if var61 or var65 then
			local var68 = var36.Color:Lerp(Color3.new(0, 0, 0), math.clamp(v1.surgeDim, 0, 1) * num3)
			var36.Color = var68
		end
	end

	for k2, v2 in ipairs(arg1.cues.loop) do
		local var69 = v2:GetAttribute("FxBaseVolume") or 0.1
		local var70 = v2:GetAttribute("FxLoopIdle") or 0.5
		v2.Volume = if arg1.far then 0 else var69 * (var70 + (1 - var70) * var32)
		local var71 = (v2:GetAttribute("FxBaseSpeed") or 1) * (1 + 0.12 * var32)
		v2.PlaybackSpeed = var71
	end

	for k3, v3 in ipairs(arg1.emitters) do
		local var73 = v3:GetAttribute("FxWhen")
		local bool4 = false
		if arg1.mode ~= "viewport" then
			bool4 = true
			if var73 ~= "always" then
				if var73 == "active" then
					bool4 = success
					if not bool4 then
						bool4 = false
						if var73 == "inspect" then
							bool4 = 0.3 < num2
						end
					end
				end
			end
		end

		if arg1.far then
			if v3:GetAttribute("FxNear") then
				bool4 = false
			end
		end

		if v3:IsA("Trail") then
			local var74 = bool4
			bool4 = var74 and (not var8)
		end

		if v3:IsA("ParticleEmitter") then
			local var75 = v3:GetAttribute("FxRate")
			var75 = var75 or v3.Rate
			local var76 = if var8 then math.max(1, var75 * 0.35) else var75
			v3.Rate = var76
		end

		if v3.Enabled == bool4 then
			continue
		end

		v3.Enabled = bool4
	end

	if success then
		if not arg1.wasActive then
			local var77 = ipairs
			for k4, v4 in var77(if arg1.silent then {} else arg1.sounds) do
				v4.TimePosition = 0
				v4:Play()
			end

			arg1:_burst("burst:start")
		else
			if arg1.wasActive and (not success) then
				arg1:_cue("stop")
				arg1:_burst("burst:stop")
			end
		end
	else
		if arg1.wasActive and (not success) then
			arg1:_cue("stop")
			arg1:_burst("burst:stop")
		end
	end

	arg1.wasActive = success
end

tbl1.destroy = function(arg1)
	if arg1.dead then
		return
	end

	arg1.dead = true
	tbl2[arg1] = nil
	if arg1.ancestry then
		arg1.ancestry:Disconnect()
	end

	for k1, v1 in ipairs(arg1.emitters) do
		if not v1.Parent then
			continue
		end

		v1.Enabled = false
	end

	for k2, v2 in ipairs(arg1.sounds) do
		if not v2.Parent then
			continue
		end

		v2:Stop()
	end

	for k3, v3 in pairs(arg1.cues) do
		for k4, v4 in ipairs(v3) do
			if not v4.Parent then
				continue
			end

			v4:Stop()
		end
	end

	if var2 and next(tbl2) == nil then
		var2:Disconnect()
		var2 = nil
	end
end

tbl1.watchTool = function(arg1, arg2)
	local tbl2 = { fx = nil }
	local function update()
		local bool1 = false
		if arg1.Parent ~= nil then
			bool1 = arg1.Parent:FindFirstChildOfClass("Humanoid") ~= nil
		end

		if bool1 and (not tbl2.fx and arg1:FindFirstChild("SkinCosmetics")) then
			tbl2.fx = tbl1.attach(arg1, arg2)
			return
		end

		if not bool1 and tbl2.fx then
			tbl2.fx:destroy()
			tbl2.fx = nil
		end
	end

	tbl2.refresh = function()
		if tbl2.fx then
			tbl2.fx:destroy()
			tbl2.fx = nil
		end

		update()
	end

	tbl2.destroy = function()
		if tbl2.conn then
			tbl2.conn:Disconnect()
		end

		if tbl2.fx then
			tbl2.fx:destroy()
			tbl2.fx = nil
		end
	end

	tbl2.conn = arg1.AncestryChanged:Connect(update)
	update()
	return tbl2
end

tbl1.liveCount = function()
	local num1 = 0
	for k1 in pairs(tbl2) do
		num1 = num1 + 1
	end

	return num1
end

return tbl1

--- ReplicatedStorage.MeltShared.SkinDarkMatter [ModuleScript]
-- y u r i

local var1 = Color3.fromHex
local var2 = var1("#000000")
local var3 = var1("#5A5A72")
local var4 = var1("#2C2B3B")
local var5 = var1("#25213B")
local var6 = var1("#B4B4D0")
local var7 = var1("#4A34C4")
local var8 = var1("#B8A6FF")
local var9 = var1("#D8CCFF")
local var10 = var1("#FFFFFF")
local var11 = var1("#5B3BE0")
local var12 = var1("#9C84FF")
local var13 = var1("#FFC58F")
local var14 = var1("#FFF4E6")
local var15 = var1("#6E4DF2")
local var16 = var1("#C8B6FF")
local var17 = var1("#34288F")
local var18 = var1("#7D66FF")
local var19 = var1("#9CA3F0")
local var20 = var1("#E2E7FF")
local var21 = var1("#5A539E")
local var22 = var1("#A48CFF")
local tbl1 = {
	hum = "rbxassetid://9125674129",
	equip = "rbxassetid://9114257451",
	click = "rbxassetid://9116493294",
	pulse = "rbxassetid://9120271166",
	settle = "rbxassetid://9116394876",
}

local function sound(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = Instance.new("Sound")
	var1.Name = "DarkMatter_" .. arg5
	var1.SoundId = arg2
	var1.Volume = arg3
	var1.PlaybackSpeed = arg4
	var1.RollOffMode = Enum.RollOffMode.InverseTapered
	var1.RollOffMinDistance = 4
	var1.RollOffMaxDistance = 40
	if arg6 then
		var1.PlaybackRegionsEnabled = true
		var1.PlaybackRegion = arg6
	end

	var1:SetAttribute("FxWhen", arg5)
	var1:SetAttribute("FxBaseSpeed", arg4)
	var1.Parent = arg1
	return var1
end

local var23 = Vector3.new
local function energy(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxEnergyLow", arg2)
		v1:SetAttribute("FxEnergyHigh", arg3)
		if arg4 then
			v1:SetAttribute("FxEnergyFadeLow", arg4)
			v1:SetAttribute("FxEnergyFadeHigh", arg5 or arg4)
		end

		v1.Color = arg2
	end

	return arg1
end

local var24 = Enum.Material
local function dims(arg1, arg2)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxSurgeDim", arg2)
	end

	return arg1
end

local function detail(arg1)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxDetail", true)
	end

	return arg1
end

local function movable(arg1, arg2, arg3)
	local var1 = arg2
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg2 }
	else
		var3 = arg2
	end

	for k1, v1 in var2(var3) do
		if v1:GetAttribute("FxRotateCenter") ~= nil then
			continue
		end

		arg1.rotate({ v1 }, arg3, Vector3.new(0, 0, 1), 0)
	end

	return arg2
end

local function inspectBy(arg1, arg2)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxInspect", arg2)
	end

	return arg1
end

local function faceStill(arg1, arg2, arg3, arg4)
	arg4 = arg4.Unit
	local var1 = CFrame.new(arg3) * CFrame.lookAt(Vector3.new(0, 0, 0), -arg4, if 0.95 < math.abs(arg4.Y) then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)) * CFrame.new(-arg3) * arg2:GetAttribute("SkinOffset")
	arg2.CFrame = arg1.handle.CFrame * var1
	local var3 = arg2:FindFirstChild("SkinWeld")
	if var3 then
		var3.C0 = var1
	end
end

local function band(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
	local var1 = arg4 * 2 * math.sin(3.1415926535897931 / arg9) * (arg12 or 1)
	local var2 = var1 + (if arg12 then 0 else arg5 * 0.2)
	local tbl1 = {}
	for i1 = 0, arg9 - 1 do
		if arg11 == nil or arg11(i1) then
			local var3 = arg2
			local var4 = CFrame.new(arg3) * arg10 * CFrame.Angles(0, 0, (i1 + 0.5) * 2 * 3.1415926535897931 / arg9) * CFrame.new(arg4, 0, 0)
			local var5 = var23(arg5, var2, arg6)
			local var6 = arg7
			local var7 = arg8
			table.insert(tbl1, arg1:add(var3, var4, var5, var6, var7))
		end
	end

	return tbl1
end

local function boost(arg1, arg2)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxBoost", arg2)
	end

	return arg1
end

local function radial(arg1, arg2, arg3, arg4, arg5, arg6)
	for k1, v1 in ipairs(arg1) do
		local var2 = v1:GetAttribute("SkinOffset")
		local var3 = if var2 then var2.Position - arg2 else Vector3.new(0, 0, 0)
		var3 = if 0.0001 < var3.Magnitude then var3.Unit else Vector3.new(0, 0, 0)
		v1:SetAttribute("FxInspect", var3 * arg3 + (arg4 or Vector3.new(0, 0, 0)))
		if arg5 then
			v1:SetAttribute("FxEquip", var3 * arg5)
		end

		if not arg6 then
			continue
		end

		v1:SetAttribute("FxSurge", var3 * arg6)
	end

	return arg1
end

local var25 = math.rad
local function singularity(arg1, arg2, arg3, arg4, arg5, arg6)
	local var3 = arg6
	arg6 = var3 or {}
	var3 = arg6.tilt
	var3 = var3 or CFrame.Angles(1.2915436464758039, 0, 0.17453292519943295)
	local var5 = arg6.radii
	local var6 = var3:VectorToWorldSpace(Vector3.new(0, 0, 1))
	local var7 = arg6.lift or Vector3.new(0, 0, 0)
	local var8 = arg6.spin or 110
	if not var5 then
		var5 = { 1.5, 2.05, 2.6 }
	end

	local tbl1 = { center = arg4 }
	if not arg6.noCore then
		tbl1.core = arg1:ball(arg3 .. "Horizon", arg4, arg5 * 2, var2, var24.Neon)
		movable(arg2, tbl1.core, arg4)
		inspectBy(tbl1.core, var7)
	end

	local var19 = CFrame.new(arg4) * CFrame.Angles(0, 1.5707963267948966, 0)
	local var22 = var23(0.01, arg5 * 2.2, arg5 * 2.2)
	local var26 = arg1:add(arg3 .. "Rim", var19, var22, var9, var24.Neon, { Shape = Enum.PartType.Cylinder })
	local var27 = arg5 * (arg6.halo or 2.9)
	local var28 = var23(0.008, var27, var27)
	local var29 = arg1:add(arg3 .. "Halo", var19 + Vector3.new(0, 0, -0.004), var28, var11, var24.Neon, { Shape = Enum.PartType.Cylinder, Transparency = 0.5 })
	energy(var26, var9, var10)
	energy(var29, var11, var12, 0.4, 0.25)
	dims(var26, 0.55)
	dims(var29, 0.85)
	local var30 = var29
	for k1, v1 in ipairs({ var26, var30 }) do
		arg2.rotate({ v1 }, arg4, Vector3.new(0, 0, 1), 0)
		v1:SetAttribute("FxFace", arg6.still or Vector3.new(0.85, 0.2, -0.49))
		inspectBy(v1, var7)
		faceStill(arg1, v1, arg4, arg6.still or Vector3.new(0.85, 0.2, -0.49))
	end

	tbl1.rim = var26
	tbl1.halo = var29
	local var31 = band(arg1, arg3 .. "Edge", arg4, arg5 * var5[1], arg5 * 0.16, arg5 * 0.07, var13, var24.Neon, 16, var3)
	energy(var31, var13, var14)
	arg2.rotate(var31, arg4, var6, var8)
	boost(var31, 3)
	radial(var31, arg4, arg5 * 0.5, var7, arg5 * 1.6, -arg5 * 0.28)
	var22 = band(arg1, arg3 .. "Band", arg4, arg5 * var5[2], arg5 * 0.34, arg5 * 0.05, var15, var24.Neon, 22, var3, function(arg1)
		local bool1 = false
		if arg1 % 11 ~= 3 then
			bool1 = arg1 % 11 ~= 8
		end

		return bool1
	end, 0.84)

	energy(var22, var15, var16, 0.12, 0)
	arg2.rotate(var22, arg4, var6, var8 * 0.5)
	boost(var22, 3)
	radial(var22, arg4, arg5 * 0.75, var7, arg5 * 2.2, -arg5 * 0.36)
	local var32 = band(arg1, arg3 .. "Outer", arg4, arg5 * var5[3], arg5 * 0.07, arg5 * 0.07, var17, var24.Neon, 18, var3)
	energy(var32, var17, var18)
	arg2.rotate(var32, arg4, var6, -var8 * 0.22)
	boost(var32, 2)
	radial(var32, arg4, arg5 * 1, var7, arg5 * 2.8, -arg5 * 0.3)
	detail(var32)
	tbl1.hot = var31
	tbl1.band = var22
	tbl1.outer = var32
	local tbl2 = { 1.78, 20 }
	local tbl3 = { 2.3, 130 }
	local tbl4 = {}
	for k2, v2 in ipairs({ tbl2, tbl3, { 1.92, 215 }, { 2.4, 300 } }) do
		local var33 = var25(v2[2])
		local var34 = arg5 * v2[1]
		local var35 = arg1:ball(arg3 .. "Drift", arg4 + var3:VectorToWorldSpace((var23(math.cos(var33) * var34, math.sin(var33) * var34, arg5 * 0.08))), arg5 * (0.1 + k2 % 2 * 0.03), var20, var24.Neon)
		arg2.rotate({ var35 }, arg4, var6, var8 * (var5[1] / v2[1]) ^ 1.5)
		boost(var35, 3)
		table.insert(tbl4, var35)
	end

	arg2.pulse(tbl4, var20, var21, 3.2, nil)
	dims(tbl4, 1)
	detail(tbl4)
	local var36 = arg1:ball(arg3 .. "Infall", arg4, arg5 * 3.2, var2, var24.SmoothPlastic, { Transparency = 1 })
	local function infall(arg1, arg2)
		local str1 = "#6A45F0"
		local tbl1 = { color = ColorSequence.new(var1("#FFF1E0"), var1(str1)), light = 1, locked = true }
		tbl1.life = NumberRange.new(0.35, 0.55)
		tbl1.speed = NumberRange.new(arg5 * 3, arg5 * 5)
		tbl1.rate = arg2
		local num1 = 1
		local var2 = arg5 * 0.04
		tbl1.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, arg5 * 0.35), NumberSequenceKeypoint.new(num1, var2) })
		tbl1.shape = Enum.ParticleEmitterShape.Sphere
		num1 = 1
		var2 = 0.9
		tbl1.alpha = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(num1, var2) })
		local var3 = arg2.emitter(arg1, var36, tbl1, arg1)
		var3.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
		var3:SetAttribute("FxNear", true)
		return var3
	end

	infall("active", arg6.sparks or 12)
	infall("burst:equip", 0):SetAttribute("FxBurst", 10)
	infall("burst:stop", 0):SetAttribute("FxBurst", 8)
	infall("burst:inspect", 0):SetAttribute("FxBurst", 16)
	infall("burst:surge", 0):SetAttribute("FxBurst", 12)
	tbl1.shell = var36
	return tbl1
end

local function voice(arg1, arg2)
	local var1 = Instance.new("Sound")
	var1.Name = "DarkMatter_loop"
	var1.SoundId = tbl1.hum
	var1.Volume = arg2 * 0.045
	var1.PlaybackSpeed = 1
	var1.RollOffMode = Enum.RollOffMode.InverseTapered
	var1.RollOffMinDistance = 4
	var1.RollOffMaxDistance = 40
	var1:SetAttribute("FxWhen", "loop")
	var1:SetAttribute("FxBaseSpeed", 1)
	var1.Parent = arg1
	var1:SetAttribute("FxLoopIdle", 0.55)
	local num1 = 0
	local num2 = 1.1
	sound(arg1, tbl1.equip, arg2 * 0.16, 1.5, "equip", NumberRange.new(num1, num2))
	local var2 = Instance.new("Sound")
	var2.Name = "DarkMatter_equip"
	var2.SoundId = tbl1.click
	var2.Volume = arg2 * 0.18
	var2.PlaybackSpeed = 0.72
	var2.RollOffMode = Enum.RollOffMode.InverseTapered
	var2.RollOffMinDistance = 4
	var2.RollOffMaxDistance = 40
	var2:SetAttribute("FxWhen", "equip")
	var2:SetAttribute("FxBaseSpeed", 0.72)
	var2.Parent = arg1
	var2 = Instance.new("Sound")
	var2.Name = "DarkMatter_start"
	var2.SoundId = tbl1.pulse
	var2.Volume = arg2 * 0.12
	var2.PlaybackSpeed = 0.55
	var2.RollOffMode = Enum.RollOffMode.InverseTapered
	var2.RollOffMinDistance = 4
	var2.RollOffMaxDistance = 40
	var2:SetAttribute("FxWhen", "start")
	var2:SetAttribute("FxBaseSpeed", 0.55)
	var2.Parent = arg1
	var2 = Instance.new("Sound")
	var2.Name = "DarkMatter_stop"
	var2.SoundId = tbl1.settle
	var2.Volume = arg2 * 0.1
	var2.PlaybackSpeed = 0.6
	var2.RollOffMode = Enum.RollOffMode.InverseTapered
	var2.RollOffMinDistance = 4
	var2.RollOffMaxDistance = 40
	var2:SetAttribute("FxWhen", "stop")
	var2:SetAttribute("FxBaseSpeed", 0.6)
	var2.Parent = arg1
	num1 = 0
	num2 = 2.6
	sound(arg1, tbl1.equip, arg2 * 0.2, 1, "inspect", NumberRange.new(num1, num2))
	var2 = Instance.new("Sound")
	var2.Name = "DarkMatter_surge"
	var2.SoundId = tbl1.pulse
	var2.Volume = arg2 * 0.07
	var2.PlaybackSpeed = 0.42
	var2.RollOffMode = Enum.RollOffMode.InverseTapered
	var2.RollOffMinDistance = 4
	var2.RollOffMaxDistance = 40
	var2:SetAttribute("FxWhen", "surge")
	var2:SetAttribute("FxBaseSpeed", 0.42)
	var2.Parent = arg1
end

local function stars(arg1, arg2, arg3)
	local tbl1 = {}
	for k1, v1 in ipairs(arg3) do
		local str1 = "Star"
		local var1 = v1
		local var2 = 0.022 + k1 % 3 * 0.006
		local var3 = var20
		local var4 = var24.Neon
		table.insert(tbl1, arg1:ball(str1, var1, var2, var3, var4))
	end

	arg2.pulse(tbl1, var20, var21, 5.5, nil)
	dims(tbl1, 0.9)
	return (detail(tbl1))
end

local function fasteners(arg1, arg2, arg3)
	for k1, v1 in ipairs(arg2) do
		arg1:ball("Fastener", v1, arg3 or 0.045, var6, var24.Metal, { Reflectance = 0.3 })
	end
end

local function equipFrom(arg1, arg2)
	local var1 = arg1
	local var2 = ipairs
	local var3
	if typeof(var1) == "Instance" then
		var3 = { arg1 }
	else
		var3 = arg1
	end

	for k1, v1 in var2(var3) do
		v1:SetAttribute("FxEquip", arg2)
	end

	return arg1
end

local tbl2 = {
	Hairdryer = function(arg1, arg2)
		arg1:hide("Body", "NozzleTip", "IntakeMesh", "IntakeHub")
		arg1:tube("DMVessel", 0, 0.95, -0.63, 0.56, 0.96, var19, var24.Glass, { Transparency = 0.9, Reflectance = 0.1 })
		arg1:tube("DMBulkhead", 0, 0.95, -0.76, -0.62, 1.1, var3, var24.Metal, { Reflectance = 0.18 })
		arg1:tube("DMBevel", 0, 0.95, -0.625, -0.61, 1.06, var6, var24.Metal, { Reflectance = 0.35 })
		arg1:tube("DMBevel", 0, 0.95, 0.545, 0.56, 1.06, var6, var24.Metal, { Reflectance = 0.35 })
		energy(arg1:tube("DMBulkheadSeam", 0, 0.95, -0.77, -0.755, 1, var7, var24.Neon), var7, var8)
		local num1 = 28
		for k1, v1 in ipairs({ 90, num1, 152, 208, 332 }) do
			local var1 = var25(v1)
			local var5 = if v1 == 90 then 0.49 else 0.5
			local var9 = var23(math.cos(var1) * var5, math.sin(var1) * var5 + 0.95, -0.63)
			local var10 = var23(math.cos(var1) * var5, math.sin(var1) * var5 + 0.95, 0.56)
			local str1 = "DMRail"
			local var11 = var9
			local var12 = var10
			local var15 = if v1 == 90 then 0.11 else 0.065
			arg1:rod(str1, var11, var12, var15, if v1 == 90 then var4 else var3, var24.Metal, { Reflectance = 0.2 })
			if v1 == 28 or v1 == 152 then
				local var18 = var9 + Vector3.new(0, 0.035, 0)
				local var20 = var10 + Vector3.new(0, 0.035, 0)
				energy(arg1:add("DMRailSeam", CFrame.lookAt((var18 + var20) / 2, var20), var23(0.016, 0.016, (var20 - var18).Magnitude), var7, var24.Neon), var7, var8)
			end
		end

		energy(arg1:add("DMSpineSeam", CFrame.lookAt(Vector3.new(0, 1.5, -0.04), Vector3.new(0, 1.5, 0.52)), var23(0.02, 0.02, Vector3.new(0, 0, 1.12).Magnitude), var7, var24.Neon), var7, var8)
		local num2 = 0.44
		for k2, v2 in ipairs({ -0.5, num2 }) do
			arg1:ring("DMHoop", var23(0, 0.95, v2), 0.505, 0.06, var3, var24.Metal, 18, nil, { Reflectance = 0.2 })
		end

		arg1:add("DMKeel", CFrame.new(0, 0.57, -0.05), Vector3.new(0.46, 0.22, 1.12), var4, var24.Metal, { Reflectance = 0.1 })
		energy(arg1:add("DMKeelSeam", CFrame.lookAt(Vector3.new(0.232, 0.62, -0.05), Vector3.new(0.232, 0.62, 0.45)), var23(0.016, 0.016, Vector3.new(0, 0, 1).Magnitude), var7, var24.Neon), var7, var8)
		energy(arg1:add("DMKeelSeam", CFrame.lookAt(Vector3.new(-0.232, 0.62, -0.05), Vector3.new(-0.232, 0.62, 0.45)), var23(0.016, 0.016, Vector3.new(0, 0, 1).Magnitude), var7, var24.Neon), var7, var8)
		arg1:rod("DMClamp", Vector3.new(0, 1.43, -0.05), Vector3.new(0, 1.26, -0.05), 0.08, var3, var24.Metal, { Reflectance = 0.2 })
		arg1:rod("DMClamp", Vector3.new(0, 0.67, -0.05), Vector3.new(0, 0.73, -0.05), 0.12, var3, var24.Metal, { Reflectance = 0.2 })
		local var21 = arg1
		local str2 = "DMClampTip"
		local var22 = Vector3.new(0, 0.73, -0.05)
		local var26 = Vector3.new(0, 1, 0)
		local num3 = 0.14
		local num4 = 0.02
		local var27 = var7
		local var28 = var24.Neon
		energy({
			arg2.disc(arg1, "DMClampTip", Vector3.new(0, 1.265, -0.05), Vector3.new(0, -1, 0), 0.12, 0.02, var7, var24.Neon),
			arg2.disc(var21, str2, var22, var26, num3, num4, var27, var28),
		}, var7, var8)

		num3 = {
			tilt = CFrame.lookAt(Vector3.new(0, 0, 0), -Vector3.new(0.5, 0.8, 0.33).Unit),
			spin = 120,
			lift = Vector3.new(0, 0.05, 0),
			sparks = 10,
		}

		num3.radii = { 1.45, 1.85, 2.25 }
		voice(singularity(arg1, arg2, "DMCore", Vector3.new(0, 0.96, -0.05), 0.19, num3).shell, 0.8)
		arg1:tube("DMLip", 0, 0.95, -1.45, -1.36, 0.76, var3, var24.Metal, { Reflectance = 0.18 })
		arg1:tube("DMThroat", 0, 0.95, -1.455, -1.44, 0.54, var2, var24.Neon)
		arg1:tube("DMBevel", 0, 0.95, -1.365, -1.355, 0.78, var6, var24.Metal, { Reflectance = 0.35 })
		local var29 = arg1:ring("DMNozzleRing", Vector3.new(0, 0.95, -1.46), 0.33, 0.028, var13, var24.Neon, 16, nil)
		energy(var29, var7, var14)
		arg2.rotate(var29, Vector3.new(0, 0.95, -1.46), Vector3.new(0, 0, 1), 60)
		boost(var29, 4)
		radial(var29, Vector3.new(0, 0.95, -1.46), 0.08, nil, 0.3)
		arg2.disc(arg1, "DMIntake", Vector3.new(0, 0.95, 0.93), Vector3.new(0, 0, 1), 0.56, 0.02, var2, var24.Neon)
		var21 = {}
		for i1 = 0, 5 do
			local str3 = "DMVane"
			local var30 = CFrame.new(Vector3.new(0, 0.95, 0.96)) * CFrame.Angles(0, 0, i1 * 3.1415926535897931 / 3) * CFrame.new(0.13, 0, 0) * CFrame.Angles(0.43633231299858238, 0, 0)
			local var31 = Vector3.new(0.2, 0.05, 0.02)
			local var32 = var3
			local var33 = var24.Metal
			table.insert(var21, arg1:add(str3, var30, var31, var32, var33))
		end

		arg2.rotate(var21, Vector3.new(0, 0.95, 0.96), Vector3.new(0, 0, 1), 40)
		boost(var21, 5)
		detail(var21)
		energy(arg1:ball("DMIntakeHub", Vector3.new(0, 0.95, 0.97), 0.08, var7, var24.Neon), var7, var8)
		stars(arg1, arg2, {
			Vector3.new(0.5, 0.95, -0.69),
			Vector3.new(-0.5, 1, -0.69),
			Vector3.new(0.42, 1.2, 0.6),
			Vector3.new(0.2, 0.6, 0.4),
		})
	end,
	HeatGun = function(arg1, arg2)
		arg1:hide("Body", "SidePanel", "HeatBadge", "HeatLine", "NozzleTaper", "NozzleTip")
		arg1:add("DMRearBody", CFrame.new(0, 1.02, 0.38), Vector3.new(0.86, 0.9, 0.5), arg1.pal.housing, var24.Metal, { Reflectance = 0.12 })
		arg1:add("DMTopPlate", CFrame.new(0, 1.42, -0.24), Vector3.new(0.88, 0.1, 0.74), var4, var24.Metal, { Reflectance = 0.12 })
		arg1:add("DMFloor", CFrame.new(0, 0.63, -0.24), Vector3.new(0.88, 0.12, 0.74), var4, var24.Metal, { Reflectance = 0.12 })
		local num1 = 1
		for k1, v1 in ipairs({ -1, num1 }) do
			local num2 = 0.09
			for k2, v2 in ipairs({ -0.57, num2 }) do
				arg1:add("DMPost", CFrame.new(v1 * 0.395, 1.02, v2), Vector3.new(0.09, 0.7, 0.08), var3, var24.Metal, { Reflectance = 0.2 })
			end

			arg1:add("DMBevel", CFrame.new(v1 * 0.442, 1.475, -0.24), Vector3.new(0.012, 0.02, 0.74), var6, var24.Metal, { Reflectance = 0.35 })
			arg1:add("DMBevel", CFrame.new(v1 * 0.442, 0.575, -0.24), Vector3.new(0.012, 0.02, 0.74), var6, var24.Metal, { Reflectance = 0.35 })
		end

		local num3 = 1
		local var1 = CFrame.Angles(0, 1.5707963267948966, 0)
		for k3, v3 in ipairs({ -1, num3 }) do
			local var9 = var23(v3 * 0.44, 1.0199999809265137, -0.23999999463558197)
			arg1:ring("DMPortBezel", var9, 0.335, 0.08, var3, var24.Metal, 18, var1, { Reflectance = 0.2 })
			energy(arg1:ring("DMPortCoil", var9 + var23(v3 * 0.012, 0, 0), 0.29, 0.02, var7, var24.Neon, 18, var1), var7, var8)
			arg2.disc(arg1, "DMPortGlass", var23(v3 * 0.425, 1.0199999809265137, -0.23999999463558197), var23(v3, 0, 0), 0.6, 0.01, var19, var24.Glass, { Transparency = 0.9, Reflectance = 0.1 })
			local tbl1 = {}
			for i1 = 0, 5 do
				local var10 = i1 * 3.1415926535897931 / 3 + 0.52359877559829882
				table.insert(tbl1, var9 + var23(v3 * 0.045, math.cos(var10) * 0.335, math.sin(var10) * 0.335))
			end

			fasteners(arg1, tbl1, 0.04)
		end

		voice(singularity(arg1, arg2, "DMCore", Vector3.new(0, 1.02, -0.24), 0.12, {
			tilt = CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.Angles(0.27925268031909273, 0, 0),
			spin = 130,
			lift = Vector3.new(0, 0.03, 0),
			still = Vector3.new(1, 0.15, -0.2),
			sparks = 8,
		}).shell, 0.9)

		local num4 = 1
		for k4, v4 in ipairs({ -1, num4 }) do
			for i2 = 0, (if 0 < v4 then 3 else 2) - 1 do
				arg2.plate(arg1, "DMShield", var23(v4 * (i2 * 0.026 + 0.48), 1.02, i2 * 0.1 + -0.92), var23(v4, 0, 0), 0.52 - i2 * 0.1, 0.84 - i2 * 0.18, 0.026, if i2 % 2 == 0 then var5 else var4, var24.Metal)
			end

			local var11 = var23(v4 * 0.56, 1.29, -1.06)
			local var12 = var23(v4 * 0.56, 1.29, -0.68)
			energy(arg1:add("DMShieldSeam", CFrame.lookAt((var11 + var12) / 2, var12), var23(0.016, 0.016, (var12 - var11).Magnitude), var7, var24.Neon), var7, var8)
			energy(arg2.plate(arg1, "DMVentGlow", var23(v4 * 0.43, 0.98, 0.36), var23(v4, 0, 0), 0.5, 0.56, 0.008, var7, var24.Neon, { Transparency = 0.5 }), var7, var8, 0.5, 0.15)
		end

		local num5 = 1
		for k5, v5 in ipairs({ -1, num5 }) do
			arg1:add("DMBevel", CFrame.new(v5 * 0.483, 1.553, -0.9), Vector3.new(0.02, 0.02, 0.62), var6, var24.Metal, { Reflectance = 0.35 })
		end

		local num6 = -0.12
		for k6, v6 in ipairs({ -0.28, num6, 0.12, 0.28 }) do
			arg1:add("DMFin", CFrame.new(v6, 1.61, -0.92), Vector3.new(0.03, 0.12, 0.5), var3, var24.Metal, { Reflectance = 0.15 })
			energy(arg1:add("DMFinTip", CFrame.new(v6, 1.675, -0.92), Vector3.new(0.032, 0.012, 0.46), var7, var24.Neon), var7, var8)
		end

		arg1:tube("DMFocus1", 0, 1.04, -1.86, -1.78, 0.46, var3, var24.Metal, { Reflectance = 0.15 })
		arg1:tube("DMFocus2", 0, 1.04, -1.96, -1.9, 0.4, var4, var24.Metal)
		arg1:tube("DMFocus3", 0, 1.04, -2.05, -2, 0.33, var3, var24.Metal)
		arg1:tube("DMThroat", 0, 1.04, -2.08, -2.05, 0.22, var2, var24.Neon)
		local tbl2 = { -1.88, 0.2 }
		local tbl3 = { -1.975, 0.17 }
		for k7, v7 in ipairs({ tbl2, tbl3, { -2.07, 0.14 } }) do
			local var17 = var23(0, 1.04, v7[1])
			local var18 = arg1:ring("DMFocusRing", var17, v7[2], 0.024, var15, var24.Neon, 12, nil)
			local var20 = energy
			local var21 = var18
			local var22 = if k7 == 3 then var13 else var15
			var20(var21, var22, if k7 == 3 then var14 else var16)
			var20 = arg2.rotate
			var21 = var18
			var22 = var17
			local var25 = Vector3.new(0, 0, 1)
			var20(var21, var22, var25, if k7 % 2 == 0 then -90 else 90)
			boost(var18, 4)
			inspectBy(var18, (var23(0, 0, -0.07 * k7)))
			equipFrom(var18, (var23(0, 0, 0.12 * k7)))
		end

		local num7 = 0
		for k8, v8 in ipairs({ -0.12, num7, 0.12 }) do
			energy(arg1:add("DMRearSlot", CFrame.new(0, 1 + v8, 1.105), Vector3.new(0.4, 0.028, 0.012), var7, var24.Neon), var7, var8)
		end

		stars(arg1, arg2, {
			Vector3.new(0.3, 1.475, -0.45),
			Vector3.new(-0.25, 1.475, -0.05),
			Vector3.new(0.44, 1.3, 0.3),
			Vector3.new(-0.44, 1.32, 0.52),
		})
	end,
	SteamBlaster = function(arg1, arg2)
		arg1:hide("Body", "ChamberEnd")
		arg1:tube("DMVessel", 0, 1.3, -0.3, 0.6, 1.08, var19, var24.Glass, { Transparency = 0.88, Reflectance = 0.12 })
		local tbl1 = { 0.6, 0.72, 0.74 }
		for k1, v1 in ipairs({ { -0.42, -0.3, -0.44 }, tbl1 }) do
			arg1:tube("DMVesselCap", 0, 1.3, v1[1], v1[2], 1.14, var3, var24.Metal, { Reflectance = 0.18 })
			arg1:ball("DMVesselDome", var23(0, 1.3, v1[3]), 0.86, var4, var24.Metal, { Reflectance = 0.1 })
		end

		local num1 = 0.605
		for k2, v2 in ipairs({ -0.305, num1 }) do
			arg1:tube("DMBevel", 0, 1.3, v2 - 0.008, v2 + 0.008, 1.16, var6, var24.Metal, { Reflectance = 0.35 })
		end

		local num2 = 0.45
		for k3, v3 in ipairs({ -0.15, num2 }) do
			energy(arg1:tube("DMVesselSeam", 0, 1.3, v3 - 0.055, v3 - 0.04, 1.205, var7, var24.Neon), var7, var8)
		end

		local num3 = 25
		for k4, v4 in ipairs({ 345, num3, 70, 115 }) do
			local var5 = var25(v4)
			arg1:rod("DMCageBar", var23(math.cos(var5) * 0.56, math.sin(var5) * 0.56 + 1.3, -0.31), var23(math.cos(var5) * 0.56, math.sin(var5) * 0.56 + 1.3, 0.61), 0.05, var3, var24.Metal, { Reflectance = 0.2 })
		end

		arg1:rod("DMClamp", Vector3.new(0, 1.84, 0.15), Vector3.new(0, 1.62, 0.15), 0.08, var3, var24.Metal, { Reflectance = 0.2 })
		arg1:rod("DMClamp", Vector3.new(0, 0.88, 0.15), Vector3.new(0, 1, 0.15), 0.12, var3, var24.Metal, { Reflectance = 0.2 })
		local var9 = arg1
		local str1 = "DMClampTip"
		local var10 = Vector3.new(0, 1, 0.15)
		local var11 = Vector3.new(0, 1, 0)
		local num4 = 0.15
		local num5 = 0.02
		local var12 = var7
		local var13 = var24.Neon
		energy({
			arg2.disc(arg1, "DMClampTip", Vector3.new(0, 1.625, 0.15), Vector3.new(0, -1, 0), 0.13, 0.02, var7, var24.Neon),
			arg2.disc(var9, str1, var10, var11, num4, num5, var12, var13),
		}, var7, var8)

		var10 = {
			tilt = CFrame.lookAt(Vector3.new(0, 0, 0), -Vector3.new(0.5, 0.8, 0.33).Unit),
			spin = 100,
			lift = Vector3.new(0, 0.05, 0),
			sparks = 10,
		}

		var10.radii = { 1.4, 1.8, 2.2 }
		local var14 = singularity(arg1, arg2, "DMCore", Vector3.new(0, 1.3, 0.15), 0.2, var10)
		arg1:ring("DMFieldRing", Vector3.new(0, 1.3, 0.15), 0.5, 0.03, var3, var24.Metal, 20, CFrame.Angles(1.5707963267948966, 0, 0), { Reflectance = 0.25 })
		voice(var14.shell, 1)
		var10 = { "active", 14 }
		local var15 = arg1:ball("DMVapour", Vector3.new(0, 1.3, 0.15), 1, var2, var24.SmoothPlastic, { Transparency = 1 })
		for k5, v5 in ipairs({ { "always", 3 }, var10 }) do
			local str2 = "#3E5BFF"
			var12 = {
				texture = "rbxasset://textures/particles/smoke_main.dds",
				color = ColorSequence.new(var1("#A898FF"), var1(str2)),
				light = 0.6,
				locked = true,
			}

			var12.life = NumberRange.new(1.2, 1.7)
			var12.speed = NumberRange.new(0.2, 0.4)
			var12.rate = v5[2]
			local num6 = 1
			local num7 = 0.04
			var12.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(num6, num7) })
			num7 = 1
			local num8 = 1
			var12.alpha = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0.75),
				NumberSequenceKeypoint.new(0.5, 0.6),
				NumberSequenceKeypoint.new(num7, num8),
			})

			var12.rot = NumberRange.new(-40, 40)
			var12.shape = Enum.ParticleEmitterShape.Sphere
			var11 = arg2.emitter(arg1, var15, var12, v5[1])
			var11.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
			var11:SetAttribute("FxNear", true)
		end

		energy(arg1:add("DMConduit", CFrame.lookAt(Vector3.new(0.64, 1.1, -0.2), Vector3.new(0.64, 1.1, 0.22)), var23(0.026, 0.026, Vector3.new(0, 0, 0.84).Magnitude), var7, var24.Neon), var7, var8)
		local num9 = 1
		for k6, v6 in ipairs({ -1, num9 }) do
			arg1:add("DMGuide", CFrame.new(0, 1.1 + v6 * 0.43, -1.3), Vector3.new(1.12, 0.045, 0.32), var3, var24.Metal, { Reflectance = 0.15 })
			energy(arg1:add("DMGuideEdge", CFrame.new(0, 1.1 + v6 * 0.43, -1.47), Vector3.new(1.1, 0.02, 0.02), var7, var24.Neon), var7, var8)
		end

		local num10 = 1
		for k7, v7 in ipairs({ -1, num10 }) do
			var11 = var23(v7 * 0.505, 0.5, -1)
			num4 = var23(v7 * 0.505, 0.5, 0.72)
			energy(arg1:add("DMCasingSeam", CFrame.lookAt((var11 + num4) / 2, num4), var23(0.014, 0.014, (num4 - var11).Magnitude), var7, var24.Neon), var7, var8)
			var13 = -0.5
			for k8, v8 in ipairs({ -0.85, var13, 0.25, 0.6 }) do
				arg1:add("DMCasingRib", CFrame.new(v7 * 0.515, 0.67, v8), Vector3.new(0.04, 0.38, 0.07), var3, var24.Metal, { Reflectance = 0.2 })
			end

			arg1:add("DMBevel", CFrame.new(v7 * 0.503, 0.888, -0.15), Vector3.new(0.02, 0.02, 1.9), var6, var24.Metal, { Reflectance = 0.35 })
		end

		stars(arg1, arg2, {
			Vector3.new(0.52, 0.72, -0.68),
			Vector3.new(0.52, 0.62, 0.42),
			Vector3.new(-0.52, 0.74, -0.3),
			Vector3.new(-0.52, 0.6, 0.42),
		})
	end,
	Flamethrower = function(arg1, arg2)
		arg1:hide("HeatVent", "BarrelRib", "MuzzleRing", "MuzzleCone", "CageBar", "MuzzleFront")
		local var9 = CFrame.new(Vector3.new(0, 1.65, -0.75)) * CFrame.Angles(0, 0, 1.5707963267948966)
		arg1:add("DMFoot", var9, Vector3.new(0.1, 0.62, 0.62), var3, var24.Metal, { Shape = Enum.PartType.Cylinder, Reflectance = 0.18 })
		energy(arg2.disc(arg1, "DMFootSeam", Vector3.new(0, 1.7, -0.75), Vector3.new(0, 1, 0), 0.56, 0.012, var7, var24.Neon), var7, var8)
		local tbl1 = {}
		for i1 = 0, 5 do
			local var10 = i1 * 3.1415926535897931 / 3
			table.insert(tbl1, Vector3.new(0, 1.6, -0.75) + var23(math.cos(var10) * 0.26, 0.1, math.sin(var10) * 0.26))
		end

		fasteners(arg1, tbl1, 0.04)
		arg1:rod("DMColumn", Vector3.new(0, 1.7, -0.75), Vector3.new(0, 1.77, -0.75), 0.24, var6, var24.Metal, { Reflectance = 0.35 })
		local var11 = CFrame.Angles(1.5707963267948966, 0, 0)
		arg1:ring("DMCradle", Vector3.new(0, 1.8, -0.75), 0.32, 0.05, var3, var24.Metal, 18, var11, { Reflectance = 0.2 })
		energy(arg1:ring("DMCradleGlow", Vector3.new(0, 1.83, -0.75), 0.32, 0.016, var7, var24.Neon, 18, var11), var7, var8)
		for i2 = 0, 2 do
			local var12 = var25(i2 * 120 + 90)
			local var16 = var23(math.cos(var12) * 0.32 + 0, 1.78, math.sin(var12) * 0.32 + -0.75)
			arg1:rod("DMCradleArm", Vector3.new(0, 1.6, -0.75) + var23(math.cos(var12) * 0.14, 0.14, math.sin(var12) * 0.14), var16, 0.055, var3, var24.Metal, { Reflectance = 0.2 })
			energy(arg2.disc(arg1, "DMNode", var16 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), 0.08, 0.02, var7, var24.Neon), var7, var8)
		end

		local tbl2 = {
			tilt = CFrame.lookAt(Vector3.new(0, 0, 0), -Vector3.new(0.45, 0.85, 0.28).Unit),
			spin = 120,
			lift = Vector3.new(0, 0.1, 0),
			sparks = 16,
		}

		tbl2.radii = { 1.45, 1.9, 2.3 }
		local var17 = singularity(arg1, arg2, "DMCore", Vector3.new(0, 2.3, -0.75), 0.18, tbl2)
		local var18 = arg1:ring("DMGyroA", Vector3.new(0, 2.3, -0.75), 0.46, 0.035, var3, var24.Metal, 20, nil, { Reflectance = 0.25 })
		arg2.rotate(var18, Vector3.new(0, 2.3, -0.75), Vector3.new(1, 0, 0), 16)
		boost(var18, 3)
		radial(var18, Vector3.new(0, 2.3, -0.75), 0.07, Vector3.new(0, 0.1, 0), 0.22)
		local var19 = arg1:ring("DMGyroB", Vector3.new(0, 2.3, -0.75), 0.52, 0.03, var6, var24.Metal, 22, CFrame.Angles(0, 1.5707963267948966, 0), { Reflectance = 0.35 })
		arg2.rotate(var19, Vector3.new(0, 2.3, -0.75), Vector3.new(0, 0, 1), -11)
		boost(var19, 3)
		radial(var19, Vector3.new(0, 2.3, -0.75), 0.09, Vector3.new(0, 0.1, 0), 0.3)
		detail(var19)
		voice(var17.shell, 1.1)
		tbl2 = -2.05
		local num1 = -2.3
		for k1, v1 in ipairs({ tbl2, num1, -2.55, -2.78 }) do
			local var20 = arg1:tube("DMCoil", 0, 1.05, v1 - 0.035, v1 + 0.035, 0.58, var3, var24.Metal, { Reflectance = 0.15 })
			local var21 = energy(arg1:tube("DMCoilGlow", 0, 1.05, v1 - 0.012, v1 + 0.012, 0.6, var7, var24.Neon), var7, var8)
			movable(arg2, { var20, var21 }, (var23(0, 1.05, v1)))
			inspectBy({ var20, var21 }, (var23(0, 0, -0.06 * k1)))
			equipFrom({ var20, var21 }, (var23(0, 0, 0.1 * k1)))
		end

		energy(arg1:add("DMBarrelConduit", CFrame.lookAt(Vector3.new(0, 1.27, -2.395), Vector3.new(0, 1.27, -2.84)), var23(0.026, 0.026, Vector3.new(0, 0, -0.89).Magnitude), var7, var24.Neon), var7, var8)
		arg1:tube("DMThroat", 0, 1.05, -3.28, -2.9, 0.5, var2, var24.Neon)
		arg1:ring("DMMuzzleRing", Vector3.new(0, 1.05, -3.28), 0.5, 0.12, var3, var24.Metal, 16, nil, { Reflectance = 0.15 })
		arg1:ring("DMMuzzleBevel", Vector3.new(0, 1.05, -3.345), 0.5, 0.025, var6, var24.Metal, 16, nil, { Reflectance = 0.35 })
		arg1:ring("DMMuzzleBack", Vector3.new(0, 1.05, -2.92), 0.42, 0.09, var4, var24.Metal, 12, nil)
		for i3 = 0, 3 do
			local var22 = var25(i3 * 90 + 45)
			local var26 = var23(math.cos(var22) * 0.42, math.sin(var22) * 0.42 + 1.05, -2.92)
			local var27 = var23(math.cos(var22) * 0.52, math.sin(var22) * 0.52 + 1.05, -3.26)
			arg1:rod("DMProng", var26, var27, 0.09, var3, var24.Metal)
			local var28 = var26 + (var26 - var23(0, 1.05, var26.Z)).Unit * 0.05
			local var29 = var27 + (var27 - var23(0, 1.05, var27.Z)).Unit * 0.05
			energy(arg1:add("DMProngSeam", CFrame.lookAt((var28 + var29) / 2, var29), var23(0.016, 0.016, (var29 - var28).Magnitude), var7, var24.Neon), var7, var8)
		end

		local var30 = arg1:ring("DMMuzzleAccretion", Vector3.new(0, 1.05, -3.2), 0.37, 0.035, var13, var24.Neon, 18, nil)
		energy(var30, var15, var14)
		arg2.rotate(var30, Vector3.new(0, 1.05, -3.2), Vector3.new(0, 0, 1), 60)
		boost(var30, 6)
		radial(var30, Vector3.new(0, 1.05, -3.2), 0.1, nil, 0.4)
		local str1 = "DMMuzzleCounter"
		local var31 = Vector3.new(0, 1.05, -3.08)
		local num2 = 0.44
		local num3 = 0.02
		local var32 = var3
		local var33 = var24.Metal
		local num4 = 14
		local var34 = nil
		local var35 = detail(arg1:ring(str1, var31, num2, num3, var32, var33, num4, var34))
		arg2.rotate(var35, Vector3.new(0, 1.05, -3.08), Vector3.new(0, 0, 1), -30)
		boost(var35, 3)
		num4 = "#7A5CFF"
		var31 = arg2.anchor(arg1, "DMEdge", Vector3.new(0, 1.05, -3.3), Vector3.new(0, 0, -1))
		num2 = { color = ColorSequence.new(var1("#E6E0FF"), var1(num4)), rate = 18, light = 1 }
		num2.life = NumberRange.new(0.16, 0.26)
		num2.speed = NumberRange.new(28, 40)
		num2.spread = Vector2.new(7, 7)
		var34 = 1
		local num5 = 0.02
		num2.size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(var34, num5) })
		var34 = 1
		num5 = 1
		num2.alpha = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(var34, num5) })
		local var36 = arg2.emitter(arg1, var31, num2, "active")
		var36:SetAttribute("FxNear", true)
		var32 = 1
		for k2, v2 in ipairs({ -1, var32 }) do
			arg2.plate(arg1, "DMArmour", var23(v2 * 0.432, 1.02, -0.55), var23(v2, 0, 0), 1.1, 0.26, 0.026, var5, var24.DiamondPlate)
			var33 = var23(v2 * 0.46, 1.16, -1.1)
			num4 = var23(v2 * 0.46, 1.16, 0)
			energy(arg1:add("DMArmourSeam", CFrame.lookAt((var33 + num4) / 2, num4), var23(0.016, 0.016, (num4 - var33).Magnitude), var7, var24.Neon), var7, var8)
			local num6 = -0.55
			var33 = {}
			for k3, v3 in ipairs({ -1.05, num6, -0.05 }) do
				table.insert(var33, (var23(v2 * 0.462, 1.09, v3)))
				table.insert(var33, (var23(v2 * 0.462, 0.95, v3)))
			end

			fasteners(arg1, var33, 0.035)
		end

		local num7 = 1
		for k4, v4 in ipairs({ -1, num7 }) do
			arg1:add("DMBevel", CFrame.new(v4 * 0.423, 1.6, -0.45), Vector3.new(0.02, 0.02, 1.7), var6, var24.Metal, { Reflectance = 0.35 })
			arg1:add("DMBevel", CFrame.new(v4 * 0.393, 0.625, -0.55), Vector3.new(0.02, 0.02, 2.3), var6, var24.Metal, { Reflectance = 0.35 })
		end

		arg1:wedge("DMFin", CFrame.new(-0.2, 1.72, -0.2), Vector3.new(0.05, 0.24, 0.5), var4, var24.Metal)
		energy(arg1:add("DMFinEdge", CFrame.lookAt(Vector3.new(-0.2, 1.7225, -0.2), Vector3.new(-0.2, 1.84, 0.04)), var23(0.03, 0.03, Vector3.new(0, 0.235, 0.48).Magnitude), var7, var24.Neon), var7, var8)
		local num8 = -0.12
		for k5, v5 in ipairs({ -0.24, num8, 0, 0.12, 0.24 }) do
			arg1:add("DMHeatSink", CFrame.new(v5, 1.05, 0.93), Vector3.new(0.025, 0.4, 0.06), var3, var24.Metal)
			energy(arg1:add("DMHeatSinkTip", CFrame.new(v5, 1.26, 0.93), Vector3.new(0.027, 0.012, 0.062), var7, var24.Neon), var7, var8)
		end

		stars(arg1, arg2, {
			Vector3.new(0.47, 1.05, -0.95),
			Vector3.new(0.47, 0.98, -0.25),
			Vector3.new(-0.47, 1.06, -0.7),
			Vector3.new(-0.47, 0.97, -0.1),
			Vector3.new(0.3, 1.61, -1.2),
		})
	end,
	FireGrenade = function(arg1, arg2)
		arg1:hide("Emblem", "EmblemFlame", "EmblemFlake")
		local var3 = arg1.handle
		var3.Color = var2
		var3.Material = var24.Neon
		var3.Reflectance = 0
		local tbl2 = {
			noCore = true,
			tilt = CFrame.Angles(1.2566370614359172, 0, 0.20943951023931956),
			halo = 2.5,
			spin = 70,
			lift = Vector3.new(0, 0.04, 0),
			sparks = 6,
		}

		tbl2.radii = { 1.28, 1.58, 1.86 }
		local num1 = 0.35
		local var4 = singularity(arg1, arg2, "DMCore", Vector3.new(0, 0, 0), num1, tbl2)
		for k1, v1 in ipairs(var4.hot) do
			tbl2 = var23(0.045, v1.Size.Y, 0.02)
			v1.Size = tbl2
		end

		for k2, v2 in ipairs(var4.band) do
			tbl2 = var23(0.09, v2.Size.Y, 0.014)
			v2.Size = tbl2
		end

		for k3, v3 in ipairs(var4.outer) do
			tbl2 = var23(0.018, v3.Size.Y, 0.018)
			v3.Size = tbl2
		end

		boost(var4.hot, 5)
		boost(var4.band, 5)
		local num2 = 0.2
		for k4, v4 in ipairs({ -0.2, num2 }) do
			energy(arg2.disc(arg1, "DMCollarSeam", var23(0, v4, 0), Vector3.new(0, 1, 0), 0.6, 0.012, var7, var24.Neon), var7, var8)
		end

		local var5 = arg1:ball("DMTrailRoot", Vector3.new(0, 0, 0), 0.05, var2, var24.SmoothPlastic, { Transparency = 1 })
		local var6 = Instance.new("Attachment")
		var6.Position = Vector3.new(0, 0.12, 0)
		var6.Parent = var5
		local var9 = Instance.new("Attachment")
		var9.Position = Vector3.new(0, -0.12, 0)
		var9.Parent = var5
		local var10 = Instance.new("Trail")
		var10.Name = "SkinFx"
		var10.Attachment0 = var6
		var10.Attachment1 = var9
		var10.Lifetime = 0.25
		local str1 = "#3D5BFF"
		var10.Color = ColorSequence.new(var1("#C9BCFF"), var1(str1))
		var10.Transparency = NumberSequence.new(0.35, 1)
		var10.LightEmission = 1
		var10.FaceCamera = true
		var10.Enabled = false
		var10:SetAttribute("FxWhen", "active")
		var10.Parent = var5
		local var11 = Instance.new("Sound")
		var11.Name = "DarkMatter_equip"
		var11.SoundId = tbl1.click
		var11.Volume = 0.16
		var11.PlaybackSpeed = 0.8
		var11.RollOffMode = Enum.RollOffMode.InverseTapered
		var11.RollOffMinDistance = 4
		var11.RollOffMaxDistance = 40
		var11:SetAttribute("FxWhen", "equip")
		var11:SetAttribute("FxBaseSpeed", 0.8)
		var11.Parent = var4.shell
		local var12 = Instance.new("Sound")
		var12.Name = "DarkMatter_loop"
		var12.SoundId = tbl1.hum
		var12.Volume = 0.03
		var12.PlaybackSpeed = 1.3
		var12.RollOffMode = Enum.RollOffMode.InverseTapered
		var12.RollOffMinDistance = 4
		var12.RollOffMaxDistance = 40
		var12:SetAttribute("FxWhen", "loop")
		var12:SetAttribute("FxBaseSpeed", 1.3)
		var12.Parent = var4.shell
		var12:SetAttribute("FxLoopIdle", 0.4)
		var11 = Instance.new("Sound")
		var11.Name = "DarkMatter_surge"
		var11.SoundId = tbl1.pulse
		var11.Volume = 0.05
		var11.PlaybackSpeed = 0.5
		var11.RollOffMode = Enum.RollOffMode.InverseTapered
		var11.RollOffMinDistance = 4
		var11.RollOffMaxDistance = 40
		var11:SetAttribute("FxWhen", "surge")
		var11:SetAttribute("FxBaseSpeed", 0.5)
		var11.Parent = var4.shell
	end,
}

return {
	Sounds = tbl1,
	build = function(arg1, arg2)
		local var1 = tbl2[arg1.weapon]
		assert(var1, "Dark Matter has no build for " .. tostring(arg1.weapon))
		var1(arg1, arg2)
	end,
	burst = function(arg1, arg2, arg3, arg4, _)
		local var1 = game:GetService("TweenService")
		local var3 = Instance.new("Folder")
		var3.Name = "DarkMatterBurst"
		var3.Parent = arg3
		local var4 = CFrame.new(arg1)
		local var5 = arg2 * 0.75
		local var6 = if arg4 then 10 else 20
		local var7 = var5 * 2 * math.sin(3.1415926535897931 / var6) + 0.1
		for i1 = 0, var6 - 1 do
			local var8 = (i1 + 0.5) * 2 * 3.1415926535897931 / var6
			local var9 = var4 * CFrame.Angles(0, var8, 0) * CFrame.new(var5, 0, 0)
			local var10 = Instance.new("Part")
			local var11 = var23(0.12, 0.12, var7)
			var10.Name = "Collapse"
			var10.Shape = Enum.PartType.Block
			var10.Size = var11
			var10.CFrame = var9
			var10.Color = var14
			var10.Material = var24.Neon
			var10.Transparency = 0.1
			var10.Anchored = true
			var10.CanCollide = false
			var10.CanQuery = false
			var10.CanTouch = false
			var10.CastShadow = false
			var10.Parent = var3
			local var12 = TweenInfo.new(0.24, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			var1:Create(var10, var12, {
				CFrame = var4 * CFrame.Angles(0, var8, 0) * CFrame.new(0.2, 0, 0),
				Size = Vector3.new(0.06, 0.06, 0.1),
				Transparency = 0.6,
			}):Play()

		end

		local var13 = Instance.new("Part")
		var13.Name = "Void"
		local var15 = Enum.PartType.Ball
		var13.Shape = var15 or Enum.PartType.Block
		var13.Size = Vector3.new(0.2, 0.2, 0.2)
		var13.CFrame = var4
		var13.Color = var2
		var13.Material = var24.Neon
		var13.Transparency = 0
		var13.Anchored = true
		var13.CanCollide = false
		var13.CanQuery = false
		var13.CanTouch = false
		var13.CastShadow = false
		var13.Parent = var3
		var15 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var1:Create(var13, var15, { Size = Vector3.new(1, 1, 1) * arg2 * 0.3 }):Play()
		task.delay(0.22, function()
			if var13.Parent then
				var1:Create(var13, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Size = Vector3.new(0.05, 0.05, 0.05), Transparency = 1 }):Play()
			end

			for k1, v1 in ipairs(var3:GetChildren()) do
				if v1.Name ~= "Collapse" then
					continue
				end

				v1.Transparency = 1
			end

			if not arg4 then
				local var2 = Instance.new("Part")
				var2.Name = "Lensing"
				local var5 = Enum.PartType.Ball
				var2.Shape = var5 or Enum.PartType.Block
				var2.Size = Vector3.new(1, 1, 1) * arg2 * 0.4
				var2.CFrame = var4
				var2.Color = var22
				var2.Material = var24.ForceField
				var2.Transparency = 0
				var2.Anchored = true
				var2.CanCollide = false
				var2.CanQuery = false
				var2.CanTouch = false
				var2.CastShadow = false
				var2.Parent = var3
				local var6 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				var1:Create(var2, var6, { Size = Vector3.new(1, 1, 1) * arg2 * 1.7, Transparency = 1 }):Play()
			end
		end)

		local var16 = Instance.new("Sound")
		var16.SoundId = tbl1.pulse
		var16.Volume = 0.3
		var16.PlaybackSpeed = 0.5
		var16.RollOffMaxDistance = 80
		for k1, v1 in ipairs(game:GetService("SoundService"):GetDescendants()) do
			if not v1:IsA("SoundGroup") then
				continue
			end

			if string.sub(v1.Name, -7) ~= "Effects" then
				continue
			end

			var16.SoundGroup = v1
			break
		end

		local var17 = Instance.new("Part")
		var17.Name = "Sound"
		var17.Shape = Enum.PartType.Block
		var17.Size = Vector3.new(0.1, 0.1, 0.1)
		var17.CFrame = var4
		var17.Color = var2
		var17.Material = var24.SmoothPlastic
		var17.Transparency = 1
		var17.Anchored = true
		var17.CanCollide = false
		var17.CanQuery = false
		var17.CanTouch = false
		var17.CastShadow = false
		var17.Parent = var3
		var16.Parent = var17
		var16:Play()
		task.delay(1.2, function()
			var3:Destroy()
		end)
	end,
}

--- ReplicatedStorage.MeltShared.Vip [ModuleScript]
-- y u r i

local tbl1 = { GemMultiplier = 1.5, BonusPercent = 50, DailyGems = 500, DaySeconds = 86400 }
tbl1.runGems = function(arg1, arg2, arg3)
	local var2 = math.floor(arg1 * arg2 + 0.5)
	if not arg3 then
		return var2, var2 - arg1, 0
	end

	local var3 = math.floor(arg1 * arg2 * tbl1.GemMultiplier + 0.5 + 1e-09)
	return var3, var2 - arg1, var3 - var2
end

tbl1.day = function(arg1)
	return arg1 // tbl1.DaySeconds
end

tbl1.nextDayAt = function(arg1)
	return (arg1 + 1) * tbl1.DaySeconds
end

return tbl1

--- Workspace.hspspjl.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

