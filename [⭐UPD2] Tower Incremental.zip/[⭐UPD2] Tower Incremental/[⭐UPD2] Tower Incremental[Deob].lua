--- Players.LocalPlayer.PlayerScripts.InitClient [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "DataService"
require(var1:WaitForChild("Packages"):WaitForChild(str1)).client:init()
local str2 = "WoodClient"
local var2 = var1:WaitForChild("Client", 30)
for k1, v1 in ipairs({
	"Preload",
	"ButtonEffects",
	"GamepadUI",
	"PlatformReport",
	"CodesUI",
	"WheelClient",
	"CurrencyHUD",
	"SettingsUI",
	"GiftUI",
	"ShopUI",
	"CoinDrop",
	"StairClient",
	"AutoRun",
	"FloorHUD",
	"DoorClient",
	"TreeClient",
	"GlyphClient",
	"GlyphMenu",
	"GlyphDrops",
	"TeleportUI",
	"StatsUI",
	"TrailUI",
	"TrailInventory",
	"FriendBoostUI",
	"AutoRejoin",
	"RebirthClient",
	"PotionUI",
	"UpgradeBoardUI",
	"PurchaseFX",
	"LeaderboardUI",
	"MineClient",
	"LuckyStrikeFX",
	"SmelterClient",
	"StarforgeClient",
	"MineTimer",
	"CrystalClient",
	str2,
	"EssenceClient",
	"TotemClient",
	"Ambience",
	"TutorialUI",
	"AdsUI",
	"MobileLayout",
	"NoReset",
	"MusicPlayer",
	"AdminPanel",
}) do

	local var3 = var2
	var3 = var3 and var2:FindFirstChild(v1)
	if not var3 then
		warn("[StairClimb] missing client module: " .. v1)
	else
		local var4 = require(var3)
		task.spawn(function()
			local success, result = pcall(function()
				var4:init()
			end)

			if not success then
				warn("[StairClimb] " .. v1 .. ":init() failed - " .. tostring(result))
			end
		end)

	end
end

--- Players.LocalPlayer.PlayerScripts.EventPrompt [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.StairConfig)
local bool1 = false
local var3 = game:GetService("SocialService")
local var4 = require(var1.Packages.DataService).client
local var5 = var2.collect()
local var6 = nil
local function prompt()
	bool1 = true
	task.wait(1.5)
	local success, result = pcall(function()
		local str1 = "619343918613529356"
		return var3:GetEventRsvpStatusAsync(str1)
	end)

	if success and result == Enum.RsvpStatus.Going then
		return
	end

	pcall(function()
		var3:PromptRsvpToEventAsync("619343918613529356")
	end)
end

local function check()
	local var3 = var4:get("stairsOwned")
	if var3 == nil then
		return
	end

	local var8 = var2.floorFor(var3, var5)
	if var6 ~= nil and (var6 < 159 and (159 <= var8 and (not bool1))) then
		task.spawn(prompt)
	end

	var6 = var8
end

var4:getChangedSignal("stairsOwned"):Connect(check)
check()

--- Players.LocalPlayer.PlayerGui.Main.FramewispJuice [LocalScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "FWv"
	return script:GetAttribute(str1)
end)

local var1 = success and result
game:GetService("TextService")
var1 = script.Parent
local function fwRoots()
	local tbl1 = { var1 }
	for k1, v1 in ipairs(var1:GetChildren()) do
		if not v1:IsA("ObjectValue") then
			continue
		end

		if v1.Name ~= "FW_ExtraRoot" then
			continue
		end

		if not v1.Value then
			continue
		end

		tbl1[#tbl1 + 1] = v1.Value
	end

	return tbl1
end

local function fwScaleHost(arg1)
	local var2 = arg1:FindFirstChild("FW_Scale")
	if not var2 then
		var2 = arg1:FindFirstChildWhichIsA("UIScale")
		if var2 then
			var2.Name = "FW_Scale"
			return var2
		end

		var2 = Instance.new("UIScale")
		var2.Name = "FW_Scale"
		var2:SetAttribute("FW_Owned", true)
		var2.Parent = arg1
	end

	return var2
end

local function fwScaleApply(arg1)
	local num1 = 1
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("NumberValue") then
			continue
		end

		num1 = num1 * v1.Value
	end

	arg1.Scale = num1
end

local function fwChannel(arg1, arg2)
	local var1 = fwScaleHost(arg1)
	local var3 = var1:FindFirstChild(arg2)
	if not var3 then
		var3 = Instance.new("NumberValue")
		var3.Name = arg2
		var3.Value = 1
		var3:SetAttribute("FW_Owned", true)
		var3.Parent = var1
		var3.Changed:Connect(function()
			fwScaleApply(var1)
		end)

	end

	return var3
end

local function shown(arg1)
	local var1 = arg1
	while not var1 and var1:IsA("LayerCollector") and var1:IsA("GuiObject") and (not var1.Visible) do
	end

	return var1 ~= nil
end

success = game:GetService("TweenService")
local function onShown(arg1, arg2)
	local var2 = shown(arg1)
	if var2 then
		arg2()
	end

	local var3 = arg1
	while not var3 and var3:IsA("LayerCollector") and var3:IsA("GuiObject") do
	end
end

local function popIn(arg1)
	local var2 = arg1:GetAttribute("PopFrom")
	local var3 = fwChannel(arg1, "k_pop")
	if var2 == nil then
		var2 = arg1:GetAttribute("FigmaPopFrom")
	end

	local var4 = if type(var2) ~= "number" then 0.8 else var2
	var3.Value = var4
	local var6 = arg1:GetAttribute("PopTime")
	var2 = success
	local var7 = var3
	local var8 = TweenInfo.new
	if var6 == nil then
		var6 = arg1:GetAttribute("FigmaPopTime")
	end

	var2:Create(var7, var8(if type(var6) ~= "number" then 0.3 else var6, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Value = 1 }):Play()
end

local function cascadeIn(arg1)
	local var2 = arg1:GetAttribute("CascadeGap")
	if var2 == nil then
		var2 = arg1:GetAttribute("FigmaCascadeGap")
	end

	local tbl1 = {}
	local tbl2 = {}
	local function sweep(arg1, arg2)
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("GuiObject") then
				continue
			end

			if v1:GetAttribute("FW_Owned") == false then
				continue
			end

			if arg2 == 0 then
				tbl1[#tbl1 + 1] = v1
			end

			local var2 = v1:IsA("GuiButton")
			if not var2 then
				var2 = v1:GetAttribute("FigmaAction") ~= nil
			end

			if var2 then
				tbl2[#tbl2 + 1] = v1
			else
				if arg2 >= 3 then
					continue
				end

				sweep(v1, arg2 + 1)
			end
		end
	end

	sweep(arg1, 0)
	local var3 = (if type(var2) ~= "number" then 70 else var2) / 1000
	local num1 = 0
	if 1 < (#tbl2) then
		tbl1 = tbl2
	end

	if #tbl1 == 0 then
		popIn(arg1)
		return
	end

	local var6 = tbl1[1].Name
	if #tbl1 == 1 and (1 < (#tbl1[1]:GetChildren()) and (var6:sub(-7) == "Content" or (var6:sub(-4) == "Mask" or var6:sub(-6) == "Masked"))) then
		local var7 = tbl1[1]
		return cascadeIn(var7)
	end

	var6 = false
	for k1, v2 in ipairs(tbl1) do
		if v2.LayoutOrder == 0 then
			continue
		end

		var6 = true
		break
	end

	if var6 then
		table.sort(tbl1, function(arg1, arg2)
			return arg1.LayoutOrder < arg2.LayoutOrder
		end)

	end

	for k2, v3 in ipairs(tbl1) do
		local var8 = fwChannel(v3, "k_pop")
		var8.Value = 0.001
		task.delay(num1 * var3, function()
			if v3.Parent then
				success:Create(var8, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Value = 1 }):Play()
			end
		end)

		num1 = num1 + 1
	end
end

local tbl1 = {}
local function pxScale()
	local var3 = var1:FindFirstChildWhichIsA("GuiObject")
	if not var3 then
		for k1, v1 in ipairs(var1:GetChildren()) do
			if v1:IsA("BillboardGui") then
				var3 = v1:FindFirstChildWhichIsA("GuiObject")
				break
			end

			if not v1:IsA("ObjectValue") then
				continue
			end

			if v1.Name ~= "FW_ExtraRoot" then
				continue
			end

			if not v1.Value then
				continue
			end

			var3 = v1.Value:FindFirstChildWhichIsA("GuiObject")
			break
		end
	end

	local var4 = var1:GetAttribute("BB_DesignH")
	if var3 and (type(var4) == "number" and (0 < var4 and 1 < var3.AbsoluteSize.Y)) then
		return var3.AbsoluteSize.Y / var4
	end

	return 1
end

local function slotFor(arg1, arg2)
	local var2 = arg1.Parent
	if not var2 then
		return
	end

	local var3 = var2:FindFirstChildWhichIsA("UIGridLayout")
	if not (var3 or (var2:FindFirstChildWhichIsA("UIListLayout") or (var2:FindFirstChildWhichIsA("UITableLayout") or var2:FindFirstChildWhichIsA("UIPageLayout")))) and (not arg2) then
		return
	end

	if var2:GetAttribute("FW_JuiceSlot") then
		return
	end

	local var4 = Instance.new("Frame")
	var4.Name = arg1.Name .. "_JSlot"
	var4.BackgroundTransparency = 1
	var4.Size = arg1.Size
	var4.Position = arg1.Position
	var4.AnchorPoint = arg1.AnchorPoint
	var4.ZIndex = arg1.ZIndex
	var4.LayoutOrder = arg1.LayoutOrder
	var4:SetAttribute("FW_Owned", true)
	var4:SetAttribute("FW_JuiceSlot", true)
	var4.Parent = var2
	arg1.Size = UDim2.fromScale(1, 1)
	arg1.Position = UDim2.fromScale(0.5, 0.5)
	arg1.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.Parent = var4
	return var4
end

local function gleamSeq(arg1, arg2)
	local var2 = math.clamp(arg1 * 0.5, 0.04, 0.46)
	if arg2 then
		local num3 = 1
		local num4 = 1
		local tbl1 = {
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.5 - var2, 1),
			NumberSequenceKeypoint.new(0.5, arg2),
			NumberSequenceKeypoint.new(var2 + 0.5, 1),
			NumberSequenceKeypoint.new(num3, num4),
		}

		return NumberSequence.new(tbl1)
	end

	local num5 = 1
	local num6 = 1
	local tbl2 = {
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.5 - var2, 1),
		NumberSequenceKeypoint.new(0.5 - var2 * 0.4, 0.45),
		NumberSequenceKeypoint.new(0.5, 0),
		NumberSequenceKeypoint.new(var2 * 0.4 + 0.5, 0.45),
		NumberSequenceKeypoint.new(var2 + 0.5, 1),
		NumberSequenceKeypoint.new(num5, num6),
	}

	return NumberSequence.new(tbl2)
end

local function gleamShine(arg1, arg2)
	local var1 = arg1.AbsoluteSize
	local tbl1 = {}
	local var2 = if var1.X * 0.25 <= var1.Y then -14 else 0
	local var3 = arg1.ZIndex
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("GuiObject") then
			continue
		end

		if v1.Name == "FW_GleamShine" then
			continue
		end

		if var3 >= v1.ZIndex then
			continue
		end

		var3 = v1.ZIndex
	end

	local var4 = arg1:FindFirstChildWhichIsA("UIStroke")
	local var5 = arg1:IsA("TextLabel")
	local function whiteCopy(arg1)
		local var2 = nil
		if arg1:IsA("TextLabel") or arg1:IsA("TextButton") then
			var2 = Instance.new("TextLabel")
			var2.Text = arg1.Text
			var2.RichText = arg1.RichText
			var2.FontFace = arg1.FontFace
			var2.TextScaled = arg1.TextScaled
			var2.TextSize = arg1.TextSize
			var2.TextWrapped = arg1.TextWrapped
			var2.LineHeight = arg1.LineHeight
			var2.TextXAlignment = arg1.TextXAlignment
			var2.TextYAlignment = arg1.TextYAlignment
			var2.TextColor3 = Color3.new(1, 1, 1)
			var2.TextStrokeTransparency = 1
		else
			if arg1:IsA("ImageLabel") or arg1:IsA("ImageButton") then
				var2 = Instance.new("ImageLabel")
				var2.Image = arg1.Image
				var2.ImageColor3 = Color3.new(1, 1, 1)
				var2.ScaleType = arg1.ScaleType
				var2.SliceCenter = arg1.SliceCenter
				var2.SliceScale = arg1.SliceScale
				var2.TileSize = arg1.TileSize
				var2.ImageRectOffset = arg1.ImageRectOffset
				var2.ImageRectSize = arg1.ImageRectSize
			else
				var2 = Instance.new("Frame")
				var2.BackgroundColor3 = Color3.new(1, 1, 1)
			end
		end

		var2.Name = "FW_GleamShine"
		var2.Visible = false
		if not var2:IsA("Frame") then
			var2.BackgroundTransparency = 1
		end

		var2.Size = UDim2.fromScale(1, 1)
		var2.Position = UDim2.fromScale(0.5, 0.5)
		var2.AnchorPoint = Vector2.new(0.5, 0.5)
		var2.ZIndex = var3 + arg1
		var2:SetAttribute("FW_Owned", true)
		local var5 = arg1:FindFirstChildWhichIsA("UICorner")
		if var5 then
			var5:Clone().Parent = var2
		end

		local str1 = "FigmaTextW"
		for k1, v1 in ipairs({ "FigmaFontSize", str1, "FigmaTextStrokeW", "FigmaStrokeW" }) do
			local var6 = arg1:GetAttribute(v1)
			if var6 == nil then
				continue
			end

			var2:SetAttribute(v1, var6)
		end

		local str2 = "FWTextBig"
		for k2, v2 in ipairs({ "FW_BBText", str2 }) do
			local var7 = arg1:FindFirstChild(v2)
			if not var7 then
				continue
			end

			var7:Clone().Parent = var2
		end

		var2.Parent = arg1
		return var2
	end

	local var7 = whiteCopy(1)
	local function band(arg1, arg2, arg3)
		local var1 = Instance.new("UIGradient")
		var1.Transparency = gleamSeq(arg2, arg3)
		var1.Rotation = var2
		var1.Offset = Vector2.new(-2, 0)
		var1:SetAttribute("FW_Owned", true)
		var1.Parent = arg1
		tbl1[#tbl1 + 1] = var1
	end

	local function whiteStroke(arg1, arg2)
		local var1 = var4 and var4:Clone() or Instance.new("UIStroke")
		for k1, v1 in ipairs(var1:GetChildren()) do
			v1:Destroy()
		end

		var1.Color = Color3.new(1, 1, 1)
		pcall(function()
			var1.BorderStrokePosition = Enum.BorderStrokePosition.Outer
		end)

		if arg1:IsA("TextLabel") or arg1:IsA("TextButton") then
			var1.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
		end

		if var4 then
			if var4:GetAttribute("FW_StrokeScaled") then
				local var2 = var4.Thickness
				var1.Thickness = var2 * (if 0 < arg2 then 1.7 else 1)
			else
				var1.Thickness = (var4 and var4.Thickness or 0) + arg2
			end
		else
			var1.Thickness = (var4 and var4.Thickness or 0) + arg2
		end

		var1:SetAttribute("FW_Owned", true)
		var1.Parent = arg1
	end

	var5 = var5 or arg1:IsA("TextButton")
	if var7 then
		if var5 then
			whiteStroke(var7, 3)
		end

		band(var7, arg2 * 1.6, 0.4)
	end

	local var9 = whiteCopy(2)
	if not var9 then
		return tbl1
	end

	if var4 and var5 then
		whiteStroke(var9, 0)
	end

	band(var9, arg2)
	return tbl1
end

local function wireGleam(arg1)
	if arg1:GetAttribute("FW_Gleam") then
		return
	end

	arg1:SetAttribute("FW_Gleam", true)
	local var2 = arg1:GetAttribute("GleamWidth")
	if var2 == nil then
		var2 = arg1:GetAttribute("FigmaGleamWidth")
	end

	local var3 = if type(var2) ~= "number" then 0.22 else var2
	if not arg1:IsA("TextLabel") and (not arg1:IsA("TextButton") and (not arg1:IsA("ImageLabel") and (not arg1:IsA("ImageButton")))) then
		tbl1[#tbl1 + 1] = { kind = "gleamG", el = arg1, t = 0, parts = nil, waited = 0 }
		return
	end

	local tbl2 = { kind = "gleam", el = arg1, t = 0, w = var3, grads = gleamShine(arg1, var3) }
	tbl1[#tbl1 + 1] = tbl2
end

local function wireSwing(arg1)
	if arg1:GetAttribute("FW_Swing") then
		return
	end

	arg1:SetAttribute("FW_Swing", true)
	slotFor(arg1, true)
	local var1 = arg1.Size
	local var2 = arg1.Position
	onShown(arg1, function()
		local var3 = arg1
		local var5 = var3:GetAttribute("SwingTime")
		local var6 = tbl1
		local var7 = #tbl1 + 1
		local tbl2 = { kind = "swing", el = arg1, t = 0, size0 = var1, pos0 = var2, par = arg1.Parent }
		local num1 = 0.02
		if var5 == nil then
			var5 = var3:GetAttribute("FigmaSwingTime")
		end

		tbl2.T = math.max(num1, if type(var5) ~= "number" then 1.2 else var5)
		num1 = arg1
		local var9 = num1:GetAttribute("SwingAngle")
		if var9 == nil then
			var9 = num1:GetAttribute("FigmaSwingAngle")
		end

		local var10 = if type(var9) ~= "number" then 20 else var9
		tbl2.A = var10
		num1 = arg1
		var9 = num1:GetAttribute("SwingCount")
		if var9 == nil then
			var9 = num1:GetAttribute("FigmaSwingCount")
		end

		var10 = if type(var9) ~= "number" then 4 else var9
		tbl2.n = var10
		num1 = arg1
		var9 = num1:GetAttribute("SwingFrom")
		if var9 == nil then
			var9 = num1:GetAttribute("FigmaSwingFrom")
		end

		var10 = if type(var9) ~= "number" then 0.5 else var9
		tbl2.from = var10
		var6[var7] = tbl2
	end)
end

local function wireReveal(arg1)
	if arg1:GetAttribute("FW_Reveal") then
		return
	end

	arg1:SetAttribute("FW_Reveal", true)
	slotFor(arg1, true)
	local var1 = arg1.Size
	local var2 = arg1.Position
	onShown(arg1, function()
		local var3 = arg1
		local var5 = var3:GetAttribute("RevealTime")
		local var6 = tbl1
		local var7 = #tbl1 + 1
		local tbl2 = { kind = "reveal", el = arg1, t = 0, size0 = var1, pos0 = var2 }
		local num1 = 0.02
		if var5 == nil then
			var5 = var3:GetAttribute("FigmaRevealTime")
		end

		tbl2.T = math.max(num1, if type(var5) ~= "number" then 0.7 else var5)
		local var8 = arg1
		var3 = var8:GetAttribute("RevealAngle")
		if var3 == nil then
			var3 = var8:GetAttribute("FigmaRevealAngle")
		end

		tbl2.A = math.rad(if type(var3) ~= "number" then 35 else var3)
		var8 = arg1
		var3 = var8:GetAttribute("RevealDir")
		if var3 == nil then
			var3 = var8:GetAttribute("FigmaRevealDir")
		end

		tbl2.dir = math.rad(if type(var3) ~= "number" then 0 else var3)
		num1 = arg1
		var8 = num1:GetAttribute("RevealFrom")
		if var8 == nil then
			var8 = num1:GetAttribute("FigmaRevealFrom")
		end

		local var9 = if type(var8) ~= "number" then 0.55 else var8
		tbl2.from = var9
		var6[var7] = tbl2
	end)
end

local function wirePop(arg1)
	if arg1:GetAttribute("FW_Pop") then
		return
	end

	arg1:SetAttribute("FW_Pop", true)
	onShown(arg1, function()
		popIn(arg1)
	end)
end

local function wireCascade(arg1)
	if arg1:GetAttribute("FW_Cascade") then
		return
	end

	arg1:SetAttribute("FW_Cascade", true)
	onShown(arg1, function()
		cascadeIn(arg1)
	end)
end

local function wireGlow(arg1)
	if arg1:GetAttribute("FW_Glow") then
		return
	end

	arg1:SetAttribute("FW_Glow", true)
	local var2 = arg1:GetAttribute("GlowSW")
	local var3 = arg1
	if var2 == nil then
		var2 = arg1:GetAttribute("FigmaGlowSW")
	end

	local var5 = arg1:GetAttribute("GlowSH")
	local var6 = if type(var2) ~= "number" then 1 else var2
	if var5 == nil then
		var5 = arg1:GetAttribute("FigmaGlowSH")
	end

	local var8 = arg1:GetAttribute("GlowRot")
	var2 = if type(var5) ~= "number" then 1 else var5
	if var8 == nil then
		var8 = arg1:GetAttribute("FigmaGlowRot")
	end

	var5 = if type(var8) ~= "number" then 0 else var8
	if var6 < 0.999 or (1.001 < var6 or (var2 < 0.999 or (1.001 < var2 or 0.05 < math.abs(var5)))) then
		var8 = Instance.new("Frame")
		var8.Name = "FW_GlowRing"
		var8.BackgroundTransparency = 1
		var8.AnchorPoint = Vector2.new(0.5, 0.5)
		var8.Position = UDim2.fromScale(0.5, 0.5)
		var8.Size = UDim2.fromScale(var6, var2)
		var8.Rotation = var5
		var8:SetAttribute("FW_Owned", true)
		local var10 = arg1:GetAttribute("GlowRad")
		if var10 == nil then
			var10 = arg1:GetAttribute("FigmaGlowRad")
		end

		local var12 = if type(var10) ~= "number" then 0 else var10
		if 0 < var12 then
			var10 = Instance.new("UICorner")
			var10.CornerRadius = UDim.new(var12, 0)
			var10.Parent = var8
		end

		var8.Parent = arg1
		var3 = var8
	end

	var8 = var3:FindFirstChildWhichIsA("UIStroke")
	if var8 then
		if var8:GetAttribute("FW_Owned") ~= true then
			var8 = nil
		end
	end

	if not var8 then
		var8 = Instance.new("UIStroke")
		var8.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		var8:SetAttribute("FW_Owned", true)
		local var14 = arg1:GetAttribute("GlowColor")
		if var14 == nil then
			var14 = arg1:GetAttribute("FigmaGlowColor")
		end

		local var15 = if type(var14) ~= "number" then 16777215 else var14
		var8.Color = Color3.fromRGB(math.floor(var15 / 65536) % 256, math.floor(var15 / 256) % 256, var15 % 256)
		var8.Thickness = 0
		var8.Parent = var3
	end

	local var16 = var8:GetAttribute("FW_StrokeScaled") == true
	local tbl2 = { kind = "glow", el = arg1, stroke = var8, base = var8.Thickness, frac = var16 }
	tbl2.t = math.random() * 7
	tbl1[#tbl1 + 1] = tbl2
end

local function wirePixels(arg1)
	if arg1:GetAttribute("FW_Pixels") then
		return
	end

	arg1:SetAttribute("FW_Pixels", true)
	local var1 = Instance.new("Frame")
	var1.Name = "FW_PixelHost"
	var1.BackgroundTransparency = 1
	var1.Size = UDim2.fromScale(1, 1)
	var1.ClipsDescendants = true
	var1:SetAttribute("FW_Owned", true)
	local var3 = arg1:FindFirstChildWhichIsA("UICorner")
	if var3 then
		var3:Clone().Parent = var1
	end

	local var4 = arg1.ZIndex
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("GuiObject") then
			continue
		end

		if var4 >= v1.ZIndex then
			continue
		end

		var4 = v1.ZIndex
	end

	var1.ZIndex = var4 + 1
	var1.Parent = arg1
	local var6 = arg1:GetAttribute("PixColor")
	if var6 == nil then
		var6 = arg1:GetAttribute("FigmaPixColor")
	end

	local var7 = if type(var6) ~= "number" then 16777215 else var6
	local var9 = arg1:GetAttribute("PixAlpha")
	var6 = Color3.fromRGB(math.floor(var7 / 65536) % 256, math.floor(var7 / 256) % 256, var7 % 256)
	if var9 == nil then
		var9 = arg1:GetAttribute("FigmaPixAlpha")
	end

	local var10 = if type(var9) ~= "number" then 0.35 else var9
	for i1 = 1, 240 do
		if 2 >= arg1.AbsoluteSize.X or 2 >= arg1.AbsoluteSize.Y then
			task.wait()
			if arg1.Parent then
				continue
			end

			return
		end
	end

	local var12 = arg1:GetAttribute("PixCell")
	var9 = arg1.AbsoluteSize.X
	local var13 = arg1.AbsoluteSize.Y
	local num1 = 1
	if var12 == nil then
		var12 = arg1:GetAttribute("FigmaPixCell")
	end

	local var14 = math.max(num1, if type(var12) ~= "number" then 14 else var12)
	local var15 = var14 * pxScale()
	num1 = var15 * math.max(1, (math.ceil((math.sqrt(math.ceil(var9 / var15) * math.ceil(var13 / var15) / 1600)))))
	local tbl2 = {}
	var12 = num1 / math.max(1, var9)
	local var16 = num1 / math.max(1, var13)
	local num2 = 0
	local num3 = 0
	while num2 >= var13 and num3 < var9 do
	end

	local var18 = arg1:GetAttribute("PixRate")
	num3 = tbl1
	local var19 = #tbl1 + 1
	local tbl3 = { kind = "pixels", el = arg1, t = 0, cells = tbl2, acc = 0 }
	if var18 == nil then
		var18 = arg1:GetAttribute("FigmaPixRate")
	end

	local var20 = if type(var18) ~= "number" then 8 else var18
	tbl3.rate = var20
	tbl3.alpha = var10
	local var22 = arg1:GetAttribute("PixVary")
	if var22 == nil then
		var22 = arg1:GetAttribute("FigmaPixVary")
	end

	var20 = 0.5 <= (if type(var22) ~= "number" then 0 else var22)
	tbl3.vary = var20
	tbl3.cw = var12
	tbl3.ch = var16
	num3[var19] = tbl3
end

local var2 = game:GetService("RunService")
local function fwRotSet(arg1, arg2, arg3)
	local var2 = arg1:GetAttribute("FW_RotBase")
	if var2 == nil then
		var2 = arg1.Rotation
		arg1:SetAttribute("FW_RotBase", var2)
	end

	arg1:SetAttribute(arg2, arg3)
	local str1 = "r_spin"
	local num1 = 0
	for k1, v1 in ipairs({ "r_juice", str1, "r_tl", "r_hover" }) do
		local var3 = arg1:GetAttribute(v1)
		if type(var3) ~= "number" then
			continue
		end

		num1 = num1 + var3
	end

	arg1.Rotation = var2 + num1
end

local function wire(arg1)
	if not arg1:IsA("GuiObject") then
		return
	end

	if arg1:GetAttribute("FigmaTimeline") ~= nil then
		return
	end

	local function try(arg1, ...)
		local success, result = pcall(arg1, ...)
		if not success then
			warn("[Framewisp] " .. arg1:GetFullName() .. ": " .. tostring(result))
		end
	end

	if arg1:GetAttribute("FigmaGleam") then
		try(wireGleam, arg1)
	end

	if arg1:GetAttribute("FigmaSwing") then
		try(wireSwing, arg1)
	end

	if arg1:GetAttribute("FigmaReveal") then
		try(wireReveal, arg1)
	end

	if arg1:GetAttribute("FigmaPop") then
		try(wirePop, arg1)
	end

	if arg1:GetAttribute("FigmaCascade") then
		try(wireCascade, arg1)
	end

	if arg1:GetAttribute("FigmaGlow") then
		try(wireGlow, arg1)
	end

	if arg1:GetAttribute("FigmaPixels") then
		task.spawn(try, wirePixels, arg1)
	end

	if arg1:GetAttribute("FigmaPulse") then
		local var1
		if arg1:GetAttribute("FW_Pulse") then
			var1 = false
		else
			arg1:SetAttribute("FW_Pulse", true)
			var1 = true
		end

		if var1 then
			local tbl2 = { kind = "pulse", el = arg1, sc = fwChannel(arg1, "k_juice") }
			tbl2.t = math.random() * 7
			tbl1[#tbl1 + 1] = tbl2
		end
	end

	if arg1:GetAttribute("FigmaJelly") then
		if arg1:GetAttribute("FW_Jelly") then
			var1 = false
		else
			arg1:SetAttribute("FW_Jelly", true)
			var1 = true
		end

		if var1 then
			local tbl3 = { kind = "jelly", el = arg1, sc = fwChannel(arg1, "k_juice") }
			tbl3.base = arg1.Rotation
			tbl3.t = math.random() * 7
			tbl1[#tbl1 + 1] = tbl3
		end
	end

	if arg1:GetAttribute("FigmaWiggle") then
		if arg1:GetAttribute("FW_Wiggle") then
			var1 = false
		else
			arg1:SetAttribute("FW_Wiggle", true)
			var1 = true
		end

		if var1 then
			tbl1[#tbl1 + 1] = { kind = "wiggle", el = arg1, base = arg1.Rotation, t = 0 }
		end
	end

	if arg1:GetAttribute("FigmaRays") then
		if arg1:GetAttribute("FW_Rays") then
			var1 = false
		else
			arg1:SetAttribute("FW_Rays", true)
			var1 = true
		end

		if var1 then
			local tbl4 = { kind = "rays", el = arg1, sc = fwChannel(arg1, "k_juice") }
			tbl4.base = arg1.Rotation
			tbl4.t = math.random() * 7
			tbl1[#tbl1 + 1] = tbl4
		end
	end

	if arg1:GetAttribute("FigmaShake") then
		if arg1:GetAttribute("FW_Shake") then
			var1 = false
		else
			arg1:SetAttribute("FW_Shake", true)
			var1 = true
		end

		if var1 then
			slotFor(arg1)
			tbl1[#tbl1 + 1] = { kind = "shake", el = arg1, base = nil, t = 0 }
		end
	end
end

for k1, v2 in ipairs(((function()
	local tbl1 = {}
	for k1, v1 in ipairs((fwRoots())) do
		for k2, v2 in ipairs(v1:GetDescendants()) do
			tbl1[#tbl1 + 1] = v2
		end
	end

	return tbl1
end)())) do

	wire(v2)
end

for k2, v3 in ipairs((fwRoots())) do
	v3.DescendantAdded:Connect(wire)
end

local tbl2 = {}
local tbl3 = {}
local tbl4 = {}
local function posed(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.size0
	arg1.el.Size = UDim2.new(var1.X.Scale * arg2, var1.X.Offset * arg2, var1.Y.Scale * arg3, var1.Y.Offset * arg3)
	local var2 = arg1.pos0
	arg1.el.Position = UDim2.new(var2.X.Scale + arg4, var2.X.Offset, var2.Y.Scale + arg5, var2.Y.Offset)
end

task.delay(0.4, function()
	local num1 = 0
	local num2 = 0
	for k1, v1 in ipairs(tbl1) do
		if v1.kind ~= "pulse" then
			continue
		end

		if v1.el:GetAttribute("FW_3DHosted") then
			num2 = num2 + 1
		else
			num1 = num1 + 1
		end
	end
end)

local function tickIdle(arg1)
	table.clear(tbl2)
	table.clear(tbl3)
	table.clear(tbl4)
	local var1 = nil
	for k1, v1 in ipairs(tbl1) do
		if not v1.el.Parent then
			continue
		end

		local var2 = v1.t + arg1
		v1.t = var2
		if v1.size0 and v1.par ~= v1.el.Parent then
			v1.par = v1.el.Parent
			v1.size0 = v1.el.Size
			v1.pos0 = v1.el.Position
		end

		if v1.kind == "swing" then
			var2 = math.min(1, v1.t / v1.T)
			if 1 <= var2 then
				posed(v1, 1, 1, 0, 0)
				if v1.el:GetAttribute("FW_SwingPitch") then
					v1.el:SetAttribute("FW_SwingPitch", 0)
				end

				v1.el:SetAttribute("FW_HostScale", nil)
				v1.el:SetAttribute("FW_EntrK", nil)
				local var3 = var1
				var1 = var3 or {}
				var1[#var1 + 1] = k1
			else
				local var4 = v1.A * math.exp(var2 * -4) * math.cos(var2 * 3.1415926535897931 * 2 * v1.n)
				local var5 = math.min(1, v1.t / (v1.T * 0.3))
				local var6 = math.rad(var4)
				local var7 = v1.from + (1 - v1.from) * ((var5 - 1) ^ 3 * 3.2 + 1 + (var5 - 1) ^ 2 * 2.2)
				if v1.el:GetAttribute("FW_3DHosted") then
					v1.el:SetAttribute("FW_SwingPitch", var4)
					v1.el:SetAttribute("FW_HostScale", var7)
					posed(v1, 1, 1, 0, 0)
				else
					v1.el:SetAttribute("FW_EntrK", var7)
					posed(v1, var7, var7 * math.abs((math.cos(var6))), 0, -math.sin(var6) * 0.09)
					continue
				end
			end
		else
			if v1.kind == "reveal" then
				var2 = math.min(1, v1.t / v1.T)
				if 1 <= var2 then
					posed(v1, 1, 1, 0, 0)
					local var8 = var1
					var1 = var8 or {}
					var1[#var1 + 1] = k1
				else
					local var9 = math.min(1, v1.t / (v1.T * 0.45))
					local var10 = v1.A * math.exp(var2 * -5) * math.cos(var2 * 3.1415926535897931 * 5)
					local var11 = 1 - math.cos(var10)
					local var12 = v1.from + (1 - v1.from) * ((var9 - 1) ^ 3 * 3.2 + 1 + (var9 - 1) ^ 2 * 2.2)
					local var13 = math.sin(var10) * 0.07
					posed(v1, var12 * (1 - var11 * math.abs((math.sin(v1.dir)))), var12 * (1 - var11 * math.abs((math.cos(v1.dir)))), math.sin(v1.dir) * var13, -math.cos(v1.dir) * var13)
					continue
				end
			else
				if v1.kind == "pulse" then
					local var16 = v1.el
					local var18 = var16:GetAttribute("PulseSpeed")
					if var18 == nil then
						var18 = var16:GetAttribute("FigmaPulseSpeed")
					end

					local var19 = v1.el
					local var21 = var19:GetAttribute("PulseAmp")
					var16 = (1 - math.cos(v1.t * 3.1415926535897931 * 2 * (if type(var18) ~= "number" then 1 else var18))) * 0.5
					if var21 == nil then
						var21 = var19:GetAttribute("FigmaPulseAmp")
					end

					var18 = (if type(var21) ~= "number" then 5 else var21) / 100
					if v1.el:GetAttribute("FW_3DHosted") then
						v1.el:SetAttribute("FW_HostScale", 1 + var18 * var16)
					else
						local var23 = math.min(v1.el.AbsoluteSize.X, v1.el.AbsoluteSize.Y)
						if 1 < var23 and var18 * var23 < 10 then
							var18 = math.min(var18 * 4, 10 / var23)
						end

						tbl2[v1.sc] = (tbl2[v1.sc] or 1) * (1 + var18 * var16)
						continue
					end
				else
					if v1.kind == "jelly" then
						local var26 = v1.el
						local var28 = var26:GetAttribute("JellySpeed")
						if var28 == nil then
							var28 = var26:GetAttribute("FigmaJellySpeed")
						end

						var2 = if type(var28) ~= "number" then 1.2 else var28
						tbl4[v1.el] = v1.base
						local var29 = v1.el
						local var31 = var29:GetAttribute("JellyAmp")
						var26 = tbl3
						var28 = v1.el
						local var32 = tbl3[v1.el] or 0
						local var33 = math.sin(v1.t * 3.1415926535897931 * 2 * var2)
						if var31 == nil then
							var31 = var29:GetAttribute("FigmaJellyAmp")
						end

						var26[var28] = var32 + var33 * (if type(var31) ~= "number" then 3 else var31)
						tbl2[v1.sc] = (tbl2[v1.sc] or 1) * (math.sin(v1.t * 3.1415926535897931 * 4 * var2 + 1) * 0.01 + 1)
					else
						if v1.kind == "wiggle" then
							local var36 = v1.el
							local var38 = var36:GetAttribute("WiggleEvery")
							if var38 == nil then
								var38 = var36:GetAttribute("FigmaWiggleEvery")
							end

							var36 = v1.t % ((if type(var38) ~= "number" then 4 else var38) + 0.7)
							tbl4[v1.el] = v1.base
							tbl3[v1.el] = tbl3[v1.el] or 0
							if var36 >= 0.7 then
								continue
							end

							var38 = var36 / 0.7
							local var39 = v1.el
							local var41 = var39:GetAttribute("WiggleAngle")
							local var42 = tbl3
							local var43 = v1.el
							local var44 = tbl3[v1.el]
							local var45 = math.sin(var38 * 3.1415926535897931 * 6)
							if var41 == nil then
								var41 = var39:GetAttribute("FigmaWiggleAngle")
							end

							local var46 = var45 * (if type(var41) ~= "number" then 12 else var41)
							var42[var43] = var44 + var46 * (1 - var38)
						else
							if v1.kind == "rays" then
								local var49 = v1.el
								local var51 = var49:GetAttribute("RaysSpeed")
								local var52 = v1.ang or 0
								if var51 == nil then
									var51 = var49:GetAttribute("FigmaRaysSpeed")
								end

								v1.ang = var52 + (if type(var51) ~= "number" then 25 else var51) * arg1
								tbl4[v1.el] = v1.base or 0
								tbl3[v1.el] = (tbl3[v1.el] or 0) + v1.ang
								local var53 = v1.el
								local var55 = var53:GetAttribute("RaysPulse")
								var2 = tbl2
								var52 = v1.sc
								local var56 = tbl2[v1.sc] or 1
								var51 = 1
								if var55 == nil then
									var55 = var53:GetAttribute("FigmaRaysPulse")
								end

								var2[var52] = var56 * (var51 + (if type(var55) ~= "number" then 6 else var55) / 100 * (math.sin(v1.t * 2) * 0.5 + 0.5))
							else
								if v1.kind == "shake" then
									local var59 = v1.el
									local var61 = var59:GetAttribute("ShakeEvery")
									if var61 == nil then
										var61 = var59:GetAttribute("FigmaShakeEvery")
									end

									var61 = v1.el
									local var63 = var61:GetAttribute("ShakeTime")
									var2 = if type(var61) ~= "number" then 3 else var61
									if var63 == nil then
										var63 = var61:GetAttribute("FigmaShakeTime")
									end

									var59 = if type(var63) ~= "number" then 0.5 else var63
									var61 = v1.t % (var2 + var59)
									if v1.base == nil then
										v1.base = v1.el.Position
									end

									if var61 < var59 then
										local var66 = v1.el
										local var68 = var66:GetAttribute("ShakeAmp")
										var63 = var61 / var59
										if var68 == nil then
											var68 = var66:GetAttribute("FigmaShakeAmp")
										end

										local var69 = (if type(var68) ~= "number" then 6 else var68) * (1 - var63)
										v1.el.Position = v1.base + UDim2.fromOffset(math.sin(v1.t * 53) * var69, math.cos(v1.t * 47) * var69)
									else
										v1.el.Position = v1.base
										continue
									end
								else
									if v1.kind == "glow" then
										local var72 = v1.el
										local var74 = var72:GetAttribute("GlowSpeed")
										if var74 == nil then
											var74 = var72:GetAttribute("FigmaGlowSpeed")
										end

										var74 = v1.el
										local var76 = var74:GetAttribute("GlowSize")
										var2 = if type(var74) ~= "number" then 0.8 else var74
										if var76 == nil then
											var76 = var74:GetAttribute("FigmaGlowSize")
										end

										var72 = if type(var76) ~= "number" then 12 else var76
										var74 = math.sin(v1.t * 3.1415926535897931 * 2 * var2) * 0.5 + 0.5
										if v1.frac then
											v1.stroke.Thickness = v1.base + var72 * 0.5 * var74 / math.max(1, (math.min(v1.el.AbsoluteSize.X, v1.el.AbsoluteSize.Y)))
										else
											v1.stroke.Thickness = math.max(v1.base + var72 * 0.5 * var74, 1.5)
										end

										v1.stroke.Transparency = 0.15
									else
										if v1.kind == "gleam" then
											local var79 = v1.el
											local var81 = var79:GetAttribute("GleamSpeed")
											if var81 == nil then
												var81 = var79:GetAttribute("FigmaGleamSpeed")
											end

											var81 = v1.el
											local var83 = var81:GetAttribute("GleamCooldown")
											var2 = if type(var81) ~= "number" then 0.8 else var81
											if var83 == nil then
												var83 = var81:GetAttribute("FigmaGleamCooldown")
											end

											var83 = v1.el
											local var85 = var83:GetAttribute("GleamWidth")
											var79 = if type(var83) ~= "number" then 2 else var83
											if var85 == nil then
												var85 = var83:GetAttribute("FigmaGleamWidth")
											end

											if not v1.grads then
												continue
											end

											var83 = v1.t % (var2 + var79)
											var85 = var83 < var2
											local var86 = 0.5 + (if type(var85) ~= "number" then 0.22 else var85)
											local num1 = -2
											num1 = var85 and -var86 + var83 / var2 * var86 * 2
											for i1 = 1, #v1.grads do
												v1.grads[i1].Offset = Vector2.new(num1, 0)
												local var87 = v1.grads[i1].Parent
												if not var87 then
													continue
												end

												if not var87:IsA("GuiObject") then
													continue
												end

												if var87.Visible ~= var85 then
													var87.Visible = var85
												end

												if not var85 then
													continue
												end

												if not var87:IsA("TextLabel") then
													continue
												end

												if not v1.el:IsA("TextLabel") then
													continue
												end

												if var87.TextSize ~= v1.el.TextSize then
													var87.TextSize = v1.el.TextSize
												end

												if var87.TextScaled == v1.el.TextScaled then
													continue
												end

												var87.TextScaled = v1.el.TextScaled
											end
										else
											if v1.kind == "gleamG" then
												if v1.parts == nil then
													local var92 = v1.el
													local var94 = var92:GetAttribute("GleamWidth")
													if var94 == nil then
														var94 = var92:GetAttribute("FigmaGleamWidth")
													end

													var92 = math.max(1, v1.el.AbsoluteSize.X)
													var2 = if type(var94) ~= "number" then 0.22 else var94
													var94 = {}
													if 1 < var92 then
														for k2, v2 in ipairs(v1.el:GetDescendants()) do
															if (v2:IsA("TextLabel") or (v2:IsA("TextButton") or (v2:IsA("ImageLabel") or v2:IsA("ImageButton")))) and v2.Name ~= "FW_GleamShine" and (v2.Name ~= "Background" and (0 < v2.AbsoluteSize.X and v2.AbsoluteSize.X < var92 * 0.95)) then
																local var95 = math.clamp(var2 * var92 / math.max(1, v2.AbsoluteSize.X), 0.05, 0.6)
																local tbl5 = { el = v2, grads = gleamShine(v2, var95) }
																var94[#var94 + 1] = tbl5
															end
														end
													end

													if 0 < (#var94) then
														v1.parts = var94
													else
														local var96 = v1.waited + arg1
														v1.waited = var96
														if 2 >= v1.waited then
															continue
														end

														v1.kind = "gleam"
														v1.w = var2
														v1.grads = gleamShine(v1.el, var2)
														continue
													end
												else
													local var97 = v1.el
													local var99 = var97:GetAttribute("GleamSpeed")
													local num2 = 0.02
													if var99 == nil then
														var99 = var97:GetAttribute("FigmaGleamSpeed")
													end

													local var100 = v1.el
													var97 = var100:GetAttribute("GleamCooldown")
													var2 = math.max(num2, if type(var99) ~= "number" then 0.8 else var99)
													if var97 == nil then
														var97 = var100:GetAttribute("FigmaGleamCooldown")
													end

													var97 = v1.el
													var99 = var97:GetAttribute("GleamWidth")
													num2 = if type(var97) ~= "number" then 2 else var97
													if var99 == nil then
														var99 = var97:GetAttribute("FigmaGleamWidth")
													end

													var97 = v1.t % (var2 + num2)
													local var101 = 0.5 + (if type(var99) ~= "number" then 0.22 else var99)
													var99 = var97 < var2
													local var102 = v1.el.AbsolutePosition.X
													local var103 = math.max(1, v1.el.AbsoluteSize.X)
													local var104 = -var101 + var97 / var2 * (1 + 2 * var101)
													for i2 = 1, #v1.parts do
														local var105 = v1.parts[i2]
														if not var105.el.Parent then
															continue
														end

														local var106 = var99 and (var104 - (var105.el.AbsolutePosition.X - var102) / var103) / math.max(0.001, var105.el.AbsoluteSize.X / var103) - 0.5 or -10
														for i3 = 1, #var105.grads do
															var105.grads[i3].Offset = Vector2.new(var106, 0)
															local var107 = var105.grads[i3].Parent
															if not var107 then
																continue
															end

															if not var107:IsA("GuiObject") then
																continue
															end

															if var107.Visible ~= var99 then
																var107.Visible = var99
															end

															if not var99 then
																continue
															end

															if not var107:IsA("TextLabel") then
																continue
															end

															if not var105.el:IsA("TextLabel") then
																continue
															end

															if var107.TextSize ~= var105.el.TextSize then
																var107.TextSize = var105.el.TextSize
															end

															if var107.TextScaled == var105.el.TextScaled then
																continue
															end

															var107.TextScaled = var105.el.TextScaled
														end
													end

													continue
												end
											else
												if v1.kind ~= "pixels" then
													continue
												end

												var2 = v1.acc + arg1 * v1.rate
												v1.acc = var2
												while 1 <= v1.acc do
													var2 = v1.acc - 1
													v1.acc = var2
													var2 = v1.cells[math.random(#v1.cells)]
													if not var2 then
														continue
													end

													if v1.vary then
														local var109 = 0.3 + math.random() * 1.4
														var2.Size = UDim2.fromScale(v1.cw * var109, v1.ch * var109)
													else
														var2.Size = UDim2.fromScale(v1.cw, v1.ch)
													end

													local var110 = 1 - v1.alpha * (0.55 + 0.45 * math.random())
													local var111 = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
													success:Create(var2, var111, { BackgroundTransparency = var110 }):Play()
													local var112 = 0.35 + math.random() * 0.45
													task.delay(0.16 + math.random() * 0.48, function()
														if var2.Parent then
															success:Create(var2, TweenInfo.new(var112, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { BackgroundTransparency = 1 }):Play()
														end
													end)

												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end

	for k3, v3 in pairs(tbl2) do
		k3.Value = v3
	end

	for k4, v4 in pairs(tbl3) do
		fwRotSet(k4, "r_juice", v4)
	end

	if var1 then
		for i4 = #var1, 1, -1 do
			table.remove(tbl1, var1[i4])
		end
	end
end

local bool1 = false
var2.RenderStepped:Connect(function(arg1)
	local success, result = pcall(tickIdle, arg1)
	if not success and (not bool1) then
		bool1 = true
		warn("[Framewisp] effects: " .. tostring(result))
	end
end)

--- Players.LocalPlayer.PlayerGui.FramewispTextScaler [LocalScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "FWv"
	return script:GetAttribute(str1)
end)

local var1 = script.Parent
local var2 = success and result
success = function()
	local tbl1 = { var1 }
	for k1, v1 in ipairs(var1:GetChildren()) do
		if not v1:IsA("ObjectValue") then
			continue
		end

		if v1.Name ~= "FW_ExtraRoot" then
			continue
		end

		if not v1.Value then
			continue
		end

		tbl1[#tbl1 + 1] = v1.Value
	end

	return tbl1
end

var2 = function(arg1)
	local var2 = arg1:FindFirstChild("FW_Scale")
	if not var2 then
		var2 = arg1:FindFirstChildWhichIsA("UIScale")
		if var2 then
			var2.Name = "FW_Scale"
			return var2
		end

		var2 = Instance.new("UIScale")
		var2.Name = "FW_Scale"
		var2:SetAttribute("FW_Owned", true)
		var2.Parent = arg1
	end

	return var2
end

local function fwScaleApply(arg1)
	local num1 = 1
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("NumberValue") then
			continue
		end

		num1 = num1 * v1.Value
	end

	arg1.Scale = num1
end

local var4 = (function()
	local var2 = nil
	for k1, v1 in ipairs(var1:GetChildren()) do
		local var3 = v1:FindFirstChildWhichIsA("GuiObject")
		if v1:IsA("BillboardGui") and var3 then
			return var3
		end

		var3 = v1.Value:FindFirstChildWhichIsA("GuiObject")
		if v1:IsA("ObjectValue") and (v1.Name == "FW_ExtraRoot" and (v1.Value and var3)) then
			return var3
		end

		if not v1:IsA("GuiObject") then
			continue
		end

		if v1:GetAttribute("FW_Owned") ~= true then
			continue
		end

		return v1
	end

	return var2
end)()

local var5 = game:GetService("TextService")
local function fwChannel(arg1, arg2)
	local var1 = var2(arg1)
	local var4 = var1:FindFirstChild(arg2)
	if not var4 then
		var4 = Instance.new("NumberValue")
		var4.Name = arg2
		var4.Value = 1
		var4:SetAttribute("FW_Owned", true)
		var4.Parent = var1
		var4.Changed:Connect(function()
			fwScaleApply(var1)
		end)

	end

	return var4
end

if not var4 then
	return
end

local function gridRatio(arg1, arg2, arg3)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChildWhichIsA("UIGridLayout")
	if not var1 then
		return arg2
	end

	local var3 = var1:GetAttribute("FigmaWinW") or 0
	if var3 <= 0 then
		return arg2
	end

	local var4 = arg1.Parent
	local var6 = (var4 and (var4:IsA("ScrollingFrame") and var4.AbsoluteSize.X) or arg1.AbsoluteSize.X) / arg3
	if var6 <= 1 then
		return arg2
	end

	return var6 / var3
end

local function fwHoverRoom(arg1, arg2, arg3)
	local num1 = 1
	if arg1 then
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("GuiObject") then
				continue
			end

			if not v1:GetAttribute("FigmaSmooth") then
				continue
			end

			local var1 = v1:GetAttribute("SmoothHover")
			var1 = var1 or (v1:GetAttribute("FigmaSmoothHover") or 1.08)
			if type(var1) ~= "number" or num1 >= var1 then
				continue
			end

			num1 = var1
		end
	end

	if num1 <= 1 then
		return 0, 0
	end

	return arg2 * (num1 - 1) / 2, arg3 * (num1 - 1) / 2
end

local var6 = setmetatable({}, { __mode = "k" })
local var7 = nil
local var8 = nil
local var9 = setmetatable({}, { __mode = "k" })
local bool1 = false
local var10 = nil
local num1 = 0
local var11 = nil
local function smRerun()
	if bool1 then
		return
	end

	bool1 = true
	task.delay(0.2, function()
		bool1 = false
		var10()
	end)
end

local var12 = var1:GetAttribute("BB_DesignH") or 1080
local var13 = var1:GetAttribute("BB_DesignW")
local function setTextPx(arg1, arg2, arg3)
	if arg1:FindFirstAncestorWhichIsA("BillboardGui") then
		return
	end

	local var1 = arg1:GetAttribute("FW_TextMine")
	if type(var1) == "number" then
		if 0.5 >= math.abs(arg1.TextSize - var1) then
			if arg1.TextScaled ~= (arg1:GetAttribute("FW_TextScaledMine") == true) then
				arg1:SetAttribute("FW_TextOwn", true)
			end
		end
	end

	if arg1:GetAttribute("FW_TextOwn") then
		return
	end

	local var2 = fwChannel(arg1, "k_text")
	local var3 = arg1:FindFirstChild("FWTextBig")
	if 100 < arg2 and (arg2 <= 500 and arg3) then
		var2.Value = 1
		if not var3 then
			var3 = Instance.new("UITextSizeConstraint")
			var3.Name = "FWTextBig"
			var3:SetAttribute("FW_Owned", true)
			var3.Parent = arg1
		end

		local var4 = math.floor(arg2)
		var3.MinTextSize = var4
		var3.MaxTextSize = var4
		arg1.TextScaled = true
		arg1.TextSize = 100
	else
		if 100 < arg2 then
			if var3 then
				var3:Destroy()
			end

			arg1.TextScaled = false
			var2.Value = arg2 / 100
			arg1.TextSize = 100
		elseif var3 then
			var3:Destroy()
		end
	end

	arg1:SetAttribute("FW_TextMine", arg1.TextSize)
	arg1:SetAttribute("FW_TextScaledMine", arg1.TextScaled)
end

local var14 = var1:GetAttribute("BB_TextFactor") or 1.16
var7 = function(arg1, arg2, arg3, arg4)
	if arg1:IsA("UIPadding") and arg1:GetAttribute("FigmaPadL") ~= nil then
		local var2 = gridRatio(arg1.Parent, arg3, arg4)
		local var3 = UDim.new(0, (arg1:GetAttribute("FigmaPadL") or 0) * var2)
		arg1.PaddingLeft = var3
		var3 = UDim.new(0, (arg1:GetAttribute("FigmaPadT") or 0) * var2)
		arg1.PaddingTop = var3
		var3 = UDim.new(0, (arg1:GetAttribute("FigmaPadB") or 0) * var2)
		arg1.PaddingBottom = var3
		return
	end

	if not arg1:IsA("UIGridLayout") or arg1:GetAttribute("FigmaCellW") == nil then
		return
	end

	local var4 = arg1.Parent
	local var5 = var4
	var5 = var5 and var4:FindFirstChildWhichIsA("UIPadding")
	local var9 = var4
	var9 = var9 and var4.Parent
	local var10 = math.max(1, arg1.FillDirectionMaxCells)
	local var11 = gridRatio(var4, arg3, arg4)
	local var12 = arg1:GetAttribute("FigmaCellW") or 0
	local var13 = arg1:GetAttribute("FigmaCellH") or 0
	local var14 = arg1:GetAttribute("FigmaGapX") or 0
	local var15 = arg1:GetAttribute("FigmaGapY") or 0
	local var16 = var5 and var5:GetAttribute("FigmaPadL") or 0
	local num2 = 0
	if var9 then
		if var9:IsA("ScrollingFrame") then
			local var17 = var9:GetAttribute("FigmaBar")
			num2 = var17 or var9.ScrollBarThickness
			var17 = var9:GetAttribute("FW_BarPx")
			if type(var17) == "number" then
				if 0.5 < math.abs(var9.ScrollBarThickness - var17) then
					num2 = var9.ScrollBarThickness / (0.001 < var11 and var11 or 1)
					var9:SetAttribute("FigmaBar", num2)
				end
			end

			local var18 = math.max(2, num2 * var11)
			var9.ScrollBarThickness = var18
			var9:SetAttribute("FW_BarPx", var18)
		end
	end

	local var23 = arg1:GetAttribute("FigmaHoverRoom")
	if var23 == nil then
		local var24 = var4
		local var25 = var12
		local var26 = var13
		var23 = select(1, fwHoverRoom(var24, var25, var26))
	end

	local var30 = (var9 and (var9:IsA("ScrollingFrame") and var9.AbsoluteSize.X) or (var4 and var4.AbsoluteSize.X or 0)) / arg4 / math.max(var11, 1e-06)
	local var31 = (var30 - var16 - (var10 - 1) * var14 - num2 - var23) / var10
	local var32 = var12
	if 1 < var30 and (0 < var31 and var31 < var32) then
		var32 = var31
	end

	arg1.CellSize = UDim2.fromOffset(math.max(1, var32 * var11), (math.max(1, var13 * (var32 / math.max(var12, 1e-06)) * var11)))
	arg1.CellPadding = UDim2.fromOffset(var14 * var11, var15 * var11)
	local var34 = var6[arg1]
	if not var34 then
		var34 = {}
		var6[arg1] = var34
	end

	if var4 and (not var34.sizeWired) then
		var34.sizeWired = true
		var4:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			if var34.refit then
				if not var34.busy then
					local var4 = workspace.CurrentCamera
					local bool4 = false
					if var4 ~= nil then
						bool4 = false
						if 2 <= var4.ViewportSize.X then
							bool4 = 2 <= var4.ViewportSize.Y
						end
					end

					if bool4 then
						var34.busy = true
						var34.refit()
						var34.busy = false
					end
				end
			end
		end)

	end

	var34.refit = function()
		var7(arg1, arg2, arg3, arg4)
		if var5 then
			var7(var5, arg2, arg3, arg4)
		end

		if var9 then
			var8(var9)
		end
	end
end

var8 = function(arg1)
	if not arg1:IsA("ScrollingFrame") or (not arg1:GetAttribute("FWGridScroll")) then
		return
	end

	local var1 = nil
	local var2 = nil
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "Cells" then
			continue
		end

		if not v1:GetAttribute("FW_Owned") then
			continue
		end

		local var3 = v1:FindFirstChildWhichIsA("UIGridLayout")
		if not var3 then
			continue
		end

		var1 = v1
		var2 = var3
		break
	end

	if not var2 then
		return
	end

	local var5 = var6[var2]
	local var7 = var1:FindFirstChildWhichIsA("UIPadding")
	if not var5 then
		var5 = {}
		var6[var2] = var5
	end

	if not var5.canvasWired then
		var5.canvasWired = true
		var2:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			if var5.set then
				local var3 = workspace.CurrentCamera
				local bool3 = false
				if var3 ~= nil then
					bool3 = false
					if 2 <= var3.ViewportSize.X then
						bool3 = 2 <= var3.ViewportSize.Y
					end
				end

				if bool3 then
					var5.set()
				end
			end
		end)

		var1.ChildAdded:Connect(function()
			if var5.set then
				local var3 = workspace.CurrentCamera
				local bool3 = false
				if var3 ~= nil then
					bool3 = false
					if 2 <= var3.ViewportSize.X then
						bool3 = 2 <= var3.ViewportSize.Y
					end
				end

				if bool3 then
					var5.set()
				end
			end
		end)

		var1.ChildRemoved:Connect(function()
			if var5.set then
				local var3 = workspace.CurrentCamera
				local bool3 = false
				if var3 ~= nil then
					bool3 = false
					if 2 <= var3.ViewportSize.X then
						bool3 = 2 <= var3.ViewportSize.Y
					end
				end

				if bool3 then
					var5.set()
				end
			end
		end)

	end

	var5.set = function()
		local var3 = var2.CellSize.Y.Offset
		local var4 = var2.CellPadding.Y.Offset
		local var6 = var3 + var4
		local var8 = var7 and var7.PaddingTop.Offset or 0
		local var9 = var7 and var7.PaddingBottom.Offset or 0
		local num1 = 0
		if 0 < var6 then
			num1 = math.max(0, (math.floor((var2.AbsoluteContentSize.Y + var4) / var6 + 0.5)))
		end

		if num1 == 0 then
			local num2 = 0
			for k1, v1 in ipairs(var1:GetChildren()) do
				if not v1:IsA("GuiObject") then
					continue
				end

				if not v1.Visible then
					continue
				end

				num2 = num2 + 1
			end

			num1 = math.ceil(num2 / math.max(1, var2.FillDirectionMaxCells))
		end

		local var11 = 0 < num1 and var8 + num1 * var3 + (num1 - 1) * var4 + var9 or 0
		if var11 <= arg1.AbsoluteWindowSize.Y + 1 then
			var11 = 0
		end

		arg1.CanvasSize = UDim2.fromOffset(0, var11)
	end

	var5.set()
end

local bool2 = false
local num2 = 0
local bool3 = false
var10 = function()
	local var1 = num1 + 1
	num1 = var1
	local var2 = var4:FindFirstChild("FW_Scale")
	var2 = var2 or (var4:FindFirstChild("FramewispSmooth") or var4:FindFirstChild("FWActScale"))
	var1 = num1
	local var3 = var2 and (var2:IsA("UIScale") and (0 < var2.Scale and var2.Scale)) or 1
	if var2 and (var2 ~= var11 and var2:IsA("UIScale")) then
		var11 = var2
		var2:GetPropertyChangedSignal("Scale"):Connect(smRerun)
	end

	local var15 = var4.AbsoluteSize.Y / var12 / var3
	if var15 <= 0 then
		return
	end

	local var17 = workspace.CurrentCamera
	local bool3 = false
	if var17 ~= nil then
		bool3 = false
		if 2 <= var17.ViewportSize.X then
			bool3 = 2 <= var17.ViewportSize.Y
		end
	end

	if not bool3 then
		return
	end

	if var4.AbsoluteSize.X < 2 or var4.AbsoluteSize.Y < 2 then
		return
	end

	bool3 = type(var13) == "number" and (0 < var13 and var4.AbsoluteSize.X / var13 / var3) or var15
	var17 = false
	local num3 = 0
	local num4 = 0
	for k1, v1 in ipairs(var4:GetDescendants()) do
		if var1 ~= num1 then
			return
		end

		local var19 = v1:GetAttribute("FigmaFontSize")
		if var19 then
			local var20 = v1:GetAttribute("FigmaTextW")
			local var22 = nil
			if type(var20) == "number" then
				if 0 < var20 then
					local var25 = v1:GetAttribute("FW_Text0")
					if var25 == nil then
						var25 = v1.ContentText
						v1:SetAttribute("FW_Text0", var25)
					end

					if v1.ContentText == var25 then
						local var29 = v1:GetAttribute("FW_M100")
						if not var29 then
							local var31 = var9[v1]
							if var31 ~= nil then
								var29 = var31
							else
								local success, result = pcall(function()
									local var1 = Instance.new("GetTextBoundsParams")
									var1.Text = v1.ContentText:gsub("^%s+", ""):gsub("%s+$", "")
									var1.Font = v1.FontFace
									var1.Size = 100
									var1.Width = 1000000
									local var2 = var1
									return var5:GetTextBoundsAsync(var2)
								end)

								if success and (result and 0 < result.X) then
									var9[v1] = result.X
									var29 = result.X
								elseif success then
									var9[v1] = false
								end
							end
						end

						var22 = var29
						var17 = var22 == nil and (var9[v1] == nil and true)
					end

					if var1 ~= num1 then
						return
					end
				end
			end

			if var22 then
				setTextPx(v1, 100 * (var20 * bool3) / var22, true)
				num3 = num3 + 1
			else
				setTextPx(v1, var19 * var15 * var14)
				num4 = num4 + 1
			end
		end

		local var32 = v1:GetAttribute("FW_StrokeMine")
		if type(var32) == "number" and 0.01 < math.abs(v1.Thickness - var32) then
			v1:SetAttribute("FW_StrokeOwn", true)
		end

		if not v1:GetAttribute("FW_StrokeOwn") then
			if not v1:GetAttribute("FW_StrokeScaled") then
				local var36 = v1:GetAttribute("FigmaStrokeW")
				if var36 then
					v1.Thickness = math.max(0.35, var36 * var15)
				end

				local var38 = v1:GetAttribute("FigmaTextStrokeW")
				if var38 then
					local var39 = v1.Parent
					var39 = var39 and v1.Parent:FindFirstChild("FW_Scale")
					v1.Thickness = math.max(0.35, var38 * var15 * var14 / (var39 and var39.Scale or 1))
				end

				if var36 or var38 then
					v1:SetAttribute("FW_StrokeMine", v1.Thickness)
				end
			end
		end

		var7(v1, var15, bool3, var3)
		var8(v1)
	end

	var8(var4)
	if not bool2 and (0 < num3 + num4 and game:GetService("ReplicatedStorage"):GetAttribute("FramewispLogging") == true) then
		bool2 = true
		local var40 = num3
		local var41 = num4
		print(("[Framewisp] TextScaler: %d width-exact, %d fallback"):format(var40, var41))
		local var43 = var4.AbsoluteSize.Y
		local tbl1 = {}
		local num5 = 0
		if 1 < var43 then
			for k2, v2 in ipairs(var4:GetDescendants()) do
				local var44 = v2:GetAttribute("FW_EDbg")
				if type(var44) ~= "string" then
					continue
				end

				if not v2:IsA("TextLabel") then
					continue
				end

				if 0 >= v2.AbsoluteSize.Y then
					continue
				end

				local var45, var46 = var44:match("([%d.]+)|([%d.]+)")
				var45 = tonumber(var45)
				var46 = tonumber(var46)
				if not var45 or (not var46) then
					continue
				end

				local var47 = v2.TextSize / var43 - var45
				local var48 = (v2.AbsolutePosition.Y - var4.AbsolutePosition.Y + v2.AbsoluteSize.Y / 2) / var43 - var46
				if 0.002 < math.abs(var47) or 0.002 < math.abs(var48) then
					tbl1[#tbl1 + 1] = { n = v2.Name, dl = var47 * var43, dc = var48 * var43 }
				end
			end
		end

		table.sort(tbl1, function(arg1, arg2)
			return math.abs(arg2.dc) + math.abs(arg2.dl) < math.abs(arg1.dc) + math.abs(arg1.dl)
		end)

		for i1 = 1, math.min(3, #tbl1) do
			local var49 = tbl1[i1]
			local var50 = var49.n
			local var51 = var49.dl
			local var52 = var49.dc
			print(("[Framewisp] play vs edit %q: size %+.1f px, centre %+.1f px"):format(var50, var51, var52))
		end

		if #tbl1 == 0 then
			print("[Framewisp] play matches the editor within 0.2% \226\128\148 any remaining shift is pure rendering")
		end
	end

	if var17 and num2 < 6 then
		local var53 = num2 + 1
		num2 = var53
		task.delay(0.5, function()
			if var1 == num1 then
				var10()
			end
		end)

	end
end

var4:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
	if bool3 then
		return
	end

	bool3 = true
	task.spawn(function()
		task.wait()
		bool3 = false
		var10()
	end)
end)

var10()

--- ReplicatedStorage.Packages.DataService [ModuleScript]
-- y u r i

local var1 = require(script.DataServiceServer)
local var2 = require(script.DataServiceClient)
return { server = var1, client = var2 }

--- ReplicatedStorage.Packages.DataService.Data [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Signal)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local tbl2 = { changed = setmetatable({}, { __mode = "v" }) }
	tbl2.indexChanged = setmetatable({}, { __mode = "v" })
	tbl2.arrayInserted = setmetatable({}, { __mode = "v" })
	tbl2.arrayRemoved = setmetatable({}, { __mode = "v" })
	local tbl3 = {
		_data = arg1,
		_signals = { changed = {}, indexChanged = {}, arrayInserted = {}, arrayRemoved = {} },
		_weakSignals = tbl2,
	}

	setmetatable(tbl3, tbl1)
	return tbl3
end

tbl1.get = function(arg1, arg2)
	if not arg2 then
		return arg1._data
	end

	local var2 = arg1._data
	if type(arg2) == "string" then
		return var2[arg2]
	end

	for k1, v1 in ipairs(arg2) do
		var2 = var2[v1]
	end

	return var2
end

tbl1.set = function(arg1, arg2, arg3)
	local var2 = arg1._data
	if type(arg2) == "string" then
		local var3 = var2[arg2]
		var2[arg2] = arg3
		arg1:_firePathChangedSignals(arg2, var3)
		return
	end

	for i1 = 1, #arg2 - 1 do
		var2 = var2[arg2[i1]]
	end

	local var4 = var2[arg2[#arg2]]
	var2[arg2[#arg2]] = arg3
	arg1:_firePathChangedSignals(arg2, var4)
end

tbl1.update = function(arg1, arg2, arg3)
	local var1 = arg3((arg1:get(arg2)))
	arg1:set(arg2, var1)
	return var1
end

tbl1.arrayInsert = function(arg1, arg2, arg3, arg4)
	local var1 = arg1:get(arg2)
	assert(type(var1) == "table", "Data at path is not a table")
	if arg4 then
		table.insert(var1, arg4, arg3)
	else
		table.insert(var1, arg3)
	end

	local var3 = arg1._signals.arrayInserted[arg1:_firePathChangedSignals(arg2)]
	if var3 then
		local var4 = arg4
		var3:Fire(var4 or (#var1), arg3)
	end
end

tbl1.arrayRemove = function(arg1, arg2, arg3)
	local var1 = arg1:get(arg2)
	assert(type(var1) == "table", "Data at path is not a table")
	local var4 = arg1._signals.arrayRemoved[arg1:_firePathChangedSignals(arg2)]
	local var5 = table.remove(var1, arg3)
	if var4 then
		var4:Fire(arg3, var5)
	end

	return var5
end

tbl1.getChangedSignal = function(arg1, arg2)
	local var1 = arg2
	local str1 = "changed"
	return arg1:_getSignal(var1, str1)
end

tbl1.getIndexChangedSignal = function(arg1, arg2)
	local var1 = arg2
	local str1 = "indexChanged"
	return arg1:_getSignal(var1, str1)
end

tbl1.getArrayInsertedSignal = function(arg1, arg2)
	local var1 = arg2
	local str1 = "arrayInserted"
	return arg1:_getSignal(var1, str1)
end

tbl1.getArrayRemovedSignal = function(arg1, arg2)
	local var1 = arg2
	local str1 = "arrayRemoved"
	return arg1:_getSignal(var1, str1)
end

tbl1._firePathChangedSignals = function(arg1, arg2, arg3)
	local var2
	if type(arg2) == "string" then
		var2 = arg2
		arg1:_fireChangedSignal(arg2, arg1:get(var2), arg3)
		return arg2
	end

	local var3 = arg1._data
	local str1 = ""
	for k1, v1 in ipairs(arg2) do
		var3 = var3[v1]
		if 1 < k1 then
			arg1:_fireIndexChangedSignal(str1, v1, var3, arg3)
			str1 = str1 .. "."
		end

		if type(v1) == "number" then
			str1 = str1 .. "#"
		end

		str1 = str1 .. v1
		arg1:_fireChangedSignal(str1, var3, arg3)
	end

	return str1
end

tbl1._fireChangedSignal = function(arg1, arg2, arg3, arg4)
	local var2 = arg1._signals.changed[arg2]
	if var2 then
		var2:Fire(arg3, arg4)
	end
end

tbl1._fireIndexChangedSignal = function(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg1._signals.indexChanged[arg2]
	if var2 then
		var2:Fire(arg3, arg4, arg5)
	end
end

local function pathToString(arg1)
	if type(arg1) == "string" then
		return arg1
	end

	local str1 = ""
	for k1, v1 in ipairs(arg1) do
		local var1 = #arg1
		if type(v1) == "number" then
			str1 = str1 .. "#"
		end

		if k1 >= var1 then
			continue
		end

		str1 = str1 .. v1 .. "."
	end

	return str1
end

tbl1._getSignal = function(arg1, arg2, arg3)
	local var2 = arg1._weakSignals[arg3]
	local var3 = pathToString(arg2)
	local var5 = var2[var3]
	if var5 then
		return var5
	end

	var5 = var1.new()
	var2[var3] = var5
	local num1 = 0
	local var6 = arg1._signals[arg3]
	for k1, v1 in { Connect = var5.Connect, Once = var5.Once }, nil do
		var5[k1] = function(_, arg2)
			local var1 = v1(var5, arg2)
			local var2 = num1 + 1
			num1 = var2
			var6[var3] = var5
			var2 = var1.Disconnect
			var1.Disconnect = function()
				if var1.Connected then
					local var4 = num1 - 1
					num1 = var4
					if num1 <= 0 then
						var6[var3] = nil
					end
				end

				var2(var1)
			end

			var1.Destroy = var1.Disconnect
			return var1
		end

	end

	local var7 = var5.Destroy
	var5.Destroy = function()
		num1 = 0
		var6[var3] = nil
		var2[var3] = nil
		var7(var5)
	end

	local var8 = var5.DisconnectAll
	var5.DisconnectAll = function()
		num1 = 0
		var6[var3] = nil
		var8(var5)
	end

	return var5
end

tbl1.destroy = function(arg1)
	for k1, v1 in arg1._signals, nil do
		for k2, v2 in v1, nil do
			v2:Destroy()
		end
	end

	arg1._signals = nil
end

return tbl1

--- ReplicatedStorage.Packages.DataService.DataServiceClient [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
if var1:IsServer() then
	return {}
end

local var2 = script.Parent
local var3 = require(var2.Networker)
local var4 = require(script.Parent.DataServiceUtils)
local var5 = require(script.Parent.Data)
local var6 = require(var2.Signal).new()
local tbl1 = {
	_data = nil,
	init = function(arg1, arg2)
		local var2 = var3.client.new("DataService", arg1)
		arg1.networker = var2
		if arg2 then
			arg1:_initData(arg2)
		end

		if var1:IsRunning() then
			task.spawn(function()
				task.wait(3)
				local var1 = os.clock()
				while true do
					if arg1._data then
						break
					end

					local var2 = math.floor(os.clock() - var1)
					if arg1._data then
						break
					end

					local success, result = pcall(function()
						local str1 = "snapshot"
						local var1 = var2
						return arg1.networker:fetch(str1, var1)
					end)

					if success and type(result) == "table" then
						arg1:_initData(result)
						return
					end

					if 60 <= var2 then
						pcall(function()
							arg1.networker:fire("stalled", var2)
						end)

						return
					end

					task.wait(2)
				end
			end)

		end

		arg1:waitForData()
	end,
	fetch = function(arg1, arg2, arg3)
		local var2 = arg1.networker:fetch("get", arg2)
		if not arg3 then
			arg1._data:set(arg2, var2)
		end

		return var2
	end,
	get = function(arg1, arg2)
		arg1:waitForData()
		local var1 = arg2
		return arg1._data:get(var1)
	end,
	set = function(arg1, arg2, arg3)
		if not arg1._data then
			return
		end

		arg1._data:set(arg2, arg3)
	end,
	update = function(arg1, arg2, arg3)
		local var1 = arg2
		local var2 = arg3
		return arg1._data:update(var1, var2)
	end,
	arrayInsert = function(arg1, arg2, arg3, arg4)
		if not arg1._data then
			return
		end

		arg1._data:arrayInsert(arg2, arg3, arg4)
	end,
	arrayRemove = function(arg1, arg2, arg3)
		if not arg1._data then
			return nil
		end

		local var1 = arg2
		local var2 = arg3
		return arg1._data:arrayRemove(var1, var2)
	end,
	getChangedSignal = function(arg1, arg2)
		local var1 = arg2
		return arg1._data:getChangedSignal(var1)
	end,
	getIndexChangedSignal = function(arg1, arg2)
		local var1 = arg2
		return arg1._data:getIndexChangedSignal(var1)
	end,
	getArrayInsertedSignal = function(arg1, arg2)
		local var1 = arg2
		return arg1._data:getArrayInsertedSignal(var1)
	end,
	getArrayRemovedSignal = function(arg1, arg2)
		local var1 = arg2
		return arg1._data:getArrayRemovedSignal(var1)
	end,
	waitForData = function(arg1)
		local var2 = arg1._data
		if var2 then
			return var2
		end

		var6:Wait()
		return arg1._data
	end,
	_initData = function(arg1, arg2)
		if arg1._data ~= nil then
			return
		end

		arg1._data = var5.new(arg2)
		local var2 = game:GetService("Players").LocalPlayer
		if var2 then
			var2:SetAttribute("DataReady", true)
		end

		var6:Fire()
	end,
}

local var7 = tbl1.set
tbl1[var4.enums.actions.set] = var7
var7 = tbl1.arrayInsert
tbl1[var4.enums.actions.arrayInsert] = var7
var7 = tbl1.arrayRemove
tbl1[var4.enums.actions.arrayRemove] = var7
var7 = tbl1._initData
tbl1[var4.enums.actions.init] = var7
return tbl1

--- ReplicatedStorage.Packages.DataService.DataServiceServer [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("Players")
if var1:IsClient() then
	return {}
end

local var3 = script.Parent
local var4 = require(var3.Signal)
local var5 = require(var3.Networker)
local var6 = if var1:IsServer() then require(var3.ProfileStore) else nil
local var7 = require(script.Parent.Data)
local var8 = require(script.Parent.DataServiceUtils)
local tbl1 = {
	_profiles = {},
	_data = {},
	_waitSignals = {},
	_globalCallbacks = {},
	_globalCallbackAdded = var4.new(),
	onStallRejoin = nil,
}

tbl1._removalFunctions = {}
tbl1._teleportReleases = {}
tbl1._snapshotServed = {}
tbl1._stallHandled = {}
tbl1._finalized = setmetatable({}, { __mode = "k" })
tbl1.options = {}
tbl1.init = function(arg1, arg2)
	assert(var1:IsServer(), "DataServiceServer can only be used on the server.")
	assert(not arg1.playerStore, "DataServiceServer has already been initialized.")
	arg1.options = arg2
	var6.SetConstant("AUTO_SAVE_PERIOD", 60)
	arg1.playerStore = var6.New(arg2.profileStoreIndex or "Default", arg2.template)
	var6.OnError:Connect(function(arg1, _, arg3)
		pcall(arg1.onSaveIssue, arg1, "error", tostring(arg1), arg3)
	end)

	var6.OnOverwrite:Connect(function(_, arg2)
		pcall(arg1.onSaveIssue, arg1, "overwrite", "", arg2)
	end)

	var6.OnCriticalToggle:Connect(function(arg1)
		local var1 = pcall
		local var2 = arg1.onSaveIssue
		local var3 = arg1
		var1(var2, var3, if arg1 then "critical" else "recovered", "", nil)
	end)

	local var3 = arg1.get
	local var4 = var5.server.new("DataService", arg1, { var3, arg1.snapshot, arg1.stalled })
	arg1.networker = var4
	for k1, v1 in var2:GetPlayers() do
		task.spawn(function()
			arg1:_playerAdded(v1)
		end)

	end

	var2.PlayerAdded:Connect(function(arg1)
		arg1:_playerAdded(arg1)
	end)

	var2.PlayerRemoving:Connect(function(arg1)
		arg1._snapshotServed[arg1] = nil
		arg1._stallHandled[arg1] = nil
		arg1:_playerRemoving(arg1)
	end)
end

tbl1.resetData = function(arg1, arg2)
	arg1:_playerRemoving(arg2)
	arg1.playerStore:RemoveAsync((arg1:_getProfileKey(arg2.UserId)))
	arg2:Kick("Your data has been reset. Please rejoin.")
end

tbl1._playerAdded = function(arg1, arg2)
	local var1 = arg1.options.overridenUserId
	var1 = var1 or (arg1.options.viewedUserId or arg2.UserId)
	local var4 = arg1:_getProfileKey(var1)
	if arg1.options.resetData and (not arg1.options.viewedUserId) then
		arg1.playerStore:RemoveAsync(var4)
	end

	local var5 = os.clock()
	local var6
	if arg1.options.useMock then
		var6 = arg1.playerStore.Mock:StartSessionAsync(var4, { Cancel = function()
			return arg2.Parent ~= var2
		end })

	else
		if arg1.options.viewedUserId or arg1.options.dontSave then
			var6 = arg1.playerStore:GetAsync(var4)
		else
			var6 = arg1.playerStore:StartSessionAsync(var4, { Cancel = function()
				return arg2.Parent ~= var2
			end })

		end
	end

	local var10 = os.clock() - var5
	if 3 < var10 then
		local var11 = arg2.Name
		local var12 = var10
		warn(("[DataService] profile for %s took %.1fs to load - the previous server likely still held the session lock"):format(var11, var12))
	end

	if 10 < var10 then
		pcall(arg1.onStall, arg1, arg2, "slowLoad", var10)
	end

	if not var6 then
		arg2:Kick("Profile load fail - Please rejoin")
		return
	end

	if type(var6.Data) == "table" and 2 < (tonumber(var6.Data.dataVersion) or 1) then
		pcall(function()
			var6:EndSession()
		end)

		arg2:Kick("This server is running an older version of the game - please rejoin!")
		return
	end

	var6:AddUserId(var1)
	var6:Reconcile()
	var6.OnSessionEnd:Connect(function()
		arg1._profiles[arg2] = nil
		if arg1._teleportReleases[arg2] then
			arg1._teleportReleases[arg2] = nil
			return
		end

		arg2:Kick("Profile session end - Please rejoin")
	end)

	if not arg2:IsDescendantOf(var2) then
		pcall(function()
			var6:EndSession()
		end)

		arg2:Kick("Profile load fail - Please rejoin")
		return
	end

	var6.OnLastSave:Connect(function()
		arg1:_finalize(arg2, var6)
	end)

	arg1._profiles[arg2] = var6
	arg1:_initPlayer(arg2, var6.Data)
	if not arg2:IsDescendantOf(var2) then
		arg1:_playerRemoving(arg2)
		arg2:Kick("Profile load fail - Please rejoin")
		return
	end

	var6:MessageHandler(function(arg1, arg2)
		local var2 = arg1._globalCallbacks[arg1.key]
		if var2 then
			if var2(arg2, arg1.data) ~= false then
				arg2()
			end

			return
		end

		local var3 = nil
		arg1._globalCallbackAdded:Connect(function(arg1)
			if arg1 ~= arg1.key then
				return
			end

			if arg1._globalCallbacks[arg1.key](arg2, arg1.data) ~= false then
				arg2()
			end

			var3:Disconnect()
		end)
	end)
end

tbl1.snapshot = function(arg1, arg2, arg3)
	local var2 = arg1._data[arg2]
	if not var2 then
		return nil
	end

	if not arg1._snapshotServed[arg2] then
		arg1._snapshotServed[arg2] = true
		local var3 = pcall
		local var4 = arg1.onStall
		local var5 = arg1
		local var6 = arg2
		local str1 = "fetch"
		var3(var4, var5, var6, str1, if type(arg3) == "number" then arg3 else 0)
	end

	return var2._data
end

tbl1.stalled = function(arg1, arg2, arg3)
	if arg1._data[arg2] or arg1._stallHandled[arg2] then
		return
	end

	arg1._stallHandled[arg2] = true
	local var1 = pcall
	local var2 = arg1.onStall
	local var3 = arg1
	local var4 = arg2
	local str1 = "rejoin"
	var1(var2, var3, var4, str1, if type(arg3) == "number" then arg3 else 0)
	if arg1.onStallRejoin then
		arg1.onStallRejoin(arg2)
		return
	end

	arg2:Kick("Your save did not load. Please rejoin - your progress is safe.")
end

tbl1.onStall = function(_, _, _, _)
end

tbl1._getProfileKey = function(arg1, arg2)
	return (arg1.options.profileStoreDataPrefix or "PLAYER_") .. tostring(arg2)
end

tbl1.sendGlobalMessage = function(arg1, arg2, arg3, arg4)
	local var1 = arg1:_getProfileKey(arg3)
	local tbl1 = { key = arg2, data = arg4 }
	return arg1.playerStore:MessageAsync(var1, tbl1)
end

tbl1.addGlobalCallback = function(arg1, arg2, arg3)
	assert(arg1._globalCallbacks[arg2] == nil, "Global callback already exists for key: " .. arg2)
	arg1._globalCallbacks[arg2] = arg3
	arg1._globalCallbackAdded:Fire(arg2)
end

tbl1._playerRemoving = function(arg1, arg2)
	local var2 = arg1._profiles[arg2]
	if not var2 then
		return
	end

	var2:EndSession()
	arg1._profiles[arg2] = nil
	local var4 = arg1._waitSignals[arg2]
	if var4 then
		var4:Destroy()
		arg1._waitSignals[arg2] = nil
	end

	local var6 = arg1._data[arg2]
	if var6 then
		var6:destroy()
		arg1._data[arg2] = nil
	end
end

tbl1.onPlayerInit = function(_, _, _)
end

tbl1.releaseForTeleport = function(arg1, arg2)
	if not arg1._profiles[arg2] then
		return
	end

	arg1._teleportReleases[arg2] = true
	arg1:_playerRemoving(arg2)
end

tbl1.addPlayerRemovingCallback = function(arg1, arg2)
	table.insert(arg1._removalFunctions, arg2)
	return function()
		local var2 = table.find(arg1._removalFunctions, arg2)
		if var2 then
			table.remove(arg1._removalFunctions, var2)
		end
	end
end

tbl1.asyncGetProfile = function(arg1, arg2)
	local var1 = "PLAYER_" .. tostring(arg2)
	return arg1.playerStore:GetAsync(var1)
end

local tbl2 = { 1000, 310000, 94000000 }
tbl2[5] = 5600000000
tbl2[6] = 17000000000
tbl2[7] = 50000000000
tbl2[9] = 750000000000
tbl2[10] = 2400000000000
tbl2[11] = 7500000000000
tbl2[13] = 110000000000000
tbl2[14] = 580000000000000
tbl2[15] = 3000000000000000
tbl2[17] = 8.4e+16
tbl2[18] = 4.4e+17
tbl2[19] = 2.3e+18
tbl2[21] = 6.3e+19
tbl2[22] = 3.3e+20
tbl2[23] = 1.7e+21
local tbl3 = { 3, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 }
local function oldPriceScale(arg1)
	local num1 = 1
	for i1 = 1, math.min(arg1, #tbl3) do
		num1 = num1 * tbl3[i1]
	end

	local var2 = nil
	if arg1 <= 2 then
		var2 = 0.4
	else
		var2 = if 12 < arg1 then math.max(0.33, 0.58 - (arg1 - 12) * 0.055) else math.min(0.58, (arg1 - 2) * 0.035 + 0.4)
	end

	return num1 ^ var2
end

local function migrate(arg1)
	if type(arg1) ~= "table" then
		return
	end

	if (tonumber(arg1.dataVersion) or 1) < 2 then
		local var1 = arg1.rebirths
		local var2 = math.max(0, (math.floor(tonumber(var1) or 0)))
		local num1 = 0
		if type(arg1.doors) == "table" then
			for k1, v1 in pairs(tbl2) do
				local var3 = "rebirth" .. k1
				if not arg1.doors[var3] then
					continue
				end

				if var2 < k1 then
					num1 = num1 + v1 * oldPriceScale(var2)
				end

				arg1.doors[var3] = nil
			end

			if arg1.doors.door27 then
				num1 = num1 + oldPriceScale(var2) * 1.7e+18
				arg1.doors.door27 = nil
			end
		end

		if 0 < num1 then
			local var4 = (tonumber(arg1.gold) or 0) + math.floor(num1)
			arg1.gold = var4
		end

		arg1.rebirths = math.min(6, (math.ceil(var2 / 4)))
		if type(arg1.upgrades) == "table" then
			arg1.upgrades.keepTower1 = nil
			arg1.upgrades.keepTower2 = nil
			arg1.upgrades.keepTower3 = nil
		end

		if type(arg1.funnels) == "table" then
			for i1 = 1, arg1.rebirths do
				arg1.funnels["sectionRebirth:" .. i1] = true
			end
		end

		arg1.dataVersion = 2
	end
end

tbl1.migrate = migrate
tbl1._initPlayer = function(arg1, arg2, arg3)
	migrate(arg3)
	arg1._data[arg2] = var7.new(arg3)
	arg1:onPlayerInit(arg2, arg3)
	arg1.networker:fire(arg2, var8.enums.actions.init, arg3)
	local var2 = arg1._waitSignals[arg2]
	if var2 then
		var2:Fire()
		var2:Destroy()
		arg1._waitSignals[arg2] = nil
	end
end

tbl1.saveNow = function(arg1, arg2)
	local var2 = arg1._profiles[arg2]
	if var2 and var2:IsActive() then
		pcall(function()
			var2:Save()
		end)

	end
end

tbl1._finalize = function(arg1, arg2, arg3)
	if arg1._finalized[arg3] then
		return
	end

	arg1._finalized[arg3] = true
	for k1, v1 in table.clone(arg1._removalFunctions) do
		task.spawn(function()
			local success, result = pcall(v1, arg2, arg3.Data)
			if not success then
				local var2 = result
				warn(var2 or "Error in removal function for " .. arg2.Name)
			end
		end)

	end
end

tbl1.saveAndConfirm = function(arg1, arg2, arg3)
	local var2 = arg1._profiles[arg2]
	if not var2 or (not var2:IsActive()) then
		return false
	end

	local var3 = var2.Data
	local var4 = (tonumber(var3.saveMark) or 0) + 1
	var3.saveMark = var4
	local var5 = os.clock() + (arg3 or 25)
	local num1 = 0
	while true do
		if os.clock() >= var5 then
			break
		end

		local var6 = var2.LastSavedData
		local bool1 = false
		if type(var6) == "table" then
			bool1 = var4 <= (tonumber(var6.saveMark) or 0)
		end

		if bool1 then
			return true
		end

		if var2:IsActive() and num1 <= os.clock() then
			pcall(function()
				var2:Save()
			end)

		end

		task.wait(0.1)
		local var7 = os.clock() + 7
	end

	local var8 = var2.LastSavedData
	local bool2 = false
	if type(var8) == "table" then
		bool2 = var4 <= (tonumber(var8.saveMark) or 0)
	end

	return bool2
end

tbl1.onSaveIssue = function(_, _, _, _)
end

tbl1.hasProfile = function(arg1, arg2)
	return arg1._profiles[arg2] ~= nil
end

tbl1.getProfile = function(arg1, arg2)
	assert(arg1._profiles[arg2], "Profile does not exist for " .. arg2.Name)
	return arg1._profiles[arg2]
end

tbl1.waitForData = function(arg1, arg2)
	local var2 = arg1._data[arg2]
	if var2 then
		return var2
	end

	local var5 = arg1._waitSignals[arg2]
	if not var5 then
		var5 = var4.new()
		arg1._waitSignals[arg2] = var5
	end

	var5:Wait()
	return arg1._data[arg2]
end

tbl1.get = function(arg1, arg2, arg3)
	local var1 = arg3
	return arg1._data[arg2]:get(var1)
end

tbl1.set = function(arg1, arg2, arg3, arg4, arg5)
	if not arg5 then
		arg1.networker:fire(arg2, var8.enums.actions.set, arg3, arg4)
	end

	arg1._data[arg2]:set(arg3, arg4)
end

tbl1.update = function(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg1._data[arg2]:update(arg3, arg4)
	if not arg5 then
		arg1.networker:fire(arg2, var8.enums.actions.set, arg3, var2)
	end

	return var2
end

tbl1.arrayInsert = function(arg1, arg2, arg3, arg4, arg5, arg6)
	if not arg6 then
		arg1.networker:fire(arg2, var8.enums.actions.arrayInsert, arg3, arg4, arg5)
	end

	arg1._data[arg2]:arrayInsert(arg3, arg4, arg5)
end

tbl1.arrayRemove = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1._data[arg2]:arrayRemove(arg3, arg4)
	if not arg5 then
		arg1.networker:fire(arg2, var8.enums.actions.arrayRemove, arg3, arg4)
	end

	return var1
end

tbl1.getChangedSignal = function(arg1, arg2, arg3)
	local var1 = arg3
	return arg1._data[arg2]:getChangedSignal(var1)
end

tbl1.getIndexChangedSignal = function(arg1, arg2, arg3)
	local var1 = arg3
	return arg1._data[arg2]:getIndexChangedSignal(var1)
end

tbl1.getArrayInsertedSignal = function(arg1, arg2, arg3)
	local var1 = arg3
	return arg1._data[arg2]:getArrayInsertedSignal(var1)
end

tbl1.getArrayRemovedSignal = function(arg1, arg2, arg3)
	local var1 = arg3
	return arg1._data[arg2]:getArrayRemovedSignal(var1)
end

return tbl1

--- ReplicatedStorage.Packages.DataService.DataServiceUtils [ModuleScript]
-- y u r i

return { enums = { actions = { init = 0, set = 1, arrayInsert = 2, arrayRemove = 3 } } }

--- ReplicatedStorage.Packages.DataService.Signal [ModuleScript]
-- y u r i

local var1 = nil
local function acquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local tbl1 = {}
tbl1.__index = tbl1
tbl1.Disconnect = function(arg1)
	if not arg1.Connected then
		return
	end

	arg1.Connected = false
	if arg1._signal._handlerListHead == arg1 then
		arg1._signal._handlerListHead = arg1._next
		return
	end

	local var1 = arg1._signal._handlerListHead
	while var1 and var1._next ~= arg1 do
		var1 = var1._next
	end

	if var1 then
		var1._next = arg1._next
	end
end

tbl1.Destroy = tbl1.Disconnect
setmetatable(tbl1, {
	__index = function(_, arg2)
		error(("Attempt to get Connection::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
	__newindex = function(_, arg2, _)
		error(("Attempt to set Connection::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
})

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function()
	return (setmetatable({ _handlerListHead = false, _proxyHandler = nil, _yieldedThreads = nil }, tbl2))
end

tbl2.Wrap = function(arg1)
	assert(typeof(arg1) == "RBXScriptSignal", "Argument #1 to Signal.Wrap must be a RBXScriptSignal; got " .. typeof(arg1))
	local var1 = tbl2.new()
	var1._proxyHandler = arg1:Connect(function(...)
		var1:Fire(...)
	end)

	return var1
end

tbl2.Is = function(arg1)
	local bool1 = false
	if type(arg1) == "table" then
		bool1 = getmetatable(arg1) == tbl2
	end

	return bool1
end

tbl2.Connect = function(arg1, arg2)
	local var1 = setmetatable({ Connected = true, _signal = arg1, _fn = arg2, _next = false }, tbl1)
	if arg1._handlerListHead then
		var1._next = arg1._handlerListHead
		arg1._handlerListHead = var1
		return var1
	end

	arg1._handlerListHead = var1
	return var1
end

tbl2.ConnectOnce = function(arg1, arg2)
	local var1 = arg2
	return arg1:Once(var1)
end

tbl2.Once = function(arg1, arg2)
	local bool1 = false
	local var1 = nil
	return (arg1:Connect(function(...)
		if bool1 then
			return
		end

		bool1 = true
		var1:Disconnect()
		arg2(...)
	end))
end

tbl2.GetConnections = function(arg1)
	local tbl1 = {}
	local var1 = arg1._handlerListHead
	while var1 do
		table.insert(tbl1, var1)
		var1 = var1._next
	end

	return tbl1
end

tbl2.DisconnectAll = function(arg1)
	local var1 = arg1._handlerListHead
	while var1 do
		var1.Connected = false
		var1 = var1._next
	end

	arg1._handlerListHead = false
	local var3 = rawget(arg1, "_yieldedThreads")
	if var3 then
		for k1 in var3, nil do
			if coroutine.status(k1) ~= "suspended" then
				continue
			end

			local var4 = k1
			local str1 = "signal disconnected; yielded thread cancelled"
			local num1 = 2
			warn(debug.traceback(var4, str1, num1))
			task.cancel(k1)
		end

		table.clear(arg1._yieldedThreads)
	end
end

local function runEventHandlerInFreeThread(...)
	acquireRunnerThreadAndCallEventHandler(...)
	while true do
		acquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl2.Fire = function(arg1, ...)
	local var2 = arg1._handlerListHead
	while var2 do
		if var2.Connected then
			if not var1 then
				var1 = coroutine.create(runEventHandlerInFreeThread)
			end

			task.spawn(var1, var2._fn, ...)
		end

		var2 = var2._next
	end
end

tbl2.FireDeferred = function(arg1, ...)
	local var1 = arg1._handlerListHead
	while var1 do
		local var2 = var1
		task.defer(function(...)
			if var2.Connected then
				var2._fn(...)
			end
		end, ...)

		var1 = var1._next
	end
end

tbl2.Wait = function(arg1)
	local var2 = rawget(arg1, "_yieldedThreads")
	if not var2 then
		var2 = {}
		rawset(arg1, "_yieldedThreads", var2)
	end

	local var3 = coroutine.running()
	var2[var3] = true
	arg1:Once(function(...)
		var2[var3] = nil
		if coroutine.status(var3) == "suspended" then
			task.spawn(var3, ...)
		end
	end)

	return coroutine.yield()
end

tbl2.Destroy = function(arg1)
	arg1:DisconnectAll()
	local var2 = rawget(arg1, "_proxyHandler")
	if var2 then
		var2:Disconnect()
	end
end

local tbl3 = { new = tbl2.new, Wrap = tbl2.Wrap, Is = tbl2.Is }
return table.freeze(tbl3)

--- ReplicatedStorage.Packages.DataService.Signal.init.test [ModuleScript]
-- y u r i

require(game:GetService("ServerScriptService").TestRunner.Test)
local function AwaitCondition(arg1, arg2)
	arg2 = arg2 or 10
	local var1 = os.clock()
	while true do
		if arg1() then
			return true
		end

		if arg2 < os.clock() - var1 then
			return false
		end

		task.wait()
	end
end

return function(arg1)
	local var1 = nil
	local var2 = require(script.Parent)
	arg1:BeforeEach(function()
		var1 = var2.new()
	end)

	arg1:AfterEach(function()
		var1:Destroy()
	end)

	arg1:Describe("Constructor", function()
		arg1:Test("should create a new signal and fire it", function()
			local var3 = var1
			arg1:Expect(var2.Is(var3)):ToBe(true)
			task.defer(function()
				var1:Fire(10, 20)
			end)

			local var4, var5 = var1:Wait()
			arg1:Expect(var4):ToBe(10)
			arg1:Expect(var5):ToBe(20)
		end)

		arg1:Test("should create a proxy signal and connect to it", function()
			local var1 = var2.Wrap(game:GetService("RunService").Heartbeat)
			local var3 = var1
			arg1:Expect(var2.Is(var3)):ToBe(true)
			local bool1 = false
			var1:Connect(function()
				bool1 = true
			end)

			local function fn2()
				return bool1
			end

			local num1 = 2
			arg1:Expect(AwaitCondition(fn2, num1)):ToBe(true)
			var1:Destroy()
		end)
	end)

	arg1:Describe("FireDeferred", function()
		arg1:Test("should be able to fire primitive argument", function()
			local var2 = nil
			var1:Connect(function(arg1)
				var2 = arg1
			end)

			var1:FireDeferred(10)
			local function fn2()
				return var2 == 10
			end

			local num1 = 1
			arg1:Expect(AwaitCondition(fn2, num1)):ToBe(true)
		end)

		arg1:Test("should be able to fire a reference based argument", function()
			local var2 = nil
			var1:Connect(function(arg1)
				var2 = arg1
			end)

			local tbl1 = { 10, 20 }
			var1:FireDeferred(tbl1)
			local function fn2()
				return tbl1 == var2
			end

			local num1 = 1
			arg1:Expect(AwaitCondition(fn2, num1)):ToBe(true)
		end)
	end)

	arg1:Describe("Fire", function()
		arg1:Test("should be able to fire primitive argument", function()
			local var2 = nil
			var1:Connect(function(arg1)
				var2 = arg1
			end)

			var1:Fire(10)
			arg1:Expect(var2):ToBe(10)
		end)

		arg1:Test("should be able to fire a reference based argument", function()
			local var2 = nil
			var1:Connect(function(arg1)
				var2 = arg1
			end)

			local tbl1 = { 10, 20 }
			var1:Fire(tbl1)
			arg1:Expect(var2):ToBe(tbl1)
		end)
	end)

	arg1:Describe("ConnectOnce", function()
		arg1:Test("should only capture first fire", function()
			local var2 = nil
			local var3 = var1:ConnectOnce(function(arg1)
				var2 = arg1
			end)

			arg1:Expect(var3.Connected):ToBe(true)
			var1:Fire(10)
			arg1:Expect(var3.Connected):ToBe(false)
			var1:Fire(20)
			arg1:Expect(var2):ToBe(10)
		end)
	end)

	arg1:Describe("Wait", function()
		arg1:Test("should be able to wait for a signal to fire", function()
			task.defer(function()
				var1:Fire(10, 20, 30)
			end)

			local var2, var3, var4 = var1:Wait()
			arg1:Expect(var2):ToBe(10)
			arg1:Expect(var3):ToBe(20)
			arg1:Expect(var4):ToBe(30)
		end)
	end)

	arg1:Describe("DisconnectAll", function()
		arg1:Test("should disconnect all connections", function()
			var1:Connect(function()
			end)

			var1:Connect(function()
			end)

			local var2 = nil
			arg1:Expect(#(var2 or var1):GetConnections()):ToBe(2)
			var1:DisconnectAll()
			var2 = nil
			arg1:Expect(#(var2 or var1):GetConnections()):ToBe(0)
		end)
	end)

	arg1:Describe("Disconnect", function()
		arg1:Test("should disconnect connection", function()
			local var2 = nil
			arg1:Expect(#(var2 or var1):GetConnections()):ToBe(1)
			var1:Connect(function()
			end):Disconnect()

			var2 = nil
			arg1:Expect(#(var2 or var1):GetConnections()):ToBe(0)
		end)

		arg1:Test("should still work if connections disconnected while firing", function()
			local num1 = 0
			var1:Connect(function()
				local var1 = num1 + 1
				num1 = var1
			end)

			local var2 = nil
			var1:Connect(function()
				var2:Disconnect()
				local var1 = num1 + 1
				num1 = var1
			end)

			var1:Connect(function()
				local var1 = num1 + 1
				num1 = var1
			end)

			var1:Fire()
			arg1:Expect(num1):ToBe(3)
		end)

		arg1:Test("should still work if connections disconnected while firing deferred", function()
			local num1 = 0
			var1:Connect(function()
				local var1 = num1 + 1
				num1 = var1
			end)

			local var2 = nil
			var1:Connect(function()
				var2:Disconnect()
				local var1 = num1 + 1
				num1 = var1
			end)

			var1:Connect(function()
				local var1 = num1 + 1
				num1 = var1
			end)

			var1:FireDeferred()
			local function fn2()
				return num1 == 3
			end

			arg1:Expect(AwaitCondition(fn2)):ToBe(true)
		end)
	end)
end

--- ReplicatedStorage.Packages.DataService.Signal.wally [ModuleScript]
-- y u r i

return { package = {
	authors = { "Stephen Leitnick" },
	description = "Signal class",
	exclude = { "node_modules", "package.json", "**/*.ts" },
	license = "MIT",
	name = "sleitnick/signal",
	realm = "shared",
	registry = "https://github.com/UpliftGames/wally-index",
	version = "2.0.3",
} }

--- ReplicatedStorage.Packages.DataService.ProfileStore [ModuleScript]
-- y u r i

local var1 = nil
local function AcquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
tbl2.__index = tbl2
tbl1.Disconnect = function(arg1)
	if arg1.is_connected == false then
		return
	end

	arg1.is_connected = false
	local var1 = arg1.signal
	local var2 = var1.listener_count - 1
	var1.listener_count = var2
	if var1.head == arg1 then
		var1.head = arg1.next
		return
	end

	var2 = var1.head
	while var2 ~= nil and var2.next ~= arg1 do
		var2 = var2.next
	end

	if var2 ~= nil then
		var2.next = arg1.next
	end
end

tbl2.New = function()
	local tbl1 = { head = nil, listener_count = 0 }
	setmetatable(tbl1, tbl2)
	return tbl1
end

tbl2.Connect = function(arg1, arg2)
	if type(arg2) ~= "function" then
		error((("[%*]: \"listener\" must be a function; Received %*"):format(script.Name, (typeof(arg2)))))
	end

	local tbl2 = { listener = arg2, signal = arg1, next = arg1.head, is_connected = true }
	setmetatable(tbl2, tbl1)
	arg1.head = tbl2
	local var1 = arg1.listener_count + 1
	arg1.listener_count = var1
	return tbl2
end

tbl2.GetListenerCount = function(arg1)
	return arg1.listener_count
end

local function RunEventHandlerInFreeThread(...)
	AcquireRunnerThreadAndCallEventHandler(...)
	while true do
		AcquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl2.Fire = function(arg1, ...)
	local var2 = arg1.head
	while var2 ~= nil do
		if var2.is_connected == true then
			if not var1 then
				var1 = coroutine.create(RunEventHandlerInFreeThread)
			end

			task.spawn(var1, var2.listener, ...)
		end

		var2 = var2.next
	end
end

tbl2.Wait = function(arg1)
	local var1 = nil
	local var2 = coroutine.running()
	arg1:Connect(function(...)
		var1:Disconnect()
		task.spawn(var2, ...)
	end)

	return coroutine.yield()
end

local var2 = nil
var2 = table.freeze({ New = tbl2.New })
local var3 = game:GetService("RunService")
local tbl3 = {}
local str1 = "NotReady"
local function DeepCopyTable(arg1)
	local tbl1 = {}
	for k1, v1 in pairs(arg1) do
		if type(v1) == "table" then
			tbl1[k1] = DeepCopyTable(v1)
		else
			tbl1[k1] = v1
		end
	end

	return tbl1
end

RunEventHandlerInFreeThread = {}
local var4 = var2.New()
local var5 = var2.New()
local function NewMockDataStoreKeyInfo(arg1)
	local var1 = arg1.MetaData
	local var2 = arg1.UserIds
	local var3 = tostring(arg1.VersionId or 0)
	var1 = var1 or {}
	local tbl1 = {
		CreatedTime = arg1.CreatedTime,
		UpdatedTime = arg1.UpdatedTime,
		Version = string.rep("0", 16) .. "." .. string.rep("0", 10 - string.len(var3)) .. var3 .. "." .. string.rep("0", 16) .. "." .. "01",
	}

	tbl1.GetMetadata = function()
		return (DeepCopyTable(var1))
	end

	var2 = var2 or {}
	tbl1.GetUserIds = function()
		return (DeepCopyTable(var2))
	end

	return tbl1
end

local function WaitInUpdateQueue(arg1)
	local bool2 = false
	if tbl3[arg1] == nil then
		tbl3[arg1] = {}
		bool2 = true
	end

	local var2 = tbl3[arg1]
	if bool2 == false then
		table.insert(var2, coroutine.running())
		coroutine.yield()
	end

	return function()
		local var3 = table.remove(var2, 1)
		if var3 ~= nil then
			coroutine.resume(var3)
			return
		end

		tbl3[arg1] = nil
	end
end

local function MockUpdateAsync(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg1[arg2]
	if var2 == nil then
		var2 = {}
		arg1[arg2] = var2
	end

	local var4 = var2[arg3]
	local var5 = math.floor(os.time() * 1000)
	local bool2 = false
	if var4 == nil then
		bool2 = true
		if arg5 ~= true then
			var4 = {
				Data = nil,
				CreatedTime = var5,
				UpdatedTime = var5,
				VersionId = 0,
				UserIds = {},
				MetaData = {},
			}

			var2[arg3] = var4
		end
	end

	local var6 = var4
	local var10, var11, var12 = arg4(var6 and var4.Data, bool2 == false and NewMockDataStoreKeyInfo(var4) or nil)
	if var10 == nil then
		return nil
	end

	if var4 ~= nil and arg5 ~= true then
		var4.Data = DeepCopyTable(var10)
		local var13 = var11
		var4.UserIds = DeepCopyTable(var13 or {})
		var13 = var12
		var4.MetaData = DeepCopyTable(var13 or {})
		local var14 = var4.VersionId + 1
		var4.VersionId = var14
		var4.UpdatedTime = var5
	end

	return DeepCopyTable(var10), var4 ~= nil and NewMockDataStoreKeyInfo(var4) or nil
end

local tbl4 = {}
local tbl5 = {}
local var6 = game.PlaceId
local var7 = game.JobId
local bool1 = false
var1 = {}
AcquireRunnerThreadAndCallEventHandler = {}
local num1 = 1
local var8 = os.clock()
local num2 = 0
local function UpdateAsync(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = nil
	local var2 = nil
	local var3 = WaitInUpdateQueue
	local str3 = "L_"
	local var6 = arg1.Name
	if arg4 == true then
		str3 = "U_"
	else
		if str1 ~= "Access" then
			str3 = "M_"
		end
	end

	var3 = var3(str3 .. var6 .. "\0" .. arg2)
	var3()
	local success, result = pcall(function()
		local function fn4(arg1)
			local bool2 = false
			local bool3 = false
			local tbl1 = { 0, {} }
			if arg1 == nil then
				bool2 = true
			else
				if type(arg1) ~= "table" then
					bool2 = true
					bool3 = true
				else
					if type(arg1.Data) == "table" and (type(arg1.MetaData) == "table" and type(arg1.GlobalUpdates) == "table") then
						arg1.WasOverwritten = false
						tbl1 = arg1.GlobalUpdates
						if arg3.ExistingProfileHandle ~= nil then
							arg3.ExistingProfileHandle(arg1)
						end
					else
						if arg1.Data == nil and (arg1.MetaData == nil and type(arg1.GlobalUpdates) == "table") then
							arg1.WasOverwritten = false
							bool2 = true
							tbl1 = arg1.GlobalUpdates or tbl1
						else
							bool2 = true
							bool3 = true
						end
					end
				end
			end

			if bool2 == true then
				arg1 = { GlobalUpdates = tbl1 }
				if arg3.MissingProfileHandle ~= nil then
					arg3.MissingProfileHandle(arg1)
				end
			end

			if arg3.EditProfile ~= nil then
				arg3.EditProfile(arg1)
			end

			if bool3 == true then
				arg1.WasOverwritten = true
			end

			return arg1, arg1.UserIds, arg1.RobloxMetaData
		end

		if arg4 == true then
			local var3, var4 = MockUpdateAsync(tbl4, arg1.Name, arg2, fn4, arg5)
			var1 = var3
			var2 = var4
			task.wait()
			return
		end

		if str1 ~= "Access" then
			local var5, var6 = MockUpdateAsync(tbl5, arg1.Name, arg2, fn4, arg5)
			var1 = var5
			var2 = var6
			task.wait()
			return
		end

		if arg5 == true then
			if arg6 ~= nil then
				local success, result = pcall(function()
					local var3, var4 = arg1.data_store:GetVersionAsync(arg2, arg6)
					var1 = var3
					var2 = var4
				end)

				if success == false and (type(result) == "string" and string.find(result, "not valid") ~= nil) then
					warn(([=[[%*]: Passed version argument is not valid; Traceback:
]=]):format(script.Name) .. debug.traceback())

				end
			else
				local var7, var8 = arg1.data_store:GetAsync(arg2)
				var1 = var7
				var2 = var8
			end

			local var9 = fn4(var1)
			var1 = var9
			return
		end

		local var10, var11 = arg1.data_store:UpdateAsync(arg2, fn4)
		var1 = var10
		var2 = var11
	end)

	if success == true then
		if type(var1) == "table" then
			if var1.WasOverwritten == true and arg5 ~= true then
				local var9 = arg1.Name
				warn((("[%*]: Invalid profile was overwritten (STORE:%*; KEY:%*)"):format(script.Name, var9, arg2)))
				var5:Fire(var9, arg2)
			end

			return var1, var2
		end
	end

	local var10 = arg1.Name
	local var11 = result or "Undefined error"
	warn((("[%*]: DataStore API error (STORE:%*; KEY:%*) - %*"):format(script.Name, var10, arg2, (tostring(var11)))))
	table.insert(RunEventHandlerInFreeThread, os.clock())
	var4:Fire(tostring(var11), var10, arg2)
	return nil
end

tbl1 = game:GetService("DataStoreService")
tbl2 = game:GetService("MessagingService")
local var9 = game:GetService("HttpService")
local var10 = var3:IsStudio()
local function ReconcileTable(arg1, arg2)
	for k1, v1 in pairs(arg2) do
		if type(k1) ~= "string" then
			continue
		end

		if arg1[k1] == nil then
			if type(v1) == "table" then
				arg1[k1] = DeepCopyTable(v1)
			else
				arg1[k1] = v1
				continue
			end
		else
			if type(arg1[k1]) ~= "table" then
				continue
			end

			if type(v1) ~= "table" then
				continue
			end

			ReconcileTable(arg1[k1], v1)
		end
	end
end

local function SaveProfileAsync(arg1, arg2, arg3, arg4)
	if type(arg1.Data) ~= "table" then
		error((("[%*]: Developer code likely set \"Profile.Data\" to a non-table value! (STORE:%*; KEY:%*)"):format(script.Name, arg1.ProfileStore.Name, arg1.Key)))
	end

	arg1.OnSave:Fire()
	if arg2 == true then
		arg1.OnLastSave:Fire(arg4 or "Manual")
	end

	if arg2 == true then
		if arg3 ~= true then
			if arg1.roblox_message_subscription ~= nil then
				arg1.roblox_message_subscription:Disconnect()
			end

			var1[arg1.session_token] = nil
			local var3 = table.find(AcquireRunnerThreadAndCallEventHandler, arg1)
			if var3 ~= nil then
				table.remove(AcquireRunnerThreadAndCallEventHandler, var3)
				if var3 < num1 then
					local var4 = num1 - 1
					num1 = var4
				end

				if AcquireRunnerThreadAndCallEventHandler[num1] == nil then
					num1 = 1
				end
			end

			arg1.OnSessionEnd:Fire()
		end
	end

	local var5 = num2 + 1
	num2 = var5
	var5 = true
	local num3 = 1
	while var5 ~= true and arg2 ~= true do
	end

	local var8 = num2 - 1
	num2 = var8
end

local tbl6 = {}
tbl6.__index = tbl6
tbl6.New = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = arg1.Data
	local var3 = arg1.GlobalUpdates and arg1.GlobalUpdates[2] or {}
	var1 = var1 or {}
	local var4 = arg1.MetaData and arg1.MetaData.ActiveSession or nil
	local tbl1 = {}
	for k1, v1 in ipairs(var3) do
		tbl1[v1[1]] = true
	end

	local tbl2 = { Data = var1, LastSavedData = DeepCopyTable(var1) }
	tbl2.FirstSessionTime = arg1.MetaData and arg1.MetaData.ProfileCreateTime or 0
	tbl2.SessionLoadCount = arg1.MetaData and arg1.MetaData.SessionLoadCount or 0
	local var6 = var4
	if var6 then
		var6 = { PlaceId = var4[1], JobId = var4[2] }
	end

	tbl2.Session = var6
	var6 = arg1.RobloxMetaData
	tbl2.RobloxMetaData = var6 or {}
	var6 = arg1.UserIds
	tbl2.UserIds = var6 or {}
	tbl2.KeyInfo = arg2
	tbl2.OnAfterSave = var2.New()
	tbl2.OnSave = var2.New()
	tbl2.OnLastSave = var2.New()
	tbl2.OnSessionEnd = var2.New()
	tbl2.ProfileStore = arg3
	tbl2.Key = arg4
	tbl2.load_timestamp = os.clock()
	tbl2.is_mock = arg5
	tbl2.session_token = arg6 or ""
	tbl2.load_index = arg1.MetaData and arg1.MetaData.SessionLoadCount or 0
	tbl2.locked_global_updates = {}
	tbl2.received_global_updates = tbl1
	tbl2.message_handlers = {}
	tbl2.global_updates = var3
	setmetatable(tbl2, tbl6)
	return tbl2
end

tbl6.IsActive = function(arg1)
	return var1[arg1.session_token] == arg1
end

tbl6.Reconcile = function(arg1)
	ReconcileTable(arg1.Data, arg1.ProfileStore.template)
end

tbl6.EndSession = function(arg1)
	if arg1:IsActive() == true then
		task.spawn(SaveProfileAsync, arg1, true, nil, "Manual")
	end
end

tbl6.AddUserId = function(arg1, arg2)
	if type(arg2) ~= "number" or arg2 % 1 ~= 0 then
		warn(([=[[%*]: Invalid UserId argument for :AddUserId() (%*); Traceback:
]=]):format(script.Name, (tostring(arg2))) .. debug.traceback())

		return
	end

	if arg2 < 0 and (arg1.is_mock ~= true and str1 == "Access") then
		return
	end

	if table.find(arg1.UserIds, arg2) == nil then
		table.insert(arg1.UserIds, arg2)
	end
end

tbl6.RemoveUserId = function(arg1, arg2)
	if type(arg2) ~= "number" or arg2 % 1 ~= 0 then
		warn(([=[[%*]: Invalid UserId argument for :RemoveUserId() (%*); Traceback:
]=]):format(script.Name, (tostring(arg2))) .. debug.traceback())

		return
	end

	local var2 = table.find(arg1.UserIds, arg2)
	if var2 ~= nil then
		table.remove(arg1.UserIds, var2)
	end
end

tbl6.SetAsync = function(arg1)
	if arg1.view_mode ~= true then
		error((("[%*]: :SetAsync() can only be used in view mode"):format(script.Name)))
	end

	SaveProfileAsync(arg1, nil, true)
end

tbl6.MessageHandler = function(arg1, arg2)
	if type(arg2) ~= "function" then
		error((("[%*]: fn argument is not a function"):format(script.Name)))
	end

	if arg1.view_mode ~= true and arg1:IsActive() ~= true then
		return
	end

	table.insert(arg1.message_handlers, arg2)
	local var1 = arg1.locked_global_updates
	for k1, v1 in ipairs(arg1.global_updates) do
		local var2 = v1[1]
		if var1[var2] == true then
			continue
		end

		task.spawn(arg2, DeepCopyTable(v1[#v1]), function()
			var1[var2] = true
		end)

	end
end

tbl6.Save = function(arg1)
	if arg1.view_mode == true then
		error((("[%*]: Can't save profile in view mode; Should you be calling :SetAsync() instead?"):format(script.Name)))
	end

	if arg1:IsActive() == false then
		warn(("[%*]: Attempted saving an inactive profile (STORE:%*; KEY:%*);"):format(script.Name, arg1.ProfileStore.Name, arg1.Key) .. [[ Traceback:
]] .. debug.traceback())

		return
	end

	var1[arg1.session_token] = nil
	local var3 = table.find(AcquireRunnerThreadAndCallEventHandler, arg1)
	if var3 ~= nil then
		table.remove(AcquireRunnerThreadAndCallEventHandler, var3)
		if var3 < num1 then
			local var4 = num1 - 1
			num1 = var4
		end

		if AcquireRunnerThreadAndCallEventHandler[num1] == nil then
			num1 = 1
		end
	end

	var1[arg1.session_token] = arg1
	table.insert(AcquireRunnerThreadAndCallEventHandler, num1, arg1)
	if 1 < (#AcquireRunnerThreadAndCallEventHandler) then
		var3 = num1 + 1
		num1 = var3
	else
		if #AcquireRunnerThreadAndCallEventHandler == 1 then
			var8 = os.clock()
		end
	end

	task.spawn(SaveProfileAsync, arg1)
end

local tbl7 = {
	IsClosing = false,
	IsCriticalState = false,
	OnError = var4,
	OnOverwrite = var5,
	OnCriticalToggle = var2.New(),
	DataStoreState = "NotReady",
}

tbl7.__index = tbl7
local num3 = 300
local num4 = 10
local num5 = 5
local num6 = 40
local num7 = 630
local num8 = 120
local num9 = 5
local num10 = 120
local num11 = 120
local num12 = 1000
tbl7.SetConstant = function(arg1, arg2)
	if type(arg2) ~= "number" then
		error((("[%*]: Invalid value type"):format(script.Name)))
	end

	if arg1 == "AUTO_SAVE_PERIOD" then
		num3 = arg2
		return
	end

	if arg1 == "LOAD_REPEAT_PERIOD" then
		num4 = arg2
		return
	end

	if arg1 == "FIRST_LOAD_REPEAT" then
		num5 = arg2
		return
	end

	if arg1 == "SESSION_STEAL" then
		num6 = arg2
		return
	end

	if arg1 == "ASSUME_DEAD" then
		num7 = arg2
		return
	end

	if arg1 == "START_SESSION_TIMEOUT" then
		num8 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_ERROR_COUNT" then
		num9 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_ERROR_EXPIRE" then
		num10 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_EXPIRE" then
		num11 = arg2
		return
	end

	if arg1 == "MAX_MESSAGE_QUEUE" then
		num12 = arg2
		return
	end

	error((("[%*]: Invalid constant name was provided"):format(script.Name)))
end

local num13 = 0
tbl7.Test = function()
	return {
		ActiveSessionCheck = var1,
		AutoSaveList = AcquireRunnerThreadAndCallEventHandler,
		ActiveProfileLoadJobs = num13,
		ActiveProfileSaveJobs = num2,
		MockStore = tbl5,
		UserMockStore = tbl4,
		UpdateQueue = tbl3,
	}
end

tbl7.New = function(arg1, arg2)
	local var1 = arg2
	arg2 = var1 or {}
	if type(arg1) ~= "string" then
		error((("[%*]: Invalid or missing \"store_name\""):format(script.Name)))
	else
		if string.len(arg1) == 0 then
			error((("[%*]: store_name cannot be an empty string"):format(script.Name)))
		else
			if 50 < string.len(arg1) then
				error((("[%*]: store_name is too long"):format(script.Name)))
			end
		end
	end

	if type(arg2) ~= "table" then
		error((("[%*]: Invalid template argument"):format(script.Name)))
	end

	var1 = nil
	var1 = {
		Mock = {
			Name = arg1,
			StartSessionAsync = function(_, arg2)
				bool1 = true
				local var2 = arg2
				return var1:StartSessionAsync(var2)
			end,
			MessageAsync = function(_, arg2, arg3)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				return var1:MessageAsync(var2, var3)
			end,
			GetAsync = function(_, arg2, arg3)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				return var1:GetAsync(var2, var3)
			end,
			VersionQuery = function(_, arg2, arg3, arg4, arg5)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				local var4 = arg4
				local var5 = arg5
				return var1:VersionQuery(var2, var3, var4, var5)
			end,
			RemoveAsync = function(_, arg2)
				bool1 = true
				local var2 = arg2
				return var1:RemoveAsync(var2)
			end,
		},
		Name = arg1,
		template = arg2,
		data_store = nil,
		load_jobs = {},
		mock_load_jobs = {},
		is_ready = true,
	}

	setmetatable(var1, tbl7)
	local var2 = Instance.new("DataStoreOptions")
	var2:SetExperimentalFeatures({ v2 = true })
	if str1 == "NotReady" then
		var1.is_ready = false
		task.spawn(function()
			repeat
				task.wait()
			until str1 ~= "NotReady"

			if str1 == "Access" then
				var1.data_store = tbl1:GetDataStore(arg1, nil, var2)
			end

			var1.is_ready = true
		end)

	else
		if str1 == "Access" then
			var1.data_store = tbl1:GetDataStore(arg1, nil, var2)
		end
	end

	return var1
end

local num14 = 0
local function RobloxMessageSubscription(arg1, arg2)
	local num1 = 0
	local var1 = tbl2:SubscribeAsync("PS_" .. arg2, function(arg1)
		if type(arg1.Data) == "table" and (arg1.Data.LoadCount == arg1.SessionLoadCount and 6 < os.clock() - num1) then
			num1 = os.clock()
			if arg1:IsActive() == true then
				if arg1.Data.EndSession == true then
					SaveProfileAsync(arg1, true, false, "External")
					return
				end

				arg1:Save()
			end
		end
	end)

	if arg1:IsActive() == true then
		arg1.roblox_message_subscription = var1
	else
		var1:Disconnect()
	end
end

tbl7.StartSessionAsync = function(arg1, arg2, arg3)
	local var38
	local var40
	local var44
	local var2 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if arg3 ~= nil and type(arg3) ~= "table" then
		error((("[%*]: Invalid params"):format(script.Name)))
	end

	local var3 = arg3
	arg3 = var3 or {}
	if tbl7.IsClosing == true then
		return nil
	end

	while arg1.is_ready == false do
		task.wait()
	end

	var3 = "L_"
	local var4 = arg1.Name
	if var2 == true then
		var3 = "U_"
	else
		if str1 ~= "Access" then
			var3 = "M_"
		end
	end

	var3 = var3 .. var4 .. "\0" .. arg2
	if var1[var3] ~= nil then
		error((("[%*]: Profile (STORE:%*; KEY:%*) is already loaded in this session"):format(script.Name, arg1.Name, arg2)))
	end

	var4 = num13 + 1
	num13 = var4
	var4 = false
	local var5 = arg3.Steal == true
	local num2 = 0
	local bool2 = true
	local bool3 = false
	local var10 = os.clock()
	local num3 = 1
	while true do
		if tbl7.IsClosing ~= false then
			break
		end

		local var11
		if var4 == false then
			if arg3.Cancel ~= nil then
				var4 = arg3.Cancel() == true
			end

			var11 = var4
		else
			var11 = true
		end

		if var11 ~= false then
			break
		end

		var11 = num14 + 1
		num14 = var11
		local var12 = var2 == true and arg1.mock_load_jobs or arg1.load_jobs
		local var14 = var12[arg2]
		var11 = num14
		local var15 = nil
		local var16 = nil
		local var17 = var9:GenerateGUID(false)
		if var14 ~= nil then
			var14[1] = var11
			while var14[2] == nil do
				task.wait()
			end

			if var14[1] == var11 then
				local var18, var19 = table.unpack(var14[2])
				var15 = var18
				var12[arg2] = nil
				var16 = var19
			else
				local var20 = num13 - 1
				num13 = var20
				return nil
			end
		else
			var14 = { var11, nil }
			var12[arg2] = var14
			local var21 = arg1
			local var22 = arg2
			local tbl1 = {
				ExistingProfileHandle = function(arg1)
					if tbl7.IsClosing ~= true then
						local var1
						if var4 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var4 = var2
							end

							var1 = var4
						else
							var1 = true
						end

						if var1 == true then
							return
						end
					end

					var1 = arg1.MetaData.ActiveSession
					local var3 = arg1.MetaData.ForceLoadSession
					if var1 == nil then
						arg1.MetaData.ActiveSession = { var6, var7, var17 }
						arg1.MetaData.ForceLoadSession = nil
						return
					end

					if type(var1) == "table" then
						local bool1 = false
						if var1[1] == var6 then
							bool1 = var1[2] == var7
						end

						if bool1 == false then
							bool1 = arg1.MetaData.LastUpdate
							if bool1 ~= nil and num7 < os.time() - bool1 then
								arg1.MetaData.ActiveSession = { var6, var7, var17 }
								arg1.MetaData.ForceLoadSession = nil
								return
							end

							if bool3 ~= true then
								if var5 == true then
									local var8
									if var3 ~= nil then
										local bool4 = false
										if var3[1] == var6 then
											bool4 = var3[2] == var7
										end

										var8 = not bool4
									else
										var8 = true
									end

									if not (var8 == false or var5 == true) then
										return
									end

									if var5 ~= true then
										return
									end

									arg1.MetaData.ActiveSession = { var6, var7, var17 }
									arg1.MetaData.ForceLoadSession = nil
									return
								end
							end

							if bool2 ~= true then
								return
							end

							arg1.MetaData.ForceLoadSession = { var6, var7 }
							return
						end

						arg1.MetaData.ForceLoadSession = nil
					end
				end,
				MissingProfileHandle = function(arg1)
					local bool1 = true
					if tbl7.IsClosing ~= true then
						local var1
						if var4 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var4 = var2
							end

							var1 = var4
						else
							var1 = true
						end

						bool1 = var1 == true
					end

					arg1.Data = DeepCopyTable(arg1.template)
					var1 = { ProfileCreateTime = os.time(), SessionLoadCount = 0, ForceLoadSession = nil }
					local var3
					if bool1 == false then
						var3 = { var6, var7, var17 }
					else
						var3 = nil
					end

					var1.ActiveSession = var3
					var1.MetaTags = {}
					arg1.MetaData = var1
				end,
				EditProfile = function(arg1)
					if tbl7.IsClosing ~= true then
						local var1
						if var4 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var4 = var2
							end

							var1 = var4
						else
							var1 = true
						end

						if var1 == true then
							return
						end
					end

					var1 = arg1.MetaData.ActiveSession
					if var1 ~= nil then
						local bool1 = false
						if var1[1] == var6 then
							bool1 = var1[2] == var7
						end

						if bool1 == true then
							arg1.MetaData.SessionLoadCount = arg1.MetaData.SessionLoadCount + 1
							arg1.MetaData.LastUpdate = os.time()
						end
					end
				end,
			}

			local var23 = var2
			var14[2] = table.pack(UpdateAsync(var21, var22, tbl1, var23))
			if var14[1] == var11 then
				local var24, var25 = table.unpack(var14[2])
				var15 = var24
				var12[arg2] = nil
				var16 = var25
			else
				local var26 = num13 - 1
				num13 = var26
				return nil
			end
		end

		local var27
		if var15 ~= nil then
			if var16 ~= nil then
				local var28 = var15.MetaData.ActiveSession
				if type(var28) == "table" then
					local bool4 = false
					if var28[1] == var6 then
						bool4 = var28[2] == var7
					end

					if bool4 == true then
						bool4 = tbl6.New(var15, var16, arg1, arg2, var2, var3)
						var1[bool4.session_token] = bool4
						table.insert(AcquireRunnerThreadAndCallEventHandler, num1, bool4)
						if 1 < (#AcquireRunnerThreadAndCallEventHandler) then
							local var29 = num1 + 1
							num1 = var29
						else
							if #AcquireRunnerThreadAndCallEventHandler == 1 then
								var8 = os.clock()
							end
						end

						if var2 ~= true and str1 == "Access" then
							task.spawn(RobloxMessageSubscription, bool4, var17)
						end

						if tbl7.IsClosing ~= true then
							local var30
							if var4 == false then
								if arg3.Cancel ~= nil then
									var4 = arg3.Cancel() == true
								end

								var30 = var4
							else
								var30 = true
							end

							if var30 == true then
								SaveProfileAsync(bool4, true)
								bool4 = nil
							end
						end

						var30 = num13 - 1
						num13 = var30
						return bool4
					end

					if tbl7.IsClosing ~= true then
						if var4 == false then
							if arg3.Cancel ~= nil then
								var4 = arg3.Cancel() == true
							end

							bool4 = var4
						else
							bool4 = true
						end

						if bool4 == true then
							bool4 = num13 - 1
							num13 = bool4
							return nil
						end
					end

					bool4 = var15.MetaData.ForceLoadSession
					if bool4 ~= nil then
						local bool5 = false
						if bool4[1] == var6 then
							bool5 = bool4[2] == var7
						end

						var30 = not bool5
					else
						var30 = true
					end

					local var31
					if var30 == false then
						if bool2 == false then
							num2 = num2 + 1
							if math.ceil(num6 / num4) <= num2 then
							end
						end

						if type(var28[3]) == "string" then
							task.spawn(tbl2.PublishAsync, tbl2, "PS_" .. var28[3], { LoadCount = var15.MetaData.SessionLoadCount or 0, EndSession = true })
						end

						local var32 = os.clock()
						local var33 = var32 + (if bool2 == true then num5 else num4)
						while true do
							task.wait()
							if var33 > os.clock() and tbl7.IsClosing ~= true then
								continue
							end
						end
					else
						local var34 = num13 - 1
						num13 = var34
						return nil
					end
				else
					local var35 = num13 - 1
					num13 = var35
					return nil
				end
			else
				local bool6 = false
				if arg3.Cancel == nil then
					bool6 = num8 <= os.clock() - var10
				end

				if bool6 ~= true then
					if tbl7.IsClosing ~= true then
						local var36
						if var4 == false then
							if arg3.Cancel ~= nil then
								var4 = arg3.Cancel() == true
							end

							var36 = var4
						else
							var36 = true
						end

						if var36 == true then
							var36 = num13 - 1
							num13 = var36
							return nil
						end
					end
				end

				task.wait(num3)
			end

			local var37 = math.min(20, num3 * 2)
		else
			local bool7 = false
			if var38.Cancel == nil then
				bool7 = num8 <= os.clock() - var40
			end

			if bool7 ~= true then
				if tbl7.IsClosing ~= true then
					local var45
					if var44 == false then
						if var38.Cancel ~= nil then
							var45 = var38.Cancel() == true
						end

						var36 = var45
					else
						var36 = true
					end

					if var36 == true then
						var36 = num13 - 1
						num13 = var36
						return nil
					end
				end
			end

			task.wait(var37)
		end

		local var46 = math.min(20, var37 * 2)
	end

	var11 = num13 - 1
	num13 = var11
	return nil
end

tbl7.MessageAsync = function(arg1, arg2, arg3)
	local var2 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if type(arg3) ~= "table" then
		error((("[%*]: message must be a table"):format(script.Name)))
	end

	if tbl7.IsClosing == true then
		return false
	end

	while arg1.is_ready == false do
		task.wait()
	end

	local num1 = 1
	while tbl7.IsClosing == false do
		local var4 = UpdateAsync(arg1, arg2, {
			ExistingProfileHandle = nil,
			MissingProfileHandle = nil,
			EditProfile = function(arg1)
				local var1 = arg1.GlobalUpdates
				local var2 = var1[1] + 1
				var1[1] = var2
				local var3 = var1[2]
				table.insert(var3, { var1[1], arg3 })
				while num12 < (#var3) do
					table.remove(var3, 1)
				end
			end,
		}, var2)

		if var4 ~= nil then
			local str4 = "L_"
			local var5 = arg1.Name
			if var2 == true then
				str4 = "U_"
			else
				if str1 ~= "Access" then
					str4 = "M_"
				end
			end

			var5 = var1[str4 .. var5 .. "\0" .. arg2]
			if var5 ~= nil then
				var5:Save()
			else
				local var6 = var4.MetaData
				var6 = var6 or {}
				local var7 = var6.ActiveSession
				local var8 = var6.SessionLoadCount or 0
				if type(var7) == "table" and type(var7[3]) == "string" then
					task.spawn(tbl2.PublishAsync, tbl2, "PS_" .. var7[3], { LoadCount = var8 })
				end
			end

			return true
		end

		task.wait(num1)
		local var9 = math.min(20, num1 * 2)
	end

	return false
end

tbl7.GetAsync = function(arg1, arg2, arg3)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if tbl7.IsClosing == true then
		return nil
	end

	while arg1.is_ready == false do
		task.wait()
	end

	if arg3 ~= nil and (var1 or str1 ~= "Access") then
		return nil
	end

	local num1 = 1
	while tbl7.IsClosing == false do
		local var4, var5 = UpdateAsync(arg1, arg2, {
			ExistingProfileHandle = nil,
			MissingProfileHandle = function(arg1)
				arg1.Data = DeepCopyTable(arg1.template)
				local tbl1 = {
					ProfileCreateTime = os.time(),
					SessionLoadCount = 0,
					ActiveSession = nil,
					ForceLoadSession = nil,
				}

				tbl1.MetaTags = {}
				arg1.MetaData = tbl1
			end,
			EditProfile = nil,
		}, var1, true, arg3)

		if var4 ~= nil then
			if var5 == nil then
				return nil
			end

			local var6 = tbl6.New(var4, var5, arg1, arg2, var1)
			var6.view_mode = true
			return var6
		end

		task.wait(num1)
		local var7 = math.min(20, num1 * 2)
	end

	return nil
end

tbl7.RemoveAsync = function(arg1, arg2)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" or string.len(arg2) == 0 then
		error((("[%*]: Invalid profile_key"):format(script.Name)))
	end

	if tbl7.IsClosing == true then
		return false
	end

	while arg1.is_ready == false do
		task.wait()
	end

	local bool2 = false
	local var2 = WaitInUpdateQueue
	local str3 = "L_"
	local var3 = arg1.Name
	if var1 == true then
		str3 = "U_"
	else
		if str1 ~= "Access" then
			str3 = "M_"
		end
	end

	var2 = var2(str3 .. var3 .. "\0" .. arg2)
	if var1 == true then
		str3 = tbl4[arg1.Name]
		if str3 ~= nil then
			str3[arg2] = nil
			if next(str3) == nil then
				tbl4[arg1.Name] = nil
			end
		end

		task.wait()
		bool2 = true
	else
		if str1 ~= "Access" then
			str3 = tbl5[arg1.Name]
			if str3 ~= nil then
				str3[arg2] = nil
				if next(str3) == nil then
					tbl5[arg1.Name] = nil
				end
			end

			task.wait()
			bool2 = true
		else
			bool2 = pcall(function()
				arg1.data_store:RemoveAsync(arg2)
			end)

		end
	end

	var2()
	return bool2
end

local tbl8 = {}
tbl8.__index = tbl8
tbl8.New = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local tbl1 = {
		profile_store = arg1,
		profile_key = arg2,
		sort_direction = arg3,
		min_date = arg4,
		max_date = arg5,
		query_pages = nil,
		query_index = 0,
		query_failure = false,
		is_query_yielded = false,
		query_queue = {},
		is_mock = arg6,
	}

	setmetatable(tbl1, tbl8)
	return tbl1
end

function MoveVersionQueryQueue(arg1)
	repeat
		if 0 >= (#arg1.query_queue) then
			break
		end

		task.spawn((table.remove(arg1.query_queue, 1)))
	until arg1.is_query_yielded == true
end

local bool2 = false
local bool3 = false
tbl8.NextAsync = function(arg1)
	local var1 = bool2 == true
	bool2 = false
	local var2 = arg1.profile_store
	while var2.is_ready == false do
		task.wait()
	end

	if tbl7.IsClosing == true then
		return nil
	end

	if arg1.is_mock ~= true then
		if str1 ~= "Access" then
			if var10 == true and bool3 == false then
				bool3 = true
				warn((("[%*]: :VersionQuery() is not supported in mock mode!"):format(script.Name)))
			end

			return nil
		end
	end

	local bool1 = false
	var2 = nil
	local function query_job()
		if arg1.query_failure == true then
			bool1 = true
			return
		end

		if arg1.query_pages == nil then
			arg1.is_query_yielded = true
			task.spawn(function()
				bool2 = true
				var2 = arg1:NextAsync()
				bool1 = true
			end)

			local success, result = pcall(function()
				arg1.query_pages = arg1.profile_store.data_store:ListVersionsAsync(arg1.profile_key, arg1.sort_direction, arg1.min_date, arg1.max_date)
				arg1.query_index = 0
			end)

			if success == false or arg1.query_pages == nil then
				warn((("[%*]: Version query fail - %*"):format(script.Name, (tostring(result)))))
				arg1.query_failure = true
			end

			arg1.is_query_yielded = false
			MoveVersionQueryQueue(arg1)
			return
		end

		local var3 = arg1.query_pages:GetCurrentPage()[arg1.query_index + 1]
		if arg1.query_pages.IsFinished == true and var3 == nil then
			bool1 = true
			return
		end

		if var3 == nil then
			arg1.is_query_yielded = true
			task.spawn(function()
				bool2 = true
				var2 = arg1:NextAsync()
				bool1 = true
			end)

			local success, result = pcall(function()
				arg1.query_pages:AdvanceToNextPageAsync()
				arg1.query_index = 0
			end)

			if success == false or #arg1.query_pages:GetCurrentPage() == 0 then
				arg1.query_failure = true
			end

			arg1.is_query_yielded = false
			MoveVersionQueryQueue(arg1)
			return
		end

		local var4 = arg1
		local var5 = var4.query_index + 1
		var4.query_index = var5
		var2 = arg1.profile_store:GetAsync(arg1.profile_key, var3.Version)
		bool1 = true
	end

	if arg1.is_query_yielded == false then
		query_job()
	elseif var1 == true then
		table.insert(arg1.query_queue, 1, query_job)
	else
		table.insert(arg1.query_queue, query_job)
	end

	while bool1 == false do
		task.wait()
	end

	return var2
end

tbl7.VersionQuery = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" or string.len(arg2) == 0 then
		error((("[%*]: Invalid profile_key"):format(script.Name)))
	end

	if arg3 ~= nil and (typeof(arg3) ~= "EnumItem" or arg3.EnumType ~= Enum.SortDirection) then
		error((("[%*]: Invalid sort_direction (%*)"):format(script.Name, (tostring(arg3)))))
	end

	if arg4 ~= nil and (typeof(arg4) ~= "DateTime" and typeof(arg4) ~= "number") then
		error((("[%*]: Invalid min_date (%*)"):format(script.Name, (tostring(arg4)))))
	end

	if arg5 ~= nil and (typeof(arg5) ~= "DateTime" and typeof(arg5) ~= "number") then
		error((("[%*]: Invalid max_date (%*)"):format(script.Name, (tostring(arg5)))))
	end

	local var2 = arg1
	local var3 = arg2
	local var4 = arg3
	local var5 = typeof(arg4) == "DateTime" and arg4.UnixTimestampMillis or arg4
	local var6 = typeof(arg5) == "DateTime" and arg5.UnixTimestampMillis or arg5
	local var7 = var1
	return tbl8.New(var2, var3, var4, var5, var6, var7)
end

local num15 = 0
if var10 == true then
	task.spawn(function()
		local success, result = pcall(function()
			tbl1:GetDataStore("____PS"):SetAsync("____PS", os.time())
		end)

		local str2 = "NoAccess"
		local bool1 = false
		if success == false then
			bool1 = string.find(result, "ConnectFail", 1, true) ~= nil
		end

		if bool1 == true then
			warn((("[%*]: No internet access - check your network connection"):format(script.Name)))
		end

		if success == false then
			if string.find(result, "403", 1, true) ~= nil or (string.find(result, "must publish", 1, true) ~= nil or bool1 == true) then
				print((("[%*]: Roblox API services unavailable - data will not be saved"):format(script.Name)))
				str2 = if bool1 == true then "NoInternet" else "NoAccess"
			else
				str2 = "Access"
			end
		else
			str2 = "Access"
		end

		str1 = str2
		tbl7.DataStoreState = str2
	end)

else
	tbl7.DataStoreState = "Access"
	str1 = "Access"
end

var3.Heartbeat:Connect(function()
	local var4 = #AcquireRunnerThreadAndCallEventHandler
	local var5 = os.clock()
	local var6 = num3 / var4
	if 0 < var4 and var6 < var5 - var8 then
		local var7 = var8 + var6
		var8 = var7
		var7 = AcquireRunnerThreadAndCallEventHandler[num1]
		if var5 - var7.load_timestamp < num3 / 2 then
			var7 = nil
			for i1 = 1, var4 - 1 do
				local var9 = num1 + 1
				num1 = var9
				if var4 < num1 then
					num1 = 1
				end

				var7 = AcquireRunnerThreadAndCallEventHandler[num1]
				if num3 / 2 <= var5 - var7.load_timestamp then
					break
				end

				var7 = nil
			end
		end

		local var10 = num1 + 1
		num1 = var10
		if var4 < num1 then
			num1 = 1
		end

		if var7 ~= nil then
			task.spawn(SaveProfileAsync, var7)
		end
	end

	if tbl7.IsCriticalState == false then
		if num9 <= (#RunEventHandlerInFreeThread) then
			tbl7.IsCriticalState = true
			tbl7.OnCriticalToggle:Fire(true)
			num15 = os.clock()
			warn((("[%*]: Entered critical state"):format(script.Name)))
		end
	else
		if num9 <= (#RunEventHandlerInFreeThread) then
			num15 = os.clock()
		else
			if num11 < os.clock() - num15 then
				tbl7.IsCriticalState = false
				tbl7.OnCriticalToggle:Fire(false)
				warn((("[%*]: Critical state ended"):format(script.Name)))
			end
		end
	end

	while true do
		var6 = RunEventHandlerInFreeThread[1]
		if var6 == nil then
			return
		end

		if num10 >= os.clock() - var6 then
			break
		end

		table.remove(RunEventHandlerInFreeThread, 1)
		continue
	end
end)

task.spawn(function()
	while str1 == "NotReady" do
		task.wait()
	end

	if str1 ~= "Access" then
		game:BindToClose(function()
			tbl7.IsClosing = true
			task.wait()
		end)

		return
	end

	game:BindToClose(function()
		tbl7.IsClosing = true
		local num1 = 0
		local tbl1 = {}
		for k1, v1 in ipairs(AcquireRunnerThreadAndCallEventHandler) do
			tbl1[k1] = v1
		end

		for k2, v2 in ipairs(tbl1) do
			if v2:IsActive() ~= true then
				continue
			end

			num1 = num1 + 1
			task.spawn(function()
				SaveProfileAsync(v2, true, nil, "Shutdown")
				local var1 = num1 - 1
				num1 = var1
			end)

		end

		while 0 < num1 or 0 < num13 or 0 < num2 do
			task.wait()
		end
	end)
end)

return tbl7

--- ReplicatedStorage.Packages.DataService.Networker [ModuleScript]
-- y u r i

local var1 = require(script.NetworkerServer)
local var2 = require(script.NetworkerClient)
return { server = var1, client = var2 }

--- ReplicatedStorage.Packages.DataService.Networker.NetworkerClient [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = require(script.Parent.Parent.Signal)
local var3 = require(script.Parent.NetworkerUtils)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	assert(var1:IsClient(), "NetworkerClient can only be created on the client")
	local tbl2 = { networkTag = arg1, changedSignals = {} }
	setmetatable(tbl2, tbl1)
	if not var1:IsRunning() then
		return tbl2
	end

	if typeof(arg1) == "Instance" then
		local var4 = arg1:GetAttribute(var3.INSTANCE_ATTRIBUTE)
		if not var4 then
			arg1:GetAttributeChangedSignal(var3.INSTANCE_ATTRIBUTE):Wait()
			var4 = arg1:GetAttribute(var3.INSTANCE_ATTRIBUTE)
		end

		assert(var4, "NetworkerClient instance does not have a networkTag attribute")
		tbl2.networkTag = var4
	end

	local var5 = script.Parent:WaitForChild("_remotes"):WaitForChild(tbl2.networkTag)
	tbl2.remotes = var5
	var5.Destroying:Once(function()
		tbl2:destroy()
	end)

	var5.RemoteEvent.OnClientEvent:Connect(function(arg1, arg2, ...)
		if arg1 == var3.SET_TAG then
			local var1 = ...
			arg2[arg2] = var1
			if tbl2.changedSignals[arg2] then
				tbl2.changedSignals[arg2]:Fire(arg2[arg2])
			end

			return
		end

		assert(arg2[arg1], "Method " .. arg1 .. " does not exist on networkTag " .. var5.Name)
		arg2[arg1](arg2, arg2, ...)
	end)

	return tbl2
end

tbl1.getServerChangedSignal = function(arg1, arg2)
	if not arg1.changedSignals[arg2] then
		arg1.changedSignals[arg2] = var2.new()
	end

	return arg1.changedSignals[arg2]
end

tbl1.fire = function(arg1, arg2, ...)
	if var1:IsRunning() then
		arg1.remotes.RemoteEvent:FireServer(arg2, ...)
	end
end

tbl1.fetch = function(arg1, arg2, ...)
	if not var1:IsRunning() then
		return nil
	end

	local var2 = arg2
	return arg1.remotes.RemoteFunction:InvokeServer(var2, ...)
end

tbl1.destroy = function(arg1)
	if arg1.remotes then
		arg1.remotes:Destroy()
	end

	for k1, v1 in arg1.changedSignals, nil do
		v1:Destroy()
	end

	if arg1.instanceConn then
		arg1.instanceConn:Disconnect()
	end
end

return tbl1

--- ReplicatedStorage.Packages.DataService.Networker.NetworkerServer [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var3 = game:GetService("Players")
local var4 = game:GetService("HttpService")
local var5 = require(script.Parent.NetworkerUtils)
local var6 = nil
if var1:IsRunning() and var1:IsServer() then
	var6 = Instance.new("Folder")
	var6.Name = "_remotes"
	var6.Parent = script.Parent
end

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	assert(var1:IsServer(), "NetworkerServer can only be created on the server")
	local var2 = setmetatable({ networkTag = arg1, _accessLookup = {} }, tbl1)
	local var3 = Instance.new("Folder")
	local var7 = Instance.new("RemoteEvent")
	var7.Parent = var3
	local var8 = Instance.new("RemoteFunction")
	var8.Parent = var3
	var2.remotes = var3
	var2.event = var7
	var2.func = var8
	if typeof(arg1) == "Instance" then
		assert(arg1:GetAttribute(var5.INSTANCE_ATTRIBUTE) == nil, "NetworkerServer instance already has a networkTag attribute")
		var2.instance = arg1
		local var9 = var4:GenerateGUID(false):sub(1, 13)
		var2.networkTag = var9
		arg1:SetAttribute(var5.INSTANCE_ATTRIBUTE, var9)
		var2.instanceConn = arg1.Destroying:Once(function()
			var2:destroy()
		end)

	end

	var3.Name = var2.networkTag
	assert(var6:FindFirstChild(var3.Name) == nil, "NetworkerServer with the same name already exists")
	var3.Parent = var6
	if arg3 then
		assert(arg2, "Module must be provided if clientAccess is specified")
		var2:addClientAccess(arg2, arg3)
	end

	local function callback(arg1, arg2, ...)
		local var3 = var2._accessLookup[arg2]
		if not var3 then
			warn(arg2 .. " does not exist or is restricted for ", arg1)
			return
		end

		local var4 = var3.module
		local var5 = arg1
		return var3.method(var4, var5, ...)
	end

	var7.OnServerEvent:Connect(callback)
	var8.OnServerInvoke = callback
	return var2
end

tbl1.addClientAccess = function(arg1, arg2, arg3)
	local function addAccess(arg1)
		for k1, v1 in arg3, nil do
			for k2, v2 in arg1, nil do
				if v2 ~= v1 then
					continue
				end

				assert(arg1._accessLookup[k2] == nil, "Client access method already exists: " .. k2)
				assert(type(v2) == "function", "Client access method must be a function: " .. k2)
				arg1._accessLookup[k2] = { module = arg2, method = v1 }
			end
		end
	end

	addAccess(arg2)
	local var2 = getmetatable(arg2)
	local var4 = if var2 then var2.__index else var2
	if var4 then
		addAccess(var4)
	end
end

tbl1.addRecipient = function(arg1, arg2)
	if not arg1.recipients then
		arg1.recipients = {}
	end

	assert(arg1.recipients, "Recipients list is nil")
	table.insert(arg1.recipients, arg2)
end

tbl1.removeRecipient = function(arg1, arg2)
	if not arg1.recipients then
		return
	end

	local var2 = table.find(arg1.recipients, arg2)
	if var2 then
		table.remove(arg1.recipients, var2)
	end
end

tbl1.clearRecipients = function(arg1)
	arg1.recipients = nil
end

tbl1.fire = function(arg1, arg2, arg3, ...)
	local var1
	if typeof(arg2) == "Instance" then
		arg1.event:FireClient(arg2, arg3, ...)
		return
	end

	for k1, v1 in arg2, nil do
		arg1.event:FireClient(v1, arg3, ...)
	end
end

tbl1.fireAll = function(arg1, arg2, ...)
	arg1.event:FireAllClients(arg2, ...)
end

tbl1.fireAllExcept = function(arg1, arg2, arg3, ...)
	if typeof(arg2) == "Instance" then
		arg2 = { arg2 }
	end

	for k1, v1 in var3:GetPlayers() do
		if table.find(arg2, v1) then
			continue
		end

		arg1.event:FireClient(v1, arg3, ...)
	end
end

tbl1.fireRecipients = function(arg1, arg2, ...)
	if not arg1.recipients then
		warn("No recipients set for service ", arg1.networkTag)
		return
	end

	arg1:fire(arg1.recipients, arg2, ...)
end

tbl1.set = function(arg1, arg2, arg3, arg4)
	arg1:fire(arg2, var5.SET_TAG, arg3, arg4)
end

tbl1.setAll = function(arg1, arg2, arg3)
	arg1:fireAll(var5.SET_TAG, arg2, arg3)
end

tbl1.setAllExcept = function(arg1, arg2, arg3, arg4)
	arg1:fireAllExcept(arg2, var5.SET_TAG, arg3, arg4)
end

tbl1.setRecipients = function(arg1, arg2, arg3)
	arg1:fireRecipients(var5.SET_TAG, arg2, arg3)
end

tbl1.destroy = function(arg1)
	arg1.remotes:Destroy()
	arg1:clearRecipients()
	if arg1.instanceConn then
		arg1.instanceConn:Disconnect()
	end

	if arg1.instance then
		arg1.instance:SetAttribute(var5.INSTANCE_ATTRIBUTE, nil)
		arg1.instance = nil
	end
end

return tbl1

--- ReplicatedStorage.Packages.DataService.Networker.NetworkerUtils [ModuleScript]
-- y u r i

return { SET_TAG = "__set", INSTANCE_ATTRIBUTE = "__networkTag", INSTANCE_TAG = "__instance" }

--- ReplicatedStorage.Shared.DataTemplate [ModuleScript]
-- y u r i

return {
	gold = 0,
	stairsOwned = 1,
	silver = 0,
	iron = 0,
	ingots = 0,
	starmetal = 0,
	crystals = 0,
	crystalGarden = {},
	wood = 0,
	essence = 0,
	totems = { bases = {}, owned = {}, slots = {} },
	woodGrove = {},
	codes = {},
	potionsLeft = {},
	wheel = { nextFree = 0 },
	smelter = { queued = 0, ready = 0, nextAt = 0 },
	starforge = { queued = 0, ready = 0, nextAt = 0, carry = 0 },
	playtime = 0,
	playtime = 0,
	settings = {
		music = 1,
		sfx = 1,
		hidePlayers = false,
		particles = true,
		titles = true,
		shadows = true,
		goldVfx = true,
		glyphVfx = true,
		trailVfx = true,
		goldDropSound = true,
		buyStairSound = true,
		autoRun = false,
		autoMine = false,
	},
	rebirths = 0,
	potions = {},
	doors = {},
	trails = {},
	equippedTrail = "",
	position = {},
	tree = {},
	passes = {},
	glyphs = {},
	glyphsOpened = 0,
	glyphOpens = {},
	glyphPulls = {},
	tutorial = { step = 0, done = false },
	funnels = {},
	upgrades = {
		moreMoney = 0,
		fasterMoney = 0,
		speedBuff = 0,
		glyphBulk = 0,
		fasterRolling = 0,
		glyphLuck = 0,
		forgeSpeed = 0,
		forgeCapacity = 0,
		starmetalMulti = 0,
		moreSilver = 0,
		fasterMining = 0,
		goldMultiplier = 0,
		autoDeposit = 0,
		moreIron = 0,
		oreDensity = 0,
		luckyStrike = 0,
		keepTree = 0,
		keepBoard1 = 0,
		keepLavaGlyphs = 0,
		keepTree2 = 0,
		keepBoard2 = 0,
		keepWaterGlyphs = 0,
		crystalYield = 0,
		growthSpeed = 0,
		crystalPower = 0,
		woodYield = 0,
		woodGrowth = 0,
		woodPower = 0,
	},
}

--- ReplicatedStorage.Shared.StairConfig [ModuleScript]
-- y u r i

local tbl1 = {
	BASE_COST = 10,
	GROWTH_BANDS = {
		{ upTo = 35, growth = 1.1 },
		{ upTo = 59, growth = 1.23 },
		{ upTo = 119, growth = 1.105 },
		{ upTo = 155, growth = 1.05 },
		{ upTo = 192, growth = 1.05 },
		{ upTo = 720, growth = 1.019 },
		{ upTo = math.huge, growth = 1.028 },
	},
}

tbl1.GROWTH = tbl1.GROWTH_BANDS[1].growth
tbl1.INCOME_PER_SEC = 0
tbl1.REACH_EDGE = 2.5
tbl1.SLACK = 6
tbl1.REACH_Y = 6
tbl1.withinReach = function(arg1, arg2, arg3)
	local var1 = arg1:GetAttribute("StairHome")
	local var2 = (var1 or arg1.CFrame):PointToObjectSpace(arg2)
	local var3 = arg1.Size * 0.5
	local var4 = tbl1.REACH_EDGE + (arg3 or 0)
	local bool2 = false
	if math.abs(var2.X) <= var3.X + var4 then
		bool2 = false
		if math.abs(var2.Z) <= var3.Z + var4 then
			bool2 = math.abs(var2.Y) <= tbl1.REACH_Y + (arg3 or 0)
		end
	end

	return bool2
end

tbl1.DEBUG = false
local tbl2 = {}
tbl1.say = function(arg1, arg2)
	if not tbl1.DEBUG or tbl2[arg1] == arg2 then
		return
	end

	tbl2[arg1] = arg2
	print("[Stairs] " .. arg1 .. ": " .. arg2)
end

tbl1.costOf = function(arg1)
	if arg1 <= 1 then
		return 0
	end

	local var1 = tbl1.BASE_COST
	for i1 = 2, arg1 - 1 do
		for k1, v1 in ipairs(tbl1.GROWTH_BANDS) do
			if i1 > v1.upTo then
				continue
			end

			local var2 = v1.growth
		end

		var1 = var1 * tbl1.GROWTH
	end

	return (math.floor(var1 + 0.5))
end

tbl1.collect = function()
	local var2 = workspace:FindFirstChild("Stairs")
	local tbl1 = {}
	if not var2 then
		warn("[Stairs] no Workspace.Stairs - the run cannot be built")
		return tbl1
	end

	for k1, v1 in ipairs(var2:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local var3 = v1:GetAttribute("StairIndex")
		if type(var3) ~= "number" then
			continue
		end

		tbl1[var3] = v1
	end

	return tbl1
end

local var1 = setmetatable({}, { __mode = "k" })
tbl1.floorFor = function(arg1, arg2)
	if not arg2 then
		return 0
	end

	local var3 = var1[arg2]
	if not var3 then
		local num1 = 0
		for k1 in pairs(arg2) do
			if type(k1) ~= "number" or num1 >= k1 then
				continue
			end

			num1 = k1
		end

		var3 = { top = num1 }
		local num2 = 0
		for i1 = 1, num1 do
			local var5 = arg2[i1]
			if var5 and var5.Name == "EndStair" then
				num2 = num2 + 1
			end

			var3[i1] = num2
		end

		var1[arg2] = var3
	end

	arg1 = math.floor(arg1 or 0)
	if arg1 <= 0 then
		return 0
	end

	return var3[math.min(arg1, var3.top)] or 0
end

return tbl1

--- ReplicatedStorage.Shared.Remotes [ModuleScript]
-- y u r i

local str1 = "SmelterCollect"
local str2 = "BuyTrail"
local var3 = game:GetService("ReplicatedStorage")
local var4 = nil
local tbl1 = {
	"StarforgeDeposit",
	"BuyStair",
	"BuyUpgrade",
	"LeaderboardUpdate",
	"SaveSetting",
	"AdminGive",
	"AdminAction",
	"ClientInfo",
	"RedeemCode",
	"CodeResult",
	"SpinWheel",
	"WheelResult",
	"MineBlock",
	"MineReset",
	"MineCycle",
	"UnlockDoor",
	"BuyTreeNode",
	"PassesOwned",
	"GiftIntent",
	"GiftAnswer",
	"SmelterDeposit",
	str1,
	str2,
	"EquipTrail",
	"RequestRejoin",
	"Rebirth",
	"BuyPotion",
	"Essence",
	"Totem",
}

if game:GetService("RunService"):IsServer() then
	var4 = var3:FindFirstChild("Remotes")
	if not var4 then
		var4 = Instance.new("Folder")
		var4.Name = "Remotes"
		var4.Parent = var3
	end

	for k1, v1 in ipairs(tbl1) do
		str2 = var4:FindFirstChild(v1)
		if str2 then
			continue
		end

		str2 = Instance.new("RemoteEvent")
		str2.Name = v1
		str2.Parent = var4
	end
else
	var4 = var3:WaitForChild("Remotes", 30)
end

local tbl2 = {}
for k2, v2 in ipairs(tbl1) do
	local var5 = var4
	var5 = var5 and var4:WaitForChild(v2, 30)
	tbl2[v2] = var5
	if tbl2[v2] then
		continue
	end

	warn("[Stairs] remote never arrived: " .. v2)
end

return tbl2

--- ReplicatedStorage.Shared.NumberFormat [ModuleScript]
-- y u r i

local tbl1 = {
	"K",
	"M",
	"B",
	"T",
	"Qd",
	"Qn",
	"Sx",
	"Sp",
	"Oc",
	"No",
	"Dc",
	"Ud",
	"Dd",
	"Td",
	"Qdd",
	"Qnd",
	"Sxd",
	"Spd",
	"Ocd",
	"Nod",
	"Vg",
}

local tbl2 = {
	SUFFIXES = tbl1,
	SUFFIX_FROM = 1000000,
	comma = function(arg1)
		local var1 = arg1
		arg1 = if type(var1) ~= "number" or var1 ~= var1 then 0 else var1
		local var2 = string.format("%.0f", (math.abs(arg1)))
		local var3 = #var2
		var1 = if arg1 < 0 then "-" else ""
		local str1 = ""
		for i1 = 1, var3 do
			local var4 = var3 - i1
			if 0 >= var4 then
				continue
			end

			if var4 % 3 ~= 0 then
				continue
			end

			str1 = str1 .. var2:sub(i1, i1) .. ","
		end

		return var1 .. str1
	end,
	suffix = function(arg1, arg2)
		local var1 = arg1
		arg1 = if type(var1) ~= "number" or var1 ~= var1 then 0 else var1
		if arg1 ~= math.huge then
			if arg1 == -math.huge then
				if 0 < arg1 then
					return "INF"
				end

				return "-INF"
			end
		end

		local var2 = math.abs(arg1)
		var1 = if arg1 < 0 then "-" else ""
		if math.floor(var2 + 0.5) < 1000 then
			return var1 .. string.format("%.0f", var2)
		end

		local var3 = math.floor(math.log10(var2) / 3)
		local var4 = nil
		local var5 = nil
		for i1 = 1, 3 do
			local var7 = arg2
			var4 = var2 / 10 ^ (var3 * 3)
			if not var7 then
				if var4 < 10 then
					var7 = 2
				else
					var7 = if var4 < 100 then 1 else 0
				end
			end

			var5 = var7
			local var8 = "%." .. var5 .. "f"
			local var9 = var4
			if tonumber(string.format(var8, var9)) < 1000 then
				break
			end

			var3 = var3 + 1
		end

		if var3 < 1 or #tbl1 < var3 then
			return var1 .. string.format("%.2e", var2)
		end

		local var10 = "%s%." .. var5 .. "f%s"
		local var11 = var1
		local var12 = var4
		local var13 = tbl1[var3]
		return string.format(var10, var11, var12, var13)
	end,
	duration = function(arg1)
		local var1 = arg1
		arg1 = if type(var1) ~= "number" or var1 ~= var1 then 0 else var1
		if arg1 < 0 then
			arg1 = 0
		end

		if arg1 < 60 then
			local str2 = "%.0fs"
			local var3 = arg1
			return string.format(str2, var3)
		end

		if arg1 < 3600 then
			local str4 = "%.0fm"
			local var5 = arg1 / 60
			return string.format(str4, var5)
		end

		if arg1 < 86400 then
			local str6 = "%.1fh"
			local var7 = arg1 / 3600
			return string.format(str6, var7)
		end

		local str7 = "%.1fd"
		local var8 = arg1 / 86400
		return string.format(str7, var8)
	end,
}

tbl2.format = function(arg1)
	local var1 = arg1
	arg1 = if type(var1) ~= "number" or var1 ~= var1 then 0 else var1
	if math.abs(arg1) < tbl2.SUFFIX_FROM then
		local var3 = arg1
		return tbl2.comma(var3)
	end

	local var4 = arg1
	return tbl2.suffix(var4)
end

tbl2.trim = function(arg1)
	return (arg1:gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1"))
end

tbl2.price = function(arg1)
	local var1 = arg1
	return tbl2.trim(tbl2.format(var1))
end

return tbl2

--- ReplicatedStorage.Shared.UpgradeConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.NumberFormat)
local var3 = require(var1.Shared.StairConfig)
local tbl1 = {
	LIST = {
		{
			id = "moreMoney",
			board = "UpgradeBoard",
			currency = "gold",
			frame = "MoreMoney",
			cap = 100,
			baseCost = 10,
			growth = 1.15,
			value = function(arg1)
				return 5 + 3 * arg1
			end,
			show = function(arg1)
				return "+" .. var2.format(arg1)
			end,
		},
		{
			id = "fasterMoney",
			board = "UpgradeBoard",
			currency = "gold",
			frame = "FasterMoney",
			cap = 9,
			baseCost = 100,
			growth = 2.2,
			value = function(arg1)
				return 1 - 0.1 * arg1
			end,
			show = function(arg1)
				return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
			end,
		},
		{
			id = "speedBuff",
			board = "UpgradeBoard",
			currency = "gold",
			frame = "SpeedBuff",
			cap = 5,
			baseCost = 100,
			growth = 2.2,
			value = function(arg1)
				return 16 + arg1
			end,
			show = function(arg1)
				local var1 = arg1
				return var2.format(var1)
			end,
		},
		{
			id = "moreSilver",
			board = "UpgradeBoard2",
			currency = "silver",
			frame = "MoreSilver",
			cap = 200,
			baseCost = 5,
			growth = 1.07,
			value = function(arg1)
				return 3 * (1 + arg1)
			end,
			show = function(arg1)
				return "+" .. var2.format(arg1)
			end,
		},
		{
			id = "fasterMining",
			board = "UpgradeBoard2",
			currency = "silver",
			frame = "FasterMining",
			cap = 15,
			baseCost = 15,
			growth = 1.45,
			value = function(arg1)
				return 2 - 0.1 * arg1
			end,
			show = function(arg1)
				return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
			end,
		},
		{
			id = "goldMultiplier",
			board = "UpgradeBoard2",
			currency = "silver",
			frame = "GoldMultiplier",
			cap = 50,
			baseCost = 25,
			growth = 1.3,
			value = function(arg1)
				return 1 + 0.5 * arg1
			end,
			show = function(arg1)
				return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
			end,
		},
		{
			id = "fasterBelts",
			board = "UpgradeBoard3",
			currency = "ingots",
			currencyName = "IRON",
			frame = "FasterBelts",
			cap = 50,
			baseCost = 10,
			growth = 1.12,
			value = function(arg1)
				return 5 * 0.98 ^ arg1
			end,
			show = function(arg1)
				return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
			end,
		},
		{
			id = "ironCapacity",
			board = "UpgradeBoard3",
			currency = "ingots",
			currencyName = "IRON",
			frame = "IronCap",
			cap = 100,
			baseCost = 10,
			growth = 1.06,
			value = function(arg1)
				return 10 + 5 * arg1
			end,
			show = function(arg1)
				local var1 = arg1
				return var2.format(var1)
			end,
		},
		{
			id = "silverMultiplier",
			board = "UpgradeBoard3",
			currency = "ingots",
			currencyName = "IRON",
			frame = "SilverMultiplier",
			cap = 20,
			baseCost = 10,
			growth = 1.38,
			value = function(arg1)
				return 1 + 0.5 * arg1
			end,
			show = function(arg1)
				return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
			end,
		},
	},
	GLYPH_BOARD = "GlyphUpgrades1",
}

table.insert(tbl1.LIST, {
	id = "glyphBulk",
	board = tbl1.GLYPH_BOARD,
	currency = "gold",
	frame = "GlyphBulk",
	cap = 25,
	baseCost = 250000,
	growth = 2,
	value = function(arg1)
		return 1 + arg1
	end,
	show = function(arg1)
		return "+" .. var2.format(arg1)
	end,
})

table.insert(tbl1.LIST, {
	id = "fasterRolling",
	board = tbl1.GLYPH_BOARD,
	currency = "gold",
	frame = "FasterRolling",
	cap = 9,
	baseCost = 500000,
	growth = 4.2,
	value = function(arg1)
		return (math.max(0.1, 1 - 0.1 * arg1))
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
	end,
})

table.insert(tbl1.LIST, {
	id = "glyphLuck",
	board = tbl1.GLYPH_BOARD,
	currency = "gold",
	frame = "GlyphLuck",
	cap = 100,
	baseCost = 25000,
	growth = 1.2,
	value = function(arg1)
		return 1 + 0.1 * arg1
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
	end,
})

table.insert(tbl1.LIST, {
	id = "autoDeposit",
	keptWith = "UpgradeBoard3",
	board = "SingleUpgrade1",
	currency = "gold",
	frame = "AutoDeposit",
	cap = 1,
	baseCost = 30000000,
	growth = 1,
	value = function(arg1)
		return arg1
	end,
	show = function(arg1)
		local var1 = arg1
		return var2.format(var1)
	end,
})

tbl1.MINE_BOARD = "UpgradeBoard4"
table.insert(tbl1.LIST, {
	id = "moreIron",
	board = tbl1.MINE_BOARD,
	currency = "gold",
	frame = "MoreIron",
	cap = 100,
	baseCost = 3800000,
	growth = 1.15,
	value = function(arg1)
		return 1 + arg1
	end,
	show = function(arg1)
		return "+" .. var2.format(arg1)
	end,
})

table.insert(tbl1.LIST, {
	id = "oreDensity",
	board = tbl1.MINE_BOARD,
	currency = "gold",
	frame = "OreDensity",
	cap = 10,
	baseCost = 16000000,
	growth = 4,
	value = function(arg1)
		return 5 * arg1
	end,
	show = function(arg1)
		return var2.format(arg1) .. "%"
	end,
})

table.insert(tbl1.LIST, {
	id = "luckyStrike",
	board = tbl1.MINE_BOARD,
	currency = "gold",
	frame = "LuckyStrike",
	cap = 10,
	baseCost = 16000000,
	growth = 4,
	value = function(arg1)
		return 5 * arg1
	end,
	show = function(arg1)
		return var2.format(arg1) .. "%"
	end,
})

tbl1.KEEPER_DOOR = "keepers"
local function keeper(arg1)
	local var1 = arg1.currency or "gold"
	arg1.currency = var1
	arg1.cap = 1
	arg1.growth = 1
	arg1.permanent = true
	arg1.value = function(arg1)
		return arg1
	end

	arg1.show = function(arg1)
		local var1 = arg1
		return var2.format(var1)
	end

	table.insert(tbl1.LIST, arg1)
end

keeper({
	id = "keepTree",
	board = "SingleUpgrade2",
	frame = "SaveTree",
	baseCost = 110000000000,
	extra = { currency = "ingots", name = "IRON", amount = 75000 },
	keeps = { treeSection = 1 },
})

keeper({
	id = "keepBoard1",
	board = "SingleUpgrade3",
	frame = "GoldUpgradeSave",
	baseCost = 220000000000,
	extra = { currency = "ingots", name = "IRON", amount = 150000 },
	keeps = { board = "UpgradeBoard" },
})

keeper({
	id = "keepLavaGlyphs",
	board = "SingleUpgrade4",
	frame = "GlyphBoard",
	baseCost = 530000000000,
	extra = { currency = "ingots", name = "IRON", amount = 400000 },
	keeps = { glyphSet = "lava", board = tbl1.GLYPH_BOARD },
})

tbl1.CRYSTAL_BOARD = "UpgradeBoard5"
table.insert(tbl1.LIST, {
	id = "crystalYield",
	board = tbl1.CRYSTAL_BOARD,
	currency = "crystals",
	frame = "CrystalYield",
	cap = 50,
	baseCost = 430,
	growth = 1.1,
	value = function(arg1)
		return math.min(arg1, 50) * 6 + 50
	end,
	show = function(arg1)
		return "+" .. var2.format(arg1)
	end,
})

table.insert(tbl1.LIST, {
	id = "growthSpeed",
	board = tbl1.CRYSTAL_BOARD,
	currency = "crystals",
	frame = "GrowthSpeed",
	cap = 20,
	baseCost = 25,
	growth = 1.35,
	value = function(arg1)
		return 15 * 0.95 ^ arg1
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
	end,
})

table.insert(tbl1.LIST, {
	id = "crystalPower",
	board = tbl1.CRYSTAL_BOARD,
	currency = "crystals",
	frame = "CrystalPower",
	cap = 50,
	baseCost = 50,
	growth = 1.22,
	value = function(arg1)
		return 1 + 0.25 * arg1
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
	end,
})

table.insert(tbl1.LIST, {
	id = "mineRange",
	keptWith = "UpgradeBoard5",
	board = "SingleUpgrade14",
	currency = "crystals",
	frame = "MineRange",
	cap = 10,
	baseCost = 100000,
	growth = 1.5,
	value = function(arg1)
		return math.min(arg1, 10) * 2.8 + 6
	end,
	show = function(arg1)
		return (string.format("%.1f", arg1):gsub("%.0$", ""))
	end,
})

tbl1.WOOD_BOARD = "UpgradeBoard6"
table.insert(tbl1.LIST, {
	id = "woodYield",
	board = tbl1.WOOD_BOARD,
	currency = "wood",
	frame = "WoodYield",
	cap = 50,
	baseCost = 100,
	growth = 1.12,
	value = function(arg1)
		return math.min(arg1, 50) * 5 + 10
	end,
	show = function(arg1)
		return "+" .. var2.format(arg1)
	end,
})

table.insert(tbl1.LIST, {
	id = "woodGrowth",
	board = tbl1.WOOD_BOARD,
	currency = "wood",
	frame = "WoodGrowth",
	cap = 20,
	baseCost = 150,
	growth = 1.35,
	value = function(arg1)
		return 20 * 0.95 ^ arg1
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
	end,
})

table.insert(tbl1.LIST, {
	id = "woodPower",
	board = tbl1.WOOD_BOARD,
	currency = "wood",
	frame = "WoodPower",
	cap = 50,
	baseCost = 200,
	growth = 1.22,
	value = function(arg1)
		return 1 + 0.25 * arg1
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
	end,
})

table.insert(tbl1.LIST, {
	id = "chopRange",
	keptWith = "UpgradeBoard6",
	board = "SingleUpgrade15",
	currency = "wood",
	frame = "ChopRange",
	cap = 10,
	baseCost = 5000,
	growth = 1.5,
	value = function(arg1)
		return math.min(arg1, 10) * 3.4 + 5
	end,
	show = function(arg1)
		return (string.format("%.1f", arg1):gsub("%.0$", ""))
	end,
})

tbl1.ESSENCE_BOARD = "UpgradeBoardEssence"
table.insert(tbl1.LIST, {
	id = "essenceCount",
	board = tbl1.ESSENCE_BOARD,
	currency = "essence",
	frame = "EssenceCount",
	cap = 25,
	baseCost = 20,
	growth = 1.28,
	value = function(arg1)
		return math.min(arg1, 25) + 8
	end,
	show = function(arg1)
		local var1 = arg1
		return var2.format(var1)
	end,
})

table.insert(tbl1.LIST, {
	id = "essenceSpeed",
	board = tbl1.ESSENCE_BOARD,
	currency = "essence",
	frame = "EssenceSpeed",
	cap = 25,
	baseCost = 30,
	growth = 1.3,
	value = function(arg1)
		return 0.93 ^ math.min(arg1, 25) * 6
	end,
	show = function(arg1)
		return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
	end,
})

table.insert(tbl1.LIST, {
	id = "essenceYield",
	board = tbl1.ESSENCE_BOARD,
	currency = "essence",
	frame = "EssenceYield",
	cap = 50,
	baseCost = 25,
	growth = 1.16,
	value = function(arg1)
		return math.min(arg1, 50) + 1
	end,
	show = function(arg1)
		return "+" .. var2.format(arg1)
	end,
})

table.insert(tbl1.LIST, {
	id = "essenceRange",
	keptWith = "UpgradeBoardEssence",
	board = "SingleUpgradeEssence",
	currency = "essence",
	frame = "EssenceRange",
	cap = 10,
	baseCost = 250,
	growth = 1.55,
	value = function(arg1)
		return math.min(arg1, 10) * 1.6 + 6
	end,
	show = function(arg1)
		return (string.format("%.1f", arg1):gsub("%.0$", ""))
	end,
})

tbl1.KEEPER_DOOR_2 = "door13"
keeper({
	id = "keepTree2",
	board = "SingleUpgrade7",
	frame = "SaveTree",
	baseCost = 13000000000000,
	extra = { currency = "ingots", name = "IRON", amount = 500000 },
	keeps = { treeSection = 2 },
})

keeper({
	id = "keepBoard2",
	board = "SingleUpgrade6",
	frame = "GoldUpgradeSave",
	baseCost = 25000000000000,
	extra = { currency = "ingots", name = "IRON", amount = 1000000 },
	keeps = { board = "UpgradeBoard2" },
})

keeper({
	id = "keepWaterGlyphs",
	board = "SingleUpgrade5",
	frame = "GlyphBoard",
	baseCost = 63000000000000,
	extra = { currency = "ingots", name = "IRON", amount = 2500000 },
	keeps = { glyphSet = "water" },
})

tbl1.KEEPER_DOOR_3 = "door21"
keeper({
	id = "keepTree3",
	board = "SingleUpgrade10",
	frame = "SaveTree",
	baseCost = 4100000000000000,
	extra = { currency = "ingots", name = "IRON", amount = 2500000 },
	keeps = { treeSection = 3 },
})

keeper({
	id = "keepBoard3",
	board = "SingleUpgrade9",
	frame = "GoldUpgradeSave",
	baseCost = 8000000000000000,
	extra = { currency = "ingots", name = "IRON", amount = 5000000 },
	keeps = { board = "UpgradeBoard3" },
})

keeper({
	id = "keepPoisonGlyphs",
	board = "SingleUpgrade8",
	frame = "GlyphBoard",
	baseCost = 2e+16,
	extra = { currency = "ingots", name = "IRON", amount = 12500000 },
	keeps = { glyphSet = "poison" },
})

tbl1.KEEPER_DOOR_4 = "door22"
keeper({
	id = "keepTree4",
	board = "SingleUpgrade13",
	frame = "SaveTree",
	currency = "wood",
	baseCost = 100000,
	keeps = { treeSection = 4 },
})

keeper({
	id = "keepBoard4",
	board = "SingleUpgrade12",
	frame = "GoldUpgradeSave",
	currency = "wood",
	baseCost = 200000,
	keeps = { board = "UpgradeBoard4" },
})

keeper({
	id = "keepWindGlyphs",
	board = "SingleUpgrade11",
	frame = "GlyphBoard",
	currency = "wood",
	baseCost = 500000,
	keeps = { glyphSet = "wind" },
})

tbl1.KEEPER_DOOR_5 = "door26"
keeper({
	id = "keepTree5",
	board = "SingleUpgrade18",
	frame = "SaveTree",
	baseCost = 3.2e+18,
	extra = { currency = "ingots", name = "IRON", amount = 10000000 },
	keeps = { treeSection = 5 },
})

keeper({
	id = "keepBoard5",
	board = "SingleUpgrade17",
	frame = "GoldUpgradeSave",
	baseCost = 6.4e+18,
	extra = { currency = "ingots", name = "IRON", amount = 20000000 },
	keeps = { board = "UpgradeBoard5" },
})

keeper({
	id = "keepElectricGlyphs",
	board = "SingleUpgrade16",
	frame = "GlyphBoard",
	baseCost = 1.6e+19,
	extra = { currency = "ingots", name = "IRON", amount = 50000000 },
	keeps = { glyphSet = "electric" },
})

tbl1.KEEPER_DOOR_7 = "door31"
keeper({
	id = "keepTree2S1",
	board = "SingleUpgrade24",
	frame = "SaveTree",
	baseCost = 2.4e+21,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 5000000 },
	keeps = { treeSection = "2:1" },
})

keeper({
	id = "keepBoard6",
	board = "SingleUpgrade23",
	frame = "GoldUpgradeSave",
	baseCost = 4.7e+21,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 10000000 },
	keeps = { board = "UpgradeBoard6" },
})

keeper({
	id = "keepCrimsonGlyphs",
	board = "SingleUpgrade22",
	frame = "GlyphBoard",
	baseCost = 1.1e+22,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 25000000 },
	keeps = { glyphSet = "crimson" },
})

tbl1.KEEPER_DOOR_8 = "door35"
keeper({
	id = "keepTree2S2",
	board = "SingleUpgrade27",
	frame = "SaveTree",
	baseCost = 1.8e+24,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 25000000 },
	keeps = { treeSection = "2:2" },
})

keeper({
	id = "keepTree2S3",
	board = "SingleUpgrade26",
	frame = "SaveTree",
	baseCost = 3.6e+24,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 50000000 },
	keeps = { treeSection = "2:3" },
})

keeper({
	id = "keepEarthGlyphs",
	board = "SingleUpgrade25",
	frame = "GlyphBoard",
	baseCost = 8.7e+24,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 100000000 },
	keeps = { glyphSet = "earth" },
})

tbl1.KEEPER_DOOR_9 = "door41"
keeper({
	id = "keepTree2S4",
	board = "SingleUpgrade30",
	frame = "SaveTree",
	baseCost = 1.4e+27,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 50000000 },
	keeps = { treeSection = "2:4" },
})

keeper({
	id = "keepTree2S5",
	board = "SingleUpgrade29",
	frame = "SaveTree",
	baseCost = 2.7e+27,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 100000000 },
	keeps = { treeSection = "2:5" },
})

keeper({
	id = "keepFrostGlyphs",
	board = "SingleUpgrade28",
	frame = "GlyphBoard",
	baseCost = 6.6e+27,
	extra = { currency = "crystals", name = "CRYSTALS", amount = 200000000 },
	keeps = { glyphSet = "frost" },
})

local tbl2 = {
	id = "forgeCapacity",
	frame = "ForgeCapacity",
	cap = 100,
	baseCost = 10,
	growth = 1.06,
	value = function(arg1)
		return 10 + 5 * arg1
	end,
	show = function(arg1)
		local var1 = arg1
		return var2.format(var1)
	end,
}

for k1, v1 in ipairs({
	{
		id = "forgeSpeed",
		frame = "ForgeSpeed",
		cap = 50,
		baseCost = 10,
		growth = 1.12,
		value = function(arg1)
			return 3 * 0.9818 ^ arg1
		end,
		show = function(arg1)
			return string.format("%.1f", arg1):gsub("%.0$", "") .. "s"
		end,
	},
	tbl2,
	{
		id = "starmetalMulti",
		frame = "StarmetalMulti",
		cap = 20,
		baseCost = 25,
		growth = 1.38,
		value = function(arg1)
			return 1 + 0.5 * arg1
		end,
		show = function(arg1)
			return string.format("%.1f", arg1):gsub("%.0$", "") .. "x"
		end,
	},
}) do

	v1.board = "StarforgeBoard"
	v1.currency = "starmetal"
	v1.currencyName = "STARMETAL"
	table.insert(tbl1.LIST, v1)
end

tbl1.extraCost = function(arg1, arg2)
	return arg1 and (arg1.extra and arg1.extra.amount * (arg2 or 1)) or 0
end

tbl1.costText = function(arg1, arg2)
	if not arg1 or (not arg1.extra) then
		return var2.price(arg2) .. " " .. tbl1.currencyLabel(arg1)
	end

	local var1 = arg2
	local var3 = var2.trim(var2.suffix(var1))
	local var4 = arg1.extra.amount
	local var5 = var2.trim(var2.suffix(var4))
	var4 = arg1.extra.name
	return var3 .. " " .. tbl1.currencyLabel(arg1) .. " + " .. var5 .. " " .. (var4 or arg1.extra.currency:upper())
end

tbl1.afterRebirth = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = arg1
	arg1 = var1 or {}
	local var2 = arg3
	var1 = {}
	for k1, v1 in pairs(var2 or {}) do
		var1[k1] = v1
	end

	local tbl2 = {}
	var2 = {}
	local tbl3 = {}
	for k2, v2 in ipairs(tbl1.LIST) do
		if not v2.permanent then
			continue
		end

		if 0 >= (arg1[v2.id] or 0) then
			continue
		end

		var1[v2.id] = arg1[v2.id]
		if v2.keeps and v2.keeps.board then
			tbl2[v2.keeps.board] = true
		end

		if v2.keeps and v2.keeps.treeSection then
			var2[v2.keeps.treeSection] = true
		end

		if not v2.keeps then
			continue
		end

		if not v2.keeps.glyphSet then
			continue
		end

		tbl3[v2.keeps.glyphSet] = true
	end

	for k3, v3 in ipairs(tbl1.LIST) do
		local var3 = v3.board
		if not tbl2[var3] then
			local var4 = v3.keptWith
			if not var4 then
				continue
			end

			var3 = v3.keptWith
			var4 = tbl2[var3]
			if not var4 then
				continue
			end
		end

		var3 = v3.id
		local var5 = arg1[var3]
		if not var5 then
			continue
		end

		var3 = arg1[v3.id]
		var5 = v3.id
		var1[var5] = var3
	end

	local tbl4 = {}
	local var6
	local var7
	if next(var2) then
		if arg4 then
			local var8 = arg2
			for k4, v4 in pairs(var8 or {}) do
				var7 = arg4.BY_ID[k4]
				local var10 = var7
				if var10 then
					if arg4.sectionOf then
						var10 = arg4.sectionOf(var7)
						if not var10 then
							var10 = if var7.floor == nil then 1 else nil
						end
					end
				end

				if not v4 or (not var10) then
					continue
				end

				if not var2[var10] then
					continue
				end

				tbl4[k4] = v4
			end
		end
	end

	local tbl5 = {}
	if arg6 then
		local var11 = arg5
		for k5, v5 in pairs(var11 or {}) do
			local var12 = arg6.BY_ID[k5]
			if not var12 then
				continue
			end

			if not tbl3[var12.set] then
				continue
			end

			tbl5[k5] = v5
		end
	end

	return var1, tbl4, tbl5
end

local var4
if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	local tbl3 = {
		"keepTree2S1",
		"keepBoard6",
		"keepCrimsonGlyphs",
		"essenceCount",
		"essenceSpeed",
		"essenceYield",
		"essenceRange",
	}

	for i1 = #tbl1.LIST, 1, -1 do
		var4 = table.find(tbl3, tbl1.LIST[i1].id)
		if not var4 then
			continue
		end

		table.remove(tbl1.LIST, i1)
	end
end

tbl1.BY_ID = {}
for k2, v2 in ipairs(tbl1.LIST) do
	tbl1.BY_ID[v2.id] = v2
end

tbl1.QUANTITIES = { 1, 10, 0 }
tbl1.boards = function()
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(tbl1.LIST) do
		if not v1.board then
			continue
		end

		if tbl2[v1.board] then
			continue
		end

		tbl2[v1.board] = true
		table.insert(tbl3, v1.board)
	end

	return tbl3
end

tbl1.forBoard = function(arg1)
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1.LIST) do
		if v1.board ~= arg1 then
			continue
		end

		table.insert(tbl2, v1)
	end

	return tbl2
end

tbl1.currencyLabel = function(arg1)
	local var1 = arg1.currencyName
	return var1 or (arg1.currency or "gold"):upper()
end

tbl1.quantityLabel = function(arg1)
	if arg1 == 0 then
		return "MAX"
	end

	return var2.format(arg1) .. "x"
end

tbl1.costAt = function(arg1, arg2)
	return (math.floor(arg1.baseCost * arg1.growth ^ arg2 + 0.5))
end

tbl1.totalCost = function(arg1, arg2, arg3)
	local num1 = 0
	local num2 = 0
	for i1 = 0, arg3 - 1 do
		if arg1.cap <= arg2 + i1 then
			break
		end

		num1 = num1 + tbl1.costAt(arg1, arg2 + i1)
		num2 = num2 + 1
	end

	return num1, num2
end

tbl1.affordable = function(arg1, arg2, arg3)
	local num1 = 0
	local num2 = 0
	local var1 = tbl1.costAt(arg1, arg2 + num2)
	while arg2 + num2 < arg1.cap and arg3 >= num1 + var1 do
		num1 = num1 + var1
		num2 = num2 + 1
	end

	return num2, num1
end

tbl1.resolve = function(arg1, arg2, arg3, arg4)
	if arg4 == 0 then
		local var4 = arg1
		local var5 = arg2
		local var6 = arg3
		return tbl1.affordable(var4, var5, var6)
	end

	local var7, var8 = tbl1.totalCost(arg1, arg2, arg4)
	return var8, var7
end

tbl1.futureText = function(arg1, arg2)
	if arg1.cap <= arg2 then
		return "MAX"
	end

	local var1 = arg2
	local var2 = arg1.show(arg1.value(var1))
	local var3 = arg2 + 1
	return var2 .. " > " .. arg1.show(arg1.value(var3))
end

tbl1.payoutInterval = function(arg1)
	local var1 = tbl1.BY_ID.fasterMoney
	local var2 = arg1
	local var4 = var1.value((var2 or {})[var1.id] or 0)
	if var4 <= 0.01 then
		var4 = 0.01
	end

	return var4
end

tbl1.goldPerPayout = function(arg1, arg2)
	local var1 = tbl1.BY_ID.moreMoney
	local var2 = arg1
	local var3 = var1.value((var2 or {})[var1.id] or 0)
	return var3 * tbl1.goldMultiplier(arg1, arg2)
end

tbl1.goldPerSecond = function(arg1, arg2)
	local var1 = arg1
	arg1 = var1 or {}
	return tbl1.goldPerPayout(arg1, arg2) / tbl1.payoutInterval(arg1) + var3.INCOME_PER_SEC
end

tbl1.goldMultiplier = function(arg1, arg2)
	local var1 = tbl1.BY_ID.goldMultiplier
	local var2 = arg1
	local var3 = tbl1.BY_ID.crystalPower
	local var4 = var1.value((var2 or {})[var1.id] or 0) * (arg2 or 1)
	return var4 * (var3 and var3.value(({})[var3.id] or 0) or 1)
end

tbl1.walkSpeed = function(arg1)
	local var1 = tbl1.BY_ID.speedBuff
	local var2 = arg1
	local var3 = (var2 or {})[var1.id] or 0
	return var1.value(var3)
end

tbl1.BOARD_DOOR = {
	GlyphUpgrades1 = "lavaGlyphs",
	UpgradeBoard2 = "mine",
	UpgradeBoard3 = "ironOre",
	SingleUpgrade1 = "ironOre",
	SingleUpgrade14 = "crystals",
	SingleUpgrade15 = "door23",
	UpgradeBoard6 = "door23",
	UpgradeBoard4 = "ironOre",
	SingleUpgrade2 = "keepers",
	SingleUpgrade3 = "keepers",
	SingleUpgrade4 = "keepers",
	SingleUpgrade5 = "door13",
	SingleUpgrade6 = "door13",
	SingleUpgrade7 = "door13",
	SingleUpgrade8 = "door21",
	SingleUpgrade9 = "door21",
	SingleUpgrade10 = "door21",
	SingleUpgrade11 = "door22",
	SingleUpgrade12 = "door22",
	SingleUpgrade13 = "door22",
	SingleUpgrade16 = "door26",
	SingleUpgrade17 = "door26",
	SingleUpgrade18 = "door26",
	SingleUpgrade22 = "door31",
	SingleUpgrade23 = "door31",
	SingleUpgrade24 = "door31",
	SingleUpgrade25 = "door35",
	SingleUpgrade26 = "door35",
	SingleUpgrade27 = "door35",
	SingleUpgrade28 = "door41",
	SingleUpgrade29 = "door41",
	SingleUpgrade30 = "door41",
	StarforgeBoard = "door45",
	UpgradeBoard5 = "crystals",
	UpgradeBoard6 = "door23",
	UpgradeBoardEssence = "door34",
	SingleUpgradeEssence = "door34",
}

tbl1.BOARD_REVEAL = { UpgradeBoard4 = "ironOre", UpgradeBoard5 = "crystals" }
tbl1.doorFor = function(arg1)
	return arg1 and tbl1.BOARD_DOOR[arg1.board] or nil
end

return tbl1

--- ReplicatedStorage.Shared.AdminConfig [ModuleScript]
-- y u r i

local var1 = require(script.Parent.NumberFormat)
local tbl1 = { IDS = { [4446126] = true }, MAX_GOLD = 1e+60 }
tbl1.CURRENCIES = {
	{ id = "gold", label = "Gold", max = tbl1.MAX_GOLD },
	{ id = "silver", label = "Silver", max = tbl1.MAX_GOLD },
	{ id = "iron", label = "Iron Ore", max = tbl1.MAX_GOLD },
	{ id = "ingots", label = "Ingots", max = tbl1.MAX_GOLD },
	{ id = "crystals", label = "Crystals", max = tbl1.MAX_GOLD },
	{ id = "wood", label = "Wood", max = tbl1.MAX_GOLD },
	{ id = "essence", label = "Essence", max = tbl1.MAX_GOLD },
	{ id = "starmetal", label = "Starmetal", max = tbl1.MAX_GOLD },
}

local tbl2 = { id = "glyphs", label = "Max All Glyphs" }
tbl1.ACTIONS = {
	{ id = "doors", label = "Unlock All Doors" },
	{ id = "upgrades", label = "Max All Upgrades" },
	{ id = "tree", label = "Buy Whole Tree" },
	tbl2,
	{ id = "trails", label = "Own All Trails" },
	{ id = "crystalsGrow", label = "Grow All Crystals" },
	{ id = "totems", label = "Build All Totems" },
	{ id = "totemsClear", label = "Clear Totems", confirm = true },
	{ id = "reset", label = "RESET PROGRESS", confirm = true },
}

tbl1.ACTION_BY_ID = {}
for k1, v1 in ipairs(tbl1.ACTIONS) do
	local var2 = tbl1.ACTION_BY_ID
	var2[v1.id] = v1
end

local tbl3 = { qa = 15, qi = 18 }
for k2, v2 in ipairs(var1.SUFFIXES) do
	local var3 = v2:lower()
	tbl3[var3] = 3 * k2
end

tbl1.parseAmount = function(arg1)
	if type(arg1) ~= "string" then
		return nil
	end

	arg1 = arg1:gsub("[,%s]", ""):lower()
	local var2 = tonumber(arg1)
	if var2 then
		return var2
	end

	local var3, var4 = arg1:match("^([%d%.]+)(%a+)$")
	var3 = tonumber(var3)
	if not var3 then
		return nil
	end

	local var6 = tbl3[var4]
	if not var6 then
		return nil
	end

	return var3 * 10 ^ var6
end

tbl1.BY_CURRENCY = {}
for k3, v3 in ipairs(tbl1.CURRENCIES) do
	tbl1.BY_CURRENCY[v3.id] = v3
end

tbl1.isAdmin = function(arg1)
	return tbl1.IDS[arg1] == true
end

return tbl1

--- ReplicatedStorage.Shared.MineConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.UpgradeConfig)
local tbl1 = { CELL = 10, RUN = 20, BASE_ORE_PER_RUN = 4, ORE_PER_RUN_PER_LEVEL = 1 }
tbl1.densityOf = function(arg1)
	return (tbl1.BASE_ORE_PER_RUN + tbl1.ORE_PER_RUN_PER_LEVEL * (arg1 or 0)) / tbl1.RUN
end

tbl1.ORE_EVERY = tbl1.RUN / tbl1.BASE_ORE_PER_RUN
tbl1.DOOR = "mine"
tbl1.IRON_DOOR = "ironOre"
tbl1.SKIP_PRODUCT = 3712838896
tbl1.IRON_SHARE = 0.35
tbl1.CLAIM_RADIUS = 50
tbl1.gridOf = function(arg1, arg2)
	local var1 = arg2 - 1
	return var1 % arg1.X, var1 // arg1.X % arg1.Y, var1 // (arg1.X * arg1.Y)
end

tbl1.cellOf = function(arg1, arg2, arg3, arg4)
	return arg4 * arg1.X * arg1.Y + arg3 * arg1.X + arg2 + 1
end

tbl1.grid = function(arg1)
	local var1 = arg1.Size
	local var2 = tbl1.CELL
	return Vector3.new(math.floor(var1.X / var2 + 0.001), math.floor(var1.Y / var2 + 0.001), (math.floor(var1.Z / var2 + 0.001))), arg1.Position - var1 / 2
end

tbl1.centreOf = function(arg1, arg2, arg3, arg4)
	local var1 = tbl1.CELL
	return arg1 + Vector3.new((arg2 + 0.5) * var1, (arg3 + 0.5) * var1, (arg4 + 0.5) * var1)
end

tbl1.oreCells = function(arg1, arg2, arg3)
	local var1 = Random.new(arg2)
	local tbl2 = {}
	local var2 = tbl1.BASE_ORE_PER_RUN + tbl1.ORE_PER_RUN_PER_LEVEL * (arg3 or 0)
	for i1 = 1, arg1, tbl1.RUN do
		local tbl3 = {}
		for i2 = i1, math.min(i1 + tbl1.RUN - 1, arg1) do
			table.insert(tbl3, i2)
		end

		for i3 = #tbl3, 2, -1 do
			local var3 = var1:NextInteger(1, i3)
			local var4 = tbl3[var3]
			local var5 = tbl3[i3]
			tbl3[i3] = var4
			tbl3[var3] = var5
		end

		for i4 = 1, math.min(#tbl3, (math.floor(var2 * #tbl3 / tbl1.RUN + 0.5))) do
			tbl2[tbl3[i4]] = true
		end
	end

	return tbl2
end

tbl1.ironCells = function(arg1, arg2, arg3)
	local var1 = Random.new(arg2 + 7919)
	local tbl2 = {}
	for i1 = 1, arg1 do
		if not arg3[i1] then
			continue
		end

		if var1:NextNumber() >= tbl1.IRON_SHARE then
			continue
		end

		tbl2[i1] = true
	end

	return tbl2
end

tbl1.ironPerOre = function(arg1)
	local var2 = arg1 or 0
	return var1.BY_ID.moreIron.value(var2)
end

tbl1.luckyChance = function(arg1)
	return var1.BY_ID.luckyStrike.value(arg1 or 0) / 100
end

tbl1.silverPerOre = function(arg1)
	local var2 = arg1 or 0
	return var1.BY_ID.moreSilver.value(var2)
end

tbl1.MIN_HOLD = 0.1
tbl1.REMOTE_BLOCKS_PER_ORE = 3
tbl1.remoteBlocksPerOre = function(arg1)
	return tbl1.REMOTE_BLOCKS_PER_ORE * tbl1.densityOf(0) / tbl1.densityOf(arg1)
end

tbl1.REMOTE_MOVE_SECONDS = 0.35
tbl1.REMOTE_TICK = 1
tbl1.secondsFor = function(arg1, arg2)
	local var2 = arg1 or 0
	return (math.max(tbl1.MIN_HOLD, math.max(0.25, var1.BY_ID.fasterMining.value(var2)) / math.max(arg2 or 1, 1)))
end

tbl1.RESPAWN_SECONDS = 300
tbl1.REACH = 40
tbl1.VERTICAL_MARGIN = 6
tbl1.CLAIM_FLOOR = 0.6
return tbl1

--- ReplicatedStorage.Shared.LeaderboardConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {
	id = "glyphs",
	part = "LeaderboardGlyphs",
	store = "GlyphsLeaderboard_v1",
	key = "glyphsPulled",
	kind = "number",
}

local var2 = require(var1.Shared.AdminConfig)
local var3 = require(var1.Shared.NumberFormat)
local tbl2 = {
	BOARDS = {
		{
			id = "gold",
			part = "LeaderboardGold",
			store = "GoldLeaderboard_v2",
			key = "gold",
			kind = "number",
			encoding = "log",
			migrateFrom = "GoldLeaderboard_v1",
		},
		{
			id = "silver",
			part = "LeaderboardSilver",
			store = "SilverLeaderboard_v2",
			key = "silver",
			kind = "number",
			encoding = "log",
			migrateFrom = "SilverLeaderboard_v1",
		},
		{
			id = "playtime",
			part = "LeaderboardPlaytime",
			store = "PlaytimeLeaderboard_v1",
			key = "playtime",
			kind = "time",
		},
		tbl1,
	},
	TOP_N = 50,
	TICK = 60,
}

tbl2.tickFor = function(arg1)
	return (math.max(tbl2.TICK, #tbl2.BOARDS * #tbl2.STORED * 60 / (math.max(1, arg1) * 2)))
end

local tbl3 = { id = "all", label = "ALL" }
tbl2.AUDIENCES = { { id = "f2p", label = "F2P" }, { id = "p2w", label = "P2W" }, tbl3 }
tbl2.STORED = { "f2p", "p2w" }
tbl2.storeFor = function(arg1, arg2)
	return arg1.store .. "_" .. arg2
end

tbl2.audienceOf = function(arg1)
	if type(arg1) == "table" and next(arg1) ~= nil then
		return "p2w"
	end

	return "f2p"
end

tbl2.EXCLUDED = {}
for k1 in pairs(var2.IDS) do
	tbl2.EXCLUDED[k1] = true
end

tbl2.SHOW_EXCLUDED_IN_STUDIO = true
tbl2.showsExcluded = function()
	local var1 = tbl2.SHOW_EXCLUDED_IN_STUDIO
	return var1 and game:GetService("RunService"):IsStudio()
end

tbl2.ranked = function(arg1)
	if arg1 == nil then
		return false
	end

	local var1 = tbl2.showsExcluded()
	return var1 or (not tbl2.EXCLUDED[arg1])
end

tbl2.BY_ID = {}
for k2, v1 in ipairs(tbl2.BOARDS) do
	tbl2.BY_ID[v1.id] = v1
end

tbl2.LOG_SCALE = 1000000000000000
tbl2.encode = function(arg1, arg2)
	arg2 = math.max(0, arg2)
	if arg1.encoding == "log" then
		return (math.floor(math.log10(arg2 + 1) * tbl2.LOG_SCALE))
	end

	return (math.floor(arg2))
end

tbl2.decode = function(arg1, arg2)
	if arg1.encoding == "log" then
		return 10 ^ (arg2 / tbl2.LOG_SCALE) - 1
	end

	return arg2
end

tbl2.formatValue = function(arg1, arg2)
	if arg1 and arg1.kind == "time" then
		local var2 = arg2
		return var3.duration(var2)
	end

	local var4 = arg2
	return var3.format(var4)
end

return tbl2

--- ReplicatedStorage.Shared.DoorConfig [ModuleScript]
-- y u r i

local tbl1 = { DOORS = {
	{ id = "lavaGlyphs", model = "Door", floor = 1, cost = 400, currency = "gold" },
	{ id = "mine", model = "Door2", floor = 3, cost = 1500, currency = "gold" },
	{ id = "upgradeTree", model = "Door3", floor = 5, cost = 72000, currency = "gold" },
	{ id = "ironOre", model = "Door5", floor = 10, cost = 38000000, currency = "gold" },
	{ id = "waterGlyphs", model = "Door4", floor = 8, cost = 3600000, currency = "gold" },
	{ id = "poisonGlyphs", model = "Door6", floor = 13, cost = 310000000, currency = "gold" },
} }

table.insert(tbl1.DOORS, { id = "keepers", model = "Door8", floor = 20, cost = 4100000000, currency = "gold" })
table.insert(tbl1.DOORS, { id = "windGlyphs", model = "Door9", floor = 23, cost = 8300000000, currency = "gold" })
table.insert(tbl1.DOORS, { id = "crystals", model = "Door10", floor = 28, cost = 26000000000, currency = "gold" })
table.insert(tbl1.DOORS, {
	id = "electricGlyphs",
	model = "Door11",
	floor = 29,
	cost = 33000000000,
	currency = "gold",
})

table.insert(tbl1.DOORS, { id = "trails2", model = "Door12", floor = 33, cost = 81000000000, currency = "gold" })
local tbl2 = { id = "door30", model = "Door30", floor = 116, cost = 4.7e+21 }
local tbl3 = { id = "door38", model = "Door38", floor = 130, cost = 4.8e+23 }
for k1, v1 in ipairs({
	{ id = "door13", model = "Door13", floor = 40, cost = 480000000000 },
	{ id = "door14", model = "Door14", floor = 44, cost = 1200000000000 },
	{ id = "door15", model = "Door15", floor = 46, cost = 1900000000000 },
	{ id = "door16", model = "Door16", floor = 50, cost = 4600000000000 },
	{ id = "door17", model = "Door17", floor = 54, cost = 11000000000000 },
	{ id = "door23", model = "Door23", floor = 70, cost = 1100000000000000 },
	{ id = "door22", model = "Door22", floor = 72, cost = 2200000000000000 },
	{ id = "door21", model = "Door21", floor = 64, cost = 150000000000000 },
	{ id = "door19", model = "Door19", floor = 66, cost = 300000000000000 },
	{ id = "door20", model = "Door20", floor = 76, cost = 8200000000000000 },
	{ id = "door18", model = "Door18", floor = 58, cost = 28000000000000 },
	{ id = "door28", model = "Door28", floor = 90, cost = 8.5e+17 },
	{ id = "door26", model = "Door26", floor = 84, cost = 1.2e+17 },
	{ id = "door24", model = "Door24", floor = 86, cost = 2.3e+17 },
	{ id = "door25", model = "Door25", floor = 96, cost = 6.2e+18 },
	{ id = "door31", model = "Door31", floor = 104, cost = 8.8e+19 },
	{ id = "door29", model = "Door29", floor = 106, cost = 1.7e+20 },
	tbl2,
	{ id = "door33", model = "Door33", floor = 110, cost = 6.4e+20 },
	{ id = "door34", model = "Door34", floor = 108, cost = 3.3e+20 },
	{ id = "door32", model = "Door32", floor = 113, cost = 1.7e+21 },
	{ id = "door35", model = "Door35", floor = 124, cost = 6.7e+22 },
	{ id = "door36", model = "Door36", floor = 126, cost = 1.3e+23 },
	{ id = "door37", model = "Door37", floor = 128, cost = 2.5e+23 },
	tbl3,
	{ id = "door39", model = "Door39", floor = 133, cost = 1.3e+24 },
	{ id = "door40", model = "Door40", floor = 136, cost = 3.6e+24 },
	{ id = "door41", model = "Door41", floor = 144, cost = 5.1e+25 },
	{ id = "door42", model = "Door42", floor = 146, cost = 9.8e+25 },
	{ id = "door43", model = "Door43", floor = 148, cost = 1.9e+26 },
	{ id = "door44", model = "Door44", floor = 150, cost = 3.6e+26 },
	{ id = "door45", model = "Door45", floor = 153, cost = 9.8e+26 },
	{ id = "door46", model = "Door46", floor = 156, cost = 2.7e+27 },
}) do

	v1.currency = "gold"
	table.insert(tbl1.DOORS, v1)
end

table.insert(tbl1.DOORS, { id = "potions", model = "Door7", floor = 15, cost = 890000000, currency = "gold" })
local tbl4 = { id = "rebirth4", model = "DoorRebirth4", floor = 16, cost = 2000000000 }
local tbl5 = { id = "rebirth8", model = "DoorRebirth8", floor = 36, cost = 190000000000 }
for k2, v2 in ipairs({
	tbl4,
	tbl5,
	{ id = "rebirth12", model = "DoorRebirth12", floor = 57, cost = 22000000000000 },
	{ id = "rebirth16", model = "DoorRebirth16", floor = 78, cost = 1.6e+16 },
	{ id = "rebirth20", model = "DoorRebirth20", floor = 98, cost = 1.2e+19 },
	{ id = "rebirth24", model = "DoorRebirth24", floor = 118, cost = 9.3e+21 },
	{ id = "rebirth28", model = "DoorRebirth28", floor = 138, cost = 7e+24 },
	{ id = "rebirth29", model = "DoorRebirth29", floor = 158, cost = 5.3e+27 },
}) do

	v2.currency = "gold"
	v2.rebirths = k2 - 1
	v2.section = k2
	table.insert(tbl1.DOORS, v2)
end

local str1 = "door26"
local tbl6 = { "keepers", "door13", "door21", "door22", str1, "door31", "door35", "door41" }
for k3, v3 in ipairs(tbl1.DOORS) do
	if not table.find(tbl6, v3.id) then
		continue
	end

	local num1 = 0
	for k4, v4 in ipairs(tbl1.DOORS) do
		if not v4.section then
			continue
		end

		if v4.floor > v3.floor then
			continue
		end

		num1 = math.max(num1, v4.section)
	end

	v3.rebirths = num1
end

local var1
if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	local tbl7 = { "door29", "door30", "door31", "rebirth24", "door32", "door33", "door34" }
	for i1 = #tbl1.DOORS, 1, -1 do
		var1 = table.find(tbl7, tbl1.DOORS[i1].id)
		if not var1 then
			continue
		end

		table.remove(tbl1.DOORS, i1)
	end
end

tbl1.BY_ID = {}
for k5, v5 in ipairs(tbl1.DOORS) do
	tbl1.BY_ID[v5.id] = v5
end

tbl1.rebirthsNeeded = function(arg1)
	return arg1 and arg1.rebirths or 0
end

return tbl1

--- ReplicatedStorage.Shared.GlyphConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.NumberFormat)
local var3 = require(var1.Shared.UpgradeConfig)
local tbl1 = { CURRENCY = "gold", ROLL_EVERY = 1 }
tbl1.rollEvery = function(arg1)
	local var2 = var3.BY_ID.fasterRolling
	if not var2 then
		return tbl1.ROLL_EVERY
	end

	local var4 = arg1
	local var5 = (var4 or {})[var2.id] or 0
	return (math.max(0.1, var2.value(var5)))
end

tbl1.MAX_RARE_CHANCE = 0.9
local tbl2 = {
	id = "water",
	name = "Water Glyphs",
	model = "WaterRunes",
	door = "waterGlyphs",
	cost = 160000,
	vfx = Color3.fromRGB(90, 195, 255),
}

tbl2.list = {
	{ id = "dew", name = "Dew", odds = 1, cap = 1000, filler = true, gold = 0.025 },
	{ id = "drip", name = "Drip", odds = 100, cap = 500, gold = 0.05 },
	{ id = "mist", name = "Mist", odds = 500, cap = 300, silver = 0.05 },
	{ id = "frost", name = "Frost", odds = 5000, cap = 60, silver = 0.25 },
	{ id = "tide", name = "Tide", odds = 20000, cap = 40, luck = 0.1 },
	{ id = "surge", name = "Surge", odds = 50000, cap = 25, gold = 0.5 },
	{ id = "abyss", name = "Abyss", odds = 250000, cap = 15, silver = 0.75 },
	{ id = "geyser", name = "Geyser", odds = 750000, cap = 10, luck = 0.25 },
	{ id = "vortex", name = "Vortex", odds = 2500000, cap = 5, gold = 2.5 },
	{
		id = "tsunami",
		name = "Tsunami",
		odds = 10000000,
		cap = 3,
		gold = 1.25,
		silver = 1.25,
		luck = 1.25,
	},
}

local tbl3 = {
	id = "poison",
	name = "Poison Glyphs",
	model = "PoisonRunes",
	door = "poisonGlyphs",
	cost = 11000000,
	vfx = Color3.fromRGB(185, 110, 255),
}

tbl3.list = {
	{ id = "ooze", name = "Ooze", odds = 1, cap = 1000, filler = true, gold = 0.125 },
	{ id = "spore", name = "Spore", odds = 250, cap = 500, iron = 0.01 },
	{ id = "sludge", name = "Sludge", odds = 1000, cap = 300, silver = 0.25 },
	{ id = "fume", name = "Fume", odds = 10000, cap = 60, iron = 0.1 },
	{ id = "venom", name = "Venom", odds = 50000, cap = 40, luck = 0.5 },
	{ id = "blight", name = "Blight", odds = 150000, cap = 25, iron = 0.25 },
	{ id = "toxin", name = "Toxin", odds = 500000, cap = 15, silver = 3.75 },
	{ id = "miasma", name = "Miasma", odds = 2000000, cap = 10, iron = 0.75 },
	{ id = "hemlock", name = "Hemlock", odds = 7500000, cap = 5, gold = 12.5 },
	{
		id = "plague",
		name = "Plague",
		odds = 25000000,
		cap = 3,
		gold = 6.25,
		silver = 6.25,
		luck = 6.25,
		iron = 2.5,
	},
}

local tbl4 = {
	id = "wind",
	name = "Wind Glyphs",
	model = "WindRunes",
	door = "windGlyphs",
	cost = 24000000,
	vfx = Color3.fromRGB(226, 232, 240),
}

tbl4.list = {
	{ id = "breeze", name = "Breeze", odds = 1, cap = 2000, filler = true, gold = 0.3125 },
	{ id = "gust", name = "Gust", odds = 500, cap = 1000, luck = 0.025 },
	{ id = "zephyr", name = "Zephyr", odds = 2500, cap = 600, silver = 0.625 },
	{ id = "draft", name = "Draft", odds = 25000, cap = 60, luck = 0.5 },
	{ id = "squall", name = "Squall", odds = 125000, cap = 40, iron = 0.5 },
	{ id = "gale", name = "Gale", odds = 400000, cap = 25, luck = 1.25 },
	{ id = "cyclone", name = "Cyclone", odds = 1500000, cap = 15, silver = 18.75 },
	{ id = "tempest", name = "Tempest", odds = 5000000, cap = 10, luck = 3.75 },
	{ id = "hurricane", name = "Hurricane", odds = 20000000, cap = 5, gold = 62.5 },
	{
		id = "typhoon",
		name = "Typhoon",
		odds = 75000000,
		cap = 3,
		gold = 31.25,
		silver = 31.25,
		luck = 31.25,
		iron = 12.5,
	},
}

local tbl5 = {
	id = "electric",
	name = "Electric Glyphs",
	model = "ElectricGlyphs",
	door = "electricGlyphs",
	cost = 82000000,
	vfx = Color3.fromRGB(255, 225, 60),
}

tbl5.list = {
	{ id = "spark", name = "Spark", odds = 1, cap = 2500, filler = true, gold = 0.5 },
	{ id = "static", name = "Static", odds = 1000, cap = 1250, gold = 1 },
	{ id = "volt", name = "Volt", odds = 5000, cap = 750, silver = 1 },
	{ id = "arc", name = "Arc", odds = 50000, cap = 60, gold = 25 },
	{ id = "jolt", name = "Jolt", odds = 250000, cap = 40, iron = 1, crystals = 0.005 },
	{ id = "charge", name = "Charge", odds = 1000000, cap = 25, gold = 50 },
	{ id = "shock", name = "Shock", odds = 4000000, cap = 15, silver = 50 },
	{ id = "thunder", name = "Thunder", odds = 15000000, cap = 10, gold = 125 },
	{ id = "lightning", name = "Lightning", odds = 50000000, cap = 5, luck = 12.5 },
	{
		id = "thunderbolt",
		name = "Thunderbolt",
		odds = 200000000,
		cap = 3,
		gold = 125,
		silver = 125,
		luck = 62.5,
		iron = 25,
		crystals = 0.1,
	},
}

local tbl6 = {
	id = "crimson",
	name = "Crimson Glyphs",
	model = "CrimsonGlyphs",
	door = "door14",
	cost = 3500000000,
	vfx = Color3.fromRGB(220, 30, 50),
}

tbl6.list = {
	{ id = "scarlet", name = "Scarlet", odds = 1, cap = 8000, filler = true, gold = 0.78125 },
	{ id = "ruby", name = "Ruby", odds = 2000, cap = 4000, gold = 1.5625 },
	{
		id = "garnet",
		name = "Garnet",
		odds = 10000,
		cap = 2400,
		silver = 1.5625,
		crystals = 0.0001875,
	},
	{ id = "rose", name = "Rose", odds = 100000, cap = 60, gold = 125 },
	{ id = "vermilion", name = "Vermilion", odds = 500000, cap = 40, iron = 5 },
	{ id = "carmine", name = "Carmine", odds = 2000000, cap = 25, gold = 250 },
	{
		id = "cardinal",
		name = "Cardinal",
		odds = 8000000,
		cap = 15,
		silver = 250,
		crystals = 0.01,
	},
	{ id = "bloodmoon", name = "Bloodmoon", odds = 30000000, cap = 10, gold = 625 },
	{ id = "sanguine", name = "Sanguine", odds = 100000000, cap = 5, luck = 60 },
	{
		id = "crimsonheart",
		name = "Crimsonheart",
		odds = 400000000,
		cap = 3,
		gold = 625,
		silver = 625,
		luck = 300,
		iron = 125,
		crystals = 0.1,
	},
}

local tbl7 = {
	id = "earth",
	name = "Earth Glyphs",
	model = "EarthGlyphs",
	door = "door17",
	cost = 33000000000,
	vfx = Color3.fromRGB(60, 230, 120),
}

tbl7.list = {
	{ id = "pebble", name = "Pebble", odds = 1, cap = 10000, filler = true, gold = 3 },
	{ id = "moss", name = "Moss", odds = 4000, cap = 5000, silver = 6.25 },
	{ id = "clay", name = "Clay", odds = 20000, cap = 3000, iron = 0.5 },
	{ id = "root", name = "Root", odds = 200000, cap = 60, silver = 625, crystals = 0.005 },
	{ id = "boulder", name = "Boulder", odds = 1000000, cap = 40, gold = 625 },
	{ id = "quartz", name = "Quartz", odds = 4000000, cap = 25, iron = 50 },
	{ id = "jade", name = "Jade", odds = 16000000, cap = 15, silver = 1250 },
	{ id = "emerald", name = "Emerald", odds = 60000000, cap = 10, gold = 3125 },
	{ id = "terra", name = "Terra", odds = 200000000, cap = 5, iron = 200, crystals = 0.06 },
	{
		id = "gaia",
		name = "Gaia",
		odds = 800000000,
		cap = 3,
		gold = 3125,
		silver = 3125,
		luck = 1500,
		iron = 600,
		crystals = 0.1,
	},
}

local tbl8 = {
	id = "frost",
	name = "Frost Glyphs",
	model = "FrostGlyphs",
	door = "door19",
	cost = 940000000000,
	vfx = Color3.fromRGB(140, 220, 255),
}

tbl8.list = {
	{ id = "frostbite", name = "Frostbite", odds = 1, cap = 12500, filler = true, gold = 12 },
	{ id = "rime", name = "Rime", odds = 8000, cap = 6250, gold = 25 },
	{ id = "sleet", name = "Sleet", odds = 40000, cap = 3750, silver = 25, crystals = 0.0002 },
	{ id = "hail", name = "Hail", odds = 400000, cap = 60, gold = 3125 },
	{ id = "glacier", name = "Glacier", odds = 2000000, cap = 40, iron = 250 },
	{ id = "icicle", name = "Icicle", odds = 8000000, cap = 25, gold = 6250 },
	{
		id = "blizzard",
		name = "Blizzard",
		odds = 32000000,
		cap = 15,
		silver = 6250,
		crystals = 0.01,
	},
	{ id = "permafrost", name = "Permafrost", odds = 120000000, cap = 10, gold = 15625 },
	{
		id = "polaris",
		name = "Polaris",
		odds = 400000000,
		cap = 5,
		luck = 7500,
		crystals = 0.06,
	},
	{
		id = "absolutezero",
		name = "Absolute Zero",
		odds = 1600000000,
		cap = 3,
		gold = 15625,
		silver = 15625,
		luck = 7500,
		iron = 3000,
		crystals = 0.1,
	},
}

local tbl9 = {
	id = "cosmic",
	name = "Cosmic Glyphs",
	model = "CosmicGlyphs",
	door = "door20",
	currency = "ingots",
	cost = 50000,
	vfx = Color3.fromRGB(170, 90, 255),
}

tbl9.list = {
	{ id = "stardust", name = "Stardust", odds = 1, cap = 12500, filler = true, gold = 60 },
	{ id = "comet", name = "Comet", odds = 16000, cap = 6250, gold = 125 },
	{
		id = "meteor",
		name = "Meteor",
		odds = 80000,
		cap = 3750,
		silver = 125,
		crystals = 0.0002,
	},
	{ id = "nova", name = "Nova", odds = 800000, cap = 60, gold = 15625 },
	{ id = "pulsar", name = "Pulsar", odds = 5000000, cap = 40, iron = 1250 },
	{ id = "quasar", name = "Quasar", odds = 25000000, cap = 25, gold = 31250, wood = 0.01 },
	{
		id = "galaxy",
		name = "Galaxy",
		odds = 125000000,
		cap = 15,
		silver = 31250,
		crystals = 0.01,
		wood = 0.02,
	},
	{ id = "supernova", name = "Supernova", odds = 600000000, cap = 10, gold = 78125 },
	{
		id = "blackhole",
		name = "Black Hole",
		odds = 3000000000,
		cap = 5,
		luck = 37500,
		crystals = 0.06,
		wood = 0.04,
	},
	{
		id = "singularity",
		name = "Singularity",
		odds = 20000000000,
		cap = 3,
		gold = 78125,
		silver = 78125,
		luck = 37500,
		iron = 15000,
		crystals = 0.1,
		wood = 0.08,
	},
}

local tbl10 = {
	id = "sakura",
	name = "Sakura Glyphs",
	model = "SakuraGlyphs",
	door = "door24",
	cost = 710000000000000,
	vfx = Color3.fromRGB(255, 150, 205),
}

tbl10.list = {
	{ id = "petal", name = "Petal", odds = 1, cap = 5000, filler = true, gold = 750 },
	{ id = "bud", name = "Bud", odds = 7600000, cap = 2500, gold = 1562.5 },
	{
		id = "blossom",
		name = "Blossom",
		odds = 43000000,
		cap = 1500,
		silver = 1562.5,
		crystals = 0.0005,
	},
	{ id = "sakura", name = "Sakura", odds = 240000000, cap = 60, gold = 78125 },
	{ id = "lotus", name = "Lotus", odds = 1400000000, cap = 40, iron = 6250 },
	{ id = "koi", name = "Koi", odds = 7600000000, cap = 25, gold = 156250, wood = 0.01 },
	{
		id = "lantern",
		name = "Lantern",
		odds = 25000000000,
		cap = 15,
		silver = 156250,
		crystals = 0.01,
		wood = 0.02,
	},
	{ id = "torii", name = "Torii", odds = 95000000000, cap = 10, gold = 390625 },
	{
		id = "kitsune",
		name = "Kitsune",
		odds = 5600000000000,
		cap = 5,
		luck = 187500,
		crystals = 0.06,
		wood = 0.04,
	},
	{
		id = "eternalbloom",
		name = "Eternal Bloom",
		odds = 300000000000000,
		cap = 3,
		gold = 390625,
		silver = 390625,
		luck = 187500,
		iron = 75000,
		crystals = 0.1,
		wood = 0.08,
	},
}

local tbl11 = {
	id = "radiant",
	name = "Radiant Glyphs",
	model = "RadiantGlyphs",
	door = "door25",
	cost = 2e+16,
	vfx = Color3.fromRGB(255, 214, 90),
}

tbl11.list = {
	{ id = "glimmer", name = "Glimmer", odds = 1, cap = 5000, filler = true, gold = 3750 },
	{ id = "gleam", name = "Gleam", odds = 14000000, cap = 2500, gold = 7812.5 },
	{
		id = "shine",
		name = "Shine",
		odds = 79000000,
		cap = 1500,
		silver = 7812.5,
		crystals = 0.0005,
	},
	{ id = "halo", name = "Halo", odds = 440000000, cap = 60, gold = 390625 },
	{ id = "sunbeam", name = "Sunbeam", odds = 2500000000, cap = 40, iron = 31250 },
	{
		id = "zenith",
		name = "Zenith",
		odds = 14000000000,
		cap = 25,
		gold = 781250,
		wood = 0.01,
	},
	{
		id = "solstice",
		name = "Solstice",
		odds = 48000000000,
		cap = 15,
		silver = 781250,
		crystals = 0.01,
		wood = 0.02,
	},
	{ id = "seraph", name = "Seraph", odds = 180000000000, cap = 10, gold = 1953125 },
	{
		id = "celestia",
		name = "Celestia",
		odds = 1700000000000000,
		cap = 5,
		luck = 937500,
		crystals = 0.06,
		wood = 0.04,
	},
	{
		id = "genesis",
		name = "Genesis",
		odds = 7800000000000000,
		cap = 3,
		gold = 1953125,
		silver = 1953125,
		luck = 937500,
		iron = 375000,
		crystals = 0.1,
		wood = 0.08,
	},
}

local tbl12 = {
	id = "astral",
	name = "Astral Glyphs",
	model = "AstralGlyphs",
	door = "door29",
	cost = 5.4e+17,
	vfx = Color3.fromRGB(190, 150, 255),
}

tbl12.list = {
	{ id = "mote", name = "Mote", odds = 1, cap = 5000, filler = true, gold = 18750 },
	{ id = "glint", name = "Glint", odds = 700000000, cap = 2500, gold = 39062.5 },
	{
		id = "aster",
		name = "Aster",
		odds = 3900000000,
		cap = 1500,
		silver = 39062.5,
		wood = 0.0005,
	},
	{ id = "orbit", name = "Orbit", odds = 22000000000, cap = 60, gold = 1953125 },
	{ id = "lumen", name = "Lumen", odds = 120000000000, cap = 40, iron = 156250 },
	{
		id = "equinox",
		name = "Equinox",
		odds = 700000000000,
		cap = 25,
		gold = 3906250,
		wood = 0.01,
	},
	{
		id = "astrolabe",
		name = "Astrolabe",
		odds = 2300000000000,
		cap = 15,
		silver = 3906250,
		wood = 0.03,
	},
	{
		id = "constellation",
		name = "Constellation",
		odds = 8700000000000,
		cap = 10,
		gold = 9765625,
	},
	{
		id = "empyrean",
		name = "Empyrean",
		odds = 1.9e+17,
		cap = 5,
		luck = 4687500,
		wood = 0.06,
	},
	{
		id = "astralcrown",
		name = "Astral Crown",
		odds = 1e+18,
		cap = 3,
		gold = 9765625,
		silver = 9765625,
		luck = 4687500,
		iron = 1875000,
		wood = 0.12,
	},
}

local tbl13 = {
	id = "nebula",
	name = "Nebula Glyphs",
	model = "NebulaGlyphs",
	door = "door30",
	cost = 1.5e+19,
	vfx = Color3.fromRGB(120, 160, 255),
}

tbl13.list = {
	{ id = "haze", name = "Haze", odds = 1, cap = 5000, filler = true, gold = 93750 },
	{
		id = "drift",
		name = "Drift",
		odds = 41000000000,
		cap = 2500,
		gold = 195312.5,
		essence = 0.0001,
	},
	{
		id = "veil",
		name = "Veil",
		odds = 230000000000,
		cap = 1500,
		silver = 195312.5,
		wood = 0.0005,
	},
	{ id = "ion", name = "Ion", odds = 1300000000000, cap = 60, gold = 9765625 },
	{
		id = "plasma",
		name = "Plasma",
		odds = 7300000000000,
		cap = 40,
		iron = 781250,
		essence = 0.00625,
	},
	{
		id = "photon",
		name = "Photon",
		odds = 41000000000000,
		cap = 25,
		gold = 19531250,
		wood = 0.01,
	},
	{
		id = "nebula",
		name = "Nebula",
		odds = 140000000000000,
		cap = 15,
		silver = 19531250,
		wood = 0.03,
	},
	{
		id = "aurora",
		name = "Aurora",
		odds = 510000000000000,
		cap = 10,
		gold = 48828125,
		essence = 0.025,
	},
	{
		id = "starforge",
		name = "Starforge",
		odds = 3.3e+19,
		cap = 5,
		luck = 23437500,
		wood = 0.06,
		essence = 0.05,
	},
	{
		id = "infinity",
		name = "Infinity",
		odds = 1.7e+20,
		cap = 3,
		gold = 48828125,
		silver = 48828125,
		luck = 23437500,
		iron = 9375000,
		wood = 0.12,
	},
}

local tbl14 = {
	id = "rift",
	name = "Rift Glyphs",
	model = "RiftGlyphs",
	door = "door36",
	cost = 4.1e+20,
	vfx = Color3.fromRGB(70, 210, 195),
}

tbl14.list = {
	{ id = "crack", name = "Crack", odds = 1, cap = 5000, filler = true, gold = 468750 },
	{ id = "shard", name = "Shard", odds = 150000000000, cap = 2500, gold = 976562.5 },
	{
		id = "fissure",
		name = "Fissure",
		odds = 840000000000,
		cap = 1500,
		silver = 976562.5,
		wood = 0.0005,
	},
	{ id = "fracture", name = "Fracture", odds = 4700000000000, cap = 60, gold = 48828125 },
	{ id = "breach", name = "Breach", odds = 27000000000000, cap = 40, iron = 3906250 },
	{
		id = "chasm",
		name = "Chasm",
		odds = 150000000000000,
		cap = 25,
		gold = 97656250,
		wood = 0.01,
	},
	{
		id = "rupture",
		name = "Rupture",
		odds = 480000000000000,
		cap = 15,
		silver = 97656250,
		wood = 0.03,
	},
	{ id = "schism", name = "Schism", odds = 1800000000000000, cap = 10, gold = 244140625 },
	{
		id = "cataclysm",
		name = "Cataclysm",
		odds = 1.6e+21,
		cap = 5,
		luck = 117187500,
		wood = 0.06,
	},
	{
		id = "riftheart",
		name = "Riftheart",
		odds = 1.1e+22,
		cap = 3,
		gold = 244140625,
		silver = 244140625,
		luck = 117187500,
		iron = 46875000,
		wood = 0.12,
	},
}

local tbl15 = {
	id = "void",
	name = "Void Glyphs",
	model = "VoidGlyphs",
	door = "door40",
	currency = "essence",
	cost = 100000,
	vfx = Color3.fromRGB(140, 90, 235),
}

tbl15.list = {
	{ id = "hush", name = "Hush", odds = 1, cap = 5000, filler = true, gold = 2343750 },
	{
		id = "hollow",
		name = "Hollow",
		odds = 1.1e+17,
		cap = 2500,
		gold = 4882812.5,
		essence = 0.0001,
	},
	{
		id = "shade",
		name = "Shade",
		odds = 6.2e+17,
		cap = 1500,
		silver = 4882812.5,
		wood = 0.0005,
	},
	{ id = "gloom", name = "Gloom", odds = 3.5e+18, cap = 60, gold = 244140625 },
	{
		id = "umbra",
		name = "Umbra",
		odds = 2e+19,
		cap = 40,
		iron = 19531250,
		essence = 0.00625,
	},
	{ id = "null", name = "Null", odds = 1.1e+20, cap = 25, gold = 488281250, wood = 0.01 },
	{
		id = "oblivion",
		name = "Oblivion",
		odds = 3.5e+20,
		cap = 15,
		silver = 488281250,
		wood = 0.03,
	},
	{
		id = "nether",
		name = "Nether",
		odds = 1.4e+21,
		cap = 10,
		gold = 1220703125,
		essence = 0.025,
	},
	{
		id = "voidwalker",
		name = "Voidwalker",
		odds = 2.4e+22,
		cap = 5,
		luck = 585937500,
		wood = 0.06,
		essence = 0.05,
	},
	{
		id = "voidcrown",
		name = "Voidcrown",
		odds = 1.2e+23,
		cap = 3,
		gold = 1220703125,
		silver = 1220703125,
		luck = 585937500,
		iron = 234375000,
		wood = 0.12,
	},
}

local tbl16 = {
	id = "forge",
	name = "Forge Glyphs",
	model = "ForgeGlyphs",
	door = "door42",
	cost = 3.1e+23,
	vfx = Color3.fromRGB(255, 140, 50),
}

tbl16.list = {
	{ id = "soot", name = "Soot", odds = 1, cap = 5000, filler = true, gold = 11718750 },
	{
		id = "slag",
		name = "Slag",
		odds = 5.2e+18,
		cap = 2500,
		gold = 24414062.5,
		essence = 0.0001,
	},
	{
		id = "rivet",
		name = "Rivet",
		odds = 2.9e+19,
		cap = 1500,
		silver = 24414062.5,
		wood = 0.0005,
	},
	{ id = "anvil", name = "Anvil", odds = 1.6e+20, cap = 60, gold = 1220703125 },
	{
		id = "bellows",
		name = "Bellows",
		odds = 9.2e+20,
		cap = 40,
		iron = 97656250,
		essence = 0.00625,
	},
	{
		id = "crucible",
		name = "Crucible",
		odds = 5.2e+21,
		cap = 25,
		gold = 2441406250,
		wood = 0.01,
	},
	{
		id = "alloy",
		name = "Alloy",
		odds = 1.8e+22,
		cap = 15,
		silver = 2441406250,
		wood = 0.03,
	},
	{
		id = "temper",
		name = "Temper",
		odds = 7.5e+22,
		cap = 10,
		gold = 6103515625,
		essence = 0.025,
	},
	{
		id = "hammerfall",
		name = "Hammerfall",
		odds = 1.2e+24,
		cap = 5,
		luck = 2929687500,
		wood = 0.06,
		essence = 0.05,
	},
	{
		id = "forgeheart",
		name = "Forgeheart",
		odds = 6.5e+24,
		cap = 3,
		gold = 6103515625,
		silver = 6103515625,
		luck = 2929687500,
		iron = 1171875000,
		wood = 0.12,
	},
}

local tbl17 = {
	id = "starfire",
	name = "Starfire Glyphs",
	model = "StarfireGlyphs",
	door = "door46",
	cost = 8.3e+24,
	vfx = Color3.fromRGB(255, 215, 110),
}

tbl17.list = {
	{ id = "flicker", name = "Flicker", odds = 1, cap = 5000, filler = true, gold = 58593750 },
	{
		id = "flare",
		name = "Flare",
		odds = 5e+19,
		cap = 2500,
		gold = 122070312.5,
		essence = 0.0001,
	},
	{
		id = "sunspot",
		name = "Sunspot",
		odds = 2.8e+20,
		cap = 1500,
		silver = 122070312.5,
		wood = 0.0005,
	},
	{ id = "corona", name = "Corona", odds = 1.6e+21, cap = 60, gold = 6103515625 },
	{
		id = "fusion",
		name = "Fusion",
		odds = 8.9e+21,
		cap = 40,
		iron = 488281250,
		essence = 0.00625,
	},
	{
		id = "helios",
		name = "Helios",
		odds = 5e+22,
		cap = 25,
		gold = 12207031250,
		wood = 0.01,
	},
	{
		id = "magnetar",
		name = "Magnetar",
		odds = 1.8e+23,
		cap = 15,
		silver = 12207031250,
		wood = 0.03,
	},
	{
		id = "starburst",
		name = "Starburst",
		odds = 7.2e+23,
		cap = 10,
		gold = 30517578125,
		essence = 0.025,
	},
	{
		id = "hypernova",
		name = "Hypernova",
		odds = 1.2e+25,
		cap = 5,
		luck = 14648437500,
		wood = 0.06,
		essence = 0.05,
	},
	{
		id = "starcore",
		name = "Starcore",
		odds = 7.2e+25,
		cap = 3,
		gold = 30517578125,
		silver = 30517578125,
		luck = 14648437500,
		iron = 5859375000,
		wood = 0.12,
	},
}

tbl1.SETS = {
	{
		id = "lava",
		name = "Lava Glyphs",
		model = "LavaRunes",
		door = "lavaGlyphs",
		cost = 100,
		vfx = nil,
		list = {
			{ id = "cinder", name = "Cinder", odds = 1, cap = 500, filler = true, gold = 0.01 },
			{ id = "ember", name = "Ember", odds = 50, cap = 250, gold = 0.02 },
			{ id = "ash", name = "Ash", odds = 200, cap = 150, silver = 0.02 },
			{ id = "scorch", name = "Scorch", odds = 1500, cap = 100, silver = 0.05 },
			{ id = "basalt", name = "Basalt", odds = 5000, cap = 50, luck = 0.02 },
			{ id = "magma", name = "Magma", odds = 10000, cap = 30, gold = 0.1 },
			{ id = "molten", name = "Molten", odds = 50000, cap = 20, silver = 0.15 },
			{ id = "pyre", name = "Pyre", odds = 100000, cap = 15, luck = 0.05 },
			{ id = "inferno", name = "Inferno", odds = 500000, cap = 10, gold = 0.5 },
			{
				id = "vulcan",
				name = "Vulcan",
				odds = 1000000,
				cap = 5,
				gold = 0.25,
				silver = 0.25,
				luck = 0.25,
			},
		},
	},
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl13,
	tbl14,
	tbl15,
	tbl16,
	tbl17,
}

local tbl18 = { frostbite = Color3.fromRGB(225, 245, 255) }
tbl18.rime = Color3.fromRGB(205, 238, 255)
tbl18.sleet = Color3.fromRGB(185, 230, 255)
tbl18.hail = Color3.fromRGB(160, 220, 255)
tbl18.glacier = Color3.fromRGB(130, 205, 250)
tbl18.icicle = Color3.fromRGB(105, 190, 245)
tbl18.blizzard = Color3.fromRGB(80, 170, 240)
tbl18.permafrost = Color3.fromRGB(60, 150, 230)
tbl18.polaris = Color3.fromRGB(45, 125, 220)
tbl18.absolutezero = Color3.fromRGB(30, 100, 210)
tbl18.stardust = Color3.fromRGB(240, 225, 255)
tbl18.comet = Color3.fromRGB(225, 200, 255)
tbl18.meteor = Color3.fromRGB(210, 175, 255)
tbl18.nova = Color3.fromRGB(195, 150, 255)
tbl18.pulsar = Color3.fromRGB(180, 125, 250)
tbl18.quasar = Color3.fromRGB(165, 100, 245)
tbl18.galaxy = Color3.fromRGB(150, 80, 235)
tbl18.supernova = Color3.fromRGB(135, 60, 225)
tbl18.blackhole = Color3.fromRGB(110, 40, 200)
tbl18.singularity = Color3.fromRGB(90, 25, 180)
tbl18.petal = Color3.fromRGB(255, 235, 242)
tbl18.bud = Color3.fromRGB(255, 220, 232)
tbl18.blossom = Color3.fromRGB(255, 200, 222)
tbl18.sakura = Color3.fromRGB(255, 180, 210)
tbl18.lotus = Color3.fromRGB(250, 160, 198)
tbl18.koi = Color3.fromRGB(245, 140, 185)
tbl18.lantern = Color3.fromRGB(238, 118, 170)
tbl18.torii = Color3.fromRGB(228, 95, 152)
tbl18.kitsune = Color3.fromRGB(212, 72, 135)
tbl18.eternalbloom = Color3.fromRGB(190, 50, 115)
tbl18.glimmer = Color3.fromRGB(255, 248, 225)
tbl18.gleam = Color3.fromRGB(255, 240, 200)
tbl18.shine = Color3.fromRGB(255, 232, 175)
tbl18.halo = Color3.fromRGB(255, 224, 150)
tbl18.sunbeam = Color3.fromRGB(255, 214, 125)
tbl18.zenith = Color3.fromRGB(252, 202, 100)
tbl18.solstice = Color3.fromRGB(248, 188, 78)
tbl18.seraph = Color3.fromRGB(240, 172, 58)
tbl18.celestia = Color3.fromRGB(228, 152, 40)
tbl18.genesis = Color3.fromRGB(210, 130, 25)
tbl18.mote = Color3.fromRGB(245, 240, 255)
tbl18.glint = Color3.fromRGB(232, 222, 255)
tbl18.aster = Color3.fromRGB(218, 204, 255)
tbl18.orbit = Color3.fromRGB(204, 184, 252)
tbl18.lumen = Color3.fromRGB(190, 165, 250)
tbl18.equinox = Color3.fromRGB(176, 146, 246)
tbl18.astrolabe = Color3.fromRGB(160, 126, 238)
tbl18.constellation = Color3.fromRGB(142, 106, 228)
tbl18.empyrean = Color3.fromRGB(122, 86, 214)
tbl18.astralcrown = Color3.fromRGB(100, 66, 196)
tbl18.haze = Color3.fromRGB(225, 235, 255)
tbl18.drift = Color3.fromRGB(205, 222, 255)
tbl18.veil = Color3.fromRGB(185, 208, 255)
tbl18.ion = Color3.fromRGB(165, 192, 255)
tbl18.plasma = Color3.fromRGB(148, 175, 252)
tbl18.photon = Color3.fromRGB(132, 158, 248)
tbl18.nebula = Color3.fromRGB(120, 140, 240)
tbl18.aurora = Color3.fromRGB(112, 120, 230)
tbl18.starforge = Color3.fromRGB(104, 98, 218)
tbl18.infinity = Color3.fromRGB(96, 76, 204)
tbl18.crack = Color3.fromRGB(220, 250, 245)
tbl18.shard = Color3.fromRGB(195, 240, 235)
tbl18.fissure = Color3.fromRGB(170, 230, 222)
tbl18.fracture = Color3.fromRGB(145, 218, 208)
tbl18.breach = Color3.fromRGB(120, 205, 194)
tbl18.chasm = Color3.fromRGB(96, 190, 180)
tbl18.rupture = Color3.fromRGB(74, 172, 164)
tbl18.schism = Color3.fromRGB(54, 152, 146)
tbl18.cataclysm = Color3.fromRGB(38, 130, 128)
tbl18.riftheart = Color3.fromRGB(24, 108, 110)
tbl18.hush = Color3.fromRGB(228, 222, 240)
tbl18.hollow = Color3.fromRGB(210, 200, 232)
tbl18.shade = Color3.fromRGB(192, 178, 224)
tbl18.gloom = Color3.fromRGB(174, 156, 216)
tbl18.umbra = Color3.fromRGB(156, 134, 208)
tbl18.null = Color3.fromRGB(138, 112, 198)
tbl18.oblivion = Color3.fromRGB(118, 92, 186)
tbl18.nether = Color3.fromRGB(98, 72, 172)
tbl18.voidwalker = Color3.fromRGB(80, 54, 156)
tbl18.voidcrown = Color3.fromRGB(62, 38, 138)
tbl18.soot = Color3.fromRGB(235, 225, 215)
tbl18.slag = Color3.fromRGB(240, 210, 185)
tbl18.rivet = Color3.fromRGB(245, 195, 155)
tbl18.anvil = Color3.fromRGB(250, 178, 125)
tbl18.bellows = Color3.fromRGB(252, 160, 98)
tbl18.crucible = Color3.fromRGB(250, 140, 72)
tbl18.alloy = Color3.fromRGB(244, 120, 52)
tbl18.temper = Color3.fromRGB(234, 100, 36)
tbl18.hammerfall = Color3.fromRGB(218, 80, 24)
tbl18.forgeheart = Color3.fromRGB(196, 60, 14)
tbl18.flicker = Color3.fromRGB(255, 250, 235)
tbl18.flare = Color3.fromRGB(255, 240, 200)
tbl18.sunspot = Color3.fromRGB(255, 225, 160)
tbl18.corona = Color3.fromRGB(255, 205, 120)
tbl18.fusion = Color3.fromRGB(255, 180, 90)
tbl18.helios = Color3.fromRGB(255, 150, 70)
tbl18.magnetar = Color3.fromRGB(250, 120, 70)
tbl18.starburst = Color3.fromRGB(240, 95, 80)
tbl18.hypernova = Color3.fromRGB(225, 70, 95)
tbl18.starcore = Color3.fromRGB(200, 45, 110)
tbl18.dew = Color3.fromRGB(178, 235, 255)
tbl18.drip = Color3.fromRGB(150, 220, 255)
tbl18.mist = Color3.fromRGB(120, 205, 255)
tbl18.frost = Color3.fromRGB(92, 186, 255)
tbl18.tide = Color3.fromRGB(64, 165, 252)
tbl18.surge = Color3.fromRGB(44, 142, 245)
tbl18.abyss = Color3.fromRGB(28, 118, 232)
tbl18.geyser = Color3.fromRGB(20, 96, 214)
tbl18.vortex = Color3.fromRGB(30, 80, 205)
tbl18.tsunami = Color3.fromRGB(48, 70, 200)
tbl18.ooze = Color3.fromRGB(232, 205, 255)
tbl18.spore = Color3.fromRGB(218, 182, 255)
tbl18.sludge = Color3.fromRGB(204, 158, 255)
tbl18.fume = Color3.fromRGB(190, 135, 252)
tbl18.venom = Color3.fromRGB(176, 112, 248)
tbl18.blight = Color3.fromRGB(162, 90, 242)
tbl18.toxin = Color3.fromRGB(146, 70, 232)
tbl18.miasma = Color3.fromRGB(130, 52, 220)
tbl18.hemlock = Color3.fromRGB(114, 36, 206)
tbl18.plague = Color3.fromRGB(98, 22, 190)
tbl18.breeze = Color3.fromRGB(252, 252, 255)
tbl18.gust = Color3.fromRGB(238, 240, 245)
tbl18.zephyr = Color3.fromRGB(224, 227, 234)
tbl18.draft = Color3.fromRGB(209, 213, 221)
tbl18.squall = Color3.fromRGB(193, 198, 207)
tbl18.gale = Color3.fromRGB(176, 182, 192)
tbl18.cyclone = Color3.fromRGB(159, 165, 176)
tbl18.tempest = Color3.fromRGB(142, 148, 160)
tbl18.hurricane = Color3.fromRGB(124, 130, 143)
tbl18.typhoon = Color3.fromRGB(106, 112, 125)
tbl18.spark = Color3.fromRGB(255, 253, 215)
tbl18.static = Color3.fromRGB(255, 248, 185)
tbl18.volt = Color3.fromRGB(255, 242, 155)
tbl18.arc = Color3.fromRGB(255, 234, 125)
tbl18.jolt = Color3.fromRGB(255, 225, 95)
tbl18.charge = Color3.fromRGB(255, 214, 65)
tbl18.shock = Color3.fromRGB(255, 200, 40)
tbl18.thunder = Color3.fromRGB(250, 184, 20)
tbl18.lightning = Color3.fromRGB(240, 165, 5)
tbl18.thunderbolt = Color3.fromRGB(225, 140, 0)
tbl18.scarlet = Color3.fromRGB(255, 200, 200)
tbl18.ruby = Color3.fromRGB(255, 170, 170)
tbl18.garnet = Color3.fromRGB(252, 140, 145)
tbl18.rose = Color3.fromRGB(245, 110, 118)
tbl18.vermilion = Color3.fromRGB(238, 80, 90)
tbl18.carmine = Color3.fromRGB(225, 55, 68)
tbl18.cardinal = Color3.fromRGB(205, 35, 50)
tbl18.bloodmoon = Color3.fromRGB(180, 20, 38)
tbl18.sanguine = Color3.fromRGB(150, 10, 28)
tbl18.crimsonheart = Color3.fromRGB(120, 0, 20)
tbl18.pebble = Color3.fromRGB(205, 255, 215)
tbl18.moss = Color3.fromRGB(175, 245, 190)
tbl18.clay = Color3.fromRGB(145, 235, 165)
tbl18.root = Color3.fromRGB(115, 225, 140)
tbl18.boulder = Color3.fromRGB(85, 210, 115)
tbl18.quartz = Color3.fromRGB(60, 190, 95)
tbl18.jade = Color3.fromRGB(40, 165, 80)
tbl18.emerald = Color3.fromRGB(25, 140, 65)
tbl18.terra = Color3.fromRGB(15, 115, 50)
tbl4 = 38
tbl18.gaia = Color3.fromRGB(5, 90, tbl4)
tbl1.COLORS = tbl18
if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	tbl18 = { "astral", "nebula" }
	for i1 = #tbl1.SETS, 1, -1 do
		tbl4 = table.find(tbl18, tbl1.SETS[i1].id)
		if not tbl4 then
			continue
		end

		table.remove(tbl1.SETS, i1)
	end
end

tbl1.BY_SET = {}
tbl1.BY_ID = {}
tbl1.BY_NAME = {}
tbl1.ALL = {}
for k1, v1 in ipairs(tbl1.SETS) do
	tbl1.BY_SET[v1.id] = v1
	for k2, v2 in ipairs(v1.list) do
		v2.set = v1.id
		tbl1.BY_ID[v2.id] = v2
		tbl1.BY_NAME[v2.name] = v2
		table.insert(tbl1.ALL, v2)
	end
end

tbl1.setOf = function(arg1)
	local var1 = tbl1.BY_ID[arg1]
	return var1 and tbl1.BY_SET[var1.set] or nil
end

tbl1.oddsText = function(arg1)
	if 1000000 <= arg1 then
		local var3 = arg1
		return var2.trim(var2.suffix(var3))
	end

	if 10000 <= arg1 then
		local var4 = arg1 / 1000
		return (if arg1 % 1000 == 0 then "%dk" else "%.1fk"):format(var4)
	end

	return (("%.1f"):format(arg1):gsub("%.0$", ""))
end

tbl1.costText = function(arg1)
	if 1000000 <= arg1 then
		local var3 = arg1
		return var2.trim(var2.suffix(var3))
	end

	local var4 = arg1
	return var2.price(var4)
end

tbl1.multiplierText = function(arg1)
	local var1 = nil
	if 1000 <= arg1 then
		return var2.format((math.floor(arg1))) .. "x"
	end

	if 100 <= arg1 then
		var1 = ("%.0f"):format(arg1)
	else
		var1 = if 10 <= arg1 then ("%.1f"):format(arg1) else ("%.2f"):format(arg1)
	end

	if var1:find("%.") then
		var1 = var1:gsub("0+$", ""):gsub("%.$", "")
	end

	return var1 .. "x"
end

tbl1.counted = function(arg1, arg2)
	return (math.min(math.max(arg2 or 0, 0), arg1.cap))
end

tbl1.contribution = function(arg1, arg2)
	local var1 = tbl1.counted(arg1, arg2)
	return {
		gold = 1 + (arg1.gold or 0) * var1,
		silver = 1 + (arg1.silver or 0) * var1,
		luck = 1 + (arg1.luck or 0) * var1,
		iron = 1 + (arg1.iron or 0) * var1,
		crystals = 1 + (arg1.crystals or 0) * var1,
		wood = 1 + (arg1.wood or 0) * var1,
		essence = 1 + (arg1.essence or 0) * var1,
	}
end

tbl1.multipliers = function(arg1)
	local var1 = arg1
	local tbl2 = { gold = 1, silver = 1, luck = 1, iron = 1, crystals = 1, wood = 1, essence = 1 }
	for k1, v1 in pairs(var1 or {}) do
		local var2 = tbl1.BY_ID[k1]
		if not var2 then
			continue
		end

		if type(v1) ~= "number" or 0 >= v1 then
			continue
		end

		local var3 = tbl1.counted(var2, v1)
		local var4 = tbl2.gold + (var2.gold or 0) * var3
		tbl2.gold = var4
		var4 = tbl2.silver + (var2.silver or 0) * var3
		tbl2.silver = var4
		var4 = tbl2.luck + (var2.luck or 0) * var3
		tbl2.luck = var4
		var4 = tbl2.iron + (var2.iron or 0) * var3
		tbl2.iron = var4
		var4 = tbl2.crystals + (var2.crystals or 0) * var3
		tbl2.crystals = var4
		var4 = tbl2.wood + (var2.wood or 0) * var3
		tbl2.wood = var4
		var4 = tbl2.essence + (var2.essence or 0) * var3
		tbl2.essence = var4
	end

	return tbl2
end

tbl1.chances = function(arg1, arg2, arg3)
	local var1 = arg1.list
	arg2 = math.max(arg2 or 1, 1)
	local var2 = var1[1]
	local num1 = 0
	for k1, v1 in ipairs(var1) do
		if v1.filler then
			var2 = v1
		else
			local bool1 = true
			if arg3 ~= nil then
				bool1 = (arg3[v1.id] or 0) < v1.cap
			end

			if not bool1 then
				continue
			end

			num1 = num1 + 1 / v1.odds
		end
	end

	local bool2 = true
	if arg3 ~= nil then
		bool2 = (arg3[var2.id] or 0) < var2.cap
	end

	if arg3 ~= nil and (num1 == 0 and (not bool2)) then
		local var6 = arg1
		local var7 = arg2
		local var8 = nil
		return tbl1.chances(var6, var7, var8)
	end

	local var11 = bool2 and tbl1.MAX_RARE_CHANCE or 1
	local var12 = arg2
	if var11 < num1 * arg2 then
		var12 = var11 / num1
	end

	local tbl2 = {}
	local num2 = 0
	for k2, v2 in ipairs(var1) do
		if v2.filler then
			continue
		end

		local bool3 = true
		local var14
		if arg3 ~= nil then
			var14 = v2.cap
			bool3 = (arg3[v2.id] or 0) < var14
		end

		if not bool3 then
			continue
		end

		var14 = v2.odds
		tbl2[v2.id] = var12 / var14
		num2 = num2 + tbl2[v2.id]
	end

	tbl2[var2.id] = math.max(0, 1 - num2)
	if arg3 ~= nil and (not bool2) then
		local var15 = tbl2[var2.id]
		local var16 = tbl1.chances(arg1, arg2, nil)
		local num3 = 0
		for k3, v3 in ipairs(var1) do
			local bool4 = true
			if arg3 ~= nil then
				bool4 = (arg3[v3.id] or 0) < v3.cap
			end

			if bool4 then
				continue
			end

			num3 = num3 + (var16[v3.id] or 0)
		end

		if 0 < num3 and 0 < var15 then
			for k4, v4 in ipairs(var1) do
				local bool5 = true
				if arg3 ~= nil then
					bool5 = (arg3[v4.id] or 0) < v4.cap
				end

				if bool5 then
					continue
				end

				tbl2[v4.id] = var15 * (var16[v4.id] or 0) / num3
			end
		end
	end

	return tbl2
end

tbl1.ladder = function(arg1, arg2, arg3)
	local var1 = tbl1.chances(arg1, arg2, arg3)
	local tbl2 = {}
	local num1 = 0
	local var2 = arg1.list[1].id
	for i1 = #arg1.list, 1, -1 do
		local var3 = arg1.list[i1]
		if var3.filler then
			var2 = var3.id
		else
			if not var1[var3.id] then
				continue
			end

			num1 = num1 + var1[var3.id]
			table.insert(tbl2, { id = var3.id, upTo = num1 })
		end
	end

	return { steps = tbl2, filler = var2 }
end

tbl1.pick = function(arg1, arg2)
	local var1 = arg2 and arg2:NextNumber() or math.random()
	for k1, v1 in ipairs(arg1.steps) do
		if var1 >= v1.upTo then
			continue
		end

		return v1.id
	end

	return arg1.filler
end

tbl1.roll = function(arg1, arg2, arg3, arg4)
	local var1 = tbl1.ladder(arg1, arg2, arg4)
	local var2 = arg3
	return tbl1.pick(var1, var2)
end

tbl1.chanceText = function(arg1)
	if not arg1 or arg1 <= 0 then
		return "-"
	end

	local var2 = 1 / arg1
	if var2 < 1.05 then
		return "1/1"
	end

	if var2 < 10 then
		return "1/" .. ("%.1f"):format(var2):gsub("%.0$", "")
	end

	local var3 = 10 ^ (math.floor((math.log10(var2))) - 2)
	return "1/" .. tbl1.oddsText(math.floor(var2 / var3 + 0.5) * var3)
end

return tbl1

--- ReplicatedStorage.Shared.TeleportConfig [ModuleScript]
-- y u r i

local tbl1 = { id = "riftGlyphs", button = "Floor126", floor = 126, door = "door36" }
local tbl3 = { LIST = {
	{ id = "bottom", button = "Bottom", spawn = true },
	{ id = "lavaGlyphs", button = "Floor1", floor = 1, door = "lavaGlyphs" },
	{ id = "mine", button = "Floor3", floor = 3, door = "mine" },
	{ id = "upgradeTree", button = "Floor5", floor = 5, door = "upgradeTree" },
	{ id = "waterGlyphs", button = "Floor8", floor = 8, door = "waterGlyphs" },
	{ id = "smeltry", button = "Floor10", floor = 10, door = "ironOre" },
	{ id = "poisonGlyphs", button = "Floor13", floor = 13, door = "poisonGlyphs" },
	{ id = "merchant", button = "Floor15", floor = 15, door = "potions" },
	{ id = "keepers", button = "Floor20", floor = 20, door = "keepers" },
	{ id = "windGlyphs", button = "Floor23", floor = 23, door = "windGlyphs" },
	{ id = "crystalMine", button = "Floor28", floor = 28, door = "crystals" },
	{ id = "electricGlyphs", button = "Floor29", floor = 29, door = "electricGlyphs" },
	{ id = "trailMerchant", button = "Floor33", floor = 33, door = "trails2" },
	{ id = "keepers2", button = "Floor40", floor = 40, door = "door13" },
	{ id = "crimsonGlyphs", button = "Floor44", floor = 44, door = "door14" },
	{ id = "prizeWheel", button = "Floor46", floor = 46, door = "door15" },
	{ id = "upgradeTree2", button = "Floor50", floor = 50, door = "door16" },
	{ id = "earthGlyphs", button = "Floor54", floor = 54, door = "door17" },
	{ id = "merchant2", button = "Floor58", floor = 58, door = "door18" },
	{ id = "keepers3", button = "Floor64", floor = 64, door = "door21" },
	{ id = "frostGlyphs", button = "Floor66", floor = 66, door = "door19" },
	{ id = "lumberYard", button = "Floor70", floor = 70, door = "door23" },
	{ id = "keepers4", button = "Floor72", floor = 72, door = "door22" },
	{ id = "cosmicGlyphs", button = "Floor76", floor = 76, door = "door20" },
	{ id = "keepers5", button = "Floor84", floor = 84, door = "door26" },
	{ id = "sakuraGlyphs", button = "Floor86", floor = 86, door = "door24" },
	{ id = "trailMerchant3", button = "Floor90", floor = 90, door = "door28" },
	{ id = "radiantGlyphs", button = "Floor96", floor = 96, door = "door25" },
	{ id = "keepers7", button = "Floor104", floor = 104, door = "door31" },
	{ id = "astralGlyphs", button = "Floor106", floor = 106, door = "door29" },
	{ id = "essenceField", button = "Floor108", floor = 108, door = "door34" },
	{ id = "upgradeTree3", button = "Floor110", floor = 110, door = "door33" },
	{ id = "merchant3", button = "Floor113", floor = 113, door = "door32" },
	{ id = "nebulaGlyphs", button = "Floor116", floor = 116, door = "door30" },
	{ id = "keepers8", button = "Floor124", floor = 124, door = "door35" },
	tbl1,
	{ id = "trailMerchant4", button = "Floor128", floor = 128, door = "door37" },
	{ id = "upgradeTree4", button = "Floor130", floor = 130, door = "door38" },
	{ id = "totemShrine", button = "Floor133", floor = 133, door = "door39" },
	{ id = "voidGlyphs", button = "Floor136", floor = 136, door = "door40" },
	{ id = "keepers9", button = "Floor144", floor = 144, door = "door41" },
	{ id = "forgeGlyphs", button = "Floor146", floor = 146, door = "door42" },
	{ id = "trailMerchant5", button = "Floor148", floor = 148, door = "door43" },
	{ id = "upgradeTree5", button = "Floor150", floor = 150, door = "door44" },
	{ id = "starforge", button = "Floor153", floor = 153, door = "door45" },
	{ id = "starfireGlyphs", button = "Floor156", floor = 156, door = "door46" },
} }

if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	local tbl4 = {
		"keepers7",
		"astralGlyphs",
		"nebulaGlyphs",
		"merchant3",
		"upgradeTree3",
		"essenceField",
	}

	for i1 = #tbl3.LIST, 1, -1 do
		tbl1 = table.find(tbl4, tbl3.LIST[i1].id)
		if not tbl1 then
			continue
		end

		table.remove(tbl3.LIST, i1)
	end
end

tbl3.BY_ID = {}
for k1, v1 in ipairs(tbl3.LIST) do
	tbl3.BY_ID[v1.id] = v1
end

tbl3.landing = function(arg1, arg2)
	local num1 = 0
	for i1 = 1, #arg2 do
		local var1 = arg2[i1]
		if not var1 then
			continue
		end

		if var1.Name ~= "EndStair" then
			continue
		end

		num1 = num1 + 1
		if num1 ~= arg1 then
			continue
		end

		return var1, i1
	end

	return nil, nil
end

tbl3.spawnPad = function()
	local var1 = workspace:FindFirstChild("Map")
	return var1 and var1:FindFirstChildWhichIsA("SpawnLocation") or workspace:FindFirstChildWhichIsA("SpawnLocation", true)
end

return tbl3

--- ReplicatedStorage.Shared.TreeConfig [ModuleScript]
-- y u r i

local tbl1 = { title = "Gold Multi", color = Color3.fromRGB(255, 205, 70), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%.1fX More Gold"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

local tbl2 = { gold = tbl1 }
tbl1 = { title = "Silver Multi", color = Color3.fromRGB(205, 212, 226), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%.1fX More Silver"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.silver = tbl1
tbl1 = { title = "Luck Multi", color = Color3.fromRGB(150, 235, 90), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%.1fX More Luck"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.luck = tbl1
tbl1 = { title = "Movement Speed", color = Color3.fromRGB(120, 215, 255), base = 0 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("+%d Speed"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 + arg2
end

tbl2.speed = tbl1
tbl1 = { title = "Bulk Smelt", color = Color3.fromRGB(215, 175, 128), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx Bulk Smelt"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.ironCapacity = tbl1
tbl1 = { title = "Ingot Multi", color = Color3.fromRGB(205, 165, 118), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx More Ingots"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.iron = tbl1
tbl1 = { title = "Glyph Bulk", color = Color3.fromRGB(255, 170, 70), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx Glyph Bulk"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.glyphBulk = tbl1
tbl1 = { title = "Crystal Multi", color = Color3.fromRGB(170, 165, 255), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx More Crystals"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.crystals = tbl1
tbl1 = { title = "Wood Multi", color = Color3.fromRGB(214, 160, 104), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx More Wood"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.wood = tbl1
tbl1 = { title = "Essence Multi", color = Color3.fromRGB(215, 150, 255), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx More Essence"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.essence = tbl1
tbl1 = { title = "Essence Vacuum", color = Color3.fromRGB(215, 150, 255), base = 0 }
tbl1.describe = function()
	return "Collects Essence For You"
end

tbl1.apply = function(arg1, arg2)
	return (math.max(arg1, arg2))
end

tbl2.vacuum = tbl1
tbl1 = { title = "Totem Boost", color = Color3.fromRGB(96, 214, 200), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("Totems Work %gx Harder"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.totemBoost = tbl1
tbl1 = { title = "Starforge Auto Deposit", color = Color3.fromRGB(255, 160, 80), base = 0 }
tbl1.describe = function()
	return "Deposits Iron Into The Starforge For You"
end

tbl1.apply = function(arg1, arg2)
	return (math.max(arg1, arg2))
end

tbl2.starforgeAuto = tbl1
tbl1 = { title = "Forge Capacity", color = Color3.fromRGB(255, 150, 90), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx Forge Capacity"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.starforgeCapacity = tbl1
tbl1 = { title = "Starmetal Multi", color = Color3.fromRGB(255, 176, 96), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx More Starmetal"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.starmetal = tbl1
tbl1 = { title = "Mining Speed", color = Color3.fromRGB(255, 140, 110), base = 1 }
tbl1.describe = function(arg1)
	local var1 = arg1
	return ("%gx Mining Speed"):format(var1)
end

tbl1.apply = function(arg1, arg2)
	return arg1 * arg2
end

tbl2.mining = tbl1
local tbl3 = { CURRENCY = "silver", DOOR = "upgradeTree", EFFECTS = tbl2 }
tbl3.TIER_COST = { 100, 250, 600, 1500, 4000, 10000, 25000, 60000, 150000, 400000 }
local tbl4 = { name = "UpgTreeWall4", floor = 30 }
tbl3.WALLS = {
	{ name = "UpgTreeWall1", floor = 10 },
	{ name = "UpgTreeWall2", floor = 15 },
	{ name = "UpgTreeWall3", floor = 25 },
	tbl4,
	{ name = "UpgTreeWall10", floor = 60 },
	{ name = "UpgTreeWall9", floor = 65 },
	{ name = "UpgTreeWall8", floor = 75 },
	{ name = "UpgTreeWall7", floor = 90 },
	{ name = "UpgTreeWall11", floor = 118 },
	{ name = "UpgTreeWall12", rebirths = 6 },
	{ name = "UpgTreeWall13", floor = 138 },
	{ name = "UpgTreeWall14", rebirths = 7 },
	{ name = "UpgTreeWall15", floor = 158 },
	{ name = "UpgTreeWall16", rebirths = 8 },
}

tbl3.WALL = tbl3.WALLS[1]
tbl3.WALL_CURRENCY = "ingots"
tbl2 = {}
tbl2[6] = 6
tbl2[7] = 15
tbl2[8] = 38
tbl2[9] = 100
tbl2[10] = 250
tbl2[11] = 500
tbl2[12] = 1000
tbl2[13] = 2000
tbl2[14] = 4000
tbl2[15] = 8000
tbl2[16] = 20000
tbl2[17] = 40000
tbl2[18] = 80000
tbl2[19] = 160000
tbl2[20] = 320000
tbl2[21] = 640000
tbl2[22] = 1250000
tbl2[23] = 2500000
tbl2[24] = 5000000
tbl2[25] = 10000000
tbl3.WALL_TIER_COST = tbl2
tbl3.CRYSTAL_FLOOR = 30
tbl3.CRYSTAL_CURRENCY = "crystals"
tbl2 = {}
tbl2[21] = 1500
tbl2[22] = 3000
tbl2[23] = 6000
tbl2[24] = 12000
tbl2[25] = 24000
tbl2[31] = 200000
tbl2[32] = 300000
tbl2[33] = 400000
tbl2[34] = 600000
tbl2[35] = 800000
tbl2[36] = 1200000
tbl2[37] = 1600000
tbl2[38] = 2200000
tbl2[39] = 3000000
tbl2[40] = 4000000
tbl3.CRYSTAL_TIER_COST = tbl2
tbl2 = {}
tbl2[41] = 200000000000000
tbl2[42] = 400000000000000
tbl2[43] = 800000000000000
tbl2[44] = 1600000000000000
tbl2[45] = 3200000000000000
tbl3.SILVER_TIER_COST = tbl2
tbl2 = {}
tbl2[46] = 5000
tbl2[47] = 10000
tbl2[48] = 20000
tbl2[49] = 40000
tbl2[50] = 80000
tbl2[51] = 160000
tbl2[52] = 320000
tbl2[53] = 640000
tbl2[54] = 1800000
tbl2[55] = 3600000
tbl3.WOOD_TIER_COST = tbl2
tbl3.P3_DOOR = "door33"
tbl3.P3_CURRENCY = "essence"
tbl2 = {}
tbl2[60] = 100
tbl2[61] = 200
tbl2[62] = 400
tbl2[63] = 800
tbl2[64] = 1600
tbl2[65] = 3200
tbl2[66] = 60000
tbl2[67] = 150000
tbl2[68] = 375000
tbl2[69] = 950000
tbl2[70] = 2400000
tbl3.P3_TIER_COST = tbl2
tbl2 = {}
tbl2[60] = { currency = "silver", amount = 2000000000 }
tbl2[61] = { currency = "silver", amount = 3600000000 }
tbl2[62] = { currency = "silver", amount = 6500000000 }
tbl2[63] = { currency = "silver", amount = 12000000000 }
tbl2[64] = { currency = "silver", amount = 21000000000 }
tbl2[65] = { currency = "silver", amount = 38000000000 }
tbl2[66] = { currency = "ingots", amount = 50000 }
tbl2[67] = { currency = "ingots", amount = 80000 }
tbl2[68] = { currency = "ingots", amount = 120000 }
tbl2[69] = { currency = "ingots", amount = 200000 }
tbl2[70] = { currency = "ingots", amount = 300000 }
tbl3.P3_EXTRA = tbl2
tbl3.P3_TIER_COST[71] = 10000000
tbl3.P3_EXTRA[71] = { currency = "ingots", amount = 400000 }
tbl1 = {}
tbl1[72] = 2000000
tbl1[73] = 3000000
tbl1[74] = 4000000
tbl1[75] = 5500000
tbl1[76] = 7500000
tbl1[77] = 10000000
tbl1[78] = 12000000
tbl1[79] = 16000000
tbl1[80] = 21000000
tbl1[81] = 28000000
tbl1[82] = 36000000
local num1 = 60000000
tbl1[83] = num1
for k1, v1 in pairs(tbl1) do
	tbl3.P3_TIER_COST[k1] = v1
end

tbl1 = {}
tbl1[72] = { "ingots", 300000 }
tbl1[73] = { "ingots", 450000 }
tbl1[74] = { "ingots", 650000 }
tbl1[75] = { "ingots", 900000 }
tbl1[76] = { "ingots", 1300000 }
tbl1[77] = { "ingots", 1800000 }
tbl1[78] = { "wood", 2000000 }
tbl1[79] = { "wood", 3000000 }
tbl1[80] = { "wood", 4500000 }
tbl1[81] = { "wood", 7000000 }
tbl1[82] = { "wood", 10000000 }
local str1 = "wood"
local tbl5 = { str1, 20000000 }
tbl1[83] = tbl5
for k2, v2 in pairs(tbl1) do
	tbl3.P3_EXTRA[k2] = { currency = v2[1], amount = v2[2] }
end

tbl3.P4_DOOR = "door38"
tbl3.CURRENCY_NAMES = {
	silver = "Silver",
	ingots = "Iron",
	crystals = "Crystals",
	wood = "Wood",
	essence = "Essence",
}

tbl2 = { ingots = Color3.fromRGB(205, 165, 118) }
tbl2.crystals = Color3.fromRGB(170, 165, 255)
tbl2.silver = Color3.fromRGB(205, 212, 226)
tbl2.wood = Color3.fromRGB(214, 160, 104)
tbl3.CURRENCY_COLORS = tbl2
tbl3.CURRENCY_COLORS.essence = Color3.fromRGB(215, 150, 255)
tbl3.CURRENCY_COLORS.starmetal = Color3.fromRGB(255, 176, 96)
tbl3.CURRENCY_NAMES[tbl3.P3_CURRENCY] = tbl3.CURRENCY_NAMES[tbl3.P3_CURRENCY] or "???"
tbl3.NODES = {
	{ id = "GoldMiddle1", effect = "gold", value = 1.5, tier = 1, lane = "root" },
	{
		id = "GoldLeft1",
		effect = "gold",
		value = 1.5,
		tier = 2,
		lane = "left",
		requires = "GoldMiddle1",
	},
	{
		id = "LuckLeft1",
		effect = "luck",
		value = 1.5,
		tier = 3,
		lane = "left",
		requires = "GoldLeft1",
	},
	{
		id = "SilverLeft1",
		effect = "silver",
		value = 1.5,
		tier = 4,
		lane = "left",
		requires = "LuckLeft1",
	},
	{
		id = "SpeedLeft1",
		effect = "speed",
		value = 1,
		tier = 5,
		lane = "left",
		requires = "SilverLeft1",
	},
	{
		id = "SilverMiddle1",
		effect = "silver",
		value = 1.5,
		tier = 2,
		lane = "middle",
		requires = "GoldMiddle1",
	},
	{
		id = "SpeedMiddle1",
		effect = "speed",
		value = 1,
		tier = 3,
		lane = "middle",
		requires = "SilverMiddle1",
	},
	{
		id = "GoldMiddle2",
		effect = "gold",
		value = 1.5,
		tier = 4,
		lane = "middle",
		requires = "SpeedMiddle1",
	},
	{
		id = "LuckMiddle1",
		effect = "luck",
		value = 1.5,
		tier = 5,
		lane = "middle",
		requires = "GoldMiddle2",
	},
	{
		id = "SpeedRight1",
		effect = "speed",
		value = 1,
		tier = 2,
		lane = "right",
		requires = "GoldMiddle1",
	},
	{
		id = "GoldRight1",
		effect = "gold",
		value = 1.5,
		tier = 3,
		lane = "right",
		requires = "SpeedRight1",
	},
	{
		id = "SilverRight1",
		effect = "silver",
		value = 1.5,
		tier = 4,
		lane = "right",
		requires = "GoldRight1",
	},
	{
		id = "SpeedRight2",
		effect = "speed",
		value = 1,
		tier = 5,
		lane = "right",
		requires = "SilverRight1",
	},
	{
		id = "SilverLeft2",
		effect = "silver",
		value = 1.5,
		tier = 6,
		lane = "left",
		requires = "SpeedLeft1",
		floor = 10,
	},
	{
		id = "SpeedLeft2",
		effect = "speed",
		value = 1,
		tier = 7,
		lane = "left",
		requires = "SilverLeft2",
		floor = 10,
	},
	{
		id = "IronCapacityLeft1",
		effect = "ironCapacity",
		value = 2,
		tier = 8,
		lane = "left",
		requires = "SpeedLeft2",
		floor = 10,
	},
	{
		id = "GoldLeft2",
		effect = "gold",
		value = 1.5,
		tier = 9,
		lane = "left",
		requires = "IronCapacityLeft1",
		floor = 10,
	},
	{
		id = "LuckLeft2",
		effect = "luck",
		value = 1.5,
		tier = 10,
		lane = "left",
		requires = "GoldLeft2",
		floor = 10,
	},
	{
		id = "LuckMiddle2",
		effect = "luck",
		value = 1.5,
		tier = 6,
		lane = "middle",
		requires = "LuckMiddle1",
		floor = 10,
	},
	{
		id = "IronCapacityMiddle1",
		effect = "ironCapacity",
		value = 2,
		tier = 7,
		lane = "middle",
		requires = "LuckMiddle2",
		floor = 10,
	},
	{
		id = "GoldMiddle3",
		effect = "gold",
		value = 1.5,
		tier = 8,
		lane = "middle",
		requires = "IronCapacityMiddle1",
		floor = 10,
	},
	{
		id = "IronMultiMiddle1",
		effect = "iron",
		value = 2,
		tier = 9,
		lane = "middle",
		requires = "GoldMiddle3",
		floor = 10,
	},
	{
		id = "SpeedMiddle2",
		effect = "speed",
		value = 1,
		tier = 10,
		lane = "middle",
		requires = "IronMultiMiddle1",
		floor = 10,
	},
	{
		id = "SpeedRight3",
		effect = "speed",
		value = 1,
		tier = 6,
		lane = "right",
		requires = "SpeedRight2",
		floor = 10,
	},
	{
		id = "IronMultiRight1",
		effect = "iron",
		value = 2,
		tier = 7,
		lane = "right",
		requires = "SpeedRight3",
		floor = 10,
	},
	{
		id = "GoldRight2",
		effect = "gold",
		value = 1.5,
		tier = 8,
		lane = "right",
		requires = "IronMultiRight1",
		floor = 10,
	},
	{
		id = "SilverRight2",
		effect = "silver",
		value = 1.5,
		tier = 9,
		lane = "right",
		requires = "GoldRight2",
		floor = 10,
	},
	{
		id = "LuckRight1",
		effect = "luck",
		value = 1.5,
		tier = 10,
		lane = "right",
		requires = "SilverRight2",
		floor = 10,
	},
	{
		id = "IronMultiLeft1",
		effect = "iron",
		value = 2,
		tier = 11,
		lane = "left",
		requires = "LuckLeft2",
		floor = 15,
	},
	{
		id = "SpeedLeft3",
		effect = "speed",
		value = 1,
		tier = 12,
		lane = "left",
		requires = "IronMultiLeft1",
		floor = 15,
	},
	{
		id = "GoldLeft3",
		effect = "gold",
		value = 1.5,
		tier = 13,
		lane = "left",
		requires = "SpeedLeft3",
		floor = 15,
	},
	{
		id = "IronCapacityLeft2",
		effect = "ironCapacity",
		value = 2,
		tier = 14,
		lane = "left",
		requires = "GoldLeft3",
		floor = 15,
	},
	{
		id = "LuckLeft3",
		effect = "luck",
		value = 1.5,
		tier = 15,
		lane = "left",
		requires = "IronCapacityLeft2",
		floor = 15,
	},
	{
		id = "IronMultiMiddle2",
		effect = "iron",
		value = 2,
		tier = 11,
		lane = "middle",
		requires = "SpeedMiddle2",
		floor = 15,
	},
	{
		id = "IronCapacityMiddle2",
		effect = "ironCapacity",
		value = 2,
		tier = 12,
		lane = "middle",
		requires = "IronMultiMiddle2",
		floor = 15,
	},
	{
		id = "LuckMiddle3",
		effect = "luck",
		value = 1.5,
		tier = 13,
		lane = "middle",
		requires = "IronCapacityMiddle2",
		floor = 15,
	},
	{
		id = "SilverMiddle2",
		effect = "silver",
		value = 1.5,
		tier = 14,
		lane = "middle",
		requires = "LuckMiddle3",
		floor = 15,
	},
	{
		id = "GoldMiddle4",
		effect = "gold",
		value = 1.5,
		tier = 15,
		lane = "middle",
		requires = "SilverMiddle2",
		floor = 15,
	},
	{
		id = "LuckRight2",
		effect = "luck",
		value = 1.5,
		tier = 11,
		lane = "right",
		requires = "LuckRight1",
		floor = 15,
	},
	{
		id = "SilverRight3",
		effect = "silver",
		value = 1.5,
		tier = 12,
		lane = "right",
		requires = "LuckRight2",
		floor = 15,
	},
	{
		id = "GoldRight3",
		effect = "gold",
		value = 1.5,
		tier = 13,
		lane = "right",
		requires = "SilverRight3",
		floor = 15,
	},
	{
		id = "IronMultiRight2",
		effect = "iron",
		value = 2,
		tier = 14,
		lane = "right",
		requires = "GoldRight3",
		floor = 15,
	},
	{
		id = "IronCapacityRight1",
		effect = "ironCapacity",
		value = 2,
		tier = 15,
		lane = "right",
		requires = "IronMultiRight2",
		floor = 15,
	},
	{
		id = "IronMultiLeft2",
		effect = "iron",
		value = 2,
		tier = 16,
		lane = "left",
		requires = "LuckLeft3",
		floor = 25,
	},
	{
		id = "GoldLeft4",
		effect = "gold",
		value = 1.5,
		tier = 17,
		lane = "left",
		requires = "IronMultiLeft2",
		floor = 25,
	},
	{
		id = "GlyphBulkLeft1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 18,
		lane = "left",
		requires = "GoldLeft4",
		floor = 25,
	},
	{
		id = "SilverLeft3",
		effect = "silver",
		value = 1.5,
		tier = 19,
		lane = "left",
		requires = "GlyphBulkLeft1",
		floor = 25,
	},
	{
		id = "MiningSpeedLeft1",
		effect = "mining",
		value = 1.25,
		tier = 20,
		lane = "left",
		requires = "SilverLeft3",
		floor = 25,
	},
	{
		id = "LuckMiddle4",
		effect = "luck",
		value = 1.5,
		tier = 16,
		lane = "middle",
		requires = "GoldMiddle4",
		floor = 25,
	},
	{
		id = "IronMultiMiddle3",
		effect = "iron",
		value = 2,
		tier = 17,
		lane = "middle",
		requires = "LuckMiddle4",
		floor = 25,
	},
	{
		id = "SpeedMiddle3",
		effect = "speed",
		value = 1,
		tier = 18,
		lane = "middle",
		requires = "IronMultiMiddle3",
		floor = 25,
	},
	{
		id = "GoldMiddle5",
		effect = "gold",
		value = 1.5,
		tier = 19,
		lane = "middle",
		requires = "SpeedMiddle3",
		floor = 25,
	},
	{
		id = "IronCapacityMiddle3",
		effect = "ironCapacity",
		value = 2,
		tier = 20,
		lane = "middle",
		requires = "GoldMiddle5",
		floor = 25,
	},
	{
		id = "GoldRight4",
		effect = "gold",
		value = 1.5,
		tier = 16,
		lane = "right",
		requires = "IronCapacityRight1",
		floor = 25,
	},
	{
		id = "MiningSpeedRight1",
		effect = "mining",
		value = 1.25,
		tier = 17,
		lane = "right",
		requires = "GoldRight4",
		floor = 25,
	},
	{
		id = "IronMultiRight3",
		effect = "iron",
		value = 2,
		tier = 18,
		lane = "right",
		requires = "MiningSpeedRight1",
		floor = 25,
	},
	{
		id = "LuckRight3",
		effect = "luck",
		value = 1.5,
		tier = 19,
		lane = "right",
		requires = "IronMultiRight3",
		floor = 25,
	},
	{
		id = "SilverRight4",
		effect = "silver",
		value = 1.5,
		tier = 20,
		lane = "right",
		requires = "LuckRight3",
		floor = 25,
	},
	{
		id = "IronCapacityLeft3",
		effect = "ironCapacity",
		value = 2,
		tier = 21,
		lane = "left",
		requires = "MiningSpeedLeft1",
		floor = 30,
	},
	{
		id = "CrystalMultiLeft1",
		effect = "crystals",
		value = 2,
		tier = 22,
		lane = "left",
		requires = "IronCapacityLeft3",
		floor = 30,
	},
	{
		id = "IronMultiLeft3",
		effect = "iron",
		value = 2,
		tier = 23,
		lane = "left",
		requires = "CrystalMultiLeft1",
		floor = 30,
	},
	{
		id = "GoldLeft5",
		effect = "gold",
		value = 1.5,
		tier = 24,
		lane = "left",
		requires = "IronMultiLeft3",
		floor = 30,
	},
	{
		id = "CrystalMultiLeft2",
		effect = "crystals",
		value = 2,
		tier = 25,
		lane = "left",
		requires = "GoldLeft5",
		floor = 30,
	},
	{
		id = "MiningSpeedMiddle1",
		effect = "mining",
		value = 1.25,
		tier = 21,
		lane = "middle",
		requires = "IronCapacityMiddle3",
		floor = 30,
	},
	{
		id = "SilverMiddle3",
		effect = "silver",
		value = 1.5,
		tier = 22,
		lane = "middle",
		requires = "MiningSpeedMiddle1",
		floor = 30,
	},
	{
		id = "GlyphBulkMiddle1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 23,
		lane = "middle",
		requires = "SilverMiddle3",
		floor = 30,
	},
	{
		id = "IronMultiMiddle4",
		effect = "iron",
		value = 2,
		tier = 24,
		lane = "middle",
		requires = "GlyphBulkMiddle1",
		floor = 30,
	},
	{
		id = "GoldMiddle6",
		effect = "gold",
		value = 1.5,
		tier = 25,
		lane = "middle",
		requires = "IronMultiMiddle4",
		floor = 30,
	},
	{
		id = "CrystalMultiRight1",
		effect = "crystals",
		value = 2,
		tier = 21,
		lane = "right",
		requires = "SilverRight4",
		floor = 30,
	},
	{
		id = "GoldRight5",
		effect = "gold",
		value = 1.5,
		tier = 22,
		lane = "right",
		requires = "CrystalMultiRight1",
		floor = 30,
	},
	{
		id = "SilverRight5",
		effect = "silver",
		value = 1.5,
		tier = 23,
		lane = "right",
		requires = "GoldRight5",
		floor = 30,
	},
	{
		id = "IronMultiRight4",
		effect = "iron",
		value = 2,
		tier = 24,
		lane = "right",
		requires = "SilverRight5",
		floor = 30,
	},
	{
		id = "CrystalMultiRight2",
		effect = "crystals",
		value = 2,
		tier = 25,
		lane = "right",
		requires = "IronMultiRight4",
		floor = 30,
	},
	{
		id = "P2GoldRoot",
		effect = "gold",
		value = 2,
		tier = 31,
		lane = "root",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2CrystalLeft1",
		effect = "crystals",
		value = 2,
		tier = 32,
		lane = "left",
		requires = "P2GoldRoot",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2GoldLeft1",
		effect = "gold",
		value = 2,
		tier = 33,
		lane = "left",
		requires = "P2CrystalLeft1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2LuckLeft1",
		effect = "luck",
		value = 1.5,
		tier = 34,
		lane = "left",
		requires = "P2GoldLeft1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2IngotLeft1",
		effect = "iron",
		value = 2,
		tier = 35,
		lane = "left",
		requires = "P2LuckLeft1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2SilverMiddle1",
		effect = "silver",
		value = 2,
		tier = 32,
		lane = "middle",
		requires = "P2GoldRoot",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2GoldMiddle1",
		effect = "gold",
		value = 2,
		tier = 33,
		lane = "middle",
		requires = "P2SilverMiddle1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2CrystalMiddle1",
		effect = "crystals",
		value = 2,
		tier = 34,
		lane = "middle",
		requires = "P2GoldMiddle1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2GlyphBulkMiddle1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 35,
		lane = "middle",
		requires = "P2CrystalMiddle1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2GoldRight1",
		effect = "gold",
		value = 2,
		tier = 32,
		lane = "right",
		requires = "P2GoldRoot",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2MiningRight1",
		effect = "mining",
		value = 1.25,
		tier = 33,
		lane = "right",
		requires = "P2GoldRight1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2SilverRight1",
		effect = "silver",
		value = 2,
		tier = 34,
		lane = "right",
		requires = "P2MiningRight1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2BulkSmeltRight1",
		effect = "ironCapacity",
		value = 2,
		tier = 35,
		lane = "right",
		requires = "P2SilverRight1",
		floor = 50,
		door = "door16",
	},
	{
		id = "P2GoldLeft2",
		effect = "gold",
		value = 2,
		tier = 36,
		lane = "left",
		requires = "P2IngotLeft1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2CrystalLeft2",
		effect = "crystals",
		value = 2,
		tier = 37,
		lane = "left",
		requires = "P2GoldLeft2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2SilverLeft1",
		effect = "silver",
		value = 2,
		tier = 38,
		lane = "left",
		requires = "P2CrystalLeft2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2IngotLeft2",
		effect = "iron",
		value = 2,
		tier = 39,
		lane = "left",
		requires = "P2SilverLeft1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GoldLeft3",
		effect = "gold",
		value = 2,
		tier = 40,
		lane = "left",
		requires = "P2IngotLeft2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2LuckMiddle1",
		effect = "luck",
		value = 1.5,
		tier = 36,
		lane = "middle",
		requires = "P2GlyphBulkMiddle1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GoldMiddle2",
		effect = "gold",
		value = 2,
		tier = 37,
		lane = "middle",
		requires = "P2LuckMiddle1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2SpeedMiddle1",
		effect = "speed",
		value = 1,
		tier = 38,
		lane = "middle",
		requires = "P2GoldMiddle2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2CrystalMiddle2",
		effect = "crystals",
		value = 2,
		tier = 39,
		lane = "middle",
		requires = "P2SpeedMiddle1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GoldMiddle3",
		effect = "gold",
		value = 2,
		tier = 40,
		lane = "middle",
		requires = "P2CrystalMiddle2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2IngotRight1",
		effect = "iron",
		value = 2,
		tier = 36,
		lane = "right",
		requires = "P2BulkSmeltRight1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GoldRight2",
		effect = "gold",
		value = 2,
		tier = 37,
		lane = "right",
		requires = "P2IngotRight1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GlyphBulkRight1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 38,
		lane = "right",
		requires = "P2GoldRight2",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2LuckRight1",
		effect = "luck",
		value = 1.5,
		tier = 39,
		lane = "right",
		requires = "P2GlyphBulkRight1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2GoldRight3",
		effect = "gold",
		value = 2,
		tier = 40,
		lane = "right",
		requires = "P2LuckRight1",
		floor = 60,
		door = "door16",
	},
	{
		id = "P2CrystalLeft3",
		effect = "crystals",
		value = 1.5,
		tier = 41,
		lane = "left",
		requires = "P2GoldLeft3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2IngotLeft3",
		effect = "iron",
		value = 2,
		tier = 42,
		lane = "left",
		requires = "P2CrystalLeft3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldLeft4",
		effect = "gold",
		value = 2,
		tier = 43,
		lane = "left",
		requires = "P2IngotLeft3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GlyphBulkLeft1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 44,
		lane = "left",
		requires = "P2GoldLeft4",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2SilverLeft2",
		effect = "silver",
		value = 2,
		tier = 45,
		lane = "left",
		requires = "P2GlyphBulkLeft1",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2SilverMiddle2",
		effect = "silver",
		value = 2,
		tier = 41,
		lane = "middle",
		requires = "P2GoldMiddle3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldMiddle4",
		effect = "gold",
		value = 2,
		tier = 42,
		lane = "middle",
		requires = "P2SilverMiddle2",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2CrystalMiddle3",
		effect = "crystals",
		value = 1.5,
		tier = 43,
		lane = "middle",
		requires = "P2GoldMiddle4",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2LuckMiddle2",
		effect = "luck",
		value = 1.5,
		tier = 44,
		lane = "middle",
		requires = "P2CrystalMiddle3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldMiddle5",
		effect = "gold",
		value = 2,
		tier = 45,
		lane = "middle",
		requires = "P2LuckMiddle2",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2IngotRight2",
		effect = "iron",
		value = 2,
		tier = 41,
		lane = "right",
		requires = "P2GoldRight3",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldRight4",
		effect = "gold",
		value = 2,
		tier = 42,
		lane = "right",
		requires = "P2IngotRight2",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2SpeedRight1",
		effect = "speed",
		value = 1,
		tier = 43,
		lane = "right",
		requires = "P2GoldRight4",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2CrystalRight1",
		effect = "crystals",
		value = 1.5,
		tier = 44,
		lane = "right",
		requires = "P2SpeedRight1",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldRight5",
		effect = "gold",
		value = 2,
		tier = 45,
		lane = "right",
		requires = "P2CrystalRight1",
		floor = 65,
		door = "door16",
		currency = "silver",
	},
	{
		id = "P2GoldLeft5",
		effect = "gold",
		value = 2,
		tier = 46,
		lane = "left",
		requires = "P2SilverLeft2",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2CrystalLeft4",
		effect = "crystals",
		value = 1.5,
		tier = 47,
		lane = "left",
		requires = "P2GoldLeft5",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2SilverLeft3",
		effect = "silver",
		value = 2,
		tier = 48,
		lane = "left",
		requires = "P2CrystalLeft4",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodLeft1",
		effect = "wood",
		value = 2,
		tier = 49,
		lane = "left",
		requires = "P2SilverLeft3",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldLeft6",
		effect = "gold",
		value = 2,
		tier = 50,
		lane = "left",
		requires = "P2WoodLeft1",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GlyphBulkMiddle2",
		effect = "glyphBulk",
		value = 1.5,
		tier = 46,
		lane = "middle",
		requires = "P2GoldMiddle5",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2CrystalMiddle4",
		effect = "crystals",
		value = 1.5,
		tier = 47,
		lane = "middle",
		requires = "P2GlyphBulkMiddle2",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldMiddle6",
		effect = "gold",
		value = 2,
		tier = 48,
		lane = "middle",
		requires = "P2CrystalMiddle4",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodMiddle1",
		effect = "wood",
		value = 2,
		tier = 49,
		lane = "middle",
		requires = "P2GoldMiddle6",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldMiddle7",
		effect = "gold",
		value = 2,
		tier = 50,
		lane = "middle",
		requires = "P2WoodMiddle1",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2SilverRight2",
		effect = "silver",
		value = 2,
		tier = 46,
		lane = "right",
		requires = "P2GoldRight5",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldRight6",
		effect = "gold",
		value = 2,
		tier = 47,
		lane = "right",
		requires = "P2SilverRight2",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2LuckRight2",
		effect = "luck",
		value = 1.5,
		tier = 48,
		lane = "right",
		requires = "P2GoldRight6",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2CrystalRight2",
		effect = "crystals",
		value = 1.5,
		tier = 49,
		lane = "right",
		requires = "P2LuckRight2",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldRight7",
		effect = "gold",
		value = 2,
		tier = 50,
		lane = "right",
		requires = "P2CrystalRight2",
		floor = 75,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodLeft2",
		effect = "wood",
		value = 2,
		tier = 51,
		lane = "left",
		requires = "P2GoldLeft6",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GlyphBulkLeft2",
		effect = "glyphBulk",
		value = 1.5,
		tier = 52,
		lane = "left",
		requires = "P2WoodLeft2",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldLeft7",
		effect = "gold",
		value = 2,
		tier = 53,
		lane = "left",
		requires = "P2GlyphBulkLeft2",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2LuckLeft2",
		effect = "luck",
		value = 1.5,
		tier = 54,
		lane = "left",
		requires = "P2GoldLeft7",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodLeft3",
		effect = "wood",
		value = 2,
		tier = 55,
		lane = "left",
		requires = "P2LuckLeft2",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2LuckMiddle3",
		effect = "luck",
		value = 1.5,
		tier = 51,
		lane = "middle",
		requires = "P2GoldMiddle7",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodMiddle2",
		effect = "wood",
		value = 2,
		tier = 52,
		lane = "middle",
		requires = "P2LuckMiddle3",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2CrystalMiddle5",
		effect = "wood",
		value = 2,
		tier = 53,
		lane = "middle",
		requires = "P2WoodMiddle2",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GlyphBulkMiddle3",
		effect = "glyphBulk",
		value = 1.5,
		tier = 54,
		lane = "middle",
		requires = "P2CrystalMiddle5",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldMiddle8",
		effect = "gold",
		value = 2,
		tier = 55,
		lane = "middle",
		requires = "P2GlyphBulkMiddle3",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GoldRight8",
		effect = "gold",
		value = 2,
		tier = 51,
		lane = "right",
		requires = "P2GoldRight7",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2GlyphBulkRight2",
		effect = "glyphBulk",
		value = 1.5,
		tier = 52,
		lane = "right",
		requires = "P2GoldRight8",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2WoodRight1",
		effect = "wood",
		value = 2,
		tier = 53,
		lane = "right",
		requires = "P2GlyphBulkRight2",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2LuckRight3",
		effect = "luck",
		value = 1.5,
		tier = 54,
		lane = "right",
		requires = "P2WoodRight1",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P2IngotRight3",
		effect = "iron",
		value = 2,
		tier = 55,
		lane = "right",
		requires = "P2LuckRight3",
		floor = 90,
		door = "door16",
		currency = "wood",
	},
	{
		id = "P3GoldRoot",
		effect = "gold",
		value = 2,
		tier = 60,
		lane = "root",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3WoodLeft1",
		effect = "wood",
		value = 2,
		tier = 61,
		lane = "left",
		requires = "P3GoldRoot",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldLeft1",
		effect = "gold",
		value = 2,
		tier = 62,
		lane = "left",
		requires = "P3WoodLeft1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceLeft1",
		effect = "essence",
		value = 1.5,
		tier = 63,
		lane = "left",
		requires = "P3GoldLeft1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GlyphBulkLeft1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 64,
		lane = "left",
		requires = "P3EssenceLeft1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3SilverLeft1",
		effect = "silver",
		value = 2,
		tier = 65,
		lane = "left",
		requires = "P3GlyphBulkLeft1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3LuckMiddle1",
		effect = "luck",
		value = 1.5,
		tier = 61,
		lane = "middle",
		requires = "P3GoldRoot",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3IngotMiddle1",
		effect = "iron",
		value = 2,
		tier = 62,
		lane = "middle",
		requires = "P3LuckMiddle1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceMiddle1",
		effect = "essence",
		value = 1.5,
		tier = 63,
		lane = "middle",
		requires = "P3IngotMiddle1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldMiddle1",
		effect = "gold",
		value = 2,
		tier = 64,
		lane = "middle",
		requires = "P3EssenceMiddle1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3WoodMiddle1",
		effect = "wood",
		value = 2,
		tier = 65,
		lane = "middle",
		requires = "P3GoldMiddle1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3SilverRight1",
		effect = "silver",
		value = 2,
		tier = 61,
		lane = "right",
		requires = "P3GoldRoot",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3WoodRight1",
		effect = "wood",
		value = 2,
		tier = 62,
		lane = "right",
		requires = "P3SilverRight1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceRight1",
		effect = "essence",
		value = 1.5,
		tier = 63,
		lane = "right",
		requires = "P3WoodRight1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3LuckRight1",
		effect = "luck",
		value = 1.5,
		tier = 64,
		lane = "right",
		requires = "P3EssenceRight1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldRight1",
		effect = "gold",
		value = 2,
		tier = 65,
		lane = "right",
		requires = "P3LuckRight1",
		floor = 110,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3IngotLeft1",
		effect = "iron",
		value = 2,
		tier = 66,
		lane = "left",
		requires = "P3SilverLeft1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3LuckLeft1",
		effect = "luck",
		value = 1.5,
		tier = 67,
		lane = "left",
		requires = "P3IngotLeft1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceLeft2",
		effect = "essence",
		value = 1.5,
		tier = 68,
		lane = "left",
		requires = "P3LuckLeft1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3WoodLeft2",
		effect = "wood",
		value = 2,
		tier = 69,
		lane = "left",
		requires = "P3EssenceLeft2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldLeft2",
		effect = "gold",
		value = 2,
		tier = 70,
		lane = "left",
		requires = "P3WoodLeft2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GlyphBulkMiddle1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 66,
		lane = "middle",
		requires = "P3WoodMiddle1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3SilverMiddle1",
		effect = "silver",
		value = 2,
		tier = 67,
		lane = "middle",
		requires = "P3GlyphBulkMiddle1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceMiddle2",
		effect = "essence",
		value = 1.5,
		tier = 68,
		lane = "middle",
		requires = "P3SilverMiddle1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldMiddle2",
		effect = "gold",
		value = 2,
		tier = 69,
		lane = "middle",
		requires = "P3EssenceMiddle2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3LuckMiddle2",
		effect = "luck",
		value = 1.5,
		tier = 70,
		lane = "middle",
		requires = "P3GoldMiddle2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GoldRight2",
		effect = "gold",
		value = 2,
		tier = 66,
		lane = "right",
		requires = "P3GoldRight1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3GlyphBulkRight1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 67,
		lane = "right",
		requires = "P3GoldRight2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceRight2",
		effect = "essence",
		value = 1.5,
		tier = 68,
		lane = "right",
		requires = "P3GlyphBulkRight1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3IngotRight1",
		effect = "iron",
		value = 2,
		tier = 69,
		lane = "right",
		requires = "P3EssenceRight2",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3WoodRight2",
		effect = "wood",
		value = 2,
		tier = 70,
		lane = "right",
		requires = "P3IngotRight1",
		floor = 118,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P3EssenceVacuum",
		effect = "vacuum",
		value = 1,
		tier = 71,
		lane = "middle",
		floor = 118,
		rebirths = 6,
		door = "door33",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldRoot",
		effect = "gold",
		value = 2,
		tier = 72,
		lane = "root",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4WoodLeft1",
		effect = "wood",
		value = 2,
		tier = 73,
		lane = "left",
		requires = "P4GoldRoot",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldLeft1",
		effect = "gold",
		value = 2,
		tier = 74,
		lane = "left",
		requires = "P4WoodLeft1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceLeft1",
		effect = "essence",
		value = 1.5,
		tier = 75,
		lane = "left",
		requires = "P4GoldLeft1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GlyphBulkLeft1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 76,
		lane = "left",
		requires = "P4EssenceLeft1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4SilverLeft1",
		effect = "silver",
		value = 2,
		tier = 77,
		lane = "left",
		requires = "P4GlyphBulkLeft1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4SpeedMiddle1",
		effect = "speed",
		value = 2,
		tier = 73,
		lane = "middle",
		requires = "P4GoldRoot",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4IngotMiddle1",
		effect = "iron",
		value = 2,
		tier = 74,
		lane = "middle",
		requires = "P4SpeedMiddle1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceMiddle1",
		effect = "essence",
		value = 1.5,
		tier = 75,
		lane = "middle",
		requires = "P4IngotMiddle1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldMiddle1",
		effect = "gold",
		value = 2,
		tier = 76,
		lane = "middle",
		requires = "P4EssenceMiddle1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4WoodMiddle1",
		effect = "wood",
		value = 2,
		tier = 77,
		lane = "middle",
		requires = "P4GoldMiddle1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4SilverRight1",
		effect = "silver",
		value = 2,
		tier = 73,
		lane = "right",
		requires = "P4GoldRoot",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4WoodRight1",
		effect = "wood",
		value = 2,
		tier = 74,
		lane = "right",
		requires = "P4SilverRight1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceRight1",
		effect = "essence",
		value = 1.5,
		tier = 75,
		lane = "right",
		requires = "P4WoodRight1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4LuckRight1",
		effect = "luck",
		value = 1.5,
		tier = 76,
		lane = "right",
		requires = "P4EssenceRight1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldRight1",
		effect = "gold",
		value = 2,
		tier = 77,
		lane = "right",
		requires = "P4LuckRight1",
		floor = 130,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4IngotLeft1",
		effect = "iron",
		value = 2,
		tier = 78,
		lane = "left",
		requires = "P4SilverLeft1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4LuckLeft1",
		effect = "luck",
		value = 1.5,
		tier = 79,
		lane = "left",
		requires = "P4IngotLeft1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceLeft2",
		effect = "essence",
		value = 1.5,
		tier = 80,
		lane = "left",
		requires = "P4LuckLeft1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4WoodLeft2",
		effect = "wood",
		value = 2,
		tier = 81,
		lane = "left",
		requires = "P4EssenceLeft2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldLeft2",
		effect = "gold",
		value = 2,
		tier = 82,
		lane = "left",
		requires = "P4WoodLeft2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GlyphBulkMiddle1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 78,
		lane = "middle",
		requires = "P4WoodMiddle1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4SilverMiddle1",
		effect = "silver",
		value = 2,
		tier = 79,
		lane = "middle",
		requires = "P4GlyphBulkMiddle1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceMiddle2",
		effect = "essence",
		value = 1.5,
		tier = 80,
		lane = "middle",
		requires = "P4SilverMiddle1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldMiddle2",
		effect = "gold",
		value = 2,
		tier = 81,
		lane = "middle",
		requires = "P4EssenceMiddle2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4LuckMiddle2",
		effect = "luck",
		value = 1.5,
		tier = 82,
		lane = "middle",
		requires = "P4GoldMiddle2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GoldRight2",
		effect = "gold",
		value = 2,
		tier = 78,
		lane = "right",
		requires = "P4GoldRight1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4GlyphBulkRight1",
		effect = "glyphBulk",
		value = 1.5,
		tier = 79,
		lane = "right",
		requires = "P4GoldRight2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4EssenceRight2",
		effect = "essence",
		value = 1.5,
		tier = 80,
		lane = "right",
		requires = "P4GlyphBulkRight1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4IngotRight1",
		effect = "iron",
		value = 2,
		tier = 81,
		lane = "right",
		requires = "P4EssenceRight2",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4WoodRight2",
		effect = "wood",
		value = 2,
		tier = 82,
		lane = "right",
		requires = "P4IngotRight1",
		floor = 138,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
	{
		id = "P4TotemBoost",
		effect = "totemBoost",
		value = 2,
		tier = 83,
		lane = "middle",
		floor = 138,
		rebirths = 7,
		door = "door38",
		currency = tbl3.P3_CURRENCY,
	},
}

tbl2 = require(game:GetService("ReplicatedStorage").Shared.NumberFormat)
tbl3.costText = function(arg1)
	local var2 = arg1.cost
	if var2 < 1000 then
		local var3 = tostring(var2)
		var3 = var3 or tbl2.suffix(var2):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
	end

	local var4 = tbl2.suffix(var2):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
	local var5 = var4 .. " " .. arg1.currencyName
	if arg1.extra then
		local var8 = arg1.extra.amount
		var4 = var5
		var2 = " + "
		if var8 < 1000 then
			local var9 = tostring(var8)
			var9 = var9 or tbl2.suffix(var8):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
		end

		local var10 = tbl2.suffix(var8):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
		local var11 = tbl3.CURRENCY_NAMES[arg1.extra.currency]
		var5 = var4 .. var2 .. var10 .. " " .. (var11 or arg1.extra.currency)
	end

	return var5
end

tbl3.canAfford = function(arg1, arg2)
	if (arg2[arg1.currency] or 0) < arg1.cost then
		return false
	end

	local var2 = not arg1.extra
	if not var2 then
		var2 = arg1.extra.amount <= (arg2[arg1.extra.currency] or 0)
	end

	return var2
end

tbl3.P5_DOOR = "door44"
tbl3.P5_CURRENCY = "starmetal"
tbl3.CURRENCY_NAMES.starmetal = "Starmetal"
local tbl6 = {}
tbl6[90] = 12500
tbl6[91] = 15500
tbl6[92] = 19000
tbl6[93] = 24000
tbl6[94] = 30000
tbl3.P5_TIER_COST = tbl6
local tbl7 = {}
tbl7[84] = { 300, "silver", 1e+20 }
tbl7[85] = { 600, "silver", 2e+20 }
tbl7[86] = { 1200, "silver", 4e+20 }
tbl7[87] = { 2500, "silver", 1e+21 }
tbl7[88] = { 5000, "silver", 2.5e+21 }
tbl7[89] = { 9000, "silver", 6e+21 }
local num2 = 250000
local tbl8 = { num2, "starmetal", 600000 }
tbl7[95] = tbl8
for k3, v3 in pairs(tbl7) do
	tbl3.P3_TIER_COST[k3] = v3[1]
	tbl3.P3_EXTRA[k3] = { currency = v3[2], amount = v3[3] }
end

tbl6 = tbl3.P3_CURRENCY
table.insert(tbl3.NODES, {
	id = "P5Root",
	effect = "silver",
	value = 2,
	tier = 84,
	lane = "root",
	requires = nil,
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5L1Mining",
	effect = "mining",
	value = 1.5,
	tier = 85,
	lane = "left",
	requires = "P5Root",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5L2Ingot",
	effect = "iron",
	value = 2,
	tier = 86,
	lane = "left",
	requires = "P5L1Mining",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5L3BulkSmelt",
	effect = "ironCapacity",
	value = 2,
	tier = 87,
	lane = "left",
	requires = "P5L2Ingot",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5L4ForgeCap",
	effect = "starforgeCapacity",
	value = 3,
	tier = 88,
	lane = "left",
	requires = "P5L3BulkSmelt",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5L5Ingot",
	effect = "iron",
	value = 2,
	tier = 89,
	lane = "left",
	requires = "P5L4ForgeCap",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5M1Speed",
	effect = "speed",
	value = 1,
	tier = 85,
	lane = "middle",
	requires = "P5Root",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5M2Luck",
	effect = "luck",
	value = 1.5,
	tier = 86,
	lane = "middle",
	requires = "P5M1Speed",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5M3Essence",
	effect = "essence",
	value = 1.5,
	tier = 87,
	lane = "middle",
	requires = "P5M2Luck",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5M4GlyphBulk",
	effect = "glyphBulk",
	value = 1.5,
	tier = 88,
	lane = "middle",
	requires = "P5M3Essence",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5M5Gold",
	effect = "gold",
	value = 2,
	tier = 89,
	lane = "middle",
	requires = "P5M4GlyphBulk",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5R1Gold",
	effect = "gold",
	value = 2,
	tier = 85,
	lane = "right",
	requires = "P5Root",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5R2Crystals",
	effect = "crystals",
	value = 2,
	tier = 86,
	lane = "right",
	requires = "P5R1Gold",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5R3Wood",
	effect = "wood",
	value = 2,
	tier = 87,
	lane = "right",
	requires = "P5R2Crystals",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5R4Essence",
	effect = "essence",
	value = 1.5,
	tier = 88,
	lane = "right",
	requires = "P5R3Wood",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

table.insert(tbl3.NODES, {
	id = "P5R5Silver",
	effect = "silver",
	value = 2,
	tier = 89,
	lane = "right",
	requires = "P5R4Essence",
	floor = 150,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

tbl7 = tbl3.P5_CURRENCY
table.insert(tbl3.NODES, {
	id = "P5L6Starmetal",
	effect = "starmetal",
	value = 1.5,
	tier = 90,
	lane = "left",
	requires = "P5L5Ingot",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5L7BulkSmelt",
	effect = "ironCapacity",
	value = 2,
	tier = 91,
	lane = "left",
	requires = "P5L6Starmetal",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5L8Ingot",
	effect = "iron",
	value = 2,
	tier = 92,
	lane = "left",
	requires = "P5L7BulkSmelt",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5L9Starmetal",
	effect = "starmetal",
	value = 1.5,
	tier = 93,
	lane = "left",
	requires = "P5L8Ingot",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5L10Gold",
	effect = "gold",
	value = 2,
	tier = 94,
	lane = "left",
	requires = "P5L9Starmetal",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5M6GlyphBulk",
	effect = "glyphBulk",
	value = 1.5,
	tier = 90,
	lane = "middle",
	requires = "P5M5Gold",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5M7Essence",
	effect = "essence",
	value = 1.5,
	tier = 91,
	lane = "middle",
	requires = "P5M6GlyphBulk",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5M8Starmetal",
	effect = "starmetal",
	value = 1.5,
	tier = 92,
	lane = "middle",
	requires = "P5M7Essence",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5M9Luck",
	effect = "luck",
	value = 1.5,
	tier = 93,
	lane = "middle",
	requires = "P5M8Starmetal",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5M10Silver",
	effect = "silver",
	value = 2,
	tier = 94,
	lane = "middle",
	requires = "P5M9Luck",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5R6Wood",
	effect = "wood",
	value = 2,
	tier = 90,
	lane = "right",
	requires = "P5R5Silver",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5R7Mining",
	effect = "mining",
	value = 1.5,
	tier = 91,
	lane = "right",
	requires = "P5R6Wood",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5R8Gold",
	effect = "gold",
	value = 2,
	tier = 92,
	lane = "right",
	requires = "P5R7Mining",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5R9Crystals",
	effect = "crystals",
	value = 2,
	tier = 93,
	lane = "right",
	requires = "P5R8Gold",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

table.insert(tbl3.NODES, {
	id = "P5R10Starmetal",
	effect = "starmetal",
	value = 1.5,
	tier = 94,
	lane = "right",
	requires = "P5R9Crystals",
	floor = 158,
	rebirths = nil,
	door = tbl3.P5_DOOR,
	currency = tbl7,
})

local var1 = tbl3.NODES
table.insert(var1, {
	id = "P5StarforgeAuto",
	effect = "starforgeAuto",
	value = 1,
	tier = 95,
	lane = "middle",
	requires = nil,
	floor = 158,
	rebirths = 8,
	door = tbl3.P5_DOOR,
	currency = tbl6,
})

local function node(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	table.insert(tbl3.NODES, {
		id = arg1,
		effect = arg2,
		value = arg3,
		tier = arg4,
		lane = arg5,
		requires = arg6,
		floor = arg7,
		rebirths = arg9,
		door = tbl3.P5_DOOR,
		currency = arg8,
	})
end

if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	for i1 = #tbl3.NODES, 1, -1 do
		if tbl3.NODES[i1].door ~= tbl3.P3_DOOR then
			continue
		end

		table.remove(tbl3.NODES, i1)
	end

	for i2 = #tbl3.WALLS, 1, -1 do
		if tbl3.WALLS[i2].name ~= "UpgTreeWall11" then
			var1 = tbl3.WALLS
			if var1[i2].name ~= "UpgTreeWall12" then
				continue
			end
		end

		var1 = tbl3.WALLS
		table.remove(var1, i2)
	end
end

tbl3.BY_ID = {}
for k4, v4 in ipairs(tbl3.NODES) do
	if v4.currency == tbl3.P5_CURRENCY then
		v4.cost = tbl3.P5_TIER_COST[v4.tier]
	else
		if v4.currency == tbl3.P3_CURRENCY then
			v4.cost = tbl3.P3_TIER_COST[v4.tier]
			local var2 = tbl3.P3_EXTRA[v4.tier]
			local var4 = var2
			if var4 then
				var4 = { currency = var2.currency, amount = var2.amount }
			end

			v4.extra = var4
		else
			if v4.currency == "wood" then
				v4.cost = tbl3.WOOD_TIER_COST[v4.tier]
			else
				if v4.currency == "silver" then
					v4.cost = tbl3.SILVER_TIER_COST[v4.tier]
				else
					if v4.floor and tbl3.CRYSTAL_FLOOR <= v4.floor then
						v4.currency = tbl3.CRYSTAL_CURRENCY
						local var5 = tbl3.CRYSTAL_TIER_COST[v4.tier]
						v4.cost = var5 or tbl3.CRYSTAL_TIER_COST[25]
					else
						if v4.floor then
							v4.currency = tbl3.WALL_CURRENCY
							local var6 = tbl3.WALL_TIER_COST[v4.tier]
							v4.cost = var6 or tbl3.WALL_TIER_COST[10]
						else
							v4.currency = tbl3.CURRENCY
							local var7 = tbl3.TIER_COST[v4.tier]
							v4.cost = var7 or tbl3.TIER_COST[#tbl3.TIER_COST]
						end
					end
				end
			end
		end
	end

	local var8 = tbl3.CURRENCY_NAMES[v4.currency]
	v4.currencyName = var8 or v4.currency
	tbl3.BY_ID[v4.id] = v4
end

tbl3.UNLOCKS = {}
for k5, v5 in ipairs(tbl3.NODES) do
	if not v5.requires then
		continue
	end

	local var9 = tbl3.UNLOCKS[v5.requires]
	var9 = var9 or {}
	table.insert(var9, v5.id)
	tbl3.UNLOCKS[v5.requires] = var9
end

tbl3.available = function(arg1, arg2, arg3, arg4)
	if arg1.floor and (arg3 or 0) < arg1.floor then
		return false
	end

	if arg1.rebirths and (arg4 or 0) < arg1.rebirths then
		return false
	end

	if not arg1.requires then
		return true
	end

	local var1 = arg2
	return (var1 or {})[arg1.requires] == true
end

tbl6 = {}
tbl6[10] = 2
tbl6[15] = 3
tbl6[25] = 4
tbl6[30] = 5
tbl7 = {}
tbl7[50] = "2:1"
tbl7[60] = "2:2"
tbl7[65] = "2:3"
tbl7[75] = "2:4"
tbl7[90] = "2:5"
local tbl9 = {}
tbl9[110] = "3:1"
tbl9[118] = "3:2"
local tbl10 = {}
tbl10[130] = "4:1"
tbl10[138] = "4:2"
local tbl11 = {}
tbl11[150] = "5:1"
tbl11[158] = "5:2"
tbl3.sectionOf = function(arg1)
	if not arg1 then
		return nil
	end

	if arg1.door == tbl3.P3_DOOR then
		return tbl9[arg1.floor]
	end

	if arg1.door == "door38" then
		return tbl10[arg1.floor]
	end

	if arg1.door == tbl3.P5_DOOR then
		return tbl11[arg1.floor]
	end

	if arg1.door then
		return tbl7[arg1.floor]
	end

	if arg1.floor == nil then
		return 1
	end

	return tbl6[arg1.floor]
end

tbl3.totals = function(arg1)
	local tbl1 = {}
	for k1, v1 in pairs(tbl3.EFFECTS) do
		tbl1[k1] = v1.base
	end

	for k2, v2 in ipairs(tbl3.NODES) do
		local var1 = arg1
		if (var1 or {})[v2.id] ~= true then
			continue
		end

		local var2 = tbl3.EFFECTS[v2.effect].apply(tbl1[v2.effect], v2.value)
		tbl1[v2.effect] = var2
	end

	return tbl1
end

return tbl3

--- ReplicatedStorage.Shared.PassConfig [ModuleScript]
-- y u r i

local str1 = "iron"
local tbl1 = {
	"gold",
	"silver",
	"luck",
	"bulk",
	str1,
	"mining",
	"crystals",
	"wood",
	"essence",
	"starmetal",
}

local tbl2 = {
	LIST = {
		{ id = "gold2x", productId = 3712710201, card = "2x Gold", gold = 2 },
		{ id = "silver2x", productId = 3712710225, card = "2x Silver", silver = 2 },
		{ id = "starter", productId = 3712710248, card = "Starter Pack!", gold = 2, silver = 2 },
		{ id = "luck2x", productId = 3712710276, card = "2x Glyph Luck", luck = 2 },
		{ id = "bulk2x", productId = 3712710296, card = "+5 Glyph Bulk", bulk = 6 },
		{ id = "iron2x", productId = 3712979864, card = "2x Iron", iron = 2 },
		{ id = "mining2x", productId = 3713001860, card = "2x Mining Speed", mining = 2 },
		{ id = "autoMineAnywhere", productId = 3713003872, card = "Auto Mine Anywhere" },
		{ id = "crystals2x", productId = 3713240871, card = "2x Crystals", crystals = 2 },
		{ id = "wood2x", productId = 3713962603, card = "2x Wood", wood = 2 },
		{ id = "essence2x", productId = 3714771225, card = "2x Essence", essence = 2 },
		{ id = "starmetal2x", productId = 3715519733, card = "2x Starmetal", starmetal = 2 },
		{ id = "vip", productId = 3712976014, card = "VIP BUNDLE", vip = true },
	},
	VIP = "vip",
	KINDS = tbl1,
}

tbl2.owns = function(arg1, arg2)
	local var1 = arg1
	arg1 = var1 or {}
	var1 = true
	if arg1[arg2] ~= true then
		var1 = arg1[tbl2.VIP] == true
	end

	return var1
end

tbl2.BY_ID = {}
tbl2.BY_PRODUCT = {}
for k1, v1 in ipairs(tbl2.LIST) do
	tbl2.BY_ID[v1.id] = v1
	tbl2.BY_PRODUCT[v1.productId] = v1
end

tbl2.totals = function(arg1)
	local tbl3 = {
		gold = 1,
		silver = 1,
		luck = 1,
		bulk = 1,
		iron = 1,
		mining = 1,
		crystals = 1,
		wood = 1,
		essence = 1,
		starmetal = 1,
	}

	for k1, v1 in ipairs(tbl2.LIST) do
		if not tbl2.owns(arg1, v1.id) then
			continue
		end

		for k2, v2 in ipairs(tbl1) do
			if not v1[v2] then
				continue
			end

			if tbl3[v2] >= v1[v2] then
				continue
			end

			tbl3[v2] = v1[v2]
		end
	end

	return tbl3
end

return tbl2

--- ReplicatedStorage.Shared.SmelterConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.UpgradeConfig)
local tbl1 = {
	GAP = 14,
	ORE_PER_INGOT = 1,
	REACH = 30,
	inRoom = function(arg1)
		local var1 = workspace:FindFirstChild("SmelterSystem")
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("Room")
		if not var2 or (not var2:IsA("BasePart")) then
			return false
		end

		local var3 = var2.CFrame:PointToObjectSpace(arg1)
		local var4 = var2.Size / 2 + Vector3.new(1, 1, 1)
		local bool2 = false
		if math.abs(var3.X) <= var4.X then
			bool2 = false
			if math.abs(var3.Y) <= var4.Y then
				bool2 = math.abs(var3.Z) <= var4.Z
			end
		end

		return bool2
	end,
	DOOR = "ironOre",
	path = function(arg1)
		local tbl1 = {}
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			if v1.Name ~= "Conveyor" then
				continue
			end

			table.insert(tbl1, v1)
		end

		local var4 = arg1:FindFirstChild("Dropper")
		local var5 = arg1:FindFirstChild("Smelter")
		local var6 = arg1:FindFirstChild("Press")
		if #tbl1 < 2 or (not var4 or (not var5 or (not var6 or (not arg1:FindFirstChild("Collector"))))) then
			return nil
		end

		local var7 = var4:GetBoundingBox().Position
		table.sort(tbl1, function(arg1, arg2)
			local var1 = arg1.Position - var7
			local var2 = arg2.Position - var7
			local var3 = Vector3.new(var1.X, 0, var1.Z).Magnitude
			return var3 < Vector3.new(var2.X, 0, var2.Z).Magnitude
		end)

		local var8 = tbl1[1]
		local var9 = var8.Size
		local var10 = tbl1[2]
		local var11 = var8.Position.Y + var8.Size.Y / 2
		local var12
		local var13
		if var9.Z <= var9.X then
			var13 = var8.CFrame.RightVector
			var12 = var9.X
		else
			var13 = var8.CFrame.LookVector
			var12 = var9.Z
		end

		var9 = var8.Position - var13 * (var12 / 2)
		local var14 = var9 - var7
		local var15 = var8.Position + var13 * (var12 / 2)
		local var16 = var15 - var7
		local var17 = Vector3.new(var14.X, 0, var14.Z).Magnitude
		if Vector3.new(var16.X, 0, var16.Z).Magnitude < var17 then
			var17 = var15
			var15 = var9
			var9 = var17
		end

		var17 = var10.Size
		local var19 = var9
		if var17.Z <= var17.X then
			var9 = var10.CFrame.RightVector
			var15 = var17.X
		else
			var9 = var10.CFrame.LookVector
			var15 = var17.Z
		end

		var17 = var10.Position - var9 * (var15 / 2)
		local var20 = var17 - var7
		var14 = var10.Position + var9 * (var15 / 2)
		local var21 = var14 - var7
		var16 = Vector3.new(var20.X, 0, var20.Z).Magnitude
		if Vector3.new(var21.X, 0, var21.Z).Magnitude < var16 then
			var16 = var14
			var14 = var17
			var17 = var16
		end

		var15 = var10.Size
		local var22 = var17
		var12 = var14
		if var15.Z <= var15.X then
			var9 = var10.CFrame.RightVector
			var17 = var15.X
		else
			var9 = var10.CFrame.LookVector
			var17 = var15.Z
		end

		var15 = nil
		var15 = if math.abs(var9.X) <= math.abs(var9.Z) then Vector3.new(var10.Position.X, 0, var8.Position.Z) else Vector3.new(var8.Position.X, 0, var10.Position.Z)
		var17 = {
			Vector3.new(var19.X, var11, var19.Z),
			Vector3.new(var15.X, var11, var15.Z),
			(Vector3.new(var12.X, var11, var12.Z)),
		}

		var14 = { 0 }
		for i1 = 2, #var17 do
			local var23 = var14[i1 - 1] + (var17[i1] - var17[i1 - 1]).Magnitude
			var14[i1] = var23
		end

		var20 = function(arg1)
			local var1 = arg1:GetBoundingBox().Position
			local num1 = 0
			local num2 = math.huge
			for i1 = 2, #var17 do
				local var2 = var17[i1 - 1]
				local var3 = var1 - var2
				local var4 = var17[i1] - var2
				local var5 = Vector3.new(var3.X, 0, var3.Z):Dot((Vector3.new(var4.X, 0, var4.Z)))
				local var6 = var5 / Vector3.new(var4.X, 0, var4.Z):Dot((Vector3.new(var4.X, 0, var4.Z)))
				local var7 = math.clamp(var6, 0, 1)
				var3 = var1 - (var2 + var4 * var7)
				var5 = Vector3.new(var3.X, 0, var3.Z).Magnitude
				if var5 >= num2 then
					continue
				end

				num1 = var14[i1 - 1] + var4.Magnitude * var7
				local var8 = var5
			end

			return num1
		end

		local tbl2 = {
			points = var17,
			distances = var14,
			length = var14[#var14],
			top = var11,
			smelter = var20(var5),
		}

		tbl2.press = var20(var6)
		return tbl2
	end,
	bulkOf = function(arg1)
		return (math.max(1, (math.floor(arg1 and arg1.ironCapacity or 1))))
	end,
	ingotsPerOre = function(arg1, arg2)
		return (math.max(1, (arg1 and arg1.iron or 1) * (arg2 or 1)))
	end,
	loadOf = function(arg1)
		local var1 = arg1
		arg1 = var1 or {}
		var1 = arg1.load
		return var1 or (arg1.queued or 0)
	end,
}

tbl1.paceFor = function(arg1, arg2, arg3)
	local var2 = arg2
	arg2 = var2 or {}
	var2 = var1.BY_ID.fasterBelts
	local var3 = var2 and var2.value(arg2.fasterBelts or 0) or 5
	local var4 = arg1.length / math.max(var3, 0.1)
	local var5 = var1.BY_ID.ironCapacity
	return {
		trip = var3,
		speed = var4,
		spacing = tbl1.GAP / var4,
		capacity = (var5 and var5.value(arg2.ironCapacity or 0) or 10) * (arg3 or 1),
	}
end

tbl1.positionAt = function(arg1, arg2)
	local var1 = arg1.points
	arg2 = math.clamp(arg2, 0, arg1.length)
	local var2 = arg1.distances
	for i1 = 2, #var1 do
		if arg2 > var2[i1] then
			continue
		end

		local var3 = var2[i1] - var2[i1 - 1]
		return var1[i1 - 1]:Lerp(var1[i1], 0 < var3 and (arg2 - var2[i1 - 1]) / var3 or 0), (var1[i1] - var1[i1 - 1]).Unit
	end

	return var1[#var1], (var1[#var1] - var1[#var1 - 1]).Unit
end

return tbl1

--- ReplicatedStorage.Shared.TrailConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.NumberFormat)
local tbl1 = { id = "common", name = "Common", color = Color3.fromRGB(200, 200, 200) }
local tbl2 = { id = "uncommon", name = "Uncommon", color = Color3.fromRGB(110, 220, 110) }
local tbl3 = { id = "rare", name = "Rare", color = Color3.fromRGB(80, 170, 255) }
local tbl4 = { id = "epic", name = "Epic", color = Color3.fromRGB(190, 110, 255) }
local tbl5 = { id = "legendary", name = "Legendary", color = Color3.fromRGB(255, 190, 60) }
local tbl6 = { id = "special", name = "Special", color = Color3.fromRGB(255, 120, 180) }
local tbl7 = { id = "mythic", name = "Mythic", color = Color3.fromRGB(255, 70, 95) }
local tbl8 = { id = "exotic", name = "Exotic", color = Color3.fromRGB(80, 255, 230) }
local tbl9 = { id = "divine", name = "Divine", color = Color3.fromRGB(255, 232, 140) }
local tbl10 = { id = "rift", name = "Rift", color = Color3.fromRGB(70, 210, 195) }
local tbl11 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	{ id = "starforged", name = "Starforged", color = Color3.fromRGB(255, 80, 40) },
}

local tbl12 = {
	COLLECTION_GOLD = 0.02,
	VENDOR_RADIUS = 14,
	VENDOR = "TrailVendor",
	VENDORS = {
		{ booth = "Booth", shop = 1 },
		{ booth = "Booth2", shop = 2, door = "trails2" },
		{ booth = "Booth3", shop = 3, door = "door28" },
		{ booth = "Booth4", shop = 4, door = "door37" },
		{ booth = "Booth5", shop = 5, door = "door43" },
	},
	GROUP_ID = 596234797,
	TIERS = tbl11,
}

tbl12.LOOK = {
	common = { lifetime = 0.35, width = 0.8, light = 0, fade = { 0.2, 1 } },
	uncommon = { lifetime = 0.5, width = 1, light = 0, fade = { 0.15, 1 } },
	rare = { lifetime = 0.65, width = 1.1, light = 0.35, fade = { 0.1, 1 } },
	epic = {
		lifetime = 0.8,
		width = 1.25,
		light = 0.6,
		fade = { 0.05, 1 },
		faceCamera = true,
		sparkles = true,
	},
	legendary = {
		lifetime = 1,
		width = 1.4,
		light = 0.8,
		fade = { 0, 1 },
		faceCamera = true,
		sparkles = true,
	},
	special = { lifetime = 0.7, width = 1.1, light = 0.4, fade = { 0.1, 1 } },
	mythic = {
		lifetime = 1.2,
		width = 1.55,
		light = 1,
		fade = { 0, 1 },
		faceCamera = true,
		sparkles = true,
	},
	exotic = {
		lifetime = 1.4,
		width = 1.7,
		light = 1,
		fade = { 0, 1 },
		faceCamera = true,
		sparkles = true,
	},
	divine = {
		lifetime = 1.4,
		width = 1.7,
		light = 0.35,
		fade = { 0.2, 1 },
		faceCamera = true,
		sparkles = true,
	},
	rift = {
		lifetime = 1.5,
		width = 1.8,
		light = 0.3,
		fade = { 0.2, 1 },
		faceCamera = true,
		sparkles = true,
	},
	starforged = {
		lifetime = 1.6,
		width = 1.9,
		light = 0.35,
		fade = { 0.15, 1 },
		faceCamera = true,
		sparkles = false,
		embers = true,
	},
}

tbl11 = function(arg1, arg2, arg3)
	local var1 = arg1
	local var2 = arg2
	local var3 = arg3
	return Color3.fromRGB(var1, var2, var3)
end

tbl6 = 160
tbl7 = 140
tbl8 = 110
tbl3 = { Color3.fromRGB(214, 190, 150), tbl11(tbl6, tbl7, tbl8) }
tbl2 = {
	id = "dust",
	name = "Dust",
	tier = "common",
	floor = 1,
	currency = "gold",
	cost = 750,
	buffs = { gold = 1.05 },
	colors = tbl3,
}

tbl7 = 110
tbl8 = 60
tbl9 = 45
tbl4 = { Color3.fromRGB(190, 80, 60), tbl11(tbl7, tbl8, tbl9) }
tbl3 = {
	id = "brick",
	name = "Brick",
	tier = "common",
	floor = 2,
	currency = "gold",
	cost = 3000,
	buffs = { gold = 1.1 },
	colors = tbl4,
}

tbl8 = 220
tbl9 = 60
tbl10 = 30
tbl5 = { Color3.fromRGB(255, 170, 60), tbl11(tbl8, tbl9, tbl10) }
tbl4 = {
	id = "ember",
	name = "Ember",
	tier = "common",
	floor = 3,
	currency = "gold",
	cost = 7500,
	buffs = { gold = 1.15 },
	colors = tbl5,
}

tbl10 = 80
local num1 = 190
local num2 = 170
tbl6 = { Color3.fromRGB(215, 125, 70), Color3.fromRGB(180, 110, 70), tbl11(tbl10, num1, num2) }
tbl5 = {
	id = "copper",
	name = "Copper",
	tier = "uncommon",
	floor = 4,
	currency = "silver",
	cost = 25,
	buffs = { gold = 1.2 },
	colors = tbl6,
}

num1 = 40
num2 = 100
local num3 = 45
tbl7 = { Color3.fromRGB(150, 220, 110), Color3.fromRGB(80, 160, 70), tbl11(num1, num2, num3) }
tbl6 = {
	id = "moss",
	name = "Moss",
	tier = "uncommon",
	floor = 5,
	currency = "silver",
	cost = 250,
	buffs = { gold = 1.2, luck = 1.1 },
	colors = tbl7,
}

num2 = 150
num3 = 155
local num4 = 165
tbl8 = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(200, 205, 215), tbl11(num2, num3, num4) }
tbl7 = {
	id = "silver",
	name = "Silver",
	tier = "uncommon",
	floor = 6,
	currency = "silver",
	cost = 400,
	buffs = { silver = 1.3 },
	colors = tbl8,
	light = 0.3,
}

num3 = 30
num4 = 80
local num5 = 200
tbl9 = { Color3.fromRGB(180, 235, 255), Color3.fromRGB(60, 160, 250), tbl11(num3, num4, num5) }
tbl8 = {
	id = "tide",
	name = "Tide",
	tier = "rare",
	floor = 7,
	currency = "silver",
	cost = 750,
	buffs = { gold = 1.3 },
	colors = tbl9,
}

num4 = 90
num5 = 210
local num6 = 240
tbl10 = { Color3.fromRGB(245, 252, 255), Color3.fromRGB(170, 235, 255), tbl11(num4, num5, num6) }
tbl9 = {
	id = "frost",
	name = "Frost",
	tier = "rare",
	floor = 8,
	currency = "silver",
	cost = 2500,
	buffs = { luck = 1.3 },
	colors = tbl10,
}

num5 = 60
num6 = 20
local num7 = 15
num1 = { Color3.fromRGB(255, 230, 90), Color3.fromRGB(255, 120, 30), tbl11(num5, num6, num7) }
tbl10 = {
	id = "magma",
	name = "Magma",
	tier = "rare",
	floor = 9,
	currency = "silver",
	cost = 10000,
	buffs = { gold = 1.5 },
	colors = num1,
}

num5 = 205
num6 = 165
num7 = 118
num2 = { Color3.fromRGB(170, 170, 175), tbl11(num5, num6, num7) }
num1 = {
	id = "iron",
	name = "Iron",
	tier = "rare",
	floor = 10,
	currency = "ingots",
	cost = 25,
	buffs = { iron = 1.25 },
	colors = num2,
}

num7 = 200
local num8 = 140
local num9 = 20
num3 = { Color3.fromRGB(255, 245, 180), Color3.fromRGB(255, 200, 50), tbl11(num7, num8, num9) }
num2 = {
	id = "gilded",
	name = "Gilded",
	tier = "epic",
	floor = 11,
	currency = "ingots",
	cost = 75,
	buffs = { gold = 1.75 },
	colors = num3,
}

num8 = 150
num9 = 70
local num10 = 220
num4 = { Color3.fromRGB(190, 255, 90), Color3.fromRGB(140, 200, 60), tbl11(num8, num9, num10) }
num3 = {
	id = "venom",
	name = "Venom",
	tier = "epic",
	floor = 12,
	currency = "ingots",
	cost = 200,
	buffs = { silver = 1.5 },
	colors = num4,
}

num9 = 25
num10 = 10
local num11 = 35
num5 = { Color3.fromRGB(190, 130, 255), Color3.fromRGB(110, 40, 190), tbl11(num9, num10, num11) }
num4 = {
	id = "plague",
	name = "Plague",
	tier = "epic",
	floor = 13,
	currency = "ingots",
	cost = 300,
	buffs = { iron = 1.5, luck = 1.25 },
	colors = num5,
}

num10 = 170
num11 = 110
local num12 = 255
num6 = {
	Color3.fromRGB(120, 255, 170),
	Color3.fromRGB(60, 220, 220),
	tbl11(num10, num11, num12),
}

num5 = {
	id = "aurora",
	name = "Aurora",
	tier = "legendary",
	floor = 14,
	currency = "ingots",
	cost = 500,
	buffs = { gold = 2 },
	colors = num6,
	cycle = 0.25,
}

local num13 = 220
local num14 = 90
local num15 = 255
num7 = {
	Color3.fromRGB(255, 80, 80),
	Color3.fromRGB(255, 220, 60),
	Color3.fromRGB(80, 255, 120),
	Color3.fromRGB(80, 170, 255),
	tbl11(num13, num14, num15),
}

num6 = {
	id = "prism",
	name = "Prism",
	tier = "legendary",
	floor = 15,
	currency = "ingots",
	cost = 2000,
	buffs = { gold = 1.5, silver = 1.5, luck = 1.5, iron = 1.5 },
	colors = num7,
	cycle = 0.5,
}

num12 = 255
num13 = 170
num14 = 30
num8 = {
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(255, 215, 80),
	tbl11(num12, num13, num14),
}

tbl1 = {
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	num1,
	num2,
	num3,
	num4,
	num5,
	num6,
	{
		id = "crown",
		name = "Crown",
		tier = "legendary",
		floor = 16,
		currency = "ingots",
		cost = 5000,
		buffs = { gold = 2.5, luck = 1.5 },
		colors = num8,
		double = true,
	},
}

tbl7 = 90
tbl8 = 170
tbl9 = 255
tbl3 = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 230, 80), tbl11(tbl7, tbl8, tbl9) }
tbl2 = {
	id = "storm",
	name = "Storm",
	tier = "mythic",
	shop = 2,
	floor = 33,
	currency = "crystals",
	cost = 15000,
	buffs = { gold = 4, luck = 2 },
	colors = tbl3,
	cycle = 0.6,
}

tbl8 = 60
tbl9 = 120
tbl10 = 255
tbl4 = { Color3.fromRGB(255, 120, 220), Color3.fromRGB(150, 80, 255), tbl11(tbl8, tbl9, tbl10) }
tbl3 = {
	id = "nebula",
	name = "Nebula",
	tier = "mythic",
	shop = 2,
	floor = 34,
	currency = "crystals",
	cost = 40000,
	buffs = { gold = 3.5, silver = 3.5, iron = 2.5 },
	colors = tbl4,
	cycle = 0.25,
}

tbl9 = 255
tbl10 = 110
num1 = 20
tbl5 = { Color3.fromRGB(255, 255, 220), Color3.fromRGB(255, 200, 40), tbl11(tbl9, tbl10, num1) }
tbl4 = {
	id = "solar",
	name = "Solar",
	tier = "mythic",
	shop = 2,
	floor = 35,
	currency = "crystals",
	cost = 90000,
	buffs = { gold = 6, luck = 2 },
	colors = tbl5,
	double = true,
}

tbl10 = 10
num1 = 10
num2 = 10
tbl6 = { Color3.fromRGB(20, 0, 30), Color3.fromRGB(120, 30, 200), tbl11(tbl10, num1, num2) }
tbl5 = {
	id = "void",
	name = "Void",
	tier = "mythic",
	shop = 2,
	floor = 36,
	currency = "crystals",
	cost = 225000,
	buffs = { gold = 5, silver = 4, luck = 3, iron = 3 },
	colors = tbl6,
	cycle = 0.2,
	double = true,
}

num3 = 190
num4 = 150
num5 = 255
tbl7 = {
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(255, 150, 200),
	Color3.fromRGB(150, 220, 255),
	Color3.fromRGB(255, 230, 120),
	tbl11(num3, num4, num5),
}

tbl6 = {
	id = "celestial",
	name = "Celestial",
	tier = "mythic",
	shop = 2,
	floor = 37,
	currency = "crystals",
	cost = 600000,
	buffs = { gold = 8, silver = 5, luck = 4, iron = 4 },
	colors = tbl7,
	cycle = 0.5,
	double = true,
}

num2 = 230
num3 = 120
num4 = 40
tbl8 = { Color3.fromRGB(255, 215, 110), Color3.fromRGB(255, 170, 60), tbl11(num2, num3, num4) }
tbl7 = {
	id = "radiance",
	name = "Radiance",
	tier = "divine",
	shop = 3,
	floor = 90,
	currency = "crystals",
	cost = 1500000,
	extra = { currency = "wood", amount = 20000 },
	buffs = { gold = 9, luck = 3, wood = 1.5 },
	colors = tbl8,
	cycle = 0.4,
	double = true,
}

num3 = 200
num4 = 90
num5 = 30
tbl9 = { Color3.fromRGB(40, 30, 70), Color3.fromRGB(255, 150, 50), tbl11(num3, num4, num5) }
tbl8 = {
	id = "eclipse",
	name = "Eclipse",
	tier = "divine",
	shop = 3,
	floor = 91,
	currency = "crystals",
	cost = 3000000,
	extra = { currency = "wood", amount = 40000 },
	buffs = { gold = 8, silver = 6, iron = 4, wood = 1.75 },
	colors = tbl9,
	cycle = 0.3,
	double = true,
}

num4 = 170
num5 = 130
num6 = 255
tbl10 = { Color3.fromRGB(120, 200, 255), Color3.fromRGB(90, 150, 255), tbl11(num4, num5, num6) }
tbl9 = {
	id = "aether",
	name = "Aether",
	tier = "divine",
	shop = 3,
	floor = 92,
	currency = "crystals",
	cost = 6000000,
	extra = { currency = "wood", amount = 80000 },
	buffs = { gold = 11, luck = 4, wood = 2 },
	colors = tbl10,
	cycle = 0.5,
	double = true,
}

num6 = 200
num7 = 140
num8 = 255
num1 = {
	Color3.fromRGB(110, 160, 255),
	Color3.fromRGB(255, 200, 90),
	Color3.fromRGB(60, 60, 150),
	tbl11(num6, num7, num8),
}

tbl10 = {
	id = "starfall",
	name = "Starfall",
	tier = "divine",
	shop = 3,
	floor = 93,
	currency = "crystals",
	cost = 12000000,
	extra = { currency = "wood", amount = 160000 },
	buffs = { gold = 10, silver = 7, luck = 5, iron = 5, wood = 2.5 },
	colors = num1,
	cycle = 0.7,
	double = true,
}

num7 = 255
num8 = 185
num9 = 70
num2 = {
	Color3.fromRGB(255, 210, 110),
	Color3.fromRGB(255, 150, 200),
	Color3.fromRGB(130, 210, 255),
	tbl11(num7, num8, num9),
}

num1 = {
	id = "divinity",
	name = "Divinity",
	tier = "divine",
	shop = 3,
	floor = 94,
	currency = "crystals",
	cost = 25000000,
	extra = { currency = "wood", amount = 320000 },
	buffs = { gold = 14, silver = 8, luck = 6, iron = 6, wood = 3 },
	colors = num2,
	cycle = 0.8,
	double = true,
}

num7 = 20
num8 = 70
num9 = 80
num3 = { Color3.fromRGB(90, 225, 205), Color3.fromRGB(40, 150, 140), tbl11(num7, num8, num9) }
num2 = {
	id = "riftshard",
	name = "Riftshard",
	tier = "rift",
	shop = 4,
	floor = 128,
	currency = "essence",
	cost = 1500000,
	extra = { currency = "wood", amount = 300000 },
	buffs = { gold = 15, luck = 6, wood = 3, essence = 1.5 },
	colors = num3,
	cycle = 0.5,
	double = true,
}

num8 = 70
num9 = 200
num10 = 190
num4 = { Color3.fromRGB(30, 22, 48), Color3.fromRGB(120, 80, 220), tbl11(num8, num9, num10) }
num3 = {
	id = "nullwake",
	name = "Nullwake",
	tier = "rift",
	shop = 4,
	floor = 129,
	currency = "essence",
	cost = 3000000,
	extra = { currency = "wood", amount = 600000 },
	buffs = { gold = 14, silver = 9, iron = 7, wood = 3.25, essence = 1.75 },
	colors = num4,
	cycle = 0.4,
	double = true,
}

num9 = 40
num10 = 24
num11 = 90
num5 = { Color3.fromRGB(150, 110, 245), Color3.fromRGB(90, 60, 190), tbl11(num9, num10, num11) }
num4 = {
	id = "voidtrace",
	name = "Voidtrace",
	tier = "rift",
	shop = 4,
	floor = 130,
	currency = "essence",
	cost = 6000000,
	extra = { currency = "wood", amount = 1200000 },
	buffs = { gold = 17, luck = 7, wood = 3.5, essence = 2 },
	colors = num5,
	cycle = 0.6,
	double = true,
}

num11 = 40
num12 = 140
num13 = 135
num6 = {
	Color3.fromRGB(110, 235, 215),
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(130, 90, 230),
	tbl11(num11, num12, num13),
}

num5 = {
	id = "shatterline",
	name = "Shatterline",
	tier = "rift",
	shop = 4,
	floor = 131,
	currency = "essence",
	cost = 12000000,
	extra = { currency = "wood", amount = 2400000 },
	buffs = { gold = 16, silver = 10, luck = 8, iron = 8, wood = 4, essence = 2.5 },
	colors = num6,
	cycle = 0.7,
	double = true,
}

num12 = 255
num13 = 200
num14 = 120
num7 = {
	Color3.fromRGB(12, 8, 24),
	Color3.fromRGB(100, 230, 210),
	Color3.fromRGB(160, 110, 255),
	tbl11(num12, num13, num14),
}

num6 = {
	id = "horizon",
	name = "Event Horizon",
	tier = "rift",
	shop = 4,
	floor = 132,
	currency = "essence",
	cost = 24000000,
	extra = { currency = "wood", amount = 5000000 },
	buffs = { gold = 20, silver = 12, luck = 9, iron = 9, wood = 4.5, essence = 3 },
	colors = num7,
	cycle = 0.8,
	double = true,
}

num12 = 255
num13 = 110
num14 = 20
num8 = {
	Color3.fromRGB(255, 230, 120),
	Color3.fromRGB(255, 170, 40),
	tbl11(num12, num13, num14),
}

num7 = {
	id = "forgespark",
	name = "Forgespark",
	tier = "starforged",
	shop = 5,
	floor = 148,
	currency = "starmetal",
	cost = 30000,
	extra = { currency = "essence", amount = 3000000 },
	buffs = { gold = 22, luck = 10, wood = 5, essence = 3.25, starmetal = 1.25 },
	colors = num8,
	cycle = 0.5,
	double = true,
}

num12 = 255
num13 = 120
num14 = 20
num8 = {
	Color3.fromRGB(255, 250, 200),
	Color3.fromRGB(255, 200, 70),
	tbl11(num12, num13, num14),
}

num7.emberColors = num8
tbl1 = {
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	num1,
	num2,
	num3,
	num4,
	num5,
	num6,
	num7,
}

tbl8 = 200
tbl9 = 45
tbl10 = 12
tbl3 = {
	Color3.fromRGB(30, 10, 8),
	Color3.fromRGB(255, 90, 20),
	Color3.fromRGB(20, 8, 6),
	tbl11(tbl8, tbl9, tbl10),
}

tbl2 = {
	id = "slagflow",
	name = "Slagflow",
	tier = "starforged",
	shop = 5,
	floor = 149,
	currency = "starmetal",
	cost = 90000,
	extra = { currency = "essence", amount = 6000000 },
	buffs = { gold = 21, silver = 14, iron = 11, wood = 5.25, essence = 3.5, starmetal = 1.4 },
	colors = tbl3,
	cycle = 0.4,
	double = true,
}

tbl7 = 90
tbl8 = 12
tbl9 = 6
tbl3 = { Color3.fromRGB(255, 140, 50), Color3.fromRGB(200, 40, 10), tbl11(tbl7, tbl8, tbl9) }
tbl2.emberColors = tbl3
tbl9 = 85
tbl10 = 95
num1 = 115
tbl4 = {
	Color3.fromRGB(255, 250, 235),
	Color3.fromRGB(160, 175, 195),
	Color3.fromRGB(255, 130, 50),
	tbl11(tbl9, tbl10, num1),
}

tbl3 = {
	id = "anvilstrike",
	name = "Anvilstrike",
	tier = "starforged",
	shop = 5,
	floor = 150,
	currency = "starmetal",
	cost = 250000,
	extra = { currency = "essence", amount = 12000000 },
	buffs = { gold = 25, luck = 11, wood = 5.5, essence = 3.75, starmetal = 1.6 },
	colors = tbl4,
	cycle = 0.6,
	double = true,
}

tbl8 = 255
tbl9 = 150
tbl10 = 60
tbl4 = { Color3.fromRGB(255, 255, 240), Color3.fromRGB(255, 225, 150), tbl11(tbl8, tbl9, tbl10) }
tbl3.emberColors = tbl4
tbl10 = 120
num1 = 10
num2 = 80
tbl5 = {
	Color3.fromRGB(255, 245, 210),
	Color3.fromRGB(255, 90, 70),
	Color3.fromRGB(215, 25, 95),
	tbl11(tbl10, num1, num2),
}

tbl4 = {
	id = "supernova",
	name = "Supernova",
	tier = "starforged",
	shop = 5,
	floor = 151,
	currency = "starmetal",
	cost = 700000,
	extra = { currency = "essence", amount = 24000000 },
	buffs = { gold = 24, silver = 15, luck = 12, iron = 12, wood = 6, essence = 4, starmetal = 1.8 },
	colors = tbl5,
	cycle = 0.7,
	double = true,
}

tbl9 = 170
tbl10 = 20
num1 = 90
tbl5 = { Color3.fromRGB(255, 220, 230), Color3.fromRGB(255, 80, 140), tbl11(tbl9, tbl10, num1) }
tbl4.emberColors = tbl5
num2 = 90
num3 = 5
num4 = 15
tbl6 = {
	Color3.fromRGB(150, 10, 20),
	Color3.fromRGB(255, 190, 70),
	Color3.fromRGB(220, 30, 25),
	Color3.fromRGB(255, 120, 40),
	tbl11(num2, num3, num4),
}

tbl5 = {
	id = "stellarcore",
	name = "Stellar Core",
	tier = "starforged",
	shop = 5,
	floor = 152,
	currency = "starmetal",
	cost = 2000000,
	extra = { currency = "essence", amount = 48000000 },
	buffs = { gold = 30, silver = 18, luck = 14, iron = 14, wood = 7, essence = 4.5, starmetal = 2 },
	colors = tbl6,
	cycle = 0.8,
	double = true,
}

tbl10 = 200
num1 = 20
num2 = 30
tbl6 = { Color3.fromRGB(255, 215, 110), Color3.fromRGB(255, 170, 60), tbl11(tbl10, num1, num2) }
tbl5.emberColors = tbl6
tbl10 = 200
num1 = 200
num2 = 200
tbl7 = { Color3.fromRGB(255, 255, 255), tbl11(tbl10, num1, num2) }
tbl6 = {
	id = "rookie",
	name = "Rookie",
	tier = "special",
	special = "starter",
	buffs = {},
	colors = tbl7,
}

num4 = 255
num5 = 190
num6 = 60
tbl8 = {
	Color3.fromRGB(200, 200, 200),
	Color3.fromRGB(110, 220, 110),
	Color3.fromRGB(80, 170, 255),
	Color3.fromRGB(190, 110, 255),
	tbl11(num4, num5, num6),
}

tbl7 = {
	id = "collector",
	name = "Collect",
	tier = "special",
	special = "collection",
	needs = 15,
	buffs = { gold = 3, silver = 3, luck = 2, iron = 2 },
	colors = tbl8,
	cycle = 0.15,
	double = true,
	sparkles = true,
}

num2 = 255
num3 = 215
num4 = 90
tbl9 = { Color3.fromRGB(255, 150, 200), tbl11(num2, num3, num4) }
tbl8 = {
	id = "topten",
	name = "Elite",
	tier = "special",
	special = "leaderboard",
	rank = 10,
	buffs = { gold = 1.5 },
	colors = tbl9,
	sparkles = true,
}

num4 = 255
num5 = 200
num6 = 60
tbl10 = { Color3.fromRGB(255, 240, 120), Color3.fromRGB(255, 255, 255), tbl11(num4, num5, num6) }
tbl9 = {
	id = "favorite",
	name = "Star",
	tier = "special",
	special = "favorite",
	buffs = { gold = 1.1 },
	colors = tbl10,
	sparkles = true,
}

num6 = 140
num7 = 255
num8 = 140
num1 = {
	Color3.fromRGB(255, 230, 90),
	Color3.fromRGB(255, 120, 200),
	Color3.fromRGB(120, 220, 255),
	tbl11(num6, num7, num8),
}

tbl10 = {
	id = "fortune",
	name = "Fortune",
	tier = "special",
	special = "wheel",
	buffs = { gold = 6, silver = 4, luck = 3, iron = 3, crystals = 2 },
	colors = num1,
	cycle = 0.6,
	double = true,
	sparkles = true,
}

num8 = 255
num9 = 240
num10 = 120
num2 = {
	Color3.fromRGB(80, 255, 230),
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(255, 90, 220),
	Color3.fromRGB(120, 90, 255),
	tbl11(num8, num9, num10),
}

num1 = {
	id = "mirage",
	name = "Mirage",
	tier = "exotic",
	special = "wheel",
	buffs = { gold = 10, silver = 6, luck = 5, iron = 5, crystals = 3 },
	colors = num2,
	cycle = 0.8,
	double = true,
}

num6 = 255
num7 = 255
num8 = 255
num3 = { Color3.fromRGB(90, 200, 255), tbl11(num6, num7, num8) }
num2 = {
	id = "group",
	name = "Group",
	tier = "special",
	special = "group",
	buffs = { gold = 1.1 },
	colors = num3,
}

num12 = 255
num13 = 130
num14 = 160
num8 = {
	Color3.fromRGB(255, 86, 120),
	Color3.fromRGB(255, 196, 214),
	tbl11(num12, num13, num14),
}

tbl1 = {
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	num1,
	num2,
	{
		id = "like",
		name = "Like",
		tier = "special",
		special = "like",
		buffs = { gold = 1.2, silver = 1.2 },
		colors = num8,
		sparkles = true,
	},
}

tbl12.LIST = tbl1
tbl12.BY_ID = {}
tbl12.TIER_BY_ID = {}
for k1, v1 in ipairs(tbl12.TIERS) do
	v1.order = k1
	tbl6 = tbl12.TIER_BY_ID
	tbl6[v1.id] = v1
end

tbl1 = {}
for k2, v2 in ipairs(tbl12.VENDORS) do
	tbl1[v2.shop] = v2.door
end

for k3, v3 in ipairs(tbl12.LIST) do
	v3.order = k3
	tbl7 = v3.shop or 1
	v3.shop = tbl7
	tbl7 = v3.door
	v3.door = tbl7 or tbl1[v3.shop]
	tbl12.BY_ID[v3.id] = v3
end

tbl12.CURRENCY_NAMES = {
	gold = "GOLD",
	silver = "SILVER",
	ingots = "IRON",
	crystals = "CRYSTALS",
	wood = "WOOD",
	essence = "ESSENCE",
	starmetal = "STARMETAL",
}

tbl12.costText = function(arg1)
	if arg1.extra then
		local var7 = arg1.currency
		local var8 = tbl12.CURRENCY_NAMES[var7]
		var8 = var8 or var7:upper()
		local var9 = arg1.extra.currency
		local var10 = tbl12.CURRENCY_NAMES[var9]
		local var11 = var1.suffix(arg1.cost):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
		var7 = var1.suffix(arg1.extra.amount):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1")
		var10 = var10 or var9:upper()
		return ("%s %s + %s %s"):format(var11, var8, var7, var10)
	end

	local var12 = arg1.currency
	local var13 = tbl12.CURRENCY_NAMES[var12]
	return var1.price(arg1.cost) .. " " .. (var13 or var12:upper())
end

tbl12.affordable = function(arg1, arg2)
	if (arg2(arg1.currency) or 0) < (arg1.cost or 0) then
		return false
	end

	local var2 = not arg1.extra
	if not var2 then
		var2 = arg1.extra.amount <= (arg2(arg1.extra.currency) or 0)
	end

	return var2
end

tbl2 = { "gold", "silver", "luck", "iron", "crystals", "wood", "essence", "starmetal" }
tbl12.STATS = tbl2
tbl12.countOwned = function(arg1)
	local var1 = arg1
	local num1 = 0
	for k1, v1 in pairs(var1 or {}) do
		if v1 ~= true then
			continue
		end

		if not tbl12.BY_ID[k1] then
			continue
		end

		num1 = num1 + 1
	end

	return num1
end

tbl12.totals = function(arg1, arg2)
	local var1 = arg1
	arg1 = var1 or {}
	local var2 = arg2
	var2 = var2 and tbl12.BY_ID[arg2]
	var1 = {
		gold = 1,
		silver = 1,
		luck = 1,
		iron = 1,
		crystals = 1,
		wood = 1,
		essence = 1,
		starmetal = 1,
	}

	if var2 and arg1[arg2] == true then
		for k1, v1 in ipairs(tbl2) do
			local var3 = var1[v1] * (var2.buffs[v1] or 1)
			var1[v1] = var3
		end
	end

	local var4 = var1.gold * (1 + tbl12.COLLECTION_GOLD * tbl12.countOwned(arg1))
	var1.gold = var4
	return var1
end

tbl12.lookOf = function(arg1)
	local var1 = tbl12.LOOK[arg1.tier]
	local var2 = table.clone(var1 or tbl12.LOOK.common)
	local str1 = "width"
	for k1, v1 in ipairs({ "lifetime", str1, "light", "faceCamera", "sparkles", "embers" }) do
		if arg1[v1] == nil then
			continue
		end

		var2[v1] = arg1[v1]
	end

	return var2
end

tbl12.colorSequence = function(arg1, arg2)
	local var3 = #arg1
	if var3 == 1 then
		local var4 = arg1[1]
		return ColorSequence.new(var4)
	end

	arg2 = arg2 or 0
	local tbl1 = {}
	for i1 = 0, var3 - 1 do
		local var5 = (i1 + arg2) % var3
		local var6 = math.floor(var5)
		local var7 = i1 / (var3 - 1)
		local var8 = arg1[var6 + 1]:Lerp(arg1[(var6 + 1) % var3 + 1], var5 - var6)
		table.insert(tbl1, ColorSequenceKeypoint.new(var7, var8))
	end

	local var9 = tbl1
	return ColorSequence.new(var9)
end

tbl12.clear = function(arg1)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChild("HumanoidRootPart")
	if not var1 then
		return
	end

	for k1, v1 in ipairs(var1:GetChildren()) do
		if not v1:GetAttribute("PlayerTrail") then
			continue
		end

		v1:Destroy()
	end
end

tbl12.build = function(arg1, arg2)
	local var1 = arg2
	var1 = var1 and arg2:FindFirstChild("HumanoidRootPart")
	if not arg1 or (not var1) then
		return
	end

	tbl12.clear(arg2)
	local var2 = tbl12.lookOf(arg1)
	local function ribbon(arg1, arg2)
		local var3 = Instance.new("Attachment")
		var3.Name = "TrailTop"
		var3.Position = Vector3.new(arg1, 1.1 * arg2, 0)
		var3:SetAttribute("PlayerTrail", true)
		var3.Parent = var1
		local var4 = Instance.new("Attachment")
		var4.Name = "TrailBottom"
		var4.Position = Vector3.new(arg1, -1.1 * arg2, 0)
		var4:SetAttribute("PlayerTrail", true)
		var4.Parent = var1
		local var5 = Instance.new("Trail")
		var5.Name = "PlayerTrail"
		var5:SetAttribute("PlayerTrail", true)
		var5:SetAttribute("TrailId", arg1.id)
		var5.Attachment0 = var3
		var5.Attachment1 = var4
		var5.Color = tbl12.colorSequence(arg1.colors)
		var5.Lifetime = var2.lifetime
		var5.WidthScale = NumberSequence.new(1, 0.2)
		var5.Transparency = NumberSequence.new(var2.fade[1], var2.fade[2])
		var5.LightEmission = var2.light
		var5.LightInfluence = 1 - var2.light
		var5.FaceCamera = var2.faceCamera == true
		var5.MinLength = 0.05
		var5.Parent = var1
	end

	ribbon(0, var2.width)
	if arg1.double then
		ribbon(-0.9, var2.width * 0.55)
		ribbon(0.9, var2.width * 0.55)
	end

	if var2.sparkles then
		local var3 = Instance.new("ParticleEmitter")
		var3.Name = "TrailSparkles"
		var3:SetAttribute("PlayerTrail", true)
		var3:SetAttribute("TrailId", arg1.id)
		var3.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		var3.Color = tbl12.colorSequence(arg1.colors)
		var3.LightEmission = 1
		local num1 = 1
		local num2 = 0
		var3.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(num1, num2) })
		var3.Transparency = NumberSequence.new(0.1, 1)
		var3.Lifetime = NumberRange.new(0.4, 0.9)
		var3.Rate = 14
		var3.Speed = NumberRange.new(0.5, 2)
		var3.SpreadAngle = Vector2.new(180, 180)
		var3.Parent = var1
	end

	if var2.embers then
		local var4 = Instance.new("ParticleEmitter")
		var4.Name = "TrailEmbers"
		var4:SetAttribute("PlayerTrail", true)
		var4:SetAttribute("TrailId", arg1.id)
		var4.Texture = "rbxasset://textures/particles/SquareParticle.png"
		local var6 = arg1.emberColors
		if not var6 then
			local num6 = 170
			local num7 = 25
			local num8 = 10
			var6 = { Color3.fromRGB(255, 220, 130), Color3.fromRGB(255, 110, 30), tbl11(num6, num7, num8) }
		end

		local num9 = 1
		local var7 = var6[3]
		var4.Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, var6[1]),
			ColorSequenceKeypoint.new(0.35, var6[2]),
			ColorSequenceKeypoint.new(num9, var7),
		})

		var4.LightEmission = 1
		num9 = 1
		var7 = 0
		var4.Size = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.32),
			NumberSequenceKeypoint.new(0.6, 0.24),
			NumberSequenceKeypoint.new(num9, var7),
		})

		num9 = 1
		var7 = 1
		var4.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0),
			NumberSequenceKeypoint.new(0.75, 0.15),
			NumberSequenceKeypoint.new(num9, var7),
		})

		var4.Lifetime = NumberRange.new(0.9, 1.8)
		var4.Rate = 22
		var4.Speed = NumberRange.new(1, 3)
		var4.SpreadAngle = Vector2.new(35, 35)
		var4.EmissionDirection = Enum.NormalId.Top
		var4.Acceleration = Vector3.new(0, 2.5, 0)
		var4.Drag = 1.2
		var4.Rotation = NumberRange.new(0, 360)
		var4.RotSpeed = NumberRange.new(-90, 90)
		var4.Parent = var1
	end
end

return tbl12

--- ReplicatedStorage.Shared.RebirthConfig [ModuleScript]
-- y u r i

local tbl1 = {
	FLOORS_PER_SECTION = 20,
	LIST = {
		{
			board = "Rebirth4",
			door = "rebirth4",
			currency = "gold",
			cost = 1000000000,
			gold = 40,
			silver = 3,
			iron = 3,
		},
		{
			board = "Rebirth8",
			door = "rebirth8",
			currency = "gold",
			cost = 97000000000,
			gold = 80,
			silver = 10,
			iron = 3,
		},
		{
			board = "Rebirth12",
			door = "rebirth12",
			currency = "gold",
			cost = 11000000000000,
			gold = 80,
			silver = 3,
			iron = 10,
		},
		{
			board = "Rebirth16",
			door = "rebirth16",
			currency = "gold",
			cost = 2300000000000000,
			gold = 20,
			silver = 3,
			iron = 3,
		},
		{
			board = "Rebirth20",
			door = "rebirth20",
			currency = "gold",
			cost = 6.2e+18,
			gold = 20,
			silver = 3,
			iron = 3,
		},
		{
			board = "Rebirth24",
			door = "rebirth24",
			currency = "gold",
			cost = 4.6e+21,
			gold = 20,
			silver = 3,
			iron = 3,
		},
		{
			board = "Rebirth28",
			door = "rebirth28",
			currency = "gold",
			cost = 3.5e+24,
			gold = 20,
			silver = 3,
			iron = 3,
		},
		{
			board = "Rebirth29",
			door = "rebirth29",
			currency = "gold",
			cost = 2.6e+27,
			gold = 20,
			silver = 3,
			iron = 3,
		},
	},
}

tbl1.STAIRS_PER_SECTION = tbl1.FLOORS_PER_SECTION * 12
tbl1.rebirthsForStair = function(arg1)
	return (math.clamp(math.floor(((arg1 or 1) - 1) / tbl1.STAIRS_PER_SECTION), 0, #tbl1.LIST))
end

tbl1.keptFloors = function(arg1)
	return math.max(0, math.clamp(math.floor(arg1 or 0), 0, #tbl1.LIST) - 1) * tbl1.FLOORS_PER_SECTION
end

tbl1.saveText = function(arg1)
	local var1 = tbl1.keptFloors(arg1)
	local var3 = var1 // tbl1.FLOORS_PER_SECTION
	if var3 <= 0 then
		return "Saves no floors yet"
	end

	if var3 == 1 then
		local var5 = var1
		return ("Saves Section 1 (Floors 1-%d)"):format(var5)
	end

	local var6 = var3
	local var7 = var1
	return ("Saves Sections 1-%d (Floors 1-%d)"):format(var6, var7)
end

if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	local tbl2 = { "Rebirth24" }
	for i1 = #tbl1.LIST, 1, -1 do
		if not table.find(tbl2, tbl1.LIST[i1].board) then
			continue
		end

		table.remove(tbl1.LIST, i1)
	end
end

tbl1.STATS = { "gold", "silver", "iron" }
tbl1.REACH = 110
tbl1.STARTER = { gold = 4, silver = 3 }
tbl1.multiplier = function(arg1, arg2)
	local num1 = 1
	for i1 = 1, math.min(arg1 or 0, #tbl1.LIST) do
		num1 = num1 * (tbl1.LIST[i1][arg2] or 1)
	end

	if (arg1 or 0) <= 0 then
		num1 = num1 * (tbl1.STARTER[arg2] or 1)
	end

	return num1
end

tbl1.goldMultiplier = function(arg1)
	local var1 = arg1
	local str1 = "gold"
	return tbl1.multiplier(var1, str1)
end

tbl1.PRICE_EXPONENTS = { 0.81, 1.03, 0.75, 0.57, 0.5, 0.4, 0.385, [0] = 0.4 }
tbl1.priceExponent = function(arg1)
	return tbl1.PRICE_EXPONENTS[math.clamp(math.floor(arg1 or 0), 0, #tbl1.LIST)] or 0.33
end

tbl1.priceScale = function(arg1)
	local num1 = 1
	for i1 = 1, math.min(arg1 or 0, #tbl1.LIST) do
		num1 = num1 * (tbl1.LIST[i1].gold or 1)
	end

	return num1 ^ tbl1.priceExponent(arg1)
end

tbl1.scaledCost = function(arg1, arg2)
	return (math.floor((arg1 or 0) * tbl1.priceScale(arg2) + 0.5))
end

tbl1.bonusText = function(arg1)
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1.STATS) do
		if not arg1[v1] then
			continue
		end

		if arg1[v1] == 1 then
			continue
		end

		local var1 = arg1[v1]
		local var2 = v1:sub(1, 1):upper() .. v1:sub(2)
		table.insert(tbl2, ("%gx More %s"):format(var1, var2))
	end

	local var3 = tbl2
	local str1 = ", "
	return table.concat(var3, str1)
end

return tbl1

--- ReplicatedStorage.Shared.PotionConfig [ModuleScript]
-- y u r i

local tbl1 = {
	id = "gold2x",
	item = "Gold",
	icon = "Potion4",
	name = "Greater Gold Potion",
	stat = "gold",
	multiplier = 2,
	duration = 600,
	currency = "crystals",
	cost = 25000,
	shop = 2,
	tier = 2,
}

local tbl3 = {
	DOOR = "potions",
	BOOTH = "PotionBooth1",
	VENDOR_RADIUS = 14,
	SERVER_REACH = 30,
	MAX_SECONDS = 10800,
	SHOPS = {
		{ booth = "PotionBooth1", door = "potions" },
		{ booth = "PotionBooth2", door = "door18" },
		{ booth = "PotionBooth3", door = "door32" },
	},
	LIST = {
		{
			id = "gold",
			item = "Gold",
			icon = "Potion1",
			name = "Gold Potion",
			stat = "gold",
			multiplier = 1.5,
			duration = 600,
			currency = "gold",
			cost = 45000000,
			shop = 1,
			tier = 1,
		},
		{
			id = "iron",
			item = "Iron",
			icon = "Potion2",
			name = "Iron Potion",
			stat = "iron",
			multiplier = 1.5,
			duration = 600,
			currency = "gold",
			cost = 45000000,
			shop = 1,
			tier = 1,
		},
		{
			id = "silver",
			item = "Silver",
			icon = "Potion3",
			name = "Silver Potion",
			stat = "silver",
			multiplier = 1.5,
			duration = 600,
			currency = "gold",
			cost = 45000000,
			shop = 1,
			tier = 1,
		},
		tbl1,
		{
			id = "iron2x",
			item = "Iron",
			icon = "Potion5",
			name = "Greater Iron Potion",
			stat = "iron",
			multiplier = 2,
			duration = 600,
			currency = "crystals",
			cost = 25000,
			shop = 2,
			tier = 2,
		},
		{
			id = "silver2x",
			item = "Silver",
			icon = "Potion6",
			name = "Greater Silver Potion",
			stat = "silver",
			multiplier = 2,
			duration = 600,
			currency = "crystals",
			cost = 25000,
			shop = 2,
			tier = 2,
		},
		{
			id = "crystals2x",
			icon = "Potion7",
			name = "Crystal Potion",
			stat = "crystals",
			multiplier = 2,
			duration = 600,
			tier = 2,
		},
		{
			id = "gold3x",
			item = "Gold",
			icon = "Potion8",
			name = "Supreme Gold Potion",
			stat = "gold",
			multiplier = 3,
			duration = 600,
			currency = "crystals",
			cost = 150000,
			shop = 3,
			tier = 3,
		},
		{
			id = "iron3x",
			item = "Iron",
			icon = "Potion9",
			name = "Supreme Iron Potion",
			stat = "iron",
			multiplier = 3,
			duration = 600,
			currency = "crystals",
			cost = 150000,
			shop = 3,
			tier = 3,
		},
		{
			id = "silver3x",
			item = "Silver",
			icon = "Potion10",
			name = "Supreme Silver Potion",
			stat = "silver",
			multiplier = 3,
			duration = 600,
			currency = "crystals",
			cost = 150000,
			shop = 3,
			tier = 3,
		},
	},
}

if game:GetService("ReplicatedStorage"):GetAttribute("Section6Live") ~= true then
	tbl3.SHOPS[3] = nil
	for i1 = #tbl3.LIST, 1, -1 do
		local var1 = tbl3.LIST[i1]
		tbl1 = var1.shop
		if tbl1 ~= 3 then
			continue
		end

		if var1.id == "gold3x" then
			tbl1 = nil
			var1.shop = tbl1
			var1.item = nil
			var1.currency = nil
			var1.cost = nil
		else
			table.remove(tbl3.LIST, i1)
		end
	end
end

tbl3.BY_ID = {}
for k1, v1 in ipairs(tbl3.LIST) do
	tbl3.BY_ID[v1.id] = v1
	local var2 = v1.shop
	var2 = var2 and tbl3.SHOPS[v1.shop]
	local var3 = var2
	v1.door = var3 and var2.door
	var3 = var2
	v1.booth = var3 and var2.booth
end

tbl3.remaining = function(arg1, arg2, arg3)
	local var1 = arg1
	local var2 = (var1 or {})[arg2]
	if type(var2) ~= "number" then
		return 0
	end

	return (math.max(0, var2 - arg3))
end

tbl3.multiplier = function(arg1, arg2, arg3)
	local num1 = 1
	for k1, v1 in ipairs(tbl3.LIST) do
		if v1.stat ~= arg2 then
			continue
		end

		if num1 >= v1.multiplier then
			continue
		end

		if 0 >= tbl3.remaining(arg1, v1.id, arg3) then
			continue
		end

		num1 = v1.multiplier
	end

	return num1
end

local function ahead(arg1, arg2, arg3)
	local num1 = 0
	for k1, v1 in ipairs(tbl3.LIST) do
		if v1.stat ~= arg2.stat then
			continue
		end

		if arg2.tier >= v1.tier then
			continue
		end

		local var1 = arg1
		local var2 = v1.id
		local var3 = arg3
		num1 = math.max(num1, tbl3.remaining(var1, var2, var3))
	end

	return num1
end

tbl3.ownTime = function(arg1, arg2, arg3)
	local var2 = tbl3.BY_ID[arg2]
	if not var2 then
		return 0
	end

	local var4 = tbl3.remaining(arg1, arg2, arg3)
	if var4 <= 0 then
		return 0
	end

	return (math.max(0, var4 - ahead(arg1, var2, arg3)))
end

tbl3.paused = function(arg1, arg2, arg3)
	local var2 = tbl3.BY_ID[arg2]
	local bool2 = false
	if var2 ~= nil then
		bool2 = false
		if 0 < tbl3.ownTime(arg1, arg2, arg3) then
			bool2 = 0 < ahead(arg1, var2, arg3)
		end
	end

	return bool2
end

tbl3.canAdd = function(arg1, arg2, arg3, arg4)
	return tbl3.ownTime(arg1, arg2, arg4) + arg3 <= tbl3.MAX_SECONDS + 1
end

tbl3.grant = function(arg1, arg2, arg3, arg4)
	local var2 = tbl3.BY_ID[arg2]
	if not var2 then
		return {}
	end

	local var3 = tbl3.ownTime(arg1, arg2, arg4)
	local var4 = math.min(var3 + arg3, tbl3.MAX_SECONDS)
	local var5 = var2
	local tbl1 = { [arg2] = arg4 + ahead(arg1, var5, arg4) + var4 }
	for k1, v1 in ipairs(tbl3.LIST) do
		if v1.stat ~= var2.stat then
			continue
		end

		if v1.tier >= var2.tier then
			continue
		end

		if 0 >= tbl3.ownTime(arg1, v1.id, arg4) then
			continue
		end

		local var6 = arg1
		local var7 = var4 - var3
		tbl1[v1.id] = (var6 or {})[v1.id] + var7
	end

	return tbl1
end

tbl3.timeText = function(arg1)
	arg1 = math.max(0, (math.floor(arg1)))
	if 3600 <= arg1 then
		local var3 = arg1 // 3600
		local var4 = arg1 % 3600 // 60
		return ("%dh %dm"):format(var3, var4)
	end

	if 60 <= arg1 then
		local var5 = math.ceil(arg1 / 60)
		return ("%dm"):format(var5)
	end

	local var6 = arg1
	return ("%ds"):format(var6)
end

return tbl3

--- ReplicatedStorage.Shared.TutorialConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.DoorConfig)
local tbl1 = {
	START_GOLD = 500,
	STEPS = {
		{
			id = "climb",
			hint = "Climb",
			target = { kind = "topStair" },
			done = function(arg1)
				return 12 <= (arg1("stairsOwned") or 1)
			end,
		},
		{
			id = "upgrade",
			hint = "Upgrade",
			target = { kind = "board", name = "UpgradeBoard", gui = { "MoreMoney", "Buy" } },
			done = function(arg1)
				local var1 = arg1("upgrades")
				var1 = var1 or {}
				return 1 <= (var1.moreMoney or 0) + (var1.fasterMoney or 0) + (var1.speedBuff or 0)
			end,
		},
		{
			id = "door",
			hint = "Unlock",
			target = { kind = "door", door = "lavaGlyphs", gui = { "Buy" } },
			done = function(arg1)
				local str1 = "doors"
				local var1 = arg1(str1)
				for k1, v1 in pairs(var1 or {}) do
					if not v1 then
						continue
					end

					return true
				end

				return false
			end,
		},
	},
}

tbl1.COUNT = #tbl1.STEPS
tbl1.STUCK_SECONDS = 30
tbl1.NUDGES = {
	{
		id = "mine",
		hint = "Mine",
		target = { kind = "door", door = "mine", gui = { "Buy" } },
		ready = function(arg1)
			local var3 = var1.BY_ID.mine
			local bool1 = false
			if var3 ~= nil then
				bool1 = not arg1({ "doors", "mine" })
				if bool1 then
					bool1 = var3.floor * 12 <= (arg1("stairsOwned") or 1)
					if bool1 then
						bool1 = var3.cost <= (arg1("gold") or 0)
					end
				end
			end

			return bool1
		end,
	},
	{
		id = "rebirthRoom",
		hint = "Rebirth!",
		target = { kind = "door", door = "rebirth4", gui = { "Buy" } },
		ready = function(arg1, arg2)
			local var2 = arg2
			local var4 = var1.BY_ID.rebirth4
			var2 = var2 and arg2.LIST[1]
			local bool2 = false
			if var4 ~= nil then
				bool2 = false
				if var2 ~= nil then
					bool2 = not arg1({ "doors", "rebirth4" })
					if bool2 then
						bool2 = var4.floor * 12 <= (arg1("stairsOwned") or 1)
						if bool2 then
							bool2 = var4.cost + var2.cost <= (arg1("gold") or 0)
						end
					end
				end
			end

			return bool2
		end,
	},
	{
		id = "rebirth",
		hint = "Rebirth!",
		target = { kind = "rebirth", board = "Rebirth4", gui = { "Buy" } },
		ready = function(arg1, arg2)
			local var1 = arg2
			var1 = var1 and arg2.LIST[1]
			local bool2 = false
			if var1 ~= nil then
				bool2 = false
				if arg1({ "doors", "rebirth4" }) == true then
					bool2 = var1.cost <= (arg1("gold") or 0)
				end
			end

			return bool2
		end,
	},
}

tbl1.stepAt = function(arg1)
	return tbl1.STEPS[arg1 or 0]
end

tbl1.targetOf = function(arg1, arg2)
	if not arg1 then
		return nil
	end

	local var2 = arg1.target
	if var2.kind == "topStair" then
		local var4 = arg2("stairsOwned") or 1
		return tbl1.stairAt(var4)
	end

	if var2.kind == "board" then
		local var6 = workspace:FindFirstChild("Upgrades")
		return var6 and var6:FindFirstChild(var2.name) or nil
	end

	if var2.kind == "door" then
		local var7 = var1.BY_ID[var2.door]
		local var8 = workspace:FindFirstChild("Doors")
		return var7 and (var8 and var8:FindFirstChild(var7.model)) or nil
	end

	if var2.kind == "rebirth" then
		local var11 = workspace:FindFirstChild("Rebirths")
		local var12 = var11
		var12 = var12 and var11:FindFirstChild(var2.board)
		return var12 and var12:FindFirstChild("UIPart") or var12
	end

	return nil
end

local var2 = nil
tbl1.stairAt = function(arg1)
	if not var2 then
		local var3 = workspace:FindFirstChild("Stairs")
		if not var3 then
			return nil
		end

		var2 = {}
		for k1, v1 in ipairs(var3:GetDescendants()) do
			if not v1:IsA("BasePart") then
				continue
			end

			local var4 = v1:GetAttribute("StairIndex")
			if type(var4) ~= "number" then
				continue
			end

			var2[var4] = v1
		end
	end

	return var2[arg1]
end

return tbl1

--- ReplicatedStorage.Shared.FunnelConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.DoorConfig)
local var3 = require(var1.Shared.RebirthConfig)
local tbl1 = {
	name = "Doors",
	steps = (function()
		local tbl1 = {}
		for k1, v1 in ipairs(var2.DOORS) do
			table.insert(tbl1, v1)
		end

		table.sort(tbl1, function(arg1, arg2)
			if arg1.floor == arg2.floor then
				return arg1.cost < arg2.cost
			end

			return arg1.floor < arg2.floor
		end)

		local tbl2 = {}
		for k2, v2 in ipairs(tbl1) do
			local var1 = v2.id
			local tbl3 = { key = "door:" .. var1, step = k2, name = ("Floor %d %s"):format(v2.floor, var1) }
			tbl3.done = function(arg1)
				return arg1({ "doors", var1 }) == true
			end

			table.insert(tbl2, tbl3)
		end

		return tbl2
	end)(),
}

local tbl2 = {
	name = "Rebirths",
	steps = (function()
		local tbl1 = {}
		for k1 in ipairs(var3.LIST) do
			table.insert(tbl1, {
				key = "sectionRebirth:" .. k1,
				step = k1,
				name = "Rebirth " .. k1,
				done = function(arg1)
					return k1 <= (arg1("rebirths") or 0)
				end,
			})

		end

		return tbl1
	end)(),
}

local tbl3 = {
	key = "tut:upgrade",
	name = "Bought an Upgrade",
	done = function(arg1)
		local str1 = "upgrades"
		local var1 = arg1(str1)
		for k1, v1 in pairs(var1 or {}) do
			if type(v1) ~= "number" or 0 >= v1 then
				continue
			end

			return true
		end

		return false
	end,
}

local tbl4 = {
	key = "tut:door",
	name = "Bought a Door",
	done = function(arg1)
		local str1 = "doors"
		local var1 = arg1(str1)
		for k1, v1 in pairs(var1 or {}) do
			if not v1 then
				continue
			end

			return true
		end

		return false
	end,
}

local tbl5 = {
	{
		key = "tut:joined",
		name = "Joined",
		done = function()
			return true
		end,
	},
	{
		key = "tut:stair",
		name = "Bought a Stair",
		done = function(arg1)
			return 2 <= (arg1("stairsOwned") or 1)
		end,
	},
	{
		key = "tut:landing",
		name = "Floor 1",
		done = function(arg1)
			return 12 <= (arg1("stairsOwned") or 1)
		end,
	},
	tbl3,
	tbl4,
	{
		key = "tut:second",
		name = "Second Room",
		done = function(arg1)
			local str1 = "doors"
			local var1 = arg1(str1)
			local num1 = 0
			for k1, v1 in pairs(var1 or {}) do
				if not v1 then
					continue
				end

				num1 = num1 + 1
			end

			return 2 <= num1
		end,
	},
}

local tbl6 = { ONBOARDING = {
	{
		key = "joined",
		step = 1,
		name = "Joined",
		done = function()
			return true
		end,
	},
	{
		key = "firstStair",
		step = 2,
		name = "First Stair",
		done = function(arg1)
			return 2 <= (arg1("stairsOwned") or 1)
		end,
	},
	{
		key = "firstLanding",
		step = 3,
		name = "First Landing",
		done = function(arg1)
			return 12 <= (arg1("stairsOwned") or 1)
		end,
	},
	{
		key = "firstUpgrade",
		step = 4,
		name = "First Upgrade",
		done = function(arg1)
			local str1 = "upgrades"
			local var1 = arg1(str1)
			for k1, v1 in pairs(var1 or {}) do
				if type(v1) ~= "number" or 0 >= v1 then
					continue
				end

				return true
			end

			return false
		end,
	},
	{
		key = "doorGold",
		step = 5,
		name = "Door Affordable",
		done = function(arg1)
			local var3 = var2.BY_ID.lavaGlyphs
			local bool1 = false
			if var3 ~= nil then
				bool1 = var3.cost <= (arg1("gold") or 0)
			end

			return bool1
		end,
	},
	{
		key = "firstDoor",
		step = 6,
		name = "First Door",
		done = function(arg1)
			local str1 = "doors"
			local var1 = arg1(str1)
			for k1, v1 in pairs(var1 or {}) do
				if not v1 then
					continue
				end

				return true
			end

			return false
		end,
	},
	{
		key = "mineUnlocked",
		step = 7,
		name = "Mine Unlocked",
		done = function(arg1)
			return arg1({ "doors", "mine" }) == true
		end,
	},
	{
		key = "firstRebirth",
		step = 8,
		name = "First Rebirth",
		done = function(arg1)
			return 1 <= (arg1("rebirths") or 0)
		end,
	},
} }

local tbl7 = {}
local tbl8 = { name = "Tutorial" }
for k1, v1 in ipairs(tbl5) do
	v1.step = k1
end

tbl8.steps = tbl5
local str1 = "mine"
local str2 = "silver"
local num1 = 1
num1 = "silver"
local num2 = 100
num2 = "moreSilver"
local var4 = nil
var4 = "fasterMining"
local var5 = nil
var5 = "silver"
local num3 = 10000
num3 = "upgradeTree"
str2 = {
	key = "mine:board",
	name = "Silver Board Upgrade",
	done = function(arg1)
		return (var4 or 1) <= (arg1({ "upgrades", num2 }) or 0)
	end,
}

num1 = {
	key = "mine:faster",
	name = "Faster Mining",
	done = function(arg1)
		return (var5 or 1) <= (arg1({ "upgrades", var4 }) or 0)
	end,
}

local tbl9 = {
	{
		key = "mine:door",
		name = "Mine Unlocked",
		done = function(arg1)
			return arg1({ "doors", str1 }) == true
		end,
	},
	{
		key = "mine:ore",
		name = "First Ore",
		done = function(arg1)
			return num1 <= (arg1(str2) or 0)
		end,
	},
	{
		key = "mine:silver100",
		name = "100 Silver",
		done = function(arg1)
			return num2 <= (arg1(num1) or 0)
		end,
	},
	str2,
	num1,
	{
		key = "mine:silver10k",
		name = "10K Silver",
		done = function(arg1)
			return num3 <= (arg1(var5) or 0)
		end,
	},
	{
		key = "mine:tree",
		name = "Upgrade Tree Unlocked",
		done = function(arg1)
			return arg1({ "doors", num3 }) == true
		end,
	},
}

tbl5 = { name = "Mine" }
for k2, v2 in ipairs(tbl9) do
	v2.step = k2
end

tbl5.steps = tbl9
local str3 = "ironOre"
local str4 = "iron"
num2 = 1
num2 = "ingots"
var4 = 1
var4 = "ingots"
var5 = 100
var5 = "fasterBelts"
num3 = nil
num3 = "moreIron"
local var6 = nil
var6 = "autoDeposit"
local var7 = nil
str4 = {
	key = "smelt:ingots100",
	name = "100 Ingots",
	done = function(arg1)
		return var5 <= (arg1(var4) or 0)
	end,
}

num2 = {
	key = "smelt:belts",
	name = "Faster Belts",
	done = function(arg1)
		return (num3 or 1) <= (arg1({ "upgrades", var5 }) or 0)
	end,
}

local tbl10 = {
	{
		key = "smelt:door",
		name = "Smeltery Unlocked",
		done = function(arg1)
			return arg1({ "doors", str3 }) == true
		end,
	},
	{
		key = "smelt:ore",
		name = "First Iron Ore",
		done = function(arg1)
			return num2 <= (arg1(str4) or 0)
		end,
	},
	{
		key = "smelt:ingot",
		name = "First Ingots",
		done = function(arg1)
			return var4 <= (arg1(num2) or 0)
		end,
	},
	str4,
	num2,
	{
		key = "smelt:board4",
		name = "Mine Board Upgrade",
		done = function(arg1)
			return (var6 or 1) <= (arg1({ "upgrades", num3 }) or 0)
		end,
	},
	{
		key = "smelt:auto",
		name = "Auto Deposit",
		done = function(arg1)
			return (var7 or 1) <= (arg1({ "upgrades", var6 }) or 0)
		end,
	},
}

tbl9 = { name = "Smeltery" }
for k3, v3 in ipairs(tbl10) do
	v3.step = k3
end

tbl9.steps = tbl10
local str5 = "lavaGlyphs"
local str6 = "glyphsOpened"
var4 = 1
var4 = "glyphsOpened"
var5 = 10
var5 = "glyphsOpened"
num3 = 100
var6 = "glyphsOpened"
var7 = 1000
var7 = "waterGlyphs"
local str7 = "poisonGlyphs"
str6 = {
	key = "glyph:open100",
	name = "100 Opens",
	done = function(arg1)
		return num3 <= (arg1(var5) or 0)
	end,
}

var4 = {
	key = "glyph:board",
	name = "Glyph Board Upgrade",
	done = function(arg1)
		return 1 <= (arg1({ "upgrades", "glyphBulk" }) or 0) + (arg1({ "upgrades", "glyphLuck" }) or 0) + (arg1({ "upgrades", "fasterRolling" }) or 0)
	end,
}

local tbl11 = {
	{
		key = "glyph:door",
		name = "Lava Altar Unlocked",
		done = function(arg1)
			return arg1({ "doors", str5 }) == true
		end,
	},
	{
		key = "glyph:open1",
		name = "First Open",
		done = function(arg1)
			return var4 <= (arg1(str6) or 0)
		end,
	},
	{
		key = "glyph:open10",
		name = "10 Opens",
		done = function(arg1)
			return var5 <= (arg1(var4) or 0)
		end,
	},
	str6,
	var4,
	{
		key = "glyph:open1k",
		name = "1K Opens",
		done = function(arg1)
			return var7 <= (arg1(var6) or 0)
		end,
	},
	{
		key = "glyph:water",
		name = "Water Altar Unlocked",
		done = function(arg1)
			return arg1({ "doors", var7 }) == true
		end,
	},
	{
		key = "glyph:poison",
		name = "Poison Altar Unlocked",
		done = function(arg1)
			return arg1({ "doors", str7 }) == true
		end,
	},
}

tbl10 = { name = "Glyphs" }
for k4, v4 in ipairs(tbl11) do
	v4.step = k4
end

tbl10.steps = tbl11
local str8 = "crystals"
local str9 = "crystals"
var5 = 1
num3 = "crystals"
var6 = 1000
var6 = "crystalPower"
var7 = 5
str9 = {
	key = "crystal:1k",
	name = "1K Crystals",
	done = function(arg1)
		return var6 <= (arg1(num3) or 0)
	end,
}

var5 = {
	key = "crystal:power",
	name = "Crystal Power",
	done = function(arg1)
		return (var7 or 1) <= (arg1({ "upgrades", var6 }) or 0)
	end,
}

str1 = {
	{
		key = "crystal:door",
		name = "Garden Unlocked",
		done = function(arg1)
			return arg1({ "doors", str8 }) == true
		end,
	},
	{
		key = "crystal:first",
		name = "First Crystal",
		done = function(arg1)
			return var5 <= (arg1(str9) or 0)
		end,
	},
	{
		key = "crystal:board",
		name = "Crystal Board Upgrade",
		done = function(arg1)
			return 1 <= (arg1({ "upgrades", "crystalYield" }) or 0) + (arg1({ "upgrades", "growthSpeed" }) or 0) + (arg1({ "upgrades", "crystalPower" }) or 0)
		end,
	},
	str9,
	var5,
	{
		key = "crystal:trail",
		name = "First Mythic Trail",
		done = function(arg1)
			local var1 = arg1("trails")
			local str1 = "nebula"
			var1 = var1 or {}
			for k1, v1 in ipairs({ "storm", str1, "solar", "void", "celestial" }) do
				if not var1[v1] then
					continue
				end

				return true
			end

			return false
		end,
	},
}

tbl11 = { name = "Crystals" }
for k5, v5 in ipairs(str1) do
	v5.step = k5
end

tbl11.steps = str1
tbl7 = { tbl1, tbl2, tbl8, tbl5, tbl9, tbl10, tbl11 }
tbl6.FUNNELS = tbl7
tbl6.all = function()
	local tbl1 = { { funnel = nil, steps = tbl6.ONBOARDING } }
	for k1, v1 in ipairs(tbl6.FUNNELS) do
		table.insert(tbl1, { funnel = v1.name, steps = v1.steps })
	end

	return tbl1
end

return tbl6

--- ReplicatedStorage.Shared.CrystalConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.MineConfig)
local var3 = require(var1.Shared.UpgradeConfig)
local tbl1 = {
	DOOR = "crystals",
	SPOTS = "CrystalSpots",
	TEMPLATE_FOLDER = "Crystals",
	TEMPLATE = "Crystal",
	GARDEN_FLOOR = "SpawnZone",
	GARDEN_HEIGHT = 28,
	GROW_SECONDS = 15,
	HARVEST_RADIUS = 6,
	HARVEST_HEIGHT = 8,
	MIN_SCALE = 0.2,
	FULL_SCALE = 0.75,
	SINK = 0.4,
}

tbl1.inGarden = function(arg1)
	local var1 = workspace:FindFirstChild("Map")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild(tbl1.GARDEN_FLOOR)
	if not var2 or (not var2:IsA("BasePart")) then
		return false
	end

	local var3 = var2.CFrame:PointToObjectSpace(arg1)
	local bool2 = false
	if math.abs(var3.X) <= var2.Size.X / 2 then
		bool2 = false
		if math.abs(var3.Z) <= var2.Size.Z / 2 then
			bool2 = false
			if 0 <= var3.Y then
				bool2 = var3.Y <= tbl1.GARDEN_HEIGHT
			end
		end
	end

	return bool2
end

tbl1.holdSeconds = function(arg1, arg2)
	local var1 = arg1
	var1 = (var1 or {}).fasterMining
	local var3 = arg2
	return var2.secondsFor(var1, var3)
end

tbl1.spots = function()
	local var2 = workspace:FindFirstChild(tbl1.SPOTS)
	local tbl2 = {}
	if var2 then
		for k1, v1 in ipairs(var2:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			table.insert(tbl2, v1)
		end
	end

	table.sort(tbl2, function(arg1, arg2)
		return arg1.Name < arg2.Name
	end)

	return tbl2
end

tbl1.base = function(arg1)
	return arg1.Position + Vector3.new(0, arg1.Size.Y / 2, 0)
end

tbl1.growSeconds = function(arg1)
	local var1 = var3.BY_ID.growthSpeed
	return var1 and var1.value(({}).growthSpeed or 0) or tbl1.GROW_SECONDS
end

tbl1.yield = function(arg1, arg2, arg3)
	local var1 = var3.BY_ID.crystalYield
	return (math.floor((var1 and var1.value(({}).crystalYield or 0) or 1) * (arg2 and arg2.crystals or 1) * (arg3 or 1) + 0.5))
end

tbl1.progress = function(arg1, arg2, arg3)
	if not arg1 or arg1 <= arg2 then
		return 1
	end

	return (math.clamp(1 - (arg1 - arg2) / math.max(tbl1.growSeconds(arg3), 0.1), 0, 1))
end

tbl1.reach = function(arg1)
	local var1 = var3.BY_ID.mineRange
	return var1 and var1.value(({}).mineRange or 0) or tbl1.HARVEST_RADIUS
end

tbl1.target = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = nil
	local var2 = nil
	local var3 = tbl1.reach(arg5)
	for k1, v1 in ipairs(arg1) do
		local var4 = arg2
		var4 = var4 and arg2[v1.Name]
		local var5 = (tbl1.base(v1) - arg3).Magnitude
		if var4 and var4 <= arg4 or tbl1.inReach(v1, arg3, var3) and (not var2 or var5 < var2) then
			var1 = v1
		end

		local var6 = var5
	end

	return var1
end

local var4 = nil
tbl1.halfWidth = function()
	if var4 then
		return var4
	end

	local var2 = var1:FindFirstChild(tbl1.TEMPLATE_FOLDER)
	local var3 = var2
	var3 = var3 and var2:FindFirstChild(tbl1.TEMPLATE)
	if not var3 or (not var3:IsA("Model")) then
		return 1.5
	end

	local var5, var6 = var3:GetBoundingBox()
	var4 = math.max(var6.X, var6.Z) / 2 * tbl1.FULL_SCALE * 1.15
	return var4
end

tbl1.inReach = function(arg1, arg2, arg3)
	local var1 = arg2 - tbl1.base(arg1)
	local var2 = arg3
	local bool2 = false
	if Vector2.new(var1.X, var1.Z).Magnitude <= (var2 or tbl1.HARVEST_RADIUS) + tbl1.halfWidth() then
		bool2 = false
		if -2 <= var1.Y then
			bool2 = var1.Y <= tbl1.HARVEST_HEIGHT
		end
	end

	return bool2
end

return tbl1

--- ReplicatedStorage.Shared.CodeConfig [ModuleScript]
-- y u r i

return {
	CODES = { RELEASE = { potion = { id = "gold", seconds = 600 }, message = "+10m 1.5x Gold Potion!" } },
	normalize = function(arg1)
		if type(arg1) ~= "string" then
			return nil
		end

		arg1 = arg1:gsub("^%s+", ""):gsub("%s+$", ""):upper()
		if arg1 == "" or 32 < (#arg1) then
			return nil
		end

		return arg1
	end,
}

--- ReplicatedStorage.Shared.WheelConfig [ModuleScript]
-- y u r i

local tbl1 = {
	DOOR = "door15",
	MODEL = "PrizeWheel",
	FREE_COOLDOWN = 600,
	SPIN_COST = 100000,
	SPIN_TIME = 5,
	REACH = 30,
	SKIP_PRODUCT = 3714583238,
	CRYSTAL_ICON = "rbxassetid://101725822304617",
	GOLD_ICON = "rbxassetid://125268815094308",
	INGOT_ICON = "rbxassetid://72229364295214",
}

local tbl2 = {
	label = [[2X GOLD
POTION]],
	face = "2X",
	icon = tbl1.GOLD_ICON,
	weight = 28,
	color = Color3.fromRGB(255, 200, 60),
}

tbl2.reward = { potion = "gold2x", seconds = 600 }
local tbl3 = {
	label = [[RARE TRAIL;
(FORTUNE)]],
	face = [[RARE
TRAIL]],
	weight = 6,
	color = Color3.fromRGB(60, 200, 255),
}

tbl3.reward = { trail = "fortune", dupeGold = 60 }
local tbl4 = {
	label = [[2X INGOT
POTION]],
	face = "2X",
	icon = tbl1.INGOT_ICON,
	weight = 26,
	color = Color3.fromRGB(140, 150, 175),
}

tbl4.reward = { potion = "iron2x", seconds = 600 }
local tbl5 = {
	label = [[3X GOLD
POTION]],
	face = "3X",
	icon = tbl1.GOLD_ICON,
	weight = 14,
	color = Color3.fromRGB(255, 110, 30),
}

tbl5.reward = { potion = "gold3x", seconds = 600 }
local tbl6 = {
	label = [[2X CRYSTAL
POTION]],
	face = "2X",
	icon = tbl1.CRYSTAL_ICON,
	weight = 24,
	color = Color3.fromRGB(160, 90, 255),
}

tbl6.reward = { potion = "crystals2x", seconds = 600 }
local tbl7 = {
	label = [[EXOTIC TRAIL;
(MIRAGE)]],
	face = [[EXOTIC
TRAIL]],
	weight = 2,
	color = Color3.fromRGB(255, 60, 170),
}

tbl7.reward = { trail = "mirage", dupeGold = 120 }
tbl1.SEGMENTS = { tbl2, tbl3, tbl4, tbl5, tbl6, tbl7 }
local num1 = 0
for k1, v1 in ipairs(tbl1.SEGMENTS) do
	num1 = num1 + v1.weight
end

tbl1.TOTAL_WEIGHT = num1
tbl1.pick = function(arg1)
	local var1 = arg1 * tbl1.TOTAL_WEIGHT
	for k1, v1 in ipairs(tbl1.SEGMENTS) do
		var1 = var1 - v1.weight
		if var1 >= 0 then
			continue
		end

		return k1
	end

	return #tbl1.SEGMENTS
end

tbl1.angleOf = function(arg1)
	return (arg1 - 0.5) * 360 / #tbl1.SEGMENTS
end

return tbl1

--- ReplicatedStorage.Shared.WoodConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.MineConfig)
local var3 = require(var1.Shared.UpgradeConfig)
local tbl1 = {
	DOOR = "door23",
	SPOTS = "TreeSpots",
	TEMPLATE_FOLDER = "Trees",
	TEMPLATE = "Tree",
	YARD_MARGIN = 14,
	YARD_HEIGHT = 26,
	GROW_SECONDS = 20,
	HARVEST_RADIUS = 5,
	HARVEST_HEIGHT = 8,
	CHOP_FACTOR = 1.25,
	FULL_SCALE = 1,
}

tbl1.spots = function()
	local var2 = workspace:FindFirstChild(tbl1.SPOTS)
	local tbl2 = {}
	if var2 then
		for k1, v1 in ipairs(var2:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			table.insert(tbl2, v1)
		end
	end

	table.sort(tbl2, function(arg1, arg2)
		return arg1.Name < arg2.Name
	end)

	return tbl2
end

tbl1.base = function(arg1)
	return arg1.Position + Vector3.new(0, arg1.Size.Y / 2, 0)
end

local var4 = nil
tbl1.inYard = function(arg1)
	if not var4 then
		local var2 = tbl1.spots()
		if #var2 == 0 then
			return false
		end

		local var3 = Vector3.new(inf, inf, inf)
		local var5 = Vector3.new(-inf, -inf, -inf)
		for k1, v1 in ipairs(var2) do
			var3 = var3:Min(v1.Position)
			var5 = var5:Max(v1.Position)
		end

		local tbl2 = { mn = var3 - Vector3.new(tbl1.YARD_MARGIN, 2, tbl1.YARD_MARGIN) }
		tbl2.mx = var5 + Vector3.new(tbl1.YARD_MARGIN, tbl1.YARD_HEIGHT, tbl1.YARD_MARGIN)
		var4 = tbl2
	end

	local bool2 = false
	if var4.mn.X <= arg1.X then
		bool2 = false
		if arg1.X <= var4.mx.X then
			bool2 = false
			if var4.mn.Y <= arg1.Y then
				bool2 = false
				if arg1.Y <= var4.mx.Y then
					bool2 = false
					if var4.mn.Z <= arg1.Z then
						bool2 = arg1.Z <= var4.mx.Z
					end
				end
			end
		end
	end

	return bool2
end

tbl1.holdSeconds = function(arg1, arg2)
	local var1 = arg1
	local var3 = var2.secondsFor((var1 or {}).fasterMining, arg2)
	return var3 * tbl1.CHOP_FACTOR
end

tbl1.growSeconds = function(arg1)
	local var1 = var3.BY_ID.woodGrowth
	return var1 and var1.value(({}).woodGrowth or 0) or tbl1.GROW_SECONDS
end

tbl1.yield = function(arg1, arg2, arg3)
	local var1 = var3.BY_ID.woodYield
	return (math.floor((var1 and var1.value(({}).woodYield or 0) or 10) * (arg2 and arg2.wood or 1) * (arg3 or 1) + 0.5))
end

tbl1.progress = function(arg1, arg2, arg3)
	if not arg1 or arg1 <= arg2 then
		return 1
	end

	return (math.clamp(1 - (arg1 - arg2) / math.max(tbl1.growSeconds(arg3), 0.1), 0, 1))
end

local var5 = nil
tbl1.halfWidth = function()
	if var5 then
		return var5
	end

	local var2 = var1:FindFirstChild(tbl1.TEMPLATE_FOLDER)
	local var3 = var2
	var3 = var3 and var2:FindFirstChild(tbl1.TEMPLATE)
	if not var3 or (not var3:IsA("Model")) then
		return 2
	end

	local var4, var6 = var3:GetBoundingBox()
	var5 = math.max(var6.X, var6.Z) / 2 * tbl1.FULL_SCALE
	return var5
end

tbl1.reach = function(arg1)
	local var1 = var3.BY_ID.chopRange
	return var1 and var1.value(({}).chopRange or 0) or tbl1.HARVEST_RADIUS
end

tbl1.inReach = function(arg1, arg2, arg3)
	local var1 = arg2 - tbl1.base(arg1)
	local var2 = arg3
	local bool2 = false
	if Vector2.new(var1.X, var1.Z).Magnitude <= (var2 or tbl1.HARVEST_RADIUS) + tbl1.halfWidth() then
		bool2 = false
		if -2 <= var1.Y then
			bool2 = var1.Y <= tbl1.HARVEST_HEIGHT
		end
	end

	return bool2
end

tbl1.target = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = nil
	local var2 = nil
	local var3 = tbl1.reach(arg5)
	for k1, v1 in ipairs(arg1) do
		local var4 = arg2
		var4 = var4 and arg2[v1.Name]
		local var5 = (tbl1.base(v1) - arg3).Magnitude
		if var4 and var4 <= arg4 or tbl1.inReach(v1, arg3, var3) and (not var2 or var5 < var2) then
			var1 = v1
		end

		local var6 = var5
	end

	return var1
end

return tbl1

--- ReplicatedStorage.Shared.EssenceConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.UpgradeConfig)
local tbl1 = {
	DOOR = "door34",
	FIELD = "EssenceField",
	AREA = "SpawnArea",
	TEMPLATE_FOLDER = "Currency",
	TEMPLATE = "Essence",
	FLOAT_MIN = 2.4,
	FLOAT_MAX = 5.2,
	SPAWN_SHARE = 0.95,
	SPAWN_INNER = 4,
	SPREAD_TRIES = 8,
	ROOM_MARGIN = 24,
	ROOM_HEIGHT = 36,
	SERVER_SLACK = 2.5,
	CLIENT_SHORT = 0.6,
	BASE_COUNT = 8,
	BASE_RESPAWN = 6,
	BASE_YIELD = 1,
	BASE_RANGE = 6,
}

tbl1.area = function()
	local var1 = workspace:FindFirstChild(tbl1.FIELD)
	local var2 = var1
	return var2 and var1:FindFirstChild(tbl1.AREA)
end

tbl1.template = function()
	local var2 = var1:FindFirstChild(tbl1.TEMPLATE_FOLDER)
	local var3 = var2
	return var3 and var2:FindFirstChild(tbl1.TEMPLATE)
end

tbl1.floorY = function(arg1)
	return arg1.Position.Y - arg1.Size.Y / 2
end

tbl1.inRoom = function(arg1, arg2)
	local var1 = arg2
	arg2 = var1 or tbl1.area()
	if not arg2 then
		return false
	end

	var1 = arg1 - arg2.Position
	local var2 = tbl1.floorY(arg2)
	local bool2 = false
	if math.abs(var1.X) <= arg2.Size.X / 2 + tbl1.ROOM_MARGIN then
		bool2 = false
		if math.abs(var1.Z) <= arg2.Size.Z / 2 + tbl1.ROOM_MARGIN then
			bool2 = false
			if var2 - 3 <= arg1.Y then
				bool2 = arg1.Y <= var2 + tbl1.ROOM_HEIGHT
			end
		end
	end

	return bool2
end

tbl1.randomSpot = function(arg1, arg2)
	local var1 = arg2
	arg2 = var1 or tbl1.area()
	var1 = math.min(arg2.Size.X, arg2.Size.Z) / 2 * tbl1.SPAWN_SHARE
	local var2 = arg1:NextNumber(0, 6.2831853071795862)
	local var3 = math.sqrt((arg1:NextNumber((math.min(tbl1.SPAWN_INNER, var1 * 0.5) / var1) ^ 2, 1))) * var1
	return (Vector3.new(arg2.Position.X + math.cos(var2) * var3, tbl1.floorY(arg2) + arg1:NextNumber(tbl1.FLOAT_MIN, tbl1.FLOAT_MAX), arg2.Position.Z + math.sin(var2) * var3))
end

tbl1.spreadSpot = function(arg1, arg2, arg3)
	local var1 = nil
	local num1 = -1
	for i1 = 1, tbl1.SPREAD_TRIES do
		local var2 = arg3
		local var3 = tbl1.randomSpot(arg1, arg2)
		local num2 = math.huge
		for k1, v1 in pairs(var2 or {}) do
			local var4 = Vector2.new(var3.X - v1.X, var3.Z - v1.Z).Magnitude
			if var4 >= num2 then
				continue
			end

			num2 = var4
		end

		if num1 >= num2 then
			continue
		end

		var1 = var3
		local var5 = num2
	end

	return var1
end

tbl1.count = function(arg1)
	local var1 = var2.BY_ID.essenceCount
	return (math.floor(var1 and var1.value(({}).essenceCount or 0) or tbl1.BASE_COUNT))
end

tbl1.respawnSeconds = function(arg1)
	local var1 = var2.BY_ID.essenceSpeed
	return var1 and var1.value(({}).essenceSpeed or 0) or tbl1.BASE_RESPAWN
end

tbl1.range = function(arg1)
	local var1 = var2.BY_ID.essenceRange
	return var1 and var1.value(({}).essenceRange or 0) or tbl1.BASE_RANGE
end

tbl1.yield = function(arg1, arg2)
	local var1 = var2.BY_ID.essenceYield
	return (math.max(1, (math.floor((var1 and var1.value(({}).essenceYield or 0) or tbl1.BASE_YIELD) * (arg2 or 1) + 0.5))))
end

return tbl1

--- ReplicatedStorage.Shared.TotemConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.NumberFormat)
local tbl1 = {
	id = "gold",
	name = "Gold Totem",
	stat = "gold",
	currency = "essence",
	cost = 8000000,
	color = Color3.fromRGB(236, 190, 70),
}

local tbl2 = {
	id = "silver",
	name = "Silver Totem",
	stat = "silver",
	currency = "essence",
	cost = 5000000,
	color = Color3.fromRGB(205, 212, 226),
}

local tbl3 = {
	id = "iron",
	name = "Iron Totem",
	stat = "iron",
	currency = "essence",
	cost = 5000000,
	color = Color3.fromRGB(205, 165, 118),
}

local tbl4 = {
	id = "luck",
	name = "Luck Totem",
	stat = "luck",
	currency = "essence",
	cost = 10000000,
	color = Color3.fromRGB(110, 220, 110),
}

local tbl5 = {
	id = "crystals",
	name = "Crystal Totem",
	stat = "crystals",
	currency = "essence",
	cost = 5000000,
	color = Color3.fromRGB(170, 165, 255),
}

local tbl6 = {
	id = "wood",
	name = "Wood Totem",
	stat = "wood",
	currency = "essence",
	cost = 8000000,
	color = Color3.fromRGB(214, 160, 104),
}

local tbl7 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	{
		id = "essence",
		name = "Essence Totem",
		stat = "essence",
		currency = "essence",
		cost = 12000000,
		color = Color3.fromRGB(215, 150, 255),
	},
}

local tbl8 = {
	DOOR = "door39",
	FOLDER = "Totems",
	SLOTS = 3,
	MULT = 2,
	PROMPT_RADIUS = 11,
	SERVER_RADIUS = 20,
	BASES = {
		{ gold = 2e+24, wood = 180000 },
		{ gold = 1.2e+25, wood = 1500000 },
		{ gold = 7e+25, wood = 30000000 },
	},
	HEADS = tbl7,
}

tbl8.BY_ID = {}
for k1, v1 in ipairs(tbl8.HEADS) do
	v1.order = k1
	tbl8.BY_ID[v1.id] = v1
end

tbl8.CURRENCY_NAMES = {
	gold = "GOLD",
	silver = "SILVER",
	ingots = "IRON",
	crystals = "CRYSTALS",
	wood = "WOOD",
	essence = "ESSENCE",
}

tbl8.STAT_NAMES = {
	gold = "Gold",
	silver = "Silver",
	iron = "Iron",
	luck = "Luck",
	crystals = "Crystals",
	wood = "Wood",
	essence = "Essence",
}

tbl8.key = function(arg1)
	return "s" .. arg1
end

tbl8.basesOwned = function(arg1)
	local num1 = 0
	for i1 = 1, tbl8.SLOTS do
		if not arg1 then
			continue
		end

		if not arg1.bases then
			continue
		end

		if not arg1.bases[tbl8.key(i1)] then
			continue
		end

		num1 = num1 + 1
	end

	return num1
end

tbl8.nextBase = function(arg1)
	return tbl8.BASES[tbl8.basesOwned(arg1) + 1]
end

tbl8.slotOf = function(arg1, arg2)
	for i1 = 1, tbl8.SLOTS do
		if not arg1 then
			continue
		end

		if not arg1.slots then
			continue
		end

		if arg1.slots[tbl8.key(i1)] ~= arg2 then
			continue
		end

		return i1
	end

	return nil
end

tbl8.multFor = function(arg1)
	return tbl8.MULT * (arg1 or 1)
end

tbl8.totals = function(arg1, arg2)
	local var1 = tbl8.multFor(arg2)
	local tbl1 = { gold = 1, silver = 1, iron = 1, luck = 1, crystals = 1, wood = 1, essence = 1 }
	for i1 = 1, tbl8.SLOTS do
		local var2 = arg1
		local var3 = tbl8.key(i1)
		var2 = var2 and (arg1.bases and (arg1.bases[var3] and (arg1.slots and tbl8.BY_ID[arg1.slots[var3]])))
		if not var2 then
			continue
		end

		local var4 = var2.stat
		local var5 = tbl1[var4] * var1
		tbl1[var4] = var5
	end

	return tbl1
end

tbl8.short = function(arg1)
	return (var1.suffix(arg1):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1"))
end

tbl8.baseCostText = function(arg1)
	return var1.suffix(arg1.gold):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1") .. " GOLD + " .. var1.suffix(arg1.wood):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1") .. " WOOD"
end

tbl8.headCostText = function(arg1)
	local var2 = tbl8.CURRENCY_NAMES[arg1.currency]
	return var1.suffix(arg1.cost):gsub("(%.%d-)0+(%a)", "%1%2"):gsub("%.(%a)", "%1") .. " " .. (var2 or arg1.currency:upper())
end

return tbl8

--- ReplicatedStorage.Shared.TotemModels [ModuleScript]
-- y u r i

local function part(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	local var1 = Instance.new("Part")
	var1.Name = arg2
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.TopSurface = Enum.SurfaceType.Smooth
	var1.BottomSurface = Enum.SurfaceType.Smooth
	var1.Size = arg3
	var1.CFrame = arg4
	var1.Color = arg5
	local var2 = arg6
	var1.Material = var2 or Enum.Material.SmoothPlastic
	var1.Transparency = arg7 or 0
	if arg8 then
		var1.Shape = arg8
	end

	var1.Parent = arg1
	return var1
end

local var1 = Enum.Material.Wood
local tbl1 = {
	HEAD_Y = 8.45,
	base = function(arg1, arg2, arg3, arg4)
		local var2 = Instance.new("Model")
		var2.Name = if arg4 then "GhostBase" else "Base"
		local var3 = CFrame.lookAt(arg2, arg2 + arg3)
		local var4 = Color3.fromRGB(92, 58, 34)
		local var5 = if arg4 then 0.6 else 0
		part(var2, "Pedestal", Vector3.new(5, 1, 5), var3 * CFrame.new(0, 0.5, 0), var4, var1, var5)
		local var6 = Color3.fromRGB(128, 84, 48)
		part(var2, "Plinth", Vector3.new(4.2, 0.5, 4.2), var3 * CFrame.new(0, 1.25, 0), var6, var1, var5)
		local var7 = Color3.fromRGB(158, 108, 64)
		local num1 = 1.5
		for i1 = 1, 3 do
			part(var2, "Segment", Vector3.new(3.4, 2.2, 3.4), var3 * CFrame.new(0, num1 + 1.1, 0), i1 % 2 == 1 and var6 or var7, var1, var5)
			if not arg4 then
				local var9 = num1 + 1.1
				local var10 = var3 * CFrame.new(-0.7, var9 + 0.35, -1.72)
				local var11 = Color3.fromRGB(40, 24, 14)
				local var12 = Instance.new("Part")
				var12.Name = "Eye"
				var12.Anchored = true
				var12.CanCollide = false
				var12.CanQuery = false
				var12.CanTouch = false
				var12.TopSurface = Enum.SurfaceType.Smooth
				var12.BottomSurface = Enum.SurfaceType.Smooth
				var12.Size = Vector3.new(0.6, 0.45, 0.2)
				var12.CFrame = var10
				var12.Color = var11
				local var13 = var1
				var12.Material = var13 or Enum.Material.SmoothPlastic
				var12.Transparency = 0
				var12.Parent = var2
				var10 = var3 * CFrame.new(0.7, var9 + 0.35, -1.72)
				var11 = Color3.fromRGB(40, 24, 14)
				var12 = Instance.new("Part")
				var12.Name = "Eye"
				var12.Anchored = true
				var12.CanCollide = false
				var12.CanQuery = false
				var12.CanTouch = false
				var12.TopSurface = Enum.SurfaceType.Smooth
				var12.BottomSurface = Enum.SurfaceType.Smooth
				var12.Size = Vector3.new(0.6, 0.45, 0.2)
				var12.CFrame = var10
				var12.Color = var11
				var13 = var1
				var12.Material = var13 or Enum.Material.SmoothPlastic
				var12.Transparency = 0
				var12.Parent = var2
				var10 = var3 * CFrame.new(0, var9 - 0.45, -1.72)
				var11 = Color3.fromRGB(40, 24, 14)
				var12 = Instance.new("Part")
				var12.Name = "Mouth"
				var12.Anchored = true
				var12.CanCollide = false
				var12.CanQuery = false
				var12.CanTouch = false
				var12.TopSurface = Enum.SurfaceType.Smooth
				var12.BottomSurface = Enum.SurfaceType.Smooth
				var12.Size = Vector3.new(1.7, 0.35, 0.2)
				var12.CFrame = var10
				var12.Color = var11
				var13 = var1
				var12.Material = var13 or Enum.Material.SmoothPlastic
				var12.Transparency = 0
				var12.Parent = var2
				var10 = var3 * CFrame.new(0, num1 + 2.2, 0)
				local var14 = Instance.new("Part")
				var14.Name = "Band"
				var14.Anchored = true
				var14.CanCollide = false
				var14.CanQuery = false
				var14.CanTouch = false
				var14.TopSurface = Enum.SurfaceType.Smooth
				var14.BottomSurface = Enum.SurfaceType.Smooth
				var14.Size = Vector3.new(3.6, 0.25, 3.6)
				var14.CFrame = var10
				var14.Color = var4
				var12 = var1
				var14.Material = var12 or Enum.Material.SmoothPlastic
				var14.Transparency = 0
				var14.Parent = var2
			end

			num1 = num1 + 2.25
		end

		for i2 = -1, 1, 2 do
			local var15 = var3 * CFrame.new(i2 * 2.3, 6.9, 0)
			local var16 = Instance.new("Part")
			var16.Name = "Arm"
			var16.Anchored = true
			var16.CanCollide = false
			var16.CanQuery = false
			var16.CanTouch = false
			var16.TopSurface = Enum.SurfaceType.Smooth
			var16.BottomSurface = Enum.SurfaceType.Smooth
			var16.Size = Vector3.new(1.3, 0.6, 1.2)
			var16.CFrame = var15
			var16.Color = var4
			local var17 = var1
			var16.Material = var17 or Enum.Material.SmoothPlastic
			var16.Transparency = var5 or 0
			var16.Parent = var2
			var15 = var3 * CFrame.new(i2 * 3.05, 7.25, 0)
			var16 = Instance.new("Part")
			var16.Name = "ArmTip"
			var16.Anchored = true
			var16.CanCollide = false
			var16.CanQuery = false
			var16.CanTouch = false
			var16.TopSurface = Enum.SurfaceType.Smooth
			var16.BottomSurface = Enum.SurfaceType.Smooth
			var16.Size = Vector3.new(0.6, 1.1, 1.36)
			var16.CFrame = var15
			var16.Color = var6
			var17 = var1
			var16.Material = var17 or Enum.Material.SmoothPlastic
			var16.Transparency = var5 or 0
			var16.Parent = var2
		end

		local var18 = var3 * CFrame.new(0, 8.2, 0)
		local var19 = Instance.new("Part")
		var19.Name = "Collar"
		var19.Anchored = true
		var19.CanCollide = false
		var19.CanQuery = false
		var19.CanTouch = false
		var19.TopSurface = Enum.SurfaceType.Smooth
		var19.BottomSurface = Enum.SurfaceType.Smooth
		var19.Size = Vector3.new(4, 0.5, 4)
		var19.CFrame = var18
		var19.Color = var4
		local var20 = var1
		var19.Material = var20 or Enum.Material.SmoothPlastic
		var19.Transparency = var5 or 0
		var19.Parent = var2
		var2.Parent = arg1
		return var2
	end,
}

tbl1.head = function(arg1, arg2, arg3, arg4)
	local var2 = Instance.new("Model")
	var2.Name = "Head"
	local var3 = arg4.color
	local var7 = arg4.id
	local var8 = CFrame.lookAt(arg2, arg2 + arg3) * CFrame.new(0, tbl1.HEAD_Y, 0)
	local var9 = var3:Lerp(Color3.fromRGB(20, 16, 30), 0.35)
	local var10 = nil
	if var7 == "crystals" then
		var10 = Instance.new("Part")
		local var11 = var8 * CFrame.new(0, 1.63, 0)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.14, 3.6)
		var10.CFrame = var11
		var10.Color = var3
		local var12 = Enum.Material.Glass
		var10.Material = var12 or Enum.Material.SmoothPlastic
		var10.Transparency = 0.25
		var10.Parent = var2
		var11 = var8 * CFrame.new(0, 1.6, 0) * CFrame.Angles(0, 0.78539816339744828, 0)
		var12 = Instance.new("Part")
		var12.Name = "Core"
		var12.Anchored = true
		var12.CanCollide = false
		var12.CanQuery = false
		var12.CanTouch = false
		var12.TopSurface = Enum.SurfaceType.Smooth
		var12.BottomSurface = Enum.SurfaceType.Smooth
		var12.Size = Vector3.new(1.6, 1.8, 1.6)
		var12.CFrame = var11
		var12.Color = var9
		local var13 = Enum.Material.Neon
		var12.Material = var13 or Enum.Material.SmoothPlastic
		var12.Transparency = 0
		var12.Parent = var2
	elseif var7 == "essence" then
		var10 = Instance.new("Part")
		local var14 = var8 * CFrame.new(0, 1.6, 0)
		local var15 = Color3.fromRGB(60, 36, 104)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.2, 3.6)
		var10.CFrame = var14
		var10.Color = var15
		local var16 = Enum.Material.SmoothPlastic
		var10.Material = var16 or Enum.Material.SmoothPlastic
		var10.Transparency = 0
		var10.Parent = var2
		part(var2, "Orb", Vector3.new(2.2, 2.2, 2.2), var8 * CFrame.new(0, 1.7, -1.3), var9, Enum.Material.Neon, 0, Enum.PartType.Ball)
	elseif var7 == "wood" then
		var10 = Instance.new("Part")
		local var17 = var8 * CFrame.new(0, 1.6, 0)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.2, 3.6)
		var10.CFrame = var17
		var10.Color = var3
		local var18 = var1
		var10.Material = var18 or Enum.Material.SmoothPlastic
		var10.Transparency = 0
		var10.Parent = var2
		for i1 = 0, 2 do
			local var19 = var8 * CFrame.new(0, i1 * 1.05 + 0.55, 0)
			local var20 = Color3.fromRGB(120, 78, 44)
			local var21 = Instance.new("Part")
			var21.Name = "Plank"
			var21.Anchored = true
			var21.CanCollide = false
			var21.CanQuery = false
			var21.CanTouch = false
			var21.TopSurface = Enum.SurfaceType.Smooth
			var21.BottomSurface = Enum.SurfaceType.Smooth
			var21.Size = Vector3.new(3.7, 0.18, 3.7)
			var21.CFrame = var19
			var21.Color = var20
			local var22 = var1
			var21.Material = var22 or Enum.Material.SmoothPlastic
			var21.Transparency = 0
			var21.Parent = var2
		end

		var17 = var8 * CFrame.new(0, 1.7, -1.86) * CFrame.Angles(0, 0, 0.78539816339744828)
		local var23 = Color3.fromRGB(70, 150, 70)
		local var24 = Instance.new("Part")
		var24.Name = "Leaf"
		var24.Anchored = true
		var24.CanCollide = false
		var24.CanQuery = false
		var24.CanTouch = false
		var24.TopSurface = Enum.SurfaceType.Smooth
		var24.BottomSurface = Enum.SurfaceType.Smooth
		var24.Size = Vector3.new(1.4, 1.4, 0.25)
		var24.CFrame = var17
		var24.Color = var23
		local var25 = Enum.Material.SmoothPlastic
		var24.Material = var25 or Enum.Material.SmoothPlastic
		var24.Transparency = 0
		var24.Parent = var2
	elseif var7 == "iron" then
		var10 = Instance.new("Part")
		local var26 = var8 * CFrame.new(0, 1.6, 0)
		local var27 = Color3.fromRGB(96, 92, 104)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.2, 3.6)
		var10.CFrame = var26
		var10.Color = var27
		local var28 = Enum.Material.DiamondPlate
		var10.Material = var28 or Enum.Material.SmoothPlastic
		var10.Transparency = 0
		var10.Parent = var2
		local tbl2 = { 1.2, 0.5 }
		for k1, v1 in ipairs({ { -1.2, 0.5 }, tbl2, { -1.2, 2.7 }, { 1.2, 2.7 } }) do
			local var29 = var8 * CFrame.new(v1[1], v1[2], -1.86)
			local var30 = Instance.new("Part")
			var30.Name = "Rivet"
			var30.Anchored = true
			var30.CanCollide = false
			var30.CanQuery = false
			var30.CanTouch = false
			var30.TopSurface = Enum.SurfaceType.Smooth
			var30.BottomSurface = Enum.SurfaceType.Smooth
			var30.Size = Vector3.new(0.45, 0.45, 0.2)
			var30.CFrame = var29
			var30.Color = var3
			local var31 = Enum.Material.Metal
			var30.Material = var31 or Enum.Material.SmoothPlastic
			var30.Transparency = 0
			var30.Parent = var2
		end

		var26 = var8 * CFrame.new(0, 1.6, -1.86)
		local var32 = Instance.new("Part")
		var32.Name = "Bar"
		var32.Anchored = true
		var32.CanCollide = false
		var32.CanQuery = false
		var32.CanTouch = false
		var32.TopSurface = Enum.SurfaceType.Smooth
		var32.BottomSurface = Enum.SurfaceType.Smooth
		var32.Size = Vector3.new(2.2, 0.5, 0.25)
		var32.CFrame = var26
		var32.Color = var9
		local var33 = Enum.Material.Neon
		var32.Material = var33 or Enum.Material.SmoothPlastic
		var32.Transparency = 0
		var32.Parent = var2
	elseif var7 == "luck" then
		var10 = Instance.new("Part")
		local var34 = var8 * CFrame.new(0, 1.6, 0)
		local var35 = Color3.fromRGB(54, 120, 64)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.2, 3.6)
		var10.CFrame = var34
		var10.Color = var35
		local var36 = Enum.Material.SmoothPlastic
		var10.Material = var36 or Enum.Material.SmoothPlastic
		var10.Transparency = 0
		var10.Parent = var2
		var36 = { 0, 0.55 }
		local tbl3 = { 0, -0.55 }
		for k2, v2 in ipairs({ var36, tbl3, { 0.55, 0 }, { -0.55, 0 } }) do
			local var37 = var8 * CFrame.new(v2[1], 1.7 + v2[2], -1.86 - k2 * 0.012)
			local var38 = Instance.new("Part")
			var38.Name = "Petal"
			var38.Anchored = true
			var38.CanCollide = false
			var38.CanQuery = false
			var38.CanTouch = false
			var38.TopSurface = Enum.SurfaceType.Smooth
			var38.BottomSurface = Enum.SurfaceType.Smooth
			var38.Size = Vector3.new(0.85, 0.85, 0.22)
			var38.CFrame = var37
			var38.Color = var9
			local var39 = Enum.Material.Neon
			var38.Material = var39 or Enum.Material.SmoothPlastic
			var38.Transparency = 0
			var38.Parent = var2
		end
	else
		var10 = Instance.new("Part")
		local var40 = var8 * CFrame.new(0, 1.6, 0)
		var10.Name = "Block"
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.TopSurface = Enum.SurfaceType.Smooth
		var10.BottomSurface = Enum.SurfaceType.Smooth
		var10.Size = Vector3.new(3.6, 3.2, 3.6)
		var10.CFrame = var40
		var10.Color = var3
		local var41 = Enum.Material.Metal
		var10.Material = var41 or Enum.Material.SmoothPlastic
		var10.Transparency = 0
		var10.Parent = var2
		var40 = var8 * CFrame.new(0, 1.7, -1.86) * CFrame.Angles(0, 0, 0.78539816339744828)
		var41 = Instance.new("Part")
		var41.Name = "Gem"
		var41.Anchored = true
		var41.CanCollide = false
		var41.CanQuery = false
		var41.CanTouch = false
		var41.TopSurface = Enum.SurfaceType.Smooth
		var41.BottomSurface = Enum.SurfaceType.Smooth
		var41.Size = Vector3.new(1.1, 1.1, 0.25)
		var41.CFrame = var40
		var41.Color = var9
		local var42 = Enum.Material.Neon
		var41.Material = var42 or Enum.Material.SmoothPlastic
		var41.Transparency = 0
		var41.Parent = var2
	end

	local var43 = var8 * CFrame.new(0, 3.37, 0)
	local var44 = var3:Lerp(Color3.fromRGB(255, 255, 255), 0.15)
	local var45 = Instance.new("Part")
	var45.Name = "Cap"
	var45.Anchored = true
	var45.CanCollide = false
	var45.CanQuery = false
	var45.CanTouch = false
	var45.TopSurface = Enum.SurfaceType.Smooth
	var45.BottomSurface = Enum.SurfaceType.Smooth
	var45.Size = Vector3.new(4, 0.4, 4)
	var45.CFrame = var43
	var45.Color = var44
	local var46 = var10.Material == Enum.Material.Glass and Enum.Material.SmoothPlastic or var10.Material
	var45.Material = var46 or Enum.Material.SmoothPlastic
	var45.Transparency = 0
	var45.Parent = var2
	var43 = Instance.new("PointLight")
	var43.Color = var3
	var43.Range = 12
	var43.Brightness = 0.9
	var43.Shadows = false
	var43.Parent = var10
	var2.Parent = arg1
	return var2
end

return tbl1

--- ReplicatedStorage.Shared.TeleportTodo [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.TeleportConfig)
local var3 = require(var1.GlyphConfig)
local var4 = require(var1.StairConfig)
local var5 = require(var1.TotemConfig)
local var6 = require(var1.TrailConfig)
local var7 = require(var1.TreeConfig)
local var8 = require(var1.UpgradeConfig)
local var9 = require(var1.WheelConfig)
local tbl1 = {}
local tbl2 = { UpgradeBoard4 = "mine" }
local tbl3 = { like = true, collection = true, starter = true }
local tbl4 = {}
local var10 = nil
for k1, v1 in ipairs(var2.LIST) do
	local var12 = v1.spawn
	if var12 then
		var10 = v1.id
	else
		var12 = v1.door
		if not var12 then
			continue
		end

		var12 = v1.door
		tbl4[var12] = v1.id
	end
end

local tbl5 = {}
for k2, v2 in pairs(var6.VENDORS) do
	tbl5[v2.shop] = v2.door or false
end

tbl1.pending = function(arg1, arg2, arg3)
	local var1 = arg1
	arg1 = var1 or {}
	var1 = arg1.doors
	var1 = var1 or {}
	local tbl1 = {}
	local var11 = arg1.upgrades
	var11 = var11 or {}
	for k1, v1 in ipairs(var8.LIST) do
		local var13 = var8.doorFor(v1)
		local bool2 = true
		if var13 ~= nil then
			bool2 = true
			if var13 ~= false then
				bool2 = var1[var13] == true
			end
		end

		if not bool2 then
			continue
		end

		if (var11[v1.id] or 0) >= (v1.cap or math.huge) then
			continue
		end

		bool2 = tbl2[v1.board]
		if not bool2 then
			bool2 = if var13 == nil or var13 == false then var10 else tbl4[var13]
		end

		if not bool2 then
			continue
		end

		if tbl1[bool2] ~= nil then
			continue
		end

		tbl1[bool2] = if v1.permanent then "keeper" else "upgrade"
	end

	local var14 = arg1.glyphs
	var14 = var14 or {}
	for k2, v2 in ipairs(var3.SETS) do
		local var16 = v2.door
		local bool4 = true
		if var16 ~= nil then
			bool4 = true
			if var16 ~= false then
				bool4 = var1[var16] == true
			end
		end

		if not bool4 then
			continue
		end

		for k3, v3 in ipairs(v2.list) do
			if (var14[v3.id] or 0) >= v3.cap then
				continue
			end

			local var18 = v2.door
			local var19 = if var18 == nil or var18 == false then var10 else tbl4[var18]
			if not var19 then
				break
			end

			if tbl1[var19] ~= nil then
				break
			end

			tbl1[var19] = "glyphs"
			break
		end
	end

	local var20 = arg1.stairsOwned or 1
	local var21 = arg1.tree
	local var22 = var4.floorFor(var20, arg3)
	local var23 = arg1.rebirths or 0
	var21 = var21 or {}
	for k4, v4 in ipairs(var7.NODES) do
		local var24 = v4.door
		local var25 = var21[v4.id]
		if var25 then
			continue
		end

		var24 = var24 or var7.DOOR
		var25 = true
		if var24 ~= nil then
			var25 = true
			if var24 ~= false then
				var25 = var1[var24] == true
			end
		end

		if not var25 then
			continue
		end

		if v4.floor ~= nil then
			var25 = v4.floor
			if var25 > var22 then
				continue
			end
		end

		if v4.rebirths ~= nil then
			var25 = v4.rebirths
			if var25 > var23 then
				continue
			end
		end

		var25 = if var24 == nil or var24 == false then var10 else tbl4[var24]
		if not var25 then
			continue
		end

		if tbl1[var25] ~= nil then
			continue
		end

		tbl1[var25] = "tree"
	end

	local var26 = arg1.trails
	var26 = var26 or {}
	local var27 = var6.countOwned(var26)
	for k5, v5 in ipairs(var6.LIST) do
		local var28 = v5.shop
		var28 = var28 and tbl5[v5.shop]
		if var28 == nil then
			continue
		end

		if var26[v5.id] then
			continue
		end

		local bool6 = true
		if var28 ~= nil then
			bool6 = true
			if var28 ~= false then
				bool6 = var1[var28] == true
			end
		end

		if not bool6 then
			continue
		end

		bool6 = false
		if v5.special == nil then
			bool6 = v5.currency ~= nil
		end

		local var30 = tbl3[v5.special]
		if var30 then
			var30 = true
			if v5.special == "collection" then
				var30 = (v5.needs or 0) <= var27
			end
		end

		if not bool6 then
			if not var30 then
				continue
			end
		end

		local var31 = if var28 == nil or var28 == false then var10 else tbl4[var28]
		if not var31 then
			continue
		end

		if tbl1[var31] ~= nil then
			continue
		end

		tbl1[var31] = "trails"
	end

	local var32 = arg1.wheel
	local var34 = var9.DOOR
	var32 = var32 or {}
	local bool8 = true
	if var34 ~= nil then
		bool8 = true
		if var34 ~= false then
			bool8 = var1[var34] == true
		end
	end

	if bool8 then
		if (tonumber(var32.nextFree) or 0) <= (arg2 or 0) then
			if var9.SPIN_COST <= (arg1.crystals or 0) then
				var34 = var9.DOOR
				bool8 = if var34 == nil or var34 == false then var10 else tbl4[var34]
				if bool8 and tbl1[bool8] == nil then
					tbl1[bool8] = "spin"
				end
			end
		end
	end

	var34 = var5.DOOR
	bool8 = true
	if var34 ~= nil then
		bool8 = true
		if var34 ~= false then
			bool8 = var1[var34] == true
		end
	end

	local var35
	if bool8 then
		bool8 = arg1.totems
		bool8 = bool8 or {}
		for i1 = 1, var5.SLOTS do
			var35 = var5.key(i1)
			if bool8.bases then
				if not bool8.bases[var35] or (not bool8.slots or (not bool8.slots[var35])) then
					local var39 = var5.DOOR
					local var40 = if var39 == nil or var39 == false then var10 else tbl4[var39]
					if not var40 then
						break
					end

					if tbl1[var40] ~= nil then
						break
					end

					tbl1[var40] = "totems"
					break
				end
			end
		end
	end

	for k6, v6 in ipairs(var2.LIST) do
		if not tbl1[v6.id] then
			continue
		end

		if v6.spawn then
			continue
		end

		local var41, var42 = var2.landing(v6.floor, arg3)
		if var42 then
			if var42 <= var20 then
				local var45 = v6.door
				local bool11 = true
				if var45 ~= nil then
					bool11 = true
					if var45 ~= false then
						bool11 = var1[var45] == true
					end
				end

				if bool11 then
					continue
				end
			end
		end

		tbl1[v6.id] = nil
	end

	return tbl1
end

return tbl1

--- ReplicatedStorage.Shared.StarforgeConfig [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.UpgradeConfig)
local tbl1 = { DOOR = "door45", CHARGE = 1000, YIELD = 5 }
tbl1.BATCH = tbl1.CHARGE
tbl1.inRoom = function(arg1)
	local var1 = workspace:FindFirstChild("StarforgeSystem")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Room")
	if not var2 or (not var2:IsA("BasePart")) then
		return false
	end

	local var3 = var2.CFrame:PointToObjectSpace(arg1)
	local var4 = var2.Size / 2 + Vector3.new(1, 1, 1)
	local bool2 = false
	if math.abs(var3.X) <= var4.X then
		bool2 = false
		if math.abs(var3.Y) <= var4.Y then
			bool2 = math.abs(var3.Z) <= var4.Z
		end
	end

	return bool2
end

tbl1.paceFor = function(arg1, arg2)
	local var2 = arg1
	arg1 = var2 or {}
	var2 = var1.BY_ID.forgeSpeed
	local var3 = var2 and var2.value(arg1.forgeSpeed or 0) or 3
	local var4 = var1.BY_ID.forgeCapacity
	return {
		trip = var3,
		spacing = var3,
		capacity = (var4 and var4.value(arg1.forgeCapacity or 0) or 10) * math.max(arg2 or 1, 1),
	}
end

tbl1.perPiece = function(arg1, arg2)
	local var2 = var1.BY_ID.starmetalMulti
	return tbl1.YIELD * (var2 and var2.value(({}).starmetalMulti or 0) or 1) * (arg2 or 1)
end

return tbl1

--- ReplicatedStorage.Client.StairClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local tbl1 = {}
local var3 = require(var1.Shared.Remotes)
local bool1 = false
var2.Heartbeat:Connect(function()
	local var1 = os.clock()
	local var2 = nil
	for k1, v1 in pairs(tbl1) do
		if 0.25 > var1 - v1.last then
			continue
		end

		local var4 = var2
		var2 = var4 or {}
		table.insert(var2, k1)
	end

	if not var2 then
		return
	end

	table.sort(var2)
	for k2, v2 in ipairs(var2) do
		local var5 = tbl1[v2]
		var5.last = var1
		local success, result = pcall(function()
			var3.BuyStair:FireServer(v2)
		end)

		if success then
			continue
		end

		var5.last = 0
		if bool1 then
			break
		end

		bool1 = true
		warn("[Stairs] BuyStair could not be fired even from Heartbeat - " .. "set BuyStair.Sandboxed = true in Shared.Remotes. (" .. tostring(result) .. ")")
		return
	end
end)

local var4 = setmetatable({}, { __mode = "k" })
local function decorOf(arg1)
	local var2 = var4[arg1]
	if not var2 then
		local var3 = arg1:GetAttribute("StairHome")
		var2 = {}
		var3 = var3 or arg1.CFrame
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			if v1:FindFirstChildWhichIsA("SurfaceGui") then
				continue
			end

			local tbl1 = { part = v1, offset = var3:ToObjectSpace(v1.CFrame) }
			tbl1.transparency = v1.Transparency
			tbl1.collide = v1.CanCollide
			tbl1.query = v1.CanQuery
			table.insert(var2, tbl1)
		end

		var4[arg1] = var2
	end

	return var2
end

local var5 = setmetatable({}, { __mode = "k" })
local var6 = game:GetService("Players").LocalPlayer
local function characterInBox(arg1, arg2)
	local var2 = var6.Character
	if not var2 then
		return false
	end

	local var3 = OverlapParams.new()
	var3.FilterType = Enum.RaycastFilterType.Include
	var3.FilterDescendantsInstances = { var2 }
	var3.MaxParts = 1
	return 0 < (#workspace:GetPartBoundsInBox(arg1, arg2, var3))
end

local var7 = setmetatable({}, { __mode = "k" })
local var8 = setmetatable({}, { __mode = "k" })
local var9 = setmetatable({}, { __mode = "k" })
local var10 = nil
local var11 = nil
local function decorTo(arg1, arg2, arg3)
	local var1 = arg1
	for k1, v1 in ipairs((decorOf(var1))) do
		v1.part.CFrame = arg2 * v1.offset
		v1.part.Transparency = arg3 and v1.transparency or 1
		v1.part.CastShadow = arg3
		local var2 = arg3
		v1.part.CanCollide = var2 and v1.collide
		var2 = arg3
		v1.part.CanQuery = var2 and v1.query
	end
end

local function placeRamp(arg1)
	local var21
	local var2 = var9[arg1]
	if var2 then
		var9[arg1] = nil
		var2:Destroy()
	end

	local var3 = var10
	var2 = arg1:GetAttribute("StairIndex")
	var3 = var3 and (var2 and var10[var2 - 1])
	if not var3 then
		return
	end

	local var4 = arg1:GetAttribute("StairHome")
	local var6 = var3:GetAttribute("StairHome")
	local var8 = var5[arg1]
	var4 = var4 or arg1.CFrame
	var6 = var6 or var3.CFrame
	if not var8 then
		var8 = arg1.Size
		var5[arg1] = var8
	end

	local var13 = var5[var3]
	if not var13 then
		var13 = var3.Size
		var5[var3] = var13
	end

	local var14 = var4.Position.Y + var8.Y / 2
	local var15 = var6.Position.Y + var13.Y / 2
	local var17 = var14 - var15
	if var17 < 0.2 or 3 < var17 then
		return
	end

	local var18 = var4:PointToObjectSpace(var6.Position)
	if math.abs(var18.X) < 0.1 and math.abs(var18.Z) < 0.1 then
		return
	end

	if math.abs(var18.Z) < math.abs(var18.X) then
		local var20 = Vector3.new(math.sign(var18.X), 0, 0)
		if not var20 then
			var20 = Vector3.new(0, 0, (math.sign(var18.Z)))
		end
	end

	local var22 = math.abs(var21.X) * var8.X / 2 + math.abs(var21.Z) * var8.Z / 2
	local var23 = (var4 * CFrame.new(var21 * var22)).Position
	local var24 = (var4 * CFrame.new(var21 * (var22 + 4))).Position
	var23 = Vector3.new(var23.X, var14, var23.Z)
	var24 = Vector3.new(var24.X, var15, var24.Z)
	local var25 = math.abs(var21.X) * var8.Z + math.abs(var21.Z) * var8.X
	local var26 = var23 - var24
	local var27 = CFrame.lookAt((var23 + var24) / 2, var23)
	if not var11 or (not var11.Parent) then
		var11 = Instance.new("Folder")
		var11.Name = "StairRamps"
		var11.Parent = workspace
	end

	local var28 = Instance.new("Part")
	var28.Name = "StairRamp"
	var28.Anchored = true
	var28.CanCollide = true
	var28.CanQuery = false
	var28.CanTouch = false
	var28.CastShadow = false
	var28.Transparency = 1
	var28.Size = Vector3.new(var25 - 0.2, 0.4, var26.Magnitude)
	var28.CFrame = var27 * CFrame.new(0, -0.2, 0)
	var28.Parent = var11
	var9[arg1] = var28
end

local var12 = require(var1.Packages.DataService).client
local var13 = game:GetService("TweenService")
local function burst(arg1)
	local var1 = Instance.new("Highlight")
	var1.FillColor = Color3.new(1, 1, 1)
	var1.OutlineColor = Color3.new(1, 1, 1)
	var1.FillTransparency = 0
	var1.OutlineTransparency = 0
	var1.DepthMode = Enum.HighlightDepthMode.Occluded
	var1.Adornee = arg1
	var1.Parent = arg1
	var13:Create(var1, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { FillTransparency = 1, OutlineTransparency = 1 }):Play()
	task.delay(0.5, function()
		var1:Destroy()
	end)
end

local function impact(arg1)
	local var2 = var1:FindFirstChild("Effects")
	local var3 = var2
	var2 = var3 and var2:FindFirstChild("Particles")
	var3 = var2
	var3 = var3 and var2:FindFirstChild("StairImpact")
	if not var3 then
		return
	end

	local var5 = var12:get("settings")
	if var5 and var5.particles == false then
		return
	end

	local var6 = var3:Clone()
	var6.Position = var3.Position + Vector3.new(0, arg1.Size.Y / 2, 0)
	var6.Parent = arg1
	for k1, v1 in ipairs(var6:GetChildren()) do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		v1.Enabled = false
		v1:Emit(1)
	end

	task.delay(0.6, function()
		var6:Destroy()
	end)
end

local var14 = require(var1.Shared.StairConfig)
local var15 = game:GetService("TextService")
local var16 = require(var1.Shared.RebirthConfig)
local var17 = require(var1.Shared.NumberFormat)
local function reveal(arg1)
	local var2 = arg1:GetAttribute("StairHome")
	if not var2 then
		local var4 = var5[arg1]
		local var6 = arg1:GetAttribute("StairHome")
		if not var4 then
			var4 = arg1.Size
			var5[arg1] = var4
		end

		arg1.Size = var4
		if var6 then
			arg1.CFrame = var6
			decorTo(arg1, var6, true)
		end

		arg1.Transparency = 0
		arg1.CastShadow = true
		arg1.CanCollide = true
		placeRamp(arg1)
		return
	end

	local var10 = var5[arg1]
	local var11 = arg1:GetAttribute("StairHome")
	if not var10 then
		var10 = arg1.Size
		var5[arg1] = var10
	end

	local var12 = var11 * CFrame.new((var10.X - 0.05) / 2, 0, 0)
	arg1.Size = Vector3.new(0.05, var10.Y, var10.Z)
	arg1.CFrame = var12
	arg1.Transparency = 0
	arg1.CastShadow = true
	arg1.CanCollide = false
	decorTo(arg1, var12, false)
	burst(arg1)
	placeRamp(arg1)
	var11 = var7[arg1]
	if var11 then
		var7[arg1] = nil
		var11:Destroy()
	end

	var10 = var8[arg1]
	if var10 then
		var8[arg1] = nil
		var10:Cancel()
	end

	var11 = Instance.new("Part")
	var11.Name = "StairCollider"
	var11.Anchored = true
	var11.CanCollide = true
	var11.CanQuery = false
	var11.CanTouch = false
	var11.CastShadow = false
	var11.Transparency = 1
	var10 = var5[arg1]
	if not var10 then
		var10 = arg1.Size
		var5[arg1] = var10
	end

	var11.Size = var10
	var11.CFrame = var2
	var11.Parent = workspace
	var7[arg1] = var11
	local var14 = TweenInfo.new(0.16, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
	local var16 = var5[arg1]
	var10 = var13
	local var17 = arg1
	local tbl1 = { CFrame = var2 }
	if not var16 then
		var16 = arg1.Size
		var5[arg1] = var16
	end

	tbl1.Size = var16
	var10 = var10:Create(var17, var14, tbl1)
	var8[arg1] = var10
	var10.Completed:Connect(function(arg1)
		if var7[arg1] ~= var11 or arg1 ~= Enum.PlaybackState.Completed then
			return
		end

		local var1 = arg1
		local var4 = var5[var1]
		local var6 = arg1
		if not var4 then
			var4 = var1.Size
			var5[var1] = var4
		end

		var6.Size = var4
		arg1.CFrame = var2
		arg1.CanCollide = true
		decorTo(arg1, var2, true)
		var6 = arg1
		var4 = var7[var6]
		if var4 then
			var7[var6] = nil
			var4:Destroy()
		end

		var1 = var8[var6]
		if var1 then
			var8[var6] = nil
			var1:Cancel()
		end

		impact(arg1)
	end)

	var10:Play()
end

local var18 = require(var1.Client.SettingFlag)
local var19 = require(var1.Client.UISound)
local function bury(arg1)
	local var2 = var7[arg1]
	if var2 then
		var7[arg1] = nil
		var2:Destroy()
	end

	local var4 = var8[arg1]
	if var4 then
		var8[arg1] = nil
		var4:Cancel()
	end

	var2 = var9[arg1]
	if var2 then
		var9[arg1] = nil
		var2:Destroy()
	end

	arg1.CanCollide = false
	arg1.CastShadow = false
	arg1.Transparency = 1
	var2 = arg1:GetAttribute("StairHome")
	if var2 then
		local var10 = var5[arg1]
		local var11 = arg1:GetAttribute("StairHome")
		if not var10 then
			var10 = arg1.Size
			var5[arg1] = var10
		end

		var4 = var11 * CFrame.new((var10.X - 0.05) / 2, 0, 0)
		arg1.Size = Vector3.new(0.05, var10.Y, var10.Z)
		arg1.CFrame = var4
		decorTo(arg1, var2, false)
	end
end

return { init = function(_)
	local var40
	local var1 = var14.collect()
	var10 = var1
	if not var1[1] then
		warn("[Stairs] the run is not stamped - nothing to render")
		return
	end

	local var3 = var1[1]:FindFirstChildWhichIsA("SurfaceGui", true)
	local var4 = var3
	var4 = var4 and var3.Parent
	var4 = var4 and (var4:IsA("BasePart") or nil)
	local var9 = CFrame.new()
	local num1 = 0.02
	if var4 then
		local var11 = var4.Parent
		local var20 = var11 and (var11:IsA("BasePart") and var11:GetAttribute("StairHome")) or (var11.CFrame or nil)
		var9 = var20 and var20:ToObjectSpace(var4.CFrame) or CFrame.new()
		if var11 and var11:IsA("BasePart") then
			num1 = math.max(var9.Position.Y + var4.Size.Y / 2 - var11.Size.Y / 2, 0.02)
		end
	end

	local var21 = var4 and var4:GetAttribute("LandingShift") or 5.2
	local var22 = var4 and var4:GetAttribute("LandingBump") or 0
	local var23 = var3
	var23 = var23 and var3:FindFirstChild("PurchaseStair")
	local var24 = var23
	var24 = var24 and var23:FindFirstChild("Cost")
	local function plateCFrame(arg1, arg2)
		local var2 = arg1:GetAttribute("StairHome")
		local var3 = arg1
		var2 = var2 or arg1.CFrame
		local var5 = arg1.Size.Y / 2
		for k1, v1 in ipairs((decorOf(var3))) do
			var5 = math.max(var5, v1.offset.Position.Y + v1.part.Size.Y / 2)
		end

		local var8 = var9 - var9.Position
		local var10 = var9.Position.X
		local var11 = var9.Position.Z
		if arg1.Name == "EndStair" then
			local var14 = var1[arg2 + 1]
			var8 = var8 * CFrame.Angles(0, -1.5707963267948966, 0)
			local var15 = Vector3.new(-1, 0, 0)
			if var14 then
				local var16 = var14:GetAttribute("StairHome")
				local var17 = var2:ToObjectSpace(var16 or var14.CFrame).Position
				local var18 = Vector3.new(var17.X, 0, var17.Z)
				if 0.1 < var18.Magnitude then
					var15 = var18.Unit
				end
			end

			local var23 = var1[arg2 - 1]
			var10 = var10 + var15.X * var21
			var11 = var11 + var15.Z * var21
			if var23 then
				local var24 = var23:GetAttribute("StairHome")
				local var25 = var2:ToObjectSpace(var24 or var23.CFrame).Position
				local var26 = Vector3.new(var25.X, 0, var25.Z)
				if 0.1 < var26.Magnitude then
					var24 = var26.Unit
					var10 = var10 + var24.X * var22
					var11 = var11 + var24.Z * var22
				end
			end
		end

		return var2 * CFrame.new(var10, var5 + num1 - var4.Size.Y / 2, var11) * var8
	end

	local var25 = var24 and var24.TextSize or 29
	if not var3 then
		warn("[Stairs] no SurfaceGui on the first step - the run has no prompt")
	end

	local var27 = nil
	if var23 then
		var27 = var23:FindFirstChild("PromptPop")
		if not var27 then
			var27 = Instance.new("UIScale")
			var27.Name = "PromptPop"
			var27.Parent = var23
		end
	end

	local num2 = 0
	if var24 then
		if var3 then
			local num3 = 1
			local var30 = var24
			while var30 and var30 ~= var3 do
				num3 = num3 * var30.Size.X.Scale
				var30 = var30.Parent
			end

			num2 = num3 * var3.AbsoluteSize.X
		end
	end

	local function setCost(arg1)
		if not var24 then
			return
		end

		var24.Text = arg1
		local var1 = Instance.new("GetTextBoundsParams")
		var1.Text = arg1
		var1.Font = var24.FontFace
		var1.Size = var25
		var1.Width = 1000000
		local success, result = pcall(function()
			local var2 = var1
			return var15:GetTextBoundsAsync(var2)
		end)

		local var2 = 1 < num2 and num2 or var24.AbsoluteSize.X
		if success and (result and (1 < var2 and var2 < result.X)) then
			var24.TextSize = math.max(6, (math.floor(var25 * var2 / result.X)))
			return
		end

		var24.TextSize = var25
	end

	local function showPrompt(arg1)
		if not var3 then
			return
		end

		local var6 = var1[arg1]
		local var7 = var1[arg1 + 1]
		if not var6 or (not var7) then
			var3.Enabled = false
			return
		end

		if var4 then
			var4.CFrame = plateCFrame(var6, arg1)
			var3.Adornee = var4
		else
			var3.Adornee = var6
		end

		var3.Enabled = true
		local var10 = var16.rebirthsForStair(arg1 + 1)
		if (var12:get("rebirths") or 0) < var10 then
			local var11 = var10
			setCost(("REBIRTH %d REQUIRED"):format(var11))
			return
		end

		local var13 = var7:GetAttribute("StairCost") or 0
		local var14 = var12:get("rebirths") or 0
		setCost(var17.price(var16.scaledCost(var13, var14)) .. " GOLD")
	end

	local var31 = var12:get("stairsOwned") or 1
	local var32 = var31
	var6:SetAttribute("StairTop", var32)
	local var33 = Instance.new("Part")
	var33.Name = "StairGate"
	var33.Anchored = true
	var33.CanCollide = false
	var33.CanQuery = false
	var33.CanTouch = false
	var33.CastShadow = false
	var33.Transparency = 1
	var33.Parent = workspace
	local var34 = RaycastParams.new()
	var34.FilterType = Enum.RaycastFilterType.Exclude
	local var35 = workspace:FindFirstChild("Stairs")
	var34.FilterDescendantsInstances = { var35 or var1[1] }
	local function hopPrompt(arg1)
		if not var27 then
			showPrompt(arg1)
			return
		end

		var13:Create(var27, TweenInfo.new(0.07, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Scale = 0 }):Play()
		task.delay(0.07, function()
			showPrompt(arg1)
			var27.Scale = 0
			var13:Create(var27, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
		end)
	end

	var35 = nil
	local function placeGate(arg1)
		local var4 = var1[arg1]
		local var6 = var1[arg1 + 1]
		if not var4 or (not var6) then
			var33.CanCollide = false
			return
		end

		local var7 = var4:GetAttribute("StairHome")
		local var9 = var5[var4]
		var7 = var7 or var4.CFrame
		if not var9 then
			var9 = var4.Size
			var5[var4] = var9
		end

		local var10 = var6:GetAttribute("StairHome")
		local var11 = var7:ToObjectSpace(var10 or var6.CFrame).Position
		local var12 = Vector3.new(var11.X, 0, var11.Z)
		var10 = 0.1 < var12.Magnitude and var12.Unit or Vector3.new(0, 0, 1)
		local var13 = math.abs(var10.X) * var9.X / 2 + math.abs(var10.Z) * var9.Z / 2
		local var14 = math.abs(var10.X) * var9.Z + math.abs(var10.Z) * var9.X
		if workspace:Raycast((var7 * CFrame.new(var10 * (var13 + 2) + Vector3.new(0, var9.Y / 2, 0))).Position, Vector3.new(0, -(5 + var9.Y), 0), var34) then
			var33.CanCollide = false
			return
		end

		local var15 = var9.Y / 2 + 10
		local var16 = -var9.Y / 2
		local var17 = var7:VectorToWorldSpace(var10)
		var33.Size = Vector3.new(var14 + 2, var15 - var16, 0.8)
		for i1 = 0, 2 do
			local var18 = (var7 * CFrame.new(var10 * (var13 + 0.6 + 0.4 + i1) + Vector3.new(0, (var16 + var15) / 2, 0))).Position
			local var20 = CFrame.lookAt(var18, var18 + var17)
			if i1 == 2 or (not characterInBox(var20, var33.Size + Vector3.new(0.5, 0, 0.5))) then
				var33.CFrame = var20
				break
			end
		end

		var33.CanCollide = true
	end

	local function predict(arg1, arg2)
		local tbl2 = { first = os.clock(), last = 0 }
		tbl2.cost = arg2
		tbl1[arg1] = tbl2
		local var3 = var1[arg1]
		if var3 then
			reveal(var3)
		end

		if var18.on("buyStairSound") then
			var19.play("buyStair")
		end

		var32 = arg1
		var6:SetAttribute("StairTop", var32)
		hopPrompt(var32)
		var35(var32)
		placeGate(var32)
	end

	local function rollback()
		for i1 = var31 + 1, var32 do
			tbl1[i1] = nil
			local var2 = var1[i1]
			if not var2 then
				continue
			end

			bury(var2)
		end

		local var3 = var31 + 1
		local var4 = var31
		var14.say("ask", ("step %d was never confirmed - folded back to %d"):format(var3, var4))
		var32 = var31
		var6:SetAttribute("StairTop", var32)
		hopPrompt(var32)
		var35(var32)
		placeGate(var32)
	end

	local function tryAsk()
		local var4 = var1[var32 + 1]
		local var7 = var1[var32]
		if not var4 or (not var7) then
			var14.say("ask", "top of the run - nothing left to buy")
			return
		end

		if 3 <= var32 - var31 then
			var14.say("ask", "waiting on the server for the steps already shown")
			return
		end

		if not var6.Character then
			var14.say("ask", "no character yet")
			return
		end

		local var11 = var16.rebirthsForStair(var32 + 1)
		if (var12:get("rebirths") or 0) < var11 then
			local var13 = var32 + 1
			local var15 = var11
			var14.say("ask", ("step %d needs Rebirth %d"):format(var13, var15))
			return
		end

		local var18 = var16.scaledCost(var4:GetAttribute("StairCost") or 0, var12:get("rebirths") or 0)
		local var19 = var12:get("gold") or 0
		local num1 = 0
		for k1, v1 in pairs(tbl1) do
			if var31 >= k1 then
				continue
			end

			num1 = num1 + v1.cost
		end

		local var24 = var19 - num1
		if var24 < var18 then
			local var25 = var24
			local var26 = var32 + 1
			local var27 = var17.format(var18)
			var14.say("ask", ("step %d costs %s, holding %s"):format(var26, var27, var17.format(var25)))
			return
		end

		if not var7 then
			var19 = false
		else
			num1 = var7:GetAttribute("StairHome")
			local var29 = var5[var7]
			local var30 = characterInBox
			local var33 = (num1 or var7.CFrame) * CFrame.new(0, 4, 0)
			if not var29 then
				var29 = var7.Size
				var5[var7] = var29
			end

			var19 = var30(var33, var29 + Vector3.new(0, 8, 0))
		end

		if not var19 then
			local var35 = var32
			var14.say("ask", ("not standing on step %d yet"):format(var35))
			return
		end

		local var36 = var32 + 1
		var14.say("ask", ("buying step %d"):format(var36))
		predict(var32 + 1, var18)
	end

	local var36 = var6:GetAttribute("LoadingView") == true
	for k1, v1 in pairs(var1) do
		if k1 > var31 then
			if var36 then
				local var38 = var5[v1]
				local var39 = v1:GetAttribute("StairHome")
				if not var38 then
					var38 = v1.Size
					var5[v1] = var38
				end

				v1.Size = var38
				if var39 then
					v1.CFrame = var39
					decorTo(v1, var39, true)
				end

				v1.Transparency = 0
				v1.CastShadow = true
				v1.CanCollide = true
				placeRamp(v1)
			else
				bury(v1)
			end
		end
	end

	if var40 then
		local bool1 = false
		local var41 = nil
		local function foldAway()
			if bool1 then
				return
			end

			bool1 = true
			local tbl1 = {}
			for k1 in pairs(var1) do
				if var32 >= k1 then
					continue
				end

				table.insert(tbl1, k1)
			end

			table.sort(tbl1, function(arg1, arg2)
				return arg1 < arg2
			end)

			for k2, v1 in ipairs(tbl1) do
				local var2 = var1[v1]
				task.delay((k2 - 1) * 0.006, function()
					if v1 <= var32 or (not var2.Parent) then
						return
					end

					var2.CanCollide = false
					local var3 = var2:GetAttribute("StairHome")
					if not var3 then
						bury(var2)
						return
					end

					decorTo(var2, var3, false)
					local var4 = var2
					local var7 = var5[var4]
					local var8 = var4:GetAttribute("StairHome")
					if not var7 then
						var7 = var4.Size
						var5[var4] = var7
					end

					local var9 = var8 * CFrame.new((var7.X - 0.05) / 2, 0, 0)
					local var10 = Vector3.new(0.05, var7.Y, var7.Z)
					local var11 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					var4 = var13:Create(var2, var11, { CFrame = var9, Size = var10, Transparency = 1 })
					var4.Completed:Connect(function()
						if var32 < v1 then
							bury(var2)
							return
						end

						local var1 = var2
						local var4 = var5[var1]
						local var6 = var1:GetAttribute("StairHome")
						if not var4 then
							var4 = var1.Size
							var5[var1] = var4
						end

						var1.Size = var4
						if var6 then
							var1.CFrame = var6
							decorTo(var1, var6, true)
						end

						var1.Transparency = 0
						var1.CastShadow = true
						var1.CanCollide = true
						placeRamp(var1)
					end)

					var4:Play()
				end)

			end
		end

		var41 = var6:GetAttributeChangedSignal("LoadingView"):Connect(function()
			if var6:GetAttribute("LoadingView") ~= true then
				var41:Disconnect()
				foldAway()
			end
		end)

		task.delay(30, function()
			if var41.Connected then
				var41:Disconnect()
			end

			foldAway()
		end)

	end

	local var42 = nil
	showPrompt(var31)
	var35 = function(arg1)
		if var42 then
			var42:Disconnect()
			var42 = nil
		end

		local var3 = var1[arg1]
		if not var3 then
			return
		end

		var42 = var3.Touched:Connect(function(arg1)
			local var2 = var6.Character
			if var2 and arg1:IsDescendantOf(var2) then
				tryAsk()
			end
		end)

		tryAsk()
	end

	var35(var31)
	placeGate(var31)
	var12:getChangedSignal("rebirths"):Connect(function()
		showPrompt(var32)
	end)

	var12:getChangedSignal("gold"):Connect(function()
		tryAsk()
	end)

	var12:getChangedSignal("stairsOwned"):Connect(function(arg1)
		if arg1 < var31 then
			for i1 = arg1 + 1, math.max(var31, var32) do
				local var2 = var1[i1]
				if not var2 then
					continue
				end

				bury(var2)
			end

			table.clear(tbl1)
			var31 = arg1
			var32 = arg1
			var6:SetAttribute("StairTop", var32)
			hopPrompt(var32)
			var35(var32)
			placeGate(var32)
			return
		end

		local bool1 = false
		for i2 = var31 + 1, arg1 do
			tbl1[i2] = nil
			if var32 >= i2 then
				continue
			end

			local var4 = var1[i2]
			if var4 then
				reveal(var4)
			end

			bool1 = true
		end

		var31 = arg1
		if bool1 then
			if var18.on("buyStairSound") then
				var19.play("buyStair")
			end

			var32 = arg1
			var6:SetAttribute("StairTop", var32)
			hopPrompt(var32)
			var35(var32)
			placeGate(var32)
		end
	end)

	var2.Heartbeat:Connect(function()
		local var2 = tbl1[var31 + 1]
		if var2 and (var31 < var32 and 3 < os.clock() - var2.first) then
			rollback()
		end

		tryAsk()
	end)
end }

--- ReplicatedStorage.Client.CurrencyHUD [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local tbl1 = {
	{ frame = "Gold", key = "gold" },
	{ frame = "Silver", key = "silver", door = "mine" },
	{ frame = "Iron", key = "ingots", door = "ironOre" },
	{ frame = "Crystals", key = "crystals", door = "crystals" },
	{ frame = "Wood", key = "wood", door = "door23" },
	{ frame = "Essence", key = "essence", door = "door34" },
	{ frame = "Starmetal", key = "starmetal", door = "door45" },
}

local tbl2 = {}
local var3 = game:GetService("RunService")
local var4 = game:GetService("TweenService")
local var5 = require(var1.Packages.DataService).client
local var6 = require(var1.Shared.NumberFormat)
tbl2.init = function(_)
	local var1 = var2:WaitForChild("PlayerGui")
	for k1, v1 in ipairs(tbl1) do
		task.spawn(function()
			tbl2._bind(var1, v1.frame, v1.key, v1.door)
		end)

	end
end

local function findPill(arg1, arg2)
	local var1 = os.clock() + 20
	repeat
		for k1, v1 in ipairs(arg1:GetDescendants()) do
			if v1.Name ~= arg2 then
				continue
			end

			if not v1:IsA("GuiObject") then
				continue
			end

			if not v1:FindFirstChild("Amount") then
				continue
			end

			return v1
		end

		task.wait(0.2)
	until var1 < os.clock()

	return nil
end

tbl2._bind = function(arg1, arg2, arg3, arg4)
	local var1 = findPill(arg1, arg2)
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Amount")
	if var1 and arg4 then
		local var7 = var5:get({ "doors", arg4 }) == true
		var1.Visible = var7
		var5:getChangedSignal("doors"):Connect(function()
			var1.Visible = var5:get({ "doors", arg4 }) == true
		end)

	end

	local var8 = var1
	var8 = var8 and var1:FindFirstChild("Coin")
	if not var1 or (not var2) then
		local var10 = arg2
		warn(("[StairClimb] no %s frame with an Amount label in the PlayerGui - that counter is off"):format(var10))
		return
	end

	var7 = var1:FindFirstAncestorWhichIsA("ScreenGui")
	if not var7 then
		local var12 = arg2
		warn(("[StairClimb] the %s frame is not under a ScreenGui - no ticker"):format(var12))
	end

	local var14 = var1:FindFirstChildWhichIsA("UIScale")
	if not var14 then
		var14 = Instance.new("UIScale")
		var14.Name = "Scale"
		var14.Parent = var1
	end

	var2.TextWrapped = false
	var2.TextScaled = false
	var2.AutomaticSize = Enum.AutomaticSize.X
	local num1 = 0
	local var15 = var1:FindFirstChildWhichIsA("UIListLayout")
	local var16 = var1:FindFirstChildWhichIsA("UIPadding")
	local function fit()
		local var4 = var1.AbsoluteSize.Y / math.max(var14.Scale, 0.01)
		if var4 < 1 or math.abs(var4 - num1) < 0.5 then
			return
		end

		num1 = var4
		if var8 then
			local var5 = var8:GetAttribute("HeightScale")
			if type(var5) ~= "number" or var5 <= 0 then
				var5 = 1.0238095238095237
			end

			var8.Size = UDim2.new(0, math.floor(var4 * 1.0238095238095237 + 0.5), var5, 0)
		end

		var2.TextSize = math.max(6, (math.floor(var4 * 0.80952380952380953 + 0.5)))
		if var15 then
			var15.Padding = UDim.new(0, (math.floor(var4 * 0.14285714285714285 + 0.5)))
		end

		if var16 then
			var16.PaddingRight = UDim.new(0, (math.floor(var4 * 0.2857142857142857 + 0.5)))
		end
	end

	fit()
	var1:GetPropertyChangedSignal("AbsoluteSize"):Connect(fit)
	local var17 = var5:get(arg3) or 0
	local var18 = var17
	var2.Text = var6.format(var18)
	var3.Heartbeat:Connect(function(arg1)
		if var18 == var17 then
			return
		end

		local var1 = var17 - var18
		if math.abs(var1) < 1 then
			var18 = var17
		else
			local var3 = var18 + var1 * math.min(1, arg1 * 12)
			var18 = var3
		end

		var2.Text = var6.format(var18)
	end)

	local num2 = 0
	local var19 = var2.TextColor3
	local num3 = 0
	local num4 = 0
	local function ticker(arg1)
		if 6 <= num2 or (not var7) then
			return
		end

		local var3 = num2 + 1
		num2 = var3
		var3 = Instance.new("Frame")
		var3.Name = "GoldTick"
		var3.BackgroundTransparency = 1
		var3.AnchorPoint = Vector2.new(0, 1)
		local var5 = math.max(12, (math.floor(var1.AbsoluteSize.Y / math.max(var14.Scale, 0.01) * 0.62)))
		var3.Size = UDim2.fromOffset(var5 * 7, var5)
		var3.ZIndex = 20
		local var9 = var1.AbsolutePosition - var7.AbsolutePosition
		local var10 = var9.X + var1.AbsoluteSize.X + 6 + math.random(0, 8)
		local var11 = var9.Y + var1.AbsoluteSize.Y / 2 + var3.Size.Y.Offset / 2
		var3.Position = UDim2.fromOffset(var10, var11)
		var3.Parent = var7
		local var12 = var8
		var12 = var12 and var8:Clone()
		if var12 then
			for k1, v1 in ipairs(var12:GetChildren()) do
				if v1:IsA("UICorner") then
					continue
				end

				if v1:IsA("UIGradient") then
					continue
				end

				if v1:IsA("UIStroke") then
					continue
				end

				v1:Destroy()
			end

			var12.Name = "Coin"
			var12.AnchorPoint = Vector2.new(0, 0.5)
			var12.Position = UDim2.fromScale(0, 0.5)
			var12.Size = UDim2.fromScale(1, 1)
			local var13 = Instance.new("UIAspectRatioConstraint")
			var13.AspectRatio = 1
			var13.DominantAxis = Enum.DominantAxis.Height
			var13.Parent = var12
			var12.ZIndex = 20
			var12.Parent = var3
		end

		local var15 = Instance.new("TextLabel")
		var15.BackgroundTransparency = 1
		var15.AnchorPoint = Vector2.new(0, 0.5)
		var15.Position = UDim2.new(0, var5 + math.floor(var5 * 0.2), 0.5, 0)
		var15.Size = UDim2.new(1, -(var5 + math.floor(var5 * 0.2)), 0.85, 0)
		var15.FontFace = var2.FontFace
		var15.TextScaled = true
		var15.TextColor3 = var19
		var15.TextXAlignment = Enum.TextXAlignment.Left
		var15.Text = "+" .. var6.format(arg1)
		var15.ZIndex = 20
		var15.Parent = var3
		local var16 = Instance.new("UIStroke")
		var16.Color = Color3.new(0, 0, 0)
		var16.Thickness = 2
		var16.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
		var16.Parent = var15
		local var17 = TweenInfo.new(0.95, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var4:Create(var3, var17, { Position = UDim2.fromOffset(var10, var11 - 52) }):Play()
		var4:Create(var15, var17, { TextTransparency = 1 }):Play()
		var4:Create(var16, var17, { Transparency = 1 }):Play()
		if var12 then
			var4:Create(var12, var17, { ImageTransparency = 1 }):Play()
		end

		task.delay(1, function()
			local var1 = num2 - 1
			num2 = var1
			var3:Destroy()
		end)
	end

	local bool1 = false
	local function floatGain(arg1)
		local var1 = num3 + arg1
		num3 = var1
		var1 = 0.28 - (os.clock() - num4)
		if var1 <= 0 then
			num4 = os.clock()
			ticker(num3)
			num3 = 0
			return
		end

		if not bool1 then
			bool1 = true
			task.delay(var1, function()
				bool1 = false
				num4 = os.clock()
				if 0 < num3 then
					ticker(num3)
					num3 = 0
				end
			end)

		end
	end

	local var20 = var14.Scale
	var5:getChangedSignal(arg3):Connect(function(arg1, arg2)
		var17 = arg1
		if type(arg2) == "number" and arg2 < arg1 then
			floatGain(arg1 - arg2)
		end

		if type(arg2) == "number" and arg1 < arg2 then
			var14.Scale = var20 * 1.1
			local var1 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
			var4:Create(var14, var1, { Scale = var20 }):Play()
			var2.TextColor3 = Color3.new(1, 1, 1)
			var1 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			var4:Create(var2, var1, { TextColor3 = var19 }):Play()
		end
	end)
end

return tbl2

--- ReplicatedStorage.Client.UpgradeBoardUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local num1 = 124
local num2 = 23
local num3 = 23
local var2 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 229
num3 = 123
local num4 = 123
local num5 = 1
local var3 = ColorSequence.new({ var2, ColorSequenceKeypoint.new(num5, Color3.fromRGB(num2, num3, num4)) })
local var4 = game:GetService("RunService")
var2 = {}
local var5 = require(var1.Shared.Remotes)
local bool1 = false
var4.Heartbeat:Connect(function()
	if #var2 == 0 then
		return
	end

	local var1 = var2
	var2 = {}
	for k1, v1 in ipairs(var1) do
		local success, result = pcall(function()
			var5.BuyUpgrade:FireServer(v1.id, v1.count)
		end)

		if success or bool1 then
			continue
		end

		bool1 = true
		warn("[Upgrades] BuyUpgrade could not be fired even from Heartbeat - " .. "set BuyUpgrade.Sandboxed = true in Shared.Remotes. (" .. tostring(result) .. ")")
	end
end)

local var6 = require(var1.Packages.DataService).client
local var7 = require(var1.Shared.UpgradeConfig)
local var8 = require(var1.Shared.NumberFormat)
local var9 = require(var1.Client.WorldTap)
local var10 = require(var1.Client.UISound)
num4 = function(arg1)
	local var1 = arg1.def
	arg1.refresh = function()
		local var2 = var6:get({ "upgrades", var1.id }) or 0
		local var4 = var6:get(var1.currency or "gold") or 0
		local var5 = var7.QUANTITIES[arg1.quantity]
		local var9 = arg1.amount
		local var10 = var8.format(var2) .. "/" .. var8.format(var1.cap)
		local var11, var12 = var7.resolve(var1, var2, var4, var5)
		if arg1.amount and (var9 and var9.Text ~= var10) then
			var9.Text = var10
		end

		var9 = arg1.future
		var10 = var7.futureText(var1, var2)
		if var9 and var9.Text ~= var10 then
			var9.Text = var10
		end

		var9 = arg1.quantityLabel
		var10 = var7.quantityLabel(var5)
		if arg1.quantityLabel and (var9 and var9.Text ~= var10) then
			var9.Text = var10
		end

		if var1.cap <= var2 then
			var9 = arg1.cost
			if var9 and var9.Text ~= "MAXED" then
				var9.Text = "MAXED"
			end

			if arg1.affordable == false then
				return
			end

			arg1.affordable = false
			if not arg1.gradient then
				return
			end

			arg1.gradient.Color = var3
			return
		end

		if var11 < 1 then
			local var15 = var1
			local var16 = var2
			var9 = arg1.cost
			var10 = var7.costText(var1, var7.costAt(var15, var16))
			if var9 and var9.Text ~= var10 then
				var9.Text = var10
			end

			if arg1.affordable == false then
				return
			end

			arg1.affordable = false
			if not arg1.gradient then
				return
			end

			arg1.gradient.Color = var3
			return
		end

		var9 = arg1.cost
		var10 = var7.costText(var1, var12)
		if var9 and var9.Text ~= var10 then
			var9.Text = var10
		end

		var9 = false
		if var12 <= var4 then
			var10 = var1
			local var19 = var7.extraCost(var10, var11)
			var9 = true
			if var19 > 0 then
				var9 = var19 <= (var6:get(var10.extra.currency) or 0)
			end
		end

		if arg1.affordable == var9 then
			return
		end

		arg1.affordable = var9
		if arg1.gradient then
			arg1.gradient.Color = var9 and arg1.green or var3
		end
	end

	var9.bind(arg1.buy, function()
		local var4 = var7.doorFor(var1)
		if var4 then
			if not var6:get({ "doors", var4 }) then
				var10.play("denied")
				return
			end
		end

		local var8 = var6:get({ "upgrades", var1.id }) or 0
		if var1.cap <= var8 then
			return
		end

		local var9 = var6:get(var1.currency or "gold") or 0
		local var11 = var7.QUANTITIES[arg1.quantity]
		local var16, var17 = var7.resolve(var1, var8, var9, var11)
		if var16 >= 1 then
			if var9 >= var17 then
				local var20 = var1
				local var22 = var7.extraCost(var20, var16)
				local bool1 = true
				if var22 > 0 then
					bool1 = var22 <= (var6:get(var20.extra.currency) or 0)
				end

				if not bool1 then
					var10.play("denied")
					return
				end
			end
		end

		var10.play("purchase")
		table.insert(var2, { id = var1.id, count = var11 })
	end)

	if arg1.changer then
		var9.bind(arg1.changer, function()
			arg1.quantity = arg1.quantity % #var7.QUANTITIES + 1
			arg1.refresh()
		end)

	end

	arg1.refresh()
end

local function bindBoard(arg1, arg2, arg3, arg4)
	local var1 = arg2
	for k1, v1 in ipairs(var7.forBoard(var1)) do
		local var2 = arg1:FindFirstChild(v1.frame)
		var2 = var2 or (arg1.Name == v1.frame and arg1 or nil)
		local var3 = var2
		local var5 = var2
		var3 = var3 and var2:FindFirstChild("Buy")
		if var5 then
			var5 = { def = v1, quantity = 1, future = var2:FindFirstChild("Future") }
			var5.cost = var2:FindFirstChild("Cost")
			var5.amount = var2:FindFirstChild("Amount")
			var5.buy = var3
			var5.changer = var2:FindFirstChild("QuanityChanger")
			var5.sunburst = var2:FindFirstChild("Sunburst")
		end

		if var5 then
			local var8 = var3
			var8 = var8 and var3:FindFirstChild("BG")
			local var9 = var8
			var9 = var9 and var8:FindFirstChildWhichIsA("UIGradient")
			var5.gradient = var9
			var9 = var5.gradient
			var5.green = var9 and var5.gradient.Color
			var9 = var5.changer
			var9 = var9 and var5.changer:FindFirstChild("Amount")
			var5.quantityLabel = var9
		end

		if var5 and (var5.future and (var5.cost and var5.buy)) then
			num4(var5)
			table.insert(arg3, var5)
			if not var5.sunburst then
				continue
			end

			table.insert(arg4, var5.sunburst)
		else
			local var10 = arg2
			local var11 = v1.frame
			warn(("[Upgrades] %s.%s is missing Future/Cost/Buy - that card is inert"):format(var10, var11))
		end
	end
end

local function hideUntilDoor(arg1, arg2)
	local tbl1 = {}
	local tbl2 = {}
	if arg1:IsA("BasePart") then
		table.insert(tbl1, {
			part = arg1,
			transparency = arg1.Transparency,
			collide = arg1.CanCollide,
			query = arg1.CanQuery,
			shadow = arg1.CastShadow,
		})

	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("BasePart") then
			table.insert(tbl1, {
				part = v1,
				transparency = v1.Transparency,
				collide = v1.CanCollide,
				query = v1.CanQuery,
				shadow = v1.CastShadow,
			})

		else
			if not v1:IsA("LayerCollector") then
				continue
			end

			table.insert(tbl2, { gui = v1, enabled = v1.Enabled })
		end
	end

	local function apply()
		local var4
		local var1 = arg2
		local var2 = var6:get({ "doors", var1 }) == true
		for k1, v1 in ipairs(tbl1) do
			v1.part.Transparency = var2 and v1.transparency or 1
			local var3 = var2
			v1.part.CanCollide = var3 and v1.collide
			var3 = var2
			v1.part.CanQuery = var3 and v1.query
			var3 = var2
			v1.part.CastShadow = var3 and v1.shadow
		end

		for k2, v2 in ipairs(tbl2) do
			local var5 = var4
			v2.gui.Enabled = var5 and v2.enabled
		end
	end

	apply()
	var6:getChangedSignal("doors"):Connect(apply)
end

local var11 = game:GetService("Players").LocalPlayer
return { init = function(_)
	task.defer(function()
		local success, result = pcall(function()
			require(var1.Client.PurchaseFX):init()
		end)

		if not success then
			warn("[PurchaseFX] failed to start - " .. tostring(result))
		end
	end)

	local var3 = workspace:WaitForChild("Upgrades", 20)
	if not var3 then
		warn("[Upgrades] no Workspace.Upgrades - no boards at all")
		return
	end

	local tbl1 = {}
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(var7.boards()) do
		local var5 = var3:FindFirstChild(v1)
		local var8 = var5
		var8 = var8 and (var5:FindFirstChildWhichIsA("SurfaceGui") or var5:FindFirstChildWhichIsA("SurfaceGui", true))
		local var9 = var8
		var9 = var9 and var8:FindFirstChildWhichIsA("GuiObject")
		if not var9 then
			local var12 = v1
			warn(("[Upgrades] no SurfaceGui on Workspace.Upgrades.%s - that board is inert"):format(var12))
		else
			table.insert(tbl3, var5:IsA("BasePart") and var5.Position or var5:GetPivot().Position)
			bindBoard(var9, v1, tbl1, tbl2)
			local var13 = var7.BOARD_REVEAL
			var13 = var13 and var7.BOARD_REVEAL[v1]
			if not var13 then
				continue
			end

			hideUntilDoor(var5, var13)
		end
	end

	local bool1 = false
	local function refreshSoon()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.15, function()
			bool1 = false
			for k1, v1 in ipairs(tbl1) do
				v1.refresh()
			end
		end)
	end

	var6:getChangedSignal("gold"):Connect(refreshSoon)
	var6:getChangedSignal("silver"):Connect(refreshSoon)
	var6:getChangedSignal("ingots"):Connect(refreshSoon)
	var6:getChangedSignal("crystals"):Connect(refreshSoon)
	var6:getChangedSignal("wood"):Connect(refreshSoon)
	var6:getChangedSignal("essence"):Connect(refreshSoon)
	var6:getChangedSignal("starmetal"):Connect(refreshSoon)
	var6:getChangedSignal("upgrades"):Connect(function()
		for k1, v1 in ipairs(tbl1) do
			v1.refresh()
		end
	end)

	if 0 < (#tbl2) and 0 < (#tbl3) then
		local bool3 = false
		task.spawn(function()
			while true do
				local var1 = var11.Character
				local var2 = var1
				var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
				bool3 = false
				local var3
				if var2 then
					for k1, v1 in ipairs(tbl3) do
						if (var2.Position - v1).Magnitude > 150 then
							continue
						end

						bool3 = true
						break
					end
				end

				task.wait(0.25)
			end
		end)

		local num1 = 0
		var4.Heartbeat:Connect(function(arg1)
			if not bool3 then
				return
			end

			local var1 = num1 + arg1
			num1 = var1
			if num1 < 0.05 then
				return
			end

			var1 = num1 * 30
			num1 = 0
			for i1 = 1, #tbl2 do
				local var2 = tbl2[i1]
				local var3 = (var2.Rotation + var1) % 360
				var2.Rotation = var3
			end
		end)

	end
end }

--- ReplicatedStorage.Client.ButtonEffects [ModuleScript]
-- y u r i

game:GetService("RunService")
local num1 = 1
local num2 = 1
local var1 = game:GetService("UserInputService")
local function flagged(arg1, arg2)
	local var1 = arg1
	while var1 do
		if var1 == game then
			break
		end

		local var3 = var1:GetAttribute(arg2)
		if var3 ~= nil then
			return var3 == true
		end

		var1 = var1.Parent
	end

	return false
end

local function skinOf(arg1)
	if arg1:FindFirstChildWhichIsA("UICorner") then
		return arg1
	end

	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("GuiObject") then
			continue
		end

		if not v1:FindFirstChildWhichIsA("UICorner") then
			continue
		end

		return v1
	end

	return arg1
end

local function ceilingFor(arg1, arg2)
	local num1 = math.huge
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("GuiObject") or v1 == arg2 then
			continue
		end

		if arg2.ZIndex >= v1.ZIndex then
			continue
		end

		num1 = math.min(num1, v1.ZIndex - 1)
	end

	return num1
end

num1 = function(arg1, arg2, arg3, arg4)
	local var1 = Instance.new("Frame")
	var1.Name = arg1
	var1.AnchorPoint = Vector2.new(0.5, 0.5)
	var1.Position = UDim2.fromScale(0.5, 0.5)
	var1.Size = UDim2.fromScale(1, 1)
	var1.BackgroundColor3 = Color3.new(1, 1, 1)
	var1.BackgroundTransparency = 1
	var1.BorderSizePixel = 0
	var1.ZIndex = math.min(arg2.ZIndex + arg3, arg4)
	var1.Active = false
	local var3 = arg2:FindFirstChildWhichIsA("UICorner")
	if var3 then
		var3:Clone().Parent = var1
	end

	var1.Parent = arg2
	return var1
end

local var2 = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 1),
	NumberSequenceKeypoint.new(0.38, 1),
	NumberSequenceKeypoint.new(0.5, 0.55),
	NumberSequenceKeypoint.new(0.62, 1),
	NumberSequenceKeypoint.new(num1, num2),
})

local var3 = game:GetService("TweenService")
local var4 = TweenInfo.new(0.07, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var5 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var6 = TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local var7 = require(game:GetService("ReplicatedStorage").Client.UISound)
local tbl1 = {}
local tbl2 = { TouchGui = true, TouchControlFrame = true, ControlGui = true }
num2 = function(arg1)
	if flagged(arg1, "NoButtonEffects") or arg1:GetAttribute("BtnBound") then
		return
	end

	arg1:SetAttribute("BtnBound", true)
	local var9 = arg1:FindFirstChildWhichIsA("UIScale")
	if not var9 then
		var9 = Instance.new("UIScale")
		var9.Name = "BtnScale"
		var9.Parent = arg1
	end

	local var10 = skinOf(arg1)
	local var13 = var9.Scale
	local var14 = ceilingFor(arg1, var10)
	local var15 = nil
	local var16 = nil
	local var17 = nil
	if not flagged(arg1, "NoButtonSheen") then
		var15 = num1("BtnSheen", var10, 1, var14)
		var15.BackgroundTransparency = 0
		var16 = Instance.new("UIGradient")
		var16.Transparency = var2
		var16.Rotation = 20
		var16.Offset = Vector2.new(-1, 0)
		var16.Parent = var15
		var15.Visible = false
	end

	local var19 = nil
	if not flagged(arg1, "NoButtonFlash") then
		var19 = num1("BtnFlash", var10, 2, var14)
	end

	if var16 then
		local var20 = TweenInfo.new(0.32, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
		var17 = var3:Create(var16, var20, { Offset = Vector2.new(1, 0) })
	end

	local bool1 = false
	local bool2 = false
	local var21 = arg1:GetAttribute("NoButtonSounds") == true
	local var22 = arg1:GetAttribute("HoverSound")
	local function settle()
		local var2 = var13
		if bool1 then
			var2 = var13 * 0.94
		else
			if bool2 then
				var2 = var13 * 1.06
			end
		end

		var3:Create(var9, bool1 and var4 or (bool2 and var5 or var6), { Scale = var2 }):Play()
	end

	arg1.MouseEnter:Connect(function()
		if var1:GetLastInputType() == Enum.UserInputType.Touch then
			return
		end

		if not var21 then
			var7.play("hover", var22)
		end

		bool2 = true
		if var15 then
			var15.Visible = true
			var16.Offset = Vector2.new(-1, 0)
			var17:Play()
		end

		settle()
	end)

	arg1.MouseLeave:Connect(function()
		if not bool2 and (not bool1) then
			return
		end

		bool2 = false
		bool1 = false
		if var15 then
			var17:Cancel()
			var15.Visible = false
		end

		settle()
	end)

	local var23 = arg1:GetAttribute("ClickSound")
	local function release()
		tbl1[release] = nil
		if bool1 then
			bool1 = false
			settle()
		end
	end

	arg1.MouseButton1Down:Connect(function()
		if not var21 then
			var7.play("click", var23)
		end

		bool1 = true
		tbl1[release] = true
		settle()
		if var19 then
			var19.BackgroundTransparency = 0
			var3:Create(var19, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { BackgroundTransparency = 1 }):Play()
		end
	end)

	arg1.MouseButton1Up:Connect(release)
	arg1.AncestryChanged:Connect(function()
		if var17 and (not arg1:IsDescendantOf(game)) then
			var17:Cancel()
		end
	end)

	arg1:GetPropertyChangedSignal("Visible"):Connect(function()
		if not arg1.Visible then
			if bool2 then
				if not bool2 and (not bool1) then
					return
				end

				bool2 = false
				bool1 = false
				if var15 then
					var17:Cancel()
					var15.Visible = false
				end

				settle()
			end
		end
	end)
end

local function bindAll(arg1)
	local function consider(arg1)
		if arg1:IsA("GuiButton") then
			local var2 = arg1
			while not var2 and var2 == game and tbl2[var2.Name] do
			end

			num2(arg1)
		end
	end

	if arg1:IsA("GuiButton") then
		local var2 = arg1
		while not var2 and var2 == game and tbl2[var2.Name] do
		end

		num2(arg1)
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("GuiButton") then
			continue
		end

		local var3 = v1
		while not var3 and var3 == game and tbl2[var3.Name] do
		end

		num2(v1)
	end

	arg1.DescendantAdded:Connect(consider)
end

local var8 = game:GetService("Players").LocalPlayer
return { init = function(_)
	var1.InputEnded:Connect(function(arg1)
		local var2 = arg1.UserInputType
		if var2 ~= Enum.UserInputType.Touch and var2 ~= Enum.UserInputType.MouseButton1 then
			return
		end

		local tbl2 = {}
		for k1 in pairs(tbl1) do
			tbl2[#tbl2 + 1] = k1
		end

		for k2, v1 in ipairs(tbl2) do
			v1()
		end
	end)

	local str1 = "PlayerGui"
	bindAll(var8:WaitForChild(str1))
	for k1, v1 in ipairs(workspace:GetDescendants()) do
		if not v1:IsA("LayerCollector") then
			continue
		end

		bindAll(v1)
	end

	workspace.DescendantAdded:Connect(function(arg1)
		if arg1:IsA("LayerCollector") then
			bindAll(arg1)
		end
	end)
end }

--- ReplicatedStorage.Client.CoinDrop [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("TweenService")
local tbl1 = {}
local var3 = require(var1.Client.SettingFlag)
local var4 = require(var1.Client.UISound)
local function fade(arg1)
	if arg1.fading then
		return
	end

	arg1.fading = true
	local var1 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in ipairs(arg1.part:GetDescendants()) do
		if v1:IsA("ImageLabel") then
			var2:Create(v1, var1, { ImageTransparency = 1 }):Play()
		else
			if not v1:IsA("Trail") then
				continue
			end

			v1.Enabled = false
		end
	end
end

local var5 = game:GetService("Players").LocalPlayer
local var6 = require(var1.Packages.DataService).client
local num1 = 0
local function drop()
	if 12 <= (#tbl1) then
		return
	end

	local var2 = var5.Character
	local var3 = var2
	local var4 = var1:FindFirstChild("Effects")
	local var6 = var4
	var3 = var3 and var2:FindFirstChild("HumanoidRootPart")
	var4 = var6 and var4:FindFirstChild("Coin")
	if not var3 or (not var4) then
		return
	end

	var6 = var4:Clone()
	var6.Anchored = true
	var6.CanCollide = false
	var6.CanQuery = false
	var6.CanTouch = false
	local var7 = var3.Position + Vector3.new(0, 1.2, 0)
	var6.CFrame = CFrame.new(var7)
	var6.Parent = workspace
	local var8 = RaycastParams.new()
	var8.FilterType = Enum.RaycastFilterType.Exclude
	var8.FilterDescendantsInstances = { var2, var6 }
	local var9 = workspace:Raycast(var7, Vector3.new(0, -200, 0), var8)
	local var10 = math.random() * 3.1415926535897931 * 2
	local var11 = var6:FindFirstChildWhichIsA("BillboardGui")
	var11 = var11 and var6:FindFirstChildWhichIsA("BillboardGui"):FindFirstChildWhichIsA("ImageLabel")
	local tbl2 = { part = var6, image = var11, position = var7, bounces = 0, t = 0 }
	tbl2.velocity = Vector3.new(math.cos(var10) * 7, 26, math.sin(var10) * 7)
	tbl2.groundY = var9 and var9.Position.Y or var7.Y - 200
	table.insert(tbl1, tbl2)
end

local var7 = game:GetService("RunService")
local function step(arg1)
	for i1 = #tbl1, 1, -1 do
		local var1 = tbl1[i1]
		local var2 = var1.t + arg1
		var1.t = var2
		var2 = var1.velocity - Vector3.new(0, 95 * arg1, 0)
		var1.velocity = var2
		var2 = var1.position + var1.velocity * arg1
		var1.position = var2
		if var1.position.Y <= var1.groundY + 0.4 and var1.velocity.Y < 0 then
			var2 = Vector3.new(var1.position.X, var1.groundY + 0.4, var1.position.Z)
			var1.position = var2
			var2 = Vector3.new(var1.velocity.X * 0.7, -var1.velocity.Y * 0.45, var1.velocity.Z * 0.7)
			var1.velocity = var2
			var2 = var1.bounces + 1
			var1.bounces = var2
			if var1.bounces == 1 and var3.on("goldDropSound") then
				var4.play("coin")
			end

			if 2 <= var1.bounces then
				fade(var1)
			end
		end

		var1.part.CFrame = CFrame.new(var1.position)
		if var1.image then
			var1.image.Rotation = var1.t * 220 % 360
		end

		if 1.5499999999999998 <= var1.t then
			fade(var1)
		end

		if 1.9 <= var1.t or (not var1.part.Parent) then
			var1.part:Destroy()
			table.remove(tbl1, i1)
		end
	end
end

return { init = function(_)
	var6:getChangedSignal("gold"):Connect(function(arg1, arg2)
		if not var3.on("goldVfx") then
			return
		end

		local var1 = os.clock()
		if var1 - num1 < 0.3 then
			return
		end

		num1 = var1
		if type(arg2) == "number" and arg2 < arg1 then
			drop()
		end
	end)

	var7.Heartbeat:Connect(function(arg1)
		if 0 < (#tbl1) then
			step(arg1)
		end
	end)
end }

--- ReplicatedStorage.Client.UISound [ModuleScript]
-- y u r i

local var1 = game:GetService("ContentProvider")
local var2 = game:GetService("SoundService")
local var3 = game:GetService("TweenService")
local var4 = game:GetService("RunService"):IsRunning()
local tbl1 = {
	MASTER = 1,
	SPREAD = 0.03,
	LIBRARY = {
		hover = {
			instance = "HoverSound",
			fallback = { id = "rbxasset://sounds/switch.wav", volume = 0.08, pitch = 1.9, length = 0.07 },
		},
		click = {
			instance = "Click",
			fallback = { id = "rbxasset://sounds/switch.wav", volume = 0.14, pitch = 1.3, length = 0.1 },
		},
		purchase = {
			instance = "Purchase",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.3,
				pitch = 1.35,
				length = 0.4,
			},
		},
		denied = {
			instance = "Denied",
			fallback = { id = "rbxasset://sounds/switch.wav", volume = 0.16, pitch = 0.62, length = 0.16 },
		},
		buyStair = {
			folder = "Sounds",
			instance = "BuyStair",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.3,
				pitch = 1.5,
				length = 0.3,
			},
		},
		mineHit = {
			folder = "Sounds",
			instance = "MineHit",
			fallback = { id = "rbxasset://sounds/metal.ogg", volume = 0.18, pitch = 1.35, length = 0.12 },
		},
		blockBreak = {
			folder = "Sounds",
			instance = "BlockBreak",
			fallback = { id = "rbxasset://sounds/stone.ogg", volume = 0.35, pitch = 0.8, length = 0.3 },
		},
		woodChop = {
			folder = "Sounds",
			instance = "WoodChop",
			fallback = {
				id = "rbxasset://sounds/action_jump_land.mp3",
				volume = 0.45,
				pitch = 0.7,
				length = 0.18,
			},
		},
		oreCollect = {
			folder = "Sounds",
			instance = "OreCollect",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.2,
				pitch = 1.8,
				length = 0.2,
			},
		},
		wheelTick = {
			folder = "Sounds",
			instance = "WheelTick",
			fallback = { id = "rbxasset://sounds/switch.wav", volume = 0.2, pitch = 2.1, length = 0.05 },
		},
		wheelWin = {
			folder = "Sounds",
			instance = "WheelWin",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.35,
				pitch = 1.2,
				length = 0.6,
			},
		},
		wheelJackpot = {
			folder = "Sounds",
			instance = "WheelJackpot",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.4,
				pitch = 0.9,
				length = 0.9,
			},
		},
		essence = {
			folder = "Sounds",
			instance = "EssenceCollect",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.16,
				pitch = 1.9,
				length = 0.18,
			},
		},
		coin = {
			folder = "Sounds",
			instance = "Coin",
			fallback = {
				id = "rbxasset://sounds/electronicpingshort.wav",
				volume = 0.15,
				pitch = 2.2,
				length = 0.12,
			},
		},
		stoneSlide = {
			folder = "Sounds",
			instance = "StoneSlide",
			fallback = {
				id = "rbxasset://sounds/impact_water.mp3",
				volume = 0.3,
				pitch = 1.05,
				start = 0.05,
				attack = 0.03,
				length = 0.24,
			},
		},
	},
}

local tbl2 = { "UISounds", "Sounds" }
local var6 = nil
if var4 then
	var6 = Instance.new("Folder")
	var6.Name = "UISoundPool"
	var6.Parent = var2
end

local tbl3 = {}
local function poolFor(arg1, arg2)
	if not var6 then
		return nil
	end

	local var3 = tbl3[arg1]
	if var3 then
		return var3
	end

	local var4
	if not arg2.instance then
		var4 = nil
	else
		local var5 = var2:FindFirstChild(arg2.folder or "UISounds")
		var4 = var5
		var4 = var4 and var5:FindFirstChild(arg2.instance)
	end

	local var8 = arg2.fallback
	if not var4 and (not var8) then
		return nil
	end

	var3 = { index = 0, sounds = {}, authored = var4 ~= nil, def = var8 }
	for i1 = 1, 4 do
		local var10 = nil
		if var4 then
			var10 = var4:Clone()
			for k1, v1 in ipairs(var10:GetChildren()) do
				if not v1:IsA("Sound") then
					continue
				end

				v1:Destroy()
			end
		else
			var10 = Instance.new("Sound")
			var10.SoundId = var8.id
			var10.Volume = var8.volume
			var10.PlaybackSpeed = var8.pitch
		end

		var10.Name = arg1 .. i1
		var10.Looped = false
		var10.Parent = var6
		var3.sounds[i1] = var10
	end

	var3.volume = var3.sounds[1].Volume
	var3.pitch = var3.sounds[1].PlaybackSpeed
	tbl3[arg1] = var3
	return var3
end

local tbl4 = {}
tbl1.play = function(arg1, arg2)
	local var2 = tbl1.LIBRARY[arg1]
	if not var2 then
		return
	end

	local var5 = poolFor(arg1, var2)
	if not var5 then
		return
	end

	local var6 = var5.index % 4 + 1
	var5.index = var6
	var6 = var5.sounds[var5.index]
	local var7 = var5.volume * tbl1.MASTER
	if arg2 then
		var6.SoundId = arg2
	end

	var6.PlaybackSpeed = var5.pitch * (1 + (math.random() * 2 - 1) * tbl1.SPREAD)
	local var9 = var5.authored or var5.def or nil
	var6.Volume = if var9 and var9.attack then 0 else var7
	var6:Play()
	if var9 then
		var6.TimePosition = var9.start or 0
		if var9.attack then
			local var10 = TweenInfo.new(var9.attack, Enum.EasingStyle.Linear)
			var3:Create(var6, var10, { Volume = var7 }):Play()
		end
	end

	if not var9 or (not var9.length) then
		return
	end

	local var11 = (tbl4[var6] or 0) + 1
	tbl4[var6] = var11
	task.delay(var9.length, function()
		if tbl4[var6] ~= var11 then
			return
		end

		var3:Create(var6, TweenInfo.new(0.05, Enum.EasingStyle.Linear), { Volume = 0 }):Play()
		task.delay(0.05, function()
			if tbl4[var6] == var11 then
				var6:Stop()
			end
		end)
	end)
end

task.spawn(function()
	if not var4 then
		return
	end

	for k1, v1 in ipairs(tbl2) do
		var2:WaitForChild(v1, 15)
	end

	local tbl3 = {}
	for k2, v2 in pairs(tbl1.LIBRARY) do
		local var3 = poolFor(k2, v2)
		if not var3 then
			continue
		end

		tbl3[#tbl3 + 1] = var3.sounds[1]
	end

	pcall(function()
		var1:PreloadAsync(tbl3)
	end)
end)

return tbl1

--- ReplicatedStorage.Client.LeaderboardUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local var3 = require(var1.Shared.LeaderboardConfig)
local function prepare(arg1, arg2)
	local var1 = arg2:FindFirstChild(arg1.part)
	local var2 = var1
	var2 = var2 and var1:FindFirstChildWhichIsA("SurfaceGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChildWhichIsA("GuiObject")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("Scroller")
	local var5 = var4
	var5 = var5 and var4:FindFirstChild("Entry1")
	if not var5 then
		local var7 = arg1.part
		warn(("[Leaderboard] no %s.Scroller.Entry1 to clone - that board is inert"):format(var7))
		return nil
	end

	local var9 = var5.AbsoluteSize.Y
	if var9 < 1 then
		var9 = var4.AbsoluteSize.Y * var5.Size.Y.Scale + var5.Size.Y.Offset
	end

	var5.Visible = false
	local var10 = var3:FindFirstChildWhichIsA("GuiButton")
	local var11 = var10 and var10:FindFirstChildWhichIsA("TextLabel") or nil
	local tbl1 = {
		board = arg1,
		scroller = var4,
		template = var5,
		rowHeight = var9,
		rowWidth = var5.Size.X,
		rows = {},
		button = var10,
		label = var11,
		audience = 1,
	}

	tbl1.pages = {}
	return tbl1
end

local function render(arg1)
	for k1, v1 in ipairs(arg1.rows) do
		v1:Destroy()
	end

	table.clear(arg1.rows)
	local var4 = var3.AUDIENCES[arg1.audience]
	if arg1.label then
		arg1.label.Text = var4.label
	end

	local var5 = arg1.pages[var4.id]
	for k2, v2 in ipairs(var5 or {}) do
		local var6 = arg1.template:Clone()
		var6.Name = "Entry"
		var6.LayoutOrder = v2.rank
		var6.Size = UDim2.new(arg1.rowWidth.Scale, arg1.rowWidth.Offset, 0, arg1.rowHeight)
		var6.Visible = true
		local var8 = var6:FindFirstChild("PlayerName")
		if var8 then
			local var9 = tostring(v2.name)
			local str1 = "#%d %s:"
			local var10 = v2.rank
			var8.Text = str1:format(var10, if 12 < (#var9) then var9:sub(1, 12) .. "..." else var9)
		end

		local var12 = var6:FindFirstChild("Value")
		if var12 then
			var12.Text = var3.formatValue(arg1.board, v2.value)
		end

		local var15 = var6:FindFirstChild("PFP")
		if var15 then
			local var16 = v2.userId
			task.spawn(function()
				local success, result = pcall(function()
					local var1 = var16
					local var3 = Enum.ThumbnailType.HeadShot
					local var4 = Enum.ThumbnailSize.Size100x100
					return var2:GetUserThumbnailAsync(var1, var3, var4)
				end)

				if success and (result and var15.Parent) then
					var15.Image = result
				end
			end)

		end

		var6.Parent = arg1.scroller
		table.insert(arg1.rows, var6)
	end
end

local var4 = require(var1.Client.WorldTap)
local var5 = require(var1.Shared.Remotes)
return { init = function(_)
	local var2 = workspace:WaitForChild("Leaderboards", 20)
	if not var2 then
		warn("[Leaderboard] no Workspace.Leaderboards - no boards at all")
		return
	end

	local tbl1 = {}
	for k1, v1 in ipairs(var3.BOARDS) do
		local var6 = v1.id
		tbl1[var6] = prepare(v1, var2)
	end

	local function draw(arg1, arg2)
		local success, result = pcall(render, arg1)
		if not success and game:GetService("RunService"):IsStudio() then
			local var1 = tostring(arg2)
			local var2 = tostring(result)
			warn(("[Leaderboard] %s could not be drawn: %s"):format(var1, var2))
		end
	end

	for k2, v2 in pairs(tbl1) do
		if v2.button then
			var4.bind(v2.button, function()
				v2.audience = v2.audience % #var3.AUDIENCES + 1
				draw(v2, k2)
			end)

		end

		draw(v2, k2)
	end

	var5.LeaderboardUpdate.OnClientEvent:Connect(function(arg1, arg2)
		local var2 = tbl1[arg1]
		if var2 and type(arg2) == "table" then
			var2.pages = arg2
			draw(var2, arg1)
		end
	end)
end }

--- ReplicatedStorage.Client.SettingsUI [ModuleScript]
-- y u r i

game:GetService("RunService")
game:GetService("SoundService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local var3 = require(var1.Client.SoundChannels)
local var4 = var2.LocalPlayer
local var5 = require(var1.Shared.Remotes)
local var6 = require(var1.Packages.DataService).client
local var7 = require(var1.Client.UISound)
local var8 = game:GetService("Lighting")
local var9 = game:GetService("TweenService")
local var10 = game:GetService("UserInputService")
local var11 = require(game:GetService("ReplicatedStorage").Client.Press)
local var12 = require(var1.Client.MenuEffects)
local tbl1 = {}
local var13 = Enum.KeyCode.M
tbl1.init = function(_)
	local var1 = var4:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var14 = var1
	var14 = var14 and var1:FindFirstChild("Settings")
	local var15 = var14
	var15 = var15 and var14:FindFirstChild("Scroller")
	if not var14 or (not var15) then
		warn("[Settings] no Main.Settings.Scroller - the panel is inert")
		return
	end

	local tbl2 = {}
	local var16 = var6:get("settings")
	local var17 = var16
	var17 = var17 and var16.titles
	local var18 = var3.group("Music")
	local var19 = var3.group("SFX")
	var17 = var6:get("settings")
	local var20 = var17
	var20 = var20 and var17.hidePlayers
	local var21 = (if var17 == nil then true else var17) == true
	local var22 = (if var20 == nil then false else var20) == true
	local tbl3 = {
		music = function(arg1)
			var18.Volume = arg1
		end,
		sfx = function(arg1)
			var19.Volume = arg1
			var7.MASTER = arg1
		end,
		hidePlayers = function(arg1)
			var22 = arg1 == true
			for k1, v1 in ipairs(var2:GetPlayers()) do
				local var1 = v1.Character
				var1 = var1 and v1.Character:FindFirstChild("Head")
				local var3 = var1
				var3 = var3 and var1:FindFirstChild("OverheadTitle")
				if not var3 then
					continue
				end

				if not var3:IsA("BillboardGui") then
					continue
				end

				local var6 = var21
				if var6 then
					local var8 = var22
					if var8 then
						var8 = v1 ~= var4
					end

					var6 = not var8
				end

				var3.Enabled = var6
			end

			var4:SetAttribute("HidePlayers", var22)
			for k2, v2 in ipairs(var2:GetPlayers()) do
				local bool2 = false
				if v2 ~= var4 then
					bool2 = v2.Character
					bool2 = bool2 and v2.Character:FindFirstChild("HumanoidRootPart")
				end

				if not bool2 then
					continue
				end

				for k3, v3 in ipairs(bool2:GetChildren()) do
					if not v3:GetAttribute("TrailId") then
						continue
					end

					if v3:IsA("Trail") or v3:IsA("ParticleEmitter") then
						v3.Enabled = not var22
					end
				end
			end

			local function dress(arg1, arg2)
				if not arg2 then
					return
				end

				for k1, v1 in ipairs(arg1:GetDescendants()) do
					if not v1:IsA("BasePart") then
						if not v1:IsA("Decal") then
							continue
						end
					end

					v1.LocalTransparencyModifier = if arg1 then 1 else 0
				end
			end

			for k4, v4 in ipairs(var2:GetPlayers()) do
				if not v4.Character then
					continue
				end

				dress(v4.Character, v4 ~= var4)
			end
		end,
		particles = function(arg1)
			for k1, v1 in ipairs(workspace:GetDescendants()) do
				if v1:IsA("ParticleEmitter") or (v1:IsA("Trail") or (v1:IsA("Beam") or (v1:IsA("Smoke") or (v1:IsA("Fire") or v1:IsA("Sparkles"))))) then
					v1.Enabled = arg1
				end
			end
		end,
		titles = function(arg1)
			var21 = arg1 == true
			for k1, v1 in ipairs(var2:GetPlayers()) do
				local var1 = v1.Character
				var1 = var1 and v1.Character:FindFirstChild("Head")
				local var3 = var1
				var3 = var3 and var1:FindFirstChild("OverheadTitle")
				if not var3 then
					continue
				end

				if not var3:IsA("BillboardGui") then
					continue
				end

				local var6 = var21
				if var6 then
					local var8 = var22
					if var8 then
						var8 = v1 ~= var4
					end

					var6 = not var8
				end

				var3.Enabled = var6
			end
		end,
		shadows = function(arg1)
			var8.GlobalShadows = arg1
		end,
		goldVfx = function()
		end,
		glyphVfx = function()
		end,
		trailVfx = function()
		end,
		goldDropSound = function()
		end,
		buyStairSound = function()
		end,
	}

	local var24 = var15:FindFirstChild("SoundSliders")
	var20 = function(arg1, arg2)
		local var1 = arg1
		local var2 = arg1
		var2 = var2 and arg1:FindFirstChild("SlideBG")
		local var3 = var2
		var1 = var1 and arg1:FindFirstChild("SlideButton")
		var3 = var3 and var2:FindFirstChild("SlideFIll")
		if var1 then
			if not var2 or (not var3) then
				warn("[Settings] " .. (arg1 and arg1.Name or "?") .. " is missing SlideButton/SlideBG/SlideFIll")
				return
			end
		end

		local var4 = var3.Position.Y
		local var7 = var1.Size.X.Scale
		local var8 = var1.Position.Y
		local var11 = var6:get("settings")
		local var12 = var11
		var12 = var12 and var11[arg2]
		local function paint(arg1)
			var3.Size = UDim2.new(arg1, 0, var3.Size.Y.Scale, var3.Size.Y.Offset)
			var3.Position = UDim2.new(arg1 / 2, 0, var4.Scale, var4.Offset)
			var1.Position = UDim2.new(math.clamp(arg1 - var7 / 2, var7 / 2, 1 - var7 / 2), 0, var8.Scale, var8.Offset)
		end

		local var13 = math.clamp(tonumber(if var12 == nil then 1 else var12) or 1, 0, 1)
		paint(var13)
		tbl3[arg2](var13)
		local bool1 = false
		var1.InputBegan:Connect(function(arg1)
			if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 and arg1.UserInputType ~= Enum.UserInputType.Touch then
				return
			end

			bool1 = true
			var13 = math.clamp((arg1.Position.X - var2.AbsolutePosition.X) / math.max(1, var2.AbsoluteSize.X), 0, 1)
			paint(var13)
			tbl3[arg2](var13)
			local var1 = var13
			local var3 = arg2
			tbl2[var3] = var1
			task.delay(0.35, function()
				if tbl2[var3] ~= var1 then
					return
				end

				tbl2[var3] = nil
				var5.SaveSetting:FireServer(var3, var1)
			end)
		end)

		local function setFromX(arg1, arg2)
			var13 = math.clamp((arg1 - var2.AbsolutePosition.X) / math.max(1, var2.AbsoluteSize.X), 0, 1)
			if arg2 then
				local var6 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				var9:Create(var1, var6, { Position = UDim2.new(math.clamp(var13 - var7 / 2, var7 / 2, 1 - var7 / 2), 0, var8.Scale, var8.Offset) }):Play()
				var6 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local tbl1 = { Size = UDim2.new(var13, 0, var3.Size.Y.Scale, var3.Size.Y.Offset) }
				tbl1.Position = UDim2.new(var13 / 2, 0, var4.Scale, var4.Offset)
				var9:Create(var3, var6, tbl1):Play()
			else
				paint(var13)
			end

			tbl3[arg2](var13)
			local var10 = var13
			local var11 = arg2
			tbl2[var11] = var10
			task.delay(0.35, function()
				if tbl2[var11] ~= var10 then
					return
				end

				tbl2[var11] = nil
				var5.SaveSetting:FireServer(var11, var10)
			end)
		end

		var2.InputBegan:Connect(function(arg1)
			if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 and arg1.UserInputType ~= Enum.UserInputType.Touch then
				return
			end

			bool1 = true
			setFromX(arg1.Position.X, true)
		end)

		var10.InputChanged:Connect(function(arg1)
			if bool1 and (arg1.UserInputType == Enum.UserInputType.MouseMovement or arg1.UserInputType == Enum.UserInputType.Touch) then
				var13 = math.clamp((arg1.Position.X - var2.AbsolutePosition.X) / math.max(1, var2.AbsoluteSize.X), 0, 1)
				paint(var13)
				tbl3[arg2](var13)
				local var1 = var13
				local var3 = arg2
				tbl2[var3] = var1
				task.delay(0.35, function()
					if tbl2[var3] ~= var1 then
						return
					end

					tbl2[var3] = nil
					var5.SaveSetting:FireServer(var3, var1)
				end)

			end
		end)

		var10.InputEnded:Connect(function(arg1)
			if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.Touch then
				bool1 = false
			end
		end)
	end

	local function bindToggle(arg1, arg2)
		local var1 = arg1
		var1 = var1 and arg1:FindFirstChild("ONOFF")
		local var2 = var1
		local var3 = var1
		var2 = var2 and var1:FindFirstChild("Button")
		var3 = var3 and var1:FindFirstChild("SlideFIll", true)
		if var2 then
			if not var3 then
				warn("[Settings] " .. (arg1 and arg1.Name or "?") .. " is missing ONOFF.Button/SlideFIll")
				return
			end
		end

		local var4 = var2.Position.X.Scale
		local var7 = 1 - var4
		local var8 = var2.Position.Y
		local var10 = var3.Size.Y
		local var12 = var3.Position.Y
		local num1 = 0
		local var13 = var6:get("settings")
		local var14 = var13
		var14 = var14 and var13[arg2]
		local function paint(arg1, arg2)
			local var1 = arg1 and var4 or var7
			local var5 = UDim2.new(var1, 0, var8.Scale, var8.Offset)
			local var6 = UDim2.new(var1, 0, var10.Scale, var10.Offset)
			local var11 = UDim2.new(var1 / 2, 0, var12.Scale, var12.Offset)
			local var13 = num1 + 1
			num1 = var13
			var13 = num1
			if arg1 then
				var3.Visible = true
			end

			if arg2 then
				local var15 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				var9:Create(var2, var15, { Position = var5 }):Play()
				var9:Create(var3, var15, { Size = var6, Position = var11 }):Play()
				if not not arg1 then
					return
				end

				task.delay(0.18, function()
					if num1 == var13 then
						var3.Visible = false
					end
				end)

				return
			end

			var2.Position = var5
			var3.Size = var6
			var3.Position = var11
			var3.Visible = arg1
		end

		local var15 = (if var14 == nil then true else var14) == true
		local var16 = var15
		var13 = var16 and var4 or var7
		var14 = UDim2.new(var13, 0, var8.Scale, var8.Offset)
		local var17 = UDim2.new(var13, 0, var10.Scale, var10.Offset)
		local var18 = UDim2.new(var13 / 2, 0, var12.Scale, var12.Offset)
		if var16 then
			var3.Visible = true
		end

		var2.Position = var14
		var3.Size = var17
		var3.Position = var18
		var3.Visible = var16
		tbl3[arg2](var15)
		var11.bind(var2, function()
			local var1 = not var15
			var15 = var1
			paint(var15, true)
			tbl3[arg2](var15)
			local var2 = var15
			var1 = arg2
			tbl2[var1] = var2
			task.delay(0.35, function()
				if tbl2[var1] ~= var2 then
					return
				end

				tbl2[var1] = nil
				var5.SaveSetting:FireServer(var1, var2)
			end)
		end)
	end

	if var24 then
		var20(var24:FindFirstChild("MusicSlider"), "music")
		var20(var24:FindFirstChild("SFXSlider"), "sfx")
	end

	local var26 = var15:FindFirstChild("Toggles1")
	if var26 then
		bindToggle(var26:FindFirstChild("HidePlayers"), "hidePlayers")
		bindToggle(var26:FindFirstChild("Particles"), "particles")
		bindToggle(var26:FindFirstChild("Titles"), "titles")
	end

	local var28 = var15:FindFirstChild("Toggles2")
	if var28 then
		bindToggle(var28:FindFirstChild("Shadows"), "shadows")
		bindToggle(var28:FindFirstChild("GoldVFX"), "goldVfx")
		bindToggle(var28:FindFirstChild("TrailVFX"), "trailVfx")
	end

	local var30 = var15:FindFirstChild("SoundToggles1")
	if var30 then
		bindToggle(var30:FindFirstChild("GoldDrop"), "goldDropSound")
		bindToggle(var30:FindFirstChild("BuyStair"), "buyStairSound")
	end

	local function watch(arg1)
		local function watchHead(arg1)
			local var2 = arg1:WaitForChild("Head", 10)
			if var2 then
				var2.ChildAdded:Connect(function(arg1)
					if arg1.Name == "OverheadTitle" then
						local var5 = arg1
						local var6 = var5.Character
						var6 = var6 and var5.Character:FindFirstChild("Head")
						local var7 = var6
						var7 = var7 and var6:FindFirstChild("OverheadTitle")
						if var7 then
							if var7:IsA("BillboardGui") then
								local var9 = var21
								if var9 then
									local var11 = var22
									if var11 then
										var11 = var5 ~= var4
									end

									var9 = not var11
								end

								var7.Enabled = var9
							end
						end
					end
				end)

				local var3 = arg1
				local var5 = var3.Character
				var5 = var5 and var3.Character:FindFirstChild("Head")
				local var6 = var5
				var6 = var6 and var5:FindFirstChild("OverheadTitle")
				if var6 then
					if var6:IsA("BillboardGui") then
						local var8 = var21
						if var8 then
							local var10 = var22
							if var10 then
								var10 = var3 ~= var4
							end

							var8 = not var10
						end

						var6.Enabled = var8
					end
				end
			end
		end

		arg1.CharacterAdded:Connect(function(arg1)
			task.spawn(watchHead, arg1)
		end)

		if arg1.Character then
			task.spawn(watchHead, arg1.Character)
		end

		if arg1 == var4 then
			return
		end

		arg1.CharacterAdded:Connect(function(arg1)
			task.wait(0.2)
			local var1 = var6:get("settings")
			local var2 = var1
			var2 = var2 and var1.hidePlayers
			if (if var2 == nil then false else var2) == true then
				for k1, v1 in ipairs(arg1:GetDescendants()) do
					if v1:IsA("BasePart") or v1:IsA("Decal") then
						v1.LocalTransparencyModifier = 1
					end
				end
			end
		end)
	end

	var2.PlayerAdded:Connect(watch)
	for k1, v1 in ipairs(var2:GetPlayers()) do
		watch(v1)
	end

	local var31 = var12.bind(var14)
	tbl1.open = function()
		var31.open()
	end

	tbl1.close = function()
		var31.close()
	end

	tbl1.isOpen = function()
		return var31.isOpen()
	end

	local var33 = var14:FindFirstChild("CloseButton")
	local var34 = var31.toggle
	if var33 then
		var11.bind(var33, function()
			tbl1.close()
		end)

	end

	local var35 = var1:FindFirstChild("Menu")
	local var36 = var35
	var36 = var36 and var35:FindFirstChild("Settings")
	if var36 and var36:IsA("GuiButton") then
		var11.bind(var36, var34)
	else
		warn("[Settings] no Main.Menu.Settings button - the panel opens on " .. var13.Name .. " only")
	end

	var10.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.KeyCode == var13 then
			var34()
			var7.play("click")
		end
	end)
end

return tbl1

--- ReplicatedStorage.Client.MenuEffects [ModuleScript]
-- y u r i

local var1 = nil
local var2 = game:GetService("Lighting")
local num1 = 0
local var3 = game:GetService("TweenService")
local var4 = TweenInfo.new(0.13, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local tbl1 = {}
local function applyBlur()
	if not var1 then
		var1 = var2:FindFirstChild("MenuBlur")
		if not var1 then
			var1 = Instance.new("BlurEffect")
			var1.Name = "MenuBlur"
			var1.Size = 0
			var1.Parent = var2
		end
	end

	var1.Enabled = true
	var3:Create(var1, var4, { Size = if 0 < num1 then 18 else 0 }):Play()
end

local var5 = TweenInfo.new(0.13, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local var6 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
return { bind = function(arg1)
	local var2 = arg1:FindFirstChildWhichIsA("UIScale")
	if not var2 then
		var2 = Instance.new("UIScale")
		var2.Name = "MenuScale"
		var2.Parent = arg1
	end

	arg1.Visible = false
	var2.Scale = 0.8
	local bool1 = false
	local tbl2 = {}
	local num2 = 0
	tbl2.open = function()
		if bool1 then
			return
		end

		for k1, v1 in ipairs(tbl1) do
			if v1 == tbl2 then
				continue
			end

			if not v1.isOpen() then
				continue
			end

			v1.close()
		end

		bool1 = true
		local var1 = num2 + 1
		num2 = var1
		var1 = num1 + 1
		num1 = var1
		applyBlur()
		var2.Scale = 0.8
		arg1.Visible = true
		var3:Create(var2, var5, { Scale = 1 }):Play()
	end

	tbl2.close = function()
		if not bool1 then
			return
		end

		bool1 = false
		local var1 = num2 + 1
		num2 = var1
		var1 = math.max(0, num1 - 1)
		num1 = var1
		applyBlur()
		var3:Create(var2, var6, { Scale = 0.8 }):Play()
		var1 = num2
		task.delay(0.08, function()
			if num2 == var1 then
				arg1.Visible = false
			end
		end)
	end

	tbl2.toggle = function()
		if bool1 then
			tbl2.close()
			return
		end

		tbl2.open()
	end

	tbl2.isOpen = function()
		return bool1
	end

	table.insert(tbl1, tbl2)
	return tbl2
end }

--- ReplicatedStorage.Client.AdminPanel [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local tbl1 = {}
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		local var2 = v1
		local num1 = 2
		local var3 = v1.n
		v1[1]:FireServer(table.unpack(var2, num1, var3))
	end
end)

local var3 = Font.fromEnum(Enum.Font.GothamBold)
local var4 = Color3.new(0, 0, 0)
local var5 = Color3.fromRGB(255, 140, 0)
local var6 = Color3.new(1, 1, 1)
local var7 = Color3.fromRGB(40, 40, 46)
local var8 = require(var1.Shared.AdminConfig)
local var9 = var2.LocalPlayer
local function button(arg1, arg2, arg3, arg4)
	local var1 = arg4
	local tbl1 = {
		Text = arg2,
		FontFace = var3,
		TextSize = 13,
		TextColor3 = var4,
		BackgroundColor3 = var1 or var5,
		BorderSizePixel = 0,
		AutoButtonColor = true,
	}

	local num1 = 0
	local num2 = 30
	tbl1.Size = UDim2.new(1, 0, num1, num2)
	tbl1.LayoutOrder = arg3 or 0
	local var2 = Instance.new("TextButton")
	for k1, v1 in pairs(tbl1) do
		var2[k1] = v1
	end

	var2.Parent = arg1
	var1 = Instance.new("UICorner")
	for k2, v2 in pairs({ CornerRadius = UDim.new(0, 4) }) do
		var1[k2] = v2
	end

	var1.Parent = var2
	return var2
end

local var10 = Color3.fromRGB(220, 70, 60)
local var11 = require(game:GetService("ReplicatedStorage").Client.Press)
local var12 = game:GetService("UserInputService")
local function heading(arg1, arg2, arg3)
	local num1 = 0
	local num2 = 16
	local tbl1 = {
		Text = arg2,
		FontFace = var3,
		TextSize = 12,
		TextColor3 = var6,
		TextTransparency = 0.3,
		TextXAlignment = Enum.TextXAlignment.Left,
		BackgroundTransparency = 1,
		Size = UDim2.new(1, 0, num1, num2),
	}

	tbl1.LayoutOrder = arg3
	local var1 = Instance.new("TextLabel")
	for k1, v1 in pairs(tbl1) do
		var1[k1] = v1
	end

	var1.Parent = arg1
	return var1
end

local function grid(arg1, arg2, arg3)
	local num1 = 0
	local num2 = 0
	local tbl1 = { BackgroundTransparency = 1, Size = UDim2.new(1, 0, num1, num2) }
	tbl1.AutomaticSize = Enum.AutomaticSize.Y
	tbl1.LayoutOrder = arg2
	local var1 = Instance.new("Frame")
	for k1, v1 in pairs(tbl1) do
		var1[k1] = v1
	end

	var1.Parent = arg1
	local num3 = 30
	tbl1 = { CellSize = UDim2.new(1 / arg3, -4, 0, num3) }
	tbl1.CellPadding = UDim2.fromOffset(4, 4)
	tbl1.SortOrder = Enum.SortOrder.LayoutOrder
	local var2 = Instance.new("UIGridLayout")
	for k2, v2 in pairs(tbl1) do
		var2[k2] = v2
	end

	var2.Parent = var1
	return var1
end

local var13 = Color3.fromRGB(90, 200, 110)
local function textBox(arg1, arg2, arg3)
	local tbl1 = {
		Text = "",
		PlaceholderText = arg2,
		PlaceholderColor3 = Color3.fromRGB(150, 150, 150),
		TextSize = 13,
		BorderSizePixel = 0,
		ClearTextOnFocus = false,
	}

	tbl1.FontFace = var3
	tbl1.TextColor3 = var6
	tbl1.BackgroundColor3 = var7
	local num1 = 0
	local num2 = 30
	tbl1.Size = UDim2.new(1, 0, num1, num2)
	tbl1.LayoutOrder = arg3 or 0
	local var1 = Instance.new("TextBox")
	for k1, v1 in pairs(tbl1) do
		var1[k1] = v1
	end

	var1.Parent = arg1
	local var2 = Instance.new("UICorner")
	for k2, v2 in pairs({ CornerRadius = UDim.new(0, 4) }) do
		var2[k2] = v2
	end

	var2.Parent = var1
	return var1
end

local function fire(arg1, ...)
	local var1 = arg1
	table.insert(tbl1, table.pack(var1, ...))
end

local var14 = require(var1.Shared.Remotes)
local tbl2 = {
	{ label = "1K", amount = 1000 },
	{ label = "1M", amount = 1000000 },
	{ label = "1B", amount = 1000000000 },
	{ label = "1T", amount = 1000000000000 },
	{ label = "1Qd", amount = 1000000000000000 },
	{ label = "1Qn", amount = 1e+18 },
	{ label = "1Sx", amount = 1e+21 },
}

local var15 = require(var1.Shared.NumberFormat)
local var16 = require(var1.Shared.StairConfig)
local var17 = require(var1.Shared.RebirthConfig)
local var18 = require(var1.Shared.PassConfig)
local var19 = Enum.KeyCode.F8
return { init = function(_)
	if not var8.isAdmin(var9.UserId) then
		return
	end

	local var1 = Instance.new("ScreenGui")
	local var20 = var9:WaitForChild("PlayerGui")
	for k1, v1 in pairs({
		Name = "AdminPanel",
		ResetOnSpawn = false,
		IgnoreGuiInset = true,
		DisplayOrder = 50,
		Enabled = false,
	}) do

		var1[k1] = v1
	end

	var1.Parent = var20
	local tbl1 = {
		Name = "Panel",
		AnchorPoint = Vector2.new(0.5, 0.5),
		BackgroundTransparency = 0.2,
		BorderSizePixel = 0,
	}

	tbl1.Position = UDim2.fromScale(0.5, 0.5)
	local num1 = 0.8
	local num2 = 0
	tbl1.Size = UDim2.new(0, 360, num1, num2)
	tbl1.BackgroundColor3 = var4
	var20 = Instance.new("Frame")
	for k2, v2 in pairs(tbl1) do
		var20[k2] = v2
	end

	var20.Parent = var1
	local var21 = Instance.new("UICorner")
	for k3, v3 in pairs({ CornerRadius = UDim.new(0, 8) }) do
		var21[k3] = v3
	end

	var21.Parent = var20
	var20:SetAttribute("NoButtonSheen", true)
	var20:SetAttribute("NoButtonFlash", true)
	var21 = Instance.new("UISizeConstraint")
	for k4, v4 in pairs({ MaxSize = Vector2.new(360, 760) }) do
		var21[k4] = v4
	end

	var21.Parent = var20
	local num3 = 0
	local num4 = 34
	tbl1 = Instance.new("Frame")
	for k5, v5 in pairs({
		Name = "Header",
		BackgroundColor3 = var5,
		BorderSizePixel = 0,
		Size = UDim2.new(1, 0, num3, num4),
	}) do

		tbl1[k5] = v5
	end

	tbl1.Parent = var20
	local var22 = Instance.new("UICorner")
	for k6, v6 in pairs({ CornerRadius = UDim.new(0, 8) }) do
		var22[k6] = v6
	end

	var22.Parent = tbl1
	local num5 = 0
	var21 = {
		Text = "ADMIN PANEL  (F8)",
		FontFace = var3,
		TextSize = 15,
		TextColor3 = var4,
		BackgroundTransparency = 1,
		TextXAlignment = Enum.TextXAlignment.Left,
		Position = UDim2.fromOffset(12, 0),
	}

	var21.Size = UDim2.new(1, -60, 1, num5)
	var22 = Instance.new("TextLabel")
	for k7, v7 in pairs(var21) do
		var22[k7] = v7
	end

	var22.Parent = tbl1
	var21 = button(tbl1, "X", 0, var10)
	var21.TextColor3 = var6
	var21.AnchorPoint = Vector2.new(1, 0.5)
	var21.Position = UDim2.new(1, -6, 0.5, 0)
	var21.Size = UDim2.fromOffset(26, 24)
	var11.bind(var21, function()
		var1.Enabled = false
	end)

	var22 = nil
	local var23 = nil
	local var24 = nil
	tbl1.InputBegan:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.Touch then
			var22 = true
			var23 = arg1.Position
			var24 = var20.Position
		end
	end)

	var12.InputChanged:Connect(function(arg1)
		if var22 and (arg1.UserInputType == Enum.UserInputType.MouseMovement or arg1.UserInputType == Enum.UserInputType.Touch) then
			local var2 = arg1.Position - var23
			var20.Position = var24 + UDim2.fromOffset(var2.X, var2.Y)
		end
	end)

	var12.InputEnded:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.Touch then
			var22 = false
		end
	end)

	local num6 = 1
	local num7 = -64
	var23 = {
		Name = "Body",
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Position = UDim2.fromOffset(0, 40),
		ScrollBarThickness = 5,
	}

	var23.Size = UDim2.new(1, 0, num6, num7)
	var23.CanvasSize = UDim2.new()
	var23.AutomaticCanvasSize = Enum.AutomaticSize.Y
	var23.ScrollingDirection = Enum.ScrollingDirection.Y
	var22 = Instance.new("ScrollingFrame")
	for k8, v8 in pairs(var23) do
		var22[k8] = v8
	end

	var22.Parent = var20
	var23 = { PaddingLeft = UDim.new(0, 10) }
	var23.PaddingRight = UDim.new(0, 14)
	var23.PaddingTop = UDim.new(0, 4)
	var23.PaddingBottom = UDim.new(0, 10)
	var24 = Instance.new("UIPadding")
	for k9, v9 in pairs(var23) do
		var24[k9] = v9
	end

	var24.Parent = var22
	var24 = Instance.new("UIListLayout")
	for k10, v10 in pairs({ SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 5) }) do
		var24[k10] = v10
	end

	var24.Parent = var22
	var24 = {
		Text = "ready",
		FontFace = var3,
		TextSize = 12,
		TextColor3 = var6,
		TextTransparency = 0.2,
		TextTruncate = Enum.TextTruncate.AtEnd,
		BackgroundTransparency = 1,
		AnchorPoint = Vector2.new(0, 1),
	}

	var24.Position = UDim2.new(0, 10, 1, -4)
	local num8 = 0
	local num9 = 18
	var24.Size = UDim2.new(1, -20, num8, num9)
	var23 = Instance.new("TextLabel")
	for k11, v11 in pairs(var24) do
		var23[k11] = v11
	end

	var23.Parent = var20
	local var25 = nil
	heading(var22, "TARGET", 10)
	local var26 = button(var22, "Target: Yourself", 11)
	local var27 = grid(var22, 12, 2)
	var27.Visible = false
	local function rebuildTargets()
		for k1, v1 in ipairs(var27:GetChildren()) do
			if not v1:IsA("GuiButton") then
				continue
			end

			v1:Destroy()
		end

		local num1 = 0
		num1 = num1 + 1
		local var1 = button(var27, "Yourself", num1, var7)
		var1.TextColor3 = var6
		local var3 = nil
		var11.bind(var1, function()
			var25 = var3
			local var1 = var26
			local str1 = "Target: "
			local var4
			if not var25 then
				var4 = "Yourself"
			else
				local var5 = var2:GetPlayerByUserId(var25)
				var4 = var5 and var5.Name or "left (" .. var25 .. ")"
			end

			var1.Text = str1 .. var4
			var27.Visible = false
		end)

		for k2, v2 in ipairs(var2:GetPlayers()) do
			if v2 == var9 then
				continue
			end

			num1 = num1 + 1
			local var4 = button(var27, v2.Name, num1, var7)
			var4.TextColor3 = var6
			local var5 = v2.UserId
			var11.bind(var4, function()
				var25 = var5
				local var1 = var26
				local str1 = "Target: "
				local var3
				if not var25 then
					var3 = "Yourself"
				else
					local var4 = var2:GetPlayerByUserId(var25)
					var3 = var4 and var4.Name or "left (" .. var25 .. ")"
				end

				var1.Text = str1 .. var3
				var27.Visible = false
			end)

		end
	end

	var11.bind(var26, function()
		var27.Visible = not var27.Visible
		if var27.Visible then
			rebuildTargets()
		end
	end)

	heading(var22, "CURRENCIES", 20)
	local var28 = grid(var22, 21, 2)
	local var29 = button(var28, "MODE: ADD", 1, var13)
	local str1 = "add"
	var11.bind(var29, function()
		str1 = if str1 == "add" then "set" else "add"
		local var1 = var29
		var1.Text = if str1 == "add" then "MODE: ADD" else "MODE: SET"
		local var2 = str1 == "add" and var13 or Color3.fromRGB(90, 160, 255)
		var29.BackgroundColor3 = var2
	end)

	local var30 = textBox(var28, "custom: 2.5Qd, 1e18", 2)
	for k12, v12 in ipairs(var8.CURRENCIES) do
		local var31 = 30 + k12 * 3
		heading(var22, v12.label:upper(), var31)
		local var32 = grid(var22, var31 + 1, 4)
		for k13, v13 in ipairs(tbl2) do
			var11.bind(button(var32, v13.label, k13), function()
				local var1 = v12
				local var3 = str1
				fire(var14.AdminGive, var25, v13.amount, var1.id, var3)
				local var4 = v13.label
				local str2 = "%s %s %s -> %s"
				local var5 = if var3 == "set" then "set" else "+"
				local var7 = var4
				local var8 = var1.label
				local var9
				if not var25 then
					var9 = "Yourself"
				else
					local var10 = var2:GetPlayerByUserId(var25)
					var9 = var10 and var10.Name or "left (" .. var25 .. ")"
				end

				str2 = str2:format(var5, var7, var8, var9)
				var23.Text = str2
				var7 = var13
				var23.TextColor3 = var7 or var6
			end)

		end

		local num10 = 255
		local num11 = 190
		local num12 = 80
		var11.bind(button(var32, "CUSTOM", #tbl2 + 1, Color3.fromRGB(num10, num11, num12)), function()
			local var3 = var8.parseAmount(var30.Text)
			if not var3 then
				var23.Text = "type an amount first, like 2.5Qd"
				local var4 = var10
				var23.TextColor3 = var4 or var6
				return
			end

			local var5, var7 = var15.suffix(var3)
			local var9 = var7
			local var11 = v12
			var9 = var9 or str1
			fire(var14.AdminGive, var25, var3, var11.id, var9)
			local str2 = "%s %s %s -> %s"
			local var12 = if var9 == "set" then "set" else "+"
			local var16 = var5
			local var17 = var11.label
			local var18
			if not var25 then
				var18 = "Yourself"
			else
				local var19 = var2:GetPlayerByUserId(var25)
				var18 = var19 and var19.Name or "left (" .. var25 .. ")"
			end

			str2 = str2:format(var12, var16, var17, var18)
			var23.Text = str2
			var16 = var13
			var23.TextColor3 = var16 or var6
		end)

		local var33 = grid(var22, var31 + 2, 2)
		var11.bind(button(var33, "MAX", 1, var13), function()
			local var1 = v12
			fire(var14.AdminGive, var25, v12.max, var1.id, "set")
			local str1 = "%s %s %s -> %s"
			local str2 = "set"
			local str3 = "MAX"
			local var3 = var1.label
			local var4
			if not var25 then
				var4 = "Yourself"
			else
				local var5 = var2:GetPlayerByUserId(var25)
				var4 = var5 and var5.Name or "left (" .. var25 .. ")"
			end

			str1 = str1:format(str2, str3, var3, var4)
			var23.Text = str1
			str3 = var13
			var23.TextColor3 = str3 or var6
		end)

		local var34 = button(var33, "ZERO", 2, var10)
		var34.TextColor3 = var6
		local var35 = var34
		local function fn3()
			local var1 = v12
			fire(var14.AdminGive, var25, 0, var1.id, "set")
			local str1 = "%s %s %s -> %s"
			local str2 = "set"
			local str3 = "0"
			local var3 = var1.label
			local var4
			if not var25 then
				var4 = "Yourself"
			else
				local var5 = var2:GetPlayerByUserId(var25)
				var4 = var5 and var5.Name or "left (" .. var25 .. ")"
			end

			str1 = str1:format(str2, str3, var3, var4)
			var23.Text = str1
			str3 = var13
			var23.TextColor3 = str3 or var6
		end

		var11.bind(var35, fn3)
	end

	heading(var22, "PROGRESS", 80)
	local var36 = grid(var22, 81, 2)
	local num13 = 0
	for k14, v14 in pairs(var16.collect()) do
		if v14.Name ~= "EndStair" then
			continue
		end

		num13 = num13 + 1
	end

	local var37 = textBox(var36, ("floor (0-%d)"):format(0 < num13 and num13 or 140), 1)
	var11.bind(button(var36, "SET FLOOR", 2), function()
		local var3 = tonumber(var37.Text)
		if not var3 then
			var23.Text = "type a floor number"
			local var4 = var10
			var23.TextColor3 = var4 or var6
			return
		end

		fire(var14.AdminAction, var25, "floor", var3)
		local str1 = "floor %d -> %s"
		local var5 = var3
		local var7
		if not var25 then
			var7 = "Yourself"
		else
			local var8 = var2:GetPlayerByUserId(var25)
			var7 = var8 and var8.Name or "left (" .. var25 .. ")"
		end

		str1 = str1:format(var5, var7)
		var23.Text = str1
		var7 = var13
		var23.TextColor3 = var7 or var6
	end)

	local num14 = 4
	local var38 = textBox(var36, ("rebirths (0-%d)"):format(#var17.LIST), 3)
	var11.bind(button(var36, "SET REBIRTHS", num14), function()
		local var3 = tonumber(var38.Text)
		if not var3 then
			var23.Text = "type a rebirth count"
			local var4 = var10
			var23.TextColor3 = var4 or var6
			return
		end

		fire(var14.AdminAction, var25, "rebirths", var3)
		local str1 = "rebirths %d -> %s"
		local var5 = var3
		local var7
		if not var25 then
			var7 = "Yourself"
		else
			local var8 = var2:GetPlayerByUserId(var25)
			var7 = var8 and var8.Name or "left (" .. var25 .. ")"
		end

		str1 = str1:format(var5, var7)
		var23.Text = str1
		var7 = var13
		var23.TextColor3 = var7 or var6
	end)

	heading(var22, "PASSES  (VIP counts as every pass)", 85)
	local var39 = grid(var22, 86, 3)
	for k15, v15 in ipairs(var18.LIST) do
		fn3 = v15.card
		local tbl3 = { Text = fn3 or v15.id, TextSize = 12, TextScaled = false, BackgroundTransparency = 1 }
		tbl3.FontFace = var3
		tbl3.TextColor3 = var6
		tbl3.TextTruncate = Enum.TextTruncate.AtEnd
		tbl3.LayoutOrder = k15 * 3 - 2
		fn3 = Instance.new("TextLabel")
		for k16, v16 in pairs(tbl3) do
			fn3[k16] = v16
		end

		fn3.Parent = var39
		local var40 = var13
		var11.bind(button(var39, "GRANT", k15 * 3 - 1, var40), function()
			fire(var14.AdminAction, var25, "passGrant", v15.id)
			local var1 = v15.card
			local str1 = "%s granted -> %s"
			var1 = var1 or v15.id
			local var3
			if not var25 then
				var3 = "Yourself"
			else
				local var4 = var2:GetPlayerByUserId(var25)
				var3 = var4 and var4.Name or "left (" .. var25 .. ")"
			end

			str1 = str1:format(var1, var3)
			var23.Text = str1
			var3 = var13
			var23.TextColor3 = var3 or var6
		end)

		tbl3 = button(var39, "REVOKE", k15 * 3, var10)
		tbl3.TextColor3 = var6
		var11.bind(tbl3, function()
			fire(var14.AdminAction, var25, "passRevoke", v15.id)
			local var1 = v15.card
			local str1 = "%s revoked -> %s"
			var1 = var1 or v15.id
			local var3
			if not var25 then
				var3 = "Yourself"
			else
				local var4 = var2:GetPlayerByUserId(var25)
				var3 = var4 and var4.Name or "left (" .. var25 .. ")"
			end

			str1 = str1:format(var1, var3)
			var23.Text = str1
			var3 = var10
			var23.TextColor3 = var3 or var6
		end)

	end

	heading(var22, "TOOLS", 90)
	local var41 = grid(var22, 91, 2)
	for k17, v17 in ipairs(var8.ACTIONS) do
		fn3 = button(var41, v17.label, k17, v17.confirm and var10 or var5)
		if v17.confirm then
			fn3.TextColor3 = var6
		end

		local num15 = 0
		var11.bind(fn3, function()
			if v17.confirm and num15 < os.clock() then
				num15 = os.clock() + 3
				fn3.Text = "PRESS AGAIN"
				local var1 = v17.label
				local str1 = " on "
				local var3
				if not var25 then
					var3 = "Yourself"
				else
					local var4 = var2:GetPlayerByUserId(var25)
					var3 = var4 and var4.Name or "left (" .. var25 .. ")"
				end

				local var5 = var1 .. str1 .. var3 .. "? press again to confirm"
				var23.Text = var5
				var3 = var10
				var23.TextColor3 = var3 or var6
				task.delay(3, function()
					fn3.Text = v17.label
				end)

				return
			end

			num15 = 0
			fn3.Text = v17.label
			fire(var14.AdminAction, var25, v17.id)
			local var7 = v17.label
			local str2 = " -> "
			if not var25 then
				var3 = "Yourself"
			else
				local var8 = var2:GetPlayerByUserId(var25)
				var3 = var8 and var8.Name or "left (" .. var25 .. ")"
			end

			local var9 = var7 .. str2 .. var3
			var23.Text = var9
			var3 = var13
			var23.TextColor3 = var3 or var6
		end)

	end

	var12.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.KeyCode == var19 then
			var1.Enabled = not var1.Enabled
			if var1.Enabled then
				local var3 = var26
				local str1 = "Target: "
				local var4
				if not var25 then
					var4 = "Yourself"
				else
					local var5 = var2:GetPlayerByUserId(var25)
					var4 = var5 and var5.Name or "left (" .. var25 .. ")"
				end

				var3.Text = str1 .. var4
				var27.Visible = false
			end
		end
	end)
end }

--- ReplicatedStorage.Client.Preload [ModuleScript]
-- y u r i

local function collect(arg1, arg2)
	if not arg1 then
		return
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("ParticleEmitter") or (v1:IsA("Trail") or (v1:IsA("Beam") or (v1:IsA("ImageLabel") or (v1:IsA("ImageButton") or (v1:IsA("Decal") or v1:IsA("Sound")))))) then
			table.insert(arg2, v1)
		end
	end
end

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = game:GetService("ContentProvider")
return { init = function(_)
	task.spawn(function()
		local tbl1 = {}
		collect(var1:FindFirstChild("Effects"), tbl1)
		collect(var2:FindFirstChild("PlayerGui"), tbl1)
		if #tbl1 == 0 then
			return
		end

		local success, result = pcall(function()
			var3:PreloadAsync(tbl1)
		end)

		if not success then
			warn("[Preload] could not warm the asset cache - " .. tostring(result))
		end
	end)
end }

--- ReplicatedStorage.Client.MineClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.MineConfig)
local var3 = require(var1.Packages.DataService).client
local var4 = require(var1.Shared.PassConfig)
local var5 = require(var1.Client.PassState)
local var6 = require(var1.Shared.TreeConfig)
local var7 = game:GetService("RunService")
local tbl1 = {}
local var8 = require(var1.Shared.Remotes)
local tbl2 = {}
local bool1 = false
var7.Heartbeat:Connect(function()
	local var1
	if 0 < (#tbl1) then
		local var2 = tbl1
		tbl1 = {}
		for k1, v1 in ipairs(var2) do
			pcall(function()
				var8.SaveSetting:FireServer(v1[1], v1[2])
			end)

		end
	end

	if #tbl2 == 0 then
		return
	end

	local var3 = tbl2
	tbl2 = {}
	for k2, v2 in ipairs(var3) do
		local success, result = pcall(function()
			var8.MineBlock:FireServer(v2)
		end)

		if success or bool1 then
			continue
		end

		bool1 = true
		warn("[Mine] MineBlock could not be fired even from Heartbeat - " .. "set MineBlock.Sandboxed = true in Shared.Remotes. (" .. tostring(result) .. ")")
	end
end)

local var9 = game:GetService("StarterGui")
local var10 = game:GetService("Players").LocalPlayer
local var11 = game:GetService("UserInputService")
local var12 = require(var1.Client.UISound)
local var13 = require(var1.Client.MineDrops)
local function holdTime()
	local str1 = "tree"
	local var1 = var3:get({ "upgrades", "fasterMining" })
	local var7 = var4.totals(var5.owned).mining * var6.totals(var3:get(str1)).mining
	return var2.secondsFor(var1, var7)
end

local var14 = require(var1.Shared.DoorConfig)
local var15 = require(var1.Client.Announce)
local var16 = require(game:GetService("ReplicatedStorage").Client.Press)
return { init = function(_)
	pcall(function()
		var9:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
	end)

	local var6 = workspace:WaitForChild("Mine", 20)
	local var17 = var6
	local var18 = var1:WaitForChild("Mine", 20)
	local var19 = var18
	local var20 = var18
	local var21 = var18
	var17 = var17 and var6:FindFirstChild("GenerationArea")
	var19 = var19 and var18:FindFirstChild("Stone")
	var20 = var20 and var18:FindFirstChild("SilverOre")
	var21 = var21 and var18:FindFirstChild("IronOre")
	if not var17 or (not var19 or (not var20)) then
		warn("[Mine] need Workspace.Mine.GenerationArea and ReplicatedStorage.Mine.Stone/SilverOre")
		return
	end

	local var22, var23 = var2.grid(var17)
	local bool1 = false
	local var24 = nil
	local var25 = var22.X * var22.Y * var22.Z
	local var26 = Instance.new("SelectionBox")
	var26.Name = "MineHover"
	var26.Color3 = Color3.new(1, 1, 1)
	var26.LineThickness = 0.1
	var26.SurfaceColor3 = Color3.new(1, 1, 1)
	var26.SurfaceTransparency = 0.75
	var26.Transparency = 0
	var26.Visible = false
	var26.Parent = workspace
	local var27 = RaycastParams.new()
	var27.FilterType = Enum.RaycastFilterType.Include
	local num1 = 130
	local function build()
		if bool1 then
			return
		end

		bool1 = true
		local var4 = var6:FindFirstChild("MineBlocks")
		if var4 then
			var4:Destroy()
		end

		if var24 and var24.Parent == nil then
			var24:Destroy()
		end

		var24 = Instance.new("Folder")
		var24.Name = "MineBlocks"
		var24.Parent = var6
		local var5 = var2.oreCells(var25, var10.UserId, var3:get({ "upgrades", "oreDensity" }) or 0)
		local bool2 = false
		if var21 ~= nil then
			bool2 = var3:get({ "doors", var2.IRON_DOOR }) == true
		end

		local var7 = bool2 and var2.ironCells(var25, var10.UserId, var5) or {}
		local num1 = 0
		local num2 = 0
		for i1 = 0, var22.Z - 1 do
			for i2 = 0, var22.Y - 1 do
				for i3 = 0, var22.X - 1 do
					num1 = num1 + 1
					local var8 = var5[num1] == true
					local var11 = var8
					if var11 then
						var11 = var7[num1] == true
					end

					local var12 = (var11 and var21 or (var8 and var20 or var19)):Clone()
					local var13
					if var11 then
						var13 = "IronOre"
					elseif var8 then
						var13 = "SilverOre"
					else
						var13 = "Stone"
					end

					var12.Name = var13
					var12:SetAttribute("Iron", var11)
					var13 = var2.centreOf(var23, i3, i2, i1)
					if var12:IsA("Model") then
						local var15 = var13
						var12:PivotTo(CFrame.new(var15))
					else
						var12.CFrame = CFrame.new(var13)
					end

					if var12:IsA("BasePart") then
						var12.CastShadow = false
					end

					for k1, v1 in ipairs(var12:GetDescendants()) do
						if not v1:IsA("BasePart") then
							continue
						end

						v1.CastShadow = false
					end

					var12:SetAttribute("Ore", var8)
					var12:SetAttribute("Cell", num1)
					var12.Parent = var24
					num2 = num2 + 1
					if num2 % 24 ~= 0 then
						continue
					end

					task.wait()
				end
			end
		end

		bool1 = false
	end

	local var28 = nil
	local var29 = nil
	local bool2 = false
	local num2 = 0
	local num3 = 0
	local num4 = 0
	local function blockFrom(arg1)
		if not arg1 or (not var24) then
			return nil
		end

		local var1 = arg1
		while var1 do
			if var1.Parent == var24 then
				break
			end

			var1 = var1.Parent
			if not var1 or var1 == workspace then
				return nil
			end
		end

		return var1
	end

	local var30 = workspace.CurrentCamera
	local tbl3 = { Vector2.zero }
	local tbl4 = { Vector2.zero }
	for k1, v1 in ipairs({ 60, num1 }) do
		for i1 = 0, 7 do
			local var31 = i1 * 3.1415926535897931 / 4
			table.insert(tbl4, Vector2.new(math.cos(var31), (math.sin(var31))) * v1)
		end
	end

	local var32 = nil
	local bool3 = false
	local function refreshHover()
		local var1 = var10.Character
		var1 = var1 and var10.Character:FindFirstChild("HumanoidRootPart")
		if not var24 or (not var1 or (not var30)) then
			var28 = nil
			var26.Visible = false
			return
		end

		var27.FilterDescendantsInstances = { var24 }
		local var3
		if var32 then
			var3 = var32
		else
			local var5 = var30 and var30.ViewportSize or Vector2.new(1, 1)
			if bool3 then
				var3 = var5 / 2
			else
				var3 = if var11.TouchEnabled and (not var11.MouseEnabled) then var5 / 2 else var11:GetMouseLocation()
			end
		end

		local var6 = var11:GetLastInputType() == Enum.UserInputType.Gamepad1 and tbl4 or nil
		local var7 = nil
		local var8 = nil
		for k1, v1 in ipairs(var6 or tbl3) do
			local var9 = var30:ViewportPointToRay(var3.X + v1.X, var3.Y + v1.Y)
			local var12 = workspace:Raycast(var9.Origin, var9.Direction * (var2.REACH * 2), var27)
			local var13 = var12
			var13 = var13 and blockFrom(var12.Instance)
			if not var13 then
				continue
			end

			var7 = var12
			var8 = var13
			break
		end

		if var8 and (var7 and var2.REACH < (var7.Position - var1.Position).Magnitude) then
			var8 = nil
		end

		var28 = var8
		if var29 then
			return
		end

		var26.Adornee = var8
		var26.Visible = var8 ~= nil
	end

	task.spawn(function()
		while true do
			task.wait(0.05)
			if pcall(refreshHover) then
				continue
			end

			var28 = nil
			var26.Visible = false
		end
	end)

	local var33 = Instance.new("BillboardGui")
	var33.Name = "MineProgress"
	var33.Size = UDim2.fromOffset(150, 16)
	var33.StudsOffset = Vector3.new(0, 0, 0)
	var33.AlwaysOnTop = true
	var33.Enabled = false
	var33.Parent = workspace
	local var34 = Instance.new("Frame")
	var34.Size = UDim2.fromScale(1, 1)
	var34.BackgroundColor3 = Color3.new(0, 0, 0)
	var34.BackgroundTransparency = 0.35
	var34.BorderSizePixel = 0
	var34.Parent = var33
	local var35 = Instance.new("UICorner")
	var35.CornerRadius = UDim.new(0, 4)
	var35.Parent = var34
	local var36 = Instance.new("Frame")
	var36.AnchorPoint = Vector2.new(0, 0.5)
	var36.Position = UDim2.fromScale(0, 0.5)
	var36.Size = UDim2.fromScale(0, 1)
	var36.BackgroundColor3 = Color3.fromRGB(235, 240, 245)
	var36.BorderSizePixel = 0
	var36.Parent = var34
	local var37 = Instance.new("UICorner")
	var37.CornerRadius = UDim.new(0, 4)
	var37.Parent = var36
	local num5 = 0
	local num6 = 0
	local num7 = 0
	local var38 = nil
	local var39 = nil
	local num8 = 0.5
	local bool4 = false
	local function swingFor()
		local var2 = var10.Character
		local var3 = var2
		var3 = var3 and var2:FindFirstChildWhichIsA("Humanoid")
		local var4 = var3
		var4 = var4 and var3:FindFirstChildWhichIsA("Animator")
		if not var4 then
			return nil
		end

		if var38 and var39 == var4 then
			return var38
		end

		local var5 = var1:FindFirstChild("Tools")
		local var6 = var5
		var6 = var6 and var5:FindFirstChild("Pickaxe")
		local var7 = var6
		var7 = var7 and var6:FindFirstChildWhichIsA("Animation")
		if not var7 then
			warn("[Mine] no Animation under ReplicatedStorage.Tools.Pickaxe - no swing to play")
			return nil
		end

		local success, result = pcall(function()
			local var1 = var7
			return var4:LoadAnimation(var1)
		end)

		if not success or (not result) then
			warn("[Mine] the swing animation could not be loaded")
			return nil
		end

		result.Looped = true
		local var8 = var6:GetAttribute("ImpactAt")
		if type(var8) == "number" and (0 < var8 and var8 < 1) then
			num8 = var8
		end

		local success, var9 = pcall(function()
			local str1 = "Hit"
			return result:GetMarkerReachedSignal(str1)
		end)

		if success and var9 then
			var9:Connect(function()
				bool4 = true
				local var1 = os.clock()
				if 0.22857142857142856 <= var1 - num3 then
					num3 = var1
					var12.play("mineHit")
				end
			end)

		end

		result.Priority = Enum.AnimationPriority.Action
		var38 = result
		var39 = var4
		return result
	end

	local num9 = 0
	local function startSwing()
		local var2 = swingFor()
		if not var2 then
			return
		end

		var2:AdjustSpeed((0 < var2.Length and var2.Length or 1) * math.min(3 / math.max(holdTime(), 0.05), 3.5))
		if not var2.IsPlaying then
			num9 = 0
			var2:Play(0.1)
		end
	end

	local function anchorOf(arg1)
		if arg1:IsA("BasePart") then
			return arg1
		end

		local var1 = nil
		local var2 = nil
		for k1, v1 in ipairs(arg1:GetDescendants()) do
			if not v1:IsA("BasePart") then
				continue
			end

			if not v1.CanQuery then
				continue
			end

			local var4 = v1.Size.X * v1.Size.Y * v1.Size.Z
			if not var2 or var2 < var4 then
				var1 = v1
			end

			local var5 = var4
		end

		local var6 = var1
		return var6 or arg1:FindFirstChildWhichIsA("BasePart", true)
	end

	local bool5 = false
	var11.InputBegan:Connect(function(arg1, arg2)
		if not arg2 then
			local bool4 = true
			if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
				bool4 = true
				if arg1.UserInputType ~= Enum.UserInputType.Touch then
					bool4 = arg1.KeyCode == Enum.KeyCode.ButtonR2
				end
			end

			if not bool4 then
				return
			end
		end

		if arg1.UserInputType == Enum.UserInputType.Touch then
			var32 = Vector2.new(arg1.Position.X, arg1.Position.Y)
			refreshHover()
		else
			if arg1.KeyCode == Enum.KeyCode.ButtonR2 then
				bool3 = true
			end
		end

		bool5 = true
	end)

	var11.InputChanged:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.Touch and var32 then
			var32 = Vector2.new(arg1.Position.X, arg1.Position.Y)
		end
	end)

	var11.InputEnded:Connect(function(arg1)
		local bool4 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool4 = true
			if arg1.UserInputType ~= Enum.UserInputType.Touch then
				bool4 = arg1.KeyCode == Enum.KeyCode.ButtonR2
			end
		end

		if bool4 then
			if arg1.UserInputType == Enum.UserInputType.Touch then
				var32 = nil
			else
				if arg1.KeyCode == Enum.KeyCode.ButtonR2 then
					bool3 = false
				end
			end

			bool5 = false
			if bool2 then
				return
			end

			if var38 and var38.IsPlaying then
				var38:Stop(0.1)
			end

			var29 = nil
			num5 = 0
			num6 = 0
			num7 = 0
			var33.Enabled = false
			var36.Size = UDim2.fromScale(0, 1)
		end
	end)

	local function breakBlock(arg1)
		local var1 = arg1:GetAttribute("Cell")
		num2 = os.clock()
		local var4 = arg1:GetAttribute("Ore") == true
		local var5 = arg1:GetAttribute("Iron") == true
		local var6 = arg1:IsA("Model") and arg1:GetPivot().Position or arg1.Position
		var29 = nil
		num5 = 0
		num6 = 0
		num7 = 0
		var33.Enabled = false
		var36.Size = UDim2.fromScale(0, 1)
		var26.Visible = false
		var28 = nil
		arg1:Destroy()
		if type(var1) == "number" then
			table.insert(tbl2, var1)
		end

		local var7 = os.clock()
		if 0.12 <= var7 - num4 then
			num4 = var7
			var12.play("blockBreak")
		end

		if var4 then
			if var5 then
				var13.burst(var6, 3, "iron")
			else
				local tbl1 = { "upgrades", "moreSilver" }
				local var8 = math.floor(var2.silverPerOre(var3:get(tbl1)) / 15) + 3
				var13.burst(var6, (math.clamp(var8, 3, 8)))
			end
		end

		pcall(refreshHover)
	end

	var7.Heartbeat:Connect(function(arg1)
		local var8
		if not var29 then
			if bool5 and (var28 and var28.Parent) then
				startSwing()
				local var1 = var28
				var29 = var1
				num5 = 0
				num6 = 0
				num7 = 0
				var26.Adornee = var1
				var26.Visible = true
				var33.Adornee = anchorOf(var1)
				var36.Size = UDim2.fromScale(0, 1)
				var33.Enabled = var33.Adornee ~= nil
				return
			end

			if var38 and var38.IsPlaying then
				var38:Stop(0.1)
			end

			return
		end

		if not var29.Parent then
			var29 = nil
			num5 = 0
			num6 = 0
			num7 = 0
			var33.Enabled = false
			var36.Size = UDim2.fromScale(0, 1)
			return
		end

		if not bool2 then
			if var28 ~= var29 then
				if var28 and (var28.Parent and bool5) then
					startSwing()
					local var2 = var28
					var29 = var2
					num5 = 0
					num6 = 0
					num7 = 0
					var26.Adornee = var2
					var26.Visible = true
					var33.Adornee = anchorOf(var2)
					var36.Size = UDim2.fromScale(0, 1)
					var33.Enabled = var33.Adornee ~= nil
					return
				end

				local var3 = num6 + arg1
				num6 = var3
				if 0.2 < num6 then
					var29 = nil
					num5 = 0
					num6 = 0
					num7 = 0
					var33.Enabled = false
					var36.Size = UDim2.fromScale(0, 1)
				end

				return
			end
		end

		num6 = 0
		startSwing()
		local var4 = math.min(1, num5 + arg1 / holdTime())
		num5 = var4
		var36.Size = UDim2.fromScale(num5, 1)
		if 1 <= num5 then
			breakBlock(var29)
			return
		end

		if var38 then
			if var38.IsPlaying then
				if not bool4 then
					var4 = var38.Length
					local var5 = 0 < var4 and var38.TimePosition % var4 / var4 or 0
					local var7 = var5 < num9
					if not var7 then
						if num9 < num8 then
							local bool7 = true
							if num8 > var5 then
								bool7 = var7
								if bool7 then
									bool7 = true
									if num9 >= num8 then
										bool7 = num8 <= var5
									end
								end
							end
						end
					end

					if var8 then
						local var9 = num7 + 1
						num7 = var9
						var9 = os.clock()
						if 0.22857142857142856 <= var9 - num3 then
							num3 = var9
							var12.play("mineHit")
						end
					end

					num9 = var5
					return
				end
			end
		end

		var4 = math.min(3, math.floor(num5 * 3) + 1)
		if not var38 and num7 < var4 then
			local var10 = num7 + 1
			num7 = var10
			var10 = os.clock()
			if 0.22857142857142856 <= var10 - num3 then
				num3 = var10
				var12.play("mineHit")
			end
		end
	end)

	local var40 = var14.BY_ID[var2.DOOR]
	local var41 = var40
	local var42 = workspace:FindFirstChild("Doors")
	var41 = var41 and (var42 and var42:FindFirstChild(var40.model))
	local var43, var44 = var41:GetBoundingBox()
	local var45 = var17.Position.Y - var17.Size.Y / 2
	var45 = var41 and var43.Position.Y - var44.Y / 2
	var43 = var41 and (var41:GetBoundingBox().Position - var17.Position) * Vector3.new(1, 0, 1) or Vector3.new(0, 0, -1)
	local var46 = nil
	local var47 = nil
	if math.abs(var43.Z) < math.abs(var43.X) then
		var46 = Vector3.new(if 0 <= var43.X then 1 else -1, 0, 0)
		var47 = Vector3.new(0, 0, 1)
	else
		local num10 = 0
		local num11 = 0
		var46 = Vector3.new(num10, num11, if 0 <= var43.Z then 1 else -1)
		var47 = Vector3.new(1, 0, 0)
	end

	var40 = function(arg1, arg2)
		local var1 = RaycastParams.new()
		var1.FilterType = Enum.RaycastFilterType.Exclude
		local var2 = var17.Position.Y - var17.Size.Y / 2
		local tbl1 = { var10.Character, var24, var17 }
		local var3 = var17.Position.Y + var17.Size.Y / 2 + 60
		local num1 = math.huge
		local var4 = nil
		for i1 = 1, 10 do
			var1.FilterDescendantsInstances = tbl1
			local var5 = workspace:Raycast(Vector3.new(arg1, var3, arg2), Vector3.new(0, -(var3 - var2 + 40), 0), var1)
			if not var5 then
				break
			end

			if 0.5 < var5.Normal.Y then
				local var8 = var5.Position.Y
				local var9 = var5.Instance.Size
				local tbl2 = { var9.X, var9.Y, var9.Z }
				table.sort(tbl2)
				if 4 <= tbl2[2] and (var45 - 4 <= var8 and (var8 <= var45 + 8 and 7 <= num1 - var8)) then
					var4 = var5.Position + Vector3.new(0, 4, 0)
					return var4
				end
			end

			table.insert(tbl1, var5.Instance)
			local var11 = var5.Position.Y + 0.05
			local var12 = var8 - var5.Instance.Size.Y
		end

		return var4
	end

	var42 = function(arg1)
		local var15
		local var1 = var10.Character
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
		if not var2 then
			return
		end

		local var4 = var2.Position - var17.Position
		local var5 = var17.Size / 2
		if not arg1 and (var5.X < math.abs(var4.X) or (var5.Y < math.abs(var4.Y) or var5.Z < math.abs(var4.Z))) then
			return
		end

		if var46.X ~= 0 then
			local var6 = var5.X
			var6 = var6 or var5.Z
		end

		local var7 = var5.Z + 8
		if var47.X ~= 0 then
			local var8 = var5.X
			var8 = var8 or var5.Z
		end

		local var9 = var5.Z - 4
		local var11 = math.clamp(var4:Dot(var47), -var9, var9)
		local var12 = nil
		for i1 = 0, 30 do
			local var13 = ipairs
			if i1 == 0 then
				local tbl2 = { 1 }
				local var14
				if not tbl2 then
					var14 = -1
					tbl2 = { 1, var14 }
				end
			end

			for k1, v1 in var13(var15) do
				local var16 = var17.Position + var47 * math.clamp(var11 + v1 * i1 * 4, -var9, var9) + var46 * var7
				var12 = var40(var16.X, var16.Z)
				if var12 then
					break
				end
			end

			if var12 then
				break
			end
		end

		if not var12 then
			warn("[Mine] no floor at the mine's entrance to evict onto - leaving the player in place")
			return
		end

		var2.CFrame = CFrame.lookAt(var12, var12 - var46)
		var2.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	end

	var8.MineReset.OnClientEvent:Connect(function()
		var42()
		task.wait(0.2)
		build()
	end)

	var43 = var3:get({ "doors", var2.IRON_DOOR }) == true
	var3:getChangedSignal("doors"):Connect(function()
		local var4 = var3:get({ "doors", var2.IRON_DOOR }) == true
		if var4 and (not var43) then
			local num4 = 214
			local num5 = 196
			local num6 = 178
			var15.show("Iron Ore has Entered the Mine", Color3.fromRGB(num4, num5, num6))
			local bool1 = true
			if var2.DOOR ~= nil then
				bool1 = var3:get({ "doors", var2.DOOR }) == true
			end

			if bool1 and var24 then
				var42()
				task.wait(0.2)
				build()
			end
		end

		var43 = var4
	end)

	var44 = var3:get({ "upgrades", "oreDensity" }) or 0
	var3:getChangedSignal("upgrades"):Connect(function()
		local var4 = var3:get({ "upgrades", "oreDensity" }) or 0
		if var4 == var44 then
			return
		end

		var44 = var4
		local bool1 = true
		if var2.DOOR ~= nil then
			bool1 = var3:get({ "doors", var2.DOOR }) == true
		end

		if bool1 and var24 then
			var42()
			task.wait(0.2)
			build()
		end
	end)

	local var48 = var10:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var49 = var48
	var49 = var49 and var48:FindFirstChild("AutoList")
	local var50 = var49
	local var51 = nil
	var51 = var50 and var49:FindFirstChild("AutoMine")
	local var55 = nil
	local var56 = nil
	local var57 = nil
	if var51 then
		var56 = var51:FindFirstChild("Indicator")
		var50 = var56
		var57 = var50 and var56.BackgroundColor3
		if var51:IsA("GuiButton") then
			var55 = var51
		else
			var50 = var51:FindFirstChild("Hit")
			var55 = var50 or Instance.new("TextButton")
			var55.Name = "Hit"
			var55.Text = ""
			var55.BackgroundTransparency = 1
			var55.Size = UDim2.fromScale(1, 1)
			var55.ZIndex = var51.ZIndex + 10
			var55.Parent = var51
		end
	end

	local var58 = Color3.fromRGB(80, 220, 90)
	local var59 = nil
	var7.RenderStepped:Connect(function()
		if not bool2 or (not var59) then
			return
		end

		local var1 = var10.Character
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
		if not var2 then
			var59 = nil
			return
		end

		local var3 = math.clamp((os.clock() - var59.started) / 0.35, 0, 1)
		local var4 = (var59.to - var59.from) * Vector3.new(1, 0, 1)
		local var5 = CFrame.new(var59.from:Lerp(var59.to, var3) + Vector3.new(0, var3 * 12 * (1 - var3), 0)) * (0.1 < var4.Magnitude and CFrame.lookAt(Vector3.new(0, 0, 0), var4).Rotation or var2.CFrame.Rotation)
		var2.CFrame = var5
		var2.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		if 1 <= var3 then
			var59 = nil
		end
	end)

	local var60 = os.clock()
	local var61 = nil
	local var62 = nil
	var50 = false
	local var63 = var22.X * var22.Y
	local var64 = RaycastParams.new()
	var64.FilterType = Enum.RaycastFilterType.Include
	local function setAuto(arg1)
		var60 = os.clock()
		var61 = nil
		bool2 = arg1
		var62 = nil
		if var56 then
			var56.BackgroundColor3 = bool2 and var58 or var57
		end

		local var2 = var3:get("settings")
		if not (var2 and var2.autoMine == arg1) then
			table.insert(tbl1, { "autoMine", arg1 })
		end

		if arg1 then
			if not var4.owns(var5.owned, "autoMineAnywhere") then
				var2 = var3:get("settings")
				if var2 and var2.autoRun == false then
					return
				end

				table.insert(tbl1, { "autoRun", false })
				return
			end
		end

		var50 = false
		if var38 and var38.IsPlaying then
			var38:Stop(0.1)
		end

		var29 = nil
		num5 = 0
		num6 = 0
		num7 = 0
		var33.Enabled = false
		var36.Size = UDim2.fromScale(0, 1)
		var2 = var10.Character
		local var6 = var10.Character
		var2 = var2 and var10.Character:FindFirstChildWhichIsA("Humanoid")
		var6 = var6 and var10.Character:FindFirstChild("HumanoidRootPart")
		if var2 and var6 then
			var2:MoveTo(var6.Position)
		end
	end

	local num12 = 0
	local var65 = nil
	local var66 = setmetatable({}, { __mode = "k" })
	local function hopOnto(arg1)
		local var1 = var10.Character
		local var3 = var1
		local var4 = var1
		var3 = var3 and var1:FindFirstChildWhichIsA("Humanoid")
		var4 = var4 and var1:FindFirstChild("HumanoidRootPart")
		if not var3 or (not var4) then
			return
		end

		local var5 = (var4.Position - arg1) * Vector3.new(1, 0, 1)
		local var6 = var3.HipHeight + var4.Size.Y / 2
		if 0.1 < var5.Magnitude then
			local var7 = var5.Unit * math.min(var2.CELL / 2 - 2, var5.Magnitude)
			var7 = var7 or Vector3.new(0, 0, 0)
		end

		local var8 = arg1 + Vector3.new(0, 0, 0) + Vector3.new(0, var6 + 0.1, 0)
		local tbl1 = { from = var4.Position, to = var8, started = os.clock() }
		var59 = tbl1
		var3:ChangeState(Enum.HumanoidStateType.Jumping)
	end

	local num13 = 0
	local var67 = nil
	local num14 = 0
	local num15 = 0
	local function autoStep()
		local var1 = var10.Character
		local var6 = var1
		local var7 = var1
		var6 = var6 and var1:FindFirstChildWhichIsA("Humanoid")
		var7 = var7 and var1:FindFirstChild("HumanoidRootPart")
		if not var6 or (not var7) then
			return
		end

		if var6.Health <= 0 then
			setAuto(false)
			return
		end

		local var8 = var2.REACH
		local var9 = var7.Position - var17.Position
		local var11 = var17.Size / 2 + Vector3.new(var8, var8, var8)
		local bool3 = false
		if math.abs(var9.X) <= var11.X then
			bool3 = false
			if math.abs(var9.Y) <= var11.Y then
				bool3 = math.abs(var9.Z) <= var11.Z
			end
		end

		if not bool3 then
			if not var50 then
				if var4.owns(var5.owned, "autoMineAnywhere") then
					return
				end

				setAuto(false)
				return
			end
		end

		local var13 = var3:get("settings")
		if var4.owns(var5.owned, "autoMineAnywhere") and (var13 and (var13.autoRun == true and (not var50))) then
			return
		end

		if bool1 or (not var24) then
			return
		end

		if bool3 then
			if not var50 then
				var9 = math.floor((var7.Position.Y - (var6.HipHeight + var7.Size.Y / 2) - var23.Y) / var2.CELL + 0.25)
				var11 = os.clock()
				if var61 == nil or var61 < var9 then
					var61 = var9
					var60 = var11
				end

				local var14 = math.max(var60, num2)
				var60 = var14
				var14 = var11 - var60
				if 15 < var14 then
					var60 = var11
					var61 = nil
					var59 = nil
					if var38 and var38.IsPlaying then
						var38:Stop(0.1)
					end

					var29 = nil
					num5 = 0
					num6 = 0
					num7 = 0
					var33.Enabled = false
					var36.Size = UDim2.fromScale(0, 1)
					var42(true)
					return
				end

				if 8 < var14 and (not var29 or (not var29.Parent)) then
					local var15 = nil
					local var16 = nil
					for k1, v1 in ipairs(var24:GetChildren()) do
						if type((v1:GetAttribute("Cell"))) ~= "number" then
							continue
						end

						local var18 = v1:IsA("Model") and v1:GetPivot().Position or v1.Position
						local var20 = (var18 - var7.Position).Magnitude
						local var21 = var7.Position.Y + 4 < var18.Y
						local var25
						if v1:GetAttribute("Ore") == true then
							if var21 then
								var25 = 30
							else
								var25 = 22
							end
						elseif var21 then
							var25 = 24
						else
							var25 = 18
						end

						if var20 > var25 then
							continue
						end

						if not var16 or var20 < var16 then
							var15 = v1
							var16 = var20
						end
					end

					if var15 then
						var59 = nil
						startSwing()
						var29 = var15
						num5 = 0
						num6 = 0
						num7 = 0
						var26.Adornee = var15
						var26.Visible = true
						var33.Adornee = anchorOf(var15)
						var36.Size = UDim2.fromScale(0, 1)
						var33.Enabled = var33.Adornee ~= nil
						return
					end
				end
			end
		end

		if var59 then
			return
		end

		if var29 then
			if var29.Parent then
				var9 = var29
				var8 = "digging " .. var29.Name
				var8 = var9:IsA("Model") and var9:GetPivot().Position or var9.Position
				var9 = Vector3.new(var8.X, var7.Position.Y, var8.Z)
				if 0.5 < (var9 - var7.Position).Magnitude then
					var7.CFrame = CFrame.lookAt(var7.Position, var9)
				end

				var6:MoveTo(var7.Position)
				return
			end
		end

		var8 = {}
		var9 = {}
		for k2, v2 in ipairs(var24:GetChildren()) do
			local var27 = v2:GetAttribute("Cell")
			if type(var27) ~= "number" then
				continue
			end

			var8[var27] = v2
			local str1 = "Ore"
			if v2:GetAttribute(str1) ~= true then
				continue
			end

			str1 = v2
			table.insert(var9, str1)
		end

		var11 = function(arg1)
			local var1 = arg1 - 1
			local var2 = var1 % var22.X
			local var3 = var1 // var22.X % var22.Y
			local var4 = var1 // var63
			local tbl1 = { -1, 0, 0 }
			for k1, v1 in ipairs({ { 1, 0, 0 }, tbl1, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 } }) do
				local var9 = var2 + v1[1]
				local var10 = var3 + v1[2]
				local var11 = var4 + v1[3]
				if var9 >= 0 then
					if var10 < 0 or (var11 < 0 or (var22.X <= var9 or (var22.Y <= var10 or var22.Z <= var11))) then
						if 0 > v1[2] then
							continue
						end

						return true
					else
						if var8[var11 * var63 + var10 * var22.X + var9 + 1] then
							continue
						end

						return true
					end
				end
			end

			return false
		end

		local var28 = os.clock()
		if num12 < num2 then
			num12 = num2
		end

		if var65 then
			if var65.Parent then
				if 12 < var28 - num12 then
					if var65.Parent then
						var66[var65] = var28 + 20
					end

					var65 = nil
				end
			end
		end

		local var31 = var65
		if not var31 then
			local var32 = nil
			for k3, v3 in ipairs(var9) do
				if var66[v3] then
					if var28 < var66[v3] then
						continue
					end
				end

				local var35 = ((v3:IsA("Model") and v3:GetPivot().Position or v3.Position) - var7.Position).Magnitude
				if not var32 or var35 < var32 then
					var31 = v3
					var32 = var35
				end
			end

			if var31 then
				var65 = var31
				num12 = var28
			end
		end

		local var37 = var31
		local var39 = var1:FindFirstChild("Head")
		var37 = var37 and (var31:IsA("Model") and var31:GetPivot().Position or var31.Position)
		var64.FilterType = Enum.RaycastFilterType.Exclude
		var64.FilterDescendantsInstances = { var1, var17 }
		local var40 = var39 and var39.Position or var7.Position + Vector3.new(0, 1.5, 0)
		local function canSee(arg1)
			local var1 = arg1:IsA("Model") and arg1:GetPivot().Position or arg1.Position
			local var3 = var40 - var1
			local var4 = var2.CELL / 2 - 0.5
			local var5 = var1 + Vector3.new(math.clamp(var3.X, -var4, var4), math.clamp(var3.Y, -var4, var4), (math.clamp(var3.Z, -var4, var4))) - var40
			if var5.Magnitude < 0.1 then
				return true
			end

			local var6 = workspace:Raycast(var40, var5 + var5.Unit * 1, var64)
			local var7 = var6
			var7 = var7 and var6.Instance
			while var7 do
				if var7.Parent == var24 then
					break
				end

				var7 = var7.Parent
				if var7 == workspace or var7 == nil then
					return false
				end
			end

			return var7 == arg1
		end

		local var41 = var37 and (var37 - var7.Position) * Vector3.new(1, 0, 1) or nil
		local bool4 = false
		if var62 ~= nil then
			bool4 = 1.5 <= os.clock() - var62
		end

		local var43 = nil
		local var44 = nil
		local var45 = nil
		var25 = nil
		if not var50 then
			for k4, v4 in pairs(var8) do
				local var46 = v4:IsA("Model") and v4:GetPivot().Position or v4.Position
				local var48 = (var46 - var7.Position).Magnitude
				local var49 = v4:GetAttribute("Ore") == true
				local var51 = var7.Position.Y + 4 < var46.Y
				local var52
				if v4:GetAttribute("Ore") == true then
					if var51 then
						var52 = 30
					else
						var52 = 22
					end
				elseif var51 then
					var52 = 24
				else
					var52 = 18
				end

				if var48 > var52 then
					continue
				end

				if not var11(k4) then
					continue
				end

				if not canSee(v4) then
					continue
				end

				if var49 then
					if not var44 or var48 < var44 then
						var43 = v4
					end
				end

				var51 = 18
				local var53
				if var49 then
					var53 = 0
				else
					local var55 = var7.Position.Y + 4 < var46.Y
					if v4:GetAttribute("Ore") == true then
						if var55 then
							var53 = 30
						else
							var53 = 22
						end
					elseif var55 then
						var53 = 24
					else
						var53 = 18
					end
				end

				if var48 > math.max(var51, var53) then
					continue
				end

				var51 = bool4
				var52 = (var46 - var7.Position) * Vector3.new(1, 0, 1)
				if not var51 then
					var51 = not var41
					if not var51 then
						var51 = true
						if var41.Magnitude >= 1 then
							var51 = true
							if var52.Magnitude >= 1 then
								var51 = -0.1 < var52.Unit:Dot(var41.Unit)
							end
						end
					end
				end

				if not var51 then
					continue
				end

				var53 = var37 and (var46 - var37).Magnitude or var48
				if not var25 or var53 < var25 then
					var45 = v4
				end

				local var56 = var48
				local var57 = var53
			end
		end

		local var68 = var37
		if var68 then
			var68 = Vector3.new(var37.X, var7.Position.Y, var37.Z)
		end

		if var43 then
			var62 = nil
			var59 = nil
			startSwing()
			var29 = var43
			num5 = 0
			num6 = 0
			num7 = 0
			var26.Adornee = var43
			var26.Visible = true
			var33.Adornee = anchorOf(var43)
			var36.Size = UDim2.fromScale(0, 1)
			var33.Enabled = var33.Adornee ~= nil
			return
		end

		if not var50 then
			if var31 then
				local var71 = var2.CELL
				local var72 = var31:GetAttribute("Cell") - 1
				local var73 = math.floor((var7.Position.X - var23.X) / var71)
				var53 = var72 // var63
				local var74 = math.floor((var7.Position.Z - var23.Z) / var71)
				local var75 = var72 % var22.X
				local var76 = var72 // var22.X % var22.Y
				var72 = math.max(-var73, var73 - (var22.X - 1), -var74, var74 - (var22.Z - 1), 0)
				local var78 = math.floor((var7.Position.Y - (var6.HipHeight + var7.Size.Y / 2) - var23.Y) / var71 + 0.25)
				var73 = math.clamp(var73, 0, var22.X - 1)
				var74 = math.clamp(var74, 0, var22.Z - 1)
				var52 = function(arg1, arg2, arg3)
					if arg1 < 0 or (arg3 < 0 or (var22.X <= arg1 or (var22.Z <= arg3 or arg2 < 0))) then
						return false
					end

					if var22.Y <= arg2 then
						return false
					end

					return var8[arg3 * var63 + arg2 * var22.X + arg1 + 1] ~= nil
				end

				local var79 = var72 == 0
				if var72 <= 1 and (0 <= var78 and (var78 < var22.Y and var78 < var76)) then
					local num1 = 0
					local tbl2 = {}
					local tbl3 = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { num1, -1 } }
					if not var79 then
						num1 = 0
						table.insert(tbl3, 1, { num1, 0 })
					end

					for k5, v5 in ipairs(tbl3) do
						local var82 = var73 + v5[1]
						local var83 = var74 + v5[2]
						local var84
						if var82 < 0 or (var83 < 0 or (var22.X <= var82 or (var22.Z <= var83 or var78 < 0))) then
							var84 = false
						else
							if var22.Y <= var78 then
								var84 = false
							else
								var84 = var8[var83 * var63 + var78 * var22.X + var82 + 1] ~= nil
							end
						end

						if not var84 then
							continue
						end

						var84 = var2.centreOf(var23, var82, var78, var83)
						table.insert(tbl2, { x = var82, z = var83, at = var84, score = (var84 - var37).Magnitude })
					end

					table.sort(tbl2, function(arg1, arg2)
						return arg1.score < arg2.score
					end)

					for k6, v6 in ipairs(tbl2) do
						local var87 = v6.x
						local var88 = v6.z
						var84 = var78 + 1
						local var89
						if var87 < 0 or (var88 < 0 or (var22.X <= var87 or (var22.Z <= var88 or var84 < 0))) then
							var89 = false
						else
							if var22.Y <= var84 then
								var89 = false
							else
								var89 = var8[var88 * var63 + var84 * var22.X + var87 + 1] ~= nil
							end
						end

						var89 = var89 and var8[v6.z * var63 + (var78 + 1) * var22.X + v6.x + 1]
						if var79 then
							local var92 = var78 + 1
							if var73 < 0 or (var74 < 0 or (var22.X <= var73 or (var22.Z <= var74 or var92 < 0))) then
								var84 = false
							else
								if var22.Y <= var92 then
									var84 = false
								else
									var84 = var8[var74 * var63 + var92 * var22.X + var73 + 1] ~= nil
								end
							end

							var87 = var84 and var8[var74 * var63 + (var78 + 1) * var22.X + var73 + 1] or nil
						end

						var84 = nil or var89
						if var84 then
							if ((var84:IsA("Model") and var84:GetPivot().Position or var84.Position) - var7.Position).Magnitude > 22 then
								continue
							end

							var62 = nil;
							("climb: clearing headroom (layer %d -> ore layer %d)"):format(var78, var76)
							startSwing()
							var29 = var84
							num5 = 0
							num6 = 0
							num7 = 0
							var26.Adornee = var84
							var26.Visible = true
							var33.Adornee = anchorOf(var84)
							var36.Size = UDim2.fromScale(0, 1)
							var33.Enabled = var33.Adornee ~= nil
							return
						else
							hopOnto(v6.at + Vector3.new(0, var71 / 2, 0))
							var62 = nil;
							("climb: jumping to layer %d"):format(var78 + 1)
							return
						end
					end
				end
			end
		end

		local var94 = var45
		if var94 then
			var62 = nil
			startSwing()
			var29 = var94
			num5 = 0
			num6 = 0
			num7 = 0
			var26.Adornee = var94
			var26.Visible = true
			var33.Adornee = anchorOf(var94)
			var36.Size = UDim2.fromScale(0, 1)
			var33.Enabled = var33.Adornee ~= nil
			return
		end

		local var96 = os.clock()
		if var96 < num13 then
			var6:MoveTo((Vector3.new(var17.Position.X, var7.Position.Y, var17.Position.Z)))
			return
		end

		if var68 then
			var6:MoveTo(var68)
		end

		if var67 then
			if 0.4 < var96 - num14 then
				local var97 = var67
				var97 = var97 and (var7.Position - var67) * Vector3.new(1, 0, 1)
				if var97 then
					if var97.Magnitude < 1 then
						if var68 then
							if var6.FloorMaterial ~= Enum.Material.Air then
								local var101 = (var68 - var7.Position) * Vector3.new(1, 0, 1)
								if 0.5 < var101.Magnitude then
									local var102 = RaycastParams.new()
									var102.FilterType = Enum.RaycastFilterType.Include
									var102.FilterDescendantsInstances = { var24 }
									local var103 = workspace:Raycast(var7.Position - Vector3.new(0, 1.5, 0), var101.Unit * 6, var102)
									local var104 = var103
									var104 = var104 and var103.Instance
									while var104 and var104.Parent ~= var24 and var104 ~= workspace do
										var104 = var104.Parent
									end

									if var104 then
										if var104.Parent == var24 then
											var52 = var104:GetAttribute("Cell")
											local var109 = var52 - 1
											local var110 = var109 // var22.X % var22.Y
											var53 = var109 % var22.X
											local var111 = var109 // var63
											local var112 = nil
											if type(var52) == "number" and var110 + 1 < var22.Y then
												var112 = var8[var111 * var63 + (var110 + 1) * var22.X + var53 + 1]
											end

											num15 = 0
											if var112 then
												startSwing()
												var29 = var112
												num5 = 0
												num6 = 0
												num7 = 0
												var26.Adornee = var112
												var26.Visible = true
												var33.Adornee = anchorOf(var112)
												var36.Size = UDim2.fromScale(0, 1)
												var33.Enabled = var33.Adornee ~= nil
											else
												hopOnto((var104:IsA("Model") and var104:GetPivot().Position or var104.Position) + Vector3.new(0, var2.CELL / 2, 0))
											end
										else
											var52 = num15 + 1
											num15 = var52
											if 2 <= num15 then
												num15 = 0
												if var31 then
													var66[var31] = var96 + 20
												end

												var65 = nil
												num13 = var96 + 1.5
											else
												var6.Jump = true
											end
										end
									else
										var52 = num15 + 1
										num15 = var52
										if 2 <= num15 then
											num15 = 0
											if var31 then
												var66[var31] = var96 + 20
											end

											var65 = nil
											num13 = var96 + 1.5
										else
											var6.Jump = true
										end
									end

		if not (var104 and var104.Parent == var24) then
									end
								end
							else
								num15 = 0
							end
						else
							num15 = 0
						end
					else
						num15 = 0
					end
				else
					num15 = 0
				end

				num14 = var96
				var67 = var7.Position
			end

			local str2 = "blocked: jumping"
		end

		if var50 then
			var42(true)
			var50 = false
			var62 = nil
			return
		end

		local var113 = var62 or var96
		var62 = var113
		if 6 <= var96 - var62 then
			var62 = nil
			var42(true)
		end
	end

	task.spawn(function()
		while true do
			task.wait(0.15)
			if not bool2 then
				continue
			end

			local success, result = pcall(autoStep)
			if success then
				continue
			end

			warn("[Mine] auto mine step failed: " .. tostring(result))
		end
	end)

	task.spawn(function()
		while true do
			task.wait(0.5)
			if not var24 or bool1 then
				continue
			end

			local var1 = var10.Character
			var1 = var1 and var10.Character:FindFirstChild("HumanoidRootPart")
			if not var1 then
				continue
			end

			if var24.Parent == nil then
				local var3 = var1.Position - var17.Position
				local var4 = var17.Size / 2 + Vector3.new(90, 90, 90)
				local bool4 = false
				if math.abs(var3.X) <= var4.X then
					bool4 = false
					if math.abs(var3.Y) <= var4.Y then
						bool4 = math.abs(var3.Z) <= var4.Z
					end
				end

				if bool4 then
					var24.Parent = var6
				else
					if var24.Parent ~= var6 then
						continue
					end

					var3 = var1.Position - var17.Position
					var4 = var17.Size / 2 + Vector3.new(130, 130, 130)
					bool4 = false
					if math.abs(var3.X) <= var4.X then
						bool4 = false
						if math.abs(var3.Y) <= var4.Y then
							bool4 = math.abs(var3.Z) <= var4.Z
						end
					end

					if bool4 or bool2 then
						continue
					end

					var24.Parent = nil
				end
			else
				if var24.Parent ~= var6 then
					continue
				end

				local var5 = var1.Position - var17.Position
				local var7 = var17.Size / 2 + Vector3.new(130, 130, 130)
				local bool6 = false
				if math.abs(var5.X) <= var7.X then
					bool6 = false
					if math.abs(var5.Y) <= var7.Y then
						bool6 = math.abs(var5.Z) <= var7.Z
					end
				end

				if bool6 or bool2 then
					continue
				end

				var24.Parent = nil
			end
		end
	end)

	if var51 then
		var51.Visible = false
		if var56 then
			var56.BackgroundColor3 = bool2 and var58 or var57
		end

		task.spawn(function()
			while true do
				task.wait(0.25)
				local var1 = var10.Character
				var1 = var1 and var10.Character:FindFirstChild("HumanoidRootPart")
				local bool2 = false
				if var1 ~= nil then
					bool2 = true
					if var2.DOOR ~= nil then
						bool2 = var3:get({ "doors", var2.DOOR }) == true
					end

					if bool2 then
						local var6 = var1.Position - var17.Position
						local var7 = var17.Size / 2 + Vector3.new(30, var2.VERTICAL_MARGIN or 30, 30)
						bool2 = false
						if math.abs(var6.X) <= var7.X then
							bool2 = false
							if math.abs(var6.Y) <= var7.Y then
								bool2 = math.abs(var6.Z) <= var7.Z
							end
						end
					end
				end

				local var9 = bool2
				if not var9 then
					var9 = true
					if var2.DOOR ~= nil then
						var9 = var3:get({ "doors", var2.DOOR }) == true
					end

					var9 = var9 and var4.owns(var5.owned, "autoMineAnywhere")
				end

				if var51.Visible == var9 then
					continue
				end

				var51.Visible = var9
			end
		end)

		var16.bind(var55, function()
			if bool2 then
				setAuto(false)
				var12.play("purchase")
				return
			end

			local bool1 = true
			if var2.DOOR ~= nil then
				bool1 = var3:get({ "doors", var2.DOOR }) == true
			end

			if not bool1 then
				var12.play("denied")
				return
			end

			var12.play("purchase")
			setAuto(true)
		end)

	else
		warn("[Mine] no Main.AutoList.AutoMine - auto mine cannot be toggled")
	end

	local num16 = 0
	local function remoteDrop(arg1, arg2)
		if not bool2 or (not var4.owns(var5.owned, "autoMineAnywhere") or arg1 <= 0) then
			return
		end

		local var1 = var10.Character
		var1 = var1 and var10.Character:FindFirstChild("HumanoidRootPart")
		if var1 then
			local var3 = var2.REACH
			local var6 = var1.Position - var17.Position
			local var7 = var17.Size / 2 + Vector3.new(var3, var3, var3)
			local bool3 = false
			if math.abs(var6.X) <= var7.X then
				bool3 = false
				if math.abs(var6.Y) <= var7.Y then
					bool3 = math.abs(var6.Z) <= var7.Z
				end
			end

			if bool3 then
				return
			end
		end

		local var8 = os.clock()
		if var8 - num16 < 0.25 then
			return
		end

		num16 = var8
		local var9 = math.random() * 3.1415926535897931 * 2
		local var11 = var13.burst
		local var14 = var1.Position + Vector3.new(math.cos(var9) * 4, 1.5, math.sin(var9) * 4)
		local var15 = if arg2 then 2 else 3
		var11(var14, var15, if arg2 then "iron" else nil)
		var11 = os.clock()
		if 0.22857142857142856 <= var11 - num3 then
			num3 = var11
			var12.play("mineHit")
		end
	end

	local var68 = var3:get("silver") or 0
	var3:getChangedSignal("silver"):Connect(function()
		local var1 = var3:get("silver") or 0
		remoteDrop(var1 - var68, false)
		var68 = var1
	end)

	local var69 = var3:get("iron") or 0
	var3:getChangedSignal("iron"):Connect(function()
		local var1 = var3:get("iron") or 0
		remoteDrop(var1 - var69, true)
		var69 = var1
	end)

	var3:getChangedSignal("settings"):Connect(function()
		local var2 = var3:get("settings")
		if bool2 and (var2 and var2.autoMine == false) then
			setAuto(false)
		end
	end)

	var68 = var3:get("settings")
	if var68 and var68.autoMine == true then
		task.spawn(function()
			local var1 = var10.Character;
			(var1 or var10.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart", 10)
			task.wait(2)
			local num1 = 0
			while not bool1 do
				if var24 or num1 >= 20 then
					break
				end

				task.wait(0.5)
				num1 = num1 + 0.5
			end

			if bool2 then
				return
			end

			local bool3 = true
			if var2.DOOR ~= nil then
				bool3 = var3:get({ "doors", var2.DOOR }) == true
			end

			if bool3 and var24 then
				var50 = not var4.owns(var5.owned, "autoMineAnywhere")
				bool2 = true
				var62 = nil
				if not var56 then
					return
				end

				var56.BackgroundColor3 = bool2 and var58 or var57
				return
			end

			bool3 = var3:get("settings")
			if bool3 and bool3.autoMine == false then
				return
			end

			table.insert(tbl1, { "autoMine", false })
		end)

	end

	var68 = true
	if var2.DOOR ~= nil then
		var68 = var3:get({ "doors", var2.DOOR }) == true
	end

	if var68 then
		build()
	end

	var3:getChangedSignal("doors"):Connect(function()
		local bool3 = true
		if var2.DOOR ~= nil then
			bool3 = var3:get({ "doors", var2.DOOR }) == true
		end

		if bool3 then
			if not not var24 then
				return
			end

			build()
			return
		end

		if var24 then
			if not bool1 then
				if bool2 then
					setAuto(false)
				end

				var24:Destroy()
				var24 = nil
			end
		end
	end)
end }

--- ReplicatedStorage.Client.MineDrops [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local function hudIcon(arg1)
	local var3 = var2:FindFirstChild("PlayerGui")
	if not var3 then
		return nil
	end

	for k1, v1 in ipairs(var3:GetDescendants()) do
		if v1.Name ~= arg1 then
			continue
		end

		if not v1:IsA("GuiObject") then
			continue
		end

		local var4 = v1:FindFirstChild("Coin")
		if not var4 then
			continue
		end

		if not var4:IsA("ImageLabel") then
			continue
		end

		return var4.Image, var4.ImageColor3
	end

	return nil
end

local tbl1 = {}
local var3 = require(var1.Client.UISound)
local bool1 = false
local var4 = nil
local var5 = game:GetService("RunService")
local function step(arg1)
	local var1 = var2.Character
	local var4 = var1
	var4 = var4 and var1:FindFirstChild("HumanoidRootPart")
	for i1 = #tbl1, 1, -1 do
		local var5 = tbl1[i1]
		local var6 = var5.t + arg1
		var5.t = var6
		if var5.phase == "burst" then
			var6 = var5.velocity - Vector3.new(0, 70 * arg1, 0)
			var5.velocity = var6
			var6 = var5.position + var5.velocity * arg1
			var5.position = var6
			if var5.leaveAt <= var5.t then
				var5.phase = "collect"
				var5.from = var5.position
				var5.ct = 0
			else
				if not var5.part.Parent then
					continue
				end

				var5.part.CFrame = CFrame.new(var5.position)
			end
		else
			var6 = var5.ct + arg1
			var5.ct = var6
			var6 = math.min(1, var5.ct / 0.3)
			local var7 = var6 * var6
			var5.position = var5.from:Lerp(var4 and var4.Position + Vector3.new(0, 1, 0) or var5.from, var7)
			if var5.billboard then
				local var9 = 1 - var7 * 0.65
				var5.billboard.Size = UDim2.new(var5.size.X.Scale * var9, var5.size.X.Offset * var9, var5.size.Y.Scale * var9, var5.size.Y.Offset * var9)
			end

			if 1 <= var6 then
				local var11 = var5.burst
				if not var11.sounded then
					var11.sounded = true
					var3.play("oreCollect")
				end

				var5.part:Destroy()
				table.remove(tbl1, i1)
			else
				if not var5.part.Parent then
					continue
				end

				var5.part.CFrame = CFrame.new(var5.position)
			end
		end
	end

	if #tbl1 == 0 then
		bool1 = false
	end
end

return { burst = function(arg1, arg2, arg3)
	local var2 = var1:FindFirstChild("Effects")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Coin")
	if not var3 then
		return
	end

	local var6
	if arg3 == "iron" then
		var6 = "Iron"
	elseif arg3 == "wood" then
		var6 = "Wood"
	elseif arg3 == "crystals" then
		var6 = "Crystals"
	else
		var6 = "Silver"
	end

	local var11, var12 = hudIcon(var6)
	local var13
	local var14
	if not var11 then
		local var15, var16 = hudIcon("Silver")
		var13 = var15
		var14 = var16
	else
		var13 = var11
		var14 = var12
	end

	var6 = { sounded = false }
	for i1 = 1, arg2 do
		if 40 <= (#tbl1) then
			break
		end

		local var17 = var3:Clone()
		var17.Anchored = true
		var17.CanCollide = false
		var17.CanQuery = false
		var17.CanTouch = false
		var17.CFrame = CFrame.new(arg1)
		local var18 = var17:FindFirstChildWhichIsA("BillboardGui")
		local var19 = var18
		var19 = var19 and var18:FindFirstChildWhichIsA("ImageLabel")
		if var19 and var13 then
			var19.Image = var13
			if var14 then
				var19.ImageColor3 = var14
			end
		end

		var17.Parent = workspace
		local var20 = math.random() * 3.1415926535897931 * 2
		local var21 = 9 * (0.5 + math.random() * 0.5)
		local var22 = var18 and var18.Size or UDim2.fromScale(1, 1)
		local tbl2 = {
			part = var17,
			billboard = var18,
			size = var22,
			burst = var6,
			position = arg1,
			phase = "burst",
			t = 0,
		}

		tbl2.velocity = Vector3.new(math.cos(var20) * var21, 16 * (0.8 + math.random() * 0.4), math.sin(var20) * var21)
		tbl2.leaveAt = (i1 - 1) * 0.05 + 0.35
		table.insert(tbl1, tbl2)
	end

	if bool1 then
		return
	end

	bool1 = true
	if not var4 then
		var4 = var5.Heartbeat:Connect(function(arg1)
			if bool1 then
				step(arg1)
			end
		end)

	end
end }

--- ReplicatedStorage.Client.Ambience [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("Players").LocalPlayer
local tbl1 = { path = { "Runes", "LavaRunes", "LavaLight" }, a = Color3.fromRGB(255, 151, 32) }
tbl1.b = Color3.fromRGB(255, 132, 32)
local tbl2 = { tbl1 }
local tbl3 = {}
local var3 = require(game:GetService("ReplicatedStorage").Client.SettingFlag)
local function distanceTo(arg1, arg2)
	local var1 = arg1.CFrame:PointToObjectSpace(arg2)
	local var2 = arg1.Size / 2
	return (var1 - Vector3.new(math.clamp(var1.X, -var2.X, var2.X), math.clamp(var1.Y, -var2.Y, var2.Y), (math.clamp(var1.Z, -var2.Z, var2.Z)))).Magnitude
end

task.delay(5, function()
	for k1, v1 in ipairs(workspace:GetDescendants()) do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		local var2 = v1.Parent
		var2 = var2 and (var2:IsA("Attachment") and var2.Parent)
		local var4 = var2 and (var2:IsA("BasePart") and var2) or nil
		var2 = v1:FindFirstAncestorWhichIsA("Model")
		local var5 = var2
		if not var4 or var5 and var2:FindFirstChildWhichIsA("Humanoid") then
			continue
		end

		if v1:IsDescendantOf(workspace.CurrentCamera) then
			continue
		end

		table.insert(tbl3, { emitter = v1, part = var4 })
	end

	local num1 = 0
	var1.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if num1 < 0.5 then
			return
		end

		num1 = 0
		var1 = workspace.CurrentCamera
		if not var1 then
			return
		end

		local var2 = var1.CFrame.Position
		local var4 = var3.on("particles")
		for k1, v1 in ipairs(tbl3) do
			local var5 = v1.emitter
			if not var5.Parent then
				continue
			end

			local var7 = var4
			local var8 = v1.part
			if var7 then
				var7 = distanceTo(var8, var2) <= 160
			end

			if var5.Enabled == var7 then
				continue
			end

			var5.Enabled = var7
		end
	end)
end)

task.delay(1, function()
	local var2 = game:GetService("Lighting")
	local var3 = game:GetService("TweenService")
	local tbl1 = { Brightness = 0, Contrast = 0, Saturation = 0, TintColor = Color3.new(1, 1, 1) }
	local tbl2 = {}
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("ColorCorrectionEffect") then
			continue
		end

		local var4 = v1:GetAttribute("ZoneBottom")
		if type(var4) ~= "number" then
			continue
		end

		local var5 = v1:GetAttribute("ZoneTop")
		if type(var5) ~= "number" then
			continue
		end

		local var6 = v1.TintColor
		local tbl3 = {
			Brightness = v1.Brightness,
			Contrast = v1.Contrast,
			Saturation = v1.Saturation,
			TintColor = var6,
		}

		table.insert(tbl2, { effect = v1, bottom = var4, top = var5, inside = false, target = tbl3 })
		for k2, v2 in pairs(tbl1) do
			v1[k2] = v2
		end

		v1.Enabled = false
	end

	if #tbl2 == 0 then
		return
	end

	local num1 = 0
	var1.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if num1 < 0.25 then
			return
		end

		num1 = 0
		var1 = workspace.CurrentCamera
		if not var1 then
			return
		end

		local var2 = var1.CFrame.Position.Y
		for k1, v1 in ipairs(tbl2) do
			local bool1 = false
			if v1.bottom <= var2 then
				bool1 = var2 <= v1.top
			end

			if bool1 == v1.inside then
				continue
			end

			v1.inside = bool1
			if v1.tween then
				v1.tween:Cancel()
			end

			v1.effect.Enabled = true
			local var4 = var3:Create(v1.effect, TweenInfo.new(1.2, Enum.EasingStyle.Sine), bool1 and v1.target or tbl1)
			v1.tween = var4
			var4.Completed:Connect(function(arg1)
				if arg1 == Enum.PlaybackState.Completed and (not v1.inside) then
					v1.effect.Enabled = false
				end
			end)

			var4:Play()
		end
	end)
end)

task.delay(1, function()
	local var2 = game:GetService("Lighting")
	local var3 = game:GetService("TweenService")
	local var4 = game:GetService("CollectionService")
	local tbl1 = { Atmosphere = var2:FindFirstChildWhichIsA("Atmosphere") }
	tbl1.Lighting = var2
	tbl1.Bloom = var2:FindFirstChildWhichIsA("BloomEffect")
	local tbl2 = { Density = true, Offset = true, Haze = true, Glare = true, Color = true, Decay = true }
	local tbl3 = {}
	local function learn(arg1)
		for k1 in pairs(arg1:GetAttributes()) do
			local var1
			local var2
			if tbl2[k1] then
				var1 = "Atmosphere"
				var2 = k1
			else
				local var5, var6 = k1:match("^(%a+)_(.+)$")
				if var5 == "Lighting" or var5 == "Bloom" then
					var1 = var5
					var2 = var6
				else
					var1 = nil
					var2 = nil
				end
			end

			local var7 = var1
			var7 = var7 and tbl1[var1]
			if not var7 then
				continue
			end

			local var8 = tbl3[var1]
			tbl3[var1] = var8 or {}
			if tbl3[var1][var2] ~= nil then
				continue
			end

			local success, result = pcall(function()
				return var7[var2]
			end)

			if not success then
				continue
			end

			tbl3[var1][var2] = result
		end
	end

	local tbl4 = {}
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("Configuration") then
			continue
		end

		local str1 = "ZoneBottom"
		if type(v1:GetAttribute(str1)) ~= "number" then
			continue
		end

		str1 = "ZoneTop"
		if type(v1:GetAttribute(str1)) ~= "number" then
			continue
		end

		table.insert(tbl4, v1)
		learn(v1)
	end

	local str2 = "AtmosphereZone"
	for k2, v2 in ipairs(var4:GetTagged(str2)) do
		learn(v2)
	end

	local num1 = 0
	local var5 = nil
	local var6 = nil
	local tbl5 = {}
	local function compose(arg1, arg2)
		local tbl1 = {}
		for k1, v1 in pairs(tbl3) do
			tbl1[k1] = {}
			for k2, v2 in pairs(v1) do
				tbl1[k1][k2] = v2
			end
		end

		local var1 = arg2 or false
		for k3, v3 in ipairs({ arg1 or false, var1 }) do
			if not v3 then
				continue
			end

			for k4, v4 in pairs(v3:GetAttributes()) do
				local var2
				local var3
				if tbl2[k4] then
					var2 = "Atmosphere"
					var3 = k4
				else
					local var6, var7 = k4:match("^(%a+)_(.+)$")
					if var6 == "Lighting" or var6 == "Bloom" then
						var2 = var6
						var3 = var7
					else
						var2 = nil
						var3 = nil
					end
				end

				local var8 = var2
				var8 = var8 and (tbl1[var2] and tbl1[var2][var3])
				if var8 == nil then
					continue
				end

				if typeof(v4) ~= typeof(var8) then
					continue
				end

				tbl1[var2][var3] = v4
			end
		end

		return tbl1
	end

	var1.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if num1 < 0.25 then
			return
		end

		num1 = 0
		var1 = workspace.CurrentCamera
		if not var1 then
			return
		end

		local var7 = var1.CFrame.Position
		local var8 = nil
		for k1, v1 in ipairs(tbl4) do
			if v1.Parent ~= var2 then
				continue
			end

			if v1:GetAttribute("ZoneBottom") > var7.Y then
				continue
			end

			if var7.Y > v1:GetAttribute("ZoneTop") then
				continue
			end

			var8 = v1
			break
		end

		local str1 = "AtmosphereZone"
		local var9 = nil
		local num2 = math.huge
		for k2, v2 in ipairs(var4:GetTagged(str1)) do
			if not v2:IsA("BasePart") then
				continue
			end

			if not v2:IsDescendantOf(workspace) then
				continue
			end

			local var10 = v2.CFrame:PointToObjectSpace(var7)
			local var11 = v2.Size / 2
			local bool2 = false
			if math.abs(var10.X) <= var11.X then
				bool2 = false
				if math.abs(var10.Y) <= var11.Y then
					bool2 = math.abs(var10.Z) <= var11.Z
				end
			end

			if not bool2 then
				continue
			end

			bool2 = v2.Size.X * v2.Size.Y * v2.Size.Z
			if bool2 >= num2 then
				continue
			end

			var9 = v2
			local var12 = bool2
		end

		if var8 == var5 and var9 == var6 then
			return
		end

		var5 = var8
		var6 = var9
		if var9 then
			learn(var9)
		end

		for k3, v3 in ipairs(tbl5) do
			v3:Cancel()
		end

		table.clear(tbl5)
		local var13 = var8
		local var14 = compose(var13, var9)
		for k4, v4 in pairs(var14) do
			local var15 = tbl1[k4]
			if not var15 then
				continue
			end

			if not next(v4) then
				continue
			end

			local var16 = var3:Create(var15, TweenInfo.new(1.5, Enum.EasingStyle.Sine), v4)
			table.insert(tbl5, var16)
			var16:Play()
		end
	end)
end)

return { init = function(_)
	local tbl1 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(tbl2) do
		local var3 = workspace
		for k2, v2 in ipairs(v1.path) do
			local var4 = var3
			var3 = var4 and var3:FindFirstChild(v2)
		end

		local var5 = var3
		var5 = var5 and var3:FindFirstChildWhichIsA("Light")
		local var6
		if var5 then
			var6 = var3:IsA("BasePart")
			local tbl4 = { light = var5, def = v1, brightness = var5.Brightness, seed = math.random() * 1000 }
			tbl4.origin = var6 and var3.Position or nil
			table.insert(tbl1, tbl4)
		else
			var6 = v1.path
			warn("[Ambience] no light at Workspace." .. table.concat(var6, "."))
		end
	end

	local var7 = workspace:FindFirstChild("Runes")
	for k3, v3 in ipairs(var7 and var7:GetDescendants() or {}) do
		local var8 = v3.Name
		if var8 ~= "Crystal" then
			continue
		end

		var8 = v3:IsA("BasePart")
		if not var8 then
			continue
		end

		v3.Anchored = true
		table.insert(tbl3, { part = v3, rest = v3.CFrame, phase = math.random() * 3.1415926535897931 * 2 })
	end

	if #tbl1 == 0 and #tbl3 == 0 then
		return
	end

	local tbl5 = {}
	for k4, v4 in ipairs(tbl3) do
		table.insert(tbl5, v4.rest.Position)
	end

	for k5, v5 in ipairs(tbl1) do
		if not v5.origin then
			continue
		end

		table.insert(tbl5, v5.origin)
	end

	local bool1 = false
	task.spawn(function()
		while true do
			local var1 = var2.Character
			local var3 = var1
			var3 = var3 and var1:FindFirstChild("HumanoidRootPart")
			bool1 = false
			local var4
			if var3 then
				for k1, v1 in ipairs(tbl5) do
					if (var3.Position - v1).Magnitude > 200 then
						continue
					end

					bool1 = true
					break
				end
			end

			task.wait(0.25)
		end
	end)

	local num1 = 0
	var1.Heartbeat:Connect(function(arg1)
		if not bool1 then
			return
		end

		local var1 = num1 + arg1
		num1 = var1
		for k1, v1 in ipairs(tbl1) do
			local var2 = math.clamp(math.noise(num1 * 0.35, v1.seed) * 0.7 + math.noise(num1 * 1.4, v1.seed + 17) * 0.3 + 0.5, 0, 1)
			v1.light.Color = v1.def.a:Lerp(v1.def.b, var2)
			v1.light.Brightness = v1.brightness * ((var2 * 2 - 1) * 0.12 + 1)
		end

		for k2, v2 in ipairs(tbl3) do
			v2.part.CFrame = CFrame.new(v2.rest.Position + Vector3.new(0, math.sin(num1 * 1.9634954084936207 + v2.phase) * 0.8, 0)) * v2.rest.Rotation * CFrame.Angles(0, math.rad(num1 * 35) + v2.phase, 0)
		end
	end)
end }

--- ReplicatedStorage.Client.DoorClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local num1 = 124
local num2 = 23
local num3 = 23
local var2 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 229
num3 = 123
local num4 = 123
local num5 = 1
local var3 = ColorSequence.new({ var2, ColorSequenceKeypoint.new(num5, Color3.fromRGB(num2, num3, num4)) })
local var4 = game:GetService("RunService")
local tbl1 = {}
local var5 = require(var1.Shared.Remotes)
var4.Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			var5.UnlockDoor:FireServer(v1)
		end)

	end
end)

local var6 = game:GetService("TweenService")
local var7 = require(var1.Shared.NumberFormat)
local var8 = require(var1.Shared.StairConfig)
local var9 = require(var1.Packages.DataService).client
local var10 = require(var1.Shared.RebirthConfig)
local var11 = require(var1.Shared.DoorConfig)
local var12 = Color3.fromRGB(255, 110, 110)
num1 = function(arg1)
	local var1 = arg1.facing
	local var2 = Instance.new("Highlight")
	var2.FillColor = Color3.new(1, 1, 1)
	var2.OutlineColor = Color3.new(1, 1, 1)
	var2.FillTransparency = 0.8
	var2.OutlineTransparency = 0.8
	var2.DepthMode = Enum.HighlightDepthMode.Occluded
	var2.Adornee = arg1.model
	var2.Parent = arg1.model
	local var3 = Enum.EasingDirection.Out
	var6:Create(var2, TweenInfo.new(0.3, Enum.EasingStyle.Quad, var3), { FillTransparency = 1, OutlineTransparency = 1 }):Play()
	local var7 = arg1.centre
	local var8 = -var1
	local var9 = nil
	if arg1.lightHost then
		var9 = Instance.new("PointLight")
		var9.Color = Color3.fromRGB(255, 236, 190)
		var9.Range = 40
		var9.Brightness = 1.5
		var9.Shadows = false
		var9.Parent = arg1.lightHost
		var3 = Enum.EasingStyle.Quad
		var6:Create(var9, TweenInfo.new(0.5, var3, Enum.EasingDirection.Out), { Brightness = 0 }):Play()
	end

	local tbl1 = {}
	for k1, v1 in ipairs(arg1.shards) do
		local var10 = v1.Position - var7
		local var11 = var10 - var1 * var10:Dot(var1)
		local var12 = 11 * (0.6 + math.random() * 0.8)
		local var13 = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5)
		local tbl2 = {
			part = v1,
			cframe = v1.CFrame,
			velocity = (0.01 < var11.Magnitude and var11.Unit or Vector3.new(0, 1, 0)) * var12 + var8 * 20 * (0.7 + math.random() * 0.6) + Vector3.new(0, 5, 0),
		}

		tbl2.axis = 0.01 < var13.Magnitude and var13.Unit or Vector3.new(0, 1, 0)
		tbl2.spin = 5.5 * (0.4 + math.random() * 0.6)
		tbl2.base = v1.Transparency
		table.insert(tbl1, tbl2)
		v1.CanCollide = false
		v1.CanQuery = false
		v1.CanTouch = false
	end

	local num1 = 0
	local var14 = nil
	var4.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		var1 = math.clamp((num1 - 0.5) / 0.7, 0, 1)
		for k1, v1 in ipairs(tbl1) do
			local var3 = v1.velocity - Vector3.new(0, 24 * arg1, 0)
			v1.velocity = var3
			var3 = (v1.cframe + v1.velocity * arg1) * CFrame.fromAxisAngle(v1.axis, v1.spin * arg1)
			v1.cframe = var3
			v1.part.CFrame = v1.cframe
			v1.part.Transparency = v1.base + (1 - v1.base) * var1
		end

		if 1.2 <= num1 then
			var14:Disconnect()
			for k2, v2 in ipairs(tbl1) do
				local var4 = v2.part
				var4.Transparency = 1
				var4.CanCollide = false
				var4.CanQuery = false
				var4.CanTouch = false
				var4.CastShadow = false
			end

			var2:Destroy()
			if var9 then
				var9:Destroy()
			end
		end
	end)
end

local var13 = require(var1.Client.WorldTap)
local var14 = require(var1.Client.UISound)
num2 = function(arg1, arg2)
	local var5 = arg2:FindFirstChild(arg1.model)
	if not var5 then
		local var6 = arg1.model
		local var15 = arg1.id
		warn(("[Doors] no Workspace.Doors.%s for door '%s'"):format(var6, var15))
		return
	end

	local var16 = var5:FindFirstChild("UIPart")
	local var17 = var16
	var17 = var17 and var16:FindFirstChildWhichIsA("SurfaceGui")
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(var5:GetChildren()) do
		if not v1:IsA("BasePart") or v1 == var16 then
			continue
		end

		table.insert(tbl2, v1)
		tbl3[v1] = {
			CFrame = v1.CFrame,
			Transparency = v1.Transparency,
			CanCollide = v1.CanCollide,
			CanQuery = v1.CanQuery,
			CanTouch = v1.CanTouch,
			CastShadow = v1.CastShadow,
		}

	end

	local var18, var19 = var5:GetBoundingBox()
	local var20 = var17.Face
	local var21 = var16 and (var17 and var16.CFrame:VectorToWorldSpace(Vector3.FromNormalId(var20))) or var18.LookVector
	local tbl4 = {
		model = var5,
		shards = tbl2,
		centre = var18.Position,
		lightHost = var16,
		facing = var21,
		open = false,
	}

	var21 = var17
	var21 = var21 and var17:FindFirstChildWhichIsA("GuiObject")
	local var22 = nil
	local var23 = nil
	var20 = nil
	local var24 = nil
	local var25 = nil
	local var26 = nil
	if var21 then
		for k2, v2 in ipairs(var21:GetChildren()) do
			if not v2:IsA("TextLabel") then
				continue
			end

			if not v2.Text:lower():find("floor") then
				continue
			end

			var22 = v2
		end

		var20 = var21:FindFirstChild("Buy")
		local var27 = var20
		var27 = var27 and var20:FindFirstChild("BG")
		local var28 = var27
		var24 = var28 and var27:FindFirstChildWhichIsA("UIGradient")
		var28 = var24
		var25 = var28 and var24.Color
		var28 = var22
		var23 = var21:FindFirstChild("Cost")
		var26 = var28 and var22.TextColor3
		if var22 then
			var22.Text = ("Floor %d Required"):format(arg1.floor)
		end

		if var23 then
			var23.Text = var7.price(arg1.cost) .. " " .. arg1.currency:upper()
		end
	end

	local var29 = var8.collect()
	local var30 = var11.rebirthsNeeded(arg1)
	local function refresh()
		if tbl4.open then
			return
		end

		local var4 = arg1.floor <= var8.floorFor(var9:get("stairsOwned") or 1, var29)
		local var5 = var30 <= (var9:get("rebirths") or 0)
		if var22 then
			if var4 and (not var5) then
				var22.Text = ("Rebirth %d Required"):format(var30)
			else
				var22.Text = ("Floor %d Required"):format(arg1.floor)
			end

			var22.TextColor3 = var4 and (var5 and var26) or var12
		end

		if var24 then
			local var6 = var24
			if var4 then
				if var5 then
					if var23 then
						var23.Text = var7.price(arg1.currency == "gold" and var10.scaledCost(arg1.cost, var9:get("rebirths") or 0) or arg1.cost) .. " " .. arg1.currency:upper()
					end

					local var11 = (arg1.currency == "gold" and var10.scaledCost(arg1.cost, var9:get("rebirths") or 0) or arg1.cost) <= (var9:get(arg1.currency) or 0) and var25 or var3
				end
			end

			var6.Color = var3
		end
	end

	local function close()
		if not tbl4.open then
			return
		end

		tbl4.open = false
		for k1, v1 in pairs(tbl3) do
			for k2, v2 in pairs(v1) do
				k1[k2] = v2
			end
		end

		if var17 then
			var17.Enabled = true
		end

		refresh()
	end

	if var20 then
		var13.bind(var20, function()
			if tbl4.open then
				return
			end

			if arg1.floor <= var8.floorFor(var9:get("stairsOwned") or 1, var29) then
				if var30 <= (var9:get("rebirths") or 0) then
					if var23 then
						var23.Text = var7.price(arg1.currency == "gold" and var10.scaledCost(arg1.cost, var9:get("rebirths") or 0) or arg1.cost) .. " " .. arg1.currency:upper()
					end

					if not ((arg1.currency == "gold" and var10.scaledCost(arg1.cost, var9:get("rebirths") or 0) or arg1.cost) <= (var9:get(arg1.currency) or 0)) then
						var14.play("denied")
						return
					end
				end
			end

			var14.play("purchase")
			table.insert(tbl1, arg1.id)
		end)

	end

	local var31 = arg1.id
	if var9:get({ "doors", var31 }) then
	if not tbl4.open then
			tbl4.open = true
			if var17 then
				var17.Enabled = false
			end

			for k3, v3 in ipairs(tbl2) do
				v3.Transparency = 1
				v3.CanCollide = false
				v3.CanQuery = false
				v3.CanTouch = false
				v3.CastShadow = false
			end
		end
	else
		refresh()
	end

	var9:getChangedSignal("doors"):Connect(function()
		if var9:get({ "doors", arg1.id }) then
			if tbl4.open then
				return
			end

			tbl4.open = true
			if var17 then
				var17.Enabled = false
			end

			num1(tbl4)
			return
		end

		if tbl4.open then
			close()
		end
	end)

	var9:getChangedSignal("stairsOwned"):Connect(refresh)
	var9:getChangedSignal("rebirths"):Connect(refresh)
	var9:getChangedSignal(arg1.currency):Connect(refresh)
end

local var15 = game:GetService("Players").LocalPlayer
return { init = function(_)
	local var2 = workspace:WaitForChild("Doors", 20)
	if not var2 then
		warn("[Doors] no Workspace.Doors - no doors to drive")
		return
	end

	for k1, v1 in ipairs(var11.DOORS) do
		num2(v1, var2)
	end
end }

--- ReplicatedStorage.Client.FloorHUD [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = game:GetService("TweenService")
local var4 = require(var1.Shared.StairConfig)
local function landings(arg1)
	local tbl1 = {}
	for i1 = 1, #arg1 do
		local var1 = arg1[i1]
		if not var1 then
			continue
		end

		if var1.Name ~= "EndStair" then
			continue
		end

		table.insert(tbl1, i1)
	end

	return tbl1
end

local var5 = require(var1.Packages.DataService).client
local function progress(arg1, arg2)
	local num1 = 0
	for k1, v1 in ipairs(arg2) do
		if v1 <= arg1 then
			num1 = v1
		else
			return (arg1 - num1) / (v1 - num1)
		end
	end

	return 1
end

return { init = function(_)
	local var1 = var2:WaitForChild("PlayerGui")
	local var6 = nil
	local var7 = os.clock() + 20
	repeat
		for k1, v1 in ipairs(var1:GetDescendants()) do
			if v1.Name ~= "FloorCounter" then
				continue
			end

			if not v1:IsA("TextLabel") then
				continue
			end

			var6 = v1
			break
		end

		if not var6 then
			task.wait(0.2)
		end
	until var6 or var7 < os.clock()

	if not var6 then
		warn("[Floors] no FloorCounter label in the PlayerGui")
		return
	end

	local var9 = var6:FindFirstChildWhichIsA("UIScale")
	if not var9 then
		var9 = Instance.new("UIScale")
		var9.Parent = var6
	end

	local var10 = var6:FindFirstChild("Bar")
	local var11 = var10
	var11 = var11 and var10:FindFirstChild("Fill")
	local var12 = var11
	local var13 = nil
	var12 = var12 and var11.Size.Y
	local var14 = var4.collect()
	local var15 = landings(var14)
	local var16 = nil
	local function setFill(arg1, arg2)
		if not var11 then
			return
		end

		if var13 then
			var13:Cancel()
		end

		local var1 = UDim2.new(UDim.new(math.clamp(arg1, 0, 1), 0), var12)
		local var2 = TweenInfo.new(arg2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var13 = var3:Create(var11, var2, { Size = var1 })
		var13:Play()
		return var13
	end

	local var17 = var9.Scale
	local function update()
		local var1 = var5:get("stairsOwned") or 1
		local var8 = var4.floorFor(var1, var14)
		local var10 = progress(var1, var15)
		if var8 == var16 then
			setFill(var10, 0.25)
			return
		end

		local bool1 = false
		if var16 ~= nil then
			bool1 = var16 < var8
		end

		var16 = var8
		var6.Text = "Floor " .. var8
		if bool1 then
			var9.Scale = var17 * 1.25
			local var13 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
			var3:Create(var9, var13, { Scale = var17 }):Play()
			local var19 = setFill(1, 0.18)
			if var19 then
				var19.Completed:Connect(function()
					if var16 == var8 and var11 then
						var11.Size = UDim2.new(UDim.new(0, 0), var12)
						setFill(var10, 0.25)
					end
				end)

				return
			end
		end

		local var20 = setFill
		local var21 = var10
		var20(var21, if bool1 then 0.25 else 0)
	end

	update()
	var5:getChangedSignal("stairsOwned"):Connect(update)
end }

--- ReplicatedStorage.Client.GlyphClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Packages.DataService).client
local var3 = require(var1.Shared.TreeConfig)
local var4 = require(var1.Shared.TotemConfig)
local var5 = require(var1.Shared.GlyphConfig)
local var6 = require(var1.Shared.UpgradeConfig)
local var7 = require(var1.Shared.PassConfig)
local var8 = require(var1.Client.PassState)
local var9 = require(var1.Shared.TrailConfig)
local tbl1 = {}
local var10 = game:GetService("TextService")
local num1 = 0
local var11 = game:GetService("TweenService")
local var12 = require(var1.Client.GlyphColors)
local var13 = require(var1.Shared.NumberFormat)
local var14 = game:GetService("Players").LocalPlayer
local var15 = Color3.new(1, 1, 1)
local tbl2 = { root = nil, emitters = {} }
local num2 = 0
local num3 = 0
local function mountEffect(arg1)
	local var2 = var1:FindFirstChild("Effects")
	local var3 = var2
	var2 = var3 and var2:FindFirstChild("Particles")
	var3 = var2
	var3 = var3 and var2:FindFirstChild("GlyphOpen")
	if not var3 then
		return false
	end

	tbl2.root = arg1
	tbl2.emitters = {}
	for k1, v1 in ipairs(var3:GetChildren()) do
		local var4
		if v1:IsA("Attachment") or v1:IsA("ParticleEmitter") then
			local var5 = v1:Clone()
			var5.Parent = arg1
			if var5:IsA("ParticleEmitter") then
				local tbl1 = { var5 }
				tbl1 = tbl1 or var5:GetDescendants()
			end

			for k2, v2 in ipairs((var5:GetDescendants())) do
				if not v2:IsA("ParticleEmitter") then
					continue
				end

				v2.Enabled = false
				local var6 = v2:GetAttribute("Emit")
				if type(var6) ~= "number" then
					var6 = if v2.Speed.Max <= 0.01 then 1 else 12
				end

				table.insert(tbl2.emitters, { emitter = v2, count = var6, color = v2.Color })
			end
		end
	end

	return 0 < (#tbl2.emitters)
end

local tbl3 = { color = Color3.fromRGB(190, 130, 255), icon = "rbxassetid://113242180194185" }
local tbl4 = { essence = tbl3 }
tbl3 = { color = Color3.fromRGB(214, 196, 178), icon = "rbxassetid://72229364295214" }
tbl4.ingots = tbl3
local function widthAtRef(arg1, arg2)
	arg2 = arg2:gsub("%d", "0")
	local var1 = arg2 .. "\0" .. arg1.FontFace.Family
	local var3 = tbl1[var1]
	if var3 then
		return var3
	end

	local var4 = Instance.new("GetTextBoundsParams")
	var4.Text = arg2
	var4.Font = arg1.FontFace
	var4.Size = 100
	var4.Width = 1000000
	local success, result = pcall(function()
		local var1 = var4
		return var10:GetTextBoundsAsync(var1)
	end)

	if not success or (not result) then
		return nil
	end

	if 400 < num1 then
		table.clear(tbl1)
		num1 = 0
	end

	tbl1[var1] = result.X
	local var5 = num1 + 1
	num1 = var5
	return result.X
end

local function luckNow()
	local var1 = var2:get("upgrades")
	local str1 = "tree"
	local var10 = var3.totals(var2:get(str1))
	local var11 = var2:get("glyphs")
	local var12 = var5.multipliers(var11 or {}).luck
	local var13 = var12 * var6.BY_ID.glyphLuck.value((var1 or {}).glyphLuck or 0)
	local var14 = var13 * (var10.luck or 1)
	local var15 = var14 * (var7.totals(var8.owned).luck or 1)
	local str2 = "equippedTrail"
	str1 = var15 * (var4.totals(var2:get("totems"), var10.totemBoost).luck or 1)
	return str1 * (var9.totals(var2:get("trails"), var2:get(str2)).luck or 1)
end

local function bindBoard(arg1, arg2)
	local var1 = workspace:FindFirstChild("Runes")
	local var3 = var1
	var3 = var3 and var1:FindFirstChild(arg1.model)
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("UI")
	local var6 = var4
	var6 = var6 and var4:FindFirstChildWhichIsA("BillboardGui")
	local var7 = var6
	var7 = var7 and var6:FindFirstChild("GlyphInfo")
	if not var7 then
		local var10 = arg1.model
		local var12 = arg1.id
		warn(("[Glyphs] no board on Workspace.Runes.%s - nothing to draw for %s"):format(var10, var12))
		return nil
	end

	local var16 = var7:FindFirstChild("Title")
	local var17 = var7:FindFirstChild("List")
	local var18 = var7:FindFirstChild("BuffList")
	local var19 = var7:FindFirstChild("TotalOpened")
	local var20 = var7:FindFirstChild("Cost")
	if var16 then
		var16.Text = arg1.name
	end

	local var22
	if var20 then
		local var23 = arg1.currency
		var23 = var23 or var5.CURRENCY
		local var24 = tbl4[var23]
		local var25 = var24 and var13.suffix(arg1.cost):gsub("(%.%d-)0+(%a*)$", "%1%2"):gsub("%.(%a*)$", "%1") or var5.costText(arg1.cost)
		var22 = " "
		var20.Text = var25 .. var22 .. (if var23 == "ingots" then "IRON" else var23:upper())
		if var24 then
			if var24.color then
				var20.TextColor3 = var24.color
			end

			var22 = "Coin"
			local var27 = var7:FindFirstChild(var22)
			if var24.icon then
				if var27 then
					if var27:IsA("ImageLabel") then
						var27.Image = var24.icon
					end
				end
			end
		end
	end

	local tbl1 = {}
	for k1, v1 in ipairs(arg1.list) do
		local var28 = var17
		var28 = var28 and var17:FindFirstChild(v1.name)
		if var28 then
			if var28:IsA("TextLabel") then
				local var29 = arg2[v1.id]
				var29 = var29 or var28.TextColor3
				var28.TextColor3 = var29
				tbl1[v1.id] = { label = var28, color = var29, def = v1 }
			elseif var17 then
				local var30 = v1.name
				local var31 = arg1.id
				warn(("[Glyphs] no List.%s on the %s board"):format(var30, var31))
			end
		elseif var17 then
			local var32 = v1.name
			local var33 = arg1.id
			warn(("[Glyphs] no List.%s on the %s board"):format(var32, var33))
		end
	end

	local bool1 = false
	local bool2 = false
	local num1 = 0
	local var34 = nil
	local function flash(arg1)
		arg1.label.TextColor3 = var15
		local var1 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var11:Create(arg1.label, var1, { TextColor3 = arg1.color }):Play()
	end

	local function fitRows()
		if bool1 then
			bool2 = true
			return
		end

		bool1 = true
		task.spawn(function()
			local var2 = 0.2 - (os.clock() - num1)
			if 0 < var2 then
				task.wait(var2)
			end

			repeat
				bool2 = false
				num1 = os.clock()
				local num2 = math.huge
				for k1, v1 in pairs(tbl1) do
					local var4 = v1.label.AbsoluteSize.X
					local bool4 = false
					if 1 < var4 then
						bool4 = widthAtRef(v1.label, v1.label.Text)
					end

					if not bool4 or 0 >= bool4 then
						continue
					end

					num2 = math.min(num2, 100 * var4 * 0.94 / bool4)
				end

				local var5 = math.clamp(math.floor(num2), 1, 100)
				local var6
				if num2 < math.huge and var5 ~= var34 then
					var34 = var5
					for k2, v2 in pairs(tbl1) do
						local var7 = v2.label
						local var9 = var7:FindFirstChild("RowFit")
						if not var9 then
							var9 = Instance.new("UITextSizeConstraint")
							var9.Name = "RowFit"
							var9.MinTextSize = 1
							var9.Parent = var7
						end

						var9.MaxTextSize = var5
					end
				end
			until not bool2

			bool1 = false
		end)
	end

	if var17 then
		var17:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitRows)
	end

	local tbl2 = {}
	local tbl3 = {}
	return {
		rows = function(arg1)
			local var1 = var2:get("glyphs")
			var1 = var1 or {}
			local var3 = var5.chances(arg1, luckNow(), var1)
			local bool3 = false
			for k1, v1 in pairs(tbl1) do
				local var6 = var1[k1] or 0
				local var7 = ("%s %s"):format(v1.def.name, if v1.def.cap <= var6 then "MAX" else var5.chanceText(var3[k1]))
				if 0 < var6 then
					var7 = var7 .. "  x" .. var13.format(var6)
				end

				if var7 == tbl2[k1] then
					continue
				end

				tbl2[k1] = var7
				v1.label.Text = var7
				if arg1 and (tbl3[k1] and tbl3[k1] < var6) then
					flash(v1)
				end

				tbl3[k1] = var6
				bool3 = true
			end

			if bool3 then
				if bool1 then
					bool2 = true
					return
				end

				bool1 = true
				task.spawn(function()
					local var2 = 0.2 - (os.clock() - num1)
					if 0 < var2 then
						task.wait(var2)
					end

					repeat
						bool2 = false
						num1 = os.clock()
						local num2 = math.huge
						for k1, v1 in pairs(tbl1) do
							local var4 = v1.label.AbsoluteSize.X
							local bool4 = false
							if 1 < var4 then
								bool4 = widthAtRef(v1.label, v1.label.Text)
							end

							if not bool4 or 0 >= bool4 then
								continue
							end

							num2 = math.min(num2, 100 * var4 * 0.94 / bool4)
						end

						local var5 = math.clamp(math.floor(num2), 1, 100)
						local var6
						if num2 < math.huge and var5 ~= var34 then
							var34 = var5
							for k2, v2 in pairs(tbl1) do
								local var7 = v2.label
								local var9 = var7:FindFirstChild("RowFit")
								if not var9 then
									var9 = Instance.new("UITextSizeConstraint")
									var9.Name = "RowFit"
									var9.MinTextSize = 1
									var9.Parent = var7
								end

								var9.MaxTextSize = var5
							end
						end
					until not bool2

					bool1 = false
				end)

			end
		end,
		buffs = function(arg1)
			if not var18 then
				return
			end

			local var1 = arg1
			arg1 = var1 or var5.multipliers({})
			local tbl1 = { "Silver", arg1.silver }
			for k1, v1 in ipairs({
				{ "Gold", arg1.gold },
				tbl1,
				{ "Luck", arg1.luck },
				{ "Iron", arg1.iron },
				{ "Crystals", arg1.crystals },
				{ "Wood", arg1.wood },
				{ "Essence", arg1.essence },
			}) do

				local var3 = var18:FindFirstChild(v1[1])
				if not var3 then
					continue
				end

				if not var3:IsA("TextLabel") then
					continue
				end

				local var4 = v1[1] .. ": " .. var5.multiplierText(v1[2])
				if var3.Text == var4 then
					continue
				end

				var3.Text = var4
			end
		end,
		total = function()
			if var19 then
				local var3 = var2:get({ "glyphPulls", arg1.id })
				if var3 == nil then
					local var4 = var2:get("glyphs")
					var3 = 0
					var4 = var4 or {}
					for k1, v1 in ipairs(arg1.list) do
						var3 = var3 + (var4[v1.id] or 0)
					end
				end

				local var6 = var13.format(var3) .. " Opened"
				if var19.Text ~= var6 then
					var19.Text = var6
				end
			end
		end,
		part = var4,
	}
end

local function openEffect(arg1)
	local var1 = os.clock()
	local var3 = var1 - num2 < 0.5
	num2 = var1
	if var1 - num3 < 0.35 then
		return
	end

	local var5 = var2:get("settings")
	if var5 and var5.particles == false then
		return
	end

	local var6 = var14.Character
	local var7 = var6
	var7 = var7 and var6:FindFirstChild("HumanoidRootPart")
	if not var7 then
		return
	end

	if tbl2.root ~= var7 and (not mountEffect(var7)) then
		return
	end

	for k1, v1 in ipairs(tbl2.emitters) do
		local var8 = arg1 and (arg1.vfx and ColorSequence.new(arg1.vfx)) or v1.color
		v1.emitter.Color = var8
		local var9 = v1.emitter
		if var3 then
			local var10 = math.max(1, (math.floor(v1.count * 0.4)))
			var10 = var10 or v1.count
		end

		var9:Emit(v1.count)
	end

	num3 = var1
end

return { init = function(_)
	if not workspace:WaitForChild("Runes", 20) then
		warn("[Glyphs] no Workspace.Runes - no boards to draw")
		return
	end

	local var1 = var12.get()
	local tbl1 = {}
	for k1, v1 in ipairs(var5.SETS) do
		local var3 = bindBoard(v1, var1)
		if not var3 then
			continue
		end

		table.insert(tbl1, var3)
	end

	(function(arg1)
		for k1, v1 in ipairs(tbl1) do
			v1.rows(arg1)
			v1.buffs()
			v1.total()
		end
	end)(false)

	local tbl2 = {}
	local str1 = "upgrades"
	local function redraw(arg1)
		local var1 = var2:get("glyphs")
		local var3 = var5.multipliers(var1 or {})
		for k1, v1 in ipairs(tbl1) do
			local var6 = workspace.CurrentCamera
			local var7
			if not var6 or (not v1.part) then
				var7 = true
			elseif (var6.CFrame.Position - v1.part.Position).Magnitude > 220 then
				var7 = false
			end

			if var7 then
				tbl2[v1] = nil
				v1.rows(arg1)
				v1.buffs(var3)
			else
				tbl2[v1] = true
			end
		end
	end

	for k2, v2 in ipairs({ "tree", str1, "trails", "equippedTrail", "totems" }) do
		var2:getChangedSignal(v2):Connect(function()
			redraw(false)
		end)

	end

	local bool1 = false
	var2:getChangedSignal("glyphs"):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.3, function()
			bool1 = false
			redraw(true)
		end)
	end)

	task.spawn(function()
		while true do
			task.wait(1)
			if not next(tbl2) then
				continue
			end

			local var1 = nil
			for k1 in pairs(tbl2) do
				local var4 = workspace.CurrentCamera
				local var6
				if not var4 or (not k1.part) then
					var6 = true
				else
					var6 = (var4.CFrame.Position - k1.part.Position).Magnitude <= 220
				end

				if not var6 then
					continue
				end

				tbl2[k1] = nil
				var6 = var1
				var1 = var6 or var5.multipliers({})
				k1.rows(false)
				k1.buffs(var1)
			end
		end
	end)

	local var4 = var2:get("glyphOpens")
	local var6 = var4
	local tbl3 = {}
	for k3, v3 in pairs(var6 or {}) do
		tbl3[k3] = v3
	end

	var2:getChangedSignal("glyphPulls"):Connect(function()
		for k1, v1 in ipairs(tbl1) do
			v1.total()
		end
	end)

	var2:getChangedSignal("glyphOpens"):Connect(function()
		local var1 = var2:get("glyphOpens")
		var1 = var1 or {}
		for k1, v1 in ipairs(var5.SETS) do
			local var4 = var1[v1.id] or 0
			if (tbl3[v1.id] or 0) < var4 then
				openEffect(v1)
			end

			tbl3[v1.id] = var4
		end

		for k2, v2 in ipairs(tbl1) do
			v2.total()
		end
	end)
end }

--- ReplicatedStorage.Client.GlyphMenu [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = require(var1.Client.GlyphColors)
local var4 = require(var1.Shared.GlyphConfig)
local var5 = require(var1.Packages.DataService).client
local var6 = require(var1.Shared.NumberFormat)
local var7 = Color3.fromRGB(105, 105, 105)
local var8 = require(game:GetService("ReplicatedStorage").Client.Press)
local var9 = require(var1.Client.MenuEffects)
local tbl1 = {}
tbl1.init = function(_)
	local var1 = var2:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var10 = var1
	var10 = var10 and var1:FindFirstChild("Glyphs")
	local var11 = var10
	var11 = var11 and var10:FindFirstChild("GlyphScroller")
	local var12 = var11
	local var13 = var11
	var12 = var12 and var11:FindFirstChildWhichIsA("UIGridLayout")
	var13 = var13 and var11:FindFirstChild("Glyph")
	if not var10 or (not var11 or (not var12 or (not var13))) then
		warn("[Glyphs] no Main.Glyphs.GlyphScroller.Glyph - no collection to build")
		return
	end

	var13.Parent = nil
	local function designedWindow()
		local var1 = var11.AbsoluteWindowSize
		local num1 = 1
		local var2 = var11
		local var3 = var2:FindFirstChildWhichIsA("UIScale")
		while not var2 and var2 == var11.Parent.Parent and var3 and 0 < var3.Scale do
		end

		return var1 / math.max(num1, 0.01)
	end

	local var14 = var12.CellSize
	local str1 = "Essence"
	local var15 = var3.get()
	local function relayout(arg1)
		local var1 = designedWindow()
		if var1.X < 1 or var1.Y < 1 then
			return
		end

		local var2 = Vector2.new((var1.X - var12.CellPadding.X.Offset * 1 - 1) / 2, var1.Y * var14.Y.Scale)
		var12.CellSize = UDim2.fromOffset(math.floor(var2.X), (math.floor(var2.Y)))
		var11.AutomaticCanvasSize = Enum.AutomaticSize.None
		var11.CanvasSize = UDim2.fromOffset(0, (math.ceil(arg1 * var2.Y + math.max(arg1 - 1, 0) * var12.CellPadding.Y.Offset)))
	end

	local tbl2 = { "Gold", "Silver", "Luck", "Iron", "Crystals", "Wood", str1 }
	local tbl3 = {}
	local num1 = 0
	for k1, v1 in ipairs(var4.SETS) do
		tbl3[v1.id] = v1
		num1 = math.max(num1, #v1.list)
	end

	local tbl4 = {}
	for i1 = 1, num1 do
		local var16 = var13:Clone()
		var16.Name = "Card" .. i1
		var16.LayoutOrder = i1
		var16.Visible = false
		local tbl5 = {}
		for k2, v2 in ipairs(var16:GetDescendants()) do
			local str2 = "TextLabel"
			if not v2:IsA(str2) then
				continue
			end

			tbl5[v2] = v2.TextColor3
		end

		local var18 = var16:FindFirstChild("Stats")
		local var19 = var16:FindFirstChild("Title")
		local tbl6 = {}
		local var20
		local var21
		if var18 then
			for k3, v3 in ipairs(tbl2) do
				var21 = v3
				local var22 = var18:FindFirstChild(var21)
				if not var22 then
					continue
				end

				var20 = var22:IsA("TextLabel")
				if not var20 then
					continue
				end

				tbl6[v3] = var22
			end
		end

		var16.Parent = var11
		local var23 = var19
		local tbl7 = {
			card = var16,
			labels = tbl5,
			title = var19,
			titleColor = var23 and tbl5[var19],
			stats = tbl6,
		}

		tbl7.collected = var16:FindFirstChild("Collected")
		tbl4[i1] = tbl7
	end

	local var24 = var4.SETS[1]
	local function refresh()
		local var1 = var5:get("glyphs")
		var1 = var1 or {}
		for k1, v1 in ipairs(tbl4) do
			local var2 = v1.def
			if not var2 then
				continue
			end

			local var3 = var1[var2.id] or 0
			if v1.shown == var3 then
				continue
			end

			v1.shown = var3
			local var8 = var4.contribution(var2, var3)
			local tbl1 = { "Silver", var8.silver }
			for k2, v2 in ipairs({
				{ "Gold", var8.gold },
				tbl1,
				{ "Luck", var8.luck },
				{ "Iron", var8.iron },
				{ "Crystals", var8.crystals },
				{ "Wood", var8.wood or 1 },
				{ "Essence", var8.essence or 1 },
			}) do

				local var9 = v1.stats[v2[1]]
				if not var9 then
					continue
				end

				var9.Text = v2[1] .. ": " .. var4.multiplierText(v2[2])
			end

			local var10
			local var11
			if v1.collected then
				local var12 = var2.cap
				var10 = var6.format((math.min(var3, var2.cap)))
				v1.collected.Text = ("%s/%s Collected"):format(var10, var6.format(var12))
			end

			for k3, v3 in pairs(v1.labels) do
				k3.TextColor3 = 0 < var3 and v3 or var7
			end
		end
	end

	refresh()
	local bool1 = false
	local bool2 = false
	var5:getChangedSignal("glyphs"):Connect(function()
		if not var10.Visible then
			bool1 = true
			return
		end

		if bool2 then
			return
		end

		bool2 = true
		task.delay(0.25, function()
			bool2 = false
			refresh()
		end)
	end)

	var10:GetPropertyChangedSignal("Visible"):Connect(function()
		if var10.Visible and bool1 then
			bool1 = false
			refresh()
		end
	end)

	local var25 = math.ceil(num1 / 2)
	relayout(var25)
	var11:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		relayout(var25)
	end)

	local var26 = var10:FindFirstChild("Scroller")
	local var27 = var26
	var24 = var24 and var4.SETS[1].id
	local function fill(arg1, arg2)
		arg1.def = arg2
		arg1.shown = nil
		local var1
		local var2
		if arg1.title then
			arg1.title.Text = arg2.name .. " Glyph"
			var2 = var15
			var1 = arg2.id
			local var3 = var2[var1]
			arg1.labels[arg1.title] = var3 or arg1.titleColor
		end

		for k1, v1 in pairs(arg1.stats) do
			v1.Visible = 0 < (arg2[k1:lower()] or 0)
		end
	end

	var27 = var27 and var26:FindFirstChildWhichIsA("GuiButton")
	local function show(arg1)
		var24 = arg1
		local var1 = tbl3[arg1]
		local var2 = var1 and var1.list or {}
		for k1, v1 in ipairs(tbl4) do
			local var4 = var2[k1]
			if var4 then
				if v1.def ~= var4 then
					fill(v1, var4)
				end

				v1.card.Visible = true
			else
				v1.def = nil
				v1.card.Visible = false
			end
		end

		relayout((math.ceil(#var2 / 2)))
		refresh()
	end

	local function buttonFor(arg1)
		local tbl1 = { arg1.id:lower(), arg1.name:lower() }
		for k1, v1 in ipairs(var26:GetChildren()) do
			if not v1:IsA("GuiButton") then
				continue
			end

			local var1 = v1:FindFirstChild("Title")
			local str1 = "TextLabel"
			local tbl2 = { v1.Name:lower(), var1 and (var1:IsA(str1) and var1.Text:lower()) or "" }
			for k2, v2 in ipairs(tbl1) do
				for k3, v3 in ipairs(tbl2) do
					if v3 ~= v2 then
						continue
					end

					return v1
				end
			end
		end

		return nil
	end

	if var26 then
		local tbl8 = {}
		for k4, v4 in ipairs(var4.SETS) do
			local var30 = buttonFor(v4)
			if not var30 then
				if var27 then
					if not tbl8[var27] then
						var30 = k4 == 1 and var27 or var27:Clone()
						local var34 = var30:FindFirstChild("Title")
						if var34 and var34:IsA("TextLabel") then
							var34.Text = v4.name
							local var35 = v4.color
							var35 = var35 or (v4.vfx or var34.TextColor3)
							var34.TextColor3 = var35
						end

						var30.Parent = var26
					elseif not var30 then
						if var27 then
							var30 = var27:Clone()
							local var38 = var30:FindFirstChild("Title")
							if var38 and var38:IsA("TextLabel") then
								var38.Text = v4.name
								local var39 = v4.color
								var39 = var39 or (v4.vfx or var38.TextColor3)
								var38.TextColor3 = var39
							end

							var30.Parent = var26
						end
					end
				elseif not var30 then
					if var27 then
						var30 = var27:Clone()
						local var42 = var30:FindFirstChild("Title")
						if var42 and var42:IsA("TextLabel") then
							var42.Text = v4.name
							local var43 = v4.color
							var43 = var43 or (v4.vfx or var42.TextColor3)
							var42.TextColor3 = var43
						end

						var30.Parent = var26
					end
				end
			elseif not var30 then
				if var27 then
					var30 = var27:Clone()
					local var46 = var30:FindFirstChild("Title")
					if var46 and var46:IsA("TextLabel") then
						var46.Text = v4.name
						local var47 = v4.color
						var47 = var47 or (v4.vfx or var46.TextColor3)
						var46.TextColor3 = var47
					end

					var30.Parent = var26
				end
			end

			if var30 then
				tbl8[var30] = true
				var30.LayoutOrder = k4
				var8.bind(var30, function()
					show(v4.id)
				end)

			else
				local var48 = v4.id
				warn(("[Glyphs] no category button for %s"):format(var48))
			end
		end
	end

	if var24 then
		show(var24)
	end

	local var49 = var9.bind(var10)
	tbl1.open = function()
		var49.open()
	end

	tbl1.close = function()
		var49.close()
	end

	local var51 = var10:FindFirstChild("CloseButton")
	if var51 then
		var8.bind(var51, var49.close)
	end

	local var52 = var1:FindFirstChild("Menu")
	local var53 = var52
	var53 = var53 and var52:FindFirstChild("Runes")
	if var53 then
		var8.bind(var53, var49.toggle)
	else
		warn("[Glyphs] no Main.Menu.Runes button - the collection has no way in")
	end
end

return tbl1

--- ReplicatedStorage.Client.TeleportUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.TeleportConfig)
local var3 = require(var1.Shared.DoorConfig)
local var4 = game:GetService("Players").LocalPlayer
local var5 = require(var1.Client.MenuEffects)
local tbl1 = {}
local var6 = require(game:GetService("ReplicatedStorage").Client.Press)
local var7 = require(var1.Client.UISound)
local function poseFor(arg1, arg2)
	if arg1.spawn then
		local var4 = var2.spawnPad()
		if not var4 then
			return nil, nil
		end

		local var5 = arg2[1]
		local var6 = var5
		var6 = var6 and (var5:GetAttribute("StairHome") or var5.CFrame)
		local var9 = var6
		local var10 = var4.Position + Vector3.new(0, var4.Size.Y / 2 + 3, 0)
		if var9 then
			var9 = Vector3.new(var6.Position.X, var10.Y, var6.Position.Z)
		end

		if not var9 or (var9 - var10).Magnitude < 0.1 then
			var9 = var10 + var4.CFrame.LookVector
		end

		return CFrame.lookAt(var10, var9), 0
	end

	local var13, var14 = var2.landing(arg1.floor, arg2)
	if not var13 then
		return nil, nil
	end

	local var15 = var13:GetAttribute("StairHome")
	var15 = var15 or var13.CFrame
	local var16 = arg1.door
	var16 = var16 and var3.BY_ID[arg1.door]
	local var17 = var16
	local var18 = workspace:FindFirstChild("Doors")
	var17 = var17 and (var18 and var18:FindFirstChild(var16.model))
	local var21 = (var15 * CFrame.new(0, var13.Size.Y / 2 + 3, 0)).Position
	local var22 = nil
	if var17 then
		local var23 = var17:GetBoundingBox()
		var22 = Vector3.new(var23.Position.X, var21.Y, var23.Position.Z)
	else
		local var24 = arg2[var14 + 1]
		local var25 = var24
		var25 = var25 and var24:GetAttribute("StairHome")
		local var27 = var25
		if var27 then
			var27 = Vector3.new(var25.Position.X, var21.Y, var25.Position.Z)
		end

		var22 = var27
	end

	if not var22 or (var22 - var21).Magnitude < 0.1 then
		var22 = var21 + var15.RightVector * -1
	end

	return CFrame.lookAt(var21, var22), var14
end

local var8 = require(var1.Shared.StairConfig)
local function travelTo(arg1)
	local var1 = var4.Character
	local var2 = var1
	local var3 = var1
	var3 = var3 and var1:FindFirstChild("HumanoidRootPart")
	var2 = var2 and var1:FindFirstChildWhichIsA("Humanoid")
	if not var1 or (not var3 or var2 and var2.Health <= 0) then
		return false
	end

	if var2 and var2.Sit then
		var2.Sit = false
		task.wait()
	end

	var1:PivotTo(arg1)
	var3.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	var3.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	return true
end

local var9 = require(var1.Shared.TeleportTodo)
local var10 = require(var1.Packages.DataService).client
local var11 = Color3.fromRGB(80, 80, 80)
local var12 = Color3.fromRGB(105, 105, 105)
local var13 = game:GetService("UserInputService")
tbl1.init = function(_)
	local var1 = var4:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var3 = var1
	var3 = var3 and var1:FindFirstChild("Teleport")
	local var14 = var3
	var14 = var14 and var3:FindFirstChild("Scroller")
	local var15 = var14
	var15 = var15 and var14:FindFirstChildWhichIsA("UIGridLayout")
	if not var3 or (not var14 or (not var15)) then
		warn("[Teleport] no Main.Teleport.Scroller - nothing to drive")
		return
	end

	local var16 = var5.bind(var3)
	tbl1.open = function()
		var16.open()
	end

	tbl1.close = function()
		var16.close()
	end

	local function designedWindow()
		local var1 = var14.AbsoluteWindowSize
		local num1 = 1
		local var2 = var14
		local var3 = var2:FindFirstChildWhichIsA("UIScale")
		while not var2 and var2 == var14.Parent.Parent and var3 and 0 < var3.Scale do
		end

		return var1 / math.max(num1, 0.01)
	end

	local var17 = var15.CellSize
	local var18 = table.clone(var2.LIST)
	table.sort(var18, function(arg1, arg2)
		local var1
		if arg1.spawn then
			var1 = 0
		else
			var1 = arg1.floor
			var1 = var1 or 0
		end

		local var2
		if arg2.spawn then
			var2 = 0
		else
			var2 = arg2.floor
			var2 = var2 or 0
		end

		return var1 < var2
	end)

	local function relayout(arg1)
		local var1 = designedWindow()
		if var1.X < 1 or var1.Y < 1 then
			return
		end

		local var2 = Vector2.new((var1.X - var15.CellPadding.X.Offset * 3 - 1) / 4, var1.Y * var17.Y.Scale)
		var15.CellSize = UDim2.fromOffset(math.floor(var2.X), (math.floor(var2.Y)))
		var14.AutomaticCanvasSize = Enum.AutomaticSize.None
		var14.CanvasSize = UDim2.fromOffset(0, (math.ceil(arg1 * var2.Y + math.max(arg1 - 1, 0) * var15.CellPadding.Y.Offset)))
	end

	local tbl2 = {}
	local var19 = var3:FindFirstChild("DotTemplate")
	for k1, v1 in ipairs(var18) do
		local var21 = var14:FindFirstChild(v1.button)
		if var21 and var21:IsA("GuiButton") then
			var21.LayoutOrder = k1
			local var22 = var21:FindFirstChildWhichIsA("ViewportFrame")
			var22 = var22 or var21:FindFirstChildWhichIsA("ImageLabel")
			local tbl3 = {}
			for k2, v2 in ipairs((var21:FindFirstChild("Title") or var21):GetDescendants()) do
				if not v2:IsA("TextLabel") then
					continue
				end

				if v2.Name:find("Shadow") then
					continue
				end

				tbl3[v2] = v2.TextColor3
			end

			local var23 = var19
			var23 = var23 and var19:Clone()
			if var23 then
				var23.Name = "Dot"
				var23.Visible = false
				local num1 = 0
				for k3, v3 in ipairs(var21:GetChildren()) do
					if not v3:IsA("GuiObject") then
						continue
					end

					num1 = math.max(num1, v3.ZIndex)
				end

				var23.ZIndex = num1 + 10
				var23.Parent = var21
			end

			local var24 = var22
			tbl2[v1.id] = {
				def = v1,
				button = var21,
				picture = var22,
				pictureTint = var24 and var22.ImageColor3,
				titles = tbl3,
				unlocked = false,
				dot = var23,
			}

			var6.bind(var21, function()
				if not tbl2[v1.id].unlocked then
					var7.play("denied")
					return
				end

				local var3 = poseFor(v1, var8.collect())
				if not var3 then
					local var4 = v1.floor
					warn(("[Teleport] no EndStair for floor %d"):format(var4))
					var7.play("denied")
					return
				end

				if travelTo(var3) then
					var16.close()
				end
			end)

		else
			local var25 = v1.button
			local var26 = v1.id
			warn(("[Teleport] no Scroller.%s for destination '%s'"):format(var25, var26))
		end
	end

	local var27 = var8.collect()
	local function refreshDots()
		local success, result = pcall(var9.pending, var10:get(), workspace:GetServerTimeNow(), var27)
		local var1
		local var2
		if not success then
			var2 = result
			var1 = tostring(var2)
			warn("[Teleport] could not work out the dots: " .. var1)
			return
		end

		for k1, v1 in pairs(tbl2) do
			if not v1.dot then
				continue
			end

			local var4 = v1.unlocked
			local var5 = v1.dot
			if var4 then
				var4 = result[k1] ~= nil
			end

			var5.Visible = var4
		end
	end

	local function refresh()
		local var1 = var10:get("stairsOwned") or 1
		for k1, v1 in pairs(tbl2) do
			local var6 = v1.def.spawn == true
			if not var6 then
				local var9, var13 = var2.landing(v1.def.floor, var27)
				local bool1 = false
				if var13 ~= nil then
					bool1 = var13 <= var1
				end

				var6 = bool1
			end

			v1.unlocked = var6
			if v1.picture then
				v1.picture.ImageColor3 = var6 and v1.pictureTint or var11
			end

			for k2, v2 in pairs(v1.titles) do
				k2.TextColor3 = var6 and v2 or var12
			end
		end

		refreshDots()
	end

	refresh()
	var10:getChangedSignal("stairsOwned"):Connect(refresh)
	local bool1 = false
	local str1 = "upgrades"
	local function refreshDotsSoon()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.3, function()
			bool1 = false
			refreshDots()
		end)
	end

	for k4, v4 in ipairs({ "doors", str1, "glyphs", "tree", "trails", "totems", "wheel", "crystals", "rebirths" }) do
		var10:getChangedSignal(v4):Connect(refreshDotsSoon)
	end

	task.spawn(function()
		while true do
			task.wait(5)
			refreshDots()
		end
	end)

	local var28 = math.ceil(#var2.LIST / 4)
	relayout(var28)
	var14:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		relayout(var28)
	end)

	local var30 = var3:FindFirstChild("CloseButton")
	if var30 then
		var6.bind(var30, var16.close)
	end

	local var31 = var1:FindFirstChild("Menu")
	local var32 = var31
	var32 = var32 and var31:FindFirstChild("Teleport")
	if var32 then
		var6.bind(var32, var16.toggle)
		local var34 = var32:FindFirstChild("KeyHint")
		if var34 then
			var34.Visible = var13.KeyboardEnabled
		end
	else
		warn("[Teleport] no Main.Menu.Teleport button - the panel has no way in")
	end

	var13.InputBegan:Connect(function(arg1, arg2)
		if arg2 or arg1.KeyCode ~= Enum.KeyCode.T then
			return
		end

		var16.toggle()
		var7.play("click")
	end)
end

return tbl1

--- ReplicatedStorage.Client.StatsUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local var3 = require(var1.Shared.NumberFormat)
local var4 = require(var1.Shared.GlyphConfig)
local var5 = var2.LocalPlayer
local function amountFor(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("GuiObject") then
			continue
		end

		local var1 = v1:FindFirstChild("Title")
		local var2 = v1:FindFirstChild("Amount")
		if not var1 or (not var2) then
			continue
		end

		if not var1:IsA("TextLabel") then
			continue
		end

		if not var2:IsA("TextLabel") then
			continue
		end

		if var1.Text:lower():gsub("%s+", ""):sub(1, #arg2) ~= arg2 then
			continue
		end

		return var2
	end

	return nil
end

local var6 = require(var1.Shared.StairConfig)
local var7 = require(var1.Packages.DataService).client
local var8 = require(var1.Shared.TreeConfig)
local var9 = require(var1.Shared.PassConfig)
local var10 = require(var1.Client.PassState)
local var11 = require(var1.Shared.TotemConfig)
local var12 = require(var1.Shared.TrailConfig)
local var13 = require(var1.Shared.RebirthConfig)
local var14 = require(var1.Shared.PotionConfig)
local var15 = require(var1.Shared.UpgradeConfig)
local var16 = require(var1.Shared.SmelterConfig)
local var17 = require(var1.Client.MenuEffects)
local tbl1 = {}
local var18 = require(game:GetService("ReplicatedStorage").Client.Press)
tbl1.init = function(_)
	local var1 = var5:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var19 = var1
	var19 = var19 and var1:FindFirstChild("Stats")
	if not var19 then
		warn("[Stats] no Main.Stats - no panel to drive")
		return
	end

	local var20 = var19:FindFirstChild("List")
	local var21 = var20
	var21 = var21 and amountFor(var20, "goldmulti")
	local tbl2 = { goldMulti = var21 }
	var21 = var20
	var21 = var21 and amountFor(var20, "gold/s")
	tbl2.goldRate = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "speed")
	tbl2.speed = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "luck")
	tbl2.luck = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "silvermul")
	tbl2.silverMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "ironmul")
	tbl2.ironMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "ingotmul")
	tbl2.ingotMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "glyphbulk")
	tbl2.glyphBulk = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "crystalmul")
	tbl2.crystalMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "woodmul")
	tbl2.woodMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "essencemul")
	tbl2.essenceMulti = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "totems")
	tbl2.totems = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "glyphsopened")
	tbl2.glyphsOpened = var21
	var21 = var20
	var21 = var21 and amountFor(var20, "playtime")
	tbl2.playtime = var21
	tbl2.floor = amountFor(var19, "floor")
	tbl2.rebirths = amountFor(var19, "rebirth")
	tbl2.gold = amountFor(var19, "gold:")
	tbl2.silver = amountFor(var19, "silver")
	var21 = var19:FindFirstChild("PFP")
	if var21 and var21:IsA("ImageLabel") then
		task.spawn(function()
			local success, result = pcall(function()
				local var1 = var5.UserId
				local var3 = Enum.ThumbnailType.HeadShot
				local var4 = Enum.ThumbnailSize.Size420x420
				return var2:GetUserThumbnailAsync(var1, var3, var4)
			end)

			if success and result then
				var21.Image = result
				return
			end

			warn("[Stats] could not load the avatar thumbnail")
		end)

	end

	local var22 = nil
	local var23 = nil
	for k1, v1 in ipairs(var19:GetChildren()) do
		if not v1:IsA("TextLabel") then
			continue
		end

		if v1.Name ~= "Title" then
			continue
		end

		if v1.Text:lower():find("your stats") then
			var22 = v1
		else
			if not var23 or var23.Position.Y.Scale < v1.Position.Y.Scale then
				var23 = v1
			end
		end
	end

	if not var23 and var22 then
		for k2, v2 in ipairs(var19:GetChildren()) do
			if not v2:IsA("TextLabel") then
				continue
			end

			if v2.Name ~= "Title" or v2 == var22 then
				continue
			end

			var23 = v2
		end
	end

	if var23 then
		var23.Text = var5.DisplayName
	end

	local var24 = var6.collect()
	local function refresh()
		local var1 = var7:get("upgrades")
		local str1 = "glyphs"
		local str2 = "tree"
		local var2 = var4.multipliers(var7:get(str1))
		local var17 = var8.totals(var7:get(str2))
		str1 = var7:get("totems")
		local var18 = str1
		local var19 = var17.totemBoost
		var1 = var1 or {}
		local var20 = var9.totals(var10.owned)
		for k1, v1 in pairs(var11.totals(var18, var19)) do
			local var21 = (var20[k1] or 1) * v1
			var20[k1] = var21
		end

		if tbl2.floor then
			var18 = tonumber((var6.floorFor(var7:get("stairsOwned") or 1, var24))) or 0
			str2 = tbl2.floor
			local var22 = if math.abs(var18) < 1000 then var3.format((math.floor(var18))) else var3.suffix(var18)
			str2.Text = var22
		end

		if tbl2.gold then
			var18 = tonumber(var7:get("gold") or 0) or 0
			str2 = tbl2.gold
			local var23 = if math.abs(var18) < 1000 then var3.format((math.floor(var18))) else var3.suffix(var18)
			str2.Text = var23
		end

		if tbl2.silver then
			var18 = tonumber(var7:get("silver") or 0) or 0
			str2 = tbl2.silver
			local var25 = if math.abs(var18) < 1000 then var3.format((math.floor(var18))) else var3.suffix(var18)
			str2.Text = var25
		end

		local str3 = "equippedTrail"
		str2 = var12.totals(var7:get("trails"), var7:get(str3))
		local str4 = "rebirths"
		var18 = var2.gold * var17.gold * var20.gold * str2.gold * (if var5:GetAttribute("FriendBoost") == true then 1.1 else 1) * var13.goldMultiplier(var7:get(str4)) * var14.multiplier(var7:get("potions"), "gold", workspace:GetServerTimeNow())
		if tbl2.rebirths then
			local var26 = tonumber(var7:get("rebirths") or 0) or 0
			local var27 = tbl2.rebirths
			str3 = if math.abs(var26) < 1000 then var3.format((math.floor(var26))) else var3.suffix(var26)
			var27.Text = str3
		end

		if tbl2.goldMulti then
			local var29 = tonumber((var15.goldMultiplier(var1, var18))) or 0
			local var30 = tbl2.goldMulti
			str3 = if 1000 <= var29 then var3.suffix(var29) .. "x" else var4.multiplierText(var29)
			var30.Text = str3
		end

		if tbl2.goldRate then
			local var33 = var15.goldPerSecond(var1, var18)
			local var34 = tbl2.goldRate
			if var33 < 10 then
				str3 = ("%.1f"):format(var33):gsub("%.0$", "")
			else
				str3 = if var33 < 1000 then var3.format((math.floor(var33))) else var3.suffix(var33)
			end

			var34.Text = str3
		end

		if tbl2.speed then
			local var35 = tonumber(var15.walkSpeed(var1) + var17.speed) or 0
			local var36 = tbl2.speed
			str3 = if math.abs(var35) < 1000 then var3.format((math.floor(var35))) else var3.suffix(var35)
			var36.Text = str3
		end

		if tbl2.luck then
			local var38 = tonumber(var2.luck * var17.luck * var20.luck * str2.luck * var15.BY_ID.glyphLuck.value(var1.glyphLuck or 0)) or 0
			local var39 = tbl2.luck
			str3 = if 1000 <= var38 then var3.suffix(var38) .. "x" else var4.multiplierText(var38)
			var39.Text = str3
		end

		if tbl2.silverMulti then
			local var41 = tonumber(var2.silver * var17.silver * var20.silver * var15.BY_ID.silverMultiplier.value(var1.silverMultiplier or 0) * str2.silver * (var15.BY_ID.woodPower and var15.BY_ID.woodPower.value(var1.woodPower or 0) or 1) * var14.multiplier(var7:get("potions"), "silver", workspace:GetServerTimeNow()) * var13.multiplier(var7:get("rebirths"), "silver")) or 0
			local var42 = tbl2.silverMulti
			local var43 = if 1000 <= var41 then var3.suffix(var41) .. "x" else var4.multiplierText(var41)
			var42.Text = var43
		end

		if tbl2.ironMulti then
			local var45 = tonumber(var2.iron * str2.iron * var14.multiplier(var7:get("potions"), "iron", workspace:GetServerTimeNow()) * var13.multiplier(var7:get("rebirths"), "iron")) or 0
			local var46 = tbl2.ironMulti
			str3 = if 1000 <= var45 then var3.suffix(var45) .. "x" else var4.multiplierText(var45)
			var46.Text = str3
		end

		if tbl2.ingotMulti then
			local var48 = tonumber((var16.ingotsPerOre(var17, var20.iron))) or 0
			local var49 = tbl2.ingotMulti
			str3 = if 1000 <= var48 then var3.suffix(var48) .. "x" else var4.multiplierText(var48)
			var49.Text = str3
		end

		if tbl2.crystalMulti then
			local var51 = tonumber((var17.crystals or 1) * (var20.crystals or 1) * (var2.crystals or 1) * var14.multiplier(var7:get("potions"), "crystals", workspace:GetServerTimeNow()) * (str2.crystals or 1)) or 0
			local var52 = tbl2.crystalMulti
			str3 = if 1000 <= var51 then var3.suffix(var51) .. "x" else var4.multiplierText(var51)
			var52.Text = str3
		end

		if tbl2.glyphBulk then
			local var54 = tonumber(math.max(math.floor(var15.BY_ID.glyphBulk.value(var1.glyphBulk or 0) + math.max(var20.bulk or 1, 1) - 1), 1) * math.max(var17.glyphBulk or 1, 1)) or 0
			str3 = tbl2.glyphBulk
			local var55 = if 1000 <= var54 then var3.suffix(var54) .. "x" else var4.multiplierText(var54)
			str3.Text = var55
		end

		if tbl2.woodMulti then
			local var57 = tonumber((var17.wood or 1) * (var2.wood or 1) * (var20.wood or 1) * (str2.wood or 1)) or 0
			local var58 = tbl2.woodMulti
			str3 = if 1000 <= var57 then var3.suffix(var57) .. "x" else var4.multiplierText(var57)
			var58.Text = str3
		end

		if tbl2.essenceMulti then
			local var60 = tonumber((var17.essence or 1) * (var2.essence or 1) * (var20.essence or 1) * (str2.essence or 1)) or 0
			local var61 = tbl2.essenceMulti
			str3 = if 1000 <= var60 then var3.suffix(var60) .. "x" else var4.multiplierText(var60)
			var61.Text = str3
		end

		if tbl2.totems then
			local num1 = 0
			for i1 = 1, var11.SLOTS do
				if not str1 then
					continue
				end

				if not str1.bases then
					continue
				end

				local var62 = var11.key(i1)
				if not str1.bases[var62] then
					continue
				end

				if not str1.slots then
					continue
				end

				if not str1.slots[var62] then
					continue
				end

				num1 = num1 + 1
			end

			tbl2.totems.Text = ("%d/%d Active"):format(num1, var11.SLOTS)
		end

		if tbl2.glyphsOpened then
			local var63 = var7:get("glyphsPulled")
			var63 = tonumber(var63 or (var7:get("glyphsOpened") or 0)) or 0
			local var64 = tbl2.glyphsOpened
			str3 = if math.abs(var63) < 1000 then var3.format((math.floor(var63))) else var3.suffix(var63)
			var64.Text = str3
		end

		if tbl2.playtime then
			local var66 = math.floor((tonumber(var7:get("playtime") or 0) or 0) / 60)
			local var67 = tbl2.playtime
			if var66 < 60 then
				str3 = var66 .. "m"
			else
				local var69 = var66 // 60
				str3 = if var69 < 24 then ("%dh%dm"):format(var69, var66 % 60) else ("%dd%dh"):format(var69 // 24, var69 % 24)
			end

			var67.Text = str3
		end
	end

	refresh()
	local bool1 = false
	local str1 = "silver"
	local function refreshSoon()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.2, function()
			bool1 = false
			refresh()
		end)
	end

	for k3, v3 in ipairs({
		"gold",
		str1,
		"stairsOwned",
		"upgrades",
		"glyphs",
		"tree",
		"glyphsOpened",
		"glyphsPulled",
		"totems",
		"trails",
		"equippedTrail",
		"rebirths",
		"potions",
		"playtime",
	}) do

		var7:getChangedSignal(v3):Connect(refreshSoon)
	end

	task.spawn(function()
		while true do
			task.wait(1)
			refresh()
		end
	end)

	var5:GetAttributeChangedSignal("FriendBoost"):Connect(refresh)
	local var25 = var17.bind(var19)
	tbl1.open = function()
		var25.open()
	end

	tbl1.close = function()
		var25.close()
	end

	local var27 = var19:FindFirstChild("CloseButton")
	if var27 then
		var18.bind(var27, var25.close)
	end

	local var28 = var1:FindFirstChild("Menu")
	local var29 = var28
	var29 = var29 and var28:FindFirstChild("Stats")
	if var29 then
		var18.bind(var29, var25.toggle)
	else
		warn("[Stats] no Main.Menu.Stats button - the panel has no way in")
	end
end

return tbl1

--- ReplicatedStorage.Client.MineTimer [ModuleScript]
-- y u r i

game:GetService("RunService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.MineConfig)
local var3 = require(var1.Packages.DataService).client
local var4 = require(var1.Shared.Remotes)
local var5 = require(var1.Client.WorldTap)
local var6 = require(var1.Client.UISound)
local var7 = game:GetService("MarketplaceService")
local var8 = game:GetService("Players").LocalPlayer
return { init = function(_)
	local var1 = workspace:WaitForChild("Mine", 20)
	local var9 = var1
	var9 = var9 and var1:FindFirstChild("Timer")
	local var10 = var9
	var10 = var10 and var9:FindFirstChildWhichIsA("SurfaceGui", true)
	local var11 = nil
	for k1, v1 in ipairs(var10 and var10:GetDescendants() or {}) do
		if not v1:IsA("TextLabel") then
			continue
		end

		var11 = v1
		break
	end

	if not var11 then
		warn("[Mine] no Workspace.Mine.Timer SurfaceGui label - no countdown to draw")
		return
	end

	local var12 = nil
	var4.MineCycle.OnClientEvent:Connect(function(arg1)
		if type(arg1) ~= "number" then
			return
		end

		var12 = os.clock() + arg1
		local bool1 = true
		if var2.DOOR ~= nil then
			bool1 = var3:get({ "doors", var2.DOOR }) == true
		end

		if not bool1 then
			var11.Text = "Locked"
			return
		end

		local var1 = math.max(math.ceil(var12 and var12 - os.clock() or var2.RESPAWN_SECONDS), 0)
		var11.Text = "Resets In: " .. ("%d:%02d"):format(math.floor(var1 / 60), var1 % 60)
	end)

	var4.MineReset.OnClientEvent:Connect(function()
		var12 = nil
		local bool1 = true
		if var2.DOOR ~= nil then
			bool1 = var3:get({ "doors", var2.DOOR }) == true
		end

		if not bool1 then
			var11.Text = "Locked"
			return
		end

		local var1 = math.max(math.ceil(var12 and var12 - os.clock() or var2.RESPAWN_SECONDS), 0)
		var11.Text = "Resets In: " .. ("%d:%02d"):format(math.floor(var1 / 60), var1 % 60)
	end)

	var3:getChangedSignal("doors"):Connect(function()
		local bool1 = true
		if var2.DOOR ~= nil then
			bool1 = var3:get({ "doors", var2.DOOR }) == true
		end

		if not bool1 then
			var11.Text = "Locked"
			return
		end

		local var1 = math.max(math.ceil(var12 and var12 - os.clock() or var2.RESPAWN_SECONDS), 0)
		var11.Text = "Resets In: " .. ("%d:%02d"):format(math.floor(var1 / 60), var1 % 60)
	end)

	local var13 = var1:FindFirstChild("Skip")
	local var14 = var13
	var14 = var14 and var13:FindFirstChildWhichIsA("TextButton", true)
	if var14 then
		var5.bind(var14, function()
			local bool1 = true
			if var2.DOOR ~= nil then
				bool1 = var3:get({ "doors", var2.DOOR }) == true
			end

			if not bool1 or (not var12) then
				var6.play("denied")
				return
			end

			var7:PromptProductPurchase(var8, var2.SKIP_PRODUCT)
		end)

	else
		warn("[Mine] no Workspace.Mine.Skip button - the refill cannot be skipped")
	end

	local bool1 = true
	if var2.DOOR ~= nil then
		bool1 = var3:get({ "doors", var2.DOOR }) == true
	end

	if not bool1 then
		var11.Text = "Locked"
	elseif var12 then
		bool1 = var12 - os.clock()
		bool1 = bool1 or var2.RESPAWN_SECONDS
	end

	task.spawn(function()
		while true do
			task.wait(0.25)
			local bool1 = true
			if var2.DOOR ~= nil then
				bool1 = var3:get({ "doors", var2.DOOR }) == true
			end

			if not bool1 then
				var11.Text = "Locked"
			else
				local var1 = math.max(math.ceil(var12 and var12 - os.clock() or var2.RESPAWN_SECONDS), 0)
				var11.Text = "Resets In: " .. ("%d:%02d"):format(math.floor(var1 / 60), var1 % 60)
			end
		end
	end)
end }

--- ReplicatedStorage.Client.GlyphColors [ModuleScript]
-- y u r i

local var1 = nil
local var2 = require(game:GetService("ReplicatedStorage").Shared.GlyphConfig)
local function listFor(arg1)
	local var1 = workspace:FindFirstChild("Runes")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild(arg1.model)
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("UI")
	local var4 = var3
	var4 = var4 and var3:FindFirstChildWhichIsA("BillboardGui")
	local var5 = var4
	var5 = var5 and var4:FindFirstChild("GlyphInfo")
	return var5 and var5:FindFirstChild("List") or nil
end

return { get = function()
	if var1 then
		return var1
	end

	var1 = {}
	for k1, v1 in ipairs(var2.SETS) do
		local var3 = listFor(v1)
		for k2, v2 in ipairs(v1.list) do
			local var5 = var2.COLORS[v2.id]
			if var5 then
				var1[v2.id] = var5
			else
				local var6 = var3
				var6 = var6 and var3:FindFirstChild(v2.name)
				if not var6 then
					continue
				end

				if not var6:IsA("TextLabel") then
					continue
				end

				var1[v2.id] = var6.TextColor3
			end
		end
	end

	return var1
end }

--- ReplicatedStorage.Client.GlyphDrops [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = require(var1.Client.GlyphColors)
local var4 = require(var1.Shared.GlyphConfig)
local var5 = game:GetService("TweenService")
local var6 = require(var1.Shared.NumberFormat)
local var7 = require(var1.Packages.DataService).client
return { init = function(_)
	local var1 = var2:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var8 = var1
	var8 = var8 and var1:FindFirstChild("Drops")
	local var9 = var8
	var9 = var9 and var8:FindFirstChild("Entry")
	if not var8 or (not var9 or (not var9:IsA("TextLabel"))) then
		warn("[Glyphs] no Main.Drops.Entry - no drop lines to show")
		return
	end

	var9.Parent = nil
	var8.Visible = true
	local var10 = var3.get()
	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in ipairs(var4.ALL) do
		tbl2[v1.id] = k1
	end

	local function slideOut(arg1)
		if arg1.leaving then
			return
		end

		arg1.leaving = true
		tbl1[arg1.id] = nil
		local var1 = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var5:Create(arg1.scale, var1, { Scale = 1.08 }):Play()
		var5:Create(arg1.label, var1, { TextTransparency = 1 }):Play()
		if arg1.stroke then
			var5:Create(arg1.stroke, var1, { Transparency = 1 }):Play()
		end

		task.delay(0.22, function()
			arg1.container:Destroy()
		end)
	end

	local function bump(arg1, arg2)
		arg1.count = arg2
		arg1.until_ = os.clock() + 4
		local var1 = arg1.count
		arg1.label.Text = ("%s Glyph x%s"):format(arg1.def.name, var6.format(var1))
		if arg1.arriving then
			arg1.arriving = false
			var5:Create(arg1.scale, TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
		else
			arg1.scale.Scale = 1.09
			var5:Create(arg1.scale, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
		end

		arg1.label.TextColor3 = Color3.new(1, 1, 1)
		local var2 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var5:Create(arg1.label, var2, { TextColor3 = arg1.color }):Play()
	end

	local function makeRoom(arg1)
		local var1 = nil
		for k1, v1 in pairs(tbl1) do
			if not var1 or v1.def.odds < var1.def.odds then
				var1 = v1
			end
		end

		if var1 and var1.def.odds < arg1.odds then
			slideOut(var1)
			return true
		end

		return false
	end

	local function create(arg1, _)
		local var1 = Instance.new("Frame")
		var1.Name = arg1.name
		var1.BackgroundTransparency = 1
		var1.Size = var9.Size
		var1.ClipsDescendants = false
		var1.LayoutOrder = -(tbl2[arg1.id] or 0)
		var1.Parent = var8
		local var2 = var9:Clone()
		var2.Size = UDim2.fromScale(1, 1)
		var2.AnchorPoint = Vector2.new(0.5, 0.5)
		var2.Position = UDim2.fromScale(0.5, 0.5)
		local var3 = var10[arg1.id]
		var3 = var3 or var2.TextColor3
		var2.TextColor3 = var3
		var2.Parent = var1
		var3 = var2:FindFirstChildWhichIsA("UIScale")
		if not var3 then
			var3 = Instance.new("UIScale")
			var3.Parent = var2
		end

		var3.Scale = 0.6
		local var4 = var2.TextTransparency
		var2.TextTransparency = 1
		local var11 = var2:FindFirstChildWhichIsA("UIStroke")
		local var12 = nil
		if var11 then
			var12 = var11.Transparency
			var11.Transparency = 1
		end

		local var13 = TweenInfo.new(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var5:Create(var2, var13, { TextTransparency = var4 }):Play()
		if var11 then
			var5:Create(var11, var13, { Transparency = var12 }):Play()
		end

		return {
			id = arg1.id,
			def = arg1,
			container = var1,
			label = var2,
			stroke = var11,
			scale = var3,
			color = var2.TextColor3,
			count = 0,
			arriving = true,
			bornAt = os.clock(),
		}
	end

	local var11 = var7:get("glyphs")
	local var12 = var11
	local function applyBatch(arg1)
		table.sort(arg1, function(arg1, arg2)
			return arg2.def.odds < arg1.def.odds
		end)

		for k1, v1 in ipairs(arg1) do
			local var1 = tbl1[v1.def.id]
			if not var1 then
				continue
			end

			bump(var1, var1.count + v1.amount)
			v1.done = true
		end

		for k2, v2 in ipairs(arg1) do
			if v2.done then
				continue
			end

			local num1 = 0
			for k3 in pairs(tbl1) do
				num1 = num1 + 1
			end

			if num1 < 5 or makeRoom(v2.def) then
				num1 = create(v2.def, v2.amount)
				tbl1[v2.def.id] = num1
				bump(num1, v2.amount)
			end
		end
	end

	local tbl3 = {}
	for k2, v2 in pairs(var12 or {}) do
		tbl3[k2] = v2
	end

	local bool1 = false
	var7:getChangedSignal("glyphs"):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.3, function()
			bool1 = false
			local var1 = var7:get("glyphs")
			var1 = var1 or {}
			local tbl1 = {}
			for k1, v1 in ipairs(var4.ALL) do
				local var5 = tbl3[v1.id] or 0
				local var6 = var1[v1.id] or 0
				if var5 < var6 then
					table.insert(tbl1, { def = v1, amount = var6 - var5 })
				end

				tbl3[v1.id] = var6
			end

			if 0 < (#tbl1) then
				applyBatch(tbl1)
			end
		end)
	end)

	task.spawn(function()
		while true do
			task.wait(0.25)
			local var1 = os.clock()
			for k1, v1 in pairs(tbl1) do
				if not v1.until_ then
					continue
				end

				if v1.until_ > var1 then
					continue
				end

				slideOut(v1)
			end
		end
	end)
end }

--- ReplicatedStorage.Client.SettingFlag [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Packages.DataService).client
return { on = function(arg1)
	local var2 = var1:get("settings")
	local var4 = var2
	if var4 then
		var4 = var2[arg1] == false
	end

	return not var4
end }

--- ReplicatedStorage.Client.TreeClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Shared.NumberFormat)
local num1 = 58
local num2 = 54
local num3 = 78
local var2 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 128
num3 = 122
local num4 = 158
local num5 = 1
local var3 = ColorSequence.new({ var2, ColorSequenceKeypoint.new(num5, Color3.fromRGB(num2, num3, num4)) })
num2 = 124
num3 = 23
num4 = 23
local var4 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num2, num3, num4))
num3 = 229
num4 = 123
local num6 = 123
num1 = 1
local var5 = ColorSequence.new({ var4, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num6)) })
local var6 = game:GetService("RunService")
var4 = {}
local var7 = require(var1.Shared.Remotes)
var6.Heartbeat:Connect(function()
	if #var4 == 0 then
		return
	end

	local var1 = var4
	var4 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			var7.BuyTreeNode:FireServer(v1)
		end)

	end
end)

local var8 = require(var1.Shared.StairConfig)
local var9 = require(var1.Packages.DataService).client
local var10 = require(var1.Shared.TreeConfig)
local var11 = require(var1.Client.UISound)
local var12 = Color3.new(1, 1, 1)
local var13 = Color3.fromRGB(236, 230, 255)
num5 = function(arg1)
	local var1 = arg1:GetPivot()
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local tbl2 = { part = v1, size = v1.Size, offset = var1:ToObjectSpace(v1.CFrame) }
		tbl2.transparency = v1.Transparency
		tbl2.collide = v1.CanCollide
		table.insert(tbl1, tbl2)
	end

	return { pivot = var1, parts = tbl1 }
end

local var14 = require(game:GetService("ReplicatedStorage").Client.Press)
local var15 = game:GetService("Players").LocalPlayer
local var16 = game:GetService("UserInputService")
num1 = function(arg1, arg2, arg3)
	for k1, v1 in ipairs(arg1.parts) do
		v1.part.Size = v1.size * arg2
		local var1 = v1.offset
		v1.part.CFrame = arg1.pivot * CFrame.new(var1.Position * arg2) * (var1 - var1.Position)
		v1.part.Transparency = arg3 and v1.transparency or 1
		local var2 = arg3
		v1.part.CanCollide = var2 and v1.collide
		v1.part.CastShadow = false
	end
end

local var17 = game:GetService("TweenService")
local var18 = Color3.fromRGB(120, 235, 140)
return { init = function(_)
	local var58
	local var1 = var8.collect()
	local function currentFloor()
		local var2 = var9:get("stairsOwned") or 1
		local var3 = var1
		return var8.floorFor(var2, var3)
	end

	local var2 = nil
	for k1, v1 in ipairs(workspace:GetDescendants()) do
		if v1.Name ~= "UpgradeTree" then
			continue
		end

		var2 = v1
		break
	end

	if not var2 then
		warn("[Tree] no Workspace.UpgradeTree - nothing to draw")
		return
	end

	local tbl1 = {}
	local var7 = Instance.new("SelectionBox")
	var7.Name = "TreeHover"
	var7.Color3 = var12
	var7.LineThickness = 0.12
	var7.SurfaceTransparency = 1
	var7.Transparency = 0
	var7.Visible = false
	var7.Parent = workspace
	local var19 = nil
	local var20 = nil
	local function hexOutlineFor(arg1)
		if var19 then
			return var19
		end

		local var1 = Instance.new("Model")
		var1.Name = "TreeHoverHex"
		local var2 = arg1.Size.Z / 2 + 0.08
		local var3 = var2 + 0.16
		local tbl1 = {}
		for i1 = 0, 5 do
			local var4 = math.rad(i1 * 60 + 30)
			local var5 = Vector3.new(math.cos(var4), 0, (math.sin(var4)))
			local var6 = Instance.new("Part")
			var6.Name = "Bar"
			var6.Anchored = true
			var6.CanCollide = false
			var6.CanQuery = false
			var6.CanTouch = false
			var6.CastShadow = false
			var6.Material = Enum.Material.Neon
			var6.Color = var13
			var6.Transparency = 1
			local var7 = 2 * var3 / 1.7320508075688772
			var6.Size = Vector3.new(var7, 0.18, var3 - var2)
			local var8 = var5 * ((var2 + var3) / 2) + Vector3.new(0, -0.01, 0)
			var6.CFrame = CFrame.lookAt(var8, var8 + var5)
			var6.Parent = var1
			table.insert(tbl1, var6)
		end

		var1.WorldPivot = CFrame.new()
		var1.Parent = workspace
		var19 = {
			model = var1,
			show = function(arg1)
				for k1, v1 in ipairs(tbl1) do
					v1.Transparency = if arg1 then 0.25 else 1
				end
			end,
		}

		return var19
	end

	local function tryBuy(arg1)
		local var3 = os.clock()
		if tbl1[arg1.id] and var3 - tbl1[arg1.id] < 0.4 then
			return
		end

		tbl1[arg1.id] = var3
		local var5 = var9:get("tree")
		var5 = var5 or {}
		if var5[arg1.id] then
			return
		end

		if not var10.available(arg1, var5, var8.floorFor(var9:get("stairsOwned") or 1, var1), var9:get("rebirths") or 0) then
			return
		end

		if (var9:get(arg1.currency) or 0) < arg1.cost or arg1.extra and (var9:get(arg1.extra.currency) or 0) < arg1.extra.amount then
			var11.play("denied")
			return
		end

		var11.play("purchase")
		table.insert(var4, arg1.id)
	end

	local function hover(arg1)
		var20 = arg1
		if arg1.hexBody then
			local var3 = arg1.hexBody
			local var4 = hexOutlineFor(var3)
			var4.model:PivotTo(var3.CFrame * CFrame.new(0, var3.Size.Y / 2, 0))
			var4.show(true)
			var7.Visible = false
			var7.Adornee = nil
			return
		end

		var7.Adornee = arg1.model
		var7.Visible = true
	end

	local tbl2 = {}
	for k2, v2 in ipairs(var10.NODES) do
		local var21 = var2:FindFirstChild(v2.id)
		local var22 = var21
		var22 = var22 and var21:FindFirstChildWhichIsA("SurfaceGui", true)
		local var23 = var22
		var23 = var23 and var22:FindFirstChildWhichIsA("GuiObject")
		local var26
		if var21 then
			if var23 then
				local var29 = var23:FindFirstChild("Buy")
				local var30 = var29
				var30 = var30 and var29:FindFirstChild("BG")
				local var31 = var30
				local var34 = var23:FindFirstChild("Title")
				var31 = var31 and var30:FindFirstChildWhichIsA("UIGradient")
				local var35 = var10.EFFECTS[v2.effect]
				if var34 then
					var34.Text = var35.title
					if var35.color then
						var34.TextColor3 = var35.color
					end
				end

				local var37 = var23:FindFirstChild("Desc")
				if var37 then
					var37.Text = var35.describe(v2.value)
				end

				local var39 = var23:FindFirstChild("Cost")
				if var39 then
					var39.Text = var10.costText(v2)
					local var41 = var10.CURRENCY_COLORS[v2.currency]
					if var41 then
						var39.TextColor3 = var41
					end
				end

				local tbl3 = { node = v2, model = var21, gui = var22, skeleton = num5(var21), shown = nil }
				tbl3.buy = var29
				tbl3.gradient = var31
				var26 = var31
				tbl3.green = var26 and var31.Color
				tbl3.title = var34
				var26 = var34
				tbl3.titleColor = var26 and var34.TextColor3
				tbl3.amount = var23:FindFirstChild("Amount")
				var26 = v2.id:match("^P3") and var21:FindFirstChild("Body") or nil
				tbl3.hexBody = var26
				var26 = var29
				var26 = var26 and var29:FindFirstChild("Cost")
				tbl3.buyLabel = var26
				var26 = var29
				var26 = var26 and (var29:FindFirstChild("Cost") and var29.Cost.Text)
				tbl3.buyText = var26
				tbl2[v2.id] = tbl3
				if var29 then
					var14.bind(var29, function()
						tryBuy(v2)
					end)

				end

				local var42 = Instance.new("ClickDetector")
				var42.Name = "TreeClick"
				var42.MaxActivationDistance = 0
				var42.Parent = var21
				tbl2[v2.id].detector = var42
				var42.MouseClick:Connect(function()
					tryBuy(v2)
				end)

			else
				local var43 = v2.id
				warn(("[Tree] %s has no panel"):format(var43))
			end
		else
			local var44 = v2.id
			warn(("[Tree] %s has no panel"):format(var44))
		end
	end

	local function pick(arg1)
		local tbl1 = {}
		if var15.Character then
			table.insert(tbl1, var15.Character)
		end

		local var1 = RaycastParams.new()
		var1.FilterType = Enum.RaycastFilterType.Exclude
		for i1 = 1, 8 do
			var1.FilterDescendantsInstances = tbl1
			local var4 = workspace:Raycast(arg1.Origin, arg1.Direction.Unit * 500, var1)
			if not var4 then
				return nil
			end

			local var5 = var4.Instance
			while var5 and var5.Parent ~= var2 do
				var5 = var5.Parent
			end

			local var6 = var5
			var6 = var6 and tbl2[var5.Name]
			if var6 then
				return var6, var4.Position
			end

			if var4.Instance.Transparency < 0.99 then
				return nil
			end

			table.insert(tbl1, var4.Instance)
		end

		return nil
	end

	var16.TouchTapInWorld:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		local var2 = workspace.CurrentCamera
		if not var2 then
			return
		end

		local var3 = arg1.X
		local var4 = arg1.Y
		local var7, var8 = pick(var2:ScreenPointToRay(var3, var4))
		if var7 then
			if var7.shown == "open" then
				var3 = var15.Character
				var3 = var3 and var15.Character:FindFirstChild("HumanoidRootPart")
				local var10 = not var3
				if not var10 then
					var10 = (var3.Position - var8).Magnitude <= 60
				end

				if var10 then
					tryBuy(var7.node)
				end
			end
		end
	end)

	var16.InputBegan:Connect(function(arg1, arg2)
		if arg2 or arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			return
		end

		local var2 = workspace.CurrentCamera
		if not var2 then
			return
		end

		local var3 = arg1.Position.X
		local var4 = arg1.Position.Y
		local var7, var8 = pick(var2:ScreenPointToRay(var3, var4))
		if var7 then
			if var7.shown == "open" then
				var3 = var15.Character
				var3 = var3 and var15.Character:FindFirstChild("HumanoidRootPart")
				local var10 = not var3
				if not var10 then
					var10 = (var3.Position - var8).Magnitude <= 60
				end

				if var10 then
					tryBuy(var7.node)
				end
			end
		end
	end)

	local num2 = 0
	local tbl4 = {
		[Enum.UserInputType.MouseMovement] = true,
		[Enum.UserInputType.MouseButton1] = true,
		[Enum.UserInputType.MouseButton2] = true,
		[Enum.UserInputType.MouseWheel] = true,
		[Enum.UserInputType.Keyboard] = true,
	}

	var6.Heartbeat:Connect(function(arg1)
		local var1 = num2 + arg1
		num2 = var1
		if num2 < 0.05 then
			return
		end

		num2 = 0
		local var9 = workspace.CurrentCamera
		var1 = nil
		if var9 then
			if var16.MouseEnabled then
				if tbl4[var16:GetLastInputType()] then
					local var24 = var16:GetMouseLocation()
					local var25 = var24.X
					local var26 = var24.Y
					local var29, var30 = pick(var9:ViewportPointToRay(var25, var26))
					if var29 then
						if var29.shown == "open" then
							var25 = var15.Character
							var25 = var25 and var15.Character:FindFirstChild("HumanoidRootPart")
							local var32 = not var25
							if not var32 then
								var32 = (var25.Position - var30).Magnitude <= 60
							end

							if var32 then
								var1 = var29
							end
						end
					end
				end
			end
		end

		if var1 ~= var20 then
			if var20 and var20 == var20 then
				var20 = nil
				var7.Visible = false
				var7.Adornee = nil
				if var19 then
					var19.show(false)
				end
			end

			if var1 then
				hover(var1)
			end
		end
	end)

	local function stateOf(arg1, arg2, arg3)
		if arg2[arg1.id] == true then
			return "owned"
		end

		if var10.available(arg1, arg2, arg3, var9:get("rebirths") or 0) then
			return "open"
		end

		if arg1.door then
			if arg1.door == var10.P3_DOOR then
				if arg1.floor then
					if arg3 >= arg1.floor then
						local bool1 = false
						if arg1.rebirths ~= nil then
							bool1 = (var9:get("rebirths") or 0) < arg1.rebirths
						end

						if bool1 then
							if not arg1.requires or arg2[arg1.requires] == true then
								return "preview"
							end
						end
					end
				end
			end
		end

		return "locked"
	end

	local var45 = workspace:FindFirstChild("Map")
	local var46 = var45
	var46 = var46 and var45:FindFirstChild("Tree3Room")
	local var47 = var46
	var47 = var47 and var46:FindFirstChild("Sockets")
	local function draw(arg1, arg2, arg3)
		local var2 = tbl2[arg1]
		if not var2 then
			return
		end

		local var4 = var9:get("tree")
		var4 = var4 or {}
		local var6 = stateOf(var2.node, var4, currentFloor())
		local var8 = var9:get(var2.node.currency) or 0
		local var10 = var4[var2.node.id] == true
		local var11 = var2.shown ~= var6
		if var6 == "locked" then
			if var11 then
				num1(var2.skeleton, 0.01, false)
				if var2.gui then
					var2.gui.Enabled = false
				end
			end
		else
			if var2.shown == "locked" and arg2 then
				var2.growing = true
				num1(var2.skeleton, 0.01, true)
				local var12 = arg3 or 0
				if var2.gui then
					var2.gui.Enabled = false
				end

				task.delay(var12, function()
					local var1 = Instance.new("NumberValue")
					var1.Value = 0.01
					local var3 = var17:Create(var1, TweenInfo.new(0.55, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Value = 1 })
					local var4 = var1.Changed:Connect(function(arg1)
						num1(var2.skeleton, arg1, true)
					end)

					var3.Completed:Connect(function()
						var4:Disconnect()
						var1:Destroy()
						num1(var2.skeleton, 1, true)
						var2.growing = false
						if var2.gui then
							var2.gui.Enabled = true
						end
					end)

					var3:Play()
				end)

			else
				if not var2.growing and (var2.shown == nil or var2.shown == "locked") then
					num1(var2.skeleton, 1, true)
					if var2.gui then
						var2.gui.Enabled = true
					end
				end
			end

			if var2.amount then
				local var13 = var2.amount
				var13.Text = if var10 then "1/1" else "0/1"
			end

			if var2.title then
				var2.title.TextColor3 = var10 and var18 or var2.titleColor
			end

			if var2.gradient then
				local var16 = var2.node.extra
				local bool3 = false
				if var2.node.cost <= var8 then
					bool3 = not var16
					if not bool3 then
						bool3 = var16.amount <= (var9:get(var16.currency) or 0)
					end
				end

				if var6 == "preview" then
					var2.gradient.Color = var3
				else
					var2.gradient.Color = var10 or bool3 and var2.green or var5
				end
			end

			if var2.buyLabel then
				if var6 == "preview" then
					local var23 = var2.node
					local bool4 = false
					if var23.rebirths ~= nil then
						bool4 = (var9:get("rebirths") or 0) < var23.rebirths
					end

					local var24 = if bool4 then "Rebirth " .. tostring(var23.rebirths) else "Floor " .. tostring(var23.floor)
					var24 = var24 or var2.buyText
				end

				local var26 = var2.buyText
				if var2.buyLabel.Text ~= var26 then
					var2.buyLabel.Text = var26
				end
			end

			if var2.buy then
				var2.buy.Visible = not var10
			end
		end

		if var2.detector then
			local var27 = var2.detector
			var27.MaxActivationDistance = if var6 == "open" then 60 else 0
		end

		if var6 ~= "open" and var20 == var2 then
			var20 = nil
			var7.Visible = false
			var7.Adornee = nil
			if var19 then
				var19.show(false)
			end
		end

		var2.shown = var6
	end

	local tbl5 = {}
	for k3, v3 in ipairs(var47 and var47:GetChildren() or {}) do
		local var48 = v3:IsA("BasePart")
		var48 = var48 and v3:GetAttribute("Links")
		if type(var48) ~= "string" or var48 == "" then
			continue
		end

		local tbl6 = {}
		for k4 in var48:gmatch("[^,]+") do
			table.insert(tbl6, k4)
		end

		local var49 = v3.Transparency
		local var50 = tbl5
		table.insert(var50, { part = v3, ids = tbl6, transparency = var49, shown = nil })
	end

	local function drawLines(arg1)
		for k1, v1 in ipairs(tbl5) do
			local bool1 = false
			for k2, v2 in ipairs(v1.ids) do
				local var1 = tbl2[v2]
				if not var1 then
					continue
				end

				if var1.shown == nil then
					continue
				end

				if var1.shown == "locked" then
					continue
				end

				bool1 = true
				break
			end

			if bool1 == v1.shown then
				continue
			end

			local var2 = v1.shown == nil
			v1.shown = bool1
			if v1.tween then
				v1.tween:Cancel()
				v1.tween = nil
			end

			local var3
			if bool1 and (arg1 and (not var2)) then
				v1.part.Transparency = 1
				var3 = TweenInfo.new(0.6, Enum.EasingStyle.Quad)
				v1.tween = var17:Create(v1.part, var3, { Transparency = v1.transparency })
				v1.tween:Play()
			else
				v1.part.Transparency = bool1 and v1.transparency or 1
			end
		end
	end

	local function drawAll(arg1)
		local num1 = math.huge
		local var2
		if arg1 then
			local var3 = var9:get("tree")
			var3 = var3 or {}
			local var4 = var8.floorFor(var9:get("stairsOwned") or 1, var1)
			for k1, v1 in ipairs(var10.NODES) do
				local var5 = tbl2[v1.id]
				if not var5 then
					continue
				end

				if var5.shown ~= "locked" then
					continue
				end

				if stateOf(v1, var3, var4) == "locked" then
					continue
				end

				num1 = math.min(num1, v1.tier)
			end
		end

		for k2, v2 in ipairs(var10.NODES) do
			if arg1 then
				if num1 < math.huge then
					local var6 = math.max(0, v2.tier - num1) * 0.08
					var6 = var6 or 0
				end
			end

			draw(v2.id, arg1, 0)
		end

		drawLines(arg1)
	end

	local var51 = workspace:FindFirstChild("Walls")
	local tbl7 = {}
	for k5, v4 in ipairs(var10.WALLS) do
		local var52 = var51
		var52 = var52 and var51:FindFirstChild(v4.name)
		if var52 then
			table.insert(tbl7, {
				def = v4,
				part = var52,
				home = var52.CFrame,
				down = false,
				props = {
					CanCollide = var52.CanCollide,
					CanQuery = var52.CanQuery,
					CanTouch = var52.CanTouch,
					Transparency = var52.Transparency,
					CastShadow = var52.CastShadow,
				},
			})

		else
			warn("[Tree] no Workspace.Walls." .. v4.name)
		end
	end

	local bool1 = false
	local function dropWall(arg1, arg2)
		if arg1.down then
			return
		end

		arg1.down = true
		local var3 = arg1.part
		local var4 = arg1.home
		if not arg2 then
			var3.CFrame = var4 * CFrame.new(0, -(var3.Size.Y + 1), 0)
			local var5 = arg1.part
			var5.CanCollide = false
			var5.CanQuery = false
			var5.CanTouch = false
			var5.Transparency = 1
			var5.CastShadow = false
			local var7 = var5:FindFirstChildWhichIsA("SurfaceGui")
			if var7 then
				var7.Enabled = false
			end

			return
		end

		var3.CanCollide = false
		local var8 = Instance.new("NumberValue")
		local var9 = var17:Create(var8, TweenInfo.new(2.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Value = 1 })
		local var10 = var8.Changed:Connect(function(arg1)
			var3.CFrame = (var4 + Vector3.new(math.random() * 2 - 1, 0, math.random() * 2 - 1) * (0.15 * (1 - arg1))) * CFrame.new(0, -(var3.Size.Y + 1) * arg1, 0)
		end)

		var9.Completed:Connect(function()
			var10:Disconnect()
			var8:Destroy()
			var3.CFrame = var4 * CFrame.new(0, -(var3.Size.Y + 1), 0)
			local var1 = arg1.part
			var1.CanCollide = false
			var1.CanQuery = false
			var1.CanTouch = false
			var1.Transparency = 1
			var1.CastShadow = false
			local var5 = var1:FindFirstChildWhichIsA("SurfaceGui")
			if var5 then
				var5.Enabled = false
			end
		end)

		var9:Play()
	end

	local var53 = var8.floorFor(var9:get("stairsOwned") or 1, var1)
	local var54 = var9:get("rebirths") or 0
	for k6, v5 in ipairs(tbl7) do
		local var55 = v5.def
		local var56 = var53
		local var57 = var54
		if var55.floor then
			local bool4 = false
			if var55.floor <= var56 then
				bool4 = not var55.rebirths
				if not bool4 then
					bool4 = var55.rebirths <= var57
				end
			end
		end

		if not var58 then
			continue
		end

	if not v5.down then
			v5.down = true
			local var58 = v5.part
			var55 = v5.home
			var58.CFrame = var55 * CFrame.new(0, -(var58.Size.Y + 1), 0)
			var56 = v5.part
			var56.CanCollide = false
			var56.CanQuery = false
			var56.CanTouch = false
			var56.Transparency = 1
			var56.CastShadow = false
			var57 = var56:FindFirstChildWhichIsA("SurfaceGui")
			if not var57 then
				continue
			end

			var57.Enabled = false
		end
	end

	local function refreshWalls(arg1, arg2)
		local var2
		local bool1 = false
		for k1, v1 in ipairs(tbl7) do
			local var1 = v1.def
			if var1.floor then
				local bool4 = false
				if var1.floor <= arg1 then
					bool4 = not var1.rebirths
					if not bool4 then
						bool4 = var1.rebirths <= arg2
					end
				end
			end

			local var3
			local var4
			if var2 and (not v1.down) then
				dropWall(v1, true)
				bool1 = true
			elseif not var2 then
				if not v1.down then
					continue
				end

		if not not v1.down then
					v1.down = false
					var1 = v1.part
					var1.CFrame = v1.home
					for k2, v2 in pairs(v1.props) do
						var1[k2] = v2
					end

					local var5 = var1:FindFirstChildWhichIsA("SurfaceGui")
					if not var5 then
						continue
					end

					var5.Enabled = true
				end
			end
		end

		return bool1
	end

	local num3 = math.huge
	for k7, v6 in ipairs(var10.NODES) do
		draw(v6.id, false, 0)
	end

	drawLines(false)
	var9:getChangedSignal("tree"):Connect(function()
		drawAll(true)
	end)

	var9:getChangedSignal("stairsOwned"):Connect(function()
		local var3 = var8.floorFor(var9:get("stairsOwned") or 1, var1)
		if var3 ~= var53 then
			var53 = var3
			if refreshWalls(var3, var9:get("rebirths") or 0) then
				task.delay(1.32, function()
					drawAll(true)
				end)

				return
			end

			drawAll(true)
		end
	end)

	var9:getChangedSignal("rebirths"):Connect(function()
		local var3 = var9:get("rebirths") or 0
		if var3 ~= var54 then
			var54 = var3
			refreshWalls(var8.floorFor(var9:get("stairsOwned") or 1, var1), var3)
			drawAll(true)
		end
	end)

	var9:getChangedSignal(var10.CURRENCY):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.2, function()
			bool1 = false
			for k1, v1 in ipairs(var10.NODES) do
				draw(v1.id, false, 0)
			end

			drawLines(false)
		end)
	end)

	var9:getChangedSignal(var10.WALL_CURRENCY):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.2, function()
			bool1 = false
			for k1, v1 in ipairs(var10.NODES) do
				draw(v1.id, false, 0)
			end

			drawLines(false)
		end)
	end)

	var9:getChangedSignal(var10.CRYSTAL_CURRENCY):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.2, function()
			bool1 = false
			for k1, v1 in ipairs(var10.NODES) do
				draw(v1.id, false, 0)
			end

			drawLines(false)
		end)
	end)

	var9:getChangedSignal("wood"):Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		task.delay(0.2, function()
			bool1 = false
			for k1, v1 in ipairs(var10.NODES) do
				draw(v1.id, false, 0)
			end

			drawLines(false)
		end)
	end)

	pcall(function()
		var9:getChangedSignal(var10.P3_CURRENCY):Connect(function()
			if bool1 then
				return
			end

			bool1 = true
			task.delay(0.2, function()
				bool1 = false
				for k1, v1 in ipairs(var10.NODES) do
					draw(v1.id, false, 0)
				end

				drawLines(false)
			end)
		end)
	end)

	pcall(function()
		var9:getChangedSignal(var10.P5_CURRENCY or "starmetal"):Connect(function()
			if bool1 then
				return
			end

			bool1 = true
			task.delay(0.2, function()
				bool1 = false
				for k1, v1 in ipairs(var10.NODES) do
					draw(v1.id, false, 0)
				end

				drawLines(false)
			end)
		end)
	end)
end }

--- ReplicatedStorage.Client.AutoRun [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = nil
local var3 = require(var1.Shared.Remotes)
local bool1 = false
game:GetService("RunService").Heartbeat:Connect(function()
	if var2 ~= nil then
		local var1 = var2
		var2 = nil
		var3.SaveSetting:FireServer("autoRun", var1)
	end

	if bool1 then
		bool1 = false
		var3.SaveSetting:FireServer("autoMine", false)
	end
end)

local var4 = game:GetService("Players").LocalPlayer
local var5 = require(var1.Shared.StairConfig)
local var6 = game:GetService("GroupService")
local var7 = require(var1.Packages.DataService).client
local var8 = require(var1.Shared.PassConfig)
local var9 = require(var1.Client.PassState)
local var10 = require(game:GetService("ReplicatedStorage").Client.Press)
return { init = function(_)
	local var1 = var4:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var3 = var1
	var3 = var3 and var1:FindFirstChild("AutoRun")
	if not var3 or (not var3:IsA("GuiButton")) then
		warn("[AutoRun] no Main.AutoRun button - nothing to toggle")
		return
	end

	local var11 = nil
	for k1, v1 in ipairs(var3:GetDescendants()) do
		if not v1:IsA("TextLabel") then
			continue
		end

		var11 = v1
		break
	end

	local bool2 = false
	local num1 = 0
	local bool3 = false
	local bool4 = false
	local var12 = var5.collect()
	local var13 = nil
	local var14 = nil
	local function target()
		local var1 = var4:GetAttribute("StairTop")
		var1 = var1 or (var7:get("stairsOwned") or 1)
		local var3 = var12[var1]
		if not var3 then
			var12 = var5.collect()
			var3 = var12[var1]
		end

		if not var3 then
			return nil
		end

		local var6 = var3:GetAttribute("StairHome")
		return (var6 or var3.CFrame).Position + Vector3.new(0, var3.Size.Y / 2, 0), var1, var3
	end

	local function placeOn(arg1, arg2)
		local var1 = var4.Character
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
		if not var1 or (not var2) then
			return
		end

		local var3 = arg1:GetAttribute("StairHome")
		var3 = var3 or arg1.CFrame
		local var5 = var12[arg2 + 1]
		local var6 = var5
		var6 = var6 and (var5:GetAttribute("StairHome") or var5.CFrame)
		local var9 = var6
		local var10 = (var3 * CFrame.new(0, arg1.Size.Y / 2 + 3, 0)).Position
		if var9 then
			var9 = Vector3.new(var6.Position.X, var10.Y, var6.Position.Z)
		end

		if not var9 or (var9 - var10).Magnitude < 0.1 then
			var9 = var10 - var3.RightVector
		end

		local var11 = var10
		local var15 = var9
		var1:PivotTo(CFrame.lookAt(var11, var15))
		var2.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		var2.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		var13 = nil
		var14 = nil
	end

	local function step()
		if not bool2 then
			return
		end

		local var1 = var4.Character
		local var3 = var1
		local var5 = var1
		var3 = var3 and var1:FindFirstChildWhichIsA("Humanoid")
		var5 = var5 and var1:FindFirstChild("HumanoidRootPart")
		if not var3 or (not var5 or var3.Health <= 0) then
			return
		end

		local var9, var10, var15 = target()
		if not var9 then
			return
		end

		if #var12 <= var10 then
			bool2 = false
			if var11 then
				local var16 = var11
				var16.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
			end

			var2 = false
			return
		end

		local var17 = Vector3.new(var5.Position.X - var9.X, 0, var5.Position.Z - var9.Z)
		if var17.Magnitude <= 2.5 then
			var13 = nil
			var14 = nil
			return
		end

		local var19 = os.clock()
		if var13 and var13 - 0.5 < var17.Magnitude then
			local var20 = var14 or var19
			var14 = var20
			if 1.5 <= var19 - var14 then
				placeOn(var15, var10)
				return
			end
		else
			var14 = nil
		end

		var13 = var17.Magnitude
		var3:MoveTo(var9)
	end

	local function start()
		local var1 = num1 + 1
		num1 = var1
		bool2 = true
		if var11 then
			var1 = var11
			var1.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
		end

		var2 = true
		if not var8.owns(var9.owned, "autoMineAnywhere") then
			bool1 = true
		end

		local var3 = var4.Character
		local var5 = var3
		local var6, var7, var10 = target()
		var5 = var5 and var3:FindFirstChild("HumanoidRootPart")
		if var10 and (var5 and 2.5 < Vector3.new(var5.Position.X - var6.X, 0, var5.Position.Z - var6.Z).Magnitude) then
			placeOn(var10, var7)
		end

		step()
	end

	var10.bind(var3, function()
		if not bool2 then
			local var1 = start
			if bool4 then
				return
			end

			bool4 = true
			task.spawn(function()
				local var2
				if bool3 then
					var2 = true
				else
					local success, result = pcall(function()
						local num1 = 596234797
						return var4:IsInGroup(num1)
					end)

					local var5 = success
					if var5 then
						var5 = result == true
					end

					bool3 = var5
					var2 = bool3
				end

				if var2 then
					bool4 = false
					var1()
					return
				end

				if var11 then
					var11.Text = "Joining..."
				end

				local success, result = pcall(function()
					local num1 = 596234797
					return var6:PromptJoinAsync(num1)
				end)

				bool4 = false
				if success and (result == Enum.GroupMembershipStatus.Joined or result == Enum.GroupMembershipStatus.AlreadyMember) then
					bool3 = true
					var1()
					return
				end

				if success and result == Enum.GroupMembershipStatus.JoinRequestPending then
					local var7 = num1 + 1
					num1 = var7
					var7 = num1
					if var11 then
						var11.Text = "Request Pending"
					end

					task.delay(2.5, function()
						if num1 == var7 then
							if var11 then
								local var1 = var11
								var1.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
							end
						end
					end)

					return
				end

				local var8 = num1 + 1
				num1 = var8
				var8 = num1
				if var11 then
					var11.Text = "Join Group to Use"
				end

				task.delay(2.5, function()
					if num1 == var8 then
						if var11 then
							local var1 = var11
							var1.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
						end
					end
				end)
			end)

			return
		end

		bool2 = false
		if var11 then
			local var3 = var11
			var3.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
		end

		var2 = false
		local var5 = var4.Character
		local var7 = var5
		local var8 = var5
		var7 = var7 and var5:FindFirstChildWhichIsA("Humanoid")
		var8 = var8 and var5:FindFirstChild("HumanoidRootPart")
		if var7 and var8 then
			var7:MoveTo(var8.Position)
		end
	end)

	var7:getChangedSignal("stairsOwned"):Connect(step)
	var4:GetAttributeChangedSignal("StairTop"):Connect(step)
	var7:getChangedSignal("settings"):Connect(function()
		local var2 = var7:get("settings")
		if bool2 and (var2 and var2.autoRun == false) then
			bool2 = false
			if var11 then
				local var3 = var11
				var3.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
			end
		end
	end)

	if var11 then
		var11.Text = if bool2 then "Auto Run: On" else "Auto Run: Off"
	end

	task.spawn(function()
		while true do
			task.wait(0.25)
			step()
		end
	end)

	local var16 = var7:get("settings")
	if var16 and var16.autoRun == true then
		task.spawn(function()
			local var1 = var4.Character;
			(var1 or var4.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart", 10)
			local num1 = 0
			while not var4:GetAttribute("PositionRestored") and num1 < 15 do
				task.wait(0.25)
				num1 = num1 + 0.25
			end

			task.wait(1.5)
			if bool2 then
				return
			end

			local var3
			if bool3 then
				var3 = true
			else
				local success, result = pcall(function()
					local num1 = 596234797
					return var4:IsInGroup(num1)
				end)

				local var6 = success
				if var6 then
					var6 = result == true
				end

				bool3 = var6
				var3 = bool3
			end

			if var3 then
				start()
				return
			end

			var2 = false
		end)

	end
end }

--- ReplicatedStorage.Client.PassState [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.Remotes)
local tbl1 = { owned = {} }
local tbl2 = {}
var1.PassesOwned.OnClientEvent:Connect(function(arg1)
	if type(arg1) ~= "table" then
		return
	end

	tbl1.owned = arg1
	for k1, v1 in ipairs(tbl2) do
		task.spawn(v1, arg1)
	end
end)

tbl1.onChanged = function(arg1)
	table.insert(tbl2, arg1)
	task.spawn(arg1, tbl1.owned)
end

return tbl1

--- ReplicatedStorage.Client.ShopUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = require(var1.Client.ClickTarget)
local var4 = require(var1.Shared.PassConfig)
local var5 = require(game:GetService("ReplicatedStorage").Client.Press)
local var6 = require(var1.Client.PassState)
local var7 = game:GetService("MarketplaceService")
local var8 = require(var1.Client.GiftUI)
local tbl1 = {}
local var9 = require(var1.Client.PriceCache)
local var10 = require(var1.Client.MenuEffects)
local var11 = game:GetService("RunService")
tbl1.init = function(_)
	local var1 = var2:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var12 = var1
	var12 = var12 and var1:FindFirstChild("Shop")
	if not var12 then
		warn("[Shop] no Main.Shop - nothing to open")
		return
	end

	local var13 = var3.over
	local tbl2 = {}
	for k1, v1 in ipairs(var4.LIST) do
		for k2, v2 in ipairs(var12:GetDescendants()) do
			if not v2:IsA("TextLabel") then
				continue
			end

			if v2.Name ~= "Title" then
				continue
			end

			if v2.Text ~= v1.card then
				continue
			end

			local var14 = v2.Parent
			local var15 = var14:FindFirstChild("Buy")
			local var16 = var15
			var16 = var16 and var15:FindFirstChild("Cost")
			local tbl3 = {
				def = v1,
				card = var14,
				buy = var15,
				cost = var16,
				price = nil,
				gift = var14:FindFirstChild("Gift"),
			}

			tbl3.fades = {}
			tbl2[v1.id] = tbl3
			if not var15 then
				break
			end

			for k3, v3 in ipairs(var15:GetDescendants()) do
				if not v3:IsA("GuiObject") then
					continue
				end

				table.insert(tbl2[v1.id].fades, { object = v3, authored = v3.BackgroundTransparency })
			end

			break
		end

		if tbl2[v1.id] then
			continue
		end

		local var17 = v1.card
		warn(("[Shop] no card titled '%s'"):format(var17))
	end

	local tbl4 = {}
	for k4, v4 in ipairs(var12:GetDescendants()) do
		if v4.Name ~= "Sunburst" then
			continue
		end

		if not v4:IsA("ImageLabel") then
			continue
		end

		table.insert(tbl4, v4)
	end

	for k5, v5 in pairs(tbl2) do
		if v5.buy then
			var5.bind(var13(v5.buy), function()
				if var4.owns(var6.owned, k5) then
					return
				end

				var7:PromptProductPurchase(var2, v5.def.productId)
			end)

		end

		local var18 = v5.gift
		if not var18 then
			continue
		end

		var5.bind(var13(v5.gift), function()
			var8.openFor(v5.def, function()
				tbl1.open()
			end)
		end)

	end

	local function drawOwned()
		for k1, v1 in pairs(tbl2) do
			local var1 = var4.owns(var6.owned, k1)
			if v1.cost then
				local var2 = v1.cost
				var2.Text = if var1 then "Owned" else v1.price or "R$ -"
			end

			if not v1.buy then
				continue
			end

			if v1.buy:IsA("GuiButton") then
				v1.buy.AutoButtonColor = not var1
			end

			for k2, v2 in ipairs(v1.fades) do
				local var3 = v2.authored
				v2.object.BackgroundTransparency = var1 and var3 + (1 - var3) * 0.55 or var3
			end
		end
	end

	for k6, v6 in pairs(tbl2) do
		if v6.cost then
			v6.cost.Text = "R$ -"
		end

		var9.fetch(v6.def.productId, Enum.InfoType.Product, function(arg1)
			local var1 = arg1 and var9.text(arg1) or "R$ -"
			v6.price = var1
			drawOwned()
		end)

	end

	var6.onChanged(drawOwned)
	local var19 = var10.bind(var12)
	tbl1.open = function()
		var19.open()
	end

	tbl1.close = function()
		var19.close()
	end

	local var20 = nil
	var12:GetPropertyChangedSignal("Visible"):Connect(function()
		local var2 = var12.Visible
		if var2 and (not var20) then
			var20 = var11.RenderStepped:Connect(function(arg1)
				for k1, v1 in ipairs(tbl4) do
					local var1 = 18 * arg1
					local var2 = (v1.Rotation + var1) % 360
					v1.Rotation = var2
				end
			end)

			return
		end

		if not var2 and var20 then
			var20:Disconnect()
			var20 = nil
		end
	end)

	local var22 = var12.Visible
	if var22 and (not var20) then
		var11.RenderStepped:Connect(function(arg1)
			for k1, v1 in ipairs(tbl4) do
				local var1 = 18 * arg1
				local var2 = (v1.Rotation + var1) % 360
				v1.Rotation = var2
			end
		end)

	elseif not var22 and var20 then
		var20:Disconnect()
	end

	var22 = var12:FindFirstChild("CloseButton")
	if var22 then
		var5.bind(var22, var19.close)
	end

	local var23 = var1:FindFirstChild("Menu")
	local var24 = var23
	var24 = var24 and var23:FindFirstChild("Shop")
	if var24 then
		var5.bind(var24, var19.toggle)
	else
		warn("[Shop] no Main.Menu.Shop button - the shop has no way in")
	end
end

return tbl1

--- ReplicatedStorage.Client.GiftUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Shared.PassConfig)
local var2 = game:GetService("Players")
local tbl1 = {}
local var3 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			var3.GiftIntent:FireServer(v1.pass, v1.userId)
		end)

	end
end)

local var4 = var2.LocalPlayer
local var5 = require(var1.Client.MenuEffects)
local var6 = nil
local var7 = nil
local var8 = require(var1.Client.PriceCache)
local var9 = require(game:GetService("ReplicatedStorage").Client.Press)
local var10 = nil
local var11 = game:GetService("MarketplaceService")
local var12 = require(var1.Client.UISound)
local tbl2 = { owned = "Owned", gone = "Left", loading = "Wait", unknown = "Gift" }
local tbl3 = {}
tbl3.init = function(_)
	local var1 = var4:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var13 = var1
	var13 = var13 and var1:FindFirstChild("Gift")
	local var14 = var13
	var14 = var14 and var13:FindFirstChild("List")
	local var15 = var14
	var15 = var15 and var14:FindFirstChild("Entry")
	if not var13 or (not var14 or (not var15)) then
		warn("[Gift] no Main.Gift.List.Entry - no list to build")
		return
	end

	var15.Parent = nil
	local var16 = var5.bind(var13)
	local tbl4 = {}
	local function paintPrices()
		for k1, v1 in pairs(tbl4) do
			local bool2 = false
			if k1 ~= "empty" then
				local var2 = v1:FindFirstChild("Buy")
				bool2 = var2
				bool2 = bool2 and var2:FindFirstChildWhichIsA("TextLabel", true)
			end

			if not bool2 then
				continue
			end

			if v1:GetAttribute("Refused") then
				continue
			end

			local var3 = var7 and var8.text(var7) or "Gift"
			bool2.Text = var3
		end
	end

	var3.GiftAnswer.OnClientEvent:Connect(function(arg1, arg2, arg3, arg4)
		if not var10 or var10.id ~= arg1 then
			return
		end

		if arg3 then
			var11:PromptProductPurchase(var4, var10.productId)
			var16.close()
			local var1 = var6
			var6 = nil
			if var1 then
				var1()
			end

			return
		end

		var12.play("denied")
		local var2 = tbl4[arg2]
		local var3 = var2
		local var5 = var2:FindFirstChild("Buy")
		var3 = var3 and (var5 and var5:FindFirstChildWhichIsA("TextLabel", true))
		if var3 then
			var2:SetAttribute("Refused", true)
			var3.Text = tbl2[arg4] or "Gift"
		end
	end)

	local function rebuild()
		for k1, v1 in pairs(tbl4) do
			v1:Destroy()
		end

		tbl4 = {}
		local num1 = 0
		for k2, v2 in ipairs(var2:GetPlayers()) do
			if v2 == var4 then
				continue
			end

			local var1 = var15:Clone()
			var1.Name = v2.Name
			num1 = num1 + 1
			var1.LayoutOrder = num1
			local var5 = var1:FindFirstChild("Title")
			if var5 and var5:IsA("TextLabel") then
				var5.Text = "@" .. v2.Name
			end

			local var7 = var1:FindFirstChild("PFP")
			if var7 and var7:IsA("ImageLabel") then
				task.spawn(function()
					local success, result = pcall(function()
						local var1 = v2.UserId
						local var3 = Enum.ThumbnailType.HeadShot
						local var4 = Enum.ThumbnailSize.Size150x150
						return var2:GetUserThumbnailAsync(var1, var3, var4)
					end)

					if success and (result and var7.Parent) then
						var7.Image = result
					end
				end)

			end

			local var11 = var1:FindFirstChild("Buy")
			if var11 then
				local var12 = Instance.new("TextButton")
				var12.Name = "Hit"
				var12.Text = ""
				var12.BackgroundTransparency = 1
				var12.AnchorPoint = Vector2.new(0.5, 0.5)
				var12.Position = UDim2.fromScale(0.5, 0.5)
				var12.Size = UDim2.fromScale(1, 1)
				var12.ZIndex = var11.ZIndex + 5
				var12.Parent = var11
				var9.bind(var12, function()
					if var10 and (not var1:GetAttribute("Refused")) then
						table.insert(tbl1, { pass = var10.id, userId = v2.UserId })
					end
				end)

			end

			var1.Parent = var14
			tbl4[v2.UserId] = var1
		end

		if num1 == 0 then
			local var13 = var15:Clone()
			var13.Name = "Empty"
			local var17 = var13:FindFirstChild("Title")
			if var17 and var17:IsA("TextLabel") then
				var17.Text = "Nobody else is here"
			end

			local str1 = "PFP"
			for k3, v3 in ipairs({ "Buy", str1 }) do
				local var18 = var13:FindFirstChild(v3)
				if not var18 then
					continue
				end

				if not var18:IsA("GuiObject") then
					continue
				end

				var18.Visible = false
			end

			var13.Parent = var14
			tbl4.empty = var13
		end

		paintPrices()
		return num1
	end

	tbl3.openFor = function(arg1, arg2)
		var10 = arg1
		var7 = nil
		var6 = arg2
		rebuild()
		var16.open()
		var8.fetch(arg1.productId, Enum.InfoType.Product, function(arg1)
			if var10 == arg1 then
				var7 = arg1
				paintPrices()
			end
		end)
	end

	tbl3.close = function()
		var16.close()
		local var1 = var6
		var6 = nil
		if var1 then
			var1()
		end
	end

	local var18 = var13:FindFirstChild("CloseButton")
	local function leave()
		var16.close()
		local var1 = var6
		var6 = nil
		if var1 then
			var1()
		end
	end

	if var18 then
		var9.bind(var18, leave)
	end

	var2.PlayerAdded:Connect(function()
		if var13.Visible then
			rebuild()
		end
	end)

	var2.PlayerRemoving:Connect(function()
		if var13.Visible then
			task.defer(rebuild)
		end
	end)
end

return tbl3

--- ReplicatedStorage.Client.PriceCache [ModuleScript]
-- y u r i

local tbl1 = {}
local tbl2 = {}
local var1 = game:GetService("MarketplaceService")
local var2 = require(game:GetService("ReplicatedStorage").Shared.NumberFormat)
return {
	fetch = function(arg1, arg2, arg3)
		if type(arg1) ~= "number" then
			task.spawn(arg3, nil)
			return
		end

		local var2 = tostring(arg2) .. ":" .. arg1
		if tbl1[var2] then
			task.spawn(arg3, tbl1[var2])
			return
		end

		if tbl2[var2] then
			table.insert(tbl2[var2], arg3)
			return
		end

		tbl2[var2] = { arg3 }
		task.spawn(function()
			local success, result = pcall(function()
				local var2 = arg1
				local var3 = arg2
				return var1:GetProductInfo(var2, var3)
			end)

			if success then
				local var3 = result and result.PriceInRobux or nil
			end

			local var4 = nil
			if type(var4) == "number" then
				tbl1[var2] = var4
			else
				var4 = nil
			end

			tbl2[var2] = nil
			for k1, v1 in ipairs(tbl2[var2]) do
				task.spawn(v1, var4)
			end
		end)
	end,
	text = function(arg1)
		return "R$ " .. var2.comma(arg1)
	end,
}

--- ReplicatedStorage.Client.Announce [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = nil
local var3 = Font.new("rbxasset://fonts/families/PressStart2P.json")
local var4 = game:GetService("TweenService")
return { show = function(arg1, arg2)
	local var6 = var1:FindFirstChildOfClass("PlayerGui")
	if not var6 then
		return
	end

	if var2 then
		var2:Destroy()
	end

	local var7 = Instance.new("ScreenGui")
	var7.Name = "Announcement"
	var7.IgnoreGuiInset = true
	var7.ResetOnSpawn = false
	var7.DisplayOrder = 40
	var7.Parent = var6
	var2 = var7
	local var8 = Instance.new("TextLabel")
	var8.AnchorPoint = Vector2.new(0.5, 0.5)
	var8.Position = UDim2.fromScale(0.5, 0.32)
	var8.Size = UDim2.fromScale(0.9, 0.08)
	var8.BackgroundTransparency = 1
	var8.FontFace = var3
	var8.Text = arg1
	var8.TextScaled = true
	local var9 = arg2
	var9 = var9 or Color3.new(1, 1, 1)
	var8.TextColor3 = var9
	var8.TextTransparency = 1
	var8.Parent = var7
	var9 = Instance.new("UITextSizeConstraint")
	var9.MaxTextSize = 42
	var9.Parent = var8
	local var10 = Instance.new("UIStroke")
	var10.Thickness = 3
	var10.Color = Color3.new(0, 0, 0)
	var10.Transparency = 1
	var10.Parent = var8
	local var11 = Instance.new("UIScale")
	var11.Scale = 0.6
	var11.Parent = var8
	local var12 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	var4:Create(var11, var12, { Scale = 1 }):Play()
	var4:Create(var8, var12, { TextTransparency = 0 }):Play()
	var4:Create(var10, var12, { Transparency = 0 }):Play()
	task.delay(2.95, function()
		if var2 ~= var7 then
			return
		end

		local var1 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		var4:Create(var8, var1, { TextTransparency = 1 }):Play()
		var4:Create(var10, var1, { Transparency = 1 }):Play()
		task.delay(0.6, function()
			if var2 == var7 then
				var2 = nil
			end

			var7:Destroy()
		end)
	end)
end }

--- ReplicatedStorage.Client.SmelterClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local var3 = game:GetService("RunService")
local var4 = game:GetService("TweenService")
local var5 = require(var1.Packages.DataService).client
local var6 = require(var1.Shared.NumberFormat)
local var7 = require(var1.Shared.Remotes)
local var8 = require(var1.Shared.SmelterConfig)
local var9 = require(var1.Shared.TreeConfig)
local var10 = require(var1.Shared.PassConfig)
local var11 = require(var1.Client.PassState)
local var12 = require(var1.Client.UISound)
local var13 = require(var1.Client.WorldTap)
local tbl1 = {
	oreSize = Vector3.new(1.5, 1.1, 1.5),
	oreColor = Color3.fromRGB(118, 104, 94),
	barSize = Vector3.new(2.2, 0.8, 1.2),
	ingotSize = Vector3.new(2.4, 0.55, 1.3),
	furnace = 4,
	sink = 3,
	drawRange = 220,
}

tbl1.hot = Color3.fromRGB(255, 160, 45)
tbl1.cooled = Color3.fromRGB(190, 70, 30)
tbl1.ingotColor = Color3.fromRGB(196, 200, 210)
local tbl2 = {}
var3.Heartbeat:Connect(function()
	if #tbl2 == 0 then
		return
	end

	local var1 = tbl2
	tbl2 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			v1:FireServer()
		end)

	end
end)

local function screenOf(arg1)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChild("Screen")
	local var2 = var1
	var2 = var2 and var1:FindFirstChildWhichIsA("SurfaceGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChildWhichIsA("GuiObject")
	if not var3 then
		return nil
	end

	local var4 = nil
	for k1, v1 in ipairs(var3:GetChildren()) do
		if not v1:IsA("GuiButton") then
			continue
		end

		var4 = v1
	end

	if not var4 then
		for k2, v2 in ipairs(var3:GetChildren()) do
			if not v2:IsA("Frame") then
				continue
			end

			if not v2:FindFirstChild("Cost") then
				continue
			end

			var4 = v2
		end
	end

	local tbl1 = { count = var3:FindFirstChild("YouHave") }
	tbl1.capacity = var3:FindFirstChild("Capacity")
	tbl1.button = var4
	return tbl1
end

local function pressable(arg1, arg2)
	if arg1:IsA("GuiButton") then
		var13.bind(arg1, arg2)
		return
	end

	local var1 = Instance.new("TextButton")
	var1.Name = "Hit"
	var1.Text = ""
	var1.BackgroundTransparency = 1
	var1.AnchorPoint = Vector2.new(0.5, 0.5)
	var1.Position = UDim2.fromScale(0.5, 0.5)
	var1.Size = UDim2.fromScale(1, 1)
	var1.ZIndex = arg1.ZIndex + 5
	var1.Parent = arg1
	var13.bind(var1, arg2)
end

local var14 = var2.LocalPlayer
return { init = function(_)
	local var1 = workspace:WaitForChild("SmelterSystem", 20)
	local var13 = var1
	var13 = var13 and var1:FindFirstChild("Machine")
	local var15 = var13
	var15 = var15 and var8.path(var13)
	if not var15 then
		warn("[Smelter] Workspace.SmelterSystem.Machine is incomplete - nothing to draw")
		return
	end

	local str1 = "Dropper"
	local str2 = "Collector"
	local var16 = screenOf(var13:FindFirstChild(str1))
	local var17 = screenOf(var13:FindFirstChild(str2))
	local function drawScreens()
		local var1 = var5:get("smelter")
		var1 = var1 or {}
		if var16 and var16.count then
			var16.count.Text = "You Have: " .. var6.format(var5:get("iron") or 0)
		end

		if var16 and var16.capacity then
			local str2 = "upgrades"
			local var3 = var8.paceFor(var15, var5:get(str2))
			local var4 = math.floor(var3.capacity)
			var16.capacity.Text = ("%s/%s"):format(var6.format(var1.queued or 0), var6.format(var4))
		end

		if var17 then
			if var17.count then
				local str5 = "tree"
				local var7 = math.floor(var8.loadOf(var1) * var8.ingotsPerOre(var9.totals(var5:get(str5)), var10.totals(var11.owned).iron))
				local var13 = "Iron: " .. var6.format(var5:get("ingots") or 0)
				if 0 < var7 then
					local var14 = var7
					var13 = var13 .. ("  (+%s)"):format(var6.format(var14))
				end

				var17.count.Text = var13
			end
		end
	end

	drawScreens()
	var5:getChangedSignal("iron"):Connect(drawScreens)
	var5:getChangedSignal("ingots"):Connect(drawScreens)
	var5:getChangedSignal("smelter"):Connect(drawScreens)
	var5:getChangedSignal("upgrades"):Connect(drawScreens)
	var5:getChangedSignal("tree"):Connect(drawScreens)
	if var16 and var16.button then
		pressable(var16.button, function()
			if (var5:get("iron") or 0) <= 0 then
				var12.play("denied")
				return
			end

			local var1 = var5:get("smelter")
			local str1 = "upgrades"
			if math.floor(var8.paceFor(var15, var5:get(str1)).capacity) <= ((var1 or {}).queued or 0) then
				var12.play("denied")
				return
			end

			local var3 = var2.LocalPlayer.Character
			local var4 = var3
			var4 = var4 and var3:FindFirstChild("HumanoidRootPart")
			local bool2 = false
			if var4 ~= nil then
				bool2 = var8.inRoom(var4.Position)
			end

			if not bool2 then
				var12.play("denied")
				return
			end

			table.insert(tbl2, var7.SmelterDeposit)
		end)

	end

	var13:FindFirstChild("Smelter")
	local var18 = var8.positionAt(var15, var15.smelter) + Vector3.new(0, 2, 0)
	local var19 = Instance.new("Part")
	var19.Name = "FurnaceGlow"
	var19.Anchored = true
	var19.CanCollide = false
	var19.CanQuery = false
	var19.CanTouch = false
	var19.Transparency = 1
	var19.Size = Vector3.new(1, 1, 1)
	var19.Position = var18
	var19.Parent = var13
	local var20 = Instance.new("PointLight")
	var20.Color = Color3.fromRGB(255, 130, 40)
	var20.Range = 18
	var20.Brightness = 0.4
	var20.Shadows = false
	var20.Parent = var19
	local var21 = Instance.new("ParticleEmitter")
	var21.Enabled = false
	var21.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	local num1 = 255
	local num2 = 80
	local num3 = 20
	var21.Color = ColorSequence.new(Color3.fromRGB(255, 190, 70), Color3.fromRGB(num1, num2, num3))
	var21.LightEmission = 1
	num2 = 1
	num3 = 0
	var21.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(num2, num3) })
	var21.Lifetime = NumberRange.new(0.5, 1.1)
	var21.Speed = NumberRange.new(6, 12)
	var21.SpreadAngle = Vector2.new(35, 35)
	var21.Acceleration = Vector3.new(0, 6, 0)
	var21.EmissionDirection = Enum.NormalId.Top
	var21.Parent = var19
	local var22 = var13:FindFirstChild("Press")
	var22 = var22 and var13.Press:FindFirstChild("Hammer")
	local var23 = var22
	var23 = var23 and var22:GetPivot()
	local num4 = 0
	if var22 then
		local var26, var27 = var22:GetBoundingBox()
		num4 = math.max(0, var26.Position.Y - var27.Y / 2 - (var15.top + tbl1.ingotSize.Y))
	end

	var27 = Instance.new("Attachment")
	var27.WorldPosition = var8.positionAt(var15, var15.press) + Vector3.new(0, tbl1.ingotSize.Y, 0)
	var27.Parent = workspace.Terrain
	num3 = Instance.new("ParticleEmitter")
	num3.Enabled = false
	num3.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	local num5 = 255
	local num6 = 120
	local num7 = 30
	num3.Color = ColorSequence.new(Color3.fromRGB(255, 240, 180), Color3.fromRGB(num5, num6, num7))
	num3.LightEmission = 1
	num6 = 1
	num7 = 0
	num3.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(num6, num7) })
	num3.Lifetime = NumberRange.new(0.25, 0.55)
	num3.Speed = NumberRange.new(10, 20)
	num3.SpreadAngle = Vector2.new(80, 80)
	num3.Acceleration = Vector3.new(0, -40, 0)
	num3.Drag = 2
	num3.EmissionDirection = Enum.NormalId.Top
	num3.Parent = var27
	local bool1 = false
	local var28 = Instance.new("Folder")
	var28.Name = "SmelterBelt"
	var28.Parent = var13
	num5 = {}
	num6 = function()
		local var1 = Instance.new("Part")
		var1.Anchored = true
		var1.CanCollide = false
		var1.CanQuery = false
		var1.CanTouch = false
		var1.TopSurface = Enum.SurfaceType.Smooth
		var1.BottomSurface = Enum.SurfaceType.Smooth
		var1.Parent = var28
		return { part = var1 }
	end

	local function strike(arg1)
		if not var22 or bool1 then
			return
		end

		bool1 = true
		local var1 = math.min(1, (arg1 or 1) * 0.85 / 0.42)
		local var3 = Instance.new("NumberValue")
		local var6 = var4:Create(var3, TweenInfo.new(0.07 * var1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Value = 1 })
		local var7 = 0.35 * var1
		local var9 = var3.Changed:Connect(function(arg1)
			var22:PivotTo(CFrame.new(0, -num4 * arg1, 0) * var23)
		end)

		var6.Completed:Connect(function()
			local var1 = var5:get("settings")
			local var10 = var1
			if var10 then
				var10 = var1.particles == false
			end

			if not var10 then
				num3:Emit(18)
			end

			var1 = var2.LocalPlayer.Character
			var10 = var1
			var10 = var10 and var1:FindFirstChild("HumanoidRootPart")
			local bool3 = false
			if var10 ~= nil then
				bool3 = var8.inRoom(var10.Position)
			end

			if bool3 then
				var12.play("mineHit")
			end

			bool3 = var4:Create(var3, TweenInfo.new(var7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Value = 0 })
			bool3.Completed:Connect(function()
				var9:Disconnect()
				var3:Destroy()
				var22:PivotTo(var23)
				bool1 = false
			end)

			bool3:Play()
		end)

		var6:Play()
	end

	var3.RenderStepped:Connect(function()
		local var1 = var5:get("smelter")
		var1 = var1 or {}
		local str1 = "upgrades"
		local var4 = var1.queued or 0
		local var6 = var8.paceFor(var15, var5:get(str1))
		local tbl2 = {}
		local bool1 = false
		local var7
		local var9
		if 0 < var4 then
			str1 = var14.Character
			local var10 = str1
			var7 = "HumanoidRootPart"
			var10 = var10 and str1:FindFirstChild(var7)
			local var11
			if not var10 then
				var11 = false
			else
				var9 = (var10.Position - var15.points[2]).Magnitude
				var7 = tbl1.drawRange
				var11 = var9 <= var7
			end

			if var11 then
				var11 = workspace:GetServerTimeNow()
				for i1 = 0, var4 - 1 do
					var7 = (var1.nextAt or 0) + i1 * var6.spacing
					local var12 = var7 - var11
					if var6.trip < var12 then
						break
					end

					local var13 = var15.length - math.max(var12, 0) * var6.speed
					local var16 = ("%.2f"):format(var7)
					tbl2[var16] = true
					local var18 = num5[var16]
					if not var18 then
						var18 = num6()
						num5[var16] = var18
					end

					local var19 = var18.part
					local var22, var23 = var8.positionAt(var15, var13)
					if var13 < var15.smelter - tbl1.furnace then
						var19.Size = tbl1.oreSize
						var19.Material = Enum.Material.Slate
						var19.Color = tbl1.oreColor
						var19.Transparency = 0
					else
						if var13 <= var15.smelter + tbl1.furnace then
							var19.Transparency = 1
							bool1 = true
							if not var18.smelted then
								var18.smelted = true
								local var24 = var5:get("settings")
								local var26 = var24
								if var26 then
									var26 = var24.particles == false
								end

								if not var26 then
									var21:Emit(10)
								end
							end
						else
							if var13 < var15.press then
								local var27 = math.clamp((var13 - (var15.smelter + tbl1.furnace)) / math.max(var15.press - (var15.smelter + tbl1.furnace), 1), 0, 1)
								var19.Size = tbl1.barSize
								var19.Material = Enum.Material.Neon
								var19.Color = tbl1.hot:Lerp(tbl1.cooled, var27)
								var19.Transparency = 0
								if not var18.struck and var15.press - var6.speed * 0.07 <= var13 then
									var18.struck = true
									strike(var6.spacing)
								end
							else
								if not var18.struck then
									var18.struck = true
									strike(var6.spacing)
								end

								var19.Size = tbl1.ingotSize
								var19.Material = Enum.Material.Metal
								var19.Color = tbl1.ingotColor
								var19.Transparency = math.clamp((var13 - (var15.length - tbl1.sink)) / tbl1.sink, 0, 1)
							end
						end
					end

					local var28 = var19.Size.Y / 2
					var19.CFrame = CFrame.lookAt(var22 + Vector3.new(0, var28, 0), var22 + Vector3.new(0, var28, 0) + var23)
				end
			end
		end

		for k1, v1 in pairs(num5) do
			if tbl2[k1] then
				continue
			end

			v1.part:Destroy()
			num5[k1] = nil
		end

		str1 = var20
		local var29 = str1.Brightness + ((bool1 and 3 + math.noise(os.clock() * 6) * 1.2 or 0.4) - var20.Brightness) * 0.2
		str1.Brightness = var29
	end)
end }

--- ReplicatedStorage.Client.TrailUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Shared.NumberFormat)
local var2 = game:GetService("Players")
local var3 = game:GetService("RunService")
local tbl1 = {}
var3.Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		local var2 = v1
		local num1 = 2
		v1[1]:FireServer(table.unpack(var2, num1))
	end
end)

local num1 = 160
local num2 = 35
local num3 = 35
local var4 = ColorSequence.new(Color3.fromRGB(235, 80, 70), Color3.fromRGB(num1, num2, num3))
num2 = 95
num3 = 95
local num4 = 95
local var5 = ColorSequence.new(Color3.fromRGB(150, 150, 150), Color3.fromRGB(num2, num3, num4))
num3 = 215
num4 = 150
local num5 = 30
local var6 = ColorSequence.new(Color3.fromRGB(255, 215, 90), Color3.fromRGB(num3, num4, num5))
local var7 = var2.LocalPlayer
local var8 = nil
local var9 = require(var1.Shared.StairConfig)
local var10 = require(var1.Packages.DataService).client
local var11 = require(var1.Shared.TrailConfig)
local var12 = require(var1.Client.UISound)
num3 = function(arg1, ...)
	table.insert(tbl1, { arg1, ... })
end

local var13 = require(var1.Shared.Remotes)
local var14 = game:GetService("AvatarEditorService")
num2 = {}
local var15 = game:GetService("MarketplaceService")
local var16 = game:GetService("GroupService")
local var17 = require(game:GetService("ReplicatedStorage").Client.Press)
num1 = Color3.fromRGB(120, 120, 120)
local var18 = require(var1.Client.MenuEffects)
local var19 = require(var1.Client.SettingFlag)
num2.init = function(_)
	task.defer(function()
		local success, result = pcall(function()
			require(game:GetService("ReplicatedStorage").Client.TotemClient):init()
		end)

		if not success then
			warn("[Totems] TotemClient failed to start - " .. tostring(result))
		end
	end)

	task.defer(function()
		local success, result = pcall(function()
			require(game:GetService("ReplicatedStorage").Client.StarforgeClient):init()
		end)

		if not success then
			warn("[Starforge] StarforgeClient failed to start - " .. tostring(result))
		end
	end)

	local var1 = var7:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var20 = var1
	var20 = var20 and var1:FindFirstChild("Trails")
	local var21 = var20
	var21 = var21 and var20:FindFirstChild("TrailScroller")
	local var22 = var21
	local var23 = var21
	var22 = var22 and var21:FindFirstChildWhichIsA("UIGridLayout")
	var23 = var23 and var21:FindFirstChild("Trail")
	if not var20 or (not var21 or (not var22 or (not var23))) then
		warn("[Trails] no Main.Trails.TrailScroller.Trail - the vendor has no menu")
		return
	end

	var23.Parent = nil
	local var24 = var23:FindFirstChild("Buy")
	local var25 = var24
	var25 = var25 and var24:FindFirstChildWhichIsA("UIGradient", true)
	local num4 = 40
	local num5 = 150
	local num6 = 40
	local var26 = var25 and var25.Color or ColorSequence.new(Color3.fromRGB(90, 220, 90), Color3.fromRGB(num4, num5, num6))
	var8 = var26
	var26 = var9.collect()
	local function designedWindow()
		local var2 = var21.AbsoluteWindowSize
		local num1 = 1
		local var3 = var21
		local var4 = var3:FindFirstChildWhichIsA("UIScale")
		while not var3 and var3 == var1 and var4 and 0 < var4.Scale do
		end

		return var2 / math.max(num1, 0.01)
	end

	num4 = var22.CellSize
	num5 = math.ceil(#var11.LIST / 2)
	local bool1 = false
	local var27 = nil
	local var28 = nil
	local bool2 = false
	local bool3 = false
	local bool4 = false
	num6 = function()
		local var1 = designedWindow()
		if var1.X < 1 or var1.Y < 1 then
			return
		end

		local var2 = Vector2.new((var1.X - var22.CellPadding.X.Offset * 1 - 1) / 2, var1.Y * num4.Y.Scale)
		var22.CellSize = UDim2.fromOffset(math.floor(var2.X), (math.floor(var2.Y)))
		var21.AutomaticCanvasSize = Enum.AutomaticSize.None
		var21.CanvasSize = UDim2.fromOffset(0, (math.ceil(num5 * var2.Y + math.max(num5 - 1, 0) * var22.CellPadding.Y.Offset)))
	end

	local tbl1 = {}
	local tbl2 = {}
	local var29 = nil
	local num7 = 1
	local str1 = "all"
	local function onPress(arg1)
		local var1 = var10:get("trails")
		var1 = var1 or {}
		if var1[arg1.id] then
			if var10:get("equippedTrail") == arg1.id then
				var12.play("denied")
				return
			end

			num3(var13.EquipTrail, arg1.id)
			return
		end

		if arg1.special == "favorite" then
			if bool2 then
				return
			end

			bool2 = true
			task.spawn(function()
				local success, result = pcall(function()
					local var1 = game.PlaceId
					local var2 = Enum.AvatarItemType.Asset
					return var14:GetFavorite(var1, var2)
				end)

				if success and result then
					bool2 = false
					var12.play("purchase")
					num3(var13.BuyTrail, arg1.id, true)
					return
				end

				local var1 = nil
				local success, result = pcall(function()
					var14:PromptSetFavorite(game.PlaceId, Enum.AvatarItemType.Asset, true)
				end)

				local var2 = var14.PromptSetFavoriteCompleted:Connect(function(arg1)
					var1 = arg1
				end)

				if success then
					local num2 = 0
					while true do
						if var1 == nil and num2 < 120 then
							task.wait(0.2)
							num2 = num2 + 0.2
							continue
						end
					end
				else
					warn("[Trails] favorite prompt could not open: " .. tostring(result))
				end

				var2:Disconnect()
				bool2 = false
				if var1 == Enum.AvatarPromptResult.Success then
					var12.play("purchase")
					num3(var13.BuyTrail, arg1.id, true)
				else
					var12.play("denied")
				end
			end)

			return
		end

		if arg1.special == "like" then
			if not bool3 then
				bool3 = true
				var12.play("click")
				var28()
				return
			end

			bool3 = false
			var12.play("purchase")
			num3(var13.BuyTrail, arg1.id, true)
			return
		end

		if arg1.special == "wheel" then
			var12.play("denied")
			if num2.flashTooltip then
				num2.flashTooltip(arg1)
			end

			return
		end

		if arg1.special == "leaderboard" then
			var12.play("denied")
			num3(var13.BuyTrail, arg1.id)
			if num2.flashTooltip then
				num2.flashTooltip(arg1)
			end

			return
		end

		if arg1.special == "robux" then
			if not arg1.productId then
				var12.play("denied")
				return
			end

			pcall(function()
				var15:PromptProductPurchase(var7, arg1.productId)
			end)

			return
		end

		if arg1.special == "group" then
			if bool4 then
				return
			end

			bool4 = true
			task.spawn(function()
				local var1
				if bool1 then
					var1 = true
				else
					local success, result = pcall(function()
						local var1 = var11.GROUP_ID
						return var7:IsInGroup(var1)
					end)

					local var3 = success
					if var3 then
						var3 = result == true
					end

					bool1 = var3
					var1 = bool1
				end

				if var1 then
					bool4 = false
					var12.play("purchase")
					num3(var13.BuyTrail, arg1.id, true)
					return
				end

				var27 = "JOINING..."
				var28()
				local success, result = pcall(function()
					local var1 = var11.GROUP_ID
					return var16:PromptJoinAsync(var1)
				end)

				bool4 = false
				if success and (result == Enum.GroupMembershipStatus.Joined or result == Enum.GroupMembershipStatus.AlreadyMember) then
					bool1 = true
					var27 = "CLAIMING..."
					var28()
					local str1 = "CLAIMING..."
					task.delay(8, function()
						if var27 == str1 then
							var27 = nil
							var28()
						end
					end)

					var12.play("purchase")
					num3(var13.BuyTrail, arg1.id, true)
					return
				end

				if success and result == Enum.GroupMembershipStatus.JoinRequestPending then
					var27 = "REQUEST PENDING"
					var28()
					local str2 = "REQUEST PENDING"
					task.delay(3, function()
						if var27 == str2 then
							var27 = nil
							var28()
						end
					end)

					return
				end

				var27 = nil
				var28()
				var12.play("denied")
			end)

			return
		end

		if arg1.special == "collection" then
			if var11.countOwned(var1) < arg1.needs then
				var12.play("denied")
				return
			end

			var12.play("purchase")
			num3(var13.BuyTrail, arg1.id)
			return
		end

		if arg1.floor and var9.floorFor(var10:get("stairsOwned") or 1, var26) < arg1.floor then
			var12.play("denied")
			return
		end

		if arg1.door then
			if not var10:get({ "doors", arg1.door }) then
				var12.play("denied")
				return
			end
		end

		if not var11.affordable(arg1, function(arg1)
			local var1 = arg1
			return var10:get(var1)
		end) then

			var12.play("denied")
			return
		end

		var12.play("purchase")
		num3(var13.BuyTrail, arg1.id)
	end

	for k1, v1 in ipairs(var11.LIST) do
		local var30 = var23:Clone()
		var30.Name = v1.id
		var30.LayoutOrder = v1.order
		local var32 = var30:FindFirstChild("Title")
		local var33 = var11.TIER_BY_ID[v1.tier]
		if var32 then
			var32.Text = v1.name .. " Trail"
			var32.TextColor3 = v1.colors[1]
		end

		local var35 = var30:FindFirstChild("Buffs")
		if var35 then
			var35.Text = var33 and var33.name or v1.tier
			local var36 = var33 and var33.color or Color3.new(1, 1, 1)
			var35.TextColor3 = var36
		end

		local var37 = var30:FindFirstChild("Preview")
		local var38 = var37
		var38 = var38 and var37:FindFirstChildWhichIsA("UIGradient")
		if var38 then
			var38.Color = var11.colorSequence(v1.colors)
		end

		local var40 = var30:FindFirstChild("Stats")
		local var41
		if var40 then
			for k2, v2 in ipairs(var11.STATS) do
				local var42 = var40:FindFirstChild(v2:sub(1, 1):upper() .. v2:sub(2))
				if not var42 then
					continue
				end

				if not var42:IsA("TextLabel") then
					continue
				end

				local var43 = v1.buffs[v2] or 1
				var42.Text = ("%s: %gx"):format(var42.Name, var43)
				var42.Visible = var43 ~= 1
			end
		end

		local var45 = var30:FindFirstChild("Buy")
		if var45 then
			var17.bind(var45, function()
				onPress(v1)
			end)

		end

		var30.Parent = var21
		local var46 = var32
		local tbl3 = { def = v1, card = var30, title = var32, titleColor = var46 and var32.TextColor3 }
		var46 = var45
		var46 = var46 and var45:FindFirstChild("Cost")
		tbl3.buyText = var46
		var46 = var45
		var46 = var46 and var45:FindFirstChildWhichIsA("UIGradient", true)
		tbl3.gradient = var46
		tbl3.swatch = var38
		tbl1[v1.id] = tbl3
	end

	local var47 = var20:FindFirstChild("Scroller")
	local function showTabs()
		if not var47 then
			return
		end

		for k1, v1 in ipairs(var47:GetChildren()) do
			if not v1:IsA("GuiButton") then
				continue
			end

			local var1 = v1.Name:lower()
			if not var11.TIER_BY_ID[var1] then
				continue
			end

			local bool1 = false
			for k2, v2 in ipairs(var11.LIST) do
				if v2.shop ~= num7 then
					continue
				end

				if v2.tier ~= var1 then
					continue
				end

				bool1 = true
				break
			end

			v1.Visible = bool1
		end
	end

	showTabs()
	var28 = function()
		local var1 = var10:get("trails")
		var1 = var1 or {}
		local var2 = var10:get("equippedTrail") or ""
		local var3 = var9.floorFor(var10:get("stairsOwned") or 1, var26)
		local var7 = var11.countOwned(var1)
		for k1, v1 in pairs(tbl1) do
			local var12 = v1.def
			local bool2 = false
			if var1[k1] then
				if var2 == k1 then
					local var13 = var6
					if v1.buyText then
						v1.buyText.Text = "EQUIPPED"
					end

					if v1.gradient then
						v1.gradient.Color = var13
					end
				else
					local var14 = var8
					if v1.buyText then
						v1.buyText.Text = "EQUIP"
					end

					if v1.gradient then
						v1.gradient.Color = var14
					end
				end
			else
				if var12.special == "starter" then
					local var15 = var8
					if v1.buyText then
						v1.buyText.Text = "FREE"
					end

					if v1.gradient then
						v1.gradient.Color = var15
					end
				else
					if var12.special == "collection" then
						local var17 = var12.needs <= var7
						local var18 = if var17 then "CLAIM" else ("OWN %d/%d"):format(var7, var12.needs)
						local var19 = var17 and var8 or var5
						if v1.buyText then
							v1.buyText.Text = var18
						end

						if v1.gradient then
							v1.gradient.Color = var19
						end

						bool2 = not var17
					else
						if var12.special == "group" then
							var17 = var27
							if not var17 then
								var17 = if bool1 then "CLAIM" else "JOIN GROUP"
							end

							local var20 = var27 and var5 or var8
							if v1.buyText then
								v1.buyText.Text = var17
							end

							if v1.gradient then
								v1.gradient.Color = var20
							end
						else
							if var12.special == "wheel" then
								var17 = var5
								if v1.buyText then
									v1.buyText.Text = "PRIZE WHEEL"
								end

								if v1.gradient then
									v1.gradient.Color = var17
								end

								bool2 = true
							else
								if var12.special == "leaderboard" then
									var17 = ("TOP %d"):format(var12.rank or 10)
									local var21 = var5
									if v1.buyText then
										v1.buyText.Text = var17
									end

									if v1.gradient then
										v1.gradient.Color = var21
									end
								else
									if var12.special == "favorite" then
										var17 = var8
										if v1.buyText then
											v1.buyText.Text = "FAVORITE"
										end

										if v1.gradient then
											v1.gradient.Color = var17
										end
									else
										if var12.special == "like" then
											var17 = if bool3 then "LIKE TO CLAIM!" else "LIKE THE GAME"
											local var22 = var8
											if v1.buyText then
												v1.buyText.Text = var17
											end

											if v1.gradient then
												v1.gradient.Color = var22
											end
										else
											if var12.special == "robux" then
												var17 = if var12.productId then "ROBUX" else "COMING SOON"
												local var23 = var12.productId and var8 or var5
												if v1.buyText then
													v1.buyText.Text = var17
												end

												if v1.gradient then
													v1.gradient.Color = var23
												end

												bool2 = not var12.productId
											else
												if var12.floor then
													if var3 < var12.floor then
														var17 = ("FLOOR %d"):format(var12.floor)
														local var24 = var5
														if v1.buyText then
															v1.buyText.Text = var17
														end

														if v1.gradient then
															v1.gradient.Color = var24
														end

														bool2 = true
													else
														local var25 = var11.costText(var12)
														local var28 = var11.affordable(var12, function(arg1)
															local var1 = arg1
															return var10:get(var1)
														end) and var8 or var4

														if v1.buyText then
															v1.buyText.Text = var25
														end

														if v1.gradient then
															v1.gradient.Color = var28
														end
													end
												else
													local var29 = var11.costText(var12)
													local var30 = var11.affordable(var12, function(arg1)
														local var1 = arg1
														return var10:get(var1)
													end) and var8 or var4

													if v1.buyText then
														v1.buyText.Text = var29
													end

													if v1.gradient then
														v1.gradient.Color = var30
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end

			if v1.title then
				v1.title.TextColor3 = bool2 and num1 or v1.titleColor
			end

			if not v1.swatch then
				continue
			end

			local var31 = v1.swatch
			local var32 = NumberSequence.new
			var31.Transparency = var32(if bool2 then 0.6 else 0)
		end
	end

	local function show(arg1)
		str1 = arg1
		local num1 = 0
		for k1, v1 in pairs(tbl1) do
			local var1 = v1.card
			local bool2 = false
			if v1.def.shop == num7 then
				bool2 = true
				if arg1 ~= "all" then
					bool2 = v1.def.tier == arg1
				end
			end

			var1.Visible = bool2
			if not v1.card.Visible then
				continue
			end

			num1 = num1 + 1
		end

		num5 = math.ceil(num1 / 2)
		num6()
		var21.CanvasPosition = Vector2.zero
	end

	if var47 then
		for k3, v3 in ipairs(var47:GetChildren()) do
			if not v3:IsA("GuiButton") then
				continue
			end

			local var49 = v3.Name:lower()
			if var49 == "all" or var11.TIER_BY_ID[var49] then
				var17.bind(v3, function()
					show(var49)
				end)

			end
		end
	end

	local var50 = var1:FindFirstChild("TrailTooltip")
	local var51 = var50
	local var52 = var50
	local tbl4 = { gold = "Gold", silver = "Silver", playtime = "Playtime", glyphs = "Glyphs Opened" }
	local function describe(arg1)
		local var1 = var10:get("trails")
		local var2 = (var1 or {})[arg1.id]
		var1 = {}
		local var3
		if arg1.special == "wheel" then
			table.insert(var1, (if arg1.tier == "exotic" then "An EXOTIC" else "A rare") .. " prize on the Prize Wheel past the floor 46 door. Won there and nowhere else.")
		else
			if arg1.special == "leaderboard" then
				local var5 = arg1.rank or 10
				table.insert(var1, ("Reach the top %d on ANY leaderboard, F2P or P2W (Gold, Silver, Playtime or Glyphs Opened). It unlocks automatically and stays yours."):format(var5))
				if not var2 then
					local var6 = nil
					local var7 = nil
					for k1, v1 in pairs(tbl2) do
						if not var6 or v1 < var6 then
							var6 = v1
							var7 = k1
						end
					end

					table.insert(var1, var6 and ("Your best: #%d on %s."):format(var6, tbl4[var7] or var7) or "You are not on a leaderboard yet.")
				end
			else
				local var8
				if arg1.special == "group" then
					table.insert(var1, "Join the group to claim it. Roblox's join prompt opens right here.")
				else
					if arg1.special == "favorite" then
						table.insert(var1, "Favorite the game to claim it. Roblox's favorite prompt opens right here.")
					else
						if arg1.special == "like" then
							table.insert(var1, "Like the game to claim it: press once, like the game, then press again.")
						else
							if arg1.special == "collection" then
								local str2 = "trails"
								local var12 = arg1.needs
								table.insert(var1, ("Own %d trails to claim it. You have %d."):format(var12, var11.countOwned(var10:get(str2))))
							else
								if arg1.special == "starter" then
									table.insert(var1, "Everyone's first trail.")
								else
									if arg1.floor then
										local var14 = arg1.floor
										table.insert(var1, ("Opens on Floor %d for %s."):format(var14, var11.costText(arg1):lower()))
									end
								end
							end
						end
					end
				end
			end
		end

		local tbl1 = {}
		for k2, v2 in ipairs(var11.STATS) do
			local var15 = arg1.buffs[v2]
			if not var15 or var15 == 1 then
				continue
			end

			local var16 = v2:sub(1, 1):upper() .. v2:sub(2)
			local var17 = var15
			table.insert(tbl1, ("%s %gx"):format(var16, var17))
		end

		table.insert(var1, 0 < (#tbl1) and "Worn: " .. table.concat(tbl1, ", ") .. "." or "Cosmetic.")
		local var18 = arg1.name
		local str3 = " Trail"
		local var19 = var18 .. str3 .. (if var2 then "  (owned)" else "")
		str3 = var1
		local str4 = " "
		return var19, table.concat(str3, str4)
	end

	var51 = var51 and var50:FindFirstChild("Heading")
	var52 = var52 and var50:FindFirstChild("Body")
	local num8 = 0
	local function showTooltip(arg1)
		local var2 = arg1
		var2 = var2 and tbl1[arg1.id]
		if not var50 or (not var2 or (not var2.card.Visible or (not var20.Visible))) then
			return
		end

		var29 = arg1
		local var3, var4 = describe(arg1)
		if var51 then
			var51.Text = var3
			var51.TextColor3 = arg1.colors[1]
		end

		if var52 then
			var52.Text = var4
		end

		local var5 = var2.card
		local var6 = var1.AbsoluteSize
		local var7 = math.clamp(var5.AbsoluteSize.X * 1.6, 200, (math.min(320, var6.X - 16)))
		local var8 = math.max(1, (math.ceil(#var4 / math.max(10, (math.floor((var7 - 20) / 9)))))) * 17 + 30
		var50.AnchorPoint = Vector2.new(0.5, 0)
		var50.Size = UDim2.fromOffset(var7, var8)
		if var51 then
			var51.Size = UDim2.new(1, 0, 0, 16)
		end

		if var52 then
			var52.Position = UDim2.fromOffset(0, 20)
			var52.Size = UDim2.new(1, 0, 1, -20)
		end

		local var10 = var5.AbsolutePosition.Y - var8 - 6
		local var11 = math.clamp(var5.AbsolutePosition.X + var5.AbsoluteSize.X / 2, var7 / 2 + 8, var6.X - var7 / 2 - 8)
		if var10 < 8 then
			var10 = var5.AbsolutePosition.Y + var5.AbsoluteSize.Y + 6
		end

		local var12 = var50.Parent and (var50.Parent:IsA("GuiBase2d") and var50.Parent.AbsolutePosition) or Vector2.zero
		var50.Position = UDim2.fromOffset(var11 - var12.X, math.min(var10, var6.Y - var8 - 8) - var12.Y)
		var50.Visible = true
	end

	num2.flashTooltip = function(arg1)
		local var1 = num8 + 1
		num8 = var1
		showTooltip(arg1)
		var1 = num8
		task.delay(3, function()
			local var3 = arg1
			if num8 == var1 and (var50 and (var3 == nil or var29 == var3)) then
				var50.Visible = false
				var29 = nil
			end
		end)
	end

	local var53 = game:GetService("UserInputService")
	local var54 = nil
	var3.RenderStepped:Connect(function()
		if not var20.Visible or var53.TouchEnabled and (not var53.MouseEnabled) then
			return
		end

		local var1 = var21
		local var2 = var53:GetMouseLocation() - game:GetService("GuiService"):GetGuiInset()
		local var3 = var1.AbsolutePosition
		local var6 = var2.X
		local var7 = nil
		local var8 = nil
		local bool2 = false
		local var9 = var1.AbsoluteSize
		if var3.X <= var6 then
			var6 = var2.X
			bool2 = false
			if var6 <= var3.X + var9.X then
				var6 = var2.Y
				bool2 = false
				if var3.Y <= var6 then
					var6 = var2.Y
					bool2 = var6 <= var3.Y + var9.Y
				end
			end
		end

		if bool2 then
			for k1, v1 in pairs(tbl1) do
				local var10 = v1.card:FindFirstChild("Buy")
				if not v1.card.Visible or (not var10) then
					continue
				end

				local var11 = var10.AbsolutePosition
				local bool4 = false
				local var13 = var10.AbsoluteSize
				if var11.X <= var2.X then
					bool4 = false
					if var2.X <= var11.X + var13.X then
						bool4 = false
						if var11.Y <= var2.Y then
							bool4 = var2.Y <= var11.Y + var13.Y
						end
					end
				end

				if not bool4 then
					continue
				end

				var7 = v1.def
				var8 = 0
				break
			end

			for k2, v2 in pairs(tbl1) do
				if var7 then
					break
				end

				if not v2.card.Visible then
					continue
				end

				local var14 = v2.card
				local var15 = var14.AbsolutePosition
				local bool6 = false
				local var17 = var14.AbsoluteSize
				if var15.X <= var2.X then
					bool6 = false
					if var2.X <= var15.X + var17.X then
						bool6 = false
						if var15.Y <= var2.Y then
							bool6 = var2.Y <= var15.Y + var17.Y
						end
					end
				end

				if not bool6 then
					continue
				end

				var14 = (v2.card.AbsolutePosition + v2.card.AbsoluteSize / 2 - var2).Magnitude
				if not var8 or var14 < var8 then
					var7 = v2.def
				end

				local var18 = var14
			end
		end

		if var7 ~= var54 then
			bool2 = var54
			if var54 and (var50 and (bool2 == nil or var29 == bool2)) then
				var50.Visible = false
				var29 = nil
			end

			var54 = var7
			if var7 then
				bool2 = num8 + 1
				num8 = bool2
				showTooltip(var7)
			end
		end
	end)

	var21:GetPropertyChangedSignal("CanvasPosition"):Connect(function()
		if var50 then
			var50.Visible = false
			var29 = nil
		end
	end)

	var20:GetPropertyChangedSignal("Visible"):Connect(function()
		if not var20.Visible and var50 then
			var50.Visible = false
			var29 = nil
		end
	end)

	var13.LeaderboardUpdate.OnClientEvent:Connect(function(arg1, arg2)
		tbl2[arg1] = nil
		if arg2 and arg2[1] ~= nil then
			local tbl1 = { arg2 }
			tbl1 = tbl1 or {}
		end

		local str1 = "f2p"
		local tbl3 = {}
		for k1, v1 in ipairs({ "all", str1, "p2w" }) do
			if not arg2 then
				continue
			end

			if not arg2[v1] then
				continue
			end

			table.insert(tbl3, arg2[v1])
		end

		for k2, v2 in ipairs(tbl3) do
			for k3, v3 in ipairs(v2) do
				if v3.userId ~= var7.UserId then
					continue
				end

				if not tbl2[arg1] or v3.rank < tbl2[arg1] then
					tbl2[arg1] = v3.rank
				end
			end
		end

		if var29 and (var50 and var50.Visible) then
			showTooltip(var29)
		end
	end)

	var28()
	show("all")
	var21:GetPropertyChangedSignal("AbsoluteSize"):Connect(num6)
	local str2 = "equippedTrail"
	local str3 = "ingots"
	for k4, v4 in ipairs({
		"trails",
		str2,
		"stairsOwned",
		"gold",
		"silver",
		str3,
		"crystals",
		"wood",
		"essence",
		"starmetal",
		"doors",
	}) do

		var10:getChangedSignal(v4):Connect(var28)
	end

	local var55 = var18.bind(var20)
	num2.open = function()
		var28()
		var55.open()
	end

	num2.close = function()
		if var1:FindFirstChild("TrailTooltip") then
			var1.TrailTooltip.Visible = false
		end

		var55.close()
	end

	local var57 = var20:FindFirstChild("CloseButton")
	if var57 then
		var17.bind(var57, var55.close)
	end

	local var59 = workspace:WaitForChild(var11.VENDOR, 20)
	if var59 then
		local tbl5 = {}
		for k5, v5 in ipairs(var11.VENDORS) do
			local var61 = var59:WaitForChild(v5.booth, 10)
			if var61 and var61:IsA("Model") then
				local tbl6 = { centre = var61:GetBoundingBox().Position }
				tbl6.shop = v5.shop
				table.insert(tbl5, tbl6)
			else
				local var62 = var11.VENDOR
				local var63 = v5.booth
				local var64 = v5.shop
				warn(("[Trails] no Workspace.%s.%s - shop %d has no booth"):format(var62, var63, var64))
			end
		end

		local bool5 = false
		local bool6 = false
		task.spawn(function()
			while true do
				task.wait(0.2)
				local var1 = var7.Character
				local var2 = var1
				var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
				local bool1 = false
				local var3 = nil
				local var4
				if var2 then
					for k1, v1 in ipairs(tbl5) do
						local var5 = var2.Position - v1.centre
						if Vector2.new(var5.X, var5.Z).Magnitude > var11.VENDOR_RADIUS then
							continue
						end

						if math.abs(var5.Y) > 8 then
							continue
						end

						bool1 = true
						var3 = v1.shop
						break
					end
				end

				if bool1 and var3 ~= num7 then
					num7 = var3
					showTabs()
					show("all")
				end

				if bool1 and (not bool5) then
					bool6 = true
					num2.open()
				else
					if not bool1 and (bool5 and bool6) then
						bool6 = false
						num2.close()
					end
				end

				bool5 = bool1
			end
		end)

	else
		warn("[Trails] no Workspace." .. var11.VENDOR .. " - the menu cannot open")
	end

	local num9 = 0
	var3.Heartbeat:Connect(function(arg1)
		local var16
		local var1 = num9 + arg1
		num9 = var1
		if num9 < 0.05 then
			return
		end

		var1 = os.clock()
		num9 = 0
		local var4 = var7:GetAttribute("HidePlayers")
		local var5
		if var4 ~= nil then
			var5 = var4 == true
		else
			local var6 = var10:get("settings")
			var5 = var6
			if var5 then
				var5 = var6.hidePlayers == true
			end
		end

		var4 = var19.on("trailVfx")
		for k1, v1 in ipairs(var2:GetPlayers()) do
			local var8 = v1.Character
			local var9 = var8
			var9 = var9 and var8:FindFirstChild("HumanoidRootPart")
			if not var9 then
				continue
			end

			for k2, v2 in ipairs(var9:GetChildren()) do
				local var12 = v2:GetAttribute("TrailId")
				if not var12 then
					continue
				end

				if v1 == var7 then
					local var14 = var4
					if not var14 then
						var14 = false
						if v1 ~= var7 then
							var14 = not var5
						end
					end
				end

				if v2.Enabled ~= var16 then
					v2.Enabled = var16
				end

				local var17 = var11.BY_ID[var12]
				if not var16 or (not var17) then
					continue
				end

				if not var17.cycle then
					continue
				end

				v2.Color = var11.colorSequence(var17.colors, var1 * var17.cycle * #var17.colors)
			end
		end
	end)
end

return num2

--- ReplicatedStorage.Client.FriendBoostUI [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = game:GetService("TweenService")
local var3 = game:GetService("UserInputService")
return { init = function(_)
	local var4 = var1:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var5 = var4
	var5 = var5 and var4:FindFirstChild("FriendBoost", true)
	if not var5 then
		warn("[FriendBoost] no Main.FriendBoost - nothing to show")
		return
	end

	local var6 = var4:FindFirstChild("FriendTooltip")
	local var7 = var6
	local tbl1 = {}
	var7 = var7 and var6:FindFirstChild("Body")
	if var5:IsA("ImageLabel") or var5:IsA("ImageButton") then
		table.insert(tbl1, { inst = var5, property = "ImageTransparency", base = var5.ImageTransparency })
	end

	for k1, v1 in ipairs(var5:GetDescendants()) do
		if v1:IsA("TextLabel") then
			table.insert(tbl1, { inst = v1, property = "TextTransparency", base = v1.TextTransparency })
		else
			if v1:IsA("UIStroke") then
				table.insert(tbl1, { inst = v1, property = "Transparency", base = v1.Transparency })
			else
				if not v1:IsA("ImageLabel") then
					continue
				end

				table.insert(tbl1, { inst = v1, property = "ImageTransparency", base = v1.ImageTransparency })
			end
		end
	end

	local var8 = nil
	local function showTip(arg1)
		if not var6 then
			return
		end

		var8 = arg1
		local var1 = var4.AbsoluteSize
		local var2 = math.clamp(var1.X * 0.15, 140, 210)
		var6.Size = UDim2.fromOffset(var2, var2 * 0.36)
		local var3 = var6.Parent and (var6.Parent:IsA("GuiBase2d") and var6.Parent.AbsolutePosition) or Vector2.zero
		var6.Position = UDim2.fromOffset(math.clamp(var5.AbsolutePosition.X + var5.AbsoluteSize.X / 2, var2 / 2 + 8, var1.X - var2 / 2 - 8) - var3.X, var5.AbsolutePosition.Y - 4 - var3.Y)
		var6.Visible = true
	end

	var5.MouseEnter:Connect(function()
		if var3:GetLastInputType() ~= Enum.UserInputType.Touch then
			showTip("hover")
		end
	end)

	var5.MouseLeave:Connect(function()
		if var6 and var8 == "hover" then
			var6.Visible = false
			var8 = nil
		end
	end)

	local num1 = 0
	var5.InputBegan:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			local var1 = num1 + 1
			num1 = var1
			showTip("tap")
			var1 = num1
			task.delay(3, function()
				if num1 == var1 and (var6 and var8 == "tap") then
					var6.Visible = false
					var8 = nil
				end
			end)

		end
	end)

	local function draw(arg1)
		local var3 = if var1:GetAttribute("FriendBoost") == true then 0 else 0.6
		for k1, v1 in ipairs(tbl1) do
			local var4 = v1.base + (1 - v1.base) * var3
			if arg1 then
				local var5 = TweenInfo.new(0.35)
				var2:Create(v1.inst, var5, { [v1.property] = var4 }):Play()
			else
				v1.inst[v1.property] = var4
			end
		end

		if var7 then
			local var6 = var7
			local var8 = if var1:GetAttribute("FriendBoost") == true then "A friend is in your server - the boost is active!" else "Play with a friend in this server to activate."
			var6.Text = var8
		end
	end

	local var9 = if var1:GetAttribute("FriendBoost") == true then 0 else 0.6
	for k2, v2 in ipairs(tbl1) do
		v2.inst[v2.property] = v2.base + (1 - v2.base) * var9
	end

	if var7 then
		local var10 = if var1:GetAttribute("FriendBoost") == true then "A friend is in your server - the boost is active!" else "Play with a friend in this server to activate."
		var7.Text = var10
	end

	var1:GetAttributeChangedSignal("FriendBoost"):Connect(function()
		draw(true)
	end)
end }

--- ReplicatedStorage.Client.AutoRejoin [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = game:GetService("ReplicatedStorage")
local bool1 = false
local var2 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if bool1 then
		bool1 = false
		var2.RequestRejoin:FireServer()
	end
end)

local var3 = game:GetService("UserInputService")
local var4 = require(var1.Client.Announce)
return { init = function(_)
	local var1 = os.clock()
	local bool2 = false
	local bool3 = false
	local function touched()
		var1 = os.clock()
		bool2 = false
		bool3 = false
	end

	var3.InputBegan:Connect(touched)
	var3.InputChanged:Connect(touched)
	var3.InputEnded:Connect(touched)
	task.spawn(function()
		while true do
			task.wait(1)
			local var3 = os.clock() - var1
			if not bool2 and 585 <= var3 then
				bool2 = true
				local num1 = 255
				local num2 = 210
				local num3 = 90
				var4.show(("Inactive - rejoining in %d seconds"):format(15), Color3.fromRGB(num1, num2, num3))
			end

			if bool3 or 600 > var3 then
				continue
			end

			bool3 = true
			bool1 = true
		end
	end)
end }

--- ReplicatedStorage.Client.RebirthClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = nil
local var3 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if var2 then
		local var1 = var2
		var2 = nil
		var3.Rebirth:FireServer(var1)
	end
end)

local num1 = 160
local num2 = 35
local num3 = 35
local var4 = ColorSequence.new(Color3.fromRGB(235, 80, 70), Color3.fromRGB(num1, num2, num3))
num2 = 95
num3 = 95
local num4 = 95
local var5 = ColorSequence.new(Color3.fromRGB(150, 150, 150), Color3.fromRGB(num2, num3, num4))
num3 = 215
num4 = 150
local num5 = 30
local var6 = require(var1.Shared.RebirthConfig)
local var7 = require(var1.Packages.DataService).client
local var8 = require(var1.Shared.NumberFormat)
num1 = { gold = "GOLD", silver = "SILVER", ingots = "IRON" }
local var9 = ColorSequence.new(Color3.fromRGB(255, 215, 90), Color3.fromRGB(num3, num4, num5))
local var10 = require(var1.Client.WorldTap)
local var11 = require(var1.Client.UISound)
local var12 = require(var1.Client.Announce)
local var13 = game:GetService("Players").LocalPlayer
return { init = function(_)
	local var3 = workspace:WaitForChild("Rebirths", 20)
	if not var3 then
		warn("[Rebirth] no Workspace.Rebirths - no boards to draw")
		return
	end

	local tbl1 = {}
	for k1, v1 in ipairs(var6.LIST) do
		local var13 = var3:WaitForChild(v1.board, 10)
		local var14 = var13
		var14 = var14 and var13:FindFirstChild("UIPart")
		local var15 = var14
		var15 = var15 and var14:FindFirstChildWhichIsA("SurfaceGui")
		local var16 = var15
		var16 = var16 and var15:FindFirstChild("Upgrade")
		if var16 then
			local var17 = nil
			local var18 = nil
			for k2, v2 in ipairs(var16:GetChildren()) do
				if not v2:IsA("TextLabel") then
					continue
				end

				if v2.Name ~= "Title_TextLabel" then
					continue
				end

				if v2.Text:find(">", 1, true) then
					var17 = v2
				else
					if not v2.Text:lower():find("more", 1, true) then
						continue
					end

					var18 = v2
				end
			end

			local var19 = var16:FindFirstChild("Buy")
			local var20 = var19
			local var21 = var19
			local var22 = var19
			var22 = var22 and (var19:FindFirstChild("Hit") or Instance.new("TextButton"))
			var20 = var20 and var19:FindFirstChild("Cost")
			var21 = var21 and var19:FindFirstChildWhichIsA("UIGradient", true)
			if var22 then
				local var23 = var19:FindFirstChild("BG")
				var22.Name = "Hit"
				var22.Text = ""
				var22.BackgroundTransparency = 1
				if var23 then
					var22.AnchorPoint = var23.AnchorPoint
					var22.Position = var23.Position
					var22.Size = var23.Size
					var22.ZIndex = var23.ZIndex
					local var25 = var23:FindFirstChildWhichIsA("UICorner")
					if var25 and (not var22:FindFirstChildWhichIsA("UICorner")) then
						var25:Clone().Parent = var22
					end
				else
					var22.Size = UDim2.fromScale(1, 1)
				end

				var22.Parent = var19
			end

			local tbl2 = {
				def = v1,
				step = var17,
				bonus = var18,
				save = var16:FindFirstChild("SaveText"),
				confirmUntil = 0,
			}

			tbl2.cost = var16:FindFirstChild("Cost")
			tbl2.buyText = var20
			tbl2.gradient = var21
			local var26 = var21
			tbl2.green = var26 and var21.Color
			tbl2.hit = var22
			tbl1[k1] = tbl2
		else
			local var27 = v1.board
			warn(("[Rebirth] no Workspace.Rebirths.%s.UIPart.SurfaceGui.Upgrade"):format(var27))
		end
	end

	local function draw()
		local var1 = var7:get("rebirths") or 0
		for k1, v1 in pairs(tbl1) do
			local var2 = v1.def
			if v1.step then
				v1.step.Text = ("%d > %d"):format(k1 - 1, k1)
			end

			if v1.bonus then
				v1.bonus.Text = var6.bonusText(var2)
			end

			if v1.save then
				v1.save.Text = var6.saveText(k1)
			end

			if v1.cost then
				local var12 = var2.cost
				local var13 = k1 - 1
				local var14 = var8.price(var6.scaledCost(var12, var13))
				var12 = num1[var2.currency]
				v1.cost.Text = var14 .. " " .. (var12 or var2.currency:upper())
			end

			local var17 = nil
			local var18 = nil
			if k1 <= var1 then
				var17 = "Done"
				var18 = var9
			else
				if var1 < k1 - 1 then
					var17 = ("Rebirth %d First"):format(k1 - 1)
					var18 = var5
				else
					if os.clock() < v1.confirmUntil then
						var17 = "Confirm?"
						var18 = var4
					else
						var17 = "Rebirth"
						var18 = var6.scaledCost(var2.cost, k1 - 1) <= (var7:get(var2.currency) or 0) and v1.green or var4
					end
				end
			end

			if v1.buyText then
				v1.buyText.Text = var17
			end

			if not v1.gradient or (not var18) then
				continue
			end

			v1.gradient.Color = var18
		end
	end

	for k3, v3 in pairs(tbl1) do
		if not v3.hit then
			continue
		end

		var10.bind(v3.hit, function()
			local var3 = v3.def
			if (var7:get("rebirths") or 0) ~= k3 - 1 or (var7:get(var3.currency) or 0) < var6.scaledCost(var3.cost, k3 - 1) then
				var11.play("denied")
				return
			end

			if v3.confirmUntil <= os.clock() then
				v3.confirmUntil = os.clock() + 4
				var11.play("denied")
				draw()
				task.delay(4, draw)
				return
			end

			v3.confirmUntil = 0
			var11.play("purchase")
			var2 = k3
			if v3.buyText then
				v3.buyText.Text = "Rebirthing..."
			end
		end)

	end

	draw()
	local str1 = "gold"
	for k4, v4 in ipairs({ "rebirths", str1, "silver", "ingots" }) do
		var7:getChangedSignal(v4):Connect(draw)
	end

	local var28 = var7:get("rebirths") or 0
	var7:getChangedSignal("rebirths"):Connect(function(arg1)
		local var1 = arg1
		arg1 = var1 or (var7:get("rebirths") or 0)
		if var28 < arg1 then
			var1 = var6.LIST[arg1]
			local num1 = 255
			local num2 = 140
			local num3 = 230
			var12.show(("Rebirth %d! %s"):format(arg1, var1 and var6.bonusText(var1) or ""), Color3.fromRGB(num1, num2, num3))
		end

		var28 = arg1
	end)
end }

--- ReplicatedStorage.Client.PotionUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local var2 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		var2.BuyPotion:FireServer(v1)
	end
end)

local num1 = 160
local num2 = 35
local num3 = 35
local var3 = ColorSequence.new(Color3.fromRGB(235, 80, 70), Color3.fromRGB(num1, num2, num3))
num2 = 95
num3 = 95
local num4 = 95
local var4 = ColorSequence.new(Color3.fromRGB(150, 150, 150), Color3.fromRGB(num2, num3, num4))
local var5 = game:GetService("UserInputService")
local var6 = require(var1.Packages.DataService).client
local var7 = require(var1.Shared.GlyphConfig)
local var8 = require(game:GetService("ReplicatedStorage").Client.Press)
local var9 = require(var1.Client.MenuEffects)
local var10 = require(var1.Shared.PotionConfig)
local var11 = require(var1.Client.UISound)
local var12 = game:GetService("Players").LocalPlayer
num3 = function()
	return workspace:GetServerTimeNow()
end

local tbl2 = { gold = "Gold", silver = "Silver", ingots = "Iron", crystals = "Crystals" }
num1 = { 15, 58, 113 }
return { init = function(_)
	local var2 = var12:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	if not var2 then
		return
	end

	local var13 = var2:FindFirstChild("Potions")
	local var14 = var13
	local num2 = 1
	var14 = var14 and var13:FindFirstChild("Items", true)
	local tbl3 = {}
	local var15
	local var16
	local var17
	local var18
	if var14 then
		for k1, v1 in ipairs(var10.LIST) do
			local bool2 = false
			if v1.shop == 1 then
				bool2 = var14:FindFirstChild(v1.item)
			end

			if bool2 then
				local var19 = nil
				local var20 = nil
				var18 = nil
				for k2, v2 in ipairs(bool2:GetChildren()) do
					var16 = "TextLabel"
					if not v2:IsA(var16) then
						continue
					end

					if v2.Name ~= "Title" then
						continue
					end

					local var21 = v2.Text:lower()
					if var21:find("potion", 1, true) then
						var19 = v2
					else
						if var21:find("x ", 1, true) then
							if not var21:find("%d+[kmbt]? ") then
								var20 = v2
							else
								var18 = v2
							end
						else
							var18 = v2
						end
					end
				end

				var15 = bool2:FindFirstChild("Buy")
				local var22 = var15
				var22 = var22 and var15:FindFirstChild("Cost")
				var17 = { item = v1.item, name = var19, effect = var20, cost = var18, buyText = var22 }
				var22 = var15
				var22 = var22 and var15:FindFirstChildWhichIsA("UIGradient", true)
				var17.gradient = var22
				var22 = var17.gradient
				var17.green = var22 and var17.gradient.Color
				if var15 and var15:IsA("GuiButton") then
					var8.bind(var15, function()
						local var1 = var17.item
						for k1, v1 in ipairs(var10.LIST) do
							if v1.item ~= var1 then
								continue
							end

							if v1.shop ~= num2 then
								continue
							end

							local var2 = v1
						end

						local var4 = nil
						if not var4 then
							return
						end

						if not (var6:get({ "doors", var4.door }) == true) or ((var6:get(var4.currency) or 0) < var4.cost or (not var10.canAdd(var6:get("potions"), var4.id, var4.duration, num3()))) then
							var11.play("denied")
							return
						end

						var11.play("purchase")
						table.insert(tbl1, var4.id)
					end)

				end

				tbl3[v1.item] = var17
			else
				if v1.shop ~= 1 then
					continue
				end

				var17 = v1.item
				var18 = "[Potions] no Main.Potions card named "
				var15 = tostring(var17)
				warn(var18 .. var15)
			end
		end
	end

	local function drawCards()
		local var1 = var6:get("potions")
		for k1, v1 in pairs(tbl3) do
			local var2 = v1.item
			for k2, v2 in ipairs(var10.LIST) do
				if v2.item ~= var2 then
					continue
				end

				if v2.shop ~= num2 then
					continue
				end

				local var5 = v2
			end

			local var8 = nil
			if not var8 then
				continue
			end

			if v1.name then
				v1.name.Text = var8.name
			end

			if v1.effect then
				v1.effect.Text = ("%gx %s"):format(var8.multiplier, var8.stat:sub(1, 1):upper() .. var8.stat:sub(2))
			end

			if v1.cost then
				local var9 = tbl2[var8.currency]
				v1.cost.Text = var7.costText(var8.cost) .. " " .. (var9 or var8.currency)
			end

			local var13 = var10.ownTime(var1, var8.id, num3())
			local var14 = nil
			local var15 = nil
			local var16
			if not (var6:get({ "doors", var8.door }) == true) then
				var14 = "Locked"
				var15 = var4
			else
				var16 = var1
				if not var10.canAdd(var16, var8.id, var8.duration, num3()) then
					var14 = "Max"
					var15 = var4
				else
					if (var6:get(var8.currency) or 0) < var8.cost then
						var16 = 0
						var14 = if var16 < var13 then "Add" else "Buy"
						var15 = var3
					else
						var16 = 0
						var14 = if var16 < var13 then "Add" else "Buy"
						var15 = v1.green
					end
				end
			end

			if v1.buyText then
				v1.buyText.Text = var14
			end

			if not v1.gradient or (not var15) then
				continue
			end

			v1.gradient.Color = var15
		end
	end

	if var13 then
		local var27 = var13:FindFirstChild("CloseButton")
		local var28 = var9.bind(var13)
		if var27 then
			var8.bind(var27, var28.close)
		end

		local var29 = workspace:WaitForChild("Merchants", 20)
		local tbl4 = {}
		for k3, v3 in pairs(var10.SHOPS) do
			var17 = var29
			var17 = var17 and var29:WaitForChild(v3.booth, 10)
			if var17 then
				table.insert(tbl4, { shop = k3, centre = var17:GetBoundingBox().Position })
			else
				var16 = k3
				warn("[Potions] no Workspace.Merchants." .. v3.booth .. " - shop " .. var16 .. " cannot open")
			end
		end

		local bool3 = false
		local bool4 = false
		task.spawn(function()
			while true do
				task.wait(0.2)
				local var1 = var12.Character
				var1 = var1 and var12.Character:FindFirstChild("HumanoidRootPart")
				local bool1 = false
				local var2 = nil
				local var3
				if var1 then
					for k1, v1 in ipairs(tbl4) do
						local var4 = var1.Position - v1.centre
						if Vector2.new(var4.X, var4.Z).Magnitude > var10.VENDOR_RADIUS then
							continue
						end

						if math.abs(var4.Y) > 8 then
							continue
						end

						bool1 = true
						var2 = v1.shop
						break
					end
				end

				if bool1 and (not bool3) then
					num2 = var2
					bool4 = true
					drawCards()
					var28.open()
				else
					if not bool1 and (bool3 and bool4) then
						bool4 = false
						var28.close()
					end
				end

				bool3 = bool1
			end
		end)

	end

	local var30 = var2:FindFirstChild("PotionTooltip")
	local var31 = var30
	local var32 = var30
	local var34 = var2:FindFirstChild("BoostList")
	var31 = var31 and var30:FindFirstChild("Heading")
	var32 = var32 and var30:FindFirstChild("Body")
	local tbl5 = {}
	if var34 then
		for k4, v4 in ipairs(var10.LIST) do
			local var36 = var34:FindFirstChild(v4.icon)
			if var36 then
				local tbl7 = {}
				local function remember(arg1, arg2)
					table.insert(tbl7, { inst = arg1, property = arg2, base = arg1[arg2] })
				end

				if var36:IsA("ImageLabel") or var36:IsA("ImageButton") then
					table.insert(tbl7, { inst = var36, property = "ImageTransparency", base = var36.ImageTransparency })
				end

				for k5, v5 in ipairs(var36:GetDescendants()) do
					if v5:IsA("TextLabel") then
						table.insert(tbl7, { inst = v5, property = "TextTransparency", base = v5.TextTransparency })
					else
						if not v5:IsA("UIStroke") then
							continue
						end

						table.insert(tbl7, { inst = v5, property = "Transparency", base = v5.Transparency })
					end
				end

				var16 = var36:FindFirstChild("Timer")
				tbl5[v4.id] = { def = v4, icon = var36, timer = var16, pieces = tbl7 }
			else
				warn("[Potions] no Main.BoostList." .. v4.icon)
			end
		end
	end

	local var37 = nil
	local function describe(arg1)
		local var1 = var6:get("potions")
		local var5 = var10.ownTime(var1, arg1.id, num3())
		local var7 = ("%gx %s"):format(arg1.multiplier, arg1.stat:sub(1, 1):upper() .. arg1.stat:sub(2))
		if var10.paused(var1, arg1.id, num3()) then
			local var8 = var5
			return var7 .. (" - %s saved, paused while a stronger potion runs."):format(var10.timeText(var8))
		end

		if 0 < var5 then
			local var11 = var5
			return var7 .. (" - %s left."):format(var10.timeText(var11))
		end

		return var7 .. " for " .. var10.timeText(arg1.duration) .. (arg1.shop and (". Buy one at the potion vendor on floor %d."):format(num1[arg1.shop] or 15) or ". Win one on the Prize Wheel past floor 46.")
	end

	local function placeTip(arg1)
		if not var30 then
			return
		end

		local var1 = var2.AbsoluteSize
		local var3 = math.clamp(var1.X * 0.15, 140, 210)
		var30.Size = UDim2.fromOffset(var3, var3 * 0.36)
		local var4 = arg1.icon
		local var5 = var30.Parent and (var30.Parent:IsA("GuiBase2d") and var30.Parent.AbsolutePosition) or Vector2.zero
		var30.Position = UDim2.fromOffset(math.clamp(var4.AbsolutePosition.X + var4.AbsoluteSize.X / 2, var3 / 2 + 8, var1.X - var3 / 2 - 8) - var5.X, var4.AbsolutePosition.Y - 4 - var5.Y)
	end

	for k6, v6 in pairs(tbl5) do
		local num4 = 0
		v6.icon.MouseEnter:Connect(function()
			if var5:GetLastInputType() == Enum.UserInputType.Touch then
				return
			end

			local var1 = num4 + 1
			num4 = var1
			var1 = v6
			if not var30 then
				return
			end

			var37 = var1
			if var31 then
				var31.Text = var1.def.name
			end

			if var32 then
				var32.Text = describe(var1.def)
			end

			placeTip(var1)
			var30.Visible = true
		end)

		v6.icon.MouseLeave:Connect(function()
			if var5:GetLastInputType() == Enum.UserInputType.Touch then
				return
			end

			local var2 = v6
			if var30 and (var2 == nil or var37 == var2) then
				var30.Visible = false
				var37 = nil
			end
		end)

		v6.icon.InputBegan:Connect(function(arg1)
			if arg1.UserInputType == Enum.UserInputType.Touch then
				local var1 = num4 + 1
				num4 = var1
				var1 = num4
				local var2 = v6
			if not not var30 then
					var37 = var2
					if var31 then
						var31.Text = var2.def.name
					end

					if var32 then
						var32.Text = describe(var2.def)
					end

					placeTip(var2)
					var30.Visible = true
				end

				task.delay(3, function()
					local var3 = v6
					if num4 == var1 and (var30 and (var3 == nil or var37 == var3)) then
						var30.Visible = false
						var37 = nil
					end
				end)

			end
		end)

	end

	drawCards()
	local function drawIcons()
		local var1 = var6:get("potions")
		local var2 = workspace:GetServerTimeNow()
		for k1, v1 in pairs(tbl5) do
			local var3 = var10.ownTime(var1, v1.def.id, var2)
			local var4 = 0 < var3
			if v1.timer then
				local var5 = var4 and var10.timeText(var3) or ""
				v1.timer.Text = var5
			end

			local var7 = var4
			local var8 = var4
			var8 = var8 and (not (var7 and var10.paused(var1, v1.def.id, var2)))
			if var8 then
				if not v1.icon.Visible and var12:GetAttribute("WheelSpinning") == true then
					var8 = false
				end
			end

			if v1.icon.Visible == var8 then
				continue
			end

			v1.icon.Visible = var8
			if var8 or (not var30) then
				continue
			end

			if v1 == nil or var37 == v1 then
				var30.Visible = false
				var37 = nil
			end
		end

		if var37 and var32 then
			var32.Text = describe(var37.def)
		end
	end

	drawIcons()
	var12:GetAttributeChangedSignal("WheelSpinning"):Connect(drawIcons)
	local str1 = "doors"
	for k7, v7 in ipairs({ "potions", str1, "gold", "silver", "ingots", "crystals" }) do
		var6:getChangedSignal(v7):Connect(function()
			drawCards()
			drawIcons()
		end)

	end

	task.spawn(function()
		while true do
			task.wait(1)
			drawIcons()
			drawCards()
		end
	end)
end }

--- ReplicatedStorage.Client.TutorialUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local var3 = require(var1.Packages.DataService).client
local var4 = require(var1.Shared.TutorialConfig)
local var5 = require(var1.Shared.RebirthConfig)
local var6 = game:GetService("Players").LocalPlayer
local var7 = Color3.fromRGB(255, 214, 64)
local var8 = Font.new("rbxasset://fonts/families/PressStart2P.json")
local tbl1 = {
	[Enum.NormalId.Front] = {
		right = Vector3.new(-1, 0, 0),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(0, 0, -1),
	},
	[Enum.NormalId.Back] = { right = Vector3.new(1, 0, 0), up = Vector3.new(0, 1, 0), normal = Vector3.new(0, 0, 1) },
	[Enum.NormalId.Left] = {
		right = Vector3.new(0, 0, 1),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(-1, 0, 0),
	},
	[Enum.NormalId.Right] = {
		right = Vector3.new(0, 0, -1),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(1, 0, 0),
	},
	[Enum.NormalId.Top] = {
		right = Vector3.new(1, 0, 0),
		up = Vector3.new(0, 0, -1),
		normal = Vector3.new(0, 1, 0),
	},
	[Enum.NormalId.Bottom] = {
		right = Vector3.new(1, 0, 0),
		up = Vector3.new(0, 0, 1),
		normal = Vector3.new(0, -1, 0),
	},
}

local function buttonPointOf(arg1, arg2)
	local var1 = arg1:FindFirstChildWhichIsA("SurfaceGui")
	var1 = var1 or arg1:FindFirstChildWhichIsA("SurfaceGui", true)
	local var2 = var1
	var2 = var2 and var1:FindFirstChildWhichIsA("GuiObject")
	for k1, v1 in ipairs(arg2) do
		local var3 = var2
		var2 = var3 and var2:FindFirstChild(v1)
	end

	local var4 = var1
	local var5 = var1
	var4 = var4 and (var1.Adornee or var1.Parent)
	var5 = var5 and tbl1[var1.Face]
	if not var2 or (not var2:IsA("GuiObject") or (not var4 or (not var4:IsA("BasePart") or (not var5)))) then
		return nil
	end

	local var6 = var1.AbsoluteSize
	if var6.X <= 0 or var6.Y <= 0 then
		return nil
	end

	local var7 = var4.Size
	local var8 = var2.AbsolutePosition + var2.AbsoluteSize / 2
	local var9 = math.abs((var5.up:Dot(var7)))
	return var4.CFrame * (var5.right * ((var8.X / var6.X - 0.5) * math.abs((var5.right:Dot(var7)))) + var5.up * ((0.5 - var8.Y / var6.Y) * var9) + var5.normal * (math.abs((var5.normal:Dot(var7))) / 2)) + var4.CFrame:VectorToWorldSpace(var5.up) * (var2.AbsoluteSize.Y * (var9 / var6.Y) / 2 + 1.8) + var4.CFrame:VectorToWorldSpace(var5.normal) * 0.1
end

local function read(arg1)
	local var1 = arg1
	return var3:get(var1)
end

return { init = function(_)
	var3:waitForData()
	local var1 = Instance.new("Part")
	var1.Name = "TutorialArrow"
	var1.Size = Vector3.new(0.2, 0.2, 0.2)
	var1.Transparency = 1
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.CastShadow = false
	var1.Parent = workspace
	local var9 = Instance.new("Attachment")
	var9.Parent = var1
	local var10 = Instance.new("BillboardGui")
	var10.Name = "TutorialHint"
	var10.Size = UDim2.fromOffset(190, 108)
	var10.AlwaysOnTop = true
	var10.LightInfluence = 0
	var10.MaxDistance = 500
	var10.Adornee = var1
	var10.Parent = var1
	local var11 = Instance.new("TextLabel")
	var11.Name = "Hint"
	var11.BackgroundTransparency = 1
	var11.Size = UDim2.fromScale(1, 0.45)
	var11.Position = UDim2.fromScale(0, -0.5)
	var11.FontFace = var8
	var11.TextScaled = true
	var11.TextColor3 = Color3.new(1, 1, 1)
	var11.Text = ""
	var11.Parent = var10
	local var12 = Instance.new("UIStroke")
	var12.Thickness = 3
	var12.Color = Color3.new(0, 0, 0)
	var12.Parent = var11
	local var13 = Instance.new("TextLabel")
	var13.Name = "Arrow"
	var13.BackgroundTransparency = 1
	var13.Size = UDim2.fromScale(1, 1)
	var13.Position = UDim2.fromScale(0, 0)
	var13.Font = Enum.Font.GothamBlack
	var13.TextScaled = true
	var13.TextColor3 = var7
	var13.Text = "\226\150\188"
	var13.Parent = var10
	local var14 = Instance.new("UIStroke")
	var14.Thickness = 4
	var14.Color = Color3.new(0, 0, 0)
	var14.Parent = var13
	local var15 = Instance.new("Beam")
	var15.Name = "TutorialBeam"
	var15.Color = ColorSequence.new(var7)
	var15.LightEmission = 1
	var15.LightInfluence = 0
	var15.FaceCamera = true
	var15.Segments = 16
	var15.Width0 = 0.35
	var15.Width1 = 1.1
	local num1 = 1
	local num2 = 0.15
	var15.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.9),
		NumberSequenceKeypoint.new(0.35, 0.35),
		NumberSequenceKeypoint.new(num1, num2),
	})

	var15.CurveSize0 = 0
	var15.CurveSize1 = 0
	var15.Attachment1 = var9
	var15.Parent = var1
	var10.Enabled = false
	var15.Enabled = false
	local var16 = nil
	local var17 = var6.Character
	local var18 = var17
	var18 = var18 and var17:WaitForChild("HumanoidRootPart", 10)
	local function follow(arg1)
		local var1 = arg1
		var1 = var1 and arg1:WaitForChild("HumanoidRootPart", 10)
		if not var1 then
			return
		end

		var16 = Instance.new("Attachment")
		var16.Name = "TutorialBeamStart"
		var16.Position = Vector3.new(0, 1.5, 0)
		var16.Parent = var1
		var15.Attachment0 = var16
	end

	if not not var18 then
		var16 = Instance.new("Attachment")
		var16.Name = "TutorialBeamStart"
		var16.Position = Vector3.new(0, 1.5, 0)
		var16.Parent = var18
		var15.Attachment0 = var16
	end

	var6.CharacterAdded:Connect(follow)
	num2 = 0
	var17 = 0.2
	local var19 = nil
	local tbl1 = {}
	num1 = nil
	var18 = nil
	var2.Heartbeat:Connect(function(arg1)
		local var2 = num2 + arg1
		num2 = var2
		var2 = var17 + arg1
		var17 = var2
		if 0.2 <= var17 then
			var17 = 0
			var2 = nil
			if var3:get({ "tutorial", "done" }) == true then
				if 0 < (var3:get("rebirths") or 0) then
					var10.Enabled = false
					var15.Enabled = false
					var19:Disconnect()
					var1:Destroy()
					return
				end

				local var7 = os.clock()
				for k1, v1 in ipairs(var4.NUDGES) do
					if v1.ready(read, var5) then
						tbl1[v1.id] = tbl1[v1.id] or var7
						if var2 then
							continue
						end

						if var4.STUCK_SECONDS > var7 - tbl1[v1.id] then
							continue
						end

						var2 = v1
					else
						tbl1[v1.id] = nil
					end
				end
			else
				local tbl2 = { "tutorial", "step" }
				var2 = var4.stepAt(read(tbl2))
			end

			num1 = var2
			local var8 = var2 and var4.targetOf(var2, read) or nil
			var18 = var8
			if var18 then
				var11.Text = var2.hint
				var10.Enabled = true
			else
				var10.Enabled = false
				var15.Enabled = false
			end
		end

		if not var18 or (not var18.Parent or (not num1)) then
			var15.Enabled = false
			return
		end

		local var9 = num1
		local var14 = var18
		local var20 = buttonPointOf(var14, var9.target.gui)
		var2 = var1
		local var21
		if var9.target.gui and var20 then
			var21 = var20
		else
			if var14:IsA("BasePart") then
				var21 = var14.Position + Vector3.new(0, var14.Size.Y / 2 + 3, 0)
			else
				local var22, var23 = var14:GetBoundingBox()
				var21 = var22.Position + Vector3.new(0, var23.Y / 2 + 3, 0)
			end
		end

		var2.Position = var21
		var10.StudsOffsetWorldSpace = Vector3.new(0, math.sin(num2 * 3.2) * 1.1, 0)
		var2 = var6.Character
		var2 = var2 and var6.Character:FindFirstChild("HumanoidRootPart")
		var21 = var15
		var14 = false
		if var2 ~= nil then
			var14 = false
			if var16 ~= nil then
				var14 = 16 < (var2.Position - var1.Position).Magnitude
			end
		end

		var21.Enabled = var14
	end)
end }

--- ReplicatedStorage.Client.ClickTarget [ModuleScript]
-- y u r i

return { over = function(arg1)
	if not arg1 or arg1:IsA("GuiButton") then
		return arg1
	end

	local var1 = arg1:FindFirstChild("Hit")
	var1 = var1 or Instance.new("TextButton")
	var1.Name = "Hit"
	var1.Text = ""
	var1.BackgroundTransparency = 1
	local var3 = arg1:FindFirstChild("BG")
	if var3 and var3:IsA("GuiObject") then
		var1.AnchorPoint = var3.AnchorPoint
		var1.Position = var3.Position
		var1.Size = var3.Size
		var1.ZIndex = var3.ZIndex
		local var5 = var3:FindFirstChildWhichIsA("UICorner")
		if var5 and (not var1:FindFirstChildWhichIsA("UICorner")) then
			var5:Clone().Parent = var1
		end
	else
		var1.Size = UDim2.fromScale(1, 1)
		var1.ZIndex = arg1.ZIndex
	end

	var1.Parent = arg1
	return var1
end }

--- ReplicatedStorage.Client.AdsUI [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.PassConfig)
local var3 = game:GetService("RunService")
local var4 = require(var1.Client.PassState)
local var5 = require(var1.Client.PriceCache)
local var6 = require(var1.Client.ClickTarget)
local var7 = require(var1.Client.WorldTap)
local var8 = require(var1.Client.ShopUI)
return { init = function(_)
	local var9 = workspace:FindFirstChild("Ads")
	if not var9 then
		return
	end

	local tbl1 = {}
	for k1, v1 in ipairs(var2.LIST) do
		if not v1.card then
			continue
		end

		tbl1[v1.card] = v1
	end

	local tbl2 = {}
	for k2, v2 in ipairs(var9:GetDescendants()) do
		local var10 = v2:IsA("TextLabel")
		if not var10 then
			continue
		end

		var10 = v2.Name
		if var10 ~= "Title" then
			continue
		end

		var10 = v2:FindFirstAncestorWhichIsA("LayerCollector") ~= nil
		if not var10 then
			continue
		end

		var10 = tbl1[v2.Text]
		if var10 then
			local var12 = v2.Parent
			local var13 = var12:FindFirstChild("Buy")
			local var14 = var13 and var13:FindFirstChild("Cost") or nil
			local tbl3 = { def = var10, buy = var13, cost = var14, price = nil }
			tbl3.gift = var12:FindFirstChild("Gift")
			table.insert(tbl2, tbl3)
		else
			if not var3:IsStudio() then
				continue
			end

			local var15 = v2.Parent:GetFullName()
			local var16 = v2.Text
			warn(("[Ads] %s is titled %q, which is not a pass in PassConfig - that sign is inert"):format(var15, var16))
		end
	end

	local function draw()
		for k1, v1 in ipairs(tbl2) do
			if not v1.cost then
				continue
			end

			local var1 = v1.cost
			local var3 = if var2.owns(var4.owned, v1.def.id) then "Owned" else v1.price or "R$ -"
			var1.Text = var3
		end
	end

	for k3, v3 in ipairs(tbl2) do
		if v3.cost then
			v3.cost.Text = "R$ -"
		end

		var5.fetch(v3.def.productId, Enum.InfoType.Product, function(arg1)
			local var1 = arg1 and var5.text(arg1) or "R$ -"
			v3.price = var1
			draw()
		end)

		local var17 = v3.gift
		for k4, v4 in ipairs({ v3.buy, var17 }) do
			local var18 = v4
			var18 = var18 and var6.over(v4)
			if not var18 then
				continue
			end

			var7.bind(var18, function()
				if var8.open then
					var8.open()
					return
				end

				if var3:IsStudio() then
					warn("[Ads] the shop never opened for business - see the [Shop] warning above")
				end
			end)

		end
	end

	var4.onChanged(draw)
	draw()
end }

--- ReplicatedStorage.Client.MobileLayout [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = game:GetService("UserInputService")
return {
	init = function(arg1)
		local var4 = var1:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
		if not var4 then
			return
		end

		var4.DisplayOrder = 50
		arg1:_fitCounters(var4)
		if not var2.TouchEnabled then
			return
		end

		local var6 = var4:FindFirstChild("Menu")
		if not var6 or (not var6:IsA("GuiObject")) then
			return
		end

		local var7 = var6.Position
		var6.Position = UDim2.new(var7.X.Scale, var7.X.Offset, var7.Y.Scale - 0.02, var7.Y.Offset)
	end,
	_fitCounters = function(_, arg2)
		local var3 = arg2:FindFirstChild("CurrencyHuds")
		if not var3 or (not var3:IsA("GuiObject")) then
			return
		end

		local var5 = var3:FindFirstChildWhichIsA("UIScale")
		if not var5 then
			var5 = Instance.new("UIScale")
			var5.Name = "DeviceFit"
			var5.Parent = var3
		end

		if var3.AnchorPoint.Y ~= 1 then
			local var6 = Vector2.new(var3.AnchorPoint.X, 1)
			var3.AnchorPoint = var6
			local var7 = var3.Position
			local var8 = var3.Size
			var3.Position = UDim2.new(var7.X.Scale, var7.X.Offset, var7.Y.Scale + var8.Y.Scale, var7.Y.Offset + var8.Y.Offset)
		end

		var5.Scale = if var2.TouchEnabled then 1 else 1
	end,
}

--- ReplicatedStorage.Client.NoReset [ModuleScript]
-- y u r i

local var1 = game:GetService("StarterGui")
return { init = function(_)
	task.spawn(function()
		for i1 = 1, 20 do
			if pcall(function()
				var1:SetCore("ResetButtonCallback", false)
			end) then

				return
			end

			task.wait(0.25)
		end

		warn("[NoReset] the CoreGui never accepted ResetButtonCallback - the reset button is still live")
	end)
end }

--- ReplicatedStorage.Client.SoundChannels [ModuleScript]
-- y u r i

local var1 = game:GetService("SoundService")
return { group = function(arg1)
	local var3 = var1:FindFirstChild(arg1)
	if var3 and var3:IsA("SoundGroup") then
		return var3
	end

	local var4 = var3 and arg1 .. "Volume" or arg1
	local var6 = var1:FindFirstChild(var4)
	if var6 and var6:IsA("SoundGroup") then
		return var6
	end

	var6 = Instance.new("SoundGroup")
	var6.Name = var4
	var6.Parent = var1
	return var6
end }

--- ReplicatedStorage.Client.MusicPlayer [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = game:GetService("SoundService")
local var2 = require(game:GetService("ReplicatedStorage").Client.SoundChannels)
return { init = function(_)
	local var4 = var1:FindFirstChild("Music")
	if not var4 then
		return
	end

	local tbl1 = {}
	for k1, v1 in ipairs(var4:GetChildren()) do
		local var5 = v1:IsA("Sound")
		if not var5 then
			continue
		end

		table.insert(tbl1, v1)
	end

	if #tbl1 == 0 then
		local str2 = "Music"
		warn(("[Music] SoundService.%s holds no Sounds - nothing to play"):format(str2))
		return
	end

	local var6 = var2.group("Music")
	for k2, v2 in ipairs(tbl1) do
		v2.SoundGroup = var6
		v2.Looped = false
	end

	local tbl2 = {}
	local var7 = Random.new()
	local var8 = nil
	local bool1 = false
	local function shuffle()
		tbl2 = table.clone(tbl1)
		for i1 = #tbl2, 2, -1 do
			local var1 = var7:NextInteger(1, i1)
			tbl2[i1] = tbl2[var1]
			tbl2[var1] = tbl2[i1]
		end

		if var8 and (1 < (#tbl2) and tbl2[1] == var8) then
			tbl2[1] = tbl2[2]
			tbl2[2] = tbl2[1]
		end
	end

	local num1 = 0
	for k3, v3 in ipairs(tbl1) do
		v3.Ended:Connect(function()
			if var8 == v3 then
				if bool1 then
					return
				end

				bool1 = true
				task.delay(2, function()
					if bool1 then
						bool1 = false
						if #tbl2 == 0 then
							shuffle()
						end

						local var2 = table.remove(tbl2, 1)
						if not var2 then
							return
						end

						var8 = var2
						local var3 = os.clock()
						num1 = var3
						var2.TimePosition = 0
						var2:Play()
					end
				end)

			end
		end)

	end

	bool1 = false
	if #tbl2 == 0 then
		shuffle()
	end

	local var10 = table.remove(tbl2, 1)
	if not not var10 then
		num1 = os.clock()
		var10.TimePosition = 0
		var10:Play()
		var8 = var10
	end

	task.spawn(function()
		while true do
			task.wait(1)
			if bool1 or (not var8) then
				continue
			end

			if var8.IsPlaying then
				continue
			end

			if 5 >= os.clock() - num1 then
				continue
			end

		if not bool1 then
				bool1 = true
				task.delay(0, function()
					if bool1 then
						bool1 = false
						if #tbl2 == 0 then
							shuffle()
						end

						local var2 = table.remove(tbl2, 1)
						if not var2 then
							return
						end

						var8 = var2
						local var3 = os.clock()
						num1 = var3
						var2.TimePosition = 0
						var2:Play()
					end
				end)

			end
		end
	end)
end }

--- ReplicatedStorage.Client.WorldTap [ModuleScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = require(game:GetService("ReplicatedStorage").Client.UISound)
local var3 = require(game:GetService("ReplicatedStorage").Client.Press)
local var4 = game:GetService("Players").LocalPlayer
local tbl1 = {}
local var5 = setmetatable({}, { __mode = "k" })
local var6 = setmetatable({}, { __mode = "k" })
local tbl2 = {
	[Enum.NormalId.Front] = {
		right = Vector3.new(-1, 0, 0),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(0, 0, -1),
	},
	[Enum.NormalId.Back] = { right = Vector3.new(1, 0, 0), up = Vector3.new(0, 1, 0), normal = Vector3.new(0, 0, 1) },
	[Enum.NormalId.Left] = {
		right = Vector3.new(0, 0, 1),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(-1, 0, 0),
	},
	[Enum.NormalId.Right] = {
		right = Vector3.new(0, 0, -1),
		up = Vector3.new(0, 1, 0),
		normal = Vector3.new(1, 0, 0),
	},
	[Enum.NormalId.Top] = {
		right = Vector3.new(1, 0, 0),
		up = Vector3.new(0, 0, -1),
		normal = Vector3.new(0, 1, 0),
	},
	[Enum.NormalId.Bottom] = {
		right = Vector3.new(1, 0, 0),
		up = Vector3.new(0, 0, 1),
		normal = Vector3.new(0, -1, 0),
	},
}

local tbl3 = { TouchGui = true, ControlGui = true }
local function onHud(arg1)
	local var2 = var4:FindFirstChild("PlayerGui")
	if not var2 then
		return false
	end

	local var3 = arg1.X
	local var5 = arg1.Y
	for k1, v1 in ipairs(var2:GetGuiObjectsAtPosition(var3, var5)) do
		local var6 = v1:FindFirstAncestorWhichIsA("LayerCollector")
		if not var6 then
			continue
		end

		if not var6:IsA("ScreenGui") then
			continue
		end

		if not var6.Enabled then
			continue
		end

		if tbl3[var6.Name] then
			continue
		end

		if not v1:IsA("GuiButton") then
			if not v1.Active then
				continue
			end
		end

		local var7 = v1
		local bool1 = true
		while not var7 and var7 == var6 and var7:IsA("GuiObject") and (not var7.Visible) do
		end

		if not bool1 then
			continue
		end

		return true
	end

	return false
end

local function shown(arg1, arg2)
	if not arg2.Enabled then
		return false
	end

	local var1 = arg1
	while not var1 and var1 == arg2 and var1:IsA("GuiObject") and (not var1.Visible) do
	end

	return var1 == arg2
end

local function canvasPoint(arg1, arg2, arg3)
	local var3 = tbl2[arg1.Face]
	local var4 = arg1.AbsoluteSize
	if not var3 or (var4.X <= 0 or var4.Y <= 0) then
		return nil
	end

	local var5 = arg2.CFrame:PointToObjectSpace(arg3)
	local var6 = arg2.Size
	if var5:Dot(var3.normal) < math.abs((var3.normal:Dot(var6))) / 2 - 0.3 then
		return nil
	end

	local var7 = (var5:Dot(var3.right) / math.abs((var3.right:Dot(var6))) + 0.5) * var4.X
	local var8 = (0.5 - var5:Dot(var3.up) / math.abs((var3.up:Dot(var6)))) * var4.Y
	return Vector2.new(var7, var8)
end

local var7 = setmetatable({}, { __mode = "k" })
var1.InputBegan:Connect(function(arg1)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		local tbl1 = { at = os.clock() }
		tbl1.position = Vector2.new(arg1.Position.X, arg1.Position.Y)
		var7[arg1] = tbl1
	end
end)

local function tapAt(arg1)
	if onHud(arg1) then
		return
	end

	local var3 = workspace.CurrentCamera
	if not var3 then
		return
	end

	local var7 = var3:ScreenPointToRay(arg1.X, arg1.Y)
	local var8 = RaycastParams.new()
	var8.FilterType = Enum.RaycastFilterType.Exclude
	if var4.Character then
		local tbl2 = { var4.Character }
		tbl2 = tbl2 or {}
	end

	var8.FilterDescendantsInstances = {}
	local var10 = workspace:Raycast(var7.Origin, var7.Direction * 1000, var8)
	if not var10 then
		return
	end

	local var11 = nil
	local var12 = nil
	for k1, v1 in ipairs(tbl1) do
		local var13 = v1.button
		local var14 = var13.Parent
		var14 = var14 and var13:FindFirstAncestorWhichIsA("SurfaceGui")
		local var15 = var14
		var15 = var15 and (var14.Adornee or var14.Parent)
		if var15 ~= var10.Instance then
			continue
		end

		if not shown(var13, var14) then
			continue
		end

		local var19 = canvasPoint(var14, var15, var10.Position)
		local var20 = var13.AbsolutePosition
		local var21 = var13.AbsoluteSize
		local var22 = var21.X * var21.Y
		if (var14.MaxDistance <= 0 or (var3.CFrame.Position - var10.Position).Magnitude <= var14.MaxDistance) and var19 and (var20.X <= var19.X and (var19.X <= var20.X + var21.X and (var20.Y <= var19.Y and (var19.Y <= var20.Y + var21.Y and (not var12 or var22 < var12))))) then
			var11 = v1
		end

		local var23 = var22
	end

	if not var11 then
		return
	end

	local var25 = os.clock()
	if var6[var11.button] and var25 - var6[var11.button] < 0.60000000000000009 then
		return
	end

	var5[var11.button] = var25
	var2.play("click")
	var11.callback()
end

var1.InputEnded:Connect(function(arg1)
	if arg1.UserInputType ~= Enum.UserInputType.Touch then
		return
	end

	var7[arg1] = nil
	local var2 = var7[arg1]
	if not var2 or 0.4 < os.clock() - var2.at then
		return
	end

	local var3 = Vector2.new(arg1.Position.X, arg1.Position.Y)
	if 14 < (var3 - var2.position).Magnitude then
		return
	end

	local success, result = pcall(tapAt, var3)
	if not success and game:GetService("RunService"):IsStudio() then
		warn("[WorldTap] " .. tostring(result))
	end
end)

return { bind = function(arg1, arg2)
	table.insert(tbl1, { button = arg1, callback = arg2 })
	var3.bind(arg1, function(...)
		local var2 = os.clock()
		if var5[arg1] and var2 - var5[arg1] < 0.60000000000000009 then
			return
		end

		var6[arg1] = var2
		arg2(...)
	end)
end }

--- ReplicatedStorage.Client.LuckyStrikeFX [ModuleScript]
-- y u r i

local num1 = 0
local var1 = game:GetService("Players").LocalPlayer
local var2 = Font.new("rbxasset://fonts/families/PressStart2P.json")
local var3 = Color3.fromRGB(120, 235, 110)
local var4 = game:GetService("TweenService")
local function pop()
	local var5 = os.clock()
	if var5 - num1 < 0.35 then
		return
	end

	num1 = var5
	local var6 = var1.Character
	local var7 = var6
	var7 = var7 and (var6:FindFirstChild("Head") or var6:FindFirstChild("HumanoidRootPart"))
	if not var7 then
		return
	end

	local var8 = Instance.new("BillboardGui")
	var8.Name = "LuckyStrike"
	var8.Size = UDim2.fromOffset(150, 50)
	var8.StudsOffsetWorldSpace = Vector3.new(0, 2.5, 0)
	var8.AlwaysOnTop = true
	var8.LightInfluence = 0
	var8.Adornee = var7
	local var9 = Instance.new("TextLabel")
	var9.BackgroundTransparency = 1
	var9.Size = UDim2.fromScale(1, 1)
	var9.FontFace = var2
	var9.TextScaled = true
	var9.TextColor3 = var3
	var9.Text = "2x!"
	var9.Parent = var8
	local var10 = Instance.new("UIStroke")
	var10.Thickness = 3
	var10.Color = Color3.new(0, 0, 0)
	var10.Parent = var9
	local var11 = Instance.new("UIScale")
	var11.Scale = 0.4
	var11.Parent = var9
	var8.Parent = var1:FindFirstChildOfClass("PlayerGui")
	var4:Create(var11, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	var4:Create(var8, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { StudsOffsetWorldSpace = Vector3.new(0, 5.5, 0) }):Play()
	var4:Create(var9, TweenInfo.new(0.54, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, 0.36000000000000004), { TextTransparency = 1 }):Play()
	var4:Create(var10, TweenInfo.new(0.54, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, 0.36000000000000004), { Transparency = 1 }):Play()
	task.delay(0.95000000000000007, function()
		var8:Destroy()
	end)
end

return { init = function(_)
	local var2 = var1:GetAttribute("LuckyStrikes") or 0
	var1:GetAttributeChangedSignal("LuckyStrikes"):Connect(function()
		local var4 = var1:GetAttribute("LuckyStrikes") or 0
		if var2 < var4 then
			pop()
		end

		var2 = var4
	end)
end }

--- ReplicatedStorage.Client.CrystalClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Shared.CrystalConfig)
local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Packages.DataService).client
local var5 = require(var1.Client.UISound)
local var6 = require(var1.Client.MineDrops)
local var7 = game:GetService("RunService")
local var8 = require(var1.Shared.PassConfig)
local var9 = require(var1.Client.PassState)
local var10 = require(var1.Shared.TreeConfig)
return { init = function(_)
	task.defer(function()
		local success, result = pcall(function()
			require(var1.Client.WoodClient):init()
		end)

		if not success then
			warn("[StairClimb] WoodClient failed to start - " .. tostring(result))
		end
	end)

	local var11 = var1:WaitForChild(var2.TEMPLATE_FOLDER, 20)
	local var12 = var11
	var12 = var12 and var11:WaitForChild(var2.TEMPLATE, 20)
	if not var12 or (not var12:IsA("Model")) then
		warn("[Crystals] no ReplicatedStorage.Crystals.Crystal model - the garden cannot be drawn")
		return
	end

	workspace:WaitForChild(var2.SPOTS, 20)
	local var13 = var2.spots()
	if #var13 == 0 then
		return
	end

	local var14 = Instance.new("Folder")
	var14.Name = "MyCrystals"
	var14.Parent = workspace
	local tbl1 = {}
	local var15 = Random.new(var3.UserId)
	for k1, v1 in ipairs(var13) do
		local var16 = var12:Clone()
		var16.Name = v1.Name
		local tbl2 = {}
		for k2, v2 in ipairs(var16:GetDescendants()) do
			if not v2:IsA("BasePart") then
				continue
			end

			v2.Anchored = true
			v2.CanCollide = false
			v2.CanQuery = false
			v2.CanTouch = false
			table.insert(tbl2, { part = v2, transparency = v2.Transparency })
		end

		local tbl3 = {}
		for k3, v3 in ipairs(var16:GetDescendants()) do
			if not v3:IsA("Light") then
				continue
			end

			table.insert(tbl3, { light = v3, brightness = v3.Brightness })
		end

		local var17 = v1
		local var18 = CFrame.new(var2.base(var17))
		local var19 = var15:NextNumber(0, 6.2831853071795862)
		var16:PivotTo(var18 * CFrame.Angles(0, var19, 0))
		local var20, var21 = var16:GetBoundingBox()
		var16.Parent = var14
		local tbl4 = {
			spot = v1,
			model = var16,
			parts = tbl2,
			lights = tbl3,
			spin = var19,
			height = var21.Y,
			size = 1 + var15:NextNumber(-0.15, 0.15),
			scale = 1,
			joltUntil = 0,
			shrink = 1,
			mineStart = 0,
			readyAt = nil,
		}

		tbl1[v1.Name] = tbl4
	end

	local var22 = Vector3.new(0, 0, 0)
	for k4, v4 in ipairs(var13) do
		var22 = var22 + var2.base(v4)
	end

	local var23 = nil
	local num1 = 1
	local var24 = nil
	local var25 = nil
	local bool1 = false
	local function syncGarden()
		local var1 = var4:get("crystalGarden")
		var1 = var1 or {}
		local var3 = workspace:GetServerTimeNow()
		local bool2 = false
		for k1, v1 in pairs(tbl1) do
			local var9 = var1[k1]
			local var10 = v1.readyAt
			if bool1 and (var9 and (var3 < var9 and (not var10 or var10 <= var3))) then
				if var4:get({ "doors", var2.DOOR }) == true then
					var6.burst(var2.base(v1.spot) + Vector3.new(0, 3, 0), 5, "crystals")
					bool2 = true
				end
			end

			v1.readyAt = var9
		end

		if bool2 then
			var5.play("blockBreak")
		end

		bool1 = true
	end

	syncGarden()
	var4:getChangedSignal("crystalGarden"):Connect(syncGarden)
	local num2 = 0
	local var26 = nil
	var22 = var22 / #var13
	local function swingFor(arg1)
		local var2 = arg1
		var2 = var2 and arg1:FindFirstChildWhichIsA("Humanoid")
		local var3 = var2
		var3 = var3 and var2:FindFirstChildWhichIsA("Animator")
		if not var3 then
			return nil
		end

		if var24 and var25 == var3 then
			return var24
		end

		local var4 = var1:FindFirstChild("Tools")
		local var6 = var4
		var6 = var6 and var4:FindFirstChild("Pickaxe")
		local var7 = var6
		var7 = var7 and var6:FindFirstChildWhichIsA("Animation")
		if not var7 then
			return nil
		end

		local success, result = pcall(function()
			local var1 = var7
			return var3:LoadAnimation(var1)
		end)

		if not success or (not result) then
			return nil
		end

		result.Looped = true
		result.Priority = Enum.AnimationPriority.Action
		result:GetMarkerReachedSignal("Hit"):Connect(function()
			result:SetAttribute("HasHitMarker", true)
			if var23 then
				local var2 = os.clock()
				var23.joltUntil = var2 + 0.18
				var23.shrink = 1 - math.clamp((var2 - var23.mineStart) / num1, 0, 1) * 0.6
				var5.play("mineHit")
			end
		end)

		result.DidLoop:Connect(function()
			if not result:GetAttribute("HasHitMarker") and var23 then
				local var2 = os.clock()
				var23.joltUntil = var2 + 0.18
				var23.shrink = 1 - math.clamp((var2 - var23.mineStart) / num1, 0, 1) * 0.6
				var5.play("mineHit")
			end
		end)

		var24 = result
		var25 = var3
		return result
	end

	var7.Heartbeat:Connect(function(arg1)
		local var1 = num2 + arg1
		num2 = var1
		if num2 < 0.03 then
			return
		end

		num2 = 0
		var1 = var4:get({ "doors", var2.DOOR }) == true
		if var1 ~= var26 then
			var26 = var1
			var14.Parent = var1 and workspace or nil
		end

		if not var1 then
			if var24 and var24.IsPlaying then
				var24:Stop(0.15)
			end

			return
		end

		local var6 = workspace.CurrentCamera
		if var6 then
			if 200 < (var6.CFrame.Position - var22).Magnitude then
				if var24 and var24.IsPlaying then
					var24:Stop(0.15)
				end

				var23 = nil
				return
			end
		end

		local var7 = var3.Character
		local var11 = var7
		local var12 = var4:get("crystalGarden")
		var11 = var11 and var7:FindFirstChild("HumanoidRootPart")
		local var15 = workspace:GetServerTimeNow()
		local var16 = var4:get("upgrades")
		local var17 = var11 and (var7:FindFirstChild("Pickaxe") and var2.target(var13, var12 or {}, var11.Position, var15, var16)) or nil
		local var19 = var17 and tbl1[var17.Name] or nil
		local var20 = os.clock()
		if var19 ~= var23 then
			if var23 then
				var23.shrink = 1
			end

			if var19 then
				var19.mineStart = var20
				var19.shrink = 1
			end

			var23 = var19
		end

		local var21
		if var17 then
			local var27 = swingFor(var7)
			if var27 then
				local str3 = "tree"
				local var28 = math.max(var2.holdSeconds(var16, var8.totals(var9.owned).mining * var10.totals(var4:get(str3)).mining), 0.1)
				num1 = var28
				local var29 = 0 < var27.Length and var27.Length or 1
				if not var27.IsPlaying then
					var27:Play(0.15)
				end

				var21 = math.clamp(var29 / var28, 0.7, 1.6)
				if 0.05 < math.abs(var27.Speed - var21) then
					var27:AdjustSpeed(var21)
				end
			end
		else
			if var24 and var24.IsPlaying then
				var24:Stop(0.15)
			end
		end

		for k1, v1 in pairs(tbl1) do
			local var30 = var2.progress(v1.readyAt, var15, var16)
			local var32 = 1 <= var30
			if not var32 then
				v1.shrink = 1
			end

			local var33 = math.max(var2.FULL_SCALE * v1.size * var30 * v1.shrink, 0.01)
			if var32 then
				local var34 = math.max(0, v1.joltUntil - var20) / 0.18
				var34 = var34 or 0
			end

			local num3 = 0
			var33 = var33 * (1 + 0.12 * num3)
			local bool1 = false
			if 0.005 < math.abs(var33 - v1.scale) then
				v1.model:ScaleTo(var33)
				v1.scale = var33
				bool1 = true
			end

			local var35
			if bool1 or (0 < num3 or (v1.tilted or (not v1.posed))) then
				var35 = CFrame.Angles(0.13962634015954636 * num3, 0, 0)
				v1.model:PivotTo(CFrame.new(var2.base(v1.spot) - Vector3.new(0, var2.SINK * v1.height * v1.scale, 0)) * CFrame.Angles(0, v1.spin, 0) * var35)
				v1.tilted = 0 < num3
				v1.posed = true
			end

			local var36 = var30 < 0.02
			for k2, v2 in ipairs(v1.parts) do
				local var37 = if var36 then 1 else v2.transparency
				if v2.part.Transparency == var37 then
					continue
				end

				v2.part.Transparency = var37
			end

			for k3, v3 in ipairs(v1.lights) do
				local var38 = v3.brightness
				local var39 = var38 * (if var32 then 1 else 0.4 * var30)
				if v3.light.Enabled == var36 then
					v3.light.Enabled = not var36
				end

				if 0.01 >= math.abs(v3.light.Brightness - var39) then
					continue
				end

				v3.light.Brightness = var39
			end
		end
	end)
end }

--- ReplicatedStorage.Client.Press [ModuleScript]
-- y u r i

local tbl1 = { handlers = setmetatable({}, { __mode = "k" }) }
tbl1.fire = function(arg1)
	local var1 = arg1
	var1 = var1 and tbl1.handlers[arg1]
	if var1 and arg1.Visible then
		var1()
		return true
	end

	return false
end

tbl1.bind = function(arg1, arg2)
	if not arg1 or (not arg1:IsA("GuiButton")) then
		return
	end

	if arg1:GetAttribute("NoGamepad") ~= true then
		arg1.Selectable = true
		arg1.Active = true
	end

	local num1 = 0
	local var3 = arg1:FindFirstAncestorWhichIsA("ScrollingFrame")
	local function fire(...)
		local var1 = os.clock()
		if var1 - num1 < 0.2 then
			return
		end

		num1 = var1
		arg2(...)
	end

	if var3 then
		local var4 = nil
		arg1.MouseButton1Down:Connect(function()
			var4 = var3.CanvasPosition
		end)

		arg1.Activated:Connect(function(...)
			local var1 = var4
			var4 = nil
			if var1 and 6 < (var3.CanvasPosition - var1).Magnitude then
				return
			end

			fire(...)
		end)

		tbl1.handlers[arg1] = fire
		return arg1
	end

	local var5 = nil
	arg1.MouseButton1Down:Connect(function(...)
		var5 = os.clock()
		fire(...)
	end)

	arg1.Activated:Connect(function(...)
		local var1 = var5
		var5 = nil
		if var1 and os.clock() - var1 < 10 then
			return
		end

		fire(...)
	end)

	tbl1.handlers[arg1] = fire
	return arg1
end

return tbl1

--- ReplicatedStorage.Client.GamepadUI [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Client.Press)
local var2 = game:GetService("Players").LocalPlayer
local var3 = game:GetService("UserInputService")
local var4 = game:GetService("GuiService")
local function firstButton(arg1)
	local var2 = nil
	local var3 = nil
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("GuiButton") then
			continue
		end

		if not v1.Visible then
			continue
		end

		if not v1.Active then
			continue
		end

		if not v1.Selectable then
			continue
		end

		if not var1.handlers[v1] then
			continue
		end

		local var5 = v1.AbsolutePosition.Y * 10000 + v1.AbsolutePosition.X
		if not var3 or var5 < var3 then
			var2 = v1
		end

		local var6 = var5
	end

	return var2
end

local tbl1 = { Enum.KeyCode.ButtonR2, Enum.KeyCode.ButtonL2 }
return { init = function(_)
	local var6 = var2:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	if not var6 then
		return
	end

	local function watch(arg1)
		if not arg1:IsA("GuiObject") then
			return
		end

		arg1:GetPropertyChangedSignal("Visible"):Connect(function()
			if not var3.GamepadEnabled then
				return
			end

			if arg1.Visible then
				task.delay(0.1, function()
					if arg1.Visible then
						var4.SelectedObject = firstButton(arg1)
					end
				end)

				return
			end

			if var4.SelectedObject and var4.SelectedObject:IsDescendantOf(arg1) then
				var4.SelectedObject = nil
			end
		end)
	end

	for k1, v1 in ipairs(var6:GetChildren()) do
	if not not v1:IsA("GuiObject") then
			v1:GetPropertyChangedSignal("Visible"):Connect(function()
				if not var3.GamepadEnabled then
					return
				end

				if v1.Visible then
					task.delay(0.1, function()
						if v1.Visible then
							var4.SelectedObject = firstButton(v1)
						end
					end)

					return
				end

				if var4.SelectedObject and var4.SelectedObject:IsDescendantOf(v1) then
					var4.SelectedObject = nil
				end
			end)

		end
	end

	var6.ChildAdded:Connect(watch)
	var3.InputBegan:Connect(function(arg1)
		for k1, v1 in ipairs(tbl1) do
			if arg1.KeyCode ~= v1 then
				continue
			end

			var1.fire(var4.SelectedObject)
			return
		end
	end)
end }

--- ReplicatedStorage.Client.PlatformReport [ModuleScript]
-- y u r i

local var1 = game:GetService("GuiService")
local var2 = game:GetService("UserInputService")
local var3 = require(game:GetService("ReplicatedStorage").Shared.Remotes)
local var4 = game:GetService("RunService")
return { init = function(_)
	task.spawn(function()
		local var5
		if var1:IsTenFootInterface() then
			var5 = "console"
		else
			var5 = if var2.TouchEnabled and (not var2.MouseEnabled) then "mobile" else "pc"
		end

		for i1 = 1, 3 do
			if pcall(function()
				var3.ClientInfo:FireServer(var5)
			end) then

				return
			end

			if var4:IsStudio() then
				warn("[Telemetry] could not report the platform; retrying")
			end

			task.wait(5)
		end
	end)
end }

--- ReplicatedStorage.Client.CodesUI [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local var2 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			var2.RedeemCode:FireServer(v1)
		end)

	end
end)

local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Client.Press)
local var5 = require(var1.Client.UISound)
local var6 = Color3.fromRGB(110, 230, 120)
local var7 = Color3.fromRGB(240, 90, 80)
return { init = function(_)
	local var1 = var3:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var8 = var1
	var8 = var8 and var1:FindFirstChild("Codes", true)
	local var9 = var8
	local var10 = var8
	var9 = var9 and var8:FindFirstChild("EnterCode")
	var10 = var10 and var8:FindFirstChild("SubmitCode")
	if not var9 or (not var9:IsA("TextBox") or (not var10)) then
		warn("[Codes] no Settings Codes.EnterCode / SubmitCode - codes cannot be entered")
		return
	end

	local var11 = var9.TextColor3
	if var9.PlaceholderText == "" then
		var9.PlaceholderText = "Enter Code"
	end

	if var9.Text == var9.PlaceholderText then
		var9.Text = ""
	end

	var9.ClearTextOnFocus = true
	local bool1 = false
	local function send()
		local var2 = var9.Text
		if bool1 or var2:gsub("%s", "") == "" then
			return
		end

		bool1 = true
		table.insert(tbl1, var2)
		task.delay(5, function()
			bool1 = false
		end)
	end

	var4.bind(var10, send)
	var9.FocusLost:Connect(function(arg1)
		if arg1 then
			send()
		end
	end)

	local num1 = 0
	var2.CodeResult.OnClientEvent:Connect(function(arg1, arg2)
		bool1 = false
		local var1 = var5.play
		var1(if arg1 then "purchase" else "denied")
		var9.Text = tostring(arg2)
		var9.TextColor3 = arg1 and var6 or var7
		num1 = os.clock()
		var1 = num1
		task.delay(3, function()
			if num1 == var1 and (not var9:IsFocused()) then
				var9.Text = ""
				var9.TextColor3 = var11
			end
		end)
	end)

	var9.Focused:Connect(function()
		var9.TextColor3 = var11
	end)
end }

--- ReplicatedStorage.Client.WheelClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local var2 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1 in ipairs(var1) do
		local success, result = pcall(function()
			var2.SpinWheel:FireServer()
		end)

		if success then
			continue
		end

		warn("[Wheel] could not send the spin: " .. tostring(result))
	end
end)

local var3 = require(var1.Shared.WheelConfig)
local function describe(arg1)
	local var2 = arg1.weight / var3.TOTAL_WEIGHT * 100
	if 10 > var2 then
		if var2 % 1 == 0 then
			local var4 = ("%d%%"):format((math.floor(var2 + 0.5)))
			var4 = var4 or ("%.1f%%"):format(var2)
		end
	end

	local var5 = arg1.reward
	var5 = var5 and arg1.reward.seconds
	local var6 = ("<font color=\"#FFE27A\">%s</font>"):format((("%.1f%%"):format(var2)))
	if var5 then
		var6 = var6 .. (60 <= var5 and ("  %d MIN"):format(var5 // 60) or ("  %dS"):format(var5))
	end

	return var6
end

local function decorate(arg1)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChildWhichIsA("SurfaceGui")
	if not var1 then
		return
	end

	local var2 = 0 < var1.AbsoluteSize.X and var1.AbsoluteSize.X or 916.57
	for k1, v1 in ipairs(var3.SEGMENTS) do
		local var4 = var1:FindFirstChild("Segment" .. k1)
		if not var4 then
			continue
		end

		if var1:FindFirstChild("Info" .. k1) then
			continue
		end

		local var5 = var4:FindFirstChild("Text")
		local str1 = [[
]]

		local str2 = ""
		local var6 = (var5 and select(2, var5.Text:gsub(str1, str2)) + 1 or 1) * (var5 and var5.TextSize or 54)
		local var7 = math.rad(var4.Rotation)
		str1 = var4.Position
		local var8 = Vector2.new(-math.sin(var7), (math.cos(var7))) / var2
		var4.Position = UDim2.fromScale(str1.X.Scale + var8.X * -21, str1.Y.Scale + var8.Y * -21)
		str2 = Instance.new("TextLabel")
		str2.Name = "Info" .. k1
		str2.AnchorPoint = var4.AnchorPoint
		str2.Size = UDim2.fromOffset(var4.Size.X.Offset, 40)
		str2.Rotation = var4.Rotation
		local var9 = -21 + var6 / 2 + 10 + 16
		str2.Position = UDim2.fromScale(str1.X.Scale + var8.X * var9, str1.Y.Scale + var8.Y * var9)
		str2.BackgroundTransparency = 1
		str2.RichText = true
		str2.Text = describe(v1)
		str2.TextSize = 32
		str2.TextWrapped = false
		str2.TextColor3 = Color3.new(1, 1, 1)
		if var5 then
			str2.FontFace = var5.FontFace
		end

		local var10 = Instance.new("UIStroke")
		var10.Thickness = 5
		var10.Color = Color3.fromRGB(25, 15, 35)
		var10.Parent = str2
		str2.Parent = var1
	end
end

local var4 = game:GetService("MarketplaceService")
local var5 = require(var1.Packages.DataService).client
local var6 = Color3.new(1, 1, 1)
local var7 = Color3.fromRGB(120, 255, 140)
local var8 = require(var1.Client.UISound)
local var9 = Color3.fromRGB(255, 110, 100)
local var10 = game:GetService("Players").LocalPlayer
local var11 = require(var1.Client.WorldTap)
local var12 = game:GetService("TweenService")
return { init = function(_)
	local var1 = workspace:WaitForChild(var3.MODEL, 20)
	local var13 = var1
	local var14 = var1
	var14 = var14 and var1:FindFirstChild("Panel")
	local var15 = var14
	var13 = var13 and var1:FindFirstChild("Disc")
	var15 = var15 and (var14:FindFirstChild("WheelPanel") and var14.WheelPanel:FindFirstChild("Root"))
	if not var13 or (not var15) then
		warn("[Wheel] no Workspace." .. var3.MODEL .. " with a Disc and a Panel - the wheel is inert")
		return
	end

	local str1 = "Face"
	decorate(var13:FindFirstChild(str1))
	local var16 = var15:FindFirstChild("FreeSpin")
	local var17 = var16
	var17 = var17 and var16:FindFirstChild("Label")
	str1 = var17
	local str2 = "SKIP TIMER"
	task.spawn(function()
		local success, result = pcall(function()
			local var1 = var3.SKIP_PRODUCT
			local var2 = Enum.InfoType.Product
			return var4:GetProductInfo(var1, var2)
		end)

		if success and (result and result.PriceInRobux) then
			str2 = ("SKIP TIMER: R$%d"):format(result.PriceInRobux)
		end
	end)

	local var18 = nil
	local num1 = 0
	local var19 = var6
	local var20 = var13:GetPivot()
	str1 = str1 and var17.Text
	local function waiting()
		if not var5:get({ "doors", var3.DOOR }) then
			return false
		end

		return 3 < (var5:get({ "wheel", "nextFree" }) or 0) - workspace:GetServerTimeNow()
	end

	local var21 = var15:FindFirstChild("Status")
	local bool1 = false
	local num2 = 0
	local num3 = 0
	local num4 = 0
	local num5 = 0
	local function drawStatus()
		if var17 then
			if str1 then
				local var1 = waiting() and str2 or str1
				var17.Text = var1
			end
		end

		if not var21 then
			return
		end

		if os.clock() < num1 and var18 then
			var21.Text = var18
			var21.TextColor3 = var19
			return
		end

		if not var5:get({ "doors", var3.DOOR }) then
			var21.Text = "Unlock the door to spin"
			var21.TextColor3 = var6
			return
		end

		local var4 = (var5:get({ "wheel", "nextFree" }) or 0) - workspace:GetServerTimeNow()
		if var4 <= 0 then
			var21.Text = "Spin ready!"
			var21.TextColor3 = var7
			return
		end

		local var8 = math.max(0, (math.floor(var4)))
		var21.Text = "Next spin in " .. ("%d:%02d"):format(var8 // 60, var8 % 60)
		var21.TextColor3 = var6
	end

	local function ask()
		if bool1 and var3.SPIN_TIME + 6 < os.clock() - num2 then
			bool1 = false
			var10:SetAttribute("WheelSpinning", nil)
			warn("[Wheel] the spin lock was stuck; released")
		end

		if bool1 then
			var8.play("denied")
			return
		end

		if not var5:get({ "doors", var3.DOOR }) then
			var8.play("denied")
			local var1 = var9
			local var2 = os.clock() + 2.5
			var18 = "Unlock the door first"
			num1 = var2
			var19 = var1 or var6
			return
		end

		if waiting() then
			var4:PromptProductPurchase(var10, var3.SKIP_PRODUCT)
			return
		end

		if (var5:get("crystals") or 0) < var3.SPIN_COST then
			var8.play("denied")
			local var7 = var9
			local var11 = os.clock() + 2.5
			var18 = "Not enough crystals"
			num1 = var11
			var19 = var7 or var6
			return
		end

		bool1 = true
		num2 = os.clock()
		var10:SetAttribute("WheelSpinning", true)
		local var12 = num3 + 1
		num3 = var12
		table.insert(tbl1, true)
		var12 = num3
		task.delay(3, function()
			if num4 < var12 then
				bool1 = false
				var10:SetAttribute("WheelSpinning", nil)
			end
		end)
	end

	if var16 and var16:IsA("GuiButton") then
		var11.bind(var16, ask)
	end

	var2.WheelResult.OnClientEvent:Connect(function(arg1, arg2)
		num4 = num3
		local var1 = arg1 and arg2
		if not arg1 then
			bool1 = false
			var10:SetAttribute("WheelSpinning", nil)
			var8.play("denied")
			local var2 = var9
			local var4 = tostring(arg2 or "Can't spin right now")
			local var5 = os.clock() + 2.5
			var18 = var4
			num1 = var5
			var19 = var2 or var6
			return
		end

		bool1 = true
		num2 = os.clock()
		var18 = nil
		var8.play("purchase")
		local var11 = (-var3.angleOf(arg1) - num5) % 360 + 1800
		local var14 = Instance.new("NumberValue")
		var14.Value = num5
		local var15 = 360 / #var3.SEGMENTS
		local var16 = math.floor(num5 / var15)
		local num6 = 0
		var14.Changed:Connect(function(arg1)
			var13:PivotTo(var20 * CFrame.Angles(math.rad(arg1), 0, 0))
			local var2 = math.floor(arg1 / var15)
			if var2 ~= var16 and 0.045 <= os.clock() - num6 then
				var16 = var2
				num6 = os.clock()
				var8.play("wheelTick")
			end
		end)

		local var17 = TweenInfo.new(var3.SPIN_TIME - 0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
		local var21 = var12:Create(var14, var17, { Value = num5 + var11 })
		var21.Completed:Connect(function()
			local var2 = (num5 + var11) % 360
			num5 = var2
			var13:PivotTo(var20 * CFrame.Angles(math.rad(num5), 0, 0))
			var14:Destroy()
			bool1 = false
			var10:SetAttribute("WheelSpinning", nil)
			var2 = var3.SEGMENTS[arg1]
			local var4 = var2.reward
			var4 = var4 and var2.reward.seconds
			local var5 = var2.label:gsub([[
]], " ")

			if var4 then
				var5 = var5 .. (" (%d min)"):format((math.max(1, var4 // 60)))
			end

			local var9 = var1 and ("%s! %s"):format(var5, var1) or ("You won: %s!"):format(var5)
			local var12 = var7
			local var15 = os.clock() + (if var1 then 6 else 4)
			var18 = var9
			num1 = var15
			var19 = var12 or var6
			var9 = var8.play
			var9(if var2.reward and var2.reward.trail then "wheelJackpot" else "wheelWin")
		end)

		var21:Play()
	end)

	local bool2 = false
	local success, result = pcall(drawStatus)
	if not success and (not bool2) then
		warn("[Wheel] status line failed: " .. tostring(result))
		bool2 = true
	end

	task.spawn(function()
		while true do
			task.wait(0.5)
			local success, result = pcall(drawStatus)
			if success or bool2 then
				continue
			end

			bool2 = true
			warn("[Wheel] status line failed: " .. tostring(result))
		end
	end)
end }

--- ReplicatedStorage.Client.TrailInventory [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local var2 = require(var1.Shared.Remotes)
game:GetService("RunService").Heartbeat:Connect(function()
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			var2.EquipTrail:FireServer(v1)
		end)

	end
end)

local num1 = 215
local num2 = 150
local num3 = 30
local var3 = ColorSequence.new(Color3.fromRGB(255, 215, 90), Color3.fromRGB(num1, num2, num3))
local var4 = require(var1.Shared.TrailConfig)
local var5 = require(var1.Packages.DataService).client
local var6 = require(var1.Client.MenuEffects)
local var7 = require(var1.Client.Press)
local var8 = require(var1.Client.UISound)
local var9 = game:GetService("Players").LocalPlayer
local var10 = Color3.fromRGB(255, 215, 90)
local tbl2 = {}
num3 = {
	best = function(arg1)
		local num1 = 1
		for k1, v1 in ipairs(var4.STATS) do
			num1 = num1 * (arg1.buffs[v1] or 1)
		end

		return num1
	end,
	rarity = function(arg1)
		local var1 = var4.TIER_BY_ID[arg1.tier]
		return var1 and var1.order or 0
	end,
}

for k1, v1 in ipairs(var4.STATS) do
	num3[v1] = function(arg1)
		return arg1.buffs[v1] or 1
	end

end

tbl2.init = function(_)
	local var1 = var9:WaitForChild("PlayerGui"):WaitForChild("Main", 20)
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TrailInventory")
	local var11 = var2
	var11 = var11 and var2:FindFirstChild("TrailScroller")
	local var12 = var11
	local var13 = var11
	var12 = var12 and var11:FindFirstChildWhichIsA("UIGridLayout")
	var13 = var13 and var11:FindFirstChild("Trail")
	if not var2 or (not var11 or (not var12 or (not var13))) then
		warn("[TrailInventory] no Main.TrailInventory.TrailScroller.Trail - the inventory has no menu")
		return
	end

	var13.Parent = nil
	local var14 = var13:FindFirstChild("Buy")
	local var15 = var14
	var15 = var15 and var14:FindFirstChildWhichIsA("UIGradient", true)
	local num1 = 40
	local num2 = 150
	local num4 = 40
	local var16 = var15 and var15.Color or ColorSequence.new(Color3.fromRGB(90, 220, 90), Color3.fromRGB(num1, num2, num4))
	num4 = function()
		local var2 = var11.AbsoluteWindowSize
		local num1 = 1
		local var3 = var11
		local var4 = var3:FindFirstChildWhichIsA("UIScale")
		while not var3 and var3 == var1 and var4 and 0 < var4.Scale do
		end

		return var2 / math.max(num1, 0.01)
	end

	num1 = var12.CellSize
	num2 = 0
	local var17 = var2:FindFirstChild("Empty")
	local var18 = var2:FindFirstChild("Title")
	var12.SortOrder = Enum.SortOrder.LayoutOrder
	local tbl3 = {}
	local str1 = "best"
	local function slotAt(arg1)
		if tbl3[arg1] then
			return tbl3[arg1]
		end

		local var1 = (tbl3[1] and tbl3[1].card or var13):Clone()
		var1.Name = "Card" .. arg1
		var1.Visible = false
		local var2 = var1:FindFirstChild("Buy")
		local var3 = var2
		var3 = var3 and var2:FindFirstChild("Cost")
		local tbl2 = { card = var1, buttonText = var3 }
		var3 = var2
		var3 = var3 and var2:FindFirstChildWhichIsA("UIGradient", true)
		tbl2.gradient = var3
		if var2 then
			var7.bind(var2, function()
				local var1 = var5:get("trails")
				local var3 = tbl2.def
				if not var3 or (var1 or {})[var3.id] ~= true then
					var8.play("denied")
					return
				end

				var8.play("purchase")
				local var4 = tbl1
				table.insert(var4, if var5:get("equippedTrail") == var3.id then "" else var3.id)
			end)

		end

		var1.Parent = var11
		tbl3[arg1] = tbl2
		return tbl2
	end

	local function fill(arg1, arg2)
		arg1.def = arg2
		local var1 = arg1.card
		local var3 = var1:FindFirstChild("Title")
		local var5 = var4.TIER_BY_ID[arg2.tier]
		if var3 then
			var3.Text = arg2.name .. " Trail"
			var3.TextColor3 = arg2.colors[1]
		end

		local var7 = var1:FindFirstChild("Buffs")
		if var7 then
			var7.Text = var5 and var5.name or arg2.tier
			local var8 = var5 and var5.color or Color3.new(1, 1, 1)
			var7.TextColor3 = var8
		end

		local var9 = var1:FindFirstChild("Preview")
		local var10 = var9
		var10 = var10 and var9:FindFirstChildWhichIsA("UIGradient")
		if var10 then
			var10.Color = var4.colorSequence(arg2.colors)
		end

		local var12 = var1:FindFirstChild("Stats")
		if var12 then
			for k1, v1 in ipairs(var4.STATS) do
				local var13 = var12:FindFirstChild(v1:sub(1, 1):upper() .. v1:sub(2))
				if not var13 then
					continue
				end

				if not var13:IsA("TextLabel") then
					continue
				end

				local var14 = arg2.buffs[v1] or 1
				var13.Text = ("%s: %gx"):format(var13.Name, var14)
				var13.Visible = var14 ~= 1
			end
		end
	end

	local tbl4 = {}
	local function relayout()
		local var1 = num4()
		if var1.X < 1 or var1.Y < 1 then
			return
		end

		local var2 = Vector2.new((var1.X - var12.CellPadding.X.Offset * 1 - 1) / 2, var1.Y * num1.Y.Scale)
		var12.CellSize = UDim2.fromOffset(math.floor(var2.X), (math.floor(var2.Y)))
		var11.AutomaticCanvasSize = Enum.AutomaticSize.None
		var11.CanvasSize = UDim2.fromOffset(0, (math.ceil(num2 * var2.Y + math.max(num2 - 1, 0) * var12.CellPadding.Y.Offset)))
	end

	local var20 = var2:FindFirstChild("Scroller")
	local function draw()
		local var1 = var5:get("trails")
		var1 = var1 or {}
		local var2 = var5:get("equippedTrail") or ""
		local tbl1 = {}
		for k1, v1 in ipairs(var4.LIST) do
			local var6 = var1[v1.id]
			if var6 ~= true then
				continue
			end

			table.insert(tbl1, v1)
		end

		local var7 = num3[str1]
		var7 = var7 or num3.best
		table.sort(tbl1, function(arg1, arg2)
			local var3 = arg1.id == var2
			if var3 ~= (arg2.id == var2) then
				return var3
			end

			local var8 = var7(arg1)
			local var9 = var7(arg2)
			if var8 ~= var9 then
				return var9 < var8
			end

			local num1 = 1
			for k1, v1 in ipairs(var4.STATS) do
				num1 = num1 * (arg1.buffs[v1] or 1)
			end

			local num2 = 1
			for k2, v2 in ipairs(var4.STATS) do
				num2 = num2 * (arg2.buffs[v2] or 1)
			end

			if num1 ~= num2 then
				return num2 < num1
			end

			return arg1.order < arg2.order
		end)

		for k2, v2 in ipairs(tbl1) do
			local var8 = slotAt(k2)
			if var8.def ~= v2 then
				fill(var8, v2)
			end

			var8.card.LayoutOrder = k2
			var8.card.Visible = true
			local var9 = v2.id == var2
			if var8.buttonText then
				local var11 = var8.buttonText
				var11.Text = if var9 then "EQUIPPED" else "EQUIP"
			end

			if not var8.gradient then
				continue
			end

			var8.gradient.Color = var9 and var3 or var16
		end

		for i1 = #tbl1 + 1, #tbl3 do
			tbl3[i1].card.Visible = false
			local var12 = nil
			local var13 = tbl3[i1]
			var13.def = var12
		end

		local var15
		if var18 then
			var15 = #tbl1
			var18.Text = ("YOUR TRAILS (%d)"):format(var15)
		end

		if var17 then
			var17.Visible = #tbl1 == 0
		end

		for k3, v3 in pairs(tbl4) do
			local var19 = v3.label
			if not var19 then
				continue
			end

			var19.TextColor3 = k3 == str1 and var10 or v3.color
		end

		num2 = math.ceil(#tbl1 / 2)
		relayout()
	end

	if var20 then
		for k1, v1 in ipairs(var20:GetChildren()) do
			local var21 = v1:IsA("GuiButton")
			var21 = var21 and v1.Name:match("^Sort_(%w+)$")
			if not var21 then
				continue
			end

			if not num3[var21] then
				continue
			end

			local var22 = v1:FindFirstChild("Title")
			local var23 = var22
			tbl4[var21] = { label = var22, color = var23 and var22.TextColor3 }
			var7.bind(v1, function()
				if str1 == var21 then
					return
				end

				str1 = var21
				var8.play("click")
				draw()
				var11.CanvasPosition = Vector2.zero
			end)

		end
	end

	draw()
	local str2 = "equippedTrail"
	for k2, v2 in ipairs({ "trails", str2 }) do
		var5:getChangedSignal(v2):Connect(draw)
	end

	var11:GetPropertyChangedSignal("AbsoluteSize"):Connect(relayout)
	local var24 = var6.bind(var2)
	tbl2.open = function()
		draw()
		var24.open()
	end

	tbl2.close = function()
		var24.close()
	end

	local var26 = var2:FindFirstChild("CloseButton")
	if var26 then
		var7.bind(var26, var24.close)
	end

	local var27 = var1:FindFirstChild("Menu")
	local var28 = var27
	var28 = var28 and var27:FindFirstChild("Inventory")
	if var28 then
		var7.bind(var28, function()
			if not var24.isOpen() then
				draw()
			end

			var24.toggle()
		end)

	else
		warn("[TrailInventory] no Main.Menu.Inventory button - the inventory has no way in")
	end
end

return tbl2

--- ReplicatedStorage.Client.WoodClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local var2 = require(var1.Shared.WoodConfig)
local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Packages.DataService).client
local var5 = require(var1.Client.UISound)
local var6 = require(var1.Client.MineDrops)
local var7 = game:GetService("RunService")
local var8 = require(var1.Shared.PassConfig)
local var9 = require(var1.Client.PassState)
local var10 = require(var1.Shared.TreeConfig)
tbl1.init = function(_)
	task.defer(function()
		local success, result = pcall(function()
			require(script.Parent.EssenceClient):init()
		end)

		if not success then
			warn("[Essence] EssenceClient failed to start - " .. tostring(result))
		end
	end)

	if tbl1._started then
		return
	end

	tbl1._started = true
	local var11 = var1:WaitForChild(var2.TEMPLATE_FOLDER, 20)
	local var12 = var11
	var12 = var12 and var11:WaitForChild(var2.TEMPLATE, 20)
	if not var12 or (not var12:IsA("Model")) then
		warn("[Wood] no ReplicatedStorage.Trees.Tree model - the yard cannot be drawn")
		return
	end

	workspace:WaitForChild(var2.SPOTS, 20)
	local var13 = var2.spots()
	if #var13 == 0 then
		return
	end

	local var14 = Instance.new("Folder")
	var14.Name = "MyTrees"
	var14.Parent = workspace
	local tbl2 = {}
	local var15 = Random.new(var3.UserId + 7)
	for k1, v1 in ipairs(var13) do
		local var16 = var12:Clone()
		var16.Name = v1.Name
		local tbl3 = {}
		for k2, v2 in ipairs(var16:GetDescendants()) do
			if not v2:IsA("BasePart") then
				continue
			end

			v2.Anchored = true
			v2.CanCollide = false
			v2.CanQuery = false
			v2.CanTouch = false
			table.insert(tbl3, { part = v2, transparency = v2.Transparency })
		end

		local var17 = v1
		local var18 = CFrame.new(var2.base(var17))
		local var19 = math.rad(90 * var15:NextInteger(0, 3))
		var16:PivotTo(var18 * CFrame.Angles(0, var19, 0))
		var16.Parent = var14
		local tbl4 = {
			spot = v1,
			model = var16,
			parts = tbl3,
			spin = var19,
			size = 1 + var15:NextNumber(-0.12, 0.12),
			scale = 1,
			shakeUntil = 0,
			readyAt = nil,
		}

		tbl2[v1.Name] = tbl4
	end

	local var20 = Vector3.new(0, 0, 0)
	for k3, v3 in ipairs(var13) do
		var20 = var20 + var2.base(v3)
	end

	local var21 = nil
	local var22 = nil
	local var23 = nil
	local bool1 = false
	local function syncGrove()
		local var1 = var4:get("woodGrove")
		var1 = var1 or {}
		local var3 = workspace:GetServerTimeNow()
		for k1, v1 in pairs(tbl2) do
			local var8 = var1[k1]
			local var9 = v1.readyAt
			if bool1 and (var8 and (var3 < var8 and (not var9 or var9 <= var3))) then
				if var4:get({ "doors", var2.DOOR }) == true then
					var6.burst(var2.base(v1.spot) + Vector3.new(0, 6 * v1.scale, 0), 6, "wood")
				end
			end

			v1.readyAt = var8
		end

		bool1 = true
	end

	syncGrove()
	var4:getChangedSignal("woodGrove"):Connect(syncGrove)
	local num1 = 0
	local var24 = nil
	var20 = var20 / #var13
	local function swingFor(arg1)
		local var2 = arg1
		var2 = var2 and arg1:FindFirstChildWhichIsA("Humanoid")
		local var3 = var2
		var3 = var3 and var2:FindFirstChildWhichIsA("Animator")
		if not var3 then
			return nil
		end

		if var22 and var23 == var3 then
			return var22
		end

		local var4 = var1:FindFirstChild("Tools")
		local var6 = var4
		var6 = var6 and var4:FindFirstChild("Axe")
		local var7 = var6
		var7 = var7 and var6:FindFirstChildWhichIsA("Animation")
		if not var7 then
			return nil
		end

		local success, result = pcall(function()
			local var1 = var7
			return var3:LoadAnimation(var1)
		end)

		if not success or (not result) then
			return nil
		end

		result.Looped = true
		result.Priority = Enum.AnimationPriority.Action
		result:GetMarkerReachedSignal("Hit"):Connect(function()
			result:SetAttribute("HasHitMarker", true)
			if var21 then
				var21.shakeUntil = os.clock() + 0.2
				var5.play("woodChop")
			end
		end)

		result.DidLoop:Connect(function()
			if not result:GetAttribute("HasHitMarker") and var21 then
				var21.shakeUntil = os.clock() + 0.2
				var5.play("woodChop")
			end
		end)

		var22 = result
		var23 = var3
		return result
	end

	var7.Heartbeat:Connect(function(arg1)
		local var1 = num1 + arg1
		num1 = var1
		if num1 < 0.03 then
			return
		end

		num1 = 0
		var1 = var4:get({ "doors", var2.DOOR }) == true
		if var1 ~= var24 then
			var24 = var1
			var14.Parent = var1 and workspace or nil
		end

		if not var1 then
			if var22 and var22.IsPlaying then
				var22:Stop(0.15)
			end

			return
		end

		local var6 = workspace.CurrentCamera
		if var6 then
			if 200 < (var6.CFrame.Position - var20).Magnitude then
				if var22 and var22.IsPlaying then
					var22:Stop(0.15)
				end

				var21 = nil
				return
			end
		end

		local var7 = var3.Character
		local var11 = var7
		local var12 = var4:get("woodGrove")
		var11 = var11 and var7:FindFirstChild("HumanoidRootPart")
		local var15 = workspace:GetServerTimeNow()
		local var16 = var4:get("upgrades")
		local var17 = var16
		local var18 = var11 and (var7:FindFirstChild("Axe") and var2.target(var13, var12 or {}, var11.Position, var15, var17)) or nil
		local var19 = os.clock()
		var21 = var18 and tbl2[var18.Name] or nil
		if var18 then
			local var25 = swingFor(var7)
			if var25 then
				local str3 = "tree"
				local var27 = math.max(var2.holdSeconds(var16, var8.totals(var9.owned).mining * var10.totals(var4:get(str3)).mining), 0.1)
				local var28 = 0 < var25.Length and var25.Length or 1
				if not var25.IsPlaying then
					var25:Play(0.15)
				end

				var17 = math.clamp(var28 / var27, 0.7, 1.6)
				if 0.05 < math.abs(var25.Speed - var17) then
					var25:AdjustSpeed(var17)
				end
			end
		else
			if var22 and var22.IsPlaying then
				var22:Stop(0.15)
			end
		end

		for k1, v1 in pairs(tbl2) do
			local var29 = var2.progress(v1.readyAt, var15, var16)
			local var30 = math.max(var2.FULL_SCALE * v1.size * (0.15 + 0.85 * var29), 0.01)
			local var31 = 1 <= var29
			local bool1 = false
			if 0.005 < math.abs(var30 - v1.scale) then
				v1.model:ScaleTo(var30)
				v1.scale = var30
				bool1 = true
			end

			if var31 then
				local var32 = math.max(0, v1.shakeUntil - var19) / 0.2
				var32 = var32 or 0
			end

			local num3 = 0
			local var33
			if bool1 or (0 < num3 or (v1.tilted or (not v1.posed))) then
				local var34 = v1.spot
				var33 = CFrame.new(var2.base(var34))
				local var35 = var33 * CFrame.Angles(0, v1.spin, 0)
				var33 = CFrame.Angles(0.12217304763960307 * num3 * math.sin(var19 * 60), 0, 0)
				v1.model:PivotTo(var35 * var33)
				v1.tilted = 0 < num3
				v1.posed = true
			end

			for k2, v2 in ipairs(v1.parts) do
				local var37 = var29 < 0.02
				local var38 = if var37 then 1 else v2.transparency
				if v2.part.Transparency == var38 then
					continue
				end

				v2.part.Transparency = var38
			end
		end
	end)
end

return tbl1

--- ReplicatedStorage.Client.EssenceClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local bool1 = false
local var3 = require(var1.Shared.Remotes)
var2.Heartbeat:Connect(function()
	if bool1 then
		bool1 = false
		pcall(function()
			var3.Essence:FireServer("sync")
		end)

	end
end)

local num1 = 255
local num2 = 175
local num3 = 245
local var4 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 190
num3 = 100
local num4 = 255
local var5 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 105
num4 = 55
local num5 = 215
num1 = 1
local var6 = ColorSequence.new({ var4, var5, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
num1 = 1
num2 = 1
num2 = 1
num3 = 0.1
var5 = {}
local var7 = require(var1.Shared.EssenceConfig)
local var8 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(num1, num2) })
var4 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(num2, num3) })
local var9 = require(var1.Client.UISound)
local var10 = require(var1.Packages.DataService).client
local var11 = Color3.fromRGB(200, 130, 255)
local var12 = game:GetService("Players").LocalPlayer
var5.init = function(_)
	if var5._started then
		return
	end

	var5._started = true
	local var1 = workspace:WaitForChild(var7.FIELD, 30)
	local var13 = var1
	var13 = var13 and var1:WaitForChild(var7.AREA, 10)
	local var15 = var7.template()
	if not var13 or (not var15) then
		warn("[Essence] no Essence Field or no ReplicatedStorage.Currency.Essence - nothing to draw")
		return
	end

	local var16 = Instance.new("Folder")
	var16.Name = "EssenceOrbs"
	var16.Parent = workspace
	local tbl1 = {}
	local num1 = 0
	local num2 = 0
	local function build(arg1, arg2, arg3)
		if tbl1[arg1] then
			return
		end

		local var1 = num1 + 1
		num1 = var1
		var1 = var15:Clone()
		var1.Name = "Essence" .. arg1
		for k1, v1 in ipairs(var1:GetDescendants()) do
			if v1:IsA("BasePart") then
				v1.Anchored = true
				v1.CanCollide = false
				v1.CanQuery = false
				v1.CanTouch = false
				v1.CastShadow = false
			else
				if not v1:IsA("Light") then
					continue
				end

				if num1 % 3 == 0 then
					continue
				end

				v1:Destroy()
			end
		end

		local var2 = var1:GetBoundingBox()
		var1.WorldPivot = var2
		local var3 = arg2
		var1:PivotTo(CFrame.new(var3))
		var3 = 2.2
		var1:ScaleTo(var3 * (if arg3 then 0.05 else 1))
		var1.Parent = var16
		local tbl2 = {
			model = var1,
			spot = arg2,
			phase = math.random() * 3.1415926535897931 * 2,
			state = "live",
		}

		tbl2.spin = math.random() * 3.1415926535897931 * 2
		local var4 = arg3 and os.clock() or nil
		tbl2.bornAt = var4
		tbl1[arg1] = tbl2
	end

	local function fly(arg1)
		local var2 = tbl1[arg1]
		if not var2 or var2.state ~= "live" then
			return
		end

		var2.state = "flying"
		var2.since = os.clock()
		var2.from = var2.model:GetPivot().Position
		var2.model:ScaleTo(2.2)
		local var3 = var2.model:FindFirstChild("EssenceInner", true)
		var3 = var3 or var2.model:FindFirstChildWhichIsA("BasePart", true)
		if var3 then
			local var5 = Instance.new("Attachment")
			var5.Position = Vector3.new(0, 0.836, 0)
			var5.Parent = var3
			local var7 = Instance.new("Attachment")
			var7.Position = Vector3.new(0, -0.836, 0)
			var7.Parent = var3
			local var9 = Instance.new("Trail")
			var9.Attachment0 = var5
			var9.Attachment1 = var7
			var9.Color = var6
			var9.Transparency = var8
			var9.WidthScale = var4
			var9.LightEmission = 0.7
			var9.Lifetime = 0.3
			var9.MinLength = 0.02
			var9.FaceCamera = true
			var9.Parent = var3
		end

		for k1, v1 in ipairs(var2.model:GetDescendants()) do
			if not v1:IsA("ParticleEmitter") then
				continue
			end

			v1.Enabled = false
		end
	end

	var3.Essence.OnClientEvent:Connect(function(arg1, arg2)
		if type(arg2) ~= "table" then
			return
		end

		local var1
		local var2
		if arg1 == "spawn" then
			for k1, v1 in ipairs(arg2) do
				if type(v1) ~= "table" then
					continue
				end

				if typeof(v1[2]) ~= "Vector3" then
					continue
				end

				build(v1[1], v1[2], true)
			end

			return
		end

		local var3
		if arg1 == "take" then
			for k2, v2 in ipairs(arg2) do
				var1 = tbl1[v2]
				if not var1 then
					continue
				end

				var1.confirmed = true
				if var1.state == "live" then
					fly(v2)
				else
					if var1.state ~= "gone" then
						continue
					end

					tbl1[v2] = nil
				end
			end

			return
		end

		if arg1 == "vacuum" then
			for k3, v3 in ipairs(arg2) do
				var1 = tbl1[v3]
				if not var1 then
					continue
				end

				tbl1[v3] = nil
				var1.model:Destroy()
			end

			return
		end

		if arg1 == "full" then
			local tbl2 = {}
			for k4, v4 in ipairs(arg2) do
				if type(v4) ~= "table" then
					continue
				end

				if typeof(v4[2]) ~= "Vector3" then
					continue
				end

				tbl2[v4[1]] = true
				local var6 = tbl1[v4[1]]
				if var6 then
					if var6.state == "gone" then
						local var8 = v4[1]
						local var10 = tbl1[var8]
						if var10 then
							tbl1[var8] = nil
							var10.model:Destroy()
						end

						var6 = nil
					end
				end

				if var6 then
					continue
				end

				build(v4[1], v4[2], false)
			end

			for k5, v5 in pairs(tbl1) do
				if tbl2[k5] then
					continue
				end

				if v5.state == "live" then
					local var11 = tbl1[k5]
					if not var11 then
						continue
					end

					tbl1[k5] = nil
					var11.model:Destroy()
				else
					v5.confirmed = true
					if v5.state ~= "gone" then
						continue
					end

					tbl1[k5] = nil
				end
			end
		end
	end)

	local num3 = -math.huge
	local str1 = "upgrades"
	local var17 = var7.range(var10:get(str1))
	var10:getChangedSignal("upgrades"):Connect(function()
		local str1 = "upgrades"
		var17 = var7.range(var10:get(str1))
	end)

	local var18 = Instance.new("CylinderHandleAdornment")
	var18.Name = "EssenceRange"
	var18.Height = 0.06
	var18.Color3 = var11
	var18.Transparency = 0.3
	var18.AlwaysOnTop = false
	var18.Visible = false
	var18.Parent = var16
	local var19 = nil
	local num4 = 0
	local function place(arg1)
		local var1 = arg1
		local var2 = arg1
		var1 = var1 and arg1:FindFirstChild("HumanoidRootPart")
		var2 = var2 and arg1:FindFirstChildOfClass("Humanoid")
		if not var1 or (not var2) then
			return
		end

		var18.CFrame = CFrame.new(0, -(if var2.RigType == Enum.HumanoidRigType.R6 then 3 else var2.HipHeight + var1.Size.Y / 2) + 0.15, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
		var18.Adornee = var1
	end

	var2.Heartbeat:Connect(function(arg1)
		local var1 = num4 + arg1
		num4 = var1
		if num4 < 0.2 then
			return
		end

		num4 = 0
		var1 = var12.Character
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
		local bool2 = false
		if var2 ~= nil then
			bool2 = var7.inRoom(var2.Position, var13)
		end

		if bool2 then
			if var18.Adornee ~= var2 then
				place(var1)
			end

		if var19 ~= var17 then
				var19 = var17
				var18.Radius = var17
				var18.InnerRadius = math.max(0, var17 - 0.3)
			end
		end

		var18.Visible = bool2
	end)

	local var20 = os.clock()
	local function land(arg1)
		local var2 = tbl1[arg1]
		if not var2 then
			return
		end

		var2.state = "gone"
		var2.since = os.clock()
		for k1, v1 in ipairs(var2.model:GetDescendants()) do
			if v1:IsA("BasePart") then
				v1.Transparency = 1
			else
				if not v1:IsA("Light") then
					continue
				end

				v1.Enabled = false
			end
		end

		local var3 = os.clock()
		if 0.07 <= var3 - num2 then
			num2 = var3
			var9.play("essence")
		end

		local var4 = var2.model
		task.delay(0.35, function()
			var4:Destroy()
		end)

		if var2.confirmed then
			tbl1[arg1] = nil
		end
	end

	local function resync()
		local var1 = os.clock()
		if 1.5 <= var1 - num3 then
			num3 = var1
			bool1 = true
		end
	end

	if 1.5 <= var20 - num3 then
		bool1 = true
		num3 = var20
	end

	var10:getChangedSignal("doors"):Connect(resync)
	var12.CharacterAdded:Connect(resync)
	var2.Heartbeat:Connect(function()
		if not next(tbl1) then
			return
		end

		local var1 = var12.Character
		var1 = var1 and var12.Character:FindFirstChild("HumanoidRootPart")
		local var2 = os.clock()
		local bool2 = false
		if var1 ~= nil then
			bool2 = (var1.Position - var13.Position).Magnitude <= 160
		end

		local var3 = var1 and (var7.inRoom(var1.Position, var13) and var17 - var7.CLIENT_SHORT) or nil
		local bool3 = false
		for k1, v1 in pairs(tbl1) do
			if v1.state == "live" then
				if bool2 then
					v1.model:PivotTo(CFrame.new(v1.spot + Vector3.new(0, math.sin(var2 * 1.7 + v1.phase) * 0.7, 0)) * CFrame.Angles(0, v1.spin + var2 * 0.9, 0))
					if v1.bornAt then
						local var4 = math.clamp((var2 - v1.bornAt) / 0.35, 0, 1)
						local var5 = var4 - 1
						v1.model:ScaleTo(math.max(0.05, 1 + 2.7 * var5 * var5 * var5 + 1.7 * var5 * var5) * 2.2)
						if 1 <= var4 then
							v1.model:ScaleTo(2.2)
							v1.bornAt = nil
						end
					end
				end

				if not var3 then
					continue
				end

				if (v1.spot - var1.Position).Magnitude > var3 then
					continue
				end

				fly(k1)
			else
				if v1.state == "flying" then
					local var6 = math.clamp((var2 - v1.since) / 0.42, 0, 1)
					local var8 = var1 and var1.Position or v1.from
					local var9 = var6 * var6
					local var10 = v1.from * (1 - var9) ^ 2 + ((v1.from + var8) / 2 + Vector3.new(0, 5, 0)) * ((1 - var9) * 2 * var9) + var8 * (var9 * var9)
					v1.model:PivotTo(CFrame.new(var10))
					v1.model:ScaleTo(math.max(0.2, 1 - var9 * 0.65) * 2.2)
					if 1 > var6 then
						continue
					end

					land(k1)
				elseif not v1.confirmed and 3 < var2 - v1.since then
					bool3 = true
				end
			end
		end

		local var14 = os.clock()
		if bool3 and 1.5 <= var14 - num3 then
			num3 = var14
			bool1 = true
		end
	end)
end

return var5

--- ReplicatedStorage.Client.PurchaseFX [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = nil
local function emitter(arg1, arg2)
	local var1 = Instance.new("ParticleEmitter")
	var1.Name = arg1
	var1.Enabled = false
	var1.LightEmission = 0.3
	var1.LightInfluence = 0
	var1.ZOffset = 1
	var1.Shape = Enum.ParticleEmitterShape.Sphere
	var1.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	var1.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	var1.SpreadAngle = Vector2.new(12, 12)
	for k1, v1 in pairs(arg2) do
		var1[k1] = v1
	end

	var1:GetPropertyChangedSignal("Enabled"):Connect(function()
		if var1.Enabled then
			var1.Enabled = false
		end
	end)

	return var1
end

local var4 = Color3.fromRGB(255, 244, 200)
local var5 = Color3.fromRGB(255, 214, 120)
local function seq(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1) do
		local var1 = v1[1]
		local var2 = v1[2]
		local var3 = v1[3] or 0
		table.insert(tbl1, NumberSequenceKeypoint.new(var1, var2, var3))
	end

	local var4 = tbl1
	return NumberSequence.new(var4)
end

local var6 = Color3.new(1, 1, 1)
local num1 = 0
local bool1 = false
local var7 = game:GetService("RunService")
local num2 = 0
local var8 = require(var1.Client.SettingFlag)
local function purchaseMount()
	if var3 and var3.part.Parent then
		return var3
	end

	local var1 = Instance.new("Part")
	var1.Name = "PurchaseFX"
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.CastShadow = false
	var1.Transparency = 1
	var1.Shape = Enum.PartType.Ball
	var1.Size = Vector3.new(0.6, 0.6, 0.6)
	var1.Parent = workspace.CurrentCamera
	local tbl1 = {
		Texture = "rbxassetid://87304824079392",
		Color = ColorSequence.new(var4, var5),
		LightEmission = 0.25,
		ZOffset = -1.5,
		LockedToPart = true,
	}

	tbl1.Speed = NumberRange.new(0)
	tbl1.Lifetime = NumberRange.new(0.6)
	tbl1.Rotation = NumberRange.new(0, 360)
	tbl1.RotSpeed = NumberRange.new(150)
	tbl1.Size = seq({ { 0, 1.5 }, { 0.3, 6 }, { 1, 7.5 } })
	tbl1.Transparency = seq({ { 0, 0.3 }, { 0.5, 0.5 }, { 1, 1 } })
	local tbl2 = { 1, (emitter("Sunburst", tbl1)) }
	local tbl3 = {
		Texture = "rbxassetid://128755660236746",
		Color = ColorSequence.new(var6, var4),
		Drag = 5,
	}

	tbl3.Lifetime = NumberRange.new(0.55, 0.8)
	tbl3.Speed = NumberRange.new(22, 32)
	tbl3.Size = seq({ { 0, 1.1, 0.3 }, { 1, 0 } })
	tbl3.Transparency = seq({ { 0, 0 }, { 0.5, 0.2 }, { 1, 1 } })
	tbl3.Rotation = NumberRange.new(-20, 20)
	tbl3.RotSpeed = NumberRange.new(-90, 90)
	local tbl4 = { 12, (emitter("Stars", tbl3)) }
	local tbl5 = { Texture = "rbxassetid://128755660236746", Color = ColorSequence.new(var6), Drag = 4 }
	tbl5.Lifetime = NumberRange.new(0.45, 0.7)
	tbl5.Speed = NumberRange.new(14, 22)
	tbl5.Size = seq({ { 0, 0.6, 0.2 }, { 1, 0 } })
	tbl5.Transparency = seq({ { 0, 0 }, { 0.5, 0.25 }, { 1, 1 } })
	tbl5.Rotation = NumberRange.new(-20, 20)
	tbl5.RotSpeed = NumberRange.new(-90, 90)
	tbl1 = emitter("TinyStars", tbl5)
	local tbl6 = { tbl2, tbl4, { 8, tbl1 } }
	for k1, v1 in ipairs(tbl6) do
		v1[2].Parent = var1
	end

	var3 = { part = var1, list = tbl6 }
	return var3
end

local var9 = game:GetService("TweenService")
local var10 = require(var1.Packages.DataService).client
local var11 = Color3.fromRGB(170, 110, 255)
local var12 = Color3.fromRGB(130, 220, 255)
local var13 = Color3.fromRGB(255, 150, 230)
local tbl1 = {
	burst = function()
		local var1 = os.clock()
		if var1 - num2 < 0.2 then
			return
		end

		num2 = var1
		if not var8.on("particles") then
			return
		end

		local var3 = var2.Character
		var3 = var3 and var2.Character:FindFirstChild("HumanoidRootPart")
		if not var3 then
			return
		end

		local var4 = purchaseMount()
		local var5 = Vector3.new(0, 0.4, 0)
		var4.part.CFrame = CFrame.new(var3.Position + var5)
		for k1, v1 in ipairs(var4.list) do
			v1[2]:Emit(v1[1])
		end

		num1 = os.clock() + 0.7
		local var6 = var4.part
		if bool1 then
			return
		end

		bool1 = true
		local var9 = nil
		var7.RenderStepped:Connect(function()
			local var1 = var2.Character
			var1 = var1 and var2.Character:FindFirstChild("HumanoidRootPart")
			if num1 < os.clock() or (not var1 or (not var6.Parent)) then
				var9:Disconnect()
				bool1 = false
				return
			end

			var6.CFrame = CFrame.new(var1.Position + Vector3.new(0, 0.4, 0))
		end)
	end,
	rebirth = function()
		local var1 = var2.Character
		var1 = var1 and var2.Character:FindFirstChild("HumanoidRootPart")
		if not var1 then
			return
		end

		local var5 = workspace.CurrentCamera
		if var5 then
			local var7 = var5.FieldOfView
			local var10 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local var14 = var9:Create(var5, var10, { FieldOfView = var7 + 9 })
			var14.Completed:Connect(function()
				local var1 = TweenInfo.new(0.55, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
				var9:Create(var5, var1, { FieldOfView = var7 }):Play()
			end)

			var14:Play()
		end

		if not var8.on("particles") then
			return
		end

		local var15 = Instance.new("Part")
		var15.Name = "RebirthFX"
		var15.Anchored = true
		var15.CanCollide = false
		var15.CanQuery = false
		var15.CanTouch = false
		var15.CastShadow = false
		var15.Transparency = 1
		var15.Shape = Enum.PartType.Ball
		var15.Size = Vector3.new(5, 5, 5)
		var15.Parent = workspace.CurrentCamera
		local var16 = var1.Position
		var15.CFrame = CFrame.new(var16 + Vector3.new(0, 0.5, 0))
		local var17 = Instance.new("Part")
		var17.Name = "RebirthFXCore"
		var17.Anchored = true
		var17.CanCollide = false
		var17.CanQuery = false
		var17.CanTouch = false
		var17.CastShadow = false
		var17.Transparency = 1
		local var18 = Enum.PartType.Block
		var17.Shape = var18 or Enum.PartType.Ball
		var17.Size = Vector3.new(0.2, 0.2, 0.2)
		var17.Parent = workspace.CurrentCamera
		var17.CFrame = var15.CFrame
		local var19 = Instance.new("Part")
		var19.Name = "RebirthFXFeet"
		var19.Anchored = true
		var19.CanCollide = false
		var19.CanQuery = false
		var19.CanTouch = false
		var19.CastShadow = false
		var19.Transparency = 1
		local var20 = Enum.PartType.Block
		var19.Shape = var20 or Enum.PartType.Ball
		var19.Size = Vector3.new(0.2, 0.2, 0.2)
		var19.Parent = workspace.CurrentCamera
		var19.CFrame = CFrame.new(var16 - Vector3.new(0, 2.8, 0))
		local tbl1 = {
			Texture = "rbxassetid://76395378129188",
			Color = ColorSequence.new(var6, var11),
			LightEmission = 0.2,
		}

		tbl1.Shape = Enum.ParticleEmitterShape.Box
		tbl1.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		tbl1.Speed = NumberRange.new(0)
		tbl1.Lifetime = NumberRange.new(0.6)
		tbl1.Size = seq({ { 0, 4 }, { 0.2, 12 }, { 1, 16 } })
		tbl1.Transparency = seq({ { 0, 0.45 }, { 0.4, 0.6 }, { 1, 1 } })
		var20 = { var17, 1, (emitter("Flash", tbl1)) }
		local tbl2 = {
			Texture = "rbxassetid://126678907010300",
			Orientation = Enum.ParticleOrientation.VelocityParallel,
			Color = ColorSequence.new(var6, var11),
			Drag = 1.5,
		}

		tbl2.Lifetime = NumberRange.new(0.6, 0.9)
		tbl2.Speed = NumberRange.new(16, 28)
		tbl2.Size = seq({ { 0, 6, 1.5 }, { 1, 0 } })
		tbl2.Transparency = seq({ { 0, 0.1 }, { 0.5, 0.35 }, { 1, 1 } })
		local tbl3 = { var15, 16, (emitter("SpikesViolet", tbl2)) }
		local tbl4 = {
			Texture = "rbxassetid://126678907010300",
			Orientation = Enum.ParticleOrientation.VelocityParallel,
			Color = ColorSequence.new(var6, var12),
			Drag = 1.5,
		}

		tbl4.Lifetime = NumberRange.new(0.6, 0.9)
		tbl4.Speed = NumberRange.new(14, 24)
		tbl4.Size = seq({ { 0, 5, 1.2 }, { 1, 0 } })
		tbl4.Transparency = seq({ { 0, 0.15 }, { 0.5, 0.4 }, { 1, 1 } })
		local tbl5 = { var15, 10, (emitter("SpikesCyan", tbl4)) }
		local tbl6 = {
			Texture = "rbxassetid://128755660236746",
			Color = ColorSequence.new(var6, var13),
			Drag = 0.8,
		}

		tbl6.Lifetime = NumberRange.new(1.1, 1.6)
		tbl6.Speed = NumberRange.new(7, 12)
		tbl6.Rotation = NumberRange.new(-20, 20)
		tbl6.RotSpeed = NumberRange.new(-40, 40)
		tbl6.Size = seq({ { 0, 3, 0.8 }, { 1, 0 } })
		tbl6.Transparency = seq({ { 0, 0 }, { 0.5, 0.25 }, { 1, 1 } })
		local tbl7 = { var15, 12, (emitter("SparklesPink", tbl6)) }
		local tbl8 = {
			Texture = "rbxassetid://128755660236746",
			Color = ColorSequence.new(var6, var12),
			Drag = 0.8,
		}

		tbl8.Lifetime = NumberRange.new(1.1, 1.6)
		tbl8.Speed = NumberRange.new(7, 12)
		tbl8.Rotation = NumberRange.new(-20, 20)
		tbl8.RotSpeed = NumberRange.new(-40, 40)
		tbl8.Size = seq({ { 0, 2.6, 0.8 }, { 1, 0 } })
		tbl8.Transparency = seq({ { 0, 0 }, { 0.5, 0.25 }, { 1, 1 } })
		local tbl9 = { var15, 10, (emitter("SparklesCyan", tbl8)) }
		local tbl10 = {
			Texture = "rbxassetid://88829702225855",
			Orientation = Enum.ParticleOrientation.VelocityPerpendicular,
			Shape = Enum.ParticleEmitterShape.Box,
			ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume,
			SpreadAngle = Vector2.zero,
			Color = ColorSequence.new(var6, var11),
		}

		tbl10.Lifetime = NumberRange.new(0.8)
		tbl10.Speed = NumberRange.new(0.01)
		tbl10.Size = seq({ { 0, 2 }, { 1, 28 } })
		tbl10.Transparency = seq({ { 0, 0.15 }, { 0.5, 0.45 }, { 1, 1 } })
		tbl1 = { var19, 1, (emitter("RingFast", tbl10)) }
		local tbl11 = {
			Texture = "rbxassetid://88829702225855",
			Orientation = Enum.ParticleOrientation.VelocityPerpendicular,
			Shape = Enum.ParticleEmitterShape.Box,
			ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume,
			SpreadAngle = Vector2.zero,
			Color = ColorSequence.new(var12, var11),
		}

		tbl11.Lifetime = NumberRange.new(1.2)
		tbl11.Speed = NumberRange.new(0.01)
		tbl11.Size = seq({ { 0, 1 }, { 1, 40 } })
		tbl11.Transparency = seq({ { 0, 0.3 }, { 0.5, 0.55 }, { 1, 1 } })
		tbl2 = { var19, 1, (emitter("RingSlow", tbl11)) }
		local tbl12 = {
			Texture = "rbxassetid://128755660236746",
			Color = ColorSequence.new(var11, var12),
			Drag = 1,
			Acceleration = Vector3.new(0, 3, 0),
		}

		tbl12.Shape = Enum.ParticleEmitterShape.Box
		tbl12.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		tbl12.SpreadAngle = Vector2.new(70, 70)
		tbl12.Lifetime = NumberRange.new(1.5, 2.3)
		tbl12.Speed = NumberRange.new(4, 9)
		tbl12.Rotation = NumberRange.new(0, 360)
		tbl12.RotSpeed = NumberRange.new(-60, 60)
		tbl12.Size = seq({ { 0, 1, 0.3 }, { 1, 0 } })
		tbl12.Transparency = seq({ { 0, 0 }, { 0.6, 0.3 }, { 1, 1 } })
		var18 = { var20, tbl3, tbl5, tbl7, tbl9, tbl1, tbl2, { var19, 26, (emitter("Stardust", tbl12)) } }
		for k1, v1 in ipairs(var18) do
			v1[3].Parent = v1[1]
			v1[3]:Emit(v1[2])
		end

		var20 = Instance.new("PointLight")
		var20.Color = var11
		var20.Range = 36
		var20.Brightness = 0
		var20.Shadows = false
		var20.Parent = var15
		var9:Create(var20, TweenInfo.new(0.12), { Brightness = 3 }):Play()
		task.delay(0.12, function()
			var9:Create(var20, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Brightness = 0 }):Play()
		end)

		task.delay(3, function()
			var15:Destroy()
			var17:Destroy()
			var19:Destroy()
		end)
	end,
}

tbl1.init = function(_)
	if tbl1._started then
		return
	end

	tbl1._started = true
	task.spawn(function()
		pcall(function()
			game:GetService("ContentProvider"):PreloadAsync({
				"rbxassetid://128755660236746",
				"rbxassetid://126678907010300",
				"rbxassetid://76395378129188",
				"rbxassetid://88829702225855",
				"rbxassetid://87304824079392",
			})
		end)
	end)

	task.defer(function()
		pcall(purchaseMount)
	end)

	local function copy(arg1)
		local var1 = arg1
		local tbl1 = {}
		for k1, v1 in pairs(var1 or {}) do
			tbl1[k1] = v1
		end

		return tbl1
	end

	local str1 = "upgrades"
	local str2 = "tree"
	local var1 = copy(var10:get(str1))
	var10:getChangedSignal("upgrades"):Connect(function()
		local var2 = var10:get("upgrades")
		var2 = var2 or {}
		local bool1 = false
		for k1, v1 in pairs(var2) do
			if type(v1) ~= "number" then
				continue
			end

			if (var1[k1] or 0) >= v1 then
				continue
			end

			bool1 = true
		end

		var1 = copy(var2)
		if bool1 then
			tbl1.burst()
		end
	end)

	local var2 = copy(var10:get(str2))
	var10:getChangedSignal("tree"):Connect(function()
		local var1 = var10:get("tree")
		var1 = var1 or {}
		local bool1 = false
		for k1, v1 in pairs(var1) do
			if v1 ~= true then
				continue
			end

			if var2[k1] == true then
				continue
			end

			bool1 = true
		end

		var2 = copy(var1)
		if bool1 then
			tbl1.burst()
		end
	end)

	local var3 = var10:get("rebirths") or 0
	var10:getChangedSignal("rebirths"):Connect(function()
		local var2 = var10:get("rebirths") or 0
		if var3 < var2 then
			task.delay(0.25, tbl1.rebirth)
		end

		var3 = var2
	end)
end

return tbl1

--- ReplicatedStorage.Client.TotemClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
Font.new("rbxasset://fonts/families/PressStart2P.json")
Color3.fromRGB(24, 20, 36)
local var2 = require(var1.Packages.DataService).client
local var3 = require(var1.Shared.Remotes)
local var4 = require(var1.Shared.TotemConfig)
local var5 = require(var1.Shared.TreeConfig)
local var6 = require(var1.Shared.TotemModels)
local var7 = require(var1.Client.Press)
local var8 = require(var1.Client.UISound)
local var9 = game:GetService("Players").LocalPlayer
local var10 = Color3.fromRGB(52, 150, 142)
local var11 = Color3.fromRGB(240, 240, 250)
local var12 = Color3.fromRGB(60, 180, 90)
local var13 = Color3.fromRGB(190, 60, 70)
local var14 = Color3.fromRGB(80, 78, 92)
local var15 = Color3.fromRGB(230, 90, 90)
local tbl1 = { gold = Color3.fromRGB(255, 214, 90) }
tbl1.silver = Color3.fromRGB(205, 212, 226)
tbl1.ingots = Color3.fromRGB(205, 165, 118)
tbl1.crystals = Color3.fromRGB(170, 165, 255)
tbl1.wood = Color3.fromRGB(214, 160, 104)
tbl1.essence = Color3.fromRGB(215, 150, 255)
local tbl2 = {}
local function paint(arg1, arg2)
	local var1 = arg1:FindFirstChild("BG")
	local var2 = var1
	var2 = var2 and var1:FindFirstChildWhichIsA("UIGradient")
	if var2 then
		local var6, var7, var8 = arg2:ToHSV()
		local var9 = var6
		local var10 = var7 * 0.7
		local var11 = math.min(1, var8 * 1.15)
		var2.Color = ColorSequence.new(Color3.fromHSV(var6, math.min(1, var7 * 1.1), var8 * 0.55), Color3.fromHSV(var9, var10, var11))
		return
	end

	if var1 then
		var1.BackgroundColor3 = arg2
	end
end

local function card(arg1, arg2, _)
	local var1 = Instance.new("BillboardGui")
	var1.Name = "TotemCard" .. arg1
	var1.Adornee = arg2
	var1.Size = UDim2.fromScale(7, 4.4)
	var1.StudsOffsetWorldSpace = Vector3.new(0, 2.6, -3.4)
	var1.LightInfluence = 0
	var1.AlwaysOnTop = true
	var1.MaxDistance = 70
	var1.ResetOnSpawn = false
	var1.Active = true
	var1.Enabled = false
	local var2 = script.CardTemplate:Clone()
	var2.Name = "Panel"
	var2.Parent = var1
	return {
		bb = var1,
		title = var2.Title,
		sub = var2.Sub,
		cost = var2.CostLine,
		action = var2.Action,
		actionLabel = var2.Action.Label,
		left = var2.Left,
		right = var2.Right,
	}
end

tbl2.init = function(_)
	if tbl2._started then
		return
	end

	tbl2._started = true
	local var16 = workspace:WaitForChild(var4.FOLDER, 60)
	if not var16 then
		warn("[Totems] no Workspace." .. var4.FOLDER .. " - the shrine has nothing to show")
		return
	end

	local function data()
		local var5
		local var1 = var2:get("totems")
		if type(var1) == "table" then
			local var4 = var1
			if not var4 then
				var4 = { bases = {}, owned = {}, slots = {} }
			end
		end

		return var5
	end

	local function rebuild(arg1, arg2)
		local var3 = arg2.bases
		local var5 = var4.key(arg1.i)
		if var3 then
			var3 = arg2.bases[var5] == true
		end

		local var7 = var3 and (arg2.slots and var4.BY_ID[arg2.slots[var5]]) or nil
		local var9 = (if var3 then "b" else "-") .. (var7 and var7.id or "")
		if arg1.built == var9 then
			return
		end

		arg1.built = var9
		arg1.mine:ClearAllChildren()
		for k1, v1 in ipairs(arg1.ghost and arg1.ghost:GetDescendants() or {}) do
			if not v1:IsA("BasePart") then
				continue
			end

			v1.LocalTransparencyModifier = if var3 then 1 else 0
		end

		if var3 then
			var6.base(arg1.mine, arg1.at, arg1.facing, false)
		end

		if var7 then
			var6.head(arg1.mine, arg1.at, arg1.facing, var7)
		end
	end

	local tbl3 = {}
	local function draw(arg1)
		local var1 = data()
		rebuild(arg1, var1)
		local var7 = var1.bases
		local var8 = arg1.ui
		local var9 = var4.key(arg1.i)
		if var7 then
			var7 = var1.bases[var9] == true
		end

		var8.left.Visible = false
		var8.right.Visible = false
		var8.sub.TextColor3 = var10
		local var16 = var7 and (var1.slots and var4.BY_ID[var1.slots[var9]]) or nil
		if not var7 then
			arg1.state = "base"
			local var17 = var4.nextBase(var1)
			var8.title.Text = "Totem Base"
			if var17 then
				var8.sub.Text = var4.short(var17.gold) .. " GOLD"
				local var18 = var17.gold <= (var2:get("gold") or 0) and tbl1.gold or var15
				var8.sub.TextColor3 = var18
				var8.cost.Text = "+ " .. var4.short(var17.wood) .. " WOOD"
				var18 = var17.wood <= (var2:get("wood") or 0) and tbl1.wood or var15
				var8.cost.TextColor3 = var18
			else
				var8.sub.Text = ""
				var8.cost.Text = ""
			end

			var8.actionLabel.Text = "Purchase"
			paint(var8.action, var12)
		elseif var16 then
			arg1.state = "worn"
			var8.title.Text = var16.name
			var8.title.TextColor3 = var16.color
			local str1 = "tree"
			var8.sub.Text = ("%dx %s"):format(var4.multFor(var5.totals(var2:get(str1)).totemBoost), var4.STAT_NAMES[var16.stat])
			var8.cost.Text = "Active"
			var8.cost.TextColor3 = var10
			var8.actionLabel.Text = "Remove"
			paint(var8.action, var13)
		else
			arg1.state = "pick"
			var8.left.Visible = true
			var8.right.Visible = true
			local var19 = var4.HEADS[arg1.pick]
			var8.title.Text = var19.name
			var8.title.TextColor3 = var19.color
			local str2 = "tree"
			var8.sub.Text = ("%dx %s"):format(var4.multFor(var5.totals(var2:get(str2)).totemBoost), var4.STAT_NAMES[var19.stat])
			local var21 = var4.slotOf(var1, var19.id)
			if var21 and var21 ~= arg1.i then
				var8.cost.Text = "On another totem"
				var8.cost.TextColor3 = var14:Lerp(var11, 0.5)
				var8.actionLabel.Text = "In Use"
				paint(var8.action, var14)
			else
				if var1.owned and var1.owned[var19.id] then
					var8.cost.Text = "Owned"
					var8.cost.TextColor3 = var10
					var8.actionLabel.Text = "Place"
					paint(var8.action, var12)
				else
					var8.cost.Text = var4.headCostText(var19)
					local var22 = var19.cost <= (var2:get(var19.currency) or 0) and tbl1[var19.currency] or (var11 or var15)
					var8.cost.TextColor3 = var22
					var8.actionLabel.Text = "Purchase"
					paint(var8.action, var12)
				end
			end
		end

		if arg1.state ~= "pick" and arg1.state ~= "worn" then
			var8.title.TextColor3 = var11
		end

		local var23 = var8.sub
		local var24 = UDim2.fromScale
		var23.Size = var24(if var8.left.Visible then 0.62 else 0.88, 0.14)
	end

	local var17 = var9:WaitForChild("PlayerGui")
	local function drawAll()
		for k1, v1 in ipairs(tbl3) do
			draw(v1)
		end
	end

	for i1 = 1, var4.SLOTS do
		local var18 = var16:WaitForChild("Slot" .. i1, 30)
		local var19 = var18
		var19 = var19 and var18:WaitForChild("Square", 30)
		if not var19 then
			continue
		end

		local var20 = Instance.new("Folder")
		var20.Name = "Mine"
		var20.Parent = var18
		local var21 = var18:GetAttribute("Facing") or Vector3.new(-1, 0, 0)
		local tbl4 = {
			i = i1,
			slot = var18,
			square = var19,
			mine = var20,
			ghost = var18:FindFirstChild("GhostBase"),
			pick = 1,
		}

		tbl4.at = var19.Position + Vector3.new(0, var19.Size.Y / 2, 0)
		tbl4.facing = var21
		tbl4.ui = card(i1, var19, var21)
		tbl4.ui.bb.Parent = var17
		var7.bind(tbl4.ui.left, function()
			tbl4.pick = (tbl4.pick - 2) % #var4.HEADS + 1
			draw(tbl4)
		end)

		var7.bind(tbl4.ui.right, function()
			tbl4.pick = tbl4.pick % #var4.HEADS + 1
			draw(tbl4)
		end)

		var7.bind(tbl4.ui.action, function()
			local var6 = data()
			if tbl4.state == "base" then
				local var9 = var4.nextBase(var6)
				if var9 then
					if var9.gold <= (var2:get("gold") or 0) then
						if not (var9.wood <= (var2:get("wood") or 0)) then
							var8.play("denied")
							return
						end
					end
				end

				var3.Totem:FireServer("base", tbl4.i)
				return
			end

			if tbl4.state == "worn" then
				var3.Totem:FireServer("remove", tbl4.i)
				return
			end

			if tbl4.state == "pick" then
				local var12 = var4.HEADS[tbl4.pick]
				local var14 = var4.slotOf(var6, var12.id)
				if var14 and var14 ~= tbl4.i then
					var8.play("denied")
					return
				end

				if var6.owned then
					if not var6.owned[var12.id] then
						if not (var12.cost <= (var2:get(var12.currency) or 0)) then
							var8.play("denied")
							return
						end
					end
				end

				var3.Totem:FireServer("head", tbl4.i, var12.id)
			end
		end)

		table.insert(tbl3, tbl4)
	end

	for k1, v1 in ipairs(tbl3) do
		draw(v1)
	end

	local str1 = "tree"
	for k2, v2 in ipairs({ "totems", str1, "gold", "silver", "ingots", "crystals", "wood", "essence" }) do
		var2:getChangedSignal(v2):Connect(drawAll)
	end

	task.spawn(function()
		while true do
			task.wait(0.15)
			local var1 = var9.Character
			var1 = var1 and var9.Character:FindFirstChild("HumanoidRootPart")
			for k1, v1 in ipairs(tbl3) do
				local bool1 = false
				if var1 then
					local bool2 = false
					if ((var1.Position - v1.square.Position) * Vector3.new(1, 0, 1)).Magnitude <= var4.PROMPT_RADIUS then
						bool2 = math.abs(var1.Position.Y - v1.square.Position.Y) < 12
					end

					bool1 = bool2
				end

				if v1.ui.bb.Enabled == bool1 then
					continue
				end

				v1.ui.bb.Enabled = bool1
			end
		end
	end)
end

return tbl2

--- ReplicatedStorage.Client.StarforgeClient [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local var3 = game:GetService("TweenService")
local var4 = require(var1.Packages.DataService).client
local var5 = require(var1.Shared.NumberFormat)
local var6 = require(var1.Shared.Remotes)
local var7 = require(var1.Shared.StarforgeConfig)
local var8 = require(var1.Shared.TreeConfig)
local var9 = require(var1.Shared.TrailConfig)
local var10 = require(var1.Shared.PassConfig)
local var11 = require(var1.Client.UISound)
local var12 = require(var1.Client.WorldTap)
local var13 = game:GetService("Players").LocalPlayer
local tbl1 = { emblemDim = Color3.fromRGB(100, 70, 24) }
tbl1.emblemHot = Color3.fromRGB(190, 140, 50)
tbl1.faceHot = Color3.fromRGB(220, 120, 40)
tbl1.molten = Color3.fromRGB(150, 84, 20)
tbl1.ingot = Color3.fromRGB(255, 176, 96)
local tbl2 = {}
var2.Heartbeat:Connect(function()
	if #tbl2 == 0 then
		return
	end

	local var1 = tbl2
	tbl2 = {}
	for k1, v1 in ipairs(var1) do
		pcall(function()
			v1:FireServer()
		end)

	end
end)

local function screenOf(arg1)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChild("Screen")
	local var2 = var1
	var2 = var2 and var1:FindFirstChildWhichIsA("SurfaceGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChildWhichIsA("GuiObject")
	if not var3 then
		return nil
	end

	local var4 = nil
	for k1, v1 in ipairs(var3:GetChildren()) do
		if not v1:IsA("GuiButton") then
			continue
		end

		var4 = v1
	end

	if not var4 then
		for k2, v2 in ipairs(var3:GetChildren()) do
			if not v2:IsA("Frame") then
				continue
			end

			if not v2:FindFirstChild("Cost") then
				continue
			end

			var4 = v2
		end
	end

	local tbl1 = { count = var3:FindFirstChild("YouHave") }
	tbl1.capacity = var3:FindFirstChild("Capacity")
	tbl1.button = var4
	return tbl1
end

local function pressable(arg1, arg2)
	if arg1:IsA("GuiButton") then
		var12.bind(arg1, arg2)
		return
	end

	local var1 = Instance.new("TextButton")
	var1.Name = "Hit"
	var1.Text = ""
	var1.BackgroundTransparency = 1
	var1.AnchorPoint = Vector2.new(0.5, 0.5)
	var1.Position = UDim2.fromScale(0.5, 0.5)
	var1.Size = UDim2.fromScale(1, 1)
	var1.ZIndex = arg1.ZIndex + 5
	var1.Parent = arg1
	var12.bind(var1, arg2)
end

local function fxPart(arg1, arg2, arg3)
	local var1 = Instance.new("Part")
	var1.Name = arg2
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	local bool1 = false
	var1.CanTouch = bool1
	local bool2 = false
	var1.CastShadow = bool2
	var1.TopSurface = Enum.SurfaceType.Smooth
	var1.BottomSurface = Enum.SurfaceType.Smooth
	for k1, v1 in pairs(arg3) do
		var1[k1] = v1
	end

	var1.Parent = arg1
	return var1
end

return { init = function(arg1)
	if arg1._started then
		return
	end

	arg1._started = true
	local var1 = workspace:WaitForChild("StarforgeSystem", 20)
	local var12 = var1
	var12 = var12 and var1:WaitForChild("Forge", 10)
	local var14 = var12
	local var15 = var12
	var14 = var14 and var12:FindFirstChild("Hammer")
	var15 = var15 and var12:FindFirstChild("AnvilFace")
	if not var14 or (not var15) then
		warn("[Starforge] Workspace.StarforgeSystem.Forge is incomplete - nothing to animate")
		return
	end

	local str1 = "Dropper"
	local str2 = "Collector"
	local var16 = screenOf(var12:FindFirstChild(str1))
	local var17 = screenOf(var12:FindFirstChild(str2))
	local function drawScreens()
		local var1 = var4:get("starforge")
		var1 = var1 or {}
		local var2 = var4:get("upgrades")
		if var16 and var16.count then
			var16.count.Text = "You Have: " .. var5.format(var4:get("ingots") or 0)
		end

		if var16 and var16.capacity then
			local str2 = "tree"
			local var3 = math.floor(var7.paceFor(var2, var8.totals(var4:get(str2)).starforgeCapacity).capacity)
			var16.capacity.Text = ("%s/%s"):format(var5.format(var1.queued or 0), var5.format(var3))
		end

		if var17 then
			if var17.count then
				local str7 = "tree"
				local var14 = var8.totals(var4:get(str7)).starmetal or 1
				local str8 = "equippedTrail"
				str7 = "passes"
				local var15 = var14 * (var9.totals(var4:get("trails"), var4:get(str8)).starmetal or 1)
				var14 = (var1.queued or 0) * var7.perPiece(var2, var15 * (var10.totals(var4:get(str7)).starmetal or 1))
				var15 = math.floor(var14)
				var14 = "Starmetal: " .. var5.format(var4:get("starmetal") or 0)
				if 0 < var15 then
					local var19 = var15
					var14 = var14 .. ("  (+%s)"):format(var5.format(var19))
				end

				var17.count.Text = var14
			end
		end
	end

	drawScreens()
	local str3 = "starmetal"
	for k1, v1 in ipairs({ "ingots", str3, "starforge", "upgrades", "tree", "trails", "equippedTrail", "passes" }) do
		var4:getChangedSignal(v1):Connect(drawScreens)
	end

	if var16 and var16.button then
		pressable(var16.button, function()
			local var1 = var4:get("starforge")
			var1 = var1 or {}
			if (var4:get("ingots") or 0) >= var7.CHARGE then
				local str2 = "tree"
				if math.floor(var7.paceFor(var4:get("upgrades"), var8.totals(var4:get(str2)).starforgeCapacity).capacity) > (var1.queued or 0) then
					local var5 = var13.Character
					local var9 = var5
					var9 = var9 and var5:FindFirstChild("HumanoidRootPart")
					local bool3 = false
					if var9 ~= nil then
						bool3 = var7.inRoom(var9.Position)
					end

					if not bool3 then
						var11.play("denied")
						return
					end
				end
			end

			table.insert(tbl2, var6.StarforgeDeposit)
		end)

	end

	local var18 = var12:FindFirstChild("Crucible")
	local var19 = var18
	var19 = var19 and (var18:FindFirstChild("Faucet") or var18:FindFirstChild("Trough"))
	local var20 = var19
	str2 = var15:FindFirstChild("Impact")
	local var21 = var14.PrimaryPart
	var21 = var21 or var14:FindFirstChild("Head")
	local var22 = var15:FindFirstChild("Intake")
	var20 = var20 and var19:FindFirstChild("Spout")
	local var23 = var15:FindFirstChild("Pour")
	local var24 = var15.CFrame.Rotation
	local var25 = str2 and str2.WorldPosition or var15.Position + Vector3.new(0, 0.2, 0)
	local var26 = var14:GetPivot()
	local var27 = var21.Position
	local tbl3 = {}
	local tbl4 = {}
	for k2, v2 in ipairs(var14:GetChildren()) do
		if v2.Name == "Emblem" then
			table.insert(tbl3, v2)
		end

		if v2.Name ~= "Cable" then
			continue
		end

		local var28 = v2.Position.Z
		table.insert(tbl4, { part = v2, x = v2.Position.X, z = var28 })
	end

	local var29 = var12:FindFirstChild("Gears")
	local var30 = var27.Y + 3.9
	local var31 = var15.Color
	local tbl5 = {}
	for k3, v3 in ipairs(var29 and var29:GetChildren() or {}) do
		if not v3:IsA("Model") then
			continue
		end

		if not v3.PrimaryPart then
			continue
		end

		local tbl6 = { model = v3, base = v3:GetPivot() }
		tbl6.ratio = v3:GetAttribute("Ratio") or 1
		table.insert(tbl5, tbl6)
	end

	local str4 = "RingB"
	local var32 = var12:FindFirstChild("Reactor")
	local tbl7 = {}
	for k4, v4 in ipairs({ "RingA", str4 }) do
		local var33 = var32
		var33 = var33 and var32:FindFirstChild(v4)
		if not var33 then
			continue
		end

		if not var33.PrimaryPart then
			continue
		end

		local tbl8 = { model = var33, base = var33:GetPivot(), angle = 0 }
		tbl8.speed = if v4 == "RingA" then 0.8 else -1.1
		table.insert(tbl7, tbl8)
	end

	local tbl9 = {}
	for k5, v5 in ipairs(var32 and var32:GetChildren() or {}) do
		if v5.Name ~= "StarVoxel" then
			continue
		end

		table.insert(tbl9, { part = v5, base = v5.Color })
	end

	local tbl10 = {}
	for i1 = 1, 9 do
		local var34 = var32
		var34 = var34 and var32:FindFirstChild("C" .. i1, true)
		if not var34 then
			break
		end

		table.insert(tbl10, var34.WorldPosition)
	end

	local num1 = 0
	local tbl11 = {}
	for i2 = 1, #tbl10 - 1 do
		local var35 = i2 + 1
		local var36 = (tbl10[i2 + 1] - tbl10[i2]).Magnitude
		table.insert(tbl11, { a = tbl10[i2], b = tbl10[var35], from = num1, len = var36 })
		num1 = num1 + var36
	end

	local var37 = var12:FindFirstChild("Gauges")
	local var38 = var37:GetChildren()
	local function alongRoute(arg1)
		for k1, v1 in ipairs(tbl11) do
			if arg1 > v1.from + v1.len then
				continue
			end

			local var1 = v1.b
			local var2 = (arg1 - v1.from) / math.max(v1.len, 0.001)
			return v1.a:Lerp(var1, var2)
		end

		return tbl10[#tbl10]
	end

	local tbl12 = {}
	local num2 = 0
	local tbl13 = {}
	for k6, v6 in ipairs(var37 and var38 or {}) do
		local var39 = v6:FindFirstChild("Needle", true)
		if not var39 then
			continue
		end

		table.insert(tbl13, { frame = var39, kind = k6 })
	end

	local var40 = var12:FindFirstChild("Crucible")
	var40 = var40 and (var12.Crucible:FindFirstChild("Stack") and var12.Crucible.Stack:FindFirstChild("Out"))
	local var42 = nil
	if var40 then
		var42 = Instance.new("ParticleEmitter")
		var42.Texture = "rbxasset://textures/particles/smoke_main.dds"
		var42.Rate = 1.5
		var42.Lifetime = NumberRange.new(2.5, 4)
		var42.Speed = NumberRange.new(2, 4)
		var42.SpreadAngle = Vector2.new(12, 12)
		var42.EmissionDirection = Enum.NormalId.Top
		var42.Acceleration = Vector3.new(0, 1, 0)
		var42.Rotation = NumberRange.new(0, 360)
		local num3 = 1
		local num4 = 4
		var42.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.2), NumberSequenceKeypoint.new(num3, num4) })
		num3 = 1
		num4 = 1
		var42.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(num3, num4) })
		local num5 = 44
		num3 = 40
		num4 = 38
		var42.Color = ColorSequence.new(Color3.fromRGB(80, 72, 68), Color3.fromRGB(num5, num3, num4))
		var42.LightInfluence = 1
		var42.Parent = var40
	end

	local var43 = os.clock()
	local var44 = Instance.new("Folder")
	var44.Name = "StarforgeFX"
	var44.Parent = var12
	local var45 = Instance.new("Attachment")
	var45.WorldPosition = var25
	var45.Parent = workspace.Terrain
	local num6 = 255
	local num7 = 120
	local num8 = 30
	local tbl14 = {
		Texture = "rbxasset://textures/particles/sparkles_main.dds",
		LightEmission = 1,
		Color = ColorSequence.new(Color3.fromRGB(255, 235, 170), Color3.fromRGB(num6, num7, num8)),
		Acceleration = Vector3.new(0, -45, 0),
		Drag = 1.5,
	}

	num7 = 1
	num8 = 0
	num6 = NumberSequenceKeypoint.new(num7, num8)
	tbl14.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), num6 })
	tbl14.Lifetime = NumberRange.new(0.4, 0.9)
	tbl14.Speed = NumberRange.new(18, 34)
	tbl14.SpreadAngle = Vector2.new(75, 75)
	tbl14.EmissionDirection = Enum.NormalId.Top
	local var46 = Instance.new("ParticleEmitter")
	var46.Enabled = false
	for k7, v7 in pairs(tbl14) do
		var46[k7] = v7
	end

	var46.Parent = var45
	local num9 = 255
	num8 = 150
	local num10 = 60
	local tbl15 = {
		Texture = "rbxassetid://128755660236746",
		LightEmission = 1,
		Color = ColorSequence.new(Color3.fromRGB(255, 220, 130), Color3.fromRGB(num9, num8, num10)),
		Drag = 3,
	}

	num8 = 1
	num10 = 0
	num9 = NumberSequenceKeypoint.new(num8, num10)
	tbl15.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.1), num9 })
	tbl15.Lifetime = NumberRange.new(0.6, 1.1)
	tbl15.Speed = NumberRange.new(8, 18)
	tbl15.SpreadAngle = Vector2.new(180, 180)
	tbl15.Rotation = NumberRange.new(0, 360)
	tbl15.RotSpeed = NumberRange.new(-180, 180)
	tbl14 = Instance.new("ParticleEmitter")
	tbl14.Enabled = false
	for k8, v8 in pairs(tbl15) do
		tbl14[k8] = v8
	end

	tbl14.Parent = var45
	local num11 = 60
	num10 = 52
	local num12 = 48
	local tbl16 = {
		Texture = "rbxasset://textures/particles/smoke_main.dds",
		LightInfluence = 1,
		Color = ColorSequence.new(Color3.fromRGB(110, 92, 82), Color3.fromRGB(num11, num10, num12)),
		Drag = 4,
	}

	num10 = 1
	num12 = 6
	tbl16.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(num10, num12) })
	num10 = 1
	num12 = 1
	num11 = NumberSequenceKeypoint.new(num10, num12)
	tbl16.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), num11 })
	tbl16.Lifetime = NumberRange.new(0.6, 1.2)
	tbl16.Speed = NumberRange.new(10, 16)
	tbl16.SpreadAngle = Vector2.new(5, 180)
	tbl16.EmissionDirection = Enum.NormalId.Right
	tbl16.Rotation = NumberRange.new(0, 360)
	tbl15 = Instance.new("ParticleEmitter")
	tbl15.Enabled = false
	for k9, v9 in pairs(tbl16) do
		tbl15[k9] = v9
	end

	tbl15.Parent = var45
	tbl16 = Instance.new("Attachment")
	tbl16.Parent = var21
	local var47 = Instance.new("ParticleEmitter")
	var47.Enabled = false
	var47.Texture = "rbxassetid://128755660236746"
	var47.LightEmission = 1
	local num13 = 255
	local num14 = 220
	num12 = 140
	var47.Color = ColorSequence.new(Color3.fromRGB(num13, num14, num12))
	local num15 = 1
	local num16 = 0
	var47.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.5, 0.5),
		NumberSequenceKeypoint.new(num15, num16),
	})

	var47.Lifetime = NumberRange.new(0.4, 0.7)
	var47.Speed = NumberRange.new(-6, -4)
	var47.Shape = Enum.ParticleEmitterShape.Sphere
	var47.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	var47.Rotation = NumberRange.new(0, 360)
	var47.Parent = tbl16
	num14 = {
		Shape = Enum.PartType.Cylinder,
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(150, 90, 30),
		Transparency = 1,
		Size = Vector3.new(0.2, 4, 4),
	}

	num14.CFrame = CFrame.new(var25) * CFrame.Angles(0, 0, 1.5707963267948966)
	local var48 = fxPart(var44, "Shockwave", num14)
	num12 = {
		Shape = Enum.PartType.Ball,
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(255, 205, 130),
		Transparency = 1,
		Size = Vector3.new(2, 2, 2),
	}

	num12.CFrame = CFrame.new(var25)
	local var49 = fxPart(var44, "Flash", num12)
	num13 = fxPart(var44, "Charge", {
		Material = Enum.Material.Neon,
		Color = tbl1.molten,
		Transparency = 1,
		Size = Vector3.new(3, 0.6, 2),
		CFrame = CFrame.new(var25 + Vector3.new(0, 0.3, 0)),
	})

	num14 = fxPart(var44, "Pour", {
		Material = Enum.Material.Neon,
		Color = tbl1.molten,
		Transparency = 1,
		Size = Vector3.new(0.6, 0.6, 1),
	})

	num12 = Instance.new("PointLight")
	num12.Color = Color3.fromRGB(255, 150, 70)
	num12.Range = 26
	num12.Brightness = 0.3
	num12.Shadows = false
	num12.Parent = var49
	num16 = Instance.new("Sound")
	num16.SoundId = "rbxasset://sounds/metal.ogg"
	num16.PlaybackSpeed = 0.55
	num16.Volume = 0.9
	num16.RollOffMaxDistance = 110
	num16.RollOffMinDistance = 12
	num16.Parent = var15
	local var50 = Instance.new("Sound")
	var50.SoundId = "rbxasset://sounds/action_jump_land.mp3"
	var50.PlaybackSpeed = 0.45
	var50.Volume = 1
	var50.RollOffMaxDistance = 110
	var50.RollOffMinDistance = 12
	var50.Parent = var15
	local num17 = 0
	local num18 = 0
	var2:BindToRenderStep("StarforgeShake", Enum.RenderPriority.Camera.Value + 1, function()
		local var4 = os.clock()
		if var4 < num17 then
			local var5 = workspace.CurrentCamera
			local var6 = 0.0078539816339744835 * ((num17 - var4) / (num17 - num18))
			local var7 = var5.CFrame * CFrame.Angles((math.random() - 0.5) * var6, (math.random() - 0.5) * var6, (math.random() - 0.5) * var6 * 0.5)
			var5.CFrame = var7
		end
	end)

	local var51 = var12:FindFirstChild("Pipes")
	var51 = var51 and var12.Pipes:FindFirstChild("RouteAnchor")
	local function makeRoute(arg1)
		local tbl1 = {}
		local num1 = 0
		for i1 = 1, #arg1 - 1 do
			local var1 = (arg1[i1 + 1] - arg1[i1]).Magnitude
			table.insert(tbl1, { a = arg1[i1], b = arg1[i1 + 1], from = num1, len = var1 })
			num1 = num1 + var1
		end

		return { legs = tbl1, len = num1, last = arg1[#arg1] }
	end

	local function readRoute(arg1, arg2)
		local tbl1 = { arg2 }
		for i1 = 1, 40 do
			local var1 = var51
			var1 = var1 and var51:FindFirstChild(arg1 .. i1)
			if not var1 then
				break
			end

			table.insert(tbl1, var1.WorldPosition)
		end

		return 2 <= (#tbl1) and makeRoute(tbl1) or nil
	end

	local var52 = readRoute("I")
	local var53 = readRoute("O", var25 + Vector3.new(0, 0.3, 0))
	local tbl17 = { color = Color3.fromRGB(150, 148, 150), seconds = 3.2, minSpeed = 30 }
	local tbl18 = { iron = tbl17 }
	tbl18.star = { color = tbl1.ingot, seconds = 2.2, minSpeed = 18 }
	tbl17 = {}
	local var54 = var4:get("starforge")
	local var55 = (var54 or {}).queued or 0
	local function launch(arg1, arg2)
		if not arg1 or 24 <= (#tbl17) then
			return
		end

		local var1 = fxPart(var44, "Bar", {
			Material = Enum.Material.Metal,
			Color = arg2.color,
			Size = Vector3.new(0.9, 0.55, 1.5),
			Transparency = 1,
		})

		table.insert(tbl17, {
			part = var1,
			route = arg1,
			d = 0,
			speed = math.max(arg2.minSpeed, arg1.len / arg2.seconds),
		})
	end

	var4:getChangedSignal("starforge"):Connect(function()
		local var1 = var4:get("starforge")
		local var2 = (var1 or {}).queued or 0
		var1 = var2 - var55
		var55 = var2
		if 0 < var1 then
			if var52 then
				local var6 = var13.Character
				local var7 = var6
				var7 = var7 and var6:FindFirstChild("HumanoidRootPart")
				if (var7 and (var7.Position - var25).Magnitude or math.huge) < 220 then
					for i1 = 0, math.min(var1, 5) - 1 do
						task.delay(i1 * 0.35, launch, var52, tbl18.iron)
					end
				end
			end
		end
	end)

	var54 = function()
		if not var22 then
			return
		end

		local var1 = Instance.new("NumberValue")
		local var2 = var25 + Vector3.new(1.5, 0.6, 0)
		local var4 = var22.WorldPosition
		local var5 = fxPart(var44, "Starmetal", { Material = Enum.Material.Metal, Color = tbl1.ingot, Size = Vector3.new(2.4, 0.8, 1.2) })
		var1.Changed:Connect(function(arg1)
			var5.CFrame = CFrame.new(var2:Lerp(var4, arg1) + Vector3.new(0, math.sin(arg1 * 3.1415926535897931) * 6, 0)) * CFrame.Angles(arg1 * 5, arg1 * 3, 0)
			var5.Transparency = 0.85 < arg1 and (arg1 - 0.85) / 0.15 or 0
		end)

		local var6 = var3:Create(var1, TweenInfo.new(0.55, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), { Value = 1 })
		var6.Completed:Connect(function()
			var5:Destroy()
			var1:Destroy()
		end)

		var6:Play()
	end

	local num19 = -math.huge
	local var56 = nil
	local function impact(arg1)
		local var1 = var13.Character
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
		local var5 = var2 and (var2.Position - var25).Magnitude or math.huge
		var2 = var4:get("settings")
		local var8 = var2
		if var8 then
			var8 = var2.particles == false
		end

		if not var8 then
			var46:Emit(45)
			tbl14:Emit(14)
			tbl15:Emit(16)
		end

		var48.Size = Vector3.new(0.2, 4, 4)
		var48.Transparency = 0.35
		var3:Create(var48, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Size = Vector3.new(0.2, 30, 30), Transparency = 1 }):Play()
		var49.Size = Vector3.new(2, 2, 2)
		var49.Transparency = 0.25
		var3:Create(var49, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Size = Vector3.new(7, 7, 7), Transparency = 1 }):Play()
		num12.Brightness = 4
		var3:Create(num12, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Brightness = 0.3 }):Play()
		var15.Color = tbl1.faceHot
		local var9 = TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local tbl2 = { Color = var31 }
		var3:Create(var15, var9, tbl2):Play()
		for k1, v1 in ipairs(tbl3) do
			v1.Color = Color3.fromRGB(255, 225, 150)
		end

		if var42 then
			var2 = var4:get("settings")
			var8 = var2
			if var8 then
				var8 = var2.particles == false
			end

			if not var8 then
				var42:Emit(6)
			end
		end

		for k2, v2 in ipairs(tbl9) do
			v2.part.Color = Color3.fromRGB(210, 150, 60)
		end

		if var5 < 220 then
			var2 = var13.Character
			var8 = var2
			var8 = var8 and var2:FindFirstChild("HumanoidRootPart")
			var1 = false
			if var8 ~= nil then
				var1 = var7.inRoom(var8.Position)
			end

			if var1 then
				num16:Play()
				var50:Play()
			end

			if var53 then
				launch(var53, tbl18.star)
			else
				var54()
			end

			if arg1 then
				launch(var52, tbl18.iron)
			end
		end

		if var5 < 45 then
			var2 = var13.Character
			var8 = var2
			var8 = var8 and var2:FindFirstChild("HumanoidRootPart")
			var1 = false
			if var8 ~= nil then
				var1 = var7.inRoom(var8.Position)
			end

			if var1 then
				var1 = os.clock()
				num18 = var1
				var2 = os.clock() + 0.28
				num17 = var2
			end
		end
	end

	local function along(arg1, arg2)
		for k1, v1 in ipairs(arg1.legs) do
			if arg2 > v1.from + v1.len then
				continue
			end

			local var1 = v1.b
			local var2 = (arg2 - v1.from) / math.max(v1.len, 0.001)
			return v1.a:Lerp(var1, var2)
		end

		return arg1.last
	end

	var2.RenderStepped:Connect(function()
		local var84
		local var1 = var4:get("starforge")
		var1 = var1 or {}
		local str1 = "upgrades"
		local var2 = var7.paceFor(var4:get(str1)).spacing
		local var8 = var1.queued or 0
		local var9 = var1.nextAt or 0
		local var10 = workspace:GetServerTimeNow()
		local var11 = nil
		str1 = nil
		if 0 < var8 then
			local var15 = math.max(0, (math.ceil((var10 - var9) / var2 - 1e-09)))
			if var15 < var8 then
				var11 = var9 + var15 * var2
			end

			if 1 <= var15 then
				str1 = var9 + math.min(var15 - 1, var8 - 1) * var2
			end
		end

		if str1 and num19 < str1 then
			num19 = str1
			var56 = str1
			if var10 - str1 < 0.4 then
				local var17 = var13.Character
				local var18 = var17
				var18 = var18 and var17:FindFirstChild("HumanoidRootPart")
				if (var18 and (var18.Position - var25).Magnitude or math.huge) < 220 then
					impact(var11 ~= nil)
				end
			end
		end

		local num5 = 0
		local num6 = 0
		local var22 = var56 and var10 - var56 or math.huge
		if var11 then
			local var31 = var11 - var10
			if var31 <= 0.12 then
				local var32 = 1 - var31 / 0.12
				num5 = 9 * var32 * var32
				num6 = 1
			else
				if var31 <= 0.22 then
					num5 = (math.random() - 0.5) * 0.08
					num6 = 1
				else
					if var22 < 0.3 then
						num5 = 9 - math.sin(var22 / 0.3 * 3.1415926535897931) * 0.8
					else
						if var56 then
							local var37 = var56 + 0.3
							local var38 = var11 - 0.12 - 0.1
							if var37 < var38 then
								local var39 = math.clamp((var10 - var37) / (var38 - var37), 0, 1)
								var39 = var39 or 1
							end

							local num7 = 1
							num7 = 1 - (1 - num7) * (1 - num7)
							num5 = 9 * (1 - num7)
							num6 = num7
						end
					end
				end
			end
		else
			if var22 < 0.3 then
				num5 = 9 - math.sin(var22 / 0.3 * 3.1415926535897931) * 0.8
			else
				if var22 < 1.5 then
					local var41 = (var22 - 0.3) / 1.2
					num5 = 9 * (1 - (1 - (1 - var41) * (1 - var41)))
				end
			end
		end

		local var42 = -num5
		var14:PivotTo(CFrame.new(0, var42, 0) * var26)
		local var45 = var27.Y - num5
		for k1, v1 in ipairs(tbl4) do
			local var46 = var30
			local var48 = var45 + 1.6
			local var49 = math.max(0.2, var46 - var48)
			v1.part.Size = Vector3.new(0.45, var49, 0.45)
			v1.part.CFrame = CFrame.new(v1.x, var48 + var49 / 2, v1.z)
		end

		local var50 = tbl1.emblemDim:Lerp(tbl1.emblemHot, num6)
		for k2, v2 in ipairs(tbl3) do
			local var51 = v2.Color:Lerp(var50, 0.25)
			v2.Color = var51
		end

		local var52 = var4:get("settings")
		local var54 = var52
		local var55 = var47
		if var54 then
			var54 = var52.particles == false
		end

		local var58 = not var54
		if var58 then
			var58 = false
			if 0.05 < num6 then
				var58 = false
				if num6 < 1 then
					var58 = var11 ~= nil
				end
			end
		end

		var55.Enabled = var58
		var47.Rate = num6 * 30
		var55 = var11 and var11 - var10 or math.huge
		var52 = math.clamp((1.1 - var55) / 0.60000000000000009, 0, 1)
		var58 = var23 and var23.WorldPosition or var25
		var54 = Vector3.new(var52 * 1.4 + 0.8, var52 * 0.3 + 0.15, var52 * 0.5 + 0.5)
		if var20 and (var55 < 1.1 and 0.5 < var55) then
			local var60 = var20.WorldPosition
			local var61 = Vector3.new(var60.X, var58.Y + var54.Y, var60.Z)
			num14.Size = Vector3.new(0.5, 0.5, (math.max(0.1, (var60 - var61).Magnitude)))
			num14.CFrame = CFrame.lookAt((var60 + var61) / 2, var61, Vector3.new(1, 0, 0))
			num14.Transparency = 0.1
		else
			num14.Transparency = 1
		end

		if var55 < 1.1 then
			local var62 = math.clamp((0.46 - var55) / 0.2, 0, 1)
			num13.Size = var54
			num13.CFrame = CFrame.new(var58:Lerp(var25, var62 * var62 * (3 - var62 * 2)) + Vector3.new(0, var54.Y / 2, 0)) * var24
			num13.Transparency = 0.05
		else
			num13.Transparency = 1
		end

		local var63 = os.clock()
		local var64 = math.min(var63 - var43, 0.1)
		var43 = var63
		for i1 = #tbl17, 1, -1 do
			local var65 = tbl17[i1]
			local var66 = var65.d + var64 * var65.speed
			var65.d = var66
			var66 = var65.route.len - var65.d
			local var67
			if var66 <= 0 then
				var65.part:Destroy()
				table.remove(tbl17, i1)
			else
				local var68 = along(var65.route, (math.min(var65.d + 0.6, var65.route.len)))
				var67 = along(var65.route, var65.d)
				local var69 = var68 - var67
				if 0.001 < var69.Magnitude then
					local var70 = var65.part
					local var71 = CFrame.lookAt
					local var72 = var67
					local var73 = var68
					var70.CFrame = var71(var72, var73, if 0.9 < math.abs(var69.Unit.Y) then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0))
				else
					var65.part.CFrame = CFrame.new(var67)
				end

				var65.part.Transparency = var65.d < 0.8 and 1 - var65.d / 0.8 or (var66 < 1.2 and 1 - var66 / 1.2 or 0)
			end
		end

		local var74 = 9 - num5
		for k3, v3 in ipairs(tbl5) do
			v3.model:PivotTo(v3.base * CFrame.Angles(v3.ratio * (var74 * 0.55 + var63 * 0.08), 0, 0))
		end

		for k4, v4 in ipairs(tbl7) do
			local var75 = v4.angle + var64 * v4.speed * (num6 * 2.5 + 1)
			v4.angle = var75
			v4.model:PivotTo(v4.base * CFrame.Angles(0, v4.angle, 0))
		end

		local var76 = math.sin(var63 * 2.4) * 0.15 + 0.85
		for k5, v5 in ipairs(tbl9) do
			v5.part.Color = v5.part.Color:Lerp(Color3.new(v5.base.R * var76, v5.base.G * var76, v5.base.B * var76), 0.08)
		end

		local var77
		if 0 < num1 then
			if 0.1 < num6 and (var11 and 0.16 - num6 * 0.1 < var63 - num2) then
				num2 = var63
				local var78 = fxPart(var44, "Pulse", {
					Material = Enum.Material.Neon,
					Color = Color3.fromRGB(190, 140, 50),
					Size = Vector3.new(0.7, 0.7, 0.7),
				})

				table.insert(tbl12, { part = var78, d = 0 })
			end

			for i2 = #tbl12, 1, -1 do
				local var79 = tbl12[i2]
				var77 = var79.d + var64 * (num6 * 30 + 22)
				var79.d = var77
				if num1 <= var79.d then
					var79.part:Destroy()
					table.remove(tbl12, i2)
				else
					local var80 = var79.d
					local var81 = CFrame.new(alongRoute(var80))
					var77 = var79.part
					var77.CFrame = var81 * CFrame.Angles(var79.d, var79.d * 0.7, 0)
				end
			end
		end

		for k6, v6 in ipairs(tbl13) do
			if v6.kind == 1 then
				local var83 = num6
				if not var83 then
					var83 = math.clamp(var74 / 9, 0, 1)
				end
			end

			v6.frame.Rotation = -70 + 140 * var84 + (math.random() - 0.5) * 3 * var84
		end
	end)
end }

--- Workspace.TrailVendor.Booth..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.TrailVendor.Booth2..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.TrailVendor.Booth3..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.TrailVendor.Booth4..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.TrailVendor.Booth5..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.Merchants.PotionBooth1..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.Merchants.PotionBooth2..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.Merchants.PotionBooth3..Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var2 = nil
var2 = success and result
local var3 = var1:WaitForChild("Humanoid")
local var4 = script:FindFirstChild("ScaleDampeningPercent")
local success, result = pcall(function()
	local str1 = "UserAnimationAbilityManagerFixed"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var5 = nil
local var6 = nil
local var7 = nil
local var8 = nil
var5 = success and result
function resetManagerListeners()
	if var6 then
		var6:Disconnect()
		var6 = nil
	end

	if var7 then
		var7:Disconnect()
		var7 = nil
	end

	if var8 then
		var8:Disconnect()
		var8 = nil
	end
end

local var9 = nil
local var10 = nil
function teardownManager()
	resetManagerListeners()
	var9 = nil
	var10 = nil
end

function processIfManagerBelongsToCharacter(arg1)
	if arg1.RootPart == var1.PrimaryPart then
		if var10 ~= arg1 then
			resetManagerListeners()
			var9 = arg1.GroundSensor
			var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var6:Disconnect()
					var6 = nil
				end
			end)

			var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
				if processIfManagerBelongsToCharacter(arg1) then
					var7:Disconnect()
					var7 = nil
				end
			end)

			var8 = arg1.AncestryChanged:Connect(function(_, arg2)
				if arg2 == nil then
					resetManagerListeners()
					lookForControllerManager()
				end
			end)

			var10 = arg1
		end

		return true
	end

	return false
end

function setupManager(arg1)
	var10 = arg1
	var9 = arg1.GroundSensor
	var6 = arg1:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		var9 = var10.GroundSensor
	end)

	var7 = arg1:GetPropertyChangedSignal("RootPart"):Connect(function()
		if arg1.RootPart ~= var1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)

	var8 = arg1.AncestryChanged:Connect(function(_, arg2)
		if arg2 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end

function lookForControllerManager()
	if var5 then
		local var4 = var1:FindFirstChildOfClass("ControllerManager")
		if var4 then
			if var4.RootPart == var1.PrimaryPart then
				setupManager(var4)
				return
			end

			local var6 = nil
			var4:GetPropertyChangedSignal("RootPart"):Connect(function()
				if var4.RootPart == var1.PrimaryPart then
					var6:Disconnect()
					setupManager(var4)
				end
			end)

			return
		end

		local var7 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") then
				var7:Disconnect()
				lookForControllerManager()
			end
		end)

		return
	end

	var9 = nil
	var10 = nil
	local var11 = var1:FindFirstChildOfClass("ControllerManager")
	if var11 then
		processIfManagerBelongsToCharacter(var11)
	end

	if var10 == nil then
		local var13 = nil
		var1.ChildAdded:Connect(function(arg1)
			if arg1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(arg1) then
				var13:Disconnect()
				var13 = nil
			end
		end)

	end
end

lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(arg1, arg2)
	if arg1 == nil or arg2 == nil then
		return 0
	end

	for i1 = 1, arg1.count do
		if arg1[i1].anim.AnimationId ~= arg2.AnimationId then
			continue
		end

		return i1
	end

	return 0
end

local tbl1 = {}
local tbl2 = {}
function configureAnimationSet(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 0
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local var7 = v2:FindFirstChild("Weight")
			local num3 = 1
			if var7 ~= nil then
				num3 = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			num1 = tbl1[arg1].count
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			tbl1[arg1][num1].weight = num3
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildAdded:connect(fn4))
			fn4 = function(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.ChildRemoved:connect(fn4))
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			if tbl2[v4[i1].anim.AnimationId] ~= nil then
				continue
			end

			var3:LoadAnimation(v4[i1].anim)
			tbl2[v4[i1].anim.AnimationId] = true
		end
	end
end

function configureAnimationSetOld(arg1, arg2)
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local bool1 = true
	local success, result = pcall(function()
		bool1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not success then
		bool1 = true
	end

	local var2 = script:FindFirstChild(arg1)
	local var4
	local var5
	if bool1 and var2 ~= nil then
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildAdded:connect(var5))
		var5 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var2.ChildRemoved:connect(var5))
		local num1 = 1
		for k2, v2 in pairs(var2:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn4(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn4))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	local var8
	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end

	for k4, v4 in pairs(tbl1) do
		for i1 = 1, v4.count do
			var3:LoadAnimation(v4[i1].anim)
		end
	end
end

local tbl3 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=507766666", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766951", weight = 1 },
		{ id = "http://www.roblox.com/asset/?id=507766388", weight = 9 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=507777826", weight = 10 } },
	run = { { id = "http://www.roblox.com/asset/?id=507767714", weight = 10 } },
	swim = { { id = "http://www.roblox.com/asset/?id=507784897", weight = 10 } },
	swimidle = { { id = "http://www.roblox.com/asset/?id=507785072", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=507765000", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=507767968", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=507765644", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=2506281703", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=507768375", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=522635514", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=522638767", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=507770239", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=507770453", weight = 10 } },
	dance = {
		{ id = "http://www.roblox.com/asset/?id=507771019", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507771955", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507772104", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=507776043", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776720", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507776879", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=507777268", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777451", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=507777623", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=507770818", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=507770677", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl3[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
local function getRigScale()
	return var1:GetScale()
end

success = ""
result = nil
local var11 = nil
local var12 = nil
local num1 = 1
local var13 = nil
local var14 = nil
success = if var3 then var3:FindFirstChildOfClass("Animator") else nil
local tbl4 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var15
local var16
if success then
	for k1, v1 in ipairs((success:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl3) do
	configureAnimationSet(k2, v2)
end

local bool1 = false
function stopAllAnimations()
	local var1 = success
	if tbl4[var1] ~= nil then
		if tbl4[var1] == false then
			var1 = "idle"
		end
	end

	if bool1 then
		bool1 = false
		var1 = "idle"
	end

	success = ""
	result = nil
	if var12 ~= nil then
		var12:disconnect()
	end

	if var11 ~= nil then
		var11:Stop()
		var11:Destroy()
		var11 = nil
	end

	if var14 ~= nil then
		var14:disconnect()
	end

	if var13 ~= nil then
		var13:Stop()
		var13:Destroy()
		var13 = nil
	end

	return var1
end

function getHeightScale()
	if var3 then
		if not var3.AutomaticScalingEnabled then
			return getRigScale()
		end

		local var1 = var3.HipHeight / 2
		if var4 == nil then
			var4 = script:FindFirstChild("ScaleDampeningPercent")
		end

		if var4 ~= nil then
			var1 = 1 + (var3.HipHeight - 2) * var4.Value / 2
		end

		return var1
	end

	return getRigScale()
end

local function setRunSpeed(arg1)
	local var2 = arg1 * 1.25 / getHeightScale()
	local num3 = 0.0001
	local num4 = 0.0001
	local num5 = 1
	if var2 <= 0.5 then
		num3 = 1
		num5 = var2 / 0.5
	else
		if var2 < 1 then
			local var4 = (var2 - 0.5) / 0.5
			num3 = 1 - var4
			num4 = var4
		else
			num4 = 1
			num5 = var2 / 1
		end
	end

	var11:AdjustWeight(num3)
	var13:AdjustWeight(num4)
	var11:AdjustSpeed(num5)
	var13:AdjustSpeed(num5)
end

function setAnimationSpeed(arg1)
	if success == "walk" then
		setRunSpeed(arg1)
		return
	end

	if arg1 ~= num1 then
		num1 = arg1
		var11:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		if success == "walk" then
			if var13.Looped ~= true then
				var13.TimePosition = 0
			end

			if var11.Looped == true then
				return
			end

			var11.TimePosition = 0
			return
		end

		local var1 = success
		if tbl4[var1] ~= nil then
			if tbl4[var1] == false then
				var1 = "idle"
			end
		end

		if bool1 then
			if var11.Looped then
				return
			end

			bool1 = false
			var1 = "idle"
		end

		playAnimation(var1, 0.15, var3)
		setAnimationSpeed(num1)
	end
end

function rollAnimation(arg1)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	return num1
end

local function switchToAnim(arg1, arg2, arg3, arg4)
	if arg1 ~= result then
		if var11 ~= nil then
			var11:Stop(arg3)
			var11:Destroy()
		end

		if var13 ~= nil then
			var13:Stop(arg3)
			var13:Destroy()
			var13 = nil
		end

		num1 = 1
		var11 = arg4:LoadAnimation(arg1)
		var11.Priority = Enum.AnimationPriority.Core
		var11:Play(arg3)
		success = arg2
		result = arg1
		if var12 ~= nil then
			var12:disconnect()
		end

		var12 = var11.KeyframeReached:connect(keyFrameReachedFunc)
		if arg2 == "walk" then
			var13 = arg4:LoadAnimation(tbl1.run[rollAnimation("run")].anim)
			var13.Priority = Enum.AnimationPriority.Core
			var13:Play(arg3)
			if var14 ~= nil then
				var14:disconnect()
			end

			var14 = var13.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end

function playAnimation(arg1, arg2, arg3)
	switchToAnim(tbl1[arg1][rollAnimation(arg1)].anim, arg1, arg2, arg3)
	bool1 = false
end

function playEmote(arg1, arg2, arg3)
	switchToAnim(arg1, arg1.Name, arg2, arg3)
	bool1 = true
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var3)
	end
end

local var17 = nil
local var18 = nil
local var19 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var2 = tbl1[arg1][rollAnimation(arg1)].anim
	if var17 ~= var2 then
		if var18 ~= nil then
			var18:Stop()
			var18:Destroy()
			arg2 = 0
		end

		var18 = arg3:LoadAnimation(var2)
		if arg4 then
			var18.Priority = arg4
		end

		var18:Play(arg2)
		str2 = arg1
		var17 = var2
		var19 = var18.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var19 ~= nil then
		var19:disconnect()
	end

	str2 = ""
	var17 = nil
	if var18 ~= nil then
		var18:Stop()
		var18:Destroy()
		var18 = nil
	end

	return var1
end

function onRunning(arg1)
	local var5 = getHeightScale()
	if var9 ~= nil then
		if var3.EvaluateStateMachine == false then
			local var14 = var9.SensedPart
			local var15 = var3.RootPart
			if var14 then
				local var16 = var15.AssemblyLinearVelocity
				local var17 = var14:GetVelocityAtPosition(var9.HitFrame.Position)
				local var20 = var10.MovingDirection.Magnitude
				local var21 = Vector3.new(var16.X - var17.X, 0, var16.Z - var17.Z).Magnitude
				if var20 < 0.1 then
					var21 = 0
					var20 = 0
				elseif 1 < var20 then
					var20 = 1
				end

				arg1 = var21 * var20
			end
		end
	end

	local var23 = bool1
	if var23 then
		var23 = var3.MoveDirection == Vector3.new(0, 0, 0)
	end

	if (var23 and var3.WalkSpeed / var5 or 0.75) * var5 < arg1 then
		playAnimation("walk", 0.2, var3)
		setAnimationSpeed(arg1 / 16)
		str1 = "Running"
		return
	end

	if tbl4[success] == nil and (not bool1) then
		playAnimation("idle", 0.2, var3)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var3)
	num2 = 0.31
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var3)
	setAnimationSpeed(arg1 / getHeightScale() / 5)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	arg1 = arg1 / getHeightScale()
	if 1 < arg1 then
		playAnimation("swim", 0.4, var3)
		setAnimationSpeed(arg1 / 10)
		str1 = "Swimming"
		return
	end

	playAnimation("swimidle", 0.4, var3)
	str1 = "Standing"
end

result = "None"
function animateTool()
	if result == "None" then
		playToolAnimation("toolnone", 0.1, var3, Enum.AnimationPriority.Idle)
		return
	end

	if result == "Slash" then
		playToolAnimation("toolslash", 0, var3, Enum.AnimationPriority.Action)
		return
	end

	if result == "Lunge" then
		playToolAnimation("toollunge", 0, var3, Enum.AnimationPriority.Action)
		return
	end
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local num3 = 0
local num4 = 0
function stepAnimate(arg1)
	local var2 = arg1 - num3
	num3 = arg1
	if 0 < num2 then
		local var4 = num2 - var2
		num2 = var4
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.2, var3)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var3)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.2, var3)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
			end
		end
	end

	local var7 = var1:FindFirstChildOfClass("Tool")
	if var7 then
		if var7:FindFirstChild("Handle") then
			local var10 = getToolAnim(var7)
			if var10 then
				result = var10.Value
				var10.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				result = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	result = "None"
	var17 = nil
	num4 = 0
end

var3.Died:connect(onDied)
var3.Running:connect(onRunning)
var3.Jumping:connect(onJumping)
var3.Climbing:connect(onClimbing)
var3.GettingUp:connect(onGettingUp)
var3.FreeFalling:connect(onFreeFall)
var3.FallingDown:connect(onFallingDown)
var3.Seated:connect(onSeated)
var3.PlatformStanding:connect(onPlatformStanding)
var3.Swimming:connect(onSwimming)
if not var2 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str2 = ""
		if string.sub(arg1, 1, 3) == "/e " then
			str2 = string.sub(arg1, 4)
		else
			if string.sub(arg1, 1, 7) == "/emote " then
				str2 = string.sub(arg1, 8)
			end
		end

		if str1 == "Standing" and tbl4[str2] ~= nil then
			playAnimation(str2, 0.1, var3)
		end
	end)

end

local var20 = script:WaitForChild("PlayEmote")
var20.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var3)
		return true, var11
	end

	if typeof(arg1) == "Instance" and arg1:IsA("Animation") then
		playEmote(arg1, 0.1, var3)
		return true, var11
	end

	return false
end

if var1.Parent ~= nil then
	playAnimation("idle", 0.1, var3)
end

while var1.Parent ~= nil do
	local var21, var22 = wait(0.1)
	stepAnimate(var22)
end

--- Workspace.hspspjl.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- ReplicatedFirst.LoadingScreen [LocalScript]
-- y u r i

game:GetService("ReplicatedFirst"):RemoveDefaultLoadingScreen()
Color3.fromRGB(255, 214, 64)
local var1 = game:GetService("Players").LocalPlayer
var1:SetAttribute("LoadingView", true)
local tbl1 = {}
local var2 = var1:WaitForChild("PlayerGui")
local var3 = game:GetService("ContentProvider")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("RunService")
local var6 = game:GetService("TweenService")
local str1 = "Loading"
local var7 = Font.new("rbxasset://fonts/families/PressStart2P.json")
local var8 = Color3.fromRGB(26, 18, 14)
local var9 = os.clock()
local function hideHud(arg1)
	if arg1:IsA("ScreenGui") and arg1.Name == "Main" then
		arg1.Enabled = false
		tbl1[arg1] = true
	end
end

for k1, v1 in ipairs(var2:GetChildren()) do
	if not v1:IsA("ScreenGui") then
		continue
	end

	if v1.Name ~= "Main" then
		continue
	end

	v1.Enabled = false
	tbl1[v1] = true
end

local var10 = var2.ChildAdded:Connect(hideHud)
local var11 = Instance.new("ScreenGui")
var11.Name = "LoadingScreen"
var11.IgnoreGuiInset = true
var11.ResetOnSpawn = false
var11.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
var11.DisplayOrder = 1000
var11.Parent = var2
local var12 = Instance.new("Frame")
var12.Name = "Backdrop"
var12.Size = UDim2.fromScale(1, 1)
var12.BackgroundColor3 = var8
var12.BorderSizePixel = 0
var12.Active = true
var12.ZIndex = 1
var12.Parent = var11
local var13 = Instance.new("Frame")
var13.Name = "Vignette"
var13.Size = UDim2.fromScale(1, 1)
var13.BackgroundColor3 = Color3.new(0, 0, 0)
var13.BackgroundTransparency = 1
var13.BorderSizePixel = 0
var13.ZIndex = 2
var13.Parent = var11
local var14 = Instance.new("UIGradient")
var14.Rotation = 90
local num1 = 1
local num2 = 0.3
var14.Transparency = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 0.3),
	NumberSequenceKeypoint.new(0.28, 1),
	NumberSequenceKeypoint.new(0.72, 1),
	NumberSequenceKeypoint.new(num1, num2),
})

var14.Parent = var13
local var15 = Instance.new("TextLabel")
var15.Name = "Like"
var15.BackgroundTransparency = 1
var15.AnchorPoint = Vector2.new(0.5, 0.5)
var15.Position = UDim2.fromScale(0.5, 0.84)
var15.Size = UDim2.fromScale(0.92, 0.08)
var15.FontFace = var7
var15.TextScaled = true
var15.TextColor3 = Color3.new(1, 1, 1)
var15.Text = "Like the Game for More Updates!"
var15.ZIndex = 5
var15.Parent = var11
local var16 = Instance.new("UITextSizeConstraint")
var16.MaxTextSize = 52
var16.Parent = var15
local var17, var18 = Color3.new(0, 0, 0)
local var19 = Instance.new("UIStroke")
var19.Thickness = 4
var19.Color = var17
var19.Transparency = var18 or 0
var19.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
var19.Parent = var15
var17 = Instance.new("UIScale")
var17.Parent = var15
var18 = Instance.new("ImageLabel")
var18.Name = "Logo"
var18.BackgroundTransparency = 1
var18.Image = "rbxassetid://78581126985778"
var18.ScaleType = Enum.ScaleType.Fit
var18.AnchorPoint = Vector2.new(0.5, 0.5)
var18.Position = UDim2.fromScale(0.5, 0.45)
var18.Size = UDim2.fromScale(0.56, 0.32)
var18.ZIndex = 5
var18.Parent = var11
var19 = Instance.new("UIAspectRatioConstraint")
var19.AspectRatio = 2.6666666666666665
var19.Parent = var18
num1 = Instance.new("Frame")
num1.Name = "Track"
num1.AnchorPoint = Vector2.new(0.5, 0.5)
num1.Position = UDim2.fromScale(0.5, 0.74)
num1.Size = UDim2.fromScale(0.44, 0.055)
num1.BackgroundColor3 = Color3.new(0, 0, 0)
num1.BackgroundTransparency = 0.45
num1.BorderSizePixel = 0
num1.ZIndex = 5
num1.Parent = var11
num2 = Instance.new("UICorner", num1)
num2.CornerRadius = UDim.new(1, 0)
num2 = Color3.new(1, 1, 1)
local var20 = Instance.new("UIStroke")
var20.Thickness = 2
var20.Color = num2
var20.Transparency = 0.25
var20.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
var20.Parent = num1
num2 = Instance.new("Frame")
num2.Name = "Fill"
num2.Size = UDim2.fromScale(0, 1)
num2.BackgroundColor3 = Color3.new(1, 1, 1)
num2.BorderSizePixel = 0
num2.ZIndex = 6
num2.Parent = num1
var20 = Instance.new("UICorner", num2)
var20.CornerRadius = UDim.new(1, 0)
var20 = Instance.new("UIGradient")
var20.Rotation = 90
local num3 = 255
local num4 = 255
local num5 = 255
local var21 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num3, num4, num5))
num4 = 236
num5 = 238
local num6 = 244
local var22 = ColorSequenceKeypoint.new(0.55, Color3.fromRGB(num4, num5, num6))
num5 = 190
num6 = 196
local num7 = 208
num3 = 1
var20.Color = ColorSequence.new({ var21, var22, ColorSequenceKeypoint.new(num3, Color3.fromRGB(num5, num6, num7)) })
var20.Parent = num2
local var23 = Instance.new("TextLabel")
var23.Name = "Status"
var23.BackgroundTransparency = 1
var23.AnchorPoint = Vector2.new(0.5, 0.5)
var23.Position = UDim2.fromScale(0.5, 0.5)
var23.Size = UDim2.fromScale(0.9, 0.62)
var23.FontFace = var7
var23.TextScaled = true
var23.TextColor3 = Color3.new(1, 1, 1)
var23.Text = "Loading"
var23.ZIndex = 7
var23.Parent = num1
local var24, var25 = Color3.new(0, 0, 0)
var22 = Instance.new("UIStroke")
var22.Thickness = 2.5
var22.Color = var24
var22.Transparency = var25 or 0
var22.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
var22.Parent = var23
var24 = Instance.new("BlurEffect")
var24.Name = "LoadingBlur"
var24.Size = 9
var24.Parent = var4
local bool1 = false
var22 = 0
var25 = 0.08
num5 = false
task.spawn(function()
	pcall(function()
		var3:PreloadAsync({ var18 })
	end)
end)

num3 = var5.RenderStepped:Connect(function(arg1)
	local var1 = os.clock() - var9
	var18.Rotation = math.sin(var1 * 1.4) * 3
	var18.Position = UDim2.fromScale(0.5, math.sin(var1 * 1.9) * 0.01 + 0.45)
	var17.Scale = math.sin(var1 * 2.6) * 0.035 + 1
	if not bool1 then
		var23.Text = str1 .. string.rep(".", math.floor(var1 * 3) % 4)
	end

	local var2 = var22 + (var25 - var22) * math.min(1, arg1 * 5)
	var22 = var2
	num2.Size = UDim2.fromScale(math.clamp(var22, 0, 1), 1)
end)

num4 = function()
	local var2 = workspace:FindFirstChild("Stairs")
	if not var2 then
		return nil
	end

	local num1 = 0
	local num2 = 0
	local num3 = 0
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("Model") then
			continue
		end

		local var3 = v1:GetPivot().Position
		num1 = num1 + var3.X
		num2 = num2 + var3.Z
		num3 = num3 + 1
	end

	local num4 = -math.huge
	local num5 = math.huge
	for k2, v2 in ipairs(var2:GetDescendants()) do
		if not v2:IsA("BasePart") then
			continue
		end

		if not v2:GetAttribute("StairIndex") then
			continue
		end

		num4 = math.max(num4, v2.Position.Y)
		num5 = math.min(num5, v2.Position.Y)
	end

	if num3 == 0 or num4 == -math.huge then
		return nil
	end

	return { x = num1 / num3, z = num2 / num3, top = num4 + 8, bottom = num5 + 18 }
end

if not game:IsLoaded() then
	num7 = true
	task.spawn(function()
		game.Loaded:Wait()
		num7 = false
	end)

	local var26 = math.max(var3.RequestQueueSize, 1)
	while num7 and os.clock() - var9 < 20 do
		task.wait(0.1)
	end
end

(1 - math.clamp(var3.RequestQueueSize / var26, 0, 1)) * 0.55 + 0.08
num7 = num4()
local var28 = os.clock()
if num7 then
	local var29 = os.clock()
	var5:BindToRenderStep("LoadingFlyDown", Enum.RenderPriority.Camera.Value + 1, function()
		local var2 = workspace.CurrentCamera
		if not var2 then
			return
		end

		var2.CameraType = Enum.CameraType.Scriptable
		local var3 = os.clock() - var29
		var2.CFrame = CFrame.new(num7.x, num7.bottom + (num7.top - num7.bottom) * ((math.cos(var3 * 2 * 3.1415926535897931 / 44) + 1) / 2), num7.z) * CFrame.Angles(0, math.rad(var3 * 14), 0) * CFrame.Angles(-1.3613568165555769, 0, 0)
	end)

	var29 = TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	var6:Create(var12, var29, { BackgroundTransparency = 1 }):Play()
	var6:Create(var13, var29, { BackgroundTransparency = 0 }):Play()
	num5 = true
end

var2:WaitForChild("Main", (math.max(0.1, 20 - (os.clock() - var9))))
local var30 = var1.Character
while os.clock() - var9 < 20 and (not var30) or (not var30:FindFirstChild("HumanoidRootPart")) do
	task.wait(0.1)
end

while true do
	if os.clock() - var9 >= 75 then
		break
	end

	if var1:GetAttribute("DataReady") then
		break
	end

	if 25 < os.clock() - var9 then
	else
		if 10 < os.clock() - var9 then
		end
	end

	task.wait(0.1)
end

var30 = math.max(3 - (os.clock() - var9), num7 and 4 - (os.clock() - var28) or 0)
if 0 < var30 and os.clock() - var9 < 20 then
	task.wait((math.min(var30, 20 - (os.clock() - var9))))
end

var23.Text = "Ready!"
task.wait(0.35)
var1:SetAttribute("LoadingView", nil)
local var31 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
for k2, v2 in ipairs(var11:GetDescendants()) do
	local var33
	if v2:IsA("Frame") then
		var33 = v2
		var6:Create(var33, var31, { BackgroundTransparency = 1 }):Play()
	else
		if v2:IsA("ImageLabel") then
			var33 = v2
			var6:Create(var33, var31, { ImageTransparency = 1 }):Play()
		else
			if v2:IsA("TextLabel") then
				var33 = v2
				var6:Create(var33, var31, { TextTransparency = 1 }):Play()
			else
				var33 = "UIStroke"
				if not v2:IsA(var33) then
					continue
				end

				var33 = v2
				var6:Create(var33, var31, { Transparency = 1 }):Play()
			end
		end
	end
end

var6:Create(var24, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Size = 0 }):Play()
var12.Active = false
local var34 = var1.Character
local var35 = var34
local var36 = var34
local var37 = workspace.CurrentCamera
var35 = var35 and var34:FindFirstChild("HumanoidRootPart")
var36 = var36 and var34:FindFirstChildWhichIsA("Humanoid")
if num5 then
	var5:UnbindFromRenderStep("LoadingFlyDown")
end

if num5 and (var37 and var35) then
	var37.CameraType = Enum.CameraType.Scriptable
	local var38 = var35.Position + Vector3.new(0, 1.5, 0)
	local var39 = TweenInfo.new(1.5, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
	local var40 = var6:Create(var37, var39, { CFrame = CFrame.lookAt(var38 - var35.CFrame.LookVector * 12 + Vector3.new(0, 4, 0), var38) })
	var40:Play()
	var40.Completed:Wait()
end

if var37 then
	if var36 then
		var37.CameraSubject = var36
	end

	var37.CameraType = Enum.CameraType.Custom
end

var10:Disconnect()
for k3 in pairs(tbl1) do
	if not k3.Parent then
		continue
	end

	k3.Enabled = true
end

table.clear(tbl1)
task.wait(0)
num3:Disconnect()
var24:Destroy()
var11:Destroy()

