if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
        if type(f) == t then return f end
        return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function" or typeof(queueonteleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
    HookMeta = (typeof(hookmetamethod) == "function"),
    Firesignal = (typeof(firesignal) == "function"),
}
Services = setmetatable({}, {
        __index = function(self, name)
                local success, cache = pcall(function()
                        return cloneref(game:GetService(name))
                end)
                if success then
                        rawset(self, name, cache)
                        return cache
                else
                        error("Invalid Service: " .. tostring(name))
                end
        end
})
local Players = Services.Players
local Plr = Players.LocalPlayer
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local l,f={},"1log.txt";if isfile and isfile(f)then delfile(f)end;if writefile then writefile(f,"")end;function notyuri(...)local t=table.create(select("#",...))for i=1,select("#",...)do t[i]=tostring(select(i,...))end local s=("[%s] %s"):format(os.date("%H:%M:%S"),table.concat(t," "));l[#l+1]=s;if appendfile then appendfile(f,s.."\n")end end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true
Library.ShowCustomCursor = true
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "6pCsSbVd3E"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end

local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
}
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
}
function AddMultiDropdown(group, id, config)
    if type(group) == "string" then
        local selected = {}
        local dropdown = Options[group]
        local values = dropdown and dropdown.Values or {}
        local chosen = dropdown and dropdown.Value or {}
        if chosen["All"] then
            for _, label in ipairs(values) do
                if label ~= "All" then selected[label] = true end
            end
        else
            for label, active in pairs(chosen) do
                if active and label ~= "All" then selected[label] = true end
            end
        end
        return selected
    end
    config = config or {}
    local values = { "All" }
    for _, v in ipairs(config.Values or {}) do
        table.insert(values, v)
    end
    group:AddDropdown(id, {
        Text = config.Text,
        Values = values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    return Options[id]
end
function SafeLabel(target, id, text)
    if type(target) == "string" then
        local entry = Shared.Labels[target]
        if entry then
            entry.Text = id
            entry.Dirty = true
        end
        return
    end
    local label = target:AddLabel(text, true)
    Shared.Labels[id] = {Label = label, Text = text, Dirty = false}
    Thread("SafeLabel", function()
        while not Library.Unloaded do
            for key, entry in pairs(Shared.Labels) do
                if entry.Dirty then
                    entry.Dirty = false
                    local ok, err = pcall(function()
                        entry.Label:SetText(entry.Text)
                    end)
                    if not ok then
                        notyuri("SetText FAILED:", tostring(key), tostring(err))
                    end
                end
            end
            task.wait()
        end
    end, true)
    return label
end
function AddSliderToggle(Config)
    local Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false,
        Disabled = Config.Disabled,
    })
    local Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    Toggle:OnChanged(function()
        Slider:SetVisible(Toggle.Value)
    end)
    return Toggle, Slider
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local function SafeInvoke(remote, ...)
    local args = {...}
    local result = nil
    task.spawn(function()
        local success, res = pcall(function()
            return remote:InvokeServer(unpack(args))
        end)
        result = res
    end)
    local start = tick()
    repeat task.wait() until result ~= nil or (tick() - start) > 2
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        local args = {...}
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Fire then
                pcall(function() connection:Fire(unpack(args)) end)
            elseif connection.Function then
                task.spawn(connection.Function, unpack(args))
            end
        end
    else
        warn("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            currentTable[flagKey] = task.spawn(featureFunc, ...)
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            warn("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
local function GetCharacter()
    local c = Plr.Character
    return (c and c:FindFirstChild("HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function TPTo(target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    hrp.CFrame = cframe
    return true
end
local function GetNearest(list, filterFn)
    local char = GetCharacter()
    local root = char and char:FindFirstChild("HumanoidRootPart")
    if not root then return nil end
    local best, bestDist = nil, math.huge
    for _, inst in ipairs(list) do
        if not filterFn or filterFn(inst) then
            local part = inst:IsA("BasePart") and inst or (inst:IsA("Model") and inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart"))
            if part then
                local dist = (part.Position - root.Position).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    best = inst
                end
            end
        end
    end
    return best, bestDist
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            pcall(function()
                local promptOverlay = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = promptOverlay.promptOverlay:FindFirstChild("ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Plr)
                    end
                end
            end)
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local success, err = pcall(function()
            local pauseGui = game:GetService("CoreGui").RobloxGui:FindFirstChild("CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    if teleport then
        local char = GetCharacter()
        local hrp = char and GetObject(char, "HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local pos = isModel and part:GetPivot().Position or part.Position
            if (hrp.Position - pos).Magnitude > target.MaxActivationDistance then
                TPTo(part)
                task.wait(0.2)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and Plr.Character:FindFirstChild("HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, true)
        task.wait()
        firetouchinterest(part, root, false)
    end)
end
local function Serverhop()
    local hopSuccess, hopErr = pcall(function()
        local baseUrl = 'https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100'
        local servers = {}
        local cursor = ''
        for _ = 1, 3 do
            local url = baseUrl
            if cursor ~= '' then url = url .. '&cursor=' .. cursor end
            local pages = game:HttpGet(url)
            local data = HttpService:JSONDecode(pages)
            for _, server in ipairs(data.data) do
                if server.playing < server.maxPlayers and server.id ~= game.JobId then
                    table.insert(servers, server)
                end
            end
            cursor = data.nextPageCursor
            if not cursor or cursor == '' then break end
        end
        table.sort(servers, function(a, b) return a.playing < b.playing end)
        if #servers == 0 then
            Library:Notify("No servers found to hop to.", 3)
            return
        end
        local best = servers[1]
        for _, server in ipairs(servers) do
            if server.playing > 0 then
                best = server
                break
            end
        end
        TeleportService:TeleportToPlaceInstance(game.PlaceId, best.id, Plr)
    end)
    if not hopSuccess then
        Library:Notify("Serverhop failed: " .. tostring(hopErr), 5)
    end
end
local Window = Library:CreateWindow({
        Title = "Yuri",
        Center = true,
        AutoShow = true,
        Resizable = true,
        ShowCustomCursor = false,
        UnlockMouseWhileOpen = false,
        NotifySide = "Left",
        TabPadding = 8,
        MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
        Main = Window:AddTab("Main"),
    Player = Window:AddTab("Player"),
    Config = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Autofarm"),
        T2 = TB.Main.Left.Autofarm:AddTab("World"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
}
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
local TPW_T, TPW_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1})
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
local FPS_T, FPS_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused"})
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function() Serverhop() end })
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Plr) end })
GB.Player.Left.Server:AddToggle("AutoServerhop", { Text = "Auto Serverhop" })
GB.Player.Left.Server:AddSlider("AutoHopMins", { Text = "Minutes", Default = 30, Min = 0, Max = 300, Compact = true, Rounding = 0 })
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    TPW_S:SetVisible(TPW_T.Value)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Toggles.AutoServerhop:OnChanged(function(state)
    Thread("AutoServerhop", function()
        local lastHop = tick()
        while Toggles.AutoServerhop.Value do
            task.wait(5)
            if not Toggles.AutoServerhop.Value then break end
            if (tick() - lastHop) >= (Options.AutoHopMins.Value * 60) then
                Serverhop()
                break
            end
        end
    end, state)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then Hum.JumpPower = Options.JPValue.Value Hum.UseJumpPower = true end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if FPS_T.Value then
        setfpscap(FPS_S.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    FPS_S:SetVisible(FPS_T.Value)
    if not v and Support.FPS then
        setfpscap(2000)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local antiAFKConn = nil
local function RunAntiAFK()
    if antiAFKConn then antiAFKConn:Enable() return end
    local GC = getconnections or get_signal_cons
    if GC then
        local conns = GC(Players.LocalPlayer.Idled)
        local target = conns and conns[1]
        if target and target.Disable then
            target:Disable()
            antiAFKConn = target
            return
        end
        for _, c in pairs(conns or {}) do
            if c.Disable then
                c:Disable()
                antiAFKConn = c
                return
            elseif c.Disconnect then
                c:Disconnect()
                return
            end
        end
    end
    Players.LocalPlayer.Idled:Connect(function()
        VirtualUser:CaptureController()
        VirtualUser:ClickButton2(Vector2.new())
    end)
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then
        RunAntiAFK()
    elseif antiAFKConn and antiAFKConn.Enable then
        antiAFKConn:Enable()
    end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
local TowerOk = false
do
	local sharedFolder = RS:FindFirstChild("Shared")
	local clientFolder = RS:FindFirstChild("Client")
	local packagesFolder = RS:FindFirstChild("Packages")
	Modules.Remotes = GetSafeModule(sharedFolder, "Remotes")
	Modules.DataService = GetSafeModule(packagesFolder, "DataService")
	Modules.StairConfig = GetSafeModule(sharedFolder, "StairConfig")
	Modules.RebirthConfig = GetSafeModule(sharedFolder, "RebirthConfig")
	Modules.UpgradeConfig = GetSafeModule(sharedFolder, "UpgradeConfig")
	Modules.TreeConfig = GetSafeModule(sharedFolder, "TreeConfig")
	Modules.DoorConfig = GetSafeModule(sharedFolder, "DoorConfig")
	Modules.MineConfig = GetSafeModule(sharedFolder, "MineConfig")
	Modules.SmelterConfig = GetSafeModule(sharedFolder, "SmelterConfig")
	Modules.StarforgeConfig = GetSafeModule(sharedFolder, "StarforgeConfig")
	Modules.WoodConfig = GetSafeModule(sharedFolder, "WoodConfig")
	Modules.CrystalConfig = GetSafeModule(sharedFolder, "CrystalConfig")
	Modules.EssenceConfig = GetSafeModule(sharedFolder, "EssenceConfig")
	Modules.TotemConfig = GetSafeModule(sharedFolder, "TotemConfig")
	Modules.PotionConfig = GetSafeModule(sharedFolder, "PotionConfig")
	Modules.WheelConfig = GetSafeModule(sharedFolder, "WheelConfig")
	Modules.GlyphConfig = GetSafeModule(sharedFolder, "GlyphConfig")
	Modules.TeleportConfig = GetSafeModule(sharedFolder, "TeleportConfig")
	Modules.NumberFormat = GetSafeModule(sharedFolder, "NumberFormat")
	Modules.PassConfig = GetSafeModule(sharedFolder, "PassConfig")
	Modules.PassState = GetSafeModule(clientFolder, "PassState")
	local towerParts = { Modules.Remotes, Modules.DataService, Modules.StairConfig, Modules.RebirthConfig, Modules.UpgradeConfig, Modules.TreeConfig, Modules.DoorConfig, Modules.MineConfig, Modules.SmelterConfig, Modules.StarforgeConfig, Modules.WoodConfig, Modules.CrystalConfig, Modules.EssenceConfig, Modules.TotemConfig, Modules.PotionConfig, Modules.WheelConfig, Modules.GlyphConfig, Modules.TeleportConfig, Modules.NumberFormat, Modules.PassConfig, Modules.PassState }
	TowerOk = Modules.DataService ~= nil and Modules.DataService.client ~= nil
	for _, module in ipairs(towerParts) do
		if not module then
			TowerOk = false
		end
	end
	if TowerOk then
		Modules.Data = Modules.DataService.client
		for _, remoteName in ipairs({ "BuyStair", "BuyUpgrade", "MineBlock", "UnlockDoor", "BuyTreeNode", "SpinWheel", "Rebirth", "BuyPotion", "Essence", "Totem", "SmelterDeposit", "StarforgeDeposit" }) do
			Remotes[remoteName] = Modules.Remotes[remoteName]
		end
	end
end
if not TowerOk then
	Library:Notify("ERROR: Tower Incremental modules not found", 8)
end
if TowerOk then
	local Data = Modules.Data
	local State = {
		Stairs = nil,
		StairsAt = 0,
		WoodSpots = nil,
		CrystalSpots = nil,
		SmeltPath = nil,
		MineFired = {},
		Memos = {},
		PotionDefs = {},
		TeleportDefs = {},
	}
	local function NotifyOnce(key, msg)
		if State.Memos[key] then return end
		State.Memos[key] = true
		Library:Notify(msg, 6)
	end
	local function StairsArray()
		local now = os.clock()
		if not State.Stairs or (now - State.StairsAt) > 30 then
			State.Stairs = Modules.StairConfig.collect()
			State.StairsAt = now
		end
		return State.Stairs
	end
	local function GetWoodSpots()
		if not State.WoodSpots or #State.WoodSpots == 0 then
			State.WoodSpots = Modules.WoodConfig.spots()
		end
		return State.WoodSpots
	end
	local function GetCrystalSpots()
		if not State.CrystalSpots or #State.CrystalSpots == 0 then
			State.CrystalSpots = Modules.CrystalConfig.spots()
		end
		return State.CrystalSpots
	end
	local function GetSmeltPath()
		if State.SmeltPath then return State.SmeltPath end
		local system = workspace:FindFirstChild("SmelterSystem")
		local machine = system and system:FindFirstChild("Machine")
		local path = machine and Modules.SmelterConfig.path(machine)
		if path then
			State.SmeltPath = path
		end
		return path
	end
	local function EnsureTool(name)
		local char = Plr.Character
		if not char then return false end
		if char:FindFirstChild(name) then return true end
		local hum = char:FindFirstChildOfClass("Humanoid")
		local backpack = Plr:FindFirstChildOfClass("Backpack")
		local tool = backpack and backpack:FindFirstChild(name)
		if hum and tool and tool:IsA("Tool") then
			pcall(function() hum:EquipTool(tool) end)
			task.wait(0.15)
		end
		return char:FindFirstChild(name) ~= nil
	end
	local function MiningMulti()
		local passTotal = Modules.PassConfig.totals(Modules.PassState.owned).mining
		local treeTotal = Modules.TreeConfig.totals(Data:get("tree")).mining
		return passTotal * treeTotal
	end
	local function StepBuyStairs()
		local stairs = StairsArray()
		local owned = Data:get("stairsOwned") or 1
		local target = owned + 1
		local part = stairs[target]
		if not part then return end
		local rebirths = Data:get("rebirths") or 0
		if rebirths < Modules.RebirthConfig.rebirthsForStair(target) then return end
		local cost = Modules.RebirthConfig.scaledCost(part:GetAttribute("StairCost") or 0, rebirths)
		if (Data:get("gold") or 0) < cost then return end
		pcall(function() Remotes.BuyStair:FireServer(target) end)
	end
	local function StepUpgrades()
		local selected = AddMultiDropdown("UpgradeSelection")
		if not next(selected) then return end
		local doors = Data:get("doors") or {}
		local levels = Data:get("upgrades") or {}
		for _, def in ipairs(Modules.UpgradeConfig.LIST) do
			if selected[def.id] then
				local level = levels[def.id] or 0
				if level < def.cap then
					local doorId = Modules.UpgradeConfig.doorFor(def)
					if not doorId or doors[doorId] == true then
						local have = Data:get(def.currency or "gold") or 0
						local count, cost = Modules.UpgradeConfig.resolve(def, level, have, 1)
						if count >= 1 and have >= cost then
							local extraOk = true
							if def.extra and (Data:get(def.extra.currency) or 0) < def.extra.amount then
								extraOk = false
							end
							if extraOk then
								pcall(function() Remotes.BuyUpgrade:FireServer(def.id, 1) end)
								return
							end
						end
					end
				end
			end
		end
	end
	local function StepTree()
		local treeData = Data:get("tree") or {}
		local stairs = StairsArray()
		local floor = Modules.StairConfig.floorFor(Data:get("stairsOwned") or 1, stairs)
		local rebirths = Data:get("rebirths") or 0
		for _, node in ipairs(Modules.TreeConfig.NODES) do
			if not treeData[node.id] then
				if Modules.TreeConfig.available(node, treeData, floor, rebirths) then
					if (Data:get(node.currency) or 0) >= node.cost then
						local extraOk = true
						if node.extra and (Data:get(node.extra.currency) or 0) < node.extra.amount then
							extraOk = false
						end
						if extraOk then
							pcall(function() Remotes.BuyTreeNode:FireServer(node.id) end)
							return
						end
					end
				end
			end
		end
	end
	local function StepDoors()
		local doors = Data:get("doors") or {}
		local stairs = StairsArray()
		local floor = Modules.StairConfig.floorFor(Data:get("stairsOwned") or 1, stairs)
		local rebirths = Data:get("rebirths") or 0
		for _, door in ipairs(Modules.DoorConfig.DOORS) do
			if not doors[door.id] then
				if (door.floor or 0) <= floor and (door.rebirths or 0) <= rebirths then
					local cost = door.cost
					if door.currency == "gold" then
						cost = Modules.RebirthConfig.scaledCost(cost, rebirths)
					end
					if (Data:get(door.currency or "gold") or 0) >= cost then
						pcall(function() Remotes.UnlockDoor:FireServer(door.id) end)
						return
					end
				end
			end
		end
	end
	local function StepRebirth()
		local rebirths = Data:get("rebirths") or 0
		local tier = rebirths + 1
		local def = Modules.RebirthConfig.LIST[tier]
		if not def then return end
		local cost = Modules.RebirthConfig.scaledCost(def.cost, rebirths)
		if (Data:get(def.currency) or 0) >= cost then
			pcall(function() Remotes.Rebirth:FireServer(tier) end)
			Library:Notify("Rebirth " .. tier .. " started", 5)
		end
	end
	local function StepMine()
		local doors = Data:get("doors") or {}
		if doors[Modules.MineConfig.DOOR] ~= true then
			NotifyOnce("TIMineDoor", "Unlock the Mine door (Floor 3) to mine")
			return
		end
		local mine = workspace:FindFirstChild("Mine")
		local blocks = mine and mine:FindFirstChild("MineBlocks")
		if not blocks then return end
		local fired = 0
		for _, block in ipairs(blocks:GetChildren()) do
			if block:GetAttribute("Ore") == true then
				local cell = block:GetAttribute("Cell")
				if type(cell) == "number" and not State.MineFired[cell] then
					State.MineFired[cell] = true
					fired = fired + 1
					pcall(function() Remotes.MineBlock:FireServer(cell) end)
					task.wait(0.08)
					if Library.Unloaded or not Toggles.AutoMine.Value then return end
				end
			end
		end
		if fired == 0 then
			task.wait(2)
		end
	end
	local function StepWheel()
		local doors = Data:get("doors") or {}
		if doors[Modules.WheelConfig.DOOR] ~= true then
			NotifyOnce("TIWheelDoor", "Unlock the Prize Wheel door (Floor 46) to spin")
			return
		end
		local wheel = Data:get("wheel") or {}
		local now = workspace:GetServerTimeNow()
		local freeReady = (wheel.nextFree or 0) <= now
		local mode = Options.WheelMode and Options.WheelMode.Value or "Free Only"
		if not freeReady then
			if mode ~= "Whenever Affordable" then return end
			if (Data:get("crystals") or 0) < Modules.WheelConfig.SPIN_COST then return end
		end
		pcall(function() Remotes.SpinWheel:FireServer() end)
		task.wait(Modules.WheelConfig.SPIN_TIME + 1)
	end
	local function StepPotions()
		local selected = AddMultiDropdown("PotionSelection")
		if not next(selected) then return end
		local doors = Data:get("doors") or {}
		local potions = Data:get("potions")
		local now = workspace:GetServerTimeNow()
		for label, active in pairs(selected) do
			if active then
				local def = State.PotionDefs[label]
				if def and def.cost and def.currency and def.door then
					if doors[def.door] == true then
						if (Data:get(def.currency) or 0) >= def.cost then
							if Modules.PotionConfig.canAdd(potions, def.id, def.duration, now) then
								pcall(function() Remotes.BuyPotion:FireServer(def.id) end)
								return
							end
						end
					end
				end
			end
		end
	end
	local function StepTotems()
		local totems = Data:get("totems") or {}
		local bases = totems.bases or {}
		local slots = totems.slots or {}
		local ownedHeads = totems.owned or {}
		local nextBase = Modules.TotemConfig.nextBase(totems)
		if nextBase and (Data:get("gold") or 0) >= nextBase.gold and (Data:get("wood") or 0) >= nextBase.wood then
			for i = 1, Modules.TotemConfig.SLOTS do
				if not bases[Modules.TotemConfig.key(i)] then
					pcall(function() Remotes.Totem:FireServer("base", i) end)
					return
				end
			end
		end
		local selected = AddMultiDropdown("TotemHeads")
		if not next(selected) then return end
		for _, head in ipairs(Modules.TotemConfig.HEADS) do
			if selected[head.name] then
				if not Modules.TotemConfig.slotOf(totems, head.id) then
					local affordable = ownedHeads[head.id] == true or (Data:get(head.currency) or 0) >= head.cost
					if affordable then
						for i = 1, Modules.TotemConfig.SLOTS do
							local key = Modules.TotemConfig.key(i)
							if bases[key] and not slots[key] then
								pcall(function() Remotes.Totem:FireServer("head", i, head.id) end)
								return
							end
						end
					end
				end
			end
		end
	end
	local function TaskSmelt()
		if not Toggles.AutoSmelt or not Toggles.AutoSmelt.Value then return false end
		local doors = Data:get("doors") or {}
		if doors[Modules.SmelterConfig.DOOR] ~= true then
			NotifyOnce("TISmeltDoor", "Unlock the Smelter door (Floor 10) to smelt")
			return false
		end
		local iron = Data:get("iron") or 0
		if iron <= 0 then return false end
		local smelt = Data:get("smelter") or {}
		local path = GetSmeltPath()
		if not path then return false end
		local capacity = math.floor(Modules.SmelterConfig.paceFor(path, Data:get("upgrades")).capacity)
		if (smelt.queued or 0) >= capacity then return false end
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		if not Modules.SmelterConfig.inRoom(hrp.Position) then
			local system = workspace:FindFirstChild("SmelterSystem")
			local room = system and system:FindFirstChild("Room")
			if room and room:IsA("BasePart") then
				TPTo(room, Vector3.new(0, 4, 0))
				task.wait(0.25)
			end
		end
		pcall(function() Remotes.SmelterDeposit:FireServer() end)
		task.wait(0.35)
		return true
	end
	local function TaskStarforge()
		if not Toggles.AutoStarforge or not Toggles.AutoStarforge.Value then return false end
		local doors = Data:get("doors") or {}
		if doors[Modules.StarforgeConfig.DOOR] ~= true then
			NotifyOnce("TIForgeDoor", "Unlock the Starforge door (Floor 153) to forge")
			return false
		end
		local ingots = Data:get("ingots") or 0
		if ingots <= 0 then return false end
		local forge = Data:get("starforge") or {}
		local capacity = math.floor(Modules.StarforgeConfig.paceFor(Data:get("upgrades"), Modules.TreeConfig.totals(Data:get("tree")).starforgeCapacity).capacity)
		if (forge.queued or 0) >= capacity then return false end
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		if ingots >= Modules.StarforgeConfig.CHARGE and not Modules.StarforgeConfig.inRoom(hrp.Position) then
			local system = workspace:FindFirstChild("StarforgeSystem")
			local room = system and system:FindFirstChild("Room")
			if room and room:IsA("BasePart") then
				TPTo(room, Vector3.new(0, 4, 0))
				task.wait(0.25)
			end
		end
		pcall(function() Remotes.StarforgeDeposit:FireServer() end)
		task.wait(0.35)
		return true
	end
	local function TaskWood()
		if not Toggles.AutoWood or not Toggles.AutoWood.Value then return false end
		local doors = Data:get("doors") or {}
		if doors[Modules.WoodConfig.DOOR] ~= true then
			NotifyOnce("TIWoodDoor", "Unlock the Lumber Yard door (Floor 70) to chop trees")
			return false
		end
		local grove = Data:get("woodGrove") or {}
		local now = workspace:GetServerTimeNow()
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		local best, bestDist = nil, math.huge
		for _, spot in ipairs(GetWoodSpots()) do
			local readyAt = grove[spot.Name]
			if type(readyAt) == "number" and readyAt <= now then
				local dist = (Modules.WoodConfig.base(spot) - hrp.Position).Magnitude
				if dist < bestDist then
					best, bestDist = spot, dist
				end
			end
		end
		if not best then return false end
		EnsureTool("Axe")
		TPTo(Modules.WoodConfig.base(best) + Vector3.new(0, 4, 0))
		local hold = Modules.WoodConfig.holdSeconds(Data:get("upgrades"), MiningMulti())
		task.wait(math.max(hold, 0.15))
		return true
	end
	local function TaskCrystal()
		if not Toggles.AutoCrystal or not Toggles.AutoCrystal.Value then return false end
		local doors = Data:get("doors") or {}
		if doors[Modules.CrystalConfig.DOOR] ~= true then
			NotifyOnce("TICrystalDoor", "Unlock the Crystal Garden door (Floor 28) to harvest crystals")
			return false
		end
		local garden = Data:get("crystalGarden") or {}
		local now = workspace:GetServerTimeNow()
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		local best, bestDist = nil, math.huge
		for _, spot in ipairs(GetCrystalSpots()) do
			local readyAt = garden[spot.Name]
			if type(readyAt) == "number" and readyAt <= now then
				local dist = (Modules.CrystalConfig.base(spot) - hrp.Position).Magnitude
				if dist < bestDist then
					best, bestDist = spot, dist
				end
			end
		end
		if not best then return false end
		EnsureTool("Pickaxe")
		TPTo(Modules.CrystalConfig.base(best) + Vector3.new(0, 4, 0))
		local hold = Modules.CrystalConfig.holdSeconds(Data:get("upgrades"), MiningMulti())
		task.wait(math.max(hold, 0.15))
		return true
	end
	local function TaskEssence()
		if not Toggles.AutoEssence or not Toggles.AutoEssence.Value then return false end
		local doors = Data:get("doors") or {}
		if doors[Modules.EssenceConfig.DOOR] ~= true then
			NotifyOnce("TIEssenceDoor", "Unlock the Essence Field door (Floor 108) to collect essence")
			return false
		end
		local orbs = workspace:FindFirstChild("EssenceOrbs")
		if not orbs then return false end
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		local best, bestDist = nil, math.huge
		for _, orb in ipairs(orbs:GetChildren()) do
			local ok, pivot = pcall(function() return orb:GetPivot() end)
			if ok and pivot then
				local dist = (pivot.Position - hrp.Position).Magnitude
				if dist < bestDist then
					best, bestDist = orb, dist
				end
			end
		end
		if not best then return false end
		TPTo(best:GetPivot().Position)
		task.wait(0.25)
		return true
	end
	local function TaskGlyphs()
		if not Toggles.AutoGlyphs or not Toggles.AutoGlyphs.Value then return false end
		local selected = AddMultiDropdown("GlyphSelection")
		if not next(selected) then return false end
		local doors = Data:get("doors") or {}
		local runes = workspace:FindFirstChild("Runes")
		if not runes then return false end
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		for _, set in ipairs(Modules.GlyphConfig.SETS) do
			if selected[set.name] then
				if doors[set.door] ~= true then
					NotifyOnce("TIGlyphDoor" .. set.id, set.name .. " locked - unlock its door first")
				else
					local model = runes:FindFirstChild(set.model)
					local pad = model and model:FindFirstChild("RuneTouch")
					if pad and pad:IsA("BasePart") then
						local landing = pad.Position + Vector3.new(0, pad.Size.Y / 2 + 3, 0)
						local flat = Vector2.new(hrp.Position.X - landing.X, hrp.Position.Z - landing.Z)
						if flat.Magnitude > 2 then
							TPTo(landing)
						end
						local roll = Options.GlyphRollSeconds and Options.GlyphRollSeconds.Value or 8
						local untilTick = os.clock() + math.max(roll, 1)
						while os.clock() < untilTick do
							if Library.Unloaded or not Toggles.AutoGlyphs.Value then return true end
							task.wait(0.25)
						end
						return true
					end
				end
			end
		end
		return false
	end
	local function AnyTPEnabled()
		return (Toggles.AutoSmelt and Toggles.AutoSmelt.Value)
			or (Toggles.AutoStarforge and Toggles.AutoStarforge.Value)
			or (Toggles.AutoWood and Toggles.AutoWood.Value)
			or (Toggles.AutoCrystal and Toggles.AutoCrystal.Value)
			or (Toggles.AutoEssence and Toggles.AutoEssence.Value)
			or (Toggles.AutoGlyphs and Toggles.AutoGlyphs.Value)
	end
	local function MasterLoop()
		local fails = 0
		while not Library.Unloaded do
			if not AnyTPEnabled() then break end
			local did = false
			local passErrors = 0
			for _, taskFn in ipairs({ TaskSmelt, TaskStarforge, TaskWood, TaskCrystal, TaskEssence, TaskGlyphs }) do
				if Library.Unloaded then break end
				local ok, worked = pcall(taskFn)
				if ok then
					if worked then did = true end
				else
					passErrors = passErrors + 1
					fails = fails + 1
					notyuri("TowerInc master error:", tostring(worked))
				end
			end
			if passErrors == 0 then
				fails = 0
			end
			if fails >= 8 then
				Library:Notify("World tasks stopped after repeated errors", 8)
				break
			end
			if not did then
				task.wait(0.3)
			end
		end
	end
	local function RunLoop(toggle, step, interval, label)
		local fails = 0
		while not Library.Unloaded do
			if not toggle.Value then break end
			local ok, err = pcall(step)
			if not ok then
				fails = fails + 1
				notyuri("TowerInc loop error [" .. label .. "]:", tostring(err))
				if fails >= 4 then
					Library:Notify(label .. " stopped: " .. tostring(err), 8)
					pcall(function() toggle:SetValue(false) end)
					break
				end
			else
				fails = 0
			end
			if interval > 0 then
				task.wait(interval)
			end
		end
	end
	local function DoTeleport()
		local label = Options.TeleportDest and Options.TeleportDest.Value
		local dest = label and State.TeleportDefs[label]
		if not dest then return end
		local char = GetCharacter()
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if not char or not hrp then return end
		local pose = nil
		if dest.spawn then
			local pad = Modules.TeleportConfig.spawnPad()
			if pad then
				pose = CFrame.new(pad.Position + Vector3.new(0, pad.Size.Y / 2 + 3, 0))
			end
		else
			local landing = Modules.TeleportConfig.landing(dest.floor, StairsArray())
			if landing then
				local home = landing:GetAttribute("StairHome") or landing.CFrame
				pose = home * CFrame.new(0, landing.Size.Y / 2 + 3, 0)
			end
		end
		if pose then
			char:PivotTo(pose)
			hrp.AssemblyLinearVelocity = Vector3.zero
			hrp.AssemblyAngularVelocity = Vector3.zero
			Library:Notify("Teleported to " .. label, 3)
		else
			Library:Notify("No landing found for " .. label, 4)
		end
	end
	local function UpdateStats()
		local stairs = StairsArray()
		local floor = Modules.StairConfig.floorFor(Data:get("stairsOwned") or 1, stairs)
		local fmt = Modules.NumberFormat.price
		SafeLabel("TIStatFloors", ("Floor %d  |  Stairs %d  |  Rebirths %d"):format(floor, Data:get("stairsOwned") or 1, Data:get("rebirths") or 0))
		SafeLabel("TIStatGold", ("Gold %s  |  Silver %s  |  Iron %s"):format(fmt(Data:get("gold") or 0), fmt(Data:get("silver") or 0), fmt(Data:get("iron") or 0)))
		SafeLabel("TIStatMine", ("Ingots %s  |  Crystals %s  |  Starmetal %s"):format(fmt(Data:get("ingots") or 0), fmt(Data:get("crystals") or 0), fmt(Data:get("starmetal") or 0)))
		local glyphs = Data:get("glyphs") or {}
		local glyphTotal = 0
		for _, count in pairs(glyphs) do
			if type(count) == "number" then
				glyphTotal = glyphTotal + count
			end
		end
		SafeLabel("TIStatExtra", ("Wood %s  |  Essence %s  |  Glyphs %s"):format(fmt(Data:get("wood") or 0), fmt(Data:get("essence") or 0), fmt(glyphTotal)))
	end
	local upgradeIds = {}
	for _, def in ipairs(Modules.UpgradeConfig.LIST) do
		table.insert(upgradeIds, def.id)
	end
	local glyphNames = {}
	for _, set in ipairs(Modules.GlyphConfig.SETS) do
		table.insert(glyphNames, set.name)
	end
	local potionLabels = {}
	for _, def in ipairs(Modules.PotionConfig.LIST) do
		if def.cost and def.currency and def.door then
			local label = def.name .. " (" .. Modules.NumberFormat.price(def.cost) .. " " .. def.currency:upper() .. ")"
			table.insert(potionLabels, label)
			State.PotionDefs[label] = def
		end
	end
	local totemNames = {}
	for _, head in ipairs(Modules.TotemConfig.HEADS) do
		table.insert(totemNames, head.name)
	end
	local teleportLabels = {}
	for _, dest in ipairs(Modules.TeleportConfig.LIST) do
		local label = dest.button
		if not State.TeleportDefs[label] then
			table.insert(teleportLabels, label)
			State.TeleportDefs[label] = dest
		end
	end
	local GB_Progress = TB_Tabs.Autofarm.T1:AddGroupbox("Progress")
	local GB_Gather = TB_Tabs.Autofarm.T2:AddGroupbox("World")
	local GB_Stats = TB_Tabs.Autofarm2.T1:AddGroupbox("Live Stats")
	local GB_Teleport = TB_Tabs.Autofarm2.T1:AddGroupbox("Teleport")
	GB_Progress:AddToggle("AutoBuyStairs", { Text = "Auto Buy Stairs", Tooltip = "Buys the next stair whenever gold allows" })
	GB_Progress:AddToggle("AutoUpgrades", { Text = "Auto Upgrades", Tooltip = "Buys selected upgrades one level per pass" })
	AddMultiDropdown(GB_Progress, "UpgradeSelection", { Text = "Upgrades", Values = upgradeIds, Default = { "All" } })
	GB_Progress:AddToggle("AutoTree", { Text = "Auto Tree", Tooltip = "Buys available upgrade tree nodes" })
	GB_Progress:AddToggle("AutoDoors", { Text = "Auto Doors", Tooltip = "Unlocks the next affordable door" })
	GB_Progress:AddToggle("AutoRebirth", { Text = "Auto Rebirth", Tooltip = "Rebirths as soon as affordable - resets progress", Default = false })
	GB_Progress:AddDivider()
	GB_Progress:AddToggle("AutoMine", { Text = "Auto Mine", Tooltip = "Breaks every ore block each mine cycle" })
	GB_Progress:AddToggle("AutoSmelt", { Text = "Auto Smelt", Tooltip = "Deposits iron ore into the smelter" })
	GB_Progress:AddToggle("AutoStarforge", { Text = "Auto Starforge", Tooltip = "Deposits ingots into the starforge" })
	GB_Gather:AddToggle("AutoWood", { Text = "Auto Wood", Tooltip = "Teleports to ready trees with the axe" })
	GB_Gather:AddToggle("AutoCrystal", { Text = "Auto Crystals", Tooltip = "Teleports to ready crystals with the pickaxe" })
	GB_Gather:AddToggle("AutoEssence", { Text = "Auto Essence", Tooltip = "Sweeps essence orbs in the field" })
	GB_Gather:AddToggle("AutoGlyphs", { Text = "Auto Glyphs", Tooltip = "Stands on rune pads to auto roll" })
	AddMultiDropdown(GB_Gather, "GlyphSelection", { Text = "Glyph Sets", Values = glyphNames, Default = { "All" } })
	GB_Gather:AddSlider("GlyphRollSeconds", { Text = "Roll Seconds", Default = 8, Min = 3, Max = 30, Rounding = 0 })
	GB_Gather:AddDivider()
	GB_Gather:AddToggle("AutoSpinWheel", { Text = "Auto Spin Wheel" })
	GB_Gather:AddDropdown("WheelMode", { Text = "Spin Mode", Values = { "Free Only", "Whenever Affordable" }, Default = "Free Only" })
	GB_Gather:AddToggle("AutoPotions", { Text = "Auto Potions" })
	AddMultiDropdown(GB_Gather, "PotionSelection", { Text = "Potions", Values = potionLabels, Default = {} })
	GB_Gather:AddToggle("AutoTotems", { Text = "Auto Totems", Tooltip = "Buys totem bases and selected heads" })
	AddMultiDropdown(GB_Gather, "TotemHeads", { Text = "Totem Heads", Values = totemNames, Default = { "All" } })
	SafeLabel(GB_Stats, "TIStatFloors", "Floor -  |  Stairs -  |  Rebirths -")
	SafeLabel(GB_Stats, "TIStatGold", "Gold -  |  Silver -  |  Iron -")
	SafeLabel(GB_Stats, "TIStatMine", "Ingots -  |  Crystals -  |  Starmetal -")
	SafeLabel(GB_Stats, "TIStatExtra", "Wood -  |  Essence -  |  Glyphs -")
	GB_Teleport:AddDropdown("TeleportDest", { Text = "Destination", Values = teleportLabels, Default = teleportLabels[1] })
	GB_Teleport:AddButton({ Text = "Teleport", Func = function() DoTeleport() end })
	Toggles.AutoBuyStairs:OnChanged(function(state)
		Thread("TI.BuyStairs", function() RunLoop(Toggles.AutoBuyStairs, StepBuyStairs, 0.25, "Auto Buy Stairs") end, state)
	end)
	Toggles.AutoUpgrades:OnChanged(function(state)
		Thread("TI.Upgrades", function() RunLoop(Toggles.AutoUpgrades, StepUpgrades, 0.4, "Auto Upgrades") end, state)
	end)
	Toggles.AutoTree:OnChanged(function(state)
		Thread("TI.Tree", function() RunLoop(Toggles.AutoTree, StepTree, 0.5, "Auto Tree") end, state)
	end)
	Toggles.AutoDoors:OnChanged(function(state)
		Thread("TI.Doors", function() RunLoop(Toggles.AutoDoors, StepDoors, 0.5, "Auto Doors") end, state)
	end)
	Toggles.AutoRebirth:OnChanged(function(state)
		Thread("TI.Rebirth", function() RunLoop(Toggles.AutoRebirth, StepRebirth, 1, "Auto Rebirth") end, state)
	end)
	Toggles.AutoMine:OnChanged(function(state)
		Thread("TI.Mine", function() RunLoop(Toggles.AutoMine, StepMine, 0.1, "Auto Mine") end, state)
	end)
	Toggles.AutoSpinWheel:OnChanged(function(state)
		Thread("TI.Wheel", function() RunLoop(Toggles.AutoSpinWheel, StepWheel, 1, "Auto Spin Wheel") end, state)
	end)
	Toggles.AutoPotions:OnChanged(function(state)
		Thread("TI.Potions", function() RunLoop(Toggles.AutoPotions, StepPotions, 1, "Auto Potions") end, state)
	end)
	Toggles.AutoTotems:OnChanged(function(state)
		Thread("TI.Totems", function() RunLoop(Toggles.AutoTotems, StepTotems, 1, "Auto Totems") end, state)
	end)
	local function WireTP()
		Thread("TI.TPMaster", MasterLoop, AnyTPEnabled())
	end
	Toggles.AutoSmelt:OnChanged(WireTP)
	Toggles.AutoStarforge:OnChanged(WireTP)
	Toggles.AutoWood:OnChanged(WireTP)
	Toggles.AutoCrystal:OnChanged(WireTP)
	Toggles.AutoEssence:OnChanged(function(state)
		if state then
			pcall(function() Remotes.Essence:FireServer("sync") end)
		end
		WireTP()
	end)
	Toggles.AutoGlyphs:OnChanged(WireTP)
	SafeConnect("TI_MineReset", function()
		return Modules.Remotes.MineReset and Modules.Remotes.MineReset.OnClientEvent
	end, function()
		State.MineFired = {}
	end)
	Thread("TI.Stats", function()
		while not Library.Unloaded do
			pcall(UpdateStats)
			task.wait(0.5)
		end
	end, true)
end

local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
        Default = Library.KeybindFrame.Visible,
        Text = "Open Keybind Menu",
        Callback = function(value)
                Library.KeybindFrame.Visible = value
        end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
        Text = "Custom Cursor",
        Default = false,
        Callback = function(Value)
                Library.ShowCustomCursor = Value
        end,
})
MenuGroup:AddDropdown("NotificationSide", {
        Values = { "Left", "Right" },
        Default = "Right",
        Text = "Notification Side",
        Callback = function(Value)
                Library:SetNotifySide(Value)
        end,
})
MenuGroup:AddDropdown("DPIDropdown", {
        Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
        Default = "100%",
        Text = "DPI Scale",
        Callback = function(Value)
                Value = Value:gsub("%%", "")
                local DPI = tonumber(Value)
                Library:SetDPIScale(DPI)
        end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
        :AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    if antiAFKConn and antiAFKConn.Enable then pcall(function() antiAFKConn:Enable() end) end
    if Support.FPS then pcall(function() setfpscap(2000) end) end
    Cleanup(Connections)
    Cleanup(Flags)
        Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
SaveManager:IgnoreThemeSettings()
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/TowerInc")
SaveManager:BuildConfigSection(Tabs.Config)
ThemeManager:ApplyToTab(Tabs.Config)
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
SaveManager:SetLoadingOrder(true, {"Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle"})
if UIS.TouchEnabled and not UIS.KeyboardEnabled then
    Library:SetDPIScale(75)
elseif UIS.KeyboardEnabled then
    Library:SetDPIScale(100)
end
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end
