repeat task.wait() until game:IsLoaded()
repeat task.wait() until game.GameId ~= 0
if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
        if type(f) == t then return f end
        return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function" or typeof(queueonteleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
    HookMeta = (typeof(hookmetamethod) == "function"),
    Firesignal = (typeof(firesignal) == "function"),
}
Services = setmetatable({}, {
        __index = function(self, name)
                local success, cache = pcall(function()
                        return cloneref(game:GetService(name))
                end)
                if success then
                        rawset(self, name, cache)
                        return cache
                else
                        error("Invalid Service: " .. tostring(name))
                end
        end
})
local Players = Services.Players
local Plr = setmetatable({}, {
    __index = function(_, key)
        local lp = Players.LocalPlayer
        if not lp then return nil end
        local val = lp[key]
        if type(val) == "function" then
            return function(_, ...)
                return val(lp, ...)
            end
        end
        return val
    end,
    __newindex = function(_, key, value)
        local lp = Players.LocalPlayer
        if not lp then return end
        lp[key] = value
    end,
})
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local yuri = {
    "https://mangadex.org/covers/5311ac6f-3651-43a8-bb9c-b40dea7ab72d/062845cb-4498-4499-a23a-89ecac694ea9.jpg",
    "https://mangadex.org/covers/df01a222-faeb-4952-84ac-d6040815e2dd/ec777628-a5d7-4d5f-92f5-11a8a746427e.jpg",
    "https://cdn.donmai.us/original/dc/0e/__hayafuji_kasane_and_aoyama_meguru_keiyaku_shimai_drawn_by_hijiki_hijikini__dc0e2235f2ca00dcb06aa3db2999bd1f.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/233/thumbnail.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/328/thumbnail.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/1339/thumbnail.jpeg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/1268/thumbnail.jpeg",
    "https://dynasty-scans.com/system/releases/000/040/979/001.webp",
    "https://dynasty-scans.com/system/images_images/000/031/460/full/GErfQqXagAA4mk7-orig.webp",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2026/02/01/15/33/44/140636490_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2022/08/15/23/52/23/100515820_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2025/07/22/17/09/45/132989170_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2019/12/01/21/59/30/78092730_p0_master1200.jpg",
}
local function notyuri()
end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true
Library.ShowCustomCursor = true
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "6pCsSbVd3E"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end
local function LoadModuleAsync(parent, name, onLoaded)
    if not Support.FileIO then return end
    task.spawn(function()
        local obj = parent:FindFirstChild(name)
        local waited = 0
        while not obj and waited < 30 do
            obj = parent:WaitForChild(name, 1)
            waited = waited + 1
            if obj then break end
        end
        if not obj or not obj:IsA("ModuleScript") then return end
        local success, result = pcall(require, obj)
        if success and type(result) == "table" then
            pcall(onLoaded, result)
        end
    end)
end
local function GetSafeRemote(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and (obj:IsA("RemoteEvent") or obj:IsA("RemoteFunction")) then
        return obj
    end
    return nil
end
local function FireRemote(remote, ...)
    if not remote then return false end
    local args = {...}
    local ok, err = pcall(function()
        remote:FireServer(unpack(args))
    end)
    if not ok then notyuri("FireRemote error:", tostring(remote), tostring(err)) end
    return ok
end
local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
}
local Tables = {
}
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
}
local function AddMultiDropdown(group, id, config)
    config = config or {}
    local labelId = config.label
    local baseValues = config.Values or {}
    local values = { "All" }
    for _, v in ipairs(baseValues) do
        table.insert(values, v)
    end
    group:AddDropdown(id, {
        Text = config.Text,
        Values = values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    local function getSelection()
        local labels = (Options[id] and Options[id].Value) or {}
        local ids = {}
        if labels["All"] then
            for _, label in ipairs(baseValues) do
                if labelId then
                    local mappedId = labelId[label]
                    if mappedId then ids[mappedId] = true end
                else
                    ids[label] = true
                end
            end
            return ids
        end
        for label, active in pairs(labels) do
            if active and label ~= "All" then
                if labelId then
                    local mappedId = labelId[label]
                    if mappedId then ids[mappedId] = true end
                else
                    ids[label] = true
                end
            end
        end
        return ids
    end
    local function refresh()
        local newValues = { "All" }
        for _, v in ipairs(baseValues) do
            table.insert(newValues, v)
        end
        if Options[id] then
            Options[id]:SetValues(newValues)
        end
    end
    return getSelection, refresh, baseValues
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local SelfThreads = {}
local function SafeInvoke(remote, timeout, ...)
    local args = table.pack(...)
    local callerThread = coroutine.running()
    local selfMarked = callerThread and SelfThreads[callerThread]
    local done, result = false, nil
    local thread = task.spawn(function()
        local innerThread = coroutine.running()
        if selfMarked then SelfThreads[innerThread] = true end
        local ok, res = pcall(remote.InvokeServer, remote, table.unpack(args, 1, args.n))
        if selfMarked then SelfThreads[innerThread] = nil end
        if ok then result = res end
        done = true
    end)
    local deadline = tick() + (timeout or 8)
    while not done and tick() < deadline do
        task.wait()
    end
    if not done then
        pcall(task.cancel, thread)
        return nil
    end
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        local args = {...}
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Fire then
                pcall(function() connection:Fire(unpack(args)) end)
            elseif connection.Function then
                task.spawn(connection.Function, unpack(args))
            end
        end
    else
        warn("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            currentTable[flagKey] = task.spawn(featureFunc, ...)
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            warn("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
function AddSliderToggle(Config)
    local Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false,
        Disabled = Config.Disabled,
    })
    local Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    Toggle:OnChanged(function()
        Slider:SetVisible(Toggle.Value)
    end)
    return Toggle, Slider
end
local function GetCharacter()
    local c = Plr.Character
    return (c and c:FindFirstChild("HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function TPTo(target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    hrp.CFrame = cframe
    return true
end
local function GetNearest(list, filterFn)
    local char = GetCharacter()
    local root = char and char:FindFirstChild("HumanoidRootPart")
    if not root then return nil end
    local best, bestDist = nil, math.huge
    for _, inst in ipairs(list) do
        if not filterFn or filterFn(inst) then
            local part = inst:IsA("BasePart") and inst or (inst:IsA("Model") and inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart"))
            if part then
                local dist = (part.Position - root.Position).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    best = inst
                end
            end
        end
    end
    return best, bestDist
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            pcall(function()
                local promptOverlay = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = promptOverlay.promptOverlay:FindFirstChild("ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Players.LocalPlayer)
                    end
                end
            end)
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local success, err = pcall(function()
            local pauseGui = game:GetService("CoreGui").RobloxGui:FindFirstChild("CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    local prevDist = target.MaxActivationDistance
    if teleport then
        local char = GetCharacter()
        local hrp = char and char:FindFirstChild("HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local partPos = isModel and part:GetPivot().Position or part.Position
            local dist = (hrp.Position - partPos).Magnitude
            if dist > prevDist then
                local partCFrame = isModel and part:GetPivot() or part.CFrame
                hrp.CFrame = partCFrame * CFrame.new(0, 3, 0)
                task.wait(0.175)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and Plr.Character:FindFirstChild("HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, true)
        task.wait()
        firetouchinterest(part, root, false)
    end)
end
local function Serverhop()
    local hopSuccess, hopErr = pcall(function()
        local baseUrl = 'https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100'
        local servers = {}
        local cursor = ''
        for _ = 1, 3 do
            local url = baseUrl
            if cursor ~= '' then url = url .. '&cursor=' .. cursor end
            local pages = game:HttpGet(url)
            local data = HttpService:JSONDecode(pages)
            for _, server in ipairs(data.data) do
                if server.playing < server.maxPlayers and server.id ~= game.JobId then
                    table.insert(servers, server)
                end
            end
            cursor = data.nextPageCursor
            if not cursor or cursor == '' then break end
        end
        table.sort(servers, function(a, b) return a.playing < b.playing end)
        if #servers == 0 then
            Library:Notify("No servers found to hop to.", 3)
            return
        end
        local best = servers[1]
        for _, server in ipairs(servers) do
            if server.playing > 0 then
                best = server
                break
            end
        end
        TeleportService:TeleportToPlaceInstance(game.PlaceId, best.id, Players.LocalPlayer)
    end)
    if not hopSuccess then
        Library:Notify("Serverhop failed: " .. tostring(hopErr), 5)
    end
end
local function QueueOnTeleportExec(code)
    if typeof(queue_on_teleport) == "function" then
        queue_on_teleport(code)
    elseif typeof(queueonteleport) == "function" then
        queueonteleport(code)
    end
end
local SlopFuncs = {"RequestTower", "SpawnTower", "UpgradeTower", "SellTower", "ChangeTowerMode", "VoteSkip", "ChangeSpeed", "AutoSkip", "GetPlayerPlacement", "GetAbilityCooldown"}
local SlopEvents = {"ActivateAbility", "EndDecision", "ExitGame", "SkipButton", "AbilityCooldownUpdate", "VoteForMap", "VoteForComplication", "SlopMutator"}
local LobbyEvents = {"EnterElevator", "LeaveElevator", "ElevatorEntered", "StartElevator", "ElevatorLeft", "OnTeleported"}
Support.HookFunction = typeof(hookfunction) == "function"
local PosDir = "Yuri/STD"
local MDir = PosDir .. "/Macros"
local PosPath = PosDir .. "/position.json"
local StatsLabel = nil
local MState = {
    Rec = false,
    Rep = false,
    Cur = nil,
    Load = nil,
    Hooked = false,
    Step = 0,
    Total = 0,
    LabelRef = nil,
    SelfFire = false,
    NextKey = 0,
    RecKeys = {},
    RepMap = {},
    Saved = false,
    PendingLabel = nil,
    Pending = {},
    Adopted = {},
}
local ElevState = {Current = nil, Teleported = false, Started = 0}
local LobbyQuest = {Cache = nil}
local MutatorState = {Ids = {"None", "BossRush", "Gigantism", "Regeneration", "ArmoredSlop", "Speedrun", "Blackout", "Brainrot", "TinySlop"}}
local MutatorPriorityGetters = {}
local Place = {
    FailPos = {},
    TypeFails = {},
    PauseUntil = {},
    GridCache = nil,
    GridKey = "",
    SpiralCenter = nil,
    SpiralCursor = 0,
    Spiral = nil,
    SpiralFailMemo = {},
    SlotPositions = {},
    MapLabelRef = nil,
    PosLabelRef = nil,
}
local Memo = {
    SpeedDone = 0,
    AbilityAt = {},
    SummonFails = 0,
}
local function GetInfo()
    return workspace:FindFirstChild("Info")
end
local function IsMatchActive()
    local info = GetInfo()
    if not info then return false end
    local running = info:FindFirstChild("GameRunning")
    return (running and running.Value == true) or false
end
local function GetWave()
    local info = GetInfo()
    if not info then return 0 end
    local wave = info:FindFirstChild("Wave")
    return wave and wave.Value or 0
end
local function GetRemainingTime()
    local info = GetInfo()
    if not info then return nil end
    local min = info:FindFirstChild("Min")
    local sec = info:FindFirstChild("Sec")
    if not (min and sec) then return nil end
    return min.Value * 60 + sec.Value
end
local function GetCash()
    local cash = Plr:FindFirstChild("Cash")
    return cash and cash.Value or 0
end
local function GetTowerLimit()
    local mt = RS:FindFirstChild("maxTowers")
    return (mt and mt.Value) or 10
end
local function GetPlacedCount()
    local pt = Plr:FindFirstChild("PlacedTowers")
    return (pt and pt.Value) or 0
end
local function GetTowersFolder()
    return workspace:FindFirstChild("Towers")
end
local function IsOwnedTower(tower)
    if typeof(tower) ~= "Instance" then return false end
    local config = tower:FindFirstChild("Config")
    local owner = config and config:FindFirstChild("Owner")
    return owner ~= nil and owner.Value == Plr.Name
end
local function GetOwnedTowers()
    local folder = GetTowersFolder()
    local list = {}
    if not folder then return list end
    for _, tower in ipairs(folder:GetChildren()) do
        if IsOwnedTower(tower) then
            table.insert(list, tower)
        end
    end
    return list
end
local function GetTowerLevel(tower)
    if typeof(tower) ~= "Instance" then return nil end
    local config = tower:FindFirstChild("Config")
    local lvl = config and config:FindFirstChild("LVL")
    return lvl and lvl.Value or 0
end
local function GetTowerID(tower)
    if typeof(tower) ~= "Instance" then return nil end
    local ok, id = pcall(tower.GetAttribute, tower, "ID")
    if ok then return id end
    return nil
end
local function GetTowerModel(name)
    if type(name) ~= "string" then return nil end
    local towers = RS:FindFirstChild("Towers")
    return towers and towers:FindFirstChild(name) or nil
end
local function GetNextUpgrade(name, level)
    if type(name) ~= "string" then return nil end
    local lvls = GetSafeModule(RS, "LVLs")
    if type(lvls) ~= "table" then return nil end
    local chain = lvls[name]
    if type(chain) ~= "table" then return nil end
    return chain[(level or 0) + 1]
end
local function GetPlacementMax(name)
    local modules = RS:FindFirstChild("Modules")
    if not modules then return nil end
    local mod = GetSafeModule(modules, "TowersPlacementsMax")
    if type(mod) ~= "table" then return nil end
    return mod[name]
end
local function GetTowerPrice(name)
    local model = GetTowerModel(name)
    if not model then return nil end
    local config = model:FindFirstChild("Config")
    local price = config and config:FindFirstChild("Price")
    return price and price.Value or nil
end
local function CountOwnedByName(name)
    local count = 0
    for _, tower in ipairs(GetOwnedTowers()) do
        if tower.Name == name then
            count = count + 1
        end
    end
    return count
end
local function GetPlayerDataRaw()
    local remotes = RS:FindFirstChild("Remotes")
    local pd = remotes and remotes:FindFirstChild("PlayerData")
    local getter = pd and pd:FindFirstChild("GetData")
    if not (getter and getter:IsA("RemoteFunction")) then return nil end
    local data = SafeInvoke(getter, 8)
    if type(data) == "table" then return data end
    return nil
end
local function GetTowerEntryForName(name, slot)
    local data = GetPlayerDataRaw()
    if not data then return nil, nil end
    local towers = data.Towers
    if type(towers) ~= "table" then return nil, nil end
    if slot ~= nil then
        for k, v in pairs(towers) do
            if type(v) == "table" and v.Name == name and v.Equipped == slot then
                return k, v
            end
        end
    end
    for k, v in pairs(towers) do
        if type(v) == "table" and v.Name == name then
            return k, v
        end
    end
    return nil, nil
end
local function Invoke(remote, ...)
    if not remote then return nil end
    local args = {...}
    local thread = coroutine.running()
    if thread then SelfThreads[thread] = true end
    MState.SelfFire = true
    local result = SafeInvoke(remote, 1, unpack(args))
    if thread then SelfThreads[thread] = nil end
    MState.SelfFire = false
    return result
end
local function Fire(remote, ...)
    local args = {...}
    MState.SelfFire = true
    local ok = FireRemote(remote, unpack(args))
    MState.SelfFire = false
    return ok
end
local function FireBindable(remote, ...)
    if not remote then return false end
    local args = {...}
    local ok, err = pcall(function()
        remote:Fire(unpack(args))
    end)
    if not ok then notyuri("FireBindable error:", tostring(remote), tostring(err)) end
    return ok
end
local function LoadMDir()
    if not writefile then return end
    pcall(function()
        local built = ""
        for _, part in ipairs(MDir:split("/")) do
            built = (built == "") and part or (built .. "/" .. part)
            if not isfolder(built) then
                makefolder(built)
            end
        end
    end)
end
local function ListMacros()
    local names = {}
    if not listfiles then return names end
    local ok, files = pcall(listfiles, MDir)
    if not ok or type(files) ~= "table" then return names end
    for _, path in ipairs(files) do
        if type(path) == "string" and path:sub(-5):lower() == ".json" then
            local fname = path:match("([^/\\]+)%.json$")
            if fname and fname ~= "" then
                table.insert(names, fname)
            end
        end
    end
    table.sort(names)
    return names
end
local function LoadMacro(name)
    if not name or name == "" or not readfile then return nil end
    local path = MDir .. "/" .. name .. ".json"
    if not isfile(path) then return nil end
    local ok, raw = pcall(readfile, path)
    if not ok or type(raw) ~= "string" or raw == "" then return nil end
    local data
    pcall(function()
        data = HttpService:JSONDecode(raw)
    end)
    if type(data) ~= "table" then return nil end
    local entries = {}
    local i = 1
    while data[tostring(i)] do
        entries[i] = data[tostring(i)]
        i = i + 1
    end
    return {entries = entries}
end
local function SaveMacro(name, macro)
    if not name or name == "" or not writefile then return false end
    LoadMDir()
    local path = MDir .. "/" .. name .. ".json"
    local out = {}
    for i, entry in ipairs(macro.entries) do
        out[tostring(i)] = entry
    end
    local ok = pcall(function()
        writefile(path, HttpService:JSONEncode(out))
    end)
    return ok
end
local function EnsurePosDir()
    if not makefolder or not isfolder then return end
    pcall(function()
        local built = ""
        for _, part in ipairs(PosDir:split("/")) do
            built = (built == "") and part or (built .. "/" .. part)
            if not isfolder(built) then
                makefolder(built)
            end
        end
    end)
end
local function SavePositions()
    if not writefile then return false end
    EnsurePosDir()
    local out = {}
    for mapName, slots in pairs(Place.SlotPositions) do
        local slotOut = {}
        for slot, cfs in pairs(slots) do
            local cfOut = {}
            for i, cf in ipairs(cfs) do
                cfOut[i] = {cf:GetComponents()}
            end
            slotOut[tostring(slot)] = cfOut
        end
        out[mapName] = slotOut
    end
    local ok = pcall(function()
        writefile(PosPath, HttpService:JSONEncode(out))
    end)
    return ok
end
local function LoadPositions()
    if not readfile or not isfile then return end
    if not isfile(PosPath) then return end
    local ok, raw = pcall(readfile, PosPath)
    if not ok or type(raw) ~= "string" or raw == "" then return end
    local data
    pcall(function()
        data = HttpService:JSONDecode(raw)
    end)
    if type(data) ~= "table" then return end
    local loaded = {}
    for mapName, slots in pairs(data) do
        if type(slots) == "table" then
            loaded[mapName] = {}
            for slotStr, cfs in pairs(slots) do
                local slot = tonumber(slotStr)
                if slot and type(cfs) == "table" then
                    local cfList = {}
                    for i, comp in ipairs(cfs) do
                        if type(comp) == "table" and #comp == 12 then
                            cfList[i] = CFrame.new(unpack(comp))
                        end
                    end
                    loaded[mapName][slot] = cfList
                end
            end
        end
    end
    Place.SlotPositions = loaded
end
local function UpdateMacroLabel(suffix, elapsed)
    if not (MState.LabelRef and MState.LabelRef.SetText) then return end
    local txt
    local timeStr = ""
    if type(elapsed) == "number" then
        timeStr = " " .. tostring(elapsed)
    elseif type(elapsed) == "string" then
        timeStr = " " .. elapsed
    end
    if MState.Rec then
        if suffix then
            txt = string.format("Recording [%d] %s%s", MState.Step, suffix, timeStr)
        else
            txt = string.format("Recording [%d]", MState.Step)
        end
    elseif MState.Rep then
        txt = string.format("Replaying [%d / %d]", MState.Step, MState.Total)
        if suffix then txt = txt .. " | " .. suffix .. timeStr end
    else
        txt = "Idle" .. (suffix and (" | " .. suffix) or "")
    end
    notyuri("UpdateLabel", txt)
    if MState.Rec then
        MState.PendingLabel = txt
    else
        local ok, err = pcall(function()
            MState.LabelRef:SetText(txt)
        end)
        if not ok then
            notyuri("SetText FAILED:", tostring(err))
            MState.PendingLabel = txt
        end
    end
end
local function LabelPump()
    while MState.Rec do
        if MState.PendingLabel then
            local txt = MState.PendingLabel
            MState.PendingLabel = nil
            local ok, err = pcall(function()
                MState.LabelRef:SetText(txt)
            end)
            if not ok then
                notyuri("LabelPump SetText FAILED:", tostring(err))
            end
        end
        task.wait()
    end
end
local function RecordAct(kind, data, wave, elapsed)
    if not MState.Cur then return end
    MState.Step = MState.Step + 1
    local entry = {Type = kind, Time = tostring(wave or 0) .. " " .. tostring(elapsed or 0)}
    for k, val in pairs(data or {}) do
        entry[k] = val
    end
    table.insert(MState.Cur.entries, entry)
    UpdateMacroLabel(kind, entry.Time)
    notyuri("", kind, "confirmed", "wave", tostring(wave), string.format("%.2fs", elapsed))
end
local function ParseMacroTime(entry)
    local wStr, eStr = (entry.Time or ""):match("^(%d+)%s+(.+)$")
    return tonumber(wStr) or 0, tonumber(eStr) or 0
end
local function SortMacroEntries(entries)
    table.sort(entries, function(a, b)
        local wa, ea = ParseMacroTime(a)
        local wb, eb = ParseMacroTime(b)
        if wa ~= wb then return wa < wb end
        return ea > eb
    end)
end
local function TowerNearPos(tower, pos, radius)
    local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
    if not (pp and pos) then return false end
    return (pp.Position - pos).Magnitude <= (radius or 4)
end
local function EnsureRecKey(inst)
    if typeof(inst) ~= "Instance" then return nil end
    local key = MState.RecKeys[inst]
    if not key then
        MState.NextKey = MState.NextKey + 1
        key = MState.NextKey
        MState.RecKeys[inst] = key
        MState.Adopted[key] = true
    end
    return key
end
local function ConfirmPlace(pend, inst)
    pend.Resolved = true
    local key = EnsureRecKey(inst)
    if not key then
        pend.Dropped = true
        return
    end
    pend.Key = key
    RecordAct("Place", {Key = key, Name = pend.Name, CF = pend.CF, ID = pend.ID, Mods = pend.Mods}, pend.Wave, pend.Elapsed)
    if pend.Late then
        notyuri("Place late-confirmed key=" .. tostring(key) .. " (" .. tostring(pend.Name) .. ")")
    end
end
local function ConfirmSpawnUpgrade(pend, inst)
    pend.Resolved = true
    local key = nil
    if typeof(pend.Tower) == "Instance" then
        key = MState.RecKeys[pend.Tower]
    end
    key = key or EnsureRecKey(inst)
    if not key then
        pend.Dropped = true
        return
    end
    MState.RecKeys[inst] = key
    if typeof(pend.Tower) == "Instance" then
        MState.RecKeys[pend.Tower] = key
    end
    pend.Key = key
    RecordAct("SpawnUpgrade", {Key = key, Name = pend.Name, CF = pend.CF, ID = pend.ID, Mods = pend.Mods}, pend.Wave, pend.Elapsed)
    if pend.Late then
        notyuri("SpawnUpgrade late-confirmed key=" .. tostring(key) .. " (" .. tostring(pend.Name) .. ")")
    end
end
local function ConfirmUpgrade(pend, inst)
    pend.Resolved = true
    local key = nil
    if typeof(pend.Tower) == "Instance" then
        key = MState.RecKeys[pend.Tower]
    end
    key = key or EnsureRecKey(inst)
    if not key then
        pend.Dropped = true
        return
    end
    MState.RecKeys[inst] = key
    if typeof(pend.Tower) == "Instance" then
        MState.RecKeys[pend.Tower] = key
    end
    pend.Key = key
    RecordAct("Upgrade", {Key = key, Name = pend.Name, LVL = GetTowerLevel(inst), CF = pend.CF}, pend.Wave, pend.Elapsed)
    if pend.Late then
        notyuri("Upgrade late-confirmed key=" .. tostring(key) .. " (" .. tostring(pend.Name) .. ")")
    end
end
local function ConfirmSell(pend, late)
    pend.Resolved = true
    local key = nil
    if typeof(pend.Tower) == "Instance" then
        key = MState.RecKeys[pend.Tower]
        MState.RecKeys[pend.Tower] = nil
    end
    if not key and typeof(pend.Tower) == "Instance" then
        key = EnsureRecKey(pend.Tower)
        MState.RecKeys[pend.Tower] = nil
    end
    pend.Key = key
    local data = {Key = key, Name = pend.Name}
    if pend.CF then data.CF = pend.CF end
    RecordAct("Sell", data, pend.Wave, pend.Elapsed)
    if late then
        notyuri("Sell late-confirmed key=" .. tostring(key))
    end
end
local function ConfirmMode(pend)
    pend.Resolved = true
    local key = nil
    if typeof(pend.Tower) == "Instance" then
        key = MState.RecKeys[pend.Tower] or EnsureRecKey(pend.Tower)
        MState.RecKeys[pend.Tower] = key
    end
    pend.Key = key
    RecordAct("Mode", {Key = key, Name = pend.Name, CF = pend.CF}, pend.Wave, pend.Elapsed)
end
local function RecordMode(tower)
    if not (MState.Rec and MState.Cur) then return end
    if typeof(tower) ~= "Instance" then return end
    local pend = {Tower = tower, Name = tower.Name}
    local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
    if pp then
        pend.CF = {pp.CFrame:GetComponents()}
    end
    pend.Wave = GetWave()
    pend.Elapsed = GetRemainingTime()
    ConfirmMode(pend)
end
local function SnapshotCall(self, nargs)
    if not (MState.Rec and MState.Cur) then return nil end
    local wave = GetWave()
    local elapsed = GetRemainingTime()
    local pend
    if rawequal(self, Remotes.SpawnTower) then
        local name = nargs[2]
        local cf = nargs[3]
        local third = nargs[4]
        if type(name) ~= "string" or typeof(cf) ~= "CFrame" then return nil end
        local comps = {cf:GetComponents()}
        pend = {
            Kind = (typeof(third) == "Instance") and "SpawnUpgrade" or "Place",
            Name = name,
            ID = nargs[5],
            Mods = (type(nargs[6]) == "table") and nargs[6] or {},
            Tower = (typeof(third) == "Instance") and third or nil,
            CF = comps,
            Position = Vector3.new(comps[1], comps[2], comps[3]),
        }
    elseif rawequal(self, Remotes.UpgradeTower) then
        local tower = nargs[2]
        if typeof(tower) ~= "Instance" then return nil end
        pend = {Kind = "Upgrade", Tower = tower, Name = tower.Name, ID = nargs[3]}
        local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
        if pp then
            pend.Position = pp.Position
            local comps = {pp.CFrame:GetComponents()}
            pend.CF = comps
        end
    elseif rawequal(self, Remotes.SellTower) or rawequal(self, Remotes.ChangeTowerMode) then
        local tower = nargs[2]
        if typeof(tower) ~= "Instance" then return nil end
        pend = {
            Kind = rawequal(self, Remotes.SellTower) and "Sell" or "Mode",
            Tower = tower,
            Name = tower.Name,
        }
        local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
        if pp then
            pend.Position = pp.Position
            local comps = {pp.CFrame:GetComponents()}
            pend.CF = comps
        end
    else
        return nil
    end
    pend.Wave = wave
    pend.Elapsed = elapsed
    pend.At = tick()
    pend.Resolved = false
    table.insert(MState.Pending, pend)
    notyuri("", pend.Kind, "captured", tostring(pend.Name), "wave", tostring(wave), string.format("%.2fs", elapsed))
    return pend
end
local function ResolveCall(pend, ret)
    if not (pend and not pend.Resolved) then return end
    local result = (ret and ret.n and ret.n > 0) and ret[1] or nil
    if pend.Kind == "Place" then
        if typeof(result) == "Instance" then
            ConfirmPlace(pend, result)
        end
    elseif pend.Kind == "SpawnUpgrade" then
        if typeof(result) == "Instance" then
            ConfirmSpawnUpgrade(pend, result)
        end
    elseif pend.Kind == "Upgrade" then
        if typeof(result) == "Instance" then
            ConfirmUpgrade(pend, result)
        end
    elseif pend.Kind == "Sell" then
        if result then
            ConfirmSell(pend, false)
        end
    elseif pend.Kind == "Mode" then
        if result then
            ConfirmMode(pend)
        else
            pend.Resolved = true
            pend.Dropped = true
        end
    end
end
local function FindUnkeyedOwnedTower(predFn)
    for _, tower in ipairs(GetOwnedTowers()) do
        if not MState.RecKeys[tower] and predFn(tower) then
            return tower
        end
    end
    return nil
end
local function ProcessPendingSweep()
    local now = tick()
    for _, pend in ipairs(MState.Pending) do
        if not pend.Resolved then
            local age = now - pend.At
            if age > 12 then
                pend.Resolved = true
                pend.Dropped = true
                notyuri("", pend.Kind, "expired unresolved:", tostring(pend.Name))
            elseif age > 0.6 then
                if pend.Kind == "Place" then
                    local inst = FindUnkeyedOwnedTower(function(t)
                        return t.Name == pend.Name and TowerNearPos(t, pend.Position, 4)
                    end)
                    if inst then
                        pend.Late = true
                        ConfirmPlace(pend, inst)
                    end
                elseif pend.Kind == "SpawnUpgrade" or pend.Kind == "Upgrade" then
                    local inst = FindUnkeyedOwnedTower(function(t)
                        return t.Name == pend.Name and TowerNearPos(t, pend.Position, 4)
                    end)
                    if inst then
                        pend.Late = true
                        if pend.Kind == "Upgrade" then
                            ConfirmUpgrade(pend, inst)
                        else
                            ConfirmSpawnUpgrade(pend, inst)
                        end
                    end
                elseif pend.Kind == "Sell" then
                    local old = pend.Tower
                    if typeof(old) ~= "Instance" or old.Parent == nil then
                        pend.Late = true
                        ConfirmSell(pend, true)
                    end
                end
            end
        end
    end
    local kept = {}
    for _, pend in ipairs(MState.Pending) do
        if not pend.Resolved then
            table.insert(kept, pend)
        end
    end
    MState.Pending = kept
end
local function MacroSweeper()
    while MState.Rec do
        local ok, err = pcall(ProcessPendingSweep)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
    for _ = 1, 3 do
        if MState.Rec then break end
        if not MState.Cur then break end
        pcall(ProcessPendingSweep)
        task.wait()
    end
end
local function WaitForMacroRemotes()
    local deadline = tick() + 8
    local folder = RS:FindFirstChild("Functions")
    if not folder then return end
    for _, name in ipairs({"SpawnTower", "UpgradeTower", "SellTower", "ChangeTowerMode"}) do
        if not Remotes[name] then
            local remote = folder:FindFirstChild(name)
            if not remote then
                remote = folder:WaitForChild(name, math.max(0, deadline - tick()))
            end
            if remote and (remote:IsA("RemoteFunction") or remote:IsA("RemoteEvent")) then
                Remotes[name] = remote
            end
        end
    end
end
local function InstallMacroHook()
    if MState.Hooked then return end
    if not Support.HookMeta then
        Library:Notify("Macro record requires hookmetamethod support", 4)
        return
    end
    WaitForMacroRemotes()
    MState.Hooked = true
    local cc = (typeof(newcclosure) == "function") and newcclosure or (function(f) return f end)
    local originalNamecall
    originalNamecall = hookmetamethod(game, "__namecall", cc(function(...)
        local self = ...
        local method = getnamecallmethod()
        local ret = table.pack(originalNamecall(...))
        if method == "InvokeServer" and MState.Rec and not SelfThreads[coroutine.running() or false] then
            local isSpawn = rawequal(self, Remotes.SpawnTower)
            local isUpgrade = rawequal(self, Remotes.UpgradeTower)
            local isSell = rawequal(self, Remotes.SellTower)
            local isMode = rawequal(self, Remotes.ChangeTowerMode)
            if isSpawn or isUpgrade or isSell or isMode then
                local nargs = table.pack(...)
                local ok, snap = pcall(SnapshotCall, self, nargs)
                if ok and snap then
                    local ok2, err = pcall(ResolveCall, snap, ret)
                    if not ok2 then
                        notyuri("resolve error:", tostring(err))
                    end
                end
            end
        end
        return table.unpack(ret, 1, ret.n)
    end))
    notyuri("__namecall hook installed (captures place/upgrade/sell/mode via dot-call InvokeServer)")
end
local function Func_MacroRecord(state)
    if not state then return end
    if Toggles.LoadMacro and Toggles.LoadMacro.Value then
        Toggles.LoadMacro:SetValue(false)
    end
    InstallMacroHook()
    MState.Cur = {entries = {}}
    MState.Step = 0
    MState.NextKey = 0
    MState.RecKeys = {}
    MState.Saved = false
    MState.Pending = {}
    MState.Adopted = {}
    UpdateMacroLabel("Waiting")
    notyuri("waiting for match to start")
    while Toggles.MacroRecord.Value and not IsMatchActive() do
        task.wait()
    end
    if not Toggles.MacroRecord.Value then
        MState.Cur = nil
        MState.Step = 0
        UpdateMacroLabel()
        return
    end
    MState.Rec = true
    UpdateMacroLabel()
    task.spawn(LabelPump)
    task.spawn(MacroSweeper)
    notyuri("recording started")
    while Toggles.MacroRecord.Value and IsMatchActive() do
        task.wait()
    end
    MState.Rec = false
    task.wait()
    local entries = MState.Cur and #MState.Cur.entries or 0
    notyuri("recording stopped,", tostring(entries), "actions")
    if entries > 0 and not MState.Saved then
        MState.Saved = true
        SortMacroEntries(MState.Cur.entries)
        local recorded = MState.Cur
        local fname = (Options.FileName and Options.FileName.Value) or ""
        if fname == "" then
            fname = "Macro_" .. os.date("%Y%m%d_%H%M%S")
        end
        task.spawn(function()
            local ok = SaveMacro(fname, recorded)
            if ok then
                Library:Notify("Macro saved: " .. fname, 4)
                if Options.MacroSelected then
                    Options.MacroSelected:SetValues(ListMacros())
                end
            else
                Library:Notify("Failed to save macro (writefile unsupported?)", 4)
            end
        end)
    end
    MState.Cur = nil
    MState.Step = 0
    UpdateMacroLabel()
end
local function GetMacroEntryCost(entry)
    if entry.Type == "Place" then
        return GetTowerPrice(entry.Name)
    elseif entry.Type == "Upgrade" then
        local lvls = GetSafeModule(RS, "LVLs")
        if type(lvls) == "table" and type(lvls[entry.Name]) == "table" and type(entry.LVL) == "number" then
            local cfg = lvls[entry.Name][entry.LVL]
            if type(cfg) == "table" then return cfg.Price end
        end
        return nil
    end
    return nil
end
local function WaitForCash(amount, timeout)
    if not amount or amount <= 0 then return true end
    if GetCash() >= amount then return true end
    local limit = timeout or 60
    local start = tick()
    while Toggles.LoadMacro.Value and GetCash() < amount and (tick() - start) < limit do
        task.wait()
    end
    return Toggles.LoadMacro.Value and GetCash() >= amount
end
local function FindTowerForEntry(entry)
    local t = entry.Key and MState.RepMap[entry.Key]
    if t and t.Parent and (t.PrimaryPart or t:FindFirstChild("HumanoidRootPart")) then
        return t
    end
    local cf = entry.CF
    if type(cf) ~= "table" or #cf ~= 12 then return nil end
    local pos = Vector3.new(cf[1], cf[2], cf[3])
    local base = entry.Name
    if type(base) ~= "string" or base == "" then return nil end
    local best, bestDist = nil, 5
    for _, tower in ipairs(GetOwnedTowers()) do
        local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
        if pp and tower.Name == base then
            local dist = (pp.Position - pos).Magnitude
            if dist < bestDist then
                best, bestDist = tower, dist
            end
        end
    end
    if best then
        notyuri("position fallback resolved key", tostring(entry.Key), "->", tostring(best.Name), string.format("(%.1f studs)", bestDist))
        if entry.Key then
            MState.RepMap[entry.Key] = best
        end
    end
    return best
end
local function ResolveTowerRetry(entry)
    local tower = FindTowerForEntry(entry)
    if tower and tower.Parent then return tower end
    local start = tick()
    while Toggles.LoadMacro.Value and (tick() - start) < 1 do
        task.wait()
        tower = FindTowerForEntry(entry)
        if tower and tower.Parent then return tower end
    end
    return nil
end
local function AnchorTowerHRP(model)
    if typeof(model) ~= "Instance" then return end
    local hrp = model:FindFirstChild("HumanoidRootPart")
    if hrp then
        pcall(function()
            hrp.Anchored = true
        end)
    end
end
local function ResolvePlaceID(entry)
    if entry.ID ~= nil then
        return entry.ID, (type(entry.Mods) == "table" and entry.Mods) or {}
    end
    local k, entryData = GetTowerEntryForName(entry.Name)
    if k ~= nil then
        return k, (entryData and type(entryData.Modifiers) == "table" and entryData.Modifiers) or {}
    end
    return nil, {}
end
local function DoMacroAction(entry)
    if entry.Type == "Place" then
        local cf = entry.CF
        if type(cf) ~= "table" or #cf ~= 12 then return end
        local id, mods = ResolvePlaceID(entry)
        if id == nil then
            notyuri("Place SKIP: no tower entry for", tostring(entry.Name))
            return
        end
        local result
        for batch = 1, 3 do
            if not Toggles.LoadMacro.Value then break end
            for attempt = 1, 20 do
                if not Toggles.LoadMacro.Value then break end
                result = Invoke(Remotes.SpawnTower, entry.Name, CFrame.new(unpack(cf)), false, id, mods)
                if typeof(result) == "Instance" then break end
            end
            if typeof(result) == "Instance" then break end
            local existing = FindTowerForEntry(entry)
            if existing then
                result = existing
                notyuri("Place retry not needed: tower already at position", tostring(entry.Name))
                break
            end
            if batch < 3 then
                local cost = GetMacroEntryCost(entry)
                notyuri("Place rejected, waiting for cash, batch", batch, "of 3")
                if not WaitForCash(cost, 5) then break end
            end
        end
        if typeof(result) == "Instance" then
            if entry.Key then
                MState.RepMap[entry.Key] = result
            end
            AnchorTowerHRP(result)
        elseif not (entry.Key and MState.RepMap[entry.Key]) then
            notyuri("Place SKIP: server rejected after 20 attempts", tostring(entry.Name))
        end
    elseif entry.Type == "Upgrade" then
        local tower = ResolveTowerRetry(entry)
        if not (tower and tower.Parent) then
            notyuri("Upgrade SKIP: no tower resolved for key", tostring(entry.Key))
            return
        end
        if type(entry.LVL) == "number" then
            local curLvl = GetTowerLevel(tower)
            if curLvl and curLvl >= entry.LVL then
                notyuri("Upgrade skip: already at level", tostring(curLvl))
                return
            end
        end
        local cost = GetMacroEntryCost(entry)
        local result
        for attempt = 1, 20 do
            if not Toggles.LoadMacro.Value then break end
            result = Invoke(Remotes.UpgradeTower, tower, GetTowerID(tower))
            if typeof(result) == "Instance" then break end
            if attempt < 20 then
                notyuri("Upgrade rejected for key", tostring(entry.Key), "waiting for cash, attempt", attempt, "of 20")
                if not WaitForCash(cost, 5) then break end
            end
        end
        if typeof(result) == "Instance" then
            if entry.Key then
                MState.RepMap[entry.Key] = result
            end
            AnchorTowerHRP(result)
            task.wait()
            FireBindable(Remotes.toggleClient, result)
        else
            notyuri("Upgrade SKIP: server rejected for key after 20 attempts", tostring(entry.Key))
        end
    elseif entry.Type == "SpawnUpgrade" then
        local tower = ResolveTowerRetry(entry)
        local cf = entry.CF
        if type(cf) ~= "table" or #cf ~= 12 then return end
        if not (tower and tower.Parent) then
            notyuri("SpawnUpgrade SKIP: no tower resolved for key", tostring(entry.Key))
            return
        end
        local id, mods = ResolvePlaceID(entry)
        local result = Invoke(Remotes.SpawnTower, entry.Name, CFrame.new(unpack(cf)), tower, id, mods)
        if typeof(result) == "Instance" then
            if entry.Key then
                MState.RepMap[entry.Key] = result
            end
            AnchorTowerHRP(result)
            task.wait()
            FireBindable(Remotes.toggleClient, result)
        else
            notyuri("SpawnUpgrade SKIP: server rejected for key", tostring(entry.Key))
        end
    elseif entry.Type == "Sell" then
        local tower = ResolveTowerRetry(entry)
        if not (tower and tower.Parent) then
            notyuri("Sell SKIP: no tower resolved for key", tostring(entry.Key))
            return
        end
        local ok = Invoke(Remotes.SellTower, tower)
        if ok then
            if entry.Key then
                MState.RepMap[entry.Key] = nil
            end
            FireBindable(Remotes.toggleClient)
        end
    elseif entry.Type == "Mode" then
        local tower = ResolveTowerRetry(entry)
        if not (tower and tower.Parent) then
            notyuri("Mode SKIP: no tower resolved for key", tostring(entry.Key))
            return
        end
        Invoke(Remotes.ChangeTowerMode, tower)
    end
end
local function Func_MacroReplay()
    while Toggles.LoadMacro.Value do
        local macro = MState.Load
        if not macro or not macro.entries or #macro.entries == 0 then
            Toggles.LoadMacro:SetValue(false)
            Library:Notify("No macro loaded", 3)
            return
        end
        MState.Rep = true
        MState.Total = #macro.entries
        MState.Step = 0
        MState.RepMap = {}
        SortMacroEntries(macro.entries)
        UpdateMacroLabel()
        while Toggles.LoadMacro.Value and not IsMatchActive() do
            task.wait()
        end
        if not Toggles.LoadMacro.Value then break end
        for i, entry in ipairs(macro.entries) do
            if not Toggles.LoadMacro.Value then break end
            if not IsMatchActive() then
                notyuri("match ended mid-pass, aborting pass")
                break
            end
            MState.Step = i
            UpdateMacroLabel(entry.Type, entry.Time)
            local replayMode = Options.ReplayMode and Options.ReplayMode.Value or "Time"
            local skipStep = false
            if replayMode == "Money" then
                local cost = GetMacroEntryCost(entry)
                if cost and cost > 0 then
                    if not WaitForCash(cost) then
                        notyuri("money wait aborted (toggle off)")
                    end
                end
            else
                local tWave, tElapsed = ParseMacroTime(entry)
                while Toggles.LoadMacro.Value and GetWave() < tWave do
                    if not IsMatchActive() then break end
                    task.wait()
                end
                if not Toggles.LoadMacro.Value then break end
                if GetWave() > tWave + 10 then
                    skipStep = true
                else
                    local diff = GetRemainingTime() - tElapsed
                    if diff > 0 then
                        while Toggles.LoadMacro.Value and IsMatchActive() and GetRemainingTime() > tElapsed do
                            task.wait()
                        end
                    end
                end
            end
            if not Toggles.LoadMacro.Value then break end
            if not skipStep then
                local ok, err = pcall(DoMacroAction, entry)
                if not ok then
                    notyuri("action failed:", tostring(err))
                end
                task.wait(0)
            else
                UpdateMacroLabel("skipped")
                notyuri("skipped stale entry", entry.Type, tostring(entry.Time))
            end
        end
        MState.Rep = false
        MState.Step = 0
        UpdateMacroLabel("Finished")
        if Toggles.LoadMacro.Value then
            UpdateMacroLabel("Waiting")
            while Toggles.LoadMacro.Value and IsMatchActive() do
                task.wait()
            end
            while Toggles.LoadMacro.Value and not IsMatchActive() do
                task.wait()
            end
        end
    end
    MState.Rep = false
    UpdateMacroLabel()
end
local function GetTowerAreaParts()
    local folder = GetObject(workspace, "Map.Base.TowerArea")
    if not folder then return nil end
    local parts = {}
    for _, child in ipairs(folder:GetChildren()) do
        if child:IsA("BasePart") then
            table.insert(parts, child)
        end
    end
    if #parts == 0 then return nil end
    table.sort(parts, function(a, b)
        return (a.Size.X * a.Size.Z) > (b.Size.X * b.Size.Z)
    end)
    return parts
end
local function BuildPlacementGrid(spacing)
    local parts = GetTowerAreaParts()
    if not parts then return nil end
    local s = math.clamp(spacing or 4, 3, 12)
    local grid = {}
    for _, part in ipairs(parts) do
        local halfX = part.Size.X / 2
        local halfZ = part.Size.Z / 2
        local minX = part.Position.X - halfX + (s / 2)
        local maxX = part.Position.X + halfX - (s / 2)
        local minZ = part.Position.Z - halfZ + (s / 2)
        local maxZ = part.Position.Z + halfZ - (s / 2)
        local x = minX
        while x <= maxX do
            local z = minZ
            while z <= maxZ do
                table.insert(grid, {Part = part, X = x, Z = z})
                z = z + s
            end
            x = x + s
        end
    end
    return grid
end
local function GetPlacementGrid()
    local spacing = 1.5
    local key = tostring(spacing)
    local alive = Place.GridCache and Place.GridCache[1] and Place.GridCache[1].Part and Place.GridCache[1].Part.Parent ~= nil
    if Place.GridKey ~= key or not alive then
        Place.GridCache = BuildPlacementGrid(spacing)
        Place.GridKey = key
    end
    return Place.GridCache
end
local function ClearExpiredFailPos()
    local now = tick()
    for pos, expiry in pairs(Place.FailPos) do
        if expiry < now then
            Place.FailPos[pos] = nil
        end
    end
end
local function GetSpotForTower(model)
    local grid = GetPlacementGrid()
    if not grid then return nil end
    ClearExpiredFailPos()
    local hip = 0
    local legY = 2
    local humanoid = model:FindFirstChildOfClass("Humanoid")
    if humanoid then hip = humanoid.HipHeight end
    local hrp = model.PrimaryPart or model:FindFirstChild("HumanoidRootPart")
    if hrp then legY = hrp.Size.Y / 2 end
    local rot = (Options.PlaceRotation and Options.PlaceRotation.Value) or 0
    local towersFolder = GetTowersFolder()
    for _, spot in ipairs(grid) do
        local posKey = string.format("%.1f,%.1f", spot.X, spot.Z)
        if not Place.FailPos[posKey] then
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Include
            params.FilterDescendantsInstances = {spot.Part}
            local origin = Vector3.new(spot.X, spot.Part.Position.Y + 60, spot.Z)
            local result = workspace:Raycast(origin, Vector3.new(0, -200, 0), params)
            if result then
                local blocked = false
                if towersFolder then
                    for _, tower in ipairs(towersFolder:GetChildren()) do
                        local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
                        if pp then
                            local dx = pp.Position.X - spot.X
                            local dz = pp.Position.Z - spot.Z
                            if (dx * dx + dz * dz) < 9 then
                                blocked = true
                                break
                            end
                        end
                    end
                end
                if not blocked then
                    local y = result.Position.Y + hip + legY
                    local cf = CFrame.new(spot.X, y, spot.Z) * CFrame.Angles(0, math.rad(rot), 0)
                    return cf, posKey
                end
            end
        end
    end
    return nil
end
local PCubePool = {
    Free = {},
    Active = {},
}
local function PCubeAcq()
    local part = table.remove(PCubePool.Free)
    if not part then
        part = Instance.new("Part")
        part.Name = "PCube"
        part.Size = Vector3.new(0.5, 0.5, 0.5)
        part.Anchored = true
        part.CanCollide = false
        part.CastShadow = false
        part.Material = Enum.Material.Neon
    end
    part.Transparency = 0.55
    part.Color = Color3.fromRGB(80, 160, 255)
    part.Parent = workspace
    PCubePool.Active[part] = true
    return part
end
local function PCubeRelease(part)
    if not part or not PCubePool.Active[part] then return end
    PCubePool.Active[part] = nil
    part.Parent = nil
    table.insert(PCubePool.Free, part)
end
local function PCubeReleaseAll()
    for part in pairs(PCubePool.Active) do
        PCubePool.Active[part] = nil
        part.Parent = nil
        table.insert(PCubePool.Free, part)
    end
end
local function GetSpiralCenter()
    if Place.SpiralCenter then
        return Place.SpiralCenter
    end
    local parts = GetTowerAreaParts()
    if not parts or not parts[1] then return nil end
    Place.SpiralCenter = parts[1].Position
    return Place.SpiralCenter
end
local function SpiralNext(spacing)
    local center = GetSpiralCenter()
    if not center then return nil end
    local cursor = Place.SpiralCursor
    Place.SpiralCursor = cursor + 1
    if cursor == 0 then
        return Vector3.new(center.X, center.Y, center.Z)
    end
    local st = Place.Spiral
    st.x = st.x + st.dx
    st.z = st.z + st.dz
    local result = Vector3.new(center.X + st.x * spacing, center.Y, center.Z + st.z * spacing)
    st.stepped = st.stepped + 1
    if st.stepped >= st.segLen then
        st.stepped = 0
        st.dx, st.dz = -st.dz, st.dx
        st.turns = st.turns + 1
        if st.turns % 2 == 0 then
            st.segLen = st.segLen + 1
        end
    end
    return result
end
local function ResetSpiralCursor()
    Place.SpiralCursor = 0
    Place.SpiralCenter = nil
    Place.Spiral = {x = 0, z = 0, dx = 1, dz = 0, segLen = 1, stepped = 0, turns = 0}
    Place.SpiralFailMemo = {}
end
local function GetSpotForTowerSpiral(model)
    if not Place.Spiral then ResetSpiralCursor() end
    local towersFolder = GetTowersFolder()
    local hip = 0
    local legY = 2
    local humanoid = model:FindFirstChildOfClass("Humanoid")
    if humanoid then hip = humanoid.HipHeight end
    local hrp = model.PrimaryPart or model:FindFirstChild("HumanoidRootPart")
    if hrp then legY = hrp.Size.Y / 2 end
    local rot = (Options.PlaceRotation and Options.PlaceRotation.Value) or 0
    local spacing = 1.5
    for _ = 1, 40 do
        local candidate = SpiralNext(spacing)
        if not candidate then return nil end
        local key = string.format("%.1f_%.1f", candidate.X, candidate.Z)
        local memo = Place.SpiralFailMemo[key]
        local blocked = memo and (tick() - memo) <= 30
        if not blocked then
            local parts = GetTowerAreaParts()
            local part = parts and parts[1]
            if not part then return nil end
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Include
            params.FilterDescendantsInstances = {part}
            local origin = Vector3.new(candidate.X, part.Position.Y + 60, candidate.Z)
            local result = workspace:Raycast(origin, Vector3.new(0, -200, 0), params)
            if result then
                local blockedByTower = false
                if towersFolder then
                    for _, tower in ipairs(towersFolder:GetChildren()) do
                        local pp = tower.PrimaryPart or tower:FindFirstChild("HumanoidRootPart")
                        if pp then
                            local dx = pp.Position.X - candidate.X
                            local dz = pp.Position.Z - candidate.Z
                            if (dx * dx + dz * dz) < 9 then
                                blockedByTower = true
                                break
                            end
                        end
                    end
                end
                if not blockedByTower then
                    local y = result.Position.Y + hip + legY
                    local cf = CFrame.new(candidate.X, y, candidate.Z) * CFrame.Angles(0, math.rad(rot), 0)
                    return cf
                else
                    Place.SpiralFailMemo[key] = tick()
                end
            else
                Place.SpiralFailMemo[key] = tick()
            end
        end
    end
    return nil
end
local function GetSlotByTowerName()
    local data = GetPlayerDataRaw()
    local map = {}
    if not data or type(data.Towers) ~= "table" then return map end
    for _, v in pairs(data.Towers) do
        if type(v) == "table" and type(v.Name) == "string" and type(v.Equipped) == "number" then
            map[v.Name] = v.Equipped
        end
    end
    return map
end
local function GetLoadoutSlotName(slot)
    local map = GetSlotByTowerName()
    for name, s in pairs(map) do
        if s == slot then return name end
    end
    return nil
end
local function GetSlotDisplayNames()
    local map = GetSlotByTowerName()
    local slots = {}
    for name, slot in pairs(map) do
        table.insert(slots, { Slot = slot, Name = name })
    end
    table.sort(slots, function(a, b) return a.Slot < b.Slot end)
    local names = {}
    for _, entry in ipairs(slots) do
        table.insert(names, "Slot " .. entry.Slot .. " (" .. entry.Name .. ")")
    end
    return names
end
local function SlotDisplayToNumber(display)
    local n = display and display:match("^Slot (%d+)")
    return n and tonumber(n) or nil
end
local function GetSlotOrder(slot)
    local opt = Options["PlaceOrder" .. slot]
    return (opt and tonumber(opt.Value)) or slot
end
local function GetSlotPlaceWave(slot)
    local opt = Options["PlaceWave" .. slot]
    return (opt and tonumber(opt.Value)) or 0
end
local function GetSlotPlaceLimit(slot)
    local opt = Options["PlaceLimit" .. slot]
    return (opt and tonumber(opt.Value)) or 0
end
local function GetSlotUpgradeLimit(slot)
    local opt = Options["UpgradeLimit" .. slot]
    return (opt and tonumber(opt.Value)) or 0
end
local function GetCurrentMapName()
    local mapRoot = workspace:FindFirstChild("Map")
    local folder = mapRoot and mapRoot:FindFirstChildOfClass("Folder")
    return folder and folder.Name or nil
end
local function PosText(mapName)
    if not mapName or not Place.SlotPositions[mapName] then return "No positions set" end
    local lines = {}
    for slot, cfs in pairs(Place.SlotPositions[mapName]) do
        local unitName = GetLoadoutSlotName(slot)
        table.insert(lines, "Slot " .. slot .. (unitName and (" (" .. unitName .. ")") or "") .. ": " .. #cfs .. " pos")
    end
    if #lines == 0 then return "No positions set" end
    table.sort(lines)
    return table.concat(lines, "\n")
end
local function UpdatePosLabels()
    local mapName = GetCurrentMapName()
    if Place.PosLabelRef then
        pcall(function()
            Place.PosLabelRef:SetText(PosText(mapName))
        end)
    end
end
local function HandleSlotPos(act, slot)
    local mapName = GetCurrentMapName()
    if not mapName then
        return
    end
    if act == "reset" then
        if slot then
            if Place.SlotPositions[mapName] then Place.SlotPositions[mapName][slot] = nil end
            notyuri("ResetPos slot=" .. slot .. " map=" .. mapName)
        else
            Place.SlotPositions[mapName] = nil
            notyuri("ResetPos all map=" .. mapName)
        end
        SavePositions()
        UpdatePosLabels()
        return
    end
    local char = Plr.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then
        Library:Notify("Character not found", 3)
        return
    end
    local cf = CFrame.new(hrp.Position)
    if not Place.SlotPositions[mapName] then Place.SlotPositions[mapName] = {} end
    if act == "set" then
        if not Place.SlotPositions[mapName][slot] then Place.SlotPositions[mapName][slot] = {} end
        table.insert(Place.SlotPositions[mapName][slot], cf)
        local count = #Place.SlotPositions[mapName][slot]
        notyuri("SetPos slot=" .. slot .. " count=" .. count .. " map=" .. mapName)
    elseif act == "massset" then
        for i = 1, 6 do
            if not Place.SlotPositions[mapName][i] then Place.SlotPositions[mapName][i] = {} end
            table.insert(Place.SlotPositions[mapName][i], cf)
        end
        notyuri("MassSetPos map=" .. mapName)
    end
    SavePositions()
    UpdatePosLabels()
end
local function SetPos(slot) HandleSlotPos("set", slot) end
local function MassSetPos() HandleSlotPos("massset") end
local function ResetPos(slot) HandleSlotPos("reset", slot) end
local function GetSelectedTowerNames()
    local names = {}
    local slotByName = GetSlotByTowerName()
    for name in pairs(slotByName) do
        table.insert(names, name)
    end
    return names
end
local function GetSelectedTowerSlots()
    local names = GetSelectedTowerNames()
    local slotByName = GetSlotByTowerName()
    local list = {}
    for _, name in ipairs(names) do
        table.insert(list, {name = name, slot = slotByName[name]})
    end
    table.sort(list, function(a, b)
        local sa = a.slot and GetSlotOrder(a.slot) or 99
        local sb = b.slot and GetSlotOrder(b.slot) or 99
        if sa ~= sb then return sa < sb end
        return a.name < b.name
    end)
    return list
end
local function TryPlaceTower(name, slot)
    local model = GetTowerModel(name)
    if not model then return false, nil end
    local price = GetTowerPrice(name)
    if price and GetCash() < price then return false, nil end
    local pause = Place.PauseUntil[name] or 0
    if tick() < pause then return false, nil end
    if slot then
        local placeWave = GetSlotPlaceWave(slot)
        if placeWave > 0 and GetWave() < placeWave then return false, nil end
        local slotLimit = GetSlotPlaceLimit(slot)
        if slotLimit > 0 and CountOwnedByName(name) >= slotLimit then return false, nil end
    end
    local maxCount = GetPlacementMax(name)
    if maxCount and CountOwnedByName(name) >= maxCount then return false, nil end
    local id, entryData = GetTowerEntryForName(name, slot)
    if id == nil then return false, nil end
    local mapName = GetCurrentMapName()
    local savedList = slot and mapName and Place.SlotPositions[mapName] and Place.SlotPositions[mapName][slot]
    local cf, posKey, fromSaved
    if savedList and #savedList > 0 then
        cf = savedList[math.random(1, #savedList)]
        fromSaved = true
    else
        cf, posKey = GetSpotForTower(model)
        if not cf then
            cf = GetSpotForTowerSpiral(model)
        end
    end
    if not cf then return false, nil end
    local ghost = PCubeAcq()
    ghost.CFrame = cf
    local mods = (entryData and type(entryData.Modifiers) == "table" and entryData.Modifiers) or {}
    local result = Invoke(Remotes.SpawnTower, name, cf, false, id, mods)
    if typeof(result) == "Instance" then
        ghost.Color = Color3.fromRGB(80, 255, 120)
        Place.TypeFails[name] = 0
        AnchorTowerHRP(result)
        PCubeRelease(ghost)
        return true, result
    end
    ghost.Color = Color3.fromRGB(255, 80, 80)
    PCubeRelease(ghost)
    if posKey and not fromSaved then
        Place.FailPos[posKey] = tick() + 30
    end
    Place.TypeFails[name] = (Place.TypeFails[name] or 0) + 1
    if Place.TypeFails[name] >= 3 then
        Place.PauseUntil[name] = tick() + 10
        Place.TypeFails[name] = 0
        notyuri("3 rejects for", name, "- pausing 10s")
    end
    return false, nil
end
local function TryUpgradeOnce(tower)
    local reserve = (Options.UpgradeReserve and Options.UpgradeReserve.Value) or 0
    local nextUp = GetNextUpgrade(tower.Name, GetTowerLevel(tower) or 0)
    if not (nextUp and nextUp.Price and (GetCash() - reserve) >= nextUp.Price) then
        return false
    end
    local result = Invoke(Remotes.UpgradeTower, tower, GetTowerID(tower))
    if typeof(result) == "Instance" then
        AnchorTowerHRP(result)
        task.wait()
        FireBindable(Remotes.toggleClient, result)
        return true, result
    end
    return false, nil
end
local function Func_AutoPlace()
    while Toggles.AutoPlace.Value do
        local ok, err = pcall(function()
            if not (Remotes.SpawnTower and IsMatchActive()) then return end
            if GetPlacedCount() >= GetTowerLimit() then return end
            for _, entry in ipairs(GetSelectedTowerSlots()) do
                if not (Toggles.AutoPlace.Value and GetPlacedCount() < GetTowerLimit()) then return end
                local placed, tower = TryPlaceTower(entry.name, entry.slot)
                if placed then
                    notyuri("Placed", entry.name, "slot", tostring(entry.slot))
                    if Toggles.PlaceAndUpgrade and Toggles.PlaceAndUpgrade.Value and tower then
                        local upgLimit = entry.slot and GetSlotUpgradeLimit(entry.slot) or 0
                        for _ = 1, 20 do
                            if not Toggles.PlaceAndUpgrade.Value then break end
                            if upgLimit > 0 and (GetTowerLevel(tower) or 0) >= upgLimit then break end
                            local upgraded, newTower = TryUpgradeOnce(tower)
                            if not upgraded then break end
                            tower = newTower or tower
                            task.wait()
                        end
                    end
                end
                task.wait()
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
end
local function GetUpgradableTowers()
    local slotByName = GetSlotByTowerName()
    local result = {}
    for _, tower in ipairs(GetOwnedTowers()) do
        local slot = slotByName[tower.Name]
        local upgLimit = slot and GetSlotUpgradeLimit(slot) or 0
        local level = GetTowerLevel(tower) or 0
        if upgLimit <= 0 or level < upgLimit then
            local nextUp = GetNextUpgrade(tower.Name, level)
            if nextUp and nextUp.Price then
                table.insert(result, {
                    model = tower,
                    slot = slot,
                    level = level,
                    towerName = tower.Name,
                    price = nextUp.Price,
                })
            end
        end
    end
    return result
end
local function UpgradeCand(units)
    local method = Options.UpgradeMethod and Options.UpgradeMethod.Value or "Lowest Level (Spread Upgrade)"
    if #units == 0 then return nil end
    if method == "Randomize" then
        return units[math.random(1, #units)]
    elseif method == "Hotbar left to right (until Max)" or method == "Customize upgrade order (Set below)" then
        table.sort(units, function(a, b)
            local sa = a.slot and GetSlotOrder(a.slot) or 99
            local sb = b.slot and GetSlotOrder(b.slot) or 99
            if sa ~= sb then return sa < sb end
            return a.level < b.level
        end)
        return units[1]
    end
    table.sort(units, function(a, b) return a.level < b.level end)
    return units[1]
end
local function Func_AutoUpgrade()
    while Toggles.AutoUpgrade.Value do
        local ok, err = pcall(function()
            if not (Remotes.UpgradeTower and IsMatchActive()) then return end
            local reserve = (Options.UpgradeReserve and Options.UpgradeReserve.Value) or 0
            local units = GetUpgradableTowers()
            local target = UpgradeCand(units)
            if not target then return end
            if (GetCash() - reserve) < target.price then return end
            local tower = target.model
            local result = Invoke(Remotes.UpgradeTower, tower, GetTowerID(tower))
            if typeof(result) == "Instance" then
                task.wait()
                FireBindable(Remotes.toggleClient, result)
                notyuri("Upgraded", target.towerName, "slot", tostring(target.slot))
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
end
local function Func_AutoAbility()
    while Toggles.AutoAbility.Value do
        if Remotes.ActivateAbility and IsMatchActive() then
            for _, tower in ipairs(GetOwnedTowers()) do
                if Toggles.AutoAbility.Value then
                    local config = tower:FindFirstChild("Config")
                    local ability = config and config:FindFirstChild("Ability")
                    if ability and ability.Value ~= "" then
                        local last = Memo.AbilityAt[tower] or 0
                        if tick() - last > 3 then
                            local r1 = Invoke(Remotes.GetAbilityCooldown, tower)
                            if r1 == nil or r1 == true then
                                Fire(Remotes.ActivateAbility, tower)
                                Memo.AbilityAt[tower] = tick()
                            end
                        end
                    end
                end
            end
        end
        task.wait(1)
    end
end
local function IsModifierVotingVisible()
    local gui = Plr:FindFirstChild("PlayerGui")
    local gameGui = gui and gui:FindFirstChild("GameGui")
    local voting = gameGui and gameGui:FindFirstChild("Voting")
    local modifier = voting and voting:FindFirstChild("ModifierVoting")
    return modifier ~= nil and modifier.Visible == true
end
local function OnSkipVoteEvent(p1, p2)
    if not (Toggles.AutoSkip and Toggles.AutoSkip.Value) then return end
    if not p1 or p2 then return end
    if IsModifierVotingVisible() then return end
    if not Remotes.VoteSkip then return end
    Invoke(Remotes.VoteSkip)
    notyuri("vote fired")
end
local function ApplyGameSpeed()
    if not Remotes.ChangeSpeed then return false end
    local n = tonumber(Options.SpeedTarget and Options.SpeedTarget.Value) or 2
    local info = GetInfo()
    local cur = info and info:FindFirstChild("SpeedGame")
    if cur and cur.Value >= n then return true end
    local ok = Invoke(Remotes.ChangeSpeed, n)
    return ok == true
end
local function Func_AutoSpeed()
    while Toggles.AutoSpeed.Value do
        local ok, err = pcall(ApplyGameSpeed)
        if not ok then
            notyuri("AutoSpeed error:", tostring(err))
        end
        task.wait(2)
    end
end
local function Func_AutoVoteMap()
    while Toggles.AutoVoteMap.Value do
        local ok, err = pcall(function()
            local info = GetInfo()
            if not info then return end
            local voting = info:FindFirstChild("Voting")
            local votingOpen = voting and voting.Value == true
            if votingOpen and Remotes.VoteForMap and Options.MapVote and Options.MapVote.Value ~= "" then
                Fire(Remotes.VoteForMap, Options.MapVote.Value)
            end
        end)
        if not ok then
            notyuri("AutoVoteMap error:", tostring(err))
        end
        task.wait(0.5)
    end
end
local function Func_AutoVoteDifficulty()
    while Toggles.AutoVoteDifficulty.Value do
        local ok, err = pcall(function()
            local info = GetInfo()
            if not info then return end
            local voting = info:FindFirstChild("ComplicationVoting")
            local votingOpen = voting and voting.Value == true
            if votingOpen and Remotes.VoteForComplication and Options.DifficultyVote and Options.DifficultyVote.Value ~= "" then
                Fire(Remotes.VoteForComplication, Options.DifficultyVote.Value)
            end
        end)
        if not ok then
            notyuri("AutoVoteDifficulty error:", tostring(err))
        end
        task.wait(0.5)
    end
end
local function Func_AutoVoteMutator()
    while Toggles.AutoVoteMutator.Value do
        local ok, err = pcall(function()
            local gui = Plr:FindFirstChild("PlayerGui")
            local voting = gui and GetObject(gui, "SlopMutatorGui.MutatorVoting")
            if voting and voting.Visible and Remotes.SlopMutator then
                local available = {}
                for _, card in ipairs(voting:GetChildren()) do
                    if card:IsA("GuiButton") then
                        available[card.Name] = true
                    end
                end
                local tiers = {}
                for i = 1, 3 do
                    local getter = MutatorPriorityGetters[i]
                    tiers[i] = getter and getter() or {}
                end
                local wanted = nil
                for _, tier in ipairs(tiers) do
                    for _, id in ipairs(MutatorState.Ids) do
                        if tier[id] and available[id] then
                            wanted = id
                            break
                        end
                    end
                    if wanted then break end
                end
                if not wanted and available["None"] then
                    wanted = "None"
                end
                if wanted then
                    Fire(Remotes.SlopMutator, "Vote", wanted)
                end
            end
        end)
        if not ok then
            notyuri("AutoVoteMutator error:", tostring(err))
        end
        task.wait(0.5)
    end
end
local function Func_AutoReplay()
    while Toggles.AutoReplay.Value do
        local gui = Plr:FindFirstChild("PlayerGui")
        local endScreen = gui and GetObject(gui, "GameGui.EndScreen")
        if endScreen and endScreen.Visible and Remotes.EndDecision then
            Fire(Remotes.EndDecision, true)
            notyuri("replay vote sent")
        end
        task.wait(.5)
    end
end
local function Func_AutoNewMap()
    while Toggles.AutoNewMap.Value do
        local gui = Plr:FindFirstChild("PlayerGui")
        local endScreen = gui and GetObject(gui, "GameGui.EndScreen")
        if endScreen and endScreen.Visible and Remotes.EndDecision then
            Fire(Remotes.EndDecision, "new")
            notyuri("new map vote sent")
        end
        task.wait(.5)
    end
end
local function PickElevator()
    local folder = workspace:FindFirstChild("Elevators")
    if not folder then return nil end
    for _, elev in ipairs(folder:GetChildren()) do
        local players = elev:GetAttribute("Players")
        local raid = elev:GetAttribute("IsRaid")
        if players == 0 and raid == nil then
            return elev
        end
    end
    return nil
end
local function Func_AutoJoin()
    while Toggles.AutoJoin.Value do
        local folder = workspace:FindFirstChild("Elevators")
        if folder then
            local elev = PickElevator()
            if elev then
                TPTo(elev)
                local name = elev.Name
                if Remotes.EnterElevator then
                    Fire(Remotes.EnterElevator, name)
                end
                if Remotes.StartElevator then
                    Fire(Remotes.StartElevator, name)
                end
            end
        end
        task.wait(1)
    end
end
local function Func_AutoSummon()
    while Toggles.AutoSummon.Value do
        local remote = nil
        if (Options.SummonType and Options.SummonType.Value) == "Premium" then
            remote = Remotes.SummonPremium
        else
            remote = Remotes.SummonMain
        end
        if remote then
            local amt = tonumber(Options.SummonAmount and Options.SummonAmount.Value) or 1
            local result = Invoke(remote, amt)
            if result then
                Memo.SummonFails = 0
            else
                Memo.SummonFails = Memo.SummonFails + 1
                if Memo.SummonFails % 10 == 0 then
                end
            end
        end
        task.wait(.2)
    end
end
local function Func_AutoClaimGifts()
    while Toggles.AutoClaimGifts.Value do
        if Remotes.GiftGetData and Remotes.ClaimGift then
            local base = Invoke(Remotes.GiftGetData)
            if type(base) == "number" then
                local folder = RS:FindFirstChild("GiftFolder")
                local shared = folder and GetSafeModule(folder, "SharedGiftData")
                if type(shared) == "table" then
                    local claimedFolder = Plr:FindFirstChild("ClaimedGifts")
                    for _, v in pairs(shared) do
                        if type(v) == "table" and v.GiftNumber ~= nil and v.Time ~= nil then
                            local already = claimedFolder and claimedFolder:FindFirstChild(tostring(v.GiftNumber))
                            if not already then
                                if (v.Time - base) <= 0 then
                                    local ok = Invoke(Remotes.ClaimGift, v.GiftNumber)
                                    if ok == true then
                                        notyuri("claimed gift", tostring(v.GiftNumber))
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        task.wait(60)
    end
end
local function PushQuestClaims(payload)
    if type(payload) ~= "table" then return end
    if not (Toggles.AutoClaimQuests and Toggles.AutoClaimQuests.Value) then return end
    if not Remotes.CollectQuest then return end
    for cat, quests in pairs(payload) do
        if type(quests) == "table" then
            for _, q in pairs(quests) do
                if type(q) == "table" and q.Id ~= nil and q.State == "Completed" and not q.RewardClaimed then
                    Fire(Remotes.CollectQuest, q.Id, cat)
                    notyuri("claimed", tostring(q.Id), cat)
                end
            end
        end
    end
end
local function Func_AutoClaimQuests()
    while Toggles.AutoClaimQuests.Value do
        if Remotes.CheckAndChoose then
            Fire(Remotes.CheckAndChoose, "Daily")
            Fire(Remotes.CheckAndChoose, "Weekly")
        end
        task.wait(60)
    end
end
local GetSelectedCrates
local function Func_AutoOpenBoxes()
    while Toggles.AutoOpenBoxes.Value do
        local cratesToOpen = GetSelectedCrates and GetSelectedCrates() or {}
        local amountStr = Options.OpenAmount and Options.OpenAmount.Value or "1"
        local amountCap = tonumber(amountStr) or 1
        if next(cratesToOpen) then
            local data = GetPlayerDataRaw()
            if type(data) == "table" and type(data.Items) == "table" then
                for crateName in pairs(cratesToOpen) do
                    if crateName and type(data.Items[crateName]) == "table" then
                        local owned = data.Items[crateName].Stacks or 0
                        local toOpen = math.min(owned, amountCap)
                        if toOpen > 0 then
                            local openRemote = RS:FindFirstChild("Remotes")
                            openRemote = openRemote and openRemote:FindFirstChild("Inventory")
                            openRemote = openRemote and openRemote:FindFirstChild("OpenCrate")
                            if openRemote and openRemote:IsA("RemoteFunction") then
                                local result = SafeInvoke(openRemote, 8, crateName, toOpen)
                                if type(result) == "table" then
                                    notyuri("opened", toOpen, "x", tostring(crateName))
                                end
                            end
                        end
                    end
                end
            end
        end
        task.wait()
    end
end
local function PopulateRemotes()
    local functionsFolder = RS:FindFirstChild("Functions")
    if functionsFolder then
        for _, name in ipairs(SlopFuncs) do
            local remote = GetSafeRemote(functionsFolder, name)
            if remote then Remotes[name] = remote end
        end
    end
    local eventsFolder = RS:FindFirstChild("Events")
    if eventsFolder then
        for _, name in ipairs(SlopEvents) do
            local remote = GetSafeRemote(eventsFolder, name)
            if remote then Remotes[name] = remote end
        end
        for _, name in ipairs(LobbyEvents) do
            local remote = GetSafeRemote(eventsFolder, name)
            if remote then Remotes[name] = remote end
        end
        local toggleClient = eventsFolder:FindFirstChild("toggleClient")
        if toggleClient and toggleClient:IsA("BindableEvent") then
            Remotes.toggleClient = toggleClient
        end
    end
    local giftFolder = RS:FindFirstChild("GiftFolder")
    if giftFolder then
        local getData = GetSafeRemote(giftFolder, "GetData")
        if getData then Remotes.GiftGetData = getData end
        local claimGift = GetSafeRemote(giftFolder, "ClaimGift")
        if claimGift then Remotes.ClaimGift = claimGift end
    end
    local network = RS:FindFirstChild("Network")
    local remoteEvents = network and network:FindFirstChild("RemoteEvents")
    if remoteEvents then
        for _, name in ipairs({"SendQuestData", "CollectQuest", "CheckAndChoose"}) do
            local remote = GetSafeRemote(remoteEvents, name)
            if remote then Remotes[name] = remote end
        end
    end
    local remotesFolder = RS:FindFirstChild("Remotes")
    local summon = remotesFolder and remotesFolder:FindFirstChild("Summon")
    if summon then
        local main = GetSafeRemote(summon, "Summon")
        if main then Remotes.SummonMain = main end
        local premium = GetSafeRemote(summon, "SummonPremium")
        if premium then Remotes.SummonPremium = premium end
    end
end
PopulateRemotes()
local function SendWebhook(title, description)
    if not request then return end
    local img = yuri[math.random(1, #yuri)]
    pcall(function()
        request({
            Url = Options.WebhookURL.Value,
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = HttpService:JSONEncode({
                username = "Yuri",
                avatar_url = img,
                embeds = {
                    {
                        title = title,
                        description = description,
                        color = 0xFFB6C1,
                        thumbnail = { url = img },
                    },
                },
            }),
        })
    end)
end
local AbbrevSuffixes = { "k", "M", "B", "T", "Qd", "Qt", "Sx", "Sp", "Oc", "No", "Dc", "UDc", "DDc" }
local AbbrevMultiplier = {}
for i, suf in ipairs(AbbrevSuffixes) do
    AbbrevMultiplier[suf] = 1000 ^ i
end
local function ParseAbbreviatedNumber(text)
    if not text then return nil end
    local stripped = text:gsub("^x", "")
    local numPart, suffix = stripped:match("^(%d+%.?%d*)(%a*)$")
    if not numPart then return nil end
    local base = tonumber(numPart)
    if not base then return nil end
    if suffix == "" then return base end
    local mult = AbbrevMultiplier[suffix]
    if not mult then return nil end
    return base * mult
end
local function GetMatchEndStats()
    local gui = Plr:FindFirstChild("PlayerGui")
    local statsFolder = gui and GetObject(gui, "GameGui.EndScreen.Stats")
    if not statsFolder then return {} end
    local results = {}
    for _, child in ipairs(statsFolder:GetChildren()) do
        local total = child:FindFirstChild("Total")
        if total and total:IsA("TextLabel") and (child.Visible ~= false) then
            local value = ParseAbbreviatedNumber(total.Text)
            if value then
                table.insert(results, { Name = child.Name, Value = value })
            end
        end
    end
    return results
end
local function GetMatchEndStatsSettled(timeout)
    task.wait(0.5)
    local start = tick()
    local last = GetMatchEndStats()
    while tick() - start < (timeout or 2) do
        task.wait()
        local current = GetMatchEndStats()
        local changed = #current ~= #last
        if not changed then
            for i, stat in ipairs(current) do
                if not last[i] or last[i].Name ~= stat.Name or last[i].Value ~= stat.Value then
                    changed = true
                    break
                end
            end
        end
        last = current
        if not changed then return current end
    end
    return last
end
local function SendMatchEndWebhook(outcome)
    local info = GetInfo()
    local minsObj = info and info:FindFirstChild("Min")
    local secsObj = info and info:FindFirstChild("Sec")
    local mins = minsObj and minsObj.Value or 0
    local secs = secsObj and secsObj.Value or 0
    local stats = GetMatchEndStatsSettled(2)
    local lines = {}
    for _, stat in ipairs(stats) do
        table.insert(lines, string.format("+%d %s", math.round(stat.Value), stat.Name))
    end
    local rewards = table.concat(lines, "\n")
    local desc = string.format(
        "**%s - %s**\n- Time: %d:%02d\n- Player: ||%s||\n- Rewards:\n%s",
        "Match Finished", outcome, mins, secs, Plr.Name, rewards
    )
    SendWebhook("Match Finished", desc)
    notyuri("Match finished notification sent:", outcome)
end
do
    local info = GetInfo()
    if info then
        local message = info:WaitForChild("Message", 5)
        if message then
            SafeConnect("MatchEndWebhook", function() return message.Changed end, function(msg)
                if not (Toggles.WHMatchEnd and Toggles.WHMatchEnd.Value) then return end
                if msg ~= "Victory" and msg ~= "Defeat" then return end
                SendMatchEndWebhook(msg)
            end)
        end
    end
    local eventsFolder = RS:FindFirstChild("Events")
    local skipButton = eventsFolder and eventsFolder:FindFirstChild("SkipButton")
    if skipButton and skipButton:IsA("RemoteEvent") then
        SafeConnect("SkipButton", function() return skipButton.OnClientEvent end, OnSkipVoteEvent)
    end
    if eventsFolder then
        local entered = eventsFolder:FindFirstChild("ElevatorEntered")
        if entered and entered:IsA("RemoteEvent") then
            SafeConnect("ElevatorEntered", function() return entered.OnClientEvent end, function(name)
                if type(name) == "string" then
                    ElevState.Current = name
                    ElevState.Teleported = false
                    ElevState.Started = tick()
                    notyuri("entered", name)
                end
            end)
        end
        local left = eventsFolder:FindFirstChild("ElevatorLeft")
        if left and left:IsA("RemoteEvent") then
            SafeConnect("ElevatorLeft", function() return left.OnClientEvent end, function()
                ElevState.Current = nil
                notyuri("left")
            end)
        end
        local teleported = eventsFolder:FindFirstChild("OnTeleported")
        if teleported and teleported:IsA("RemoteEvent") then
            SafeConnect("OnTeleported", function() return teleported.OnClientEvent end, function()
                ElevState.Teleported = true
                ElevState.Current = nil
                notyuri("teleporting to game place")
            end)
        end
    end
    local network = RS:FindFirstChild("Network")
    local remoteEvents = network and network:FindFirstChild("RemoteEvents")
    local sendQuest = remoteEvents and remoteEvents:FindFirstChild("SendQuestData")
    if sendQuest and sendQuest:IsA("RemoteEvent") then
        SafeConnect("SendQuestData", function() return sendQuest.OnClientEvent end, function(payload)
            LobbyQuest.Cache = payload
            PushQuestClaims(payload)
        end)
    end
    local events = RS:FindFirstChild("Events")
    local antiMacro = events and events:FindFirstChild("AntiMacro")
    if antiMacro then
        local checkEvent = antiMacro:FindFirstChild("Check")
        local respondRemote = antiMacro:FindFirstChild("Respond")
        if checkEvent and checkEvent:IsA("RemoteEvent") and respondRemote and respondRemote:IsA("RemoteEvent") then
            SafeConnect("AntiMacro", function() return checkEvent.OnClientEvent end, function(id)
                respondRemote:FireServer(id)
            end)
        end
    end
end
local Window = Library:CreateWindow({
        Title = "Yuri",
        Center = true,
        AutoShow = true,
        Resizable = true,
        ShowCustomCursor = false,
        UnlockMouseWhileOpen = false,
        NotifySide = "Left",
        TabPadding = 8,
        MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
        Main = Window:AddTab("Main"),
    Player = Window:AddTab("Player"),
    AutoPlay = Window:AddTab("Auto Play"),
    Webhook = Window:AddTab("Webhook"),
    Config = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Game"),
        T2 = TB.Main.Left.Autofarm:AddTab("Macro"),
        T3 = TB.Main.Left.Autofarm:AddTab("Lobby"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
        T2 = TB.Main.Right.Autofarm:AddTab("LobbyConfig"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
    Webhook = {
        Left = {
            Webhook = Tabs.Webhook:AddLeftGroupbox("Webhook"),
        },
    },
}
GB.Webhook.Left.Webhook:AddInput("WebhookURL", {
    Text = "Webhook URL",
    Default = "",
})
GB.Webhook.Left.Webhook:AddToggle("WHMatchEnd", {
    Text = "Match Finished",
    Default = false,
})
if not Support.Webhook then
    GB.Webhook.Left.Webhook:AddLabel("<font color='#FFA500'>Executor does not support HTTP requests.</font>", true)
end
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
local TPW_T, TPW_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1})
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
local FPS_T, FPS_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused"})
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function() Serverhop() end })
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Players.LocalPlayer) end })
GB.Player.Left.Server:AddToggle("AutoServerhop", { Text = "Auto Serverhop" })
GB.Player.Left.Server:AddSlider("AutoHopMins", { Text = "Minutes", Default = 30, Min = 0, Max = 300, Compact = true, Rounding = 0 })
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
local function GetCrates()
    local crateNames = {}
    local modules = RS:FindFirstChild("Modules")
    if modules then
        local cfg = GetSafeModule(modules, "MainConfig")
        if cfg and type(cfg.Crates) == "table" then
            for crateName, data in pairs(cfg.Crates) do
                if type(crateName) == "string" then
                    table.insert(crateNames, crateName)
                end
            end
        end
        if cfg and type(cfg.Chest) == "table" then
            for chestName, data in pairs(cfg.Chest) do
                if type(chestName) == "string" then
                    table.insert(crateNames, chestName)
                end
            end
        end
    end
    table.sort(crateNames)
    return #crateNames > 0 and crateNames or { "Loading..." }
end
local APLeft = Tabs.AutoPlay:AddLeftGroupbox("Auto Play")
APLeft:AddToggle("AutoPlace", { Text = "Auto Place" })
APLeft:AddToggle("AutoUpgrade", { Text = "Auto Upgrade" })
APLeft:AddDropdown("UpgradeMethod", {
    Text = "Upgrade Method",
    Values = {
        "Lowest Level (Spread Upgrade)",
        "Hotbar left to right (until Max)",
        "Randomize",
        "Customize upgrade order (Set below)",
    },
    Default = "Lowest Level (Spread Upgrade)",
})
APLeft:AddToggle("PlaceAndUpgrade", { Text = "Place and Upgrade" })
APLeft:AddDivider()
local APRight = Tabs.AutoPlay:AddRightGroupbox("Limits")
APRight:AddLabel("Place Order per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceOrder" .. i, {
        Text = "Slot " .. i,
        Default = i,
        Min = 1,
        Max = 6,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Place Wave per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceWave" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 50,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Place Limit per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceLimit" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 10,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Upgrade Limit per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("UpgradeLimit" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 30,
        Rounding = 0,
        Compact = true,
    })
end
Place.PosLabelRef = APLeft:AddLabel("No positions set", true)
APLeft:AddDropdown("SetSlotSelect", {
    Text = "Set Slot Position",
    Values = GetSlotDisplayNames(),
    Default = GetSlotDisplayNames()[1] or "",
})
APLeft:AddButton({
    Text = "Set Slot Position",
    Func = function()
        local val = Options.SetSlotSelect and Options.SetSlotSelect.Value or ""
        local slot = SlotDisplayToNumber(val)
        if slot then
            SetPos(slot)
        else
            Library:Notify("Select a slot first", 3)
        end
    end,
})
APLeft:AddButton({ Text = "Save Position for All Slots", Func = function() MassSetPos() end })
APLeft:AddDivider()
APLeft:AddDropdown("ResetSlotSelect", {
    Text = "Reset Slot Position",
    Values = (function() local v = GetSlotDisplayNames() table.insert(v, "All Slots") return v end)(),
    Default = "All Slots",
})
APLeft:AddButton({
    Text = "Reset Position",
    Func = function()
        local val = Options.ResetSlotSelect and Options.ResetSlotSelect.Value or "All Slots"
        if val == "All Slots" then
            ResetPos(nil)
        else
            ResetPos(SlotDisplayToNumber(val))
        end
    end,
})
UpdatePosLabels()
TB_Tabs.Autofarm.T1:AddToggle("AutoAbility", { Text = "Auto Tower Ability", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoSkip", { Text = "Auto Skip", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoSpeed", { Text = "Auto Game Speed", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoReplay", { Text = "Auto Replay", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoNewMap", { Text = "Auto New Map", Default = false })
TB_Tabs.Autofarm2.T1:AddDropdown("SpeedTarget", { Text = "Speed Target", Values = { "1", "2", "3", "4", "5" }, Default = "2" })
local MapVoteExcludedKeys = { Quests = true, Rewards = true, Drops = true }
local function GetMapVoteValues()
    local values = {}
    local modules = RS:FindFirstChild("Modules")
    local modesConfig = modules and GetSafeModule(modules, "ModesConfig")
    if type(modesConfig) == "table" then
        for name in pairs(modesConfig) do
            if not MapVoteExcludedKeys[name] then
                table.insert(values, name)
            end
        end
    end
    return values
end
TB_Tabs.Autofarm2.T1:AddDropdown("MapVote", {
    Text = "Map Vote",
    Values = GetMapVoteValues(),
    Searchable = true,
    Default = "",
})
TB_Tabs.Autofarm.T1:AddToggle("AutoVoteMap", { Text = "Auto Vote Map", Default = false })
TB_Tabs.Autofarm2.T1:AddDropdown("DifficultyVote", {
    Text = "Difficulty Vote",
    Values = { "Normal", "Hard", "Nightmare" },
    Default = "",
})
TB_Tabs.Autofarm.T1:AddToggle("AutoVoteDifficulty", { Text = "Auto Vote Difficulty", Default = false })
for i = 1, 3 do
    MutatorPriorityGetters[i] = AddMultiDropdown(TB_Tabs.Autofarm2.T1, "MutatorPriority" .. i, {
        Text = "Mutator Priority " .. i,
        Values = MutatorState.Ids,
        Default = {},
    })
end
TB_Tabs.Autofarm.T1:AddToggle("AutoVoteMutator", { Text = "Auto Vote Mutator", Default = false })
TB_Tabs.Autofarm.T2:AddDropdown("MacroSelected", {
    Text = "Select File",
    Values = ListMacros(),
    Default = ListMacros()[1] or "",
})
TB_Tabs.Autofarm.T2:AddInput("FileName", {
    Text = "File Name",
    Default = "",
    Placeholder = "yuriyuri",
})
TB_Tabs.Autofarm.T2:AddDropdown("ReplayMode", {
    Text = "Replay Mode",
    Values = {"Time", "Money"},
    Default = "Time",
})
TB_Tabs.Autofarm.T2:AddToggle("MacroRecord", {
    Text = "Record Macro",
    Default = false,
})
TB_Tabs.Autofarm.T2:AddToggle("LoadMacro", {
    Text = "Play Macro",
    Default = false,
})
MState.LabelRef = TB_Tabs.Autofarm.T2:AddLabel("Idle", true)
TB_Tabs.Autofarm.T3:AddToggle("AutoJoin", { Text = "Auto Join" })
TB_Tabs.Autofarm.T3:AddToggle("AutoSummon", { Text = "Auto Summon" })
TB_Tabs.Autofarm2.T2:AddDropdown("SummonType", { Text = "Summon Type", Values = {"Basic", "Premium"}, Default = "Basic" })
TB_Tabs.Autofarm2.T2:AddDropdown("SummonAmount", { Text = "Summon Amount", Values = {"1", "10", "50"}, Default = "1" })
TB_Tabs.Autofarm.T3:AddToggle("AutoOpenBoxes", { Text = "Auto Open Boxes" })
GetSelectedCrates = AddMultiDropdown(TB_Tabs.Autofarm2.T2, "SelectBoxes", {
    Text = "Select Boxes",
    Values = GetCrates(),
    Default = {},
})
TB_Tabs.Autofarm2.T2:AddDropdown("OpenAmount", {
    Text = "Open Amount",
    Values = { "1", "10", "25" },
    Default = "1",
})
LoadMDir()
LoadPositions()
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    TPW_S:SetVisible(TPW_T.Value)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Toggles.AutoServerhop:OnChanged(function(state)
    Thread("AutoServerhop", function()
        local lastHop = tick()
        while Toggles.AutoServerhop.Value do
            task.wait(5)
            if not Toggles.AutoServerhop.Value then break end
            if (tick() - lastHop) >= (Options.AutoHopMins.Value * 60) then
                Serverhop()
                break
            end
        end
    end, state)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then Hum.JumpPower = Options.JPValue.Value Hum.UseJumpPower = true end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if FPS_T.Value then
        setfpscap(FPS_S.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    FPS_S:SetVisible(FPS_T.Value)
    if not v and Support.FPS then
        setfpscap(2000)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local antiAFKConn = nil
local function RunAntiAFK()
    if antiAFKConn then antiAFKConn:Enable() return end
    local GC = getconnections or get_signal_cons
    if GC then
        local conns = GC(Players.LocalPlayer.Idled)
        local target = conns and conns[1]
        if target and target.Disable then
            target:Disable()
            antiAFKConn = target
            return
        end
        for _, c in pairs(conns or {}) do
            if c.Disable then
                c:Disable()
                antiAFKConn = c
                return
            elseif c.Disconnect then
                c:Disconnect()
                return
            end
        end
    end
    Players.LocalPlayer.Idled:Connect(function()
        VirtualUser:CaptureController()
        VirtualUser:ClickButton2(Vector2.new())
    end)
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then
        RunAntiAFK()
    elseif antiAFKConn and antiAFKConn.Enable then
        antiAFKConn:Enable()
    end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
task.spawn(function()
    while task.wait(1) do
        local gui = Plr:FindFirstChild("PlayerGui")
        local checkGui = gui and gui:FindFirstChild("AntiMacroCheck")
        local frame = checkGui and checkGui:FindFirstChild("Frame")
        local button = frame and frame:FindFirstChild("TextButton")
        if button then
            if gsc(button) then
                notyuri("clicked")
            end
            task.wait(1)
        end
    end
end)
Toggles.AutoPlace:OnChanged(function(state)
    Thread("AutoPlace", SafeLoop("AutoPlace", Func_AutoPlace), state)
end)
Toggles.AutoUpgrade:OnChanged(function(state)
    Thread("AutoUpgrade", SafeLoop("AutoUpgrade", Func_AutoUpgrade), state)
end)
Toggles.AutoAbility:OnChanged(function(state)
    Thread("AutoAbility", SafeLoop("AutoAbility", Func_AutoAbility), state)
end)
Toggles.AutoOpenBoxes:OnChanged(function(state)
    Thread("AutoOpenBoxes", SafeLoop("AutoOpenBoxes", Func_AutoOpenBoxes), state)
end)
Toggles.AutoSpeed:OnChanged(function(state)
    Thread("AutoSpeed", SafeLoop("AutoSpeed", Func_AutoSpeed), state)
end)
Toggles.AutoVoteMap:OnChanged(function(state)
    Thread("AutoVoteMap", SafeLoop("AutoVoteMap", Func_AutoVoteMap), state)
end)
Toggles.AutoVoteDifficulty:OnChanged(function(state)
    Thread("AutoVoteDifficulty", SafeLoop("AutoVoteDifficulty", Func_AutoVoteDifficulty), state)
end)
Toggles.AutoVoteMutator:OnChanged(function(state)
    Thread("AutoVoteMutator", SafeLoop("AutoVoteMutator", Func_AutoVoteMutator), state)
end)
Toggles.AutoReplay:OnChanged(function(state)
    Thread("AutoReplay", SafeLoop("AutoReplay", Func_AutoReplay), state)
end)
Toggles.AutoNewMap:OnChanged(function(state)
    Thread("AutoNewMap", SafeLoop("AutoNewMap", Func_AutoNewMap), state)
end)
Toggles.AutoJoin:OnChanged(function(state)
    if not state and ElevState.Current and Remotes.LeaveElevator then
        ElevState.Current = nil
    end
    Thread("AutoJoin", SafeLoop("AutoJoin", Func_AutoJoin), state)
end)
Toggles.AutoSummon:OnChanged(function(state)
    Thread("AutoSummon", SafeLoop("AutoSummon", Func_AutoSummon), state)
end)
Toggles.MacroRecord:OnChanged(function(state)
    Func_MacroRecord(state)
end)
Toggles.LoadMacro:OnChanged(function(state)
    if state then
        if not MState.Load and Options.MacroSelected and Options.MacroSelected.Value and Options.MacroSelected.Value ~= "" then
            MState.Load = LoadMacro(Options.MacroSelected.Value)
            if not MState.Load then
                Library:Notify("Failed to load macro: " .. tostring(Options.MacroSelected.Value), 4)
            end
        end
        if Toggles.MacroRecord and Toggles.MacroRecord.Value then
            Toggles.MacroRecord:SetValue(false)
        end
    end
    Thread("LoadMacro", SafeLoop("Macro Replay", Func_MacroReplay), state)
end)
Options.MacroSelected:OnChanged(function(v)
    if v and v ~= "" then
        MState.Load = LoadMacro(v)
        if not MState.Load then
            Library:Notify("Failed to load macro: " .. tostring(v), 4)
        end
    end
end)
if Options.MacroSelected.Value and Options.MacroSelected.Value ~= "" then
    MState.Load = LoadMacro(Options.MacroSelected.Value)
end
local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
        Default = Library.KeybindFrame.Visible,
        Text = "Open Keybind Menu",
        Callback = function(value)
                Library.KeybindFrame.Visible = value
        end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
        Text = "Custom Cursor",
        Default = false,
        Callback = function(Value)
                Library.ShowCustomCursor = Value
        end,
})
MenuGroup:AddDropdown("NotificationSide", {
        Values = { "Left", "Right" },
        Default = "Right",
        Text = "Notification Side",
        Callback = function(Value)
                Library:SetNotifySide(Value)
        end,
})
MenuGroup:AddDropdown("DPIDropdown", {
        Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
        Default = "100%",
        Text = "DPI Scale",
        Callback = function(Value)
                Value = Value:gsub("%%", "")
                local DPI = tonumber(Value)
                Library:SetDPIScale(DPI)
        end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
        :AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    Shared.Farm = false
    MState.Rec = false
    MState.Rep = false
    MState.Cur = nil
    MState.Load = nil
    MState.Pending = {}
    if antiAFKConn and antiAFKConn.Enable then pcall(function() antiAFKConn:Enable() end) end
    if Support.FPS then pcall(function() setfpscap(2000) end) end
    Cleanup(Connections)
    Cleanup(Flags)
        Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
SaveManager:IgnoreThemeSettings()
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/STD")
SaveManager:BuildConfigSection(Tabs.Config)
ThemeManager:ApplyToTab(Tabs.Config)
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
SaveManager:SetLoadingOrder(true, {"Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle"})
if UIS.TouchEnabled and not UIS.KeyboardEnabled then
    Library:SetDPIScale(75)
elseif UIS.KeyboardEnabled then
    Library:SetDPIScale(100)
end
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end
