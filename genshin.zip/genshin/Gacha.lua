if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
        if type(f) == t then return f end
        return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function" or typeof(queueonteleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
    HookMeta = (typeof(hookmetamethod) == "function"),
    Firesignal = (typeof(firesignal) == "function"),
}
Services = setmetatable({}, {
        __index = function(self, name)
                local success, cache = pcall(function()
                        return cloneref(game:GetService(name))
                end)
                if success then
                        rawset(self, name, cache)
                        return cache
                else
                        error("Invalid Service: " .. tostring(name))
                end
        end
})
local Players = Services.Players
local Plr = Players.LocalPlayer
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local l,f={},"1log.txt";if isfile and isfile(f)then delfile(f)end;if writefile then writefile(f,"")end;function notyuri(...)local t=table.create(select("#",...))for i=1,select("#",...)do t[i]=tostring(select(i,...))end local s=("[%s] %s"):format(os.date("%H:%M:%S"),table.concat(t," "));l[#l+1]=s;if appendfile then appendfile(f,s.."\n")end end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true
Library.ShowCustomCursor = true
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "6pCsSbVd3E"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end

local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
}
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
}
function AddMultiDropdown(group, id, config)
    if type(group) == "string" then
        local selected = {}
        local dropdown = Options[group]
        local values = dropdown and dropdown.Values or {}
        local chosen = dropdown and dropdown.Value or {}
        if chosen["All"] then
            for _, label in ipairs(values) do
                if label ~= "All" then selected[label] = true end
            end
        else
            for label, active in pairs(chosen) do
                if active and label ~= "All" then selected[label] = true end
            end
        end
        return selected
    end
    config = config or {}
    local values = { "All" }
    for _, v in ipairs(config.Values or {}) do
        table.insert(values, v)
    end
    group:AddDropdown(id, {
        Text = config.Text,
        Values = values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    return Options[id]
end
function SafeLabel(target, id, text)
    if type(target) == "string" then
        local entry = Shared.Labels[target]
        if entry then
            entry.Text = id
            entry.Dirty = true
        end
        return
    end
    local label = target:AddLabel(text, true)
    Shared.Labels[id] = {Label = label, Text = text, Dirty = false}
    Thread("SafeLabel", function()
        while not Library.Unloaded do
            for key, entry in pairs(Shared.Labels) do
                if entry.Dirty then
                    entry.Dirty = false
                    local ok, err = pcall(function()
                        entry.Label:SetText(entry.Text)
                    end)
                    if not ok then
                        notyuri("SetText FAILED:", tostring(key), tostring(err))
                    end
                end
            end
            task.wait()
        end
    end, true)
    return label
end
function AddSliderToggle(Config)
    local Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false,
        Disabled = Config.Disabled,
    })
    local Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    Toggle:OnChanged(function()
        Slider:SetVisible(Toggle.Value)
    end)
    return Toggle, Slider
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local function SafeInvoke(remote, ...)
    local args = {...}
    local result = nil
    task.spawn(function()
        local success, res = pcall(function()
            return remote:InvokeServer(unpack(args))
        end)
        result = res
    end)
    local start = tick()
    repeat task.wait() until result ~= nil or (tick() - start) > 2
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        local args = {...}
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Fire then
                pcall(function() connection:Fire(unpack(args)) end)
            elseif connection.Function then
                task.spawn(connection.Function, unpack(args))
            end
        end
    else
        warn("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            currentTable[flagKey] = task.spawn(featureFunc, ...)
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            warn("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
local function GetCharacter()
    local c = Plr.Character
    return (c and c:FindFirstChild("HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function TPTo(target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    hrp.CFrame = cframe
    return true
end
local function GetNearest(list, filterFn)
    local char = GetCharacter()
    local root = char and char:FindFirstChild("HumanoidRootPart")
    if not root then return nil end
    local best, bestDist = nil, math.huge
    for _, inst in ipairs(list) do
        if not filterFn or filterFn(inst) then
            local part = inst:IsA("BasePart") and inst or (inst:IsA("Model") and inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart"))
            if part then
                local dist = (part.Position - root.Position).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    best = inst
                end
            end
        end
    end
    return best, bestDist
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            pcall(function()
                local promptOverlay = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = promptOverlay.promptOverlay:FindFirstChild("ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Plr)
                    end
                end
            end)
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local success, err = pcall(function()
            local pauseGui = game:GetService("CoreGui").RobloxGui:FindFirstChild("CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    if teleport then
        local char = GetCharacter()
        local hrp = char and GetObject(char, "HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local pos = isModel and part:GetPivot().Position or part.Position
            if (hrp.Position - pos).Magnitude > target.MaxActivationDistance then
                TPTo(part)
                task.wait(0.2)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and Plr.Character:FindFirstChild("HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, true)
        task.wait()
        firetouchinterest(part, root, false)
    end)
end
local function Serverhop()
    local hopSuccess, hopErr = pcall(function()
        local baseUrl = 'https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100'
        local servers = {}
        local cursor = ''
        for _ = 1, 3 do
            local url = baseUrl
            if cursor ~= '' then url = url .. '&cursor=' .. cursor end
            local pages = game:HttpGet(url)
            local data = HttpService:JSONDecode(pages)
            for _, server in ipairs(data.data) do
                if server.playing < server.maxPlayers and server.id ~= game.JobId then
                    table.insert(servers, server)
                end
            end
            cursor = data.nextPageCursor
            if not cursor or cursor == '' then break end
        end
        table.sort(servers, function(a, b) return a.playing < b.playing end)
        if #servers == 0 then
            Library:Notify("No servers found to hop to.", 3)
            return
        end
        local best = servers[1]
        for _, server in ipairs(servers) do
            if server.playing > 0 then
                best = server
                break
            end
        end
        TeleportService:TeleportToPlaceInstance(game.PlaceId, best.id, Plr)
    end)
    if not hopSuccess then
        Library:Notify("Serverhop failed: " .. tostring(hopErr), 5)
    end
end
Shared.Labels = {}
local LibClient = GetObject(RS, "Library.Client")
local LibRoot = GetObject(RS, "Library")
local LibTypes = GetObject(RS, "Library.Types")
local LibModules = GetObject(RS, "Library.Modules")
local LibUtil = GetObject(RS, "Library.Util")
local Net = LibClient and GetSafeModule(LibClient, "Network")
local SaveM = LibClient and GetSafeModule(LibClient, "Save")
local GachaCmds = LibClient and GetSafeModule(LibClient, "GachaCmds")
local CurrencyCmds = LibClient and GetSafeModule(LibClient, "CurrencyCmds")
local ExpeditionCmds = LibClient and GetSafeModule(LibClient, "ExpeditionCmds")
local UECmds = LibClient and GetSafeModule(LibClient, "UpgradeExchangeCmds")
local GameGui = LibClient and GetSafeModule(LibClient, "GUI")
local Directory = LibRoot and GetSafeModule(LibRoot, "Directory")
local Var = LibRoot and GetSafeModule(LibRoot, "Variables")
local UpgradeTypes = LibTypes and GetSafeModule(LibTypes, "UpgradeTypes")
local TimedRewards = LibTypes and GetSafeModule(LibTypes, "Timed Rewards")
local GetMaxEquipped = LibTypes and GetSafeModule(LibTypes, "GetMaxEquipped")
local ItemClassing = LibModules and GetSafeModule(LibModules, "ItemClassing")
local GachaUtil = LibModules and GetSafeModule(LibModules, "Gacha")
local ExpeditionUtil = LibUtil and GetSafeModule(LibUtil, "Expedition")
local Rolling = GameGui and GameGui.Rolling and GameGui.Rolling()
local OrbMap = {}
local SessionOrbs = 0
local PullFailNotified = false
local OfflineClaimed = false
local LastEquipSig = nil
local Funcs = {}

local function BannerList()
    local list = {}
    if Directory then
        for name in pairs(Directory.Banners or {}) do
            table.insert(list, name)
        end
    end
    table.sort(list)
    return list
end

local function DurationList()
    local list = {}
    if ExpeditionUtil then
        for _, d in ipairs(ExpeditionUtil.Durations or {}) do
            table.insert(list, d.Id)
        end
    end
    return list
end

local function UpgradeList()
    local list = {}
    if Directory then
        for id in pairs(Directory.Upgrades or {}) do
            table.insert(list, id)
        end
    end
    table.sort(list)
    return list
end

local function TierLuck(charId)
    if not Directory then
        return 0
    end
    local char = Directory.Characters and Directory.Characters[charId]
    local tier = char and char.Tier and Directory.Tiers and Directory.Tiers[char.Tier]
    return (tier and tier.Stats and tier.Stats.Luck) or 0
end

local function EquippedCounts(sv)
    local counts = {}
    local n = 0
    for _, v in pairs(sv.Equipped or {}) do
        local uid = type(v) == "table" and tostring(v.UID) or tostring(v)
        counts[uid] = (counts[uid] or 0) + 1
        n = n + 1
    end
    return counts, n
end

local function InvCount(sv)
    local n = 0
    for _, entry in pairs(sv.Inventory or {}) do
        if type(entry) == "table" then
            n = n + (entry.Amount or 1)
        end
    end
    return n
end

local function PullIter()
    if not (Directory and GachaCmds and CurrencyCmds and Rolling) then
        return
    end
    local banner = Options.PullBanner and Options.PullBanner.Value
    local amount = tonumber(Options.PullAmount and Options.PullAmount.Value) or 10
    local cfg = banner and Directory.Banners[banner]
    if not cfg then
        task.wait(1)
        return
    end
    if Toggles.EnsureAutoConvert and Toggles.EnsureAutoConvert.Value then
        local sv = SaveM.Get()
        if sv and sv.Settings and sv.Settings.AutoConvertNexus ~= 1 then
            pcall(Net.Invoke, "Toggle Setting", "AutoConvertNexus")
            task.wait(0.25)
        end
    end
    if not CurrencyCmds.CanAffordWithAutoConvert(cfg.Currency, cfg.Cost * amount) then
        if not PullFailNotified then
            PullFailNotified = true
            Library:Notify("Auto Pull: cannot afford " .. tostring(banner) .. ", waiting for currency", 5)
        end
        task.wait(5)
        return
    end
    PullFailNotified = false
    local ok, r1, r2 = pcall(GachaCmds.Roll, banner, amount)
    if not ok then
        notyuri("AutoPull error:", tostring(r1))
        task.wait(2)
        return
    end
    if r1 == nil then
        if not PullFailNotified then
            PullFailNotified = true
            Library:Notify("Auto Pull: " .. tostring(r2 or "roll failed"), 5)
        end
        task.wait(3)
        return
    end
    local waited = 0
    while not Rolling.Enabled and waited < 3 do
        task.wait(0.1)
        waited = waited + 0.1
    end
    local advanced = 0
    while Rolling.Enabled and advanced < 60 do
        local handler = Var and Var.ActiveHandler
        if handler and handler.Advance then
            pcall(handler.Advance)
        end
        advanced = advanced + 1
        task.wait(0.25)
    end
    local okS, speed = pcall(GachaCmds.PullSpeed)
    task.wait(0.4 * ((okS and speed) or 1))
end

Funcs.AutoPull = function()
    while not Library.Unloaded do
        local ok, err = pcall(PullIter)
        if not ok then
            Library:Notify("Error in [AutoPull]: " .. tostring(err), 10)
            task.wait(1)
        end
    end
end

local function OrbsIter()
    if not Net then
        return
    end
    local did = 0
    for id, inst in pairs(OrbMap) do
        if not inst or not inst.Parent then
            OrbMap[id] = nil
        else
            if Toggles.OrbTP and Toggles.OrbTP.Value then
                TPTo(inst)
                task.wait(0.15)
            end
            local char = GetCharacter()
            local hrp = char and char:FindFirstChild("HumanoidRootPart")
            if hrp then
                local pos = inst:GetPivot().Position
                if (hrp.Position - pos).Magnitude <= 13 then
                    local ok, res = pcall(Net.Invoke, "Orbs: Collect", id)
                    if ok and res then
                        OrbMap[id] = nil
                        SessionOrbs = SessionOrbs + 1
                        did = did + 1
                    end
                end
            end
        end
    end
    if did == 0 then
        task.wait((Options.OrbDelay and Options.OrbDelay.Value) or 1)
    end
end

Funcs.AutoOrbs = function()
    while not Library.Unloaded do
        local ok, err = pcall(OrbsIter)
        if not ok then
            Library:Notify("Error in [AutoOrbs]: " .. tostring(err), 10)
            task.wait(1)
        end
    end
end

local function EquipIter()
    local sv = SaveM and SaveM.Get()
    if not sv then
        return
    end
    local mode = (Options.EquipMode and Options.EquipMode.Value) or "Best Luck"
    if mode == "Server Best" then
        local _, eqN = EquippedCounts(sv)
        local sig = tostring(eqN) .. ":" .. tostring(InvCount(sv))
        if sig == LastEquipSig then
            return
        end
        if pcall(Net.Invoke, "Characters_EquipBest") then
            LastEquipSig = sig
        end
        return
    end
    if not (Directory and Net) then
        return
    end
    local equipped, eqCount = EquippedCounts(sv)
    local copies = {}
    for uid, entry in pairs(sv.Inventory or {}) do
        if type(entry) == "table" and entry.Id then
            local char = Directory.Characters and Directory.Characters[entry.Id]
            local tier = char and char.Tier and Directory.Tiers and Directory.Tiers[char.Tier]
            local luck = (tier and tier.Stats and tier.Stats.Luck) or 0
            local value = (tier and tier.Value) or 0
            for _ = 1, (entry.Amount or 1) do
                table.insert(copies, { Uid = tostring(uid), Luck = luck, Value = value })
            end
        end
    end
    if #copies == 0 then
        return
    end
    table.sort(copies, function(a, b)
        if a.Luck ~= b.Luck then
            return a.Luck > b.Luck
        end
        if a.Value ~= b.Value then
            return a.Value > b.Value
        end
        return a.Uid < b.Uid
    end)
    local maxEq = (GetMaxEquipped and GetMaxEquipped(sv)) or (sv.MaxCharacterEquipped or 3)
    local wantCount = math.min(maxEq, #copies)
    local want = {}
    for i = 1, wantCount do
        local uid = copies[i].Uid
        want[uid] = (want[uid] or 0) + 1
    end
    local same = eqCount == wantCount
    if same then
        for uid, n in pairs(want) do
            if (equipped[uid] or 0) < n then
                same = false
                break
            end
        end
    end
    if same then
        return
    end
    for key in pairs(sv.Equipped or {}) do
        pcall(Net.Fire, "Characters_Unequip", key)
        task.wait(0.05)
    end
    local waited = 0
    while waited < 3 do
        local s2 = SaveM.Get()
        local _, n2 = s2 and EquippedCounts(s2)
        if n2 == 0 then
            break
        end
        task.wait(0.1)
        waited = waited + 0.1
    end
    for uid, n in pairs(want) do
        for _ = 1, n do
            pcall(Net.Fire, "Characters_Equip", uid)
            task.wait(0.05)
        end
    end
end

Funcs.AutoEquip = function()
    while not Library.Unloaded do
        local ok, err = pcall(EquipIter)
        if not ok then
            Library:Notify("Error in [AutoEquip]: " .. tostring(err), 10)
            task.wait(1)
        end
        task.wait(5)
    end
end

local function ExchangeIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Directory and Net) then
        return
    end
    local keep = math.max(1, math.floor((Options.KeepCopies and Options.KeepCopies.Value) or 1))
    local protect = Toggles.ProtectRares and Toggles.ProtectRares.Value
    if protect and not ItemClassing then
        return
    end
    local equipped = EquippedCounts(sv)
    local batch = {}
    for uid, entry in pairs(sv.Inventory or {}) do
        if type(entry) == "table" and entry.Id then
            local skip = false
            if protect then
                local char = Directory.Characters and Directory.Characters[entry.Id]
                local tier = char and char.Tier
                if tier and ItemClassing.TierIndex(tier) >= 4 then
                    skip = true
                end
            end
            if not skip then
                local free = (entry.Amount or 1) - math.max(keep, equipped[uid] or 0)
                if free > 0 then
                    batch[tostring(uid)] = free
                end
            end
        end
    end
    if next(batch) then
        local ok, res = pcall(Net.Invoke, "ExchangeCards", batch)
        if ok and res then
            Library:Notify("Exchanged cards for essence", 3)
        end
    end
end

Funcs.AutoExchange = function()
    while not Library.Unloaded do
        local ok, err = pcall(ExchangeIter)
        if not ok then
            Library:Notify("Error in [AutoExchange]: " .. tostring(err), 10)
            task.wait(1)
        end
        task.wait(4)
    end
end

local function BoostIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Directory and Net and UECmds and UpgradeTypes) then
        return
    end
    local essence = sv.Essence or 0
    local minE = (Options.MinEssence and Options.MinEssence.Value) or 50
    if essence < minE then
        return
    end
    local sel = AddMultiDropdown("BoostUpgrades")
    for id in pairs(sel) do
        local upg = Directory.Upgrades and Directory.Upgrades[id]
        local conv = (upg and upg.ItemToTimeConversion) or UpgradeTypes.ItemToTimeConversion
        local bt = UECmds.GetBoostTime(id)
        local maxAdd = math.ceil(math.max(0, UpgradeTypes.MaxTime - (bt or 0)) / conv)
        local add = math.min(maxAdd, essence)
        if add > 0 then
            local ok, res = pcall(Net.Invoke, "UpgradeExchange_AddTime", id, add)
            if ok and res then
                essence = essence - add
                task.wait(0.3)
            end
        end
    end
end

Funcs.AutoBoost = function()
    while not Library.Unloaded do
        local ok, err = pcall(BoostIter)
        if not ok then
            Library:Notify("Error in [AutoBoost]: " .. tostring(err), 10)
            task.wait(1)
        end
        task.wait(5)
    end
end

local function ExpeditionIter()
    if not (ExpeditionCmds and ExpeditionUtil and Net and Directory) then
        return
    end
    local active = ExpeditionCmds.GetActive()
    if active then
        local remaining = ExpeditionCmds.GetTimeRemaining() or 0
        if remaining > 0 then
            return
        end
        pcall(Net.Invoke, "Expedition: Claim")
        task.wait(1)
    end
    local sv = SaveM.Get()
    if not sv then
        return
    end
    local copies = {}
    for _, entry in pairs(sv.Inventory or {}) do
        if type(entry) == "table" and entry.Id then
            local power = ExpeditionUtil.GetCharacterPower(entry.Id)
            if power > 0 then
                for _ = 1, (entry.Amount or 1) do
                    table.insert(copies, { Id = entry.Id, Power = power })
                end
            end
        end
    end
    if #copies == 0 then
        return
    end
    table.sort(copies, function(a, b)
        if a.Power ~= b.Power then
            return a.Power > b.Power
        end
        return a.Id < b.Id
    end)
    local party = {}
    for i = 1, math.min(ExpeditionUtil.MaxSlots or 6, #copies) do
        table.insert(party, copies[i].Id)
    end
    local duration = (Options.ExpeditionDuration and Options.ExpeditionDuration.Value) or (DurationList()[1])
    if not ExpeditionUtil.GetDuration(duration) then
        return
    end
    pcall(Net.Invoke, "Expedition: Start", party, duration)
    task.wait(1)
    if not ExpeditionCmds.GetActive() then
        local uniq = {}
        for _, id in ipairs(party) do
            if not table.find(uniq, id) then
                table.insert(uniq, id)
            end
        end
        if #uniq > 0 and #uniq ~= #party then
            pcall(Net.Invoke, "Expedition: Start", uniq, duration)
        end
    end
end

Funcs.AutoExpedition = function()
    while not Library.Unloaded do
        local ok, err = pcall(ExpeditionIter)
        if not ok then
            Library:Notify("Error in [AutoExpedition]: " .. tostring(err), 10)
            task.wait(1)
        end
        task.wait(8)
    end
end

local function LoginStreakIter()
    pcall(Net.Invoke, "LoginStreak: Claim")
end

Funcs.AutoLoginStreak = function()
    while not Library.Unloaded do
        pcall(LoginStreakIter)
        task.wait(60)
    end
end

local function DailyIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Net) then
        return
    end
    local dr = sv.DailyRewards or {}
    local claimed = dr.Claimed or {}
    local nextDay = nil
    for i = 1, 7 do
        if not claimed[i] then
            nextDay = i
            break
        end
    end
    if not nextDay then
        return
    end
    if nextDay > 1 and os.time() - (dr.LastClaimed or 0) < 86400 then
        return
    end
    pcall(Net.Invoke, "Claim Daily Reward", nextDay)
end

Funcs.AutoDaily = function()
    while not Library.Unloaded do
        pcall(DailyIter)
        task.wait(60)
    end
end

local function OfflineIter()
    if OfflineClaimed or not Net then
        return
    end
    local ok, res = pcall(Net.Invoke, "Claim Offline Rewards")
    if ok and res then
        OfflineClaimed = true
        Library:Notify("Offline rewards claimed", 4)
    end
end

Funcs.AutoOffline = function()
    while not Library.Unloaded do
        pcall(OfflineIter)
        task.wait(60)
    end
end

local function GiftsIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Net and TimedRewards) then
        return
    end
    local redeemed = {}
    for _, v in ipairs(sv.FreeGiftsRedeemed or {}) do
        redeemed[tonumber(v) or v] = true
    end
    local playtime = sv.Playtime or 0
    for _, reward in ipairs(TimedRewards.Rewards or {}) do
        if not redeemed[reward.Index] and reward.Time <= playtime then
            pcall(Net.Invoke, "Redeem Free Gift", reward.Index)
            task.wait(0.2)
        end
    end
end

Funcs.AutoGifts = function()
    while not Library.Unloaded do
        pcall(GiftsIter)
        task.wait(30)
    end
end

local function QuestsIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Net and Directory) then
        return
    end
    for cat, cfg in pairs(Directory.Quests or {}) do
        local quests = cfg and cfg.Quests
        if type(quests) == "table" then
            local state = sv.Quests and sv.Quests[cat]
            if type(state) == "table" then
                for qid, q in pairs(quests) do
                    if not q.CantClaim then
                        local s = state[qid]
                        if type(s) == "table" and not s.Claimed and (s.Progress or 0) >= (q.Goal or math.huge) then
                            pcall(Net.Invoke, "Quests: Claim", cat, qid)
                            task.wait(0.25)
                        end
                    end
                end
            end
        end
    end
end

Funcs.AutoQuests = function()
    while not Library.Unloaded do
        pcall(QuestsIter)
        task.wait(15)
    end
end

local function IndexIter()
    local sv = SaveM and SaveM.Get()
    if not (sv and Net) then
        return
    end
    local obtained = sv.Obtained or {}
    local claimed = sv.IndexClaimed or {}
    local n = 0
    for charId in pairs(obtained) do
        if not claimed[charId] then
            n = n + 1
        end
    end
    if n == 0 then
        return
    end
    if n > 2 then
        pcall(Net.Invoke, "Index_ClaimAll")
    else
        for charId in pairs(obtained) do
            if not claimed[charId] then
                pcall(Net.Invoke, "Index_Claim", charId)
                task.wait(0.15)
            end
        end
    end
end

Funcs.AutoIndex = function()
    while not Library.Unloaded do
        pcall(IndexIter)
        task.wait(10)
    end
end

Funcs.Stats = function()
    while not Library.Unloaded do
        pcall(function()
            local sv = SaveM and SaveM.Get()
            if not sv then
                return
            end
            local cur = sv.Currency or {}
            local luck = 0
            if GachaUtil then
                local okL, res = pcall(GachaUtil.GetLuckBoost, sv)
                if okL and type(res) == "number" then
                    luck = res
                end
            end
            local pityText = "-"
            local banner = Options.PullBanner and Options.PullBanner.Value
            local cfg = banner and Directory and Directory.Banners and Directory.Banners[banner]
            if cfg and GachaUtil and GachaUtil.GetPityProgress then
                local okP, prog = pcall(GachaUtil.GetPityProgress, cfg, sv)
                if okP and type(prog) == "table" then
                    pityText = tostring(prog.Count or 0) .. "/" .. tostring(prog.Max or 0)
                    if prog.Guaranteed then
                        pityText = pityText .. " (Guaranteed!)"
                    end
                end
            end
            SafeLabel("StatsMain", table.concat({
                "Primogems: " .. CommaFormat(cur.Primogems or 0),
                "Nexus Gems: " .. CommaFormat(cur["Nexus Gems"] or 0),
                "Essence: " .. CommaFormat(sv.Essence or 0),
                "Total Rolls: " .. CommaFormat(sv.TotalRolls or 0),
                "Luck: +" .. tostring(luck),
                "Pity: " .. pityText,
            }, "\n"))
            local eqLuck = 0
            local eqN = 0
            for _, v in pairs(sv.Equipped or {}) do
                local uid = type(v) == "table" and tostring(v.UID) or tostring(v)
                local entry = sv.Inventory and sv.Inventory[uid]
                if entry then
                    eqLuck = eqLuck + TierLuck(entry.Id)
                end
                eqN = eqN + 1
            end
            local maxEq = (GetMaxEquipped and GetMaxEquipped(sv)) or (sv.MaxCharacterEquipped or 3)
            local expText = "None"
            if ExpeditionCmds then
                local active = ExpeditionCmds.GetActive()
                if active then
                    local rem = ExpeditionCmds.GetTimeRemaining() or 0
                    if rem > 0 then
                        local m = math.floor(rem / 60)
                        expText = (m >= 60 and (math.floor(m / 60) .. "h ") or "") .. (m % 60) .. "m left"
                    else
                        expText = "Ready to claim"
                    end
                end
            end
            local orbN = 0
            for _ in pairs(OrbMap) do
                orbN = orbN + 1
            end
            SafeLabel("StatsMisc", table.concat({
                "Equipped: " .. eqN .. "/" .. maxEq .. " (+" .. tostring(eqLuck) .. " luck)",
                "Expedition: " .. expText,
                "Orbs on map: " .. orbN .. " (session: " .. SessionOrbs .. ")",
            }, "\n"))
        end)
        task.wait(1)
    end
end

SafeConnect("OrbsUpdated", function()
    return Net and Net.Fired and Net.Fired("Orbs: Updated")
end, function(payload)
    if type(payload) ~= "table" then
        return
    end
    local seen = {}
    for id, data in pairs(payload) do
        seen[id] = true
        if type(data) == "table" and data.Instance then
            OrbMap[id] = data.Instance
        end
    end
    for id in pairs(OrbMap) do
        if not seen[id] then
            OrbMap[id] = nil
        end
    end
end)

local Window = Library:CreateWindow({
        Title = "Yuri",
        Center = true,
        AutoShow = true,
        Resizable = true,
        ShowCustomCursor = false,
        UnlockMouseWhileOpen = false,
        NotifySide = "Left",
        TabPadding = 8,
        MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
        Main = Window:AddTab("Main"),
    Player = Window:AddTab("Player"),
    Config = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Autofarm"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
}
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
local TPW_T, TPW_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1})
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
local FPS_T, FPS_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused"})
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function() Serverhop() end })
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Plr) end })
GB.Player.Left.Server:AddToggle("AutoServerhop", { Text = "Auto Serverhop" })
GB.Player.Left.Server:AddSlider("AutoHopMins", { Text = "Minutes", Default = 30, Min = 0, Max = 300, Compact = true, Rounding = 0 })
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    TPW_S:SetVisible(TPW_T.Value)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Toggles.AutoServerhop:OnChanged(function(state)
    Thread("AutoServerhop", function()
        local lastHop = tick()
        while Toggles.AutoServerhop.Value do
            task.wait(5)
            if not Toggles.AutoServerhop.Value then break end
            if (tick() - lastHop) >= (Options.AutoHopMins.Value * 60) then
                Serverhop()
                break
            end
        end
    end, state)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then Hum.JumpPower = Options.JPValue.Value Hum.UseJumpPower = true end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if FPS_T.Value then
        setfpscap(FPS_S.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    FPS_S:SetVisible(FPS_T.Value)
    if not v and Support.FPS then
        setfpscap(2000)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local antiAFKConn = nil
local function RunAntiAFK()
    if antiAFKConn then antiAFKConn:Enable() return end
    local GC = getconnections or get_signal_cons
    if GC then
        local conns = GC(Players.LocalPlayer.Idled)
        local target = conns and conns[1]
        if target and target.Disable then
            target:Disable()
            antiAFKConn = target
            return
        end
        for _, c in pairs(conns or {}) do
            if c.Disable then
                c:Disable()
                antiAFKConn = c
                return
            elseif c.Disconnect then
                c:Disconnect()
                return
            end
        end
    end
    Players.LocalPlayer.Idled:Connect(function()
        VirtualUser:CaptureController()
        VirtualUser:ClickButton2(Vector2.new())
    end)
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then
        RunAntiAFK()
    elseif antiAFKConn and antiAFKConn.Enable then
        antiAFKConn:Enable()
    end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
TB_Tabs.Autofarm.T2 = TB.Main.Left.Autofarm:AddTab("Claims")
TB_Tabs.Autofarm2.T2 = TB.Main.Right.Autofarm:AddTab("Stats")
local GBGame = {
    Pull = TB_Tabs.Autofarm.T1:AddGroupbox("Gacha"),
    Farm = TB_Tabs.Autofarm.T1:AddGroupbox("Farm"),
    Cards = TB_Tabs.Autofarm.T1:AddGroupbox("Cards & Boosts"),
    Claims = TB_Tabs.Autofarm.T2:AddGroupbox("Auto Claim"),
    PullCfg = TB_Tabs.Autofarm2.T1:AddGroupbox("Pull Config"),
    OrbCfg = TB_Tabs.Autofarm2.T1:AddGroupbox("Orb Config"),
    EquipCfg = TB_Tabs.Autofarm2.T1:AddGroupbox("Equip / Exchange"),
    ExpCfg = TB_Tabs.Autofarm2.T1:AddGroupbox("Expedition"),
    Stats = TB_Tabs.Autofarm2.T2:AddGroupbox("Live Stats"),
}
local BannerValues = BannerList()
local DurationValues = DurationList()
local UpgradeValues = UpgradeList()
GBGame.Pull:AddToggle("AutoPull", { Text = "Auto Pull" })
GBGame.Pull:AddToggle("AutoOrbs", { Text = "Auto Collect Orbs" })
GBGame.Pull:AddToggle("AutoEquip", { Text = "Auto Equip Best" })
GBGame.Pull:AddToggle("AutoExpedition", { Text = "Auto Expedition" })
GBGame.Cards:AddToggle("AutoExchange", { Text = "Auto Exchange Cards" })
GBGame.Cards:AddToggle("AutoBoost", { Text = "Auto Boost Exchange" })
GBGame.Claims:AddToggle("AutoLoginStreak", { Text = "Auto Login Streak" })
GBGame.Claims:AddToggle("AutoDaily", { Text = "Auto Daily Reward" })
GBGame.Claims:AddToggle("AutoOffline", { Text = "Auto Offline Rewards" })
GBGame.Claims:AddToggle("AutoGifts", { Text = "Auto Free Gifts" })
GBGame.Claims:AddToggle("AutoQuests", { Text = "Auto Daily Quests" })
GBGame.Claims:AddToggle("AutoIndex", { Text = "Auto Index Rewards" })
GBGame.PullCfg:AddDropdown("PullBanner", {
    Text = "Banner",
    Values = BannerValues,
    Default = BannerValues[1],
})
GBGame.PullCfg:AddDropdown("PullAmount", {
    Text = "Pull Amount",
    Values = { "1", "10" },
    Default = "10",
})
GBGame.PullCfg:AddToggle("EnsureAutoConvert", { Text = "Ensure Auto-Convert Nexus", Default = true })
GBGame.OrbCfg:AddToggle("OrbTP", { Text = "Teleport To Orbs", Default = true })
GBGame.OrbCfg:AddSlider("OrbDelay", { Text = "Idle Delay", Default = 1, Min = 0.25, Max = 5, Rounding = 2 })
GBGame.EquipCfg:AddDropdown("EquipMode", {
    Text = "Equip Mode",
    Values = { "Best Luck", "Server Best" },
    Default = "Best Luck",
})
GBGame.EquipCfg:AddSlider("KeepCopies", { Text = "Keep Copies Per Card", Default = 1, Min = 1, Max = 10, Rounding = 0 })
GBGame.EquipCfg:AddToggle("ProtectRares", { Text = "Protect 5 Star And Better", Default = true })
AddMultiDropdown(GBGame.EquipCfg, "BoostUpgrades", { Text = "Boost Targets", Values = UpgradeValues, Default = { "All" } })
GBGame.EquipCfg:AddSlider("MinEssence", { Text = "Min Essence To Spend", Default = 50, Min = 1, Max = 1000, Rounding = 0 })
GBGame.ExpCfg:AddDropdown("ExpeditionDuration", {
    Text = "Duration",
    Values = DurationValues,
    Default = DurationValues[#DurationValues],
})
SafeLabel(GBGame.Stats, "StatsMain", "Loading stats...")
SafeLabel(GBGame.Stats, "StatsMisc", "")
Toggles.AutoPull:OnChanged(function(state)
    Thread("Farm.AutoPull", Funcs.AutoPull, state)
end)
Toggles.AutoOrbs:OnChanged(function(state)
    Thread("Farm.AutoOrbs", Funcs.AutoOrbs, state)
end)
Toggles.AutoEquip:OnChanged(function(state)
    Thread("Farm.AutoEquip", Funcs.AutoEquip, state)
end)
Toggles.AutoExchange:OnChanged(function(state)
    Thread("Farm.AutoExchange", Funcs.AutoExchange, state)
end)
Toggles.AutoBoost:OnChanged(function(state)
    Thread("Farm.AutoBoost", Funcs.AutoBoost, state)
end)
Toggles.AutoExpedition:OnChanged(function(state)
    Thread("Farm.AutoExpedition", Funcs.AutoExpedition, state)
end)
Toggles.AutoLoginStreak:OnChanged(function(state)
    Thread("Claims.AutoLoginStreak", Funcs.AutoLoginStreak, state)
end)
Toggles.AutoDaily:OnChanged(function(state)
    Thread("Claims.AutoDaily", Funcs.AutoDaily, state)
end)
Toggles.AutoOffline:OnChanged(function(state)
    Thread("Claims.AutoOffline", Funcs.AutoOffline, state)
end)
Toggles.AutoGifts:OnChanged(function(state)
    Thread("Claims.AutoGifts", Funcs.AutoGifts, state)
end)
Toggles.AutoQuests:OnChanged(function(state)
    Thread("Claims.AutoQuests", Funcs.AutoQuests, state)
end)
Toggles.AutoIndex:OnChanged(function(state)
    Thread("Claims.AutoIndex", Funcs.AutoIndex, state)
end)
Thread("Farm.Stats", Funcs.Stats, true)
local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
        Default = Library.KeybindFrame.Visible,
        Text = "Open Keybind Menu",
        Callback = function(value)
                Library.KeybindFrame.Visible = value
        end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
        Text = "Custom Cursor",
        Default = false,
        Callback = function(Value)
                Library.ShowCustomCursor = Value
        end,
})
MenuGroup:AddDropdown("NotificationSide", {
        Values = { "Left", "Right" },
        Default = "Right",
        Text = "Notification Side",
        Callback = function(Value)
                Library:SetNotifySide(Value)
        end,
})
MenuGroup:AddDropdown("DPIDropdown", {
        Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
        Default = "100%",
        Text = "DPI Scale",
        Callback = function(Value)
                Value = Value:gsub("%%", "")
                local DPI = tonumber(Value)
                Library:SetDPIScale(DPI)
        end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
        :AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    if antiAFKConn and antiAFKConn.Enable then pcall(function() antiAFKConn:Enable() end) end
    if Support.FPS then pcall(function() setfpscap(2000) end) end
    Cleanup(Connections)
    Cleanup(Flags)
        Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
SaveManager:IgnoreThemeSettings()
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/gacha")
SaveManager:BuildConfigSection(Tabs.Config)
ThemeManager:ApplyToTab(Tabs.Config)
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
SaveManager:SetLoadingOrder(true, {"Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle"})
if UIS.TouchEnabled and not UIS.KeyboardEnabled then
    Library:SetDPIScale(75)
elseif UIS.KeyboardEnabled then
    Library:SetDPIScale(100)
end
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end
