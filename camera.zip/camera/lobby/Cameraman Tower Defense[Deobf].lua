--- Players.LocalPlayer.PlayerScripts.Loader [LocalScript]
-- y u r i

local str1 = "Initializer"
require(script:WaitForChild(str1))

--- Players.LocalPlayer.PlayerScripts.Loader.Initializer [ModuleScript]
-- y u r i

require(game.ReplicatedStorage.ModuleLoader)
return true

--- Players.LocalPlayer.PlayerScripts.PlayerModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local str1 = "CameraModule"
	local var1 = setmetatable({}, tbl1)
	var1.cameras = require(script:WaitForChild(str1))
	str1 = "ControlModule"
	var1.controls = require(script:WaitForChild(str1))
	return var1
end

tbl1.GetCameras = function(arg1)
	return arg1.cameras
end

tbl1.GetControls = function(arg1)
	return arg1.controls
end

tbl1.GetClickToMoveController = function(arg1)
	return arg1.controls:GetClickToMoveController()
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
local var1 = script.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local var3 = require(var1:WaitForChild(str2))
local str4 = "CameraInput"
local var4 = require(script:WaitForChild(str3))
local str5 = "ClassicCamera"
str1 = require(script:WaitForChild(str4))
local str6 = "OrbitalCamera"
str2 = require(script:WaitForChild(str5))
local str7 = "LegacyCamera"
str3 = require(script:WaitForChild(str6))
local str8 = "VehicleCamera"
str4 = require(script:WaitForChild(str7))
local str9 = "VRCamera"
str5 = require(script:WaitForChild(str8))
local str10 = "VRVehicleCamera"
str6 = require(script:WaitForChild(str9))
local str11 = "Invisicam"
str7 = require(script:WaitForChild(str10))
local str12 = "Poppercam"
str8 = require(script:WaitForChild(str11))
local str13 = "TransparencyController"
str9 = require(script:WaitForChild(str12))
local str14 = "MouseLockController"
str10 = require(script:WaitForChild(str13))
local var5 = game:GetService("Players")
str11 = require(script:WaitForChild(str14))
local tbl2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock",
}

local tbl3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode",
}

local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("VRService")
local var9 = UserSettings():GetService("UserGameSettings")
str12 = {}
str13 = {}
if not var5.LocalPlayer then
	return {}
end

assert(var5.LocalPlayer, "Strict typing check")
str14 = var5.LocalPlayer:WaitForChild("PlayerScripts")
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
str14 = var3.getUserFlag("UserPlayerConnectionMemoryLeak")
local var10 = var3.getUserFlag("UserPSFixCameraControllerReset")
tbl1.new = function()
	local tbl4 = { activeTransparencyController = str10.new() }
	local var1 = if str14 then var2.new() else nil
	tbl4.connectionUtil = var1
	local var3 = setmetatable(tbl4, tbl1)
	var3.activeCameraController = nil
	var3.activeOcclusionModule = nil
	var3.activeMouseLockController = nil
	var3.currentComputerCameraMovementMode = nil
	var3.cameraSubjectChangedConn = nil
	var3.cameraTypeChangedConn = nil
	for k1, v1 in pairs(var5:GetPlayers()) do
		var3:OnPlayerAdded(v1)
	end

	var5.PlayerAdded:Connect(function(arg1)
		var3:OnPlayerAdded(arg1)
	end)

	if str14 then
		var5.PlayerRemoving:Connect(function(arg1)
			var3:OnPlayerRemoving(arg1)
		end)

	end

	var3.activeTransparencyController:Enable(true)
	var3.activeMouseLockController = str11.new()
	assert(var3.activeMouseLockController, "Strict typing check")
	tbl4 = var3.activeMouseLockController:GetBindableToggleEvent()
	if tbl4 then
		tbl4:Connect(function()
			var3:OnMouseLockToggled()
		end)

	end

	var3:ActivateCameraController()
	var3:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
	var3:OnCurrentCameraChanged()
	local function fn2(arg1)
		var3:Update(arg1)
	end

	var6:BindToRenderStep("cameraRenderUpdate", Enum.RenderPriority.Camera.Value, fn2)
	for k2, v2 in pairs(tbl2) do
		var5.LocalPlayer:GetPropertyChangedSignal(v2):Connect(function()
			var3:OnLocalPlayerCameraPropertyChanged(v2)
		end)

	end

	for k3, v3 in pairs(tbl3) do
		var9:GetPropertyChangedSignal(v3):Connect(function()
			var3:OnUserGameSettingsPropertyChanged(v3)
		end)

	end

	game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		var3:OnCurrentCameraChanged()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var3:OnPreferredInputChanged()
	end)

	return var3
end

tbl1.GetCameraMovementModeFromSettings = function(_)
	if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		local var2 = Enum.ComputerCameraMovementMode.Classic
		return var4.ConvertCameraModeEnumToStandard(var2)
	end

	local var8 = nil
	local var10 = nil
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevTouchCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.TouchCameraMovementMode)
	else
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevComputerCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.ComputerCameraMovementMode)
	end

	if var8 == Enum.DevComputerCameraMovementMode.UserChoice then
		return var10
	end

	return var8
end

tbl1.ActivateOcclusionModule = function(arg1, arg2)
	local var2 = nil
	if arg2 == Enum.DevCameraOcclusionMode.Zoom then
		var2 = str9
	else
		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			var2 = str8
		else
			warn("CameraScript ActivateOcclusionModule called with unsupported mode")
			return
		end
	end

	arg1.occlusionMode = arg2
	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() == arg2 then
			if not arg1.activeOcclusionModule:GetEnabled() then
				arg1.activeOcclusionModule:Enable(true)
			end

			return
		end
	end

	local var3 = arg1.activeOcclusionModule
	arg1.activeOcclusionModule = str13[var2]
	if not arg1.activeOcclusionModule then
		arg1.activeOcclusionModule = var2.new()
		if arg1.activeOcclusionModule then
			str13[var2] = arg1.activeOcclusionModule
		end
	end

	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() ~= arg2 then
			warn("CameraScript ActivateOcclusionModule mismatch: ", arg1.activeOcclusionModule:GetOcclusionMode(), "~=", arg2)
		end

		if var3 then
			if var3 ~= arg1.activeOcclusionModule then
				var3:Enable(false)
			else
				warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
			end
		end

		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			if var5.LocalPlayer.Character then
				arg1.activeOcclusionModule:CharacterAdded(var5.LocalPlayer.Character, var5.LocalPlayer)
			end
		else
			for k1, v1 in pairs(var5:GetPlayers()) do
				if not v1 then
					continue
				end

				if not v1.Character then
					continue
				end

				arg1.activeOcclusionModule:CharacterAdded(v1.Character, v1)
			end

			arg1.activeOcclusionModule:OnCameraSubjectChanged(game.Workspace.CurrentCamera.CameraSubject)
		end

		arg1.activeOcclusionModule:Enable(true)
	end
end

tbl1.ShouldUseVehicleCamera = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return false
	end

	local var4 = var2.CameraType
	local var5 = var2.CameraSubject
	local bool1 = true
	if var4 ~= Enum.CameraType.Custom then
		bool1 = var4 == Enum.CameraType.Follow
	end

	local var6 = var5 and var5:IsA("VehicleSeat")
	return var6 and (bool1 and arg1.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam)
end

tbl1.ActivateCameraController = function(arg1)
	local var2 = workspace.CurrentCamera.CameraType
	local var3 = arg1:GetCameraMovementModeFromSettings()
	local var4 = nil
	if var2 == Enum.CameraType.Scriptable then
		if arg1.activeCameraController then
			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = nil
		end

		return
	end

	if var2 == Enum.CameraType.Custom then
		var3 = arg1:GetCameraMovementModeFromSettings()
	else
		if var2 == Enum.CameraType.Track then
			var3 = Enum.ComputerCameraMovementMode.Classic
		else
			if var2 == Enum.CameraType.Follow then
				var3 = Enum.ComputerCameraMovementMode.Follow
			else
				if var2 == Enum.CameraType.Orbital then
					var3 = Enum.ComputerCameraMovementMode.Orbital
				else
					if var2 == Enum.CameraType.Attach or (var2 == Enum.CameraType.Watch or var2 == Enum.CameraType.Fixed) then
						var4 = str4
					else
						warn("CameraScript encountered an unhandled Camera.CameraType value: ", var2)
					end
				end
			end
		end
	end

	if not var4 then
		if var8.VREnabled then
			var4 = str6
		else
			if var3 == Enum.ComputerCameraMovementMode.Classic or (var3 == Enum.ComputerCameraMovementMode.Follow or (var3 == Enum.ComputerCameraMovementMode.Default or var3 == Enum.ComputerCameraMovementMode.CameraToggle)) then
				var4 = str2
			else
				if var3 == Enum.ComputerCameraMovementMode.Orbital then
					var4 = str3
				else
					warn("ActivateCameraController did not select a module.")
					return
				end
			end
		end
	end

	if arg1:ShouldUseVehicleCamera() then
		var4 = if var8.VREnabled then str7 else str5
	end

	local var6 = nil
	if not str12[var4] then
		var6 = var4.new()
		str12[var4] = var6
	else
		var6 = str12[var4]
		if var10 then
			if var6.Reset and arg1.activeCameraController ~= var6 then
				var6:Reset()
			end
		else
			if var6.Reset then
				var6:Reset()
			end
		end
	end

	if arg1.activeCameraController then
		if arg1.activeCameraController ~= var6 then
			if var6.HandleSubjectDistance then
				var6:HandleSubjectDistance(arg1.activeCameraController)
			end

			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = var6
			arg1.activeCameraController:Enable(true)
		else
			if not arg1.activeCameraController:GetEnabled() then
				arg1.activeCameraController:Enable(true)
			end
		end
	elseif var6 ~= nil then
		arg1.activeCameraController = var6
		assert(arg1.activeCameraController, "Strict typing check")
		arg1.activeCameraController:Enable(true)
	end

	if arg1.activeCameraController then
		arg1.activeCameraController:SetCameraMovementMode(var3)
		arg1.activeCameraController:SetCameraType(var2)
	end
end

tbl1.OnCameraSubjectChanged = function(arg1)
	local var2 = workspace.CurrentCamera
	local var4 = if var2 then var2.CameraSubject else nil
	if arg1.activeTransparencyController then
		arg1.activeTransparencyController:SetSubject(var4)
	end

	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:OnCameraSubjectChanged(var4)
	end

	arg1:ActivateCameraController()
end

tbl1.OnCameraTypeChanged = function(arg1, arg2)
	if arg2 == Enum.CameraType.Scriptable and var7.MouseBehavior == Enum.MouseBehavior.LockCenter then
		var4.restoreMouseBehavior()
	end

	arg1:ActivateCameraController()
end

tbl1.OnCurrentCameraChanged = function(arg1)
	local var2 = game.Workspace.CurrentCamera
	if not var2 then
		return
	end

	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
	end

	if arg1.cameraTypeChangedConn then
		arg1.cameraTypeChangedConn:Disconnect()
	end

	arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		arg1:OnCameraSubjectChanged()
	end)

	arg1.cameraTypeChangedConn = var2:GetPropertyChangedSignal("CameraType"):Connect(function()
		arg1:OnCameraTypeChanged(var2.CameraType)
	end)

	arg1:OnCameraSubjectChanged()
	arg1:OnCameraTypeChanged(var2.CameraType)
end

tbl1.OnLocalPlayerCameraPropertyChanged = function(arg1, arg2)
	if arg2 == "CameraMode" then
		if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			if not arg1.activeCameraController or arg1.activeCameraController:GetModuleName() ~= "ClassicCamera" then
				arg1:ActivateCameraController()
			end

			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end

		if var5.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
			arg1:ActivateCameraController()
			return
		end

		warn("Unhandled value for property player.CameraMode: ", var5.LocalPlayer.CameraMode)
		return
	end

	if arg2 == "DevComputerCameraMode" or arg2 == "DevTouchCameraMode" then
		arg1:ActivateCameraController()
		return
	end

	if arg2 == "DevCameraOcclusionMode" then
		arg1:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
		return
	end

	if arg2 ~= "CameraMinZoomDistance" then
		if arg2 == "CameraMaxZoomDistance" then
			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end
	end

	if arg2 == "DevTouchMovementMode" then
		return
	end

	if arg2 == "DevComputerMovementMode" then
		return
	end

	if arg2 == "DevEnableMouseLock" then
	end
end

tbl1.OnUserGameSettingsPropertyChanged = function(arg1, arg2)
	if arg2 == "ComputerCameraMovementMode" or arg2 == "TouchCameraMovementMode" then
		arg1:ActivateCameraController()
	end
end

tbl1.OnPreferredInputChanged = function(arg1)
	arg1:ActivateCameraController()
end

tbl1.Update = function(arg1, arg2)
	if arg1.activeCameraController then
		arg1.activeCameraController:UpdateMouseBehavior()
		local var5, var6 = arg1.activeCameraController:Update(arg2)
		if arg1.activeOcclusionModule and (not arg1.activeCameraController.skipOcclusion) then
			local var7, var8 = arg1.activeOcclusionModule:Update(arg2, var5, var6)
			var5 = var7
			var6 = var8
		end

		local var9 = game.Workspace.CurrentCamera
		var9.CFrame = var5
		var9.Focus = var6
		if arg1.activeTransparencyController then
			arg1.activeTransparencyController:Update(arg2)
		end

		if str1.getInputEnabled() then
			str1.resetInputForFrameEnd()
		end
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterAdded(arg2, arg3)
	end
end

tbl1.OnCharacterRemoving = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterRemoving(arg2, arg3)
	end
end

tbl1.OnPlayerAdded = function(arg1, arg2)
	if str14 then
		if not arg1.connectionUtil then
			return
		end

		local function fn6(arg1)
			arg1:OnCharacterAdded(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterAdded"):format(arg2.UserId), arg2.CharacterAdded:Connect(fn6))
		fn6 = function(arg1)
			arg1:OnCharacterRemoving(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterRemoving"):format(arg2.UserId), arg2.CharacterRemoving:Connect(fn6))
		return
	end

	arg2.CharacterAdded:Connect(function(arg1)
		arg1:OnCharacterAdded(arg1, arg2)
	end)

	arg2.CharacterRemoving:Connect(function(arg1)
		arg1:OnCharacterRemoving(arg1, arg2)
	end)
end

tbl1.OnPlayerRemoving = function(arg1, arg2)
	if arg1.connectionUtil then
		arg1.connectionUtil:disconnect((("%*CharacterAdded"):format(arg2.UserId)))
		arg1.connectionUtil:disconnect((("%*CharacterRemoving"):format(arg2.UserId)))
	end
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = arg1.activeMouseLockController:GetIsMouseLocked()
	local var2 = arg1.activeMouseLockController:GetMouseLockOffset()
	if arg1.activeMouseLockController and arg1.activeCameraController then
		arg1.activeCameraController:SetIsMouseLocked(var1)
		arg1.activeCameraController:SetMouseLockOffset(var2)
	end
end

tbl1.new()
return {}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ClassicCamera [ModuleScript]
-- y u r i

Vector2.new(0, 0)
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixCameraFPError")
local str2 = "CameraInput"
local str3 = "CameraUtils"
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = CFrame.fromOrientation(-0.26179938779914941, 0, 0)
local var5 = game:GetService("Players")
str2 = setmetatable({}, var3)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(var3.new(), str2)
	var1.isFollowCamera = false
	var1.isCameraToggle = false
	var1.lastUpdate = tick()
	var1.cameraToggleSpring = var2.Spring.new(5, 0)
	return var1
end

str2.GetCameraToggleOffset = function(arg1, arg2)
	if arg1.isCameraToggle then
		local var4 = arg1.currentSubjectDistance
		if str1.getTogglePan() then
			arg1.cameraToggleSpring.goal = math.clamp(var2.map(var4, 0.5, arg1.FIRST_PERSON_DISTANCE_THRESHOLD, 0, 1), 0, 1)
		else
			arg1.cameraToggleSpring.goal = 0
		end

		return (Vector3.new(0, arg1.cameraToggleSpring:step(arg2) * (math.clamp(var2.map(var4, 0.5, 64, 0, 1), 0, 1) + 1), 0))
	end

	return (Vector3.new())
end

str2.SetCameraMovementMode = function(arg1, arg2)
	var3.SetCameraMovementMode(arg1, arg2)
	arg1.isFollowCamera = arg2 == Enum.ComputerCameraMovementMode.Follow
	arg1.isCameraToggle = arg2 == Enum.ComputerCameraMovementMode.CameraToggle
end

local num1 = 0
str2.Update = function(arg1, arg2)
	local var3 = workspace.CurrentCamera
	local var8 = tick()
	local var9 = var3.CFrame
	local var10 = var3.Focus
	local var11 = nil
	if arg1.resetCameraAngle then
		local var13 = arg1:GetHumanoidRootPart()
		arg1.resetCameraAngle = false
		var11 = if var13 then (var13.CFrame * var4).lookVector else var4.lookVector
	end

	local var14 = var3.CameraSubject
	local var15 = var14
	local var16 = var14
	local var17 = arg1:GetHumanoid()
	local var19 = var17
	local var20 = var5.LocalPlayer
	var15 = var15 and var14:IsA("VehicleSeat")
	var16 = var16 and var14:IsA("SkateboardPlatform")
	if var19 then
		var19 = var17:GetState() == Enum.HumanoidStateType.Climbing
	end

	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:StepZoom()
	local var22 = str1.getRotation(arg2)
	local var23 = arg1:GetCameraHeight()
	if var22 ~= Vector2.new() then
		num1 = 0
		arg1.lastUserPanCamera = tick()
	end

	local var26 = arg1:GetSubjectPosition()
	local var27 = var8 - arg1.lastUserPanCamera < 2
	if var26 then
		if var20 then
			if var3 then
				local var31 = arg1:GetCameraToSubjectDistance()
				if var31 < 0.5 then
					var31 = 0.5
				end

				if arg1:GetIsMouseLocked() then
					if not arg1:IsInFirstPerson() then
						local var32 = arg1:CalculateNewLookCFrameFromArg(var11, var22)
						local var33 = arg1:GetMouseLockOffset()
						if var17 then
							var33 = var33 + var17.CameraOffset
						end

						local var34 = var33.X * var32.RightVector + var33.Y * var32.UpVector + var33.Z * var32.LookVector
						if var2.IsFiniteVector3(var34) then
							var26 = var26 + var34
						end
					else
						if not (var22 ~= Vector2.new()) then
							if arg1.lastCameraTransform then
								local var37 = arg1:IsInFirstPerson()
								if not var15 then
									if var16 or arg1.isFollowCamera and var19 then
										if arg1.lastUpdate then
											if var17 then
												if var17.Torso then
													if var37 then
														if arg1.lastSubjectCFrame then
															if not var15 then
																if var16 then
																	if var14:IsA("BasePart") then
																		local var47 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																		if var2.IsFinite(var47) then
																			var22 = var22 + Vector2.new(var47, 0)
																		end

																		num1 = 0
																	end
																end
															end
														end
													elseif not var27 then
														local var48 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
														num1 = var48
														local var49 = var17.Torso.CFrame.lookVector
														var48 = math.clamp(num1 * arg2, 0, 1)
														if arg1:IsInFirstPerson() then
															var48 = arg1.isFollowCamera and arg1.isClimbing or 1
														end

														local var50 = var2.GetAngleBetweenXZVectors(var49, arg1:GetCameraLookVector())
														if var2.IsFinite(var50) and 0.0001 < math.abs(var50) then
															var22 = var22 + Vector2.new(var50 * var48, 0)
														end
													end
												else
													local var52 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
													if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var52) and (0.0001 < math.abs(var52) and 0.4 * arg2 < math.abs(var52))))) then
														var22 = var22 + Vector2.new(var52, 0)
													end
												end
											else
												local var54 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var54) and (0.0001 < math.abs(var54) and 0.4 * arg2 < math.abs(var54))))) then
													var22 = var22 + Vector2.new(var54, 0)
												end
											end
										else
											local var56 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var56) and (0.0001 < math.abs(var56) and 0.4 * arg2 < math.abs(var56))))) then
												var22 = var22 + Vector2.new(var56, 0)
											end
										end
									else
										local var58 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var58) and (0.0001 < math.abs(var58) and 0.4 * arg2 < math.abs(var58))))) then
											var22 = var22 + Vector2.new(var58, 0)
										end
									end
								end
							end
						end
					end
				else
					if not (var22 ~= Vector2.new()) then
						if arg1.lastCameraTransform then
							local var61 = arg1:IsInFirstPerson()
							if not var15 then
								if var16 or arg1.isFollowCamera and var19 then
									if arg1.lastUpdate then
										if var17 then
											if var17.Torso then
												if var61 then
													if arg1.lastSubjectCFrame then
														if not var15 then
															if var16 then
																if var14:IsA("BasePart") then
																	local var71 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																	if var2.IsFinite(var71) then
																		var22 = var22 + Vector2.new(var71, 0)
																	end

																	num1 = 0
																end
															end
														end
													end
												elseif not var27 then
													local var72 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
													num1 = var72
													local var73 = var17.Torso.CFrame.lookVector
													var72 = math.clamp(num1 * arg2, 0, 1)
													if arg1:IsInFirstPerson() then
														var72 = arg1.isFollowCamera and arg1.isClimbing or 1
													end

													local var74 = var2.GetAngleBetweenXZVectors(var73, arg1:GetCameraLookVector())
													if var2.IsFinite(var74) and 0.0001 < math.abs(var74) then
														var22 = var22 + Vector2.new(var74 * var72, 0)
													end
												end
											else
												local var76 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var76) and (0.0001 < math.abs(var76) and 0.4 * arg2 < math.abs(var76))))) then
													var22 = var22 + Vector2.new(var76, 0)
												end
											end
										else
											local var78 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var78) and (0.0001 < math.abs(var78) and 0.4 * arg2 < math.abs(var78))))) then
												var22 = var22 + Vector2.new(var78, 0)
											end
										end
									else
										local var80 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var80) and (0.0001 < math.abs(var80) and 0.4 * arg2 < math.abs(var80))))) then
											var22 = var22 + Vector2.new(var80, 0)
										end
									end
								else
									local var82 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
									if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var82) and (0.0001 < math.abs(var82) and 0.4 * arg2 < math.abs(var82))))) then
										var22 = var22 + Vector2.new(var82, 0)
									end
								end
							end
						end
					end
				end

				if not arg1.isFollowCamera then
					var10 = CFrame.new(var26)
					local var87 = var10.p
					local var88 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					if var1 then
						var9 = CFrame.lookAlong(var87 - var31 * var88, var88)
					else
						var9 = CFrame.new(var87 - var31 * var88, var87)
					end
				else
					var10 = CFrame.new(var26)
					local var90 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					var9 = if var1 then CFrame.lookAlong(var10.p - var31 * var90, var90) else CFrame.new(var10.p - var31 * var90, var10.p) + Vector3.new(0, var23, 0)
				end

				local var91 = arg1:GetCameraToggleOffset(arg2)
				var9 = var9 + var91
				arg1.lastCameraTransform = var9
				var10 = var10 + var91
				arg1.lastCameraFocus = var10
				if (var15 or var16) and var14:IsA("BasePart") then
					arg1.lastSubjectCFrame = var14.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var8
	return var9, var10
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUtils [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("UserInputService")
local var3 = UserSettings():GetService("UserGameSettings")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	return (setmetatable({ freq = arg1, goal = arg2, pos = arg2, vel = 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = arg1.pos - var1
	local var4 = arg1.vel
	local var5 = math.exp(-var2 * arg2)
	local var6 = (var3 * (var2 * arg2 + 1) + var4 * arg2) * var5 + var1
	arg1.pos = var6
	arg1.vel = (var4 * (1 - var2 * arg2) - var3 * (var2 * var2 * arg2)) * var5
	return var6
end

local tbl2 = {
	Spring = tbl1,
	map = function(arg1, arg2, arg3, arg4, arg5)
		return (arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4
	end,
	mapClamp = function(arg1, arg2, arg3, arg4, arg5)
		return (math.clamp((arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4, math.min(arg4, arg5), (math.max(arg4, arg5))))
	end,
	getLooseBoundingSphere = function(arg1)
		local var1 = table.create(#arg1)
		for k1, v1 in pairs(arg1) do
			var1[k1] = v1.Position
		end

		local var2 = var1[1]
		local var3 = var2
		local num1 = 0
		for k2, v2 in ipairs(var1) do
			local var4 = (v2 - var2).Magnitude
			if num1 >= var4 then
				continue
			end

			var3 = v2
			local var5 = var4
		end

		local var6 = var3
		local num2 = 0
		for k3, v3 in ipairs(var1) do
			local var7 = (v3 - var3).Magnitude
			if num2 >= var7 then
				continue
			end

			var6 = v3
			local var8 = var7
		end

		local var9 = (var3 + var6) * 0.5
		local var10 = (var3 - var6).Magnitude * 0.5
		for k4, v4 in ipairs(var1) do
			local var11 = (v4 - var9).Magnitude
			if var10 >= var11 then
				continue
			end

			var9 = var9 + (var11 - var10) * 0.5 * (v4 - var9).Unit
			var10 = (var11 + var10) * 0.5
		end

		return var9, var10
	end,
	sanitizeAngle = function(arg1)
		return (arg1 + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
	end,
	Round = function(arg1, arg2)
		local var1 = 10 ^ arg2
		return math.floor(arg1 * var1 + 0.5) / var1
	end,
	IsFinite = function(arg1)
		local bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end

		return bool2
	end,
}

tbl2.IsFiniteVector3 = function(arg1)
	local var1 = tbl2.IsFinite(arg1.X)
	return var1 and (tbl2.IsFinite(arg1.Y) and tbl2.IsFinite(arg1.Z))
end

tbl2.GetAngleBetweenXZVectors = function(arg1, arg2)
	return (math.atan2(arg2.X * arg1.Z - arg2.Z * arg1.X, arg2.X * arg1.X + arg2.Z * arg1.Z))
end

tbl2.RotateVectorByAngleAndRound = function(arg1, arg2, arg3)
	if 0 < arg1.Magnitude then
		arg1 = arg1.Unit
		return math.floor((math.atan2(arg1.Z, arg1.X) + arg2) / arg3 + 0.5) * arg3 - math.atan2(arg1.Z, arg1.X)
	end

	return 0
end

tbl2.GamepadLinearToCurve = function(arg1)
	local var2 = arg1.X
	local var3 = Vector2.new
	local num2 = 1
	if var2 < 0 then
		num2 = -1
	end

	local var5 = math.clamp((math.abs((math.abs(var2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	local var6 = math.clamp(((if 0 <= var5 then var5 * 0.35 / (0.35 - var5 + 1) else -(-var5 * 0.8 / (var5 + 0.8 + 1))) / 2 + 0.5) * num2, -1, 1)
	num2 = arg1.Y
	local num4 = 1
	if num2 < 0 then
		num4 = -1
	end

	local var8 = math.clamp((math.abs((math.abs(num2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	var2 = math.clamp(((if 0 <= var8 then var8 * 0.35 / (0.35 - var8 + 1) else -(-var8 * 0.8 / (var8 + 0.8 + 1))) / 2 + 0.5) * num4, -1, 1)
	return var3(var6, var2)
end

tbl2.ConvertCameraModeEnumToStandard = function(arg1)
	if arg1 == Enum.TouchCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.ComputerCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Classic or (arg1 == Enum.DevTouchCameraMovementMode.Classic or (arg1 == Enum.DevComputerCameraMovementMode.Classic or arg1 == Enum.ComputerCameraMovementMode.Classic)) then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Follow or (arg1 == Enum.DevTouchCameraMovementMode.Follow or (arg1 == Enum.DevComputerCameraMovementMode.Follow or arg1 == Enum.ComputerCameraMovementMode.Follow)) then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.TouchCameraMovementMode.Orbital or (arg1 == Enum.DevTouchCameraMovementMode.Orbital or (arg1 == Enum.DevComputerCameraMovementMode.Orbital or arg1 == Enum.ComputerCameraMovementMode.Orbital)) then
		return Enum.ComputerCameraMovementMode.Orbital
	end

	if arg1 == Enum.ComputerCameraMovementMode.CameraToggle or arg1 == Enum.DevComputerCameraMovementMode.CameraToggle then
		return Enum.ComputerCameraMovementMode.CameraToggle
	end

	if arg1 == Enum.DevTouchCameraMovementMode.UserChoice or arg1 == Enum.DevComputerCameraMovementMode.UserChoice then
		return Enum.DevComputerCameraMovementMode.UserChoice
	end

	return Enum.ComputerCameraMovementMode.Classic
end

local var4 = nil
local str1 = ""
tbl2.setMouseIconOverride = function(arg1)
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon ~= var4 then
		str1 = var5.Icon
	end

	var5.Icon = arg1
	var4 = arg1
end

tbl2.restoreMouseIcon = function()
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon == var4 then
		var5.Icon = str1
	end

	var4 = nil
end

local var5 = nil
local var6 = Enum.MouseBehavior.Default
tbl2.setMouseBehaviorOverride = function(arg1)
	if var2.MouseBehavior ~= var5 then
		var6 = var2.MouseBehavior
	end

	var2.MouseBehavior = arg1
	var5 = arg1
end

tbl2.restoreMouseBehavior = function()
	if var2.MouseBehavior == var5 then
		var2.MouseBehavior = var6
	end

	var5 = nil
end

local var7 = nil
local var8 = Enum.RotationType.MovementRelative
tbl2.setRotationTypeOverride = function(arg1)
	if var3.RotationType ~= var7 then
		var8 = var3.RotationType
	end

	var3.RotationType = arg1
	var7 = arg1
end

tbl2.restoreRotationType = function()
	if var3.RotationType == var7 then
		var3.RotationType = var8
	end

	var7 = nil
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController [ModuleScript]
-- y u r i

game:GetService("Players")
game:GetService("UserInputService")
UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
local str2 = "CameraUI"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local var3 = require(script.Parent:WaitForChild(str3))
var2.setCameraModeToastEnabled(false)
str1 = false
str3 = false
str2 = tick()
local bool1 = false
local bool2 = false
return function(arg1)
	local var5 = var1.getTogglePan()
	if arg1 and var5 ~= str1 then
		str3 = true
	end

	if str1 == var5 then
		if 3 < tick() - str2 then
			local var7 = var5
			if var7 then
				var7 = tick() - str2 < 3
			end

			var2.setCameraModeToastOpen(var7)
			if var5 then
				str3 = false
			end

			str2 = tick()
			str1 = var5
		end
	end

	if arg1 ~= bool1 then
		if arg1 then
			bool2 = var1.getTogglePan()
			var1.setTogglePan(true)
		else
			if not str3 then
				var1.setTogglePan(bool2)
			end
		end
	end

	if arg1 then
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		else
			var3.restoreMouseIcon()
			var3.restoreMouseBehavior()
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		end
	else
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
		else
			if var1.getHoldPan() then
				var3.restoreMouseIcon()
				var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
				var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
			else
				var3.restoreMouseIcon()
				var3.restoreMouseBehavior()
				var3.restoreRotationType()
			end
		end
	end

	bool1 = arg1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector [ModuleScript]
-- y u r i

local tbl1 = { JUMP_STUDS = 4, SETTLED_STUDS = 1, DEBOUNCE_SECONDS = 0.25 }
tbl1.shouldRecenter = function(arg1, arg2, arg3, arg4)
	if arg2 <= tbl1.JUMP_STUDS then
		return false
	end

	if arg1 ~= nil and tbl1.SETTLED_STUDS <= arg1 then
		return false
	end

	if arg3 ~= nil and arg4 - arg3 < tbl1.DEBOUNCE_SECONDS then
		return false
	end

	return true
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera [ModuleScript]
-- y u r i

local str1 = "CameraInput"
local str2 = "ZoomController"
local var1 = require(script.Parent:WaitForChild(str2))
local var2 = require(script.Parent:WaitForChild(str1))
local str3 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str3)).getUserFlag("UserVRRemoveLuaEdgeBlur")
local str4 = "BaseCamera"
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = game:GetService("VRService")
local var5 = game:GetService("Players").LocalPlayer
local var6 = game:GetService("Lighting")
local var7 = game:GetService("RunService")
local var8 = UserSettings():GetService("UserGameSettings")
str3 = setmetatable({}, var3)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(var3.new(), str3)
	var1.gamepadZoomLevels = { 0, 7 }
	var1.headScale = 1
	var1:SetCameraToSubjectDistance(7)
	var1.VRFadeResetTimer = 0
	var1.VREdgeBlurTimer = 0
	var1.gamepadResetConnection = nil
	var1.needsReset = true
	var1.recentered = false
	var1:Reset()
	return var1
end

str3.Reset = function(arg1)
	arg1.stepRotateTimeout = 0
end

str3.GetModuleName = function(_)
	return "VRBaseCamera"
end

str3.GamepadZoomPress = function(arg1)
	var3.GamepadZoomPress(arg1)
	arg1:GamepadReset()
	arg1:ResetZoom()
end

str3.GamepadReset = function(arg1)
	arg1.stepRotateTimeout = 0
	arg1.needsReset = true
end

str3.ResetZoom = function(arg1)
	var1.SetZoomParameters(arg1.currentSubjectDistance, 0)
	var1.ReleaseSpring()
end

str3.OnEnabledChanged = function(arg1)
	var3.OnEnabledChanged(arg1)
	if arg1.enabled then
		arg1.gamepadResetConnection = var2.gamepadReset:Connect(function()
			arg1:GamepadReset()
		end)

		arg1.thirdPersonOptionChanged = var4:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function()
			arg1:Reset()
		end)

		arg1.vrRecentered = var4.UserCFrameChanged:Connect(function(arg1, _)
			if arg1 == Enum.UserCFrame.Floor then
				arg1.recentered = true
			end
		end)

		return
	end

	if arg1.inFirstPerson then
		arg1:GamepadZoomPress()
	end

	if arg1.thirdPersonOptionChanged then
		arg1.thirdPersonOptionChanged:Disconnect()
		arg1.thirdPersonOptionChanged = nil
	end

	if arg1.vrRecentered then
		arg1.vrRecentered:Disconnect()
		arg1.vrRecentered = nil
	end

	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	if arg1.gamepadResetConnection then
		arg1.gamepadResetConnection:Disconnect()
		arg1.gamepadResetConnection = nil
	end

	if not str2 then
		arg1.VREdgeBlurTimer = 0
		arg1:UpdateEdgeBlur(var5, 1)
	end

	local var7 = var6:FindFirstChild("VRFade")
	if var7 then
		var7.Brightness = 0
	end
end

str3.OnCurrentCameraChanged = function(arg1)
	var3.OnCurrentCameraChanged(arg1)
	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	local var2 = workspace.CurrentCamera
	if var2 then
		arg1.cameraHeadScaleChangedConn = var2:GetPropertyChangedSignal("HeadScale"):Connect(function()
			arg1:OnHeadScaleChanged()
		end)

		arg1:OnHeadScaleChanged()
	end
end

str3.OnHeadScaleChanged = function(arg1)
	local var1 = workspace.CurrentCamera.HeadScale
	for k1, v1 in arg1.gamepadZoomLevels, nil do
		arg1.gamepadZoomLevels[k1] = v1 * var1 / arg1.headScale
	end

	arg1:SetCameraToSubjectDistance(arg1:GetCameraToSubjectDistance() * var1 / arg1.headScale)
	arg1.headScale = var1
end

str3.GetVRFocus = function(arg1, arg2, arg3)
	local var1 = Vector3.new(arg1.cameraTranslationConstraints.x, math.min(1, arg1.cameraTranslationConstraints.y + arg3), arg1.cameraTranslationConstraints.z)
	arg1.cameraTranslationConstraints = var1
	local var2 = arg2 + Vector3.new(0, arg1:GetCameraHeight(), 0)
	local var3 = arg1.cameraTranslationConstraints.y
	return (CFrame.new(Vector3.new(arg2.x, (arg1.lastCameraFocus or arg2).y, arg2.z):Lerp(var2, var3)))
end

str3.StartFadeFromBlack = function(arg1)
	if var8.VignetteEnabled == false then
		return
	end

	local var2 = var6:FindFirstChild("VRFade")
	if not var2 then
		var2 = Instance.new("ColorCorrectionEffect")
		var2.Name = "VRFade"
		var2.Parent = var6
	end

	var2.Brightness = -1
	arg1.VRFadeResetTimer = 0.1
end

str3.UpdateFadeFromBlack = function(arg1, arg2)
	local var1 = var6:FindFirstChild("VRFade")
	if 0 < arg1.VRFadeResetTimer then
		local var2 = math.max(arg1.VRFadeResetTimer - arg2, 0)
		arg1.VRFadeResetTimer = var2
		var2 = var6:FindFirstChild("VRFade")
		if not (var2 and var2.Brightness < 0) then
			return
		end

		if var2.Brightness >= 0 then
			return
		end

		local var3 = math.min(var2.Brightness + arg2 * 10, 0)
		var2.Brightness = var3
		return
	end

	if var1 then
		var1.Brightness = 0
	end
end

str3.StartVREdgeBlur = function(arg1, arg2, arg3)
	if not arg3 and var8.VignetteEnabled == false then
		return
	end

	local var1 = nil
	var1 = workspace.CurrentCamera:FindFirstChild("VRBlurPart")
	if not var1 then
		var1 = Instance.new("Part")
		var1.Name = "VRBlurPart"
		var1.Parent = workspace.CurrentCamera
		var1.CanTouch = false
		var1.CanCollide = false
		var1.CanQuery = false
		var1.Anchored = true
		var1.Size = Vector3.new(0.44, 0.47, 1)
		var1.Transparency = 1
		var1.CastShadow = false
		var7.RenderStepped:Connect(function(_)
			local var2 = var4:GetUserCFrame(Enum.UserCFrame.Head)
			local var3 = workspace.CurrentCamera.CFrame * (CFrame.new(var2.p * workspace.CurrentCamera.HeadScale) * (var2 - var2.p))
			var1.CFrame = var3 * CFrame.Angles(0, 3.1415926535897931, 0) + var3.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
			var1.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
		end)

	end

	local var2 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var3 = nil
	var3 = var2 and var2:FindFirstChild("VRBlur")
	if not var3 then
		var2 = var2 or Instance.new("ScreenGui")
		var2.Name = "VRBlurScreen"
		var2.Parent = arg2.PlayerGui
		var2.Adornee = var1
		var3 = Instance.new("ImageLabel")
		var3.Name = "VRBlur"
		var3.Parent = var2
		var3.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
		var3.AnchorPoint = Vector2.new(0.5, 0.5)
		var3.Position = UDim2.new(0.5, 0, 0.5, 0)
		var3.Size = UDim2.fromScale(workspace.CurrentCamera.ViewportSize.X * 2.3 / 512, workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512)
		var3.BackgroundTransparency = 1
		var3.Active = true
		var3.ScaleType = Enum.ScaleType.Stretch
	end

	var3.Visible = true
	var3.ImageTransparency = 0
	arg1.VREdgeBlurTimer = 0.14
end

str3.UpdateEdgeBlur = function(arg1, arg2, arg3)
	local var3 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var4 = nil
	if var3 then
		var4 = var3:FindFirstChild("VRBlur")
	end

	if var4 then
		if 0 < arg1.VREdgeBlurTimer then
			local var5 = arg1.VREdgeBlurTimer - arg3
			arg1.VREdgeBlurTimer = var5
			var5 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
			local var6 = var5:FindFirstChild("VRBlur")
			if not (var5 and var6) then
				return
			end

			var6 = var5:FindFirstChild("VRBlur")
			if not var6 then
				return
			end

			var6.ImageTransparency = 1 - math.clamp(arg1.VREdgeBlurTimer, 0.01, 0.14) * 7.1428571428571423
			return
		end

		var4.Visible = false
	end
end

str3.GetCameraHeight = function(arg1)
	if not arg1.inFirstPerson then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

str3.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectCFrame(arg1)
	if not var2 then
		return var4
	end

	if var2:IsA("Humanoid") then
		if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
			var4 = arg1.lastSubjectCFrame
		end
	end

	if var4 then
		arg1.lastSubjectCFrame = var4
	end

	return var4
end

str3.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectPosition(arg1)
	if var2 then
		if var2:IsA("Humanoid") then
			if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
				var4 = arg1.lastSubjectPosition
			end
		else
			if var2:IsA("VehicleSeat") then
				var4 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
			end
		end
	else
		return nil
	end

	arg1.lastSubjectPosition = var4
	return var4
end

str3.getRotation = function(arg1, arg2)
	local var3 = var2.getRotation(arg2)
	local num2 = 0
	if var8.VRSmoothRotationEnabled then
		return var3.X
	end

	if 0.03 < math.abs(var3.X) then
		if 0 < arg1.stepRotateTimeout then
			local var4 = arg1.stepRotateTimeout - arg2
			arg1.stepRotateTimeout = var4
		end

		if arg1.stepRotateTimeout <= 0 then
			num2 = 1
			if var3.X < 0 then
				num2 = -1
			end

			arg1:StartFadeFromBlack()
			arg1.stepRotateTimeout = 0.25
			num2 = num2 * 0.52359877559829882
			return num2
		end
	end

	if math.abs(var3.X) < 0.02 then
		arg1.stepRotateTimeout = 0
	end

	return num2
end

str3.HandleSubjectDistance = function(arg1, arg2)
	if arg2 and (arg2.IsInFirstPerson and arg2:IsInFirstPerson()) then
		arg1:SetCameraToSubjectDistance(0)
	end
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.LegacyCamera [ModuleScript]
-- y u r i

Vector2.new()
local str1 = "CameraUtils"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str2))
local str3 = "BaseCamera"
str1 = require(script.Parent:WaitForChild(str3))
local var2 = game:GetService("Players")
str2 = setmetatable({}, str1)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(str1.new(), str2)
	var1.cameraType = Enum.CameraType.Fixed
	var1.lastUpdate = tick()
	var1.lastDistanceToSubject = nil
	return var1
end

str2.GetModuleName = function(_)
	return "LegacyCamera"
end

str2.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return str1.SetCameraToSubjectDistance(var1, var2)
end

str2.Update = function(arg1, arg2)
	if not arg1.cameraType then
		return nil, nil
	end

	local var3 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4.CFrame
	local var6 = var4.Focus
	local var7 = var2.LocalPlayer
	local var8 = var1.getRotation(arg2)
	if arg1.lastUpdate == nil or 1 < var3 - arg1.lastUpdate then
		arg1.lastDistanceToSubject = nil
	end

	local var10 = arg1:GetSubjectPosition()
	if arg1.cameraType == Enum.CameraType.Fixed then
		if var10 and (var7 and var4) then
			var5 = CFrame.new(var4.CFrame.p, var4.CFrame.p + arg1:GetCameraToSubjectDistance() * arg1:CalculateNewLookVectorFromArg(nil, var8))
			var6 = var4.Focus
		end
	else
		if arg1.cameraType == Enum.CameraType.Attach then
			local var12 = arg1:GetSubjectCFrame()
			local var13, var14 = var12:ToEulerAnglesYXZ()
			var6 = CFrame.new(var12.p) * CFrame.fromEulerAnglesYXZ(math.clamp(var4.CFrame:ToEulerAnglesYXZ() - var8.Y, -1.3962634015954636, 1.3962634015954636), var14, 0)
			var5 = var6 * CFrame.new(0, 0, arg1:StepZoom())
		else
			if arg1.cameraType == Enum.CameraType.Watch then
				if var10 then
					if var7 then
						if var4 then
							local var15 = nil
							if var10 == var4.CFrame.p then
								warn("Camera cannot watch subject in same position as itself")
								return var4.CFrame, var4.Focus
							end

							local var18 = arg1:GetHumanoid()
							if var18 then
								if var18.RootPart then
									local var20 = var10 - var4.CFrame.p
									var15 = var20.unit
									if arg1.lastDistanceToSubject and arg1.lastDistanceToSubject == arg1:GetCameraToSubjectDistance() then
										arg1:SetCameraToSubjectDistance(var20.magnitude)
									end
								end
							end

							local var21 = arg1:GetCameraToSubjectDistance()
							var6 = CFrame.new(var10)
							var5 = CFrame.new(var10 - var21 * arg1:CalculateNewLookVectorFromArg(var15, var8), var10)
							arg1.lastDistanceToSubject = var21
						end
					end
				end
			else
				return var4.CFrame, var4.Focus
			end
		end
	end

	arg1.lastUpdate = var3
	return var5, var6
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.TransparencyController [ModuleScript]
-- y u r i

local str1 = "CameraUtils"
local var1 = game:GetService("VRService")
local var2 = require(script.Parent:WaitForChild(str1))
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.transparencyDirty = false
	var1.enabled = false
	var1.lastTransparency = nil
	var1.descendantAddedConn = nil
	var1.descendantRemovingConn = nil
	var1.toolDescendantAddedConns = {}
	var1.toolDescendantRemovingConns = {}
	var1.cachedParts = {}
	return var1
end

tbl1.HasToolAncestor = function(arg1, arg2)
	if arg2.Parent == nil then
		return false
	end

	assert(arg2.Parent, "")
	local var1 = arg2.Parent:IsA("Tool")
	return var1 or arg1:HasToolAncestor(arg2.Parent)
end

local tbl2 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion",
}

tbl1.IsValidPartToModify = function(arg1, arg2)
	for k1, v1 in tbl2, nil do
		if not arg2:IsA(v1) then
			continue
		end

		return not arg1:HasToolAncestor(arg2)
	end

	return false
end

tbl1.CachePartsRecursive = function(arg1, arg2)
	if arg2 then
		if arg1:IsValidPartToModify(arg2) then
			arg1.cachedParts[arg2] = true
			arg1.transparencyDirty = true
		end

		for k1, v1 in pairs(arg2:GetChildren()) do
			arg1:CachePartsRecursive(v1)
		end
	end
end

tbl1.TeardownTransparency = function(arg1)
	for k1, v1 in pairs(arg1.cachedParts) do
		k1.LocalTransparencyModifier = 0
	end

	arg1.cachedParts = {}
	arg1.transparencyDirty = true
	arg1.lastTransparency = nil
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
		arg1.descendantAddedConn = nil
	end

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
		arg1.descendantRemovingConn = nil
	end

	for k2, v2 in pairs(arg1.toolDescendantAddedConns) do
		v2:Disconnect()
		arg1.toolDescendantAddedConns[k2] = nil
	end

	for k3, v3 in pairs(arg1.toolDescendantRemovingConns) do
		v3:Disconnect()
		arg1.toolDescendantRemovingConns[k3] = nil
	end
end

tbl1.SetupTransparency = function(arg1, arg2)
	arg1:TeardownTransparency()
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
	end

	arg1.descendantAddedConn = arg2.DescendantAdded:Connect(function(arg1)
		if arg1:IsValidPartToModify(arg1) then
			arg1.cachedParts[arg1] = true
			arg1.transparencyDirty = true
			return
		end

		if arg1:IsA("Tool") then
			if arg1.toolDescendantAddedConns[arg1] then
				arg1.toolDescendantAddedConns[arg1]:Disconnect()
			end

			arg1.toolDescendantAddedConns[arg1] = arg1.DescendantAdded:Connect(function(arg1)
				arg1.cachedParts[arg1] = nil
				if arg1:IsA("BasePart") or arg1:IsA("Decal") then
					arg1.LocalTransparencyModifier = 0
				end
			end)

			if arg1.toolDescendantRemovingConns[arg1] then
				arg1.toolDescendantRemovingConns[arg1]:disconnect()
			end

			arg1.toolDescendantRemovingConns[arg1] = arg1.DescendantRemoving:Connect(function(arg1)
				wait()
				if arg2 and (arg1 and (arg1:IsDescendantOf(arg2) and arg1:IsValidPartToModify(arg1))) then
					arg1.cachedParts[arg1] = true
					arg1.transparencyDirty = true
				end
			end)

		end
	end)

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
	end

	arg1.descendantRemovingConn = arg2.DescendantRemoving:connect(function(arg1)
		if arg1.cachedParts[arg1] then
			arg1.cachedParts[arg1] = nil
			arg1.LocalTransparencyModifier = 0
		end
	end)

	arg1:CachePartsRecursive(arg2)
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
	end
end

tbl1.SetSubject = function(arg1, arg2)
	local var1 = nil
	var1 = arg2 and (arg2:IsA("Humanoid") and arg2.Parent)
	if arg2 then
		if arg2:IsA("VehicleSeat") and arg2.Occupant then
			var1 = arg2.Occupant.Parent
		end
	end

	if var1 then
		arg1:SetupTransparency(var1)
		return
	end

	arg1:TeardownTransparency()
end

tbl1.Update = function(arg1, arg2)
	local var6 = workspace.CurrentCamera
	if var6 then
		if arg1.enabled then
			local var9 = (var6.Focus.p - var6.CoordinateFrame.p).magnitude
			local var11 = var9 < 2 and 1 - (var9 - 0.5) / 1.5 or 0
			if var11 < 0.5 then
				var11 = 0
			end

			if arg1.lastTransparency and (var11 < 1 and arg1.lastTransparency < 0.95) then
				local var13 = 2.8 * arg2
				var11 = arg1.lastTransparency + math.clamp(var11 - arg1.lastTransparency, -var13, var13)
			else
				arg1.transparencyDirty = true
			end

			local num3 = 1
			var11 = math.clamp(var2.Round(var11, 2), 0, num3)
			if arg1.transparencyDirty or arg1.lastTransparency ~= var11 then
				for k1, v1 in pairs(arg1.cachedParts) do
					if var1.VREnabled and var1.AvatarGestures then
						if k1.Parent:IsA("Accessory") and ({
							[Enum.AccessoryType.Hat] = true,
							[Enum.AccessoryType.Hair] = true,
							[Enum.AccessoryType.Face] = true,
							[Enum.AccessoryType.Eyebrow] = true,
							[Enum.AccessoryType.Eyelash] = true,
						})[k1.Parent.AccessoryType] or k1.Name == "Head" then

							k1.LocalTransparencyModifier = var11
						else
							k1.LocalTransparencyModifier = 0
							continue
						end
					else
						k1.LocalTransparencyModifier = var11
					end
				end

				arg1.transparencyDirty = false
				arg1.lastTransparency = var11
			end
		end
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController [ModuleScript]
-- y u r i

local str1 = "Popper"
local var1 = require(script:WaitForChild(str1))
local var2 = game:GetService("Players").LocalPlayer
assert(var2)
local var3 = nil
local var4 = nil
local function updateBounds()
	var3 = var2.CameraMinZoomDistance
	var4 = var2.CameraMaxZoomDistance
end

var2:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(updateBounds)
var2:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(updateBounds)
var3 = var2.CameraMinZoomDistance
var4 = var2.CameraMaxZoomDistance
var2 = {}
var2.__index = var2
local var5 = math.clamp
var2.new = function(arg1, arg2, arg3, arg4)
	arg2 = var5(arg2, arg3, arg4)
	return (setmetatable({ freq = arg1, x = arg2, v = 0, minValue = arg3, maxValue = arg4, goal = arg2 }, var2))
end

local var6 = math.exp
var2.Step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = var2 * arg2
	local var4 = arg1.v
	local var5 = var1 - arg1.x
	local var7 = var6(-var3)
	local var11 = var1 + (var4 * arg2 - var5 * (var3 + 1)) * var7
	local var12 = arg1.minValue
	local var13 = arg1.maxValue
	local var14 = ((var5 * var2 - var4) * var3 + var4) * var7
	if var11 < var12 then
		var11 = var12
		var14 = 0
	elseif var13 < var11 then
		var11 = var13
		var14 = 0
	end

	arg1.x = var11
	arg1.v = var14
	return var11
end

updateBounds = var2.new(4.5, 12.5, 0.5, var4)
local num1 = 0
local var7 = math.max
str1 = math.min
return {
	Update = function(arg1, arg2, arg3)
		local num2 = math.huge
		if 1 < updateBounds.goal then
			local var8 = updateBounds.goal
			local var9 = num1
			local var10 = var3
			var8 = var5(var8 + var9 * (var8 * 0.0375 + 1), var10, var4)
			local var11 = updateBounds.x
			if var8 < 1 then
				var8 = var9 <= 0 and var10 or 1
			end

			local var12 = var7(var11, var8)
			num2 = var1(arg2 * CFrame.new(0, 0, 0.5), var12 - 0.5, arg3) + 0.5
		end

		updateBounds.minValue = 0.5
		updateBounds.maxValue = str1(var4, num2)
		local var13 = arg1
		return updateBounds:Step(var13)
	end,
	GetZoomRadius = function()
		return updateBounds.x
	end,
	SetZoomParameters = function(arg1, arg2)
		updateBounds.goal = arg1
		num1 = arg2
	end,
	ReleaseSpring = function()
		updateBounds.x = updateBounds.goal
		updateBounds.v = 0
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper [ModuleScript]
-- y u r i

local var1 = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "FlagUtil"
local str2 = "CameraWrapper"
local str3 = "ConnectionUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
local var4 = require(var1:WaitForChild(str3))
str2 = var2.getUserFlag("UserCurrentCameraUpdate2")
local var5 = game:GetService("Players")
str1 = var2.getUserFlag("UserRaycastUpdateAPI2")
str3 = var2.getUserFlag("UserPlayerConnectionMemoryLeak")
local var6 = if str2 then var3.new() else nil
local var7 = if str2 then nil else game.Workspace.CurrentCamera
if str2 then
	var6:Enable()
end

local var8 = RaycastParams.new()
var8.IgnoreWater = true
var8.FilterType = Enum.RaycastFilterType.Exclude
var8.RespectCanCollide = true
local var9 = RaycastParams.new()
var9.IgnoreWater = true
var9.FilterType = Enum.RaycastFilterType.Include
local var10 = math.min
local var11 = math.tan
local var12 = math.rad
local var13 = Ray.new
local var16 = if str3 then var4.new() else nil
local var17 = nil
local var18 = nil
local var19 = nil
if str2 then
	local function updateProjection()
		local var1 = var6:getCamera()
		local var2 = var1.ViewportSize
		var19 = var11(var12(var1.FieldOfView) / 2) * 2
		var18 = var2.X / var2.Y * var19
	end

	var6:Connect("FieldOfView", updateProjection)
	var6:Connect("ViewportSize", updateProjection)
	local var20 = var6:getCamera()
	local var21 = var20.ViewportSize
	var19 = var11(var12(var20.FieldOfView) / 2) * 2
	var18 = var21.X / var21.Y * var19
	var17 = var6:getCamera().NearPlaneZ
	var6:Connect("NearPlaneZ", function()
		var17 = var6:getCamera().NearPlaneZ
	end)

else
	updateProjection = function()
		local var1 = var7.ViewportSize
		var19 = var11(var12(var7.FieldOfView) / 2) * 2
		var18 = var1.X / var1.Y * var19
	end

	var7:GetPropertyChangedSignal("FieldOfView"):Connect(updateProjection)
	var7:GetPropertyChangedSignal("ViewportSize"):Connect(updateProjection)
	local var22 = var7.ViewportSize
	var19 = var11(var12(var7.FieldOfView) / 2) * 2
	var17 = var7.NearPlaneZ
	var7:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		var17 = var7.NearPlaneZ
	end)

	var18 = var22.X / var22.Y * var19
end

updateProjection = {}
local tbl1 = {}
local function playerAdded(arg1)
	local function characterAdded(arg1)
		tbl1[arg1] = arg1
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	local function characterRemoving()
		tbl1[arg1] = nil
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	if str3 then
		local var2 = characterAdded
		var16:trackConnection(("%*CharacterAdded"):format(arg1.UserId), arg1.CharacterAdded:Connect(var2))
		var2 = characterRemoving
		var16:trackConnection(("%*CharacterRemoving"):format(arg1.UserId), arg1.CharacterRemoving:Connect(var2))
	else
		arg1.CharacterAdded:Connect(characterAdded)
		arg1.CharacterRemoving:Connect(characterRemoving)
	end

	if arg1.Character then
		tbl1[arg1] = arg1.Character
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end
end

var5.PlayerAdded:Connect(playerAdded)
var5.PlayerRemoving:Connect(function(arg1)
	tbl1[arg1] = nil
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end

	if str3 then
		var16:disconnect((("%*CharacterAdded"):format(arg1.UserId)))
		var16:disconnect((("%*CharacterRemoving"):format(arg1.UserId)))
	end
end)

local function refreshIgnoreList()
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end
end

for k1, v1 in ipairs(var5:GetPlayers()) do
	playerAdded(v1)
end

updateProjection = {}
local num1 = 1
for k2, v2 in pairs(tbl1) do
	updateProjection[num1] = v2
	num1 = num1 + 1
end

tbl1 = nil
refreshIgnoreList = nil
if str2 then
	var6:Connect("CameraSubject", function()
		local var2 = var6:getCamera().CameraSubject
		if var2 and var2:IsA("Humanoid") then
			refreshIgnoreList = var2.RootPart
			return
		end

		if var2 and var2:IsA("BasePart") then
			refreshIgnoreList = var2
			return
		end

		refreshIgnoreList = nil
	end)

else
	var7:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		local var1 = var7.CameraSubject
		if var1:IsA("Humanoid") then
			refreshIgnoreList = var1.RootPart
			return
		end

		if var1:IsA("BasePart") then
			refreshIgnoreList = var1
			return
		end

		refreshIgnoreList = nil
	end)

end

local num2 = 0
local num3 = 0.2
local function queryPoint(arg1, arg2, arg3, arg4)
	debug.profilebegin("queryPoint")
	arg3 = arg3 + var17
	local var1 = arg1 + arg2 * arg3
	local num1 = math.huge
	local num2 = math.huge
	local var2 = arg1
	local num3 = 0
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var3 = #updateProjection
		while true do
			local var7 = workspace:Raycast(var2, var1 - var2, var8)
			if var7 then
				local var10 = var7.Position
				num3 = num3 + 1
				local var12 = var7.Instance
				local var14 = (var10 - arg1).Magnitude
				if 64 <= num3 then
					num2 = var14
				else
					local bool2 = false
					if 1 - (1 - var12.Transparency) * (1 - var12.LocalTransparencyModifier) < 0.25 then
						if not str1 then
							bool2 = var12.CanCollide
							if bool2 then
								bool2 = false
								if tbl1 ~= (var12:GetRootPart() or var12) then
									bool2 = not var12:IsA("TrussPart")
								end
							end
						end
					end

					if bool2 then
						var9.FilterDescendantsInstances = { var12 }
						if workspace:Raycast(var1, var10 - var1, var9) then
							local var15
							if arg4 then
								var15 = workspace:Raycast(arg4, var1 - arg4, var9)
								if not var15 then
									var15 = workspace:Raycast(var1, arg4 - var1, var9)
								end
							else
								var15 = false
							end

							if var15 then
								num2 = var14
							elseif arg3 < num1 then
								num1 = var14
							end
						else
							num2 = var14
						end
					end
				end

				var8:AddToFilter(var12)
				var2 = var10 - arg2 * 0.001
				if num2 >= math.huge and var12 then
					continue
				end
			end
		end
	else
		repeat
			local var19, var20 = workspace:FindPartOnRayWithIgnoreList(var13(var2, var1 - var2), updateProjection, false, true)
			num3 = num3 + 1
			if var19 then
				local var21 = 64 <= num3
				local bool4 = false
				if 1 - (1 - var19.Transparency) * (1 - var19.LocalTransparencyModifier) < 0.25 then
					if not str1 then
						bool4 = var19.CanCollide
						if bool4 then
							bool4 = false
							if tbl1 ~= (var19:GetRootPart() or var19) then
								bool4 = not var19:IsA("TrussPart")
							end
						end
					end
				end

				if bool4 or var21 then
					bool4 = { var19 }
					var15 = (var20 - arg1).Magnitude
					if workspace:FindPartOnRayWithWhitelist(var13(var1, var20 - var1), bool4, true) then
						if not var21 then
							local bool5 = false
							if arg4 and workspace:FindPartOnRayWithWhitelist(var13(var1, arg4 - var1), bool4, true) then
								num2 = var15
							elseif arg3 < num1 then
								num1 = var15
							end
						else
							num2 = var15
						end
					else
						num2 = var15
					end
				end

				updateProjection[#updateProjection + 1] = var19
			end

			local var22 = var20 - arg2 * 0.001
		until num2 < math.huge or (not var19)

		local var23 = updateProjection
		for i1 = #var23, var3 + 1, -1 do
			var23[i1] = nil
		end
	end

	debug.profileend()
	return num1 - var17, num2 - var17
end

num1 = function(arg1, arg2)
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var2 = workspace:Raycast(arg1, arg2, var8)
		if var2 then
			return var2.Position, true
		end
	else
		local var3 = #updateProjection
		repeat
			local var7, var9 = workspace:FindPartOnRayWithIgnoreList(var13(arg1, arg2), updateProjection, false, true)
			if var7 then
				if var7.CanCollide then
					local var11 = updateProjection
					for i1 = #var11, var3 + 1, -1 do
						var11[i1] = nil
					end

					return var9, true
				end

				updateProjection[#updateProjection + 1] = var7
			end
		until not var7

		local var12 = updateProjection
		for i2 = #var12, var3 + 1, -1 do
			var12[i2] = nil
		end
	end

	return arg1 + arg2, false
end

local tbl2 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(num2, num3),
}

local function queryViewport(arg1, arg2)
	debug.profilebegin("queryViewport")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	local var5 = if str2 then var6:getCamera() else var7
	var7 = var5
	var5 = var7.ViewportSize
	local num1 = math.huge
	local num2 = math.huge
	for i1 = 0, 1 do
		for i2 = 0, 1 do
			local var8 = var2 * ((i1 - 0.5) * var18)
			local var11, var12 = queryPoint(var1 + var17 * (var8 + var3 * ((i2 - 0.5) * var19)), var4, arg2, var7:ViewportPointToRay(var5.x * i1, var5.y * i2).Origin)
			if var12 < num1 then
				num1 = var12
			end

			if var11 >= num2 then
				continue
			end

			num2 = var11
		end
	end

	debug.profileend()
	return num2, num1
end

local function testPromotion(arg1, arg2, arg3)
	debug.profilebegin("testPromotion")
	debug.profilebegin("extrapolate")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	for i1 = 0, var10(1.25, arg3.rotVelocity.magnitude + (num1(var1, arg3.posVelocity * 1.25) - var1).Magnitude / arg3.posVelocity.magnitude), 0.0625 do
		local var5 = arg3.extrapolate(i1)
		if arg2 > queryPoint(var5.p, -var5.lookVector, arg2) then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profilebegin("testOffsets")
	for k1, v1 in ipairs(tbl2) do
		local var6 = num1(var1, var2 * v1.x + var3 * v1.y)
		if queryPoint(var6, (var1 + var4 * arg2 - var6).Unit, arg2) ~= math.huge then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profileend()
	return true
end

return function(arg1, arg2, arg3)
	debug.profilebegin("popper")
	local var1 = refreshIgnoreList and refreshIgnoreList:GetRootPart() or refreshIgnoreList
	tbl1 = var1
	local var4, var5 = queryViewport(arg1, arg2)
	var1 = arg2
	if var5 < var1 then
		var1 = var5
	end

	if var4 < var1 and testPromotion(arg1, arg2, arg3) then
		var1 = var4
	end

	tbl1 = nil
	debug.profileend()
	return var1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.MouseLockController [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local str2 = "CameraUtils"
local var2 = game:GetService("Players")
str1 = game:GetService("ContextActionService")
local var3 = game:GetService("UserInputService")
local var4 = UserSettings().GameSettings
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = var1.getUserFlag("UserFixStuckShiftLock")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.isMouseLocked = false
	var1.savedMouseCursor = nil
	var1.boundKeys = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift }
	var1.mouseLockToggledEvent = Instance.new("BindableEvent")
	local var6 = script:FindFirstChild("BoundKeys")
	if var6 then
		if not var6:IsA("StringValue") then
			if var6 then
				var6:Destroy()
			end

			var6 = Instance.new("StringValue")
			assert(var6, "")
			var6.Name = "BoundKeys"
			var6.Value = "LeftShift,RightShift"
			var6.Parent = script
		end
	end

	if var6 then
		var6.Changed:Connect(function(arg1)
			var1:OnBoundKeysObjectChanged(arg1)
		end)

		var1:OnBoundKeysObjectChanged(var6.Value)
	end

	var4.Changed:Connect(function(arg1)
		if arg1 == "ControlMode" or arg1 == "ComputerMovementMode" then
			var1:UpdateMouseLockAvailability()
		end
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var3:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var1:UpdateMouseLockAvailability()
	return var1
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.isMouseLocked
end

tbl1.GetBindableToggleEvent = function(arg1)
	return arg1.mouseLockToggledEvent.Event
end

tbl1.GetMouseLockOffset = function(_)
	return Vector3.new(1.75, 0, 0)
end

tbl1.UpdateMouseLockAvailability = function(arg1)
	local var1 = var3.PreferredInput == Enum.PreferredInput.KeyboardAndMouse
	var1 = var1 and (var2.LocalPlayer.DevEnableMouseLock and (var4.ControlMode == Enum.ControlMode.MouseLockSwitch and (not (var4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove) and (not (var2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable)))))
	if var1 ~= arg1.enabled then
		arg1:EnableMouseLock(var1)
	end
end

tbl1.OnBoundKeysObjectChanged = function(arg1, arg2)
	arg1.boundKeys = {}
	for k1 in string.gmatch(arg2, "[^%s,]+") do
		for k2, v1 in pairs(Enum.KeyCode:GetEnumItems()) do
			if k1 ~= v1.Name then
				continue
			end

			arg1.boundKeys[#arg1.boundKeys + 1] = v1
			break
		end
	end

	arg1:UnbindContextActions()
	arg1:BindContextActions()
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = not arg1.isMouseLocked
	arg1.isMouseLocked = var1
	if arg1.isMouseLocked then
		var1 = script:FindFirstChild("CursorImage")
		if var1 and (var1:IsA("StringValue") and var1.Value) then
			var5.setMouseIconOverride(var1.Value)
		elseif var1 then
			var1:Destroy()
		end
	else
		var5.restoreMouseIcon()
	end

	arg1.mouseLockToggledEvent:Fire()
end

tbl1.DoMouseLockSwitch = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1:OnMouseLockToggled()
		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end

local var7 = Enum.ContextActionPriority.Medium.Value
tbl1.BindContextActions = function(arg1)
	local var1 = arg1.boundKeys
	str1:BindActionAtPriority("MouseLockSwitchAction", function(arg1, arg2, arg3)
		local var1 = arg1
		local var2 = arg2
		local var3 = arg3
		return arg1:DoMouseLockSwitch(var1, var2, var3)
	end, false, var7, unpack(var1))
end

tbl1.UnbindContextActions = function(_)
	str1:UnbindAction("MouseLockSwitchAction")
end

tbl1.IsMouseLocked = function(arg1)
	local var1 = arg1.enabled
	return var1 and arg1.isMouseLocked
end

tbl1.EnableMouseLock = function(arg1, arg2)
	if arg2 ~= arg1.enabled then
		arg1.enabled = arg2
		if arg1.enabled then
			arg1:BindContextActions()
			return
		end

		var5.restoreMouseIcon()
		arg1:UnbindContextActions()
		if var6 then
			if not arg1.isMouseLocked then
				return
			end

			arg1.isMouseLocked = false
			arg1.mouseLockToggledEvent:Fire()
			return
		end

		if arg1.isMouseLocked then
			arg1.mouseLockToggledEvent:Fire()
		end

		arg1.isMouseLocked = false
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec [ModuleScript]
-- y u r i

local var1 = require(game:GetService("CorePackages").Packages.Dev.JestGlobals)
local var2 = require(script.Parent.VRCameraTeleportDetector)
local var3 = var1.it
local var4 = var1.expect
local var5 = var2.shouldRecenter
local var6 = var2.JUMP_STUDS
local var7 = var2.SETTLED_STUDS
local var8 = var2.DEBOUNCE_SECONDS
var1.describe("VRCameraTeleportDetector.shouldRecenter", function()
	var3("fires on a discrete jump from rest (no prior step, never recentered)", function()
		local var1 = nil
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("fires on a discrete jump preceded by a near-still frame", function()
		local var1 = var7 - 0.5
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("does not fire for sub-threshold motion", function()
		local num1 = 0
		local var1 = var6 - 0.1
		local var2 = nil
		local num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
		num1 = 0
		var1 = 0
		var2 = nil
		num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
	end)

	var3("does not fire when the previous frame was already moving (continuous motion)", function()
		local var1 = var7 + 0.1
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(false)
	end)

	var3("does not fire within the debounce interval", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 - 0.01
		var4(var5(var1, var2, num1, var3)).toBe(false)
	end)

	var3("fires again once the debounce interval has elapsed", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 + 0.01
		var4(var5(var1, var2, num1, var3)).toBe(true)
	end)

	var3("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function()
		local num1 = 0
		local var1 = nil
		local var2 = nil
		local num2 = 0
		for i1 = 1, 120 do
			local var3 = var6 + 10
			if var5(var1, var3, var2, num1) then
				num2 = num2 + 1
			end

			local var7 = num1
			num1 = num1 + 0.016666666666666666
			local var8 = var3
		end

		var4(num2).toBe(1)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera [ModuleScript]
-- y u r i

local str1 = "VRBaseCamera"
local str2 = "CameraUtils"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str2))
local str4 = "VehicleCameraConfig"
str2 = game:GetService("RunService")
str3 = game:GetService("VRService")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local var6 = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild(str4))
local var7 = RaycastParams.new()
var7.FilterType = Enum.RaycastFilterType.Exclude
var7.IgnoreWater = true
local var8 = OverlapParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local var9 = setmetatable({}, var1)
var9.__index = var9
local num1 = 0.016666666666666666
var9.new = function()
	local var2 = setmetatable(var1.new(), var9)
	var2.skipOcclusion = true
	var2:Reset()
	if var2.thirdPersonOptionChanged then
		var2.thirdPersonOptionChanged:Disconnect()
		var2.thirdPersonOptionChanged = nil
	end

	str2.Stepped:Connect(function(_, arg2)
		num1 = arg2
	end)

	return var2
end

local tbl1 = { 0, 30 }
var9.Reset = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1, "VRVehicleCamera initialization error")
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	arg1.lastOrbitalDir = nil
	arg1.wasInFirstPerson = nil
	local var4 = var2:GetConnectedParts(true)
	table.insert(var4, var2)
	str1 = var2:FindFirstAncestorOfClass("Model")
	local var5, var6 = var3.getLooseBoundingSphere(var4)
	arg1.vehicleModel = str1 or var2.Parent
	arg1.assemblyRadius = math.max(var6, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var5
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.headScale * arg1.assemblyRadius / 10)
	end

	arg1.lastCameraFocus = nil
	if not arg1:IsInFirstPerson() then
		arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
	end

	arg1.needsReset = false
end

var9._getThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * var6.verticalCenterOffset, 0)
end

var9._getFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = var5.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_getThirdPersonLocalOffset()
end

local function findObstructions(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return 0, {}
	end

	local var3 = str3:GetUserCFrame(Enum.UserCFrame.Head)
	local var4 = arg1 * (CFrame.new(var3.Position * var2.HeadScale) * var3.Rotation)
	local var6 = arg2.Position
	local var9 = var4.Position - var6
	local var11 = var9.Magnitude
	if var11 < 0.5 then
		return 0, {}
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var12 = var5
	var12 = var12 and var5.Character
	if var12 then
		table.insert(tbl1, var12)
	end

	var7.FilterDescendantsInstances = tbl1
	local var15 = workspace:Raycast(var6, var9, var7)
	local var16 = (var15.Position - var6).Magnitude
	if var15 and var16 < var11 then
		local var17 = var15.Position
		local var18 = var4.Position
		local var19 = math.max(math.clamp((1 - -var9.Unit:Dot(var4.LookVector)) / 0.13397459621556129, 0, 1), 1 - var16 / arg3, 0.15)
		local var20 = Vector3.new(2, 2, (var18 - var17).Magnitude)
		local var21 = CFrame.lookAt((var17 + var18) / 2, var18)
		var8.FilterDescendantsInstances = tbl1
		return var19, (workspace:GetPartBoundsInBox(var21, var20, var8))
	end

	return 0, {}
end

var9._vrOccludeVignette = function(arg1, arg2, arg3, arg4)
	local var1 = CFrame.new(arg2.Position + arg3 * arg4) * CFrame.Angles(0, math.atan2(arg3.X, arg3.Z), 0)
	local var3 = var4:FindFirstChild("VRFade")
	local var6, var7 = findObstructions(var1, arg2, arg4, arg1.vehicleModel)
	if not var3 then
		var3 = Instance.new("ColorCorrectionEffect")
		var3.Name = "VRFade"
		var3.Parent = var4
	end

	var3.Brightness = -var6
	local var8
	if arg1.lastOccludedParts then
		for k1, v1 in arg1.lastOccludedParts, nil do
			v1.LocalTransparencyModifier = 0
		end
	end

	if 0 < (#var7) then
		for k2, v2 in var7, nil do
			v2.LocalTransparencyModifier = 1
		end

		arg1:StartVREdgeBlur(var5, true)
	end

	arg1.lastOccludedParts = var7
	return var1
end

var9.Update = function(arg1)
	local var1 = num1
	num1 = 0
	arg1:UpdateFadeFromBlack(var1)
	arg1:UpdateEdgeBlur(var5, var1)
	local var2, var3 = arg1:_updateStepRotation(var1)
	return var2, var3
end

local var10 = var3.mapClamp
local function vrOccludeDisplace(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	local var3 = CFrame.new(arg1.Position + arg2 * arg3) * CFrame.Angles(0, math.atan2(arg2.X, arg2.Z), 0)
	if not var2 then
		return var3
	end

	local var4 = arg1.Position
	local var6 = (var3.Position - var4) * Vector3.new(1, 0, 1)
	local var9 = var6.Magnitude
	if var9 < 0.5 then
		return var3
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var10 = var5
	var10 = var10 and var5.Character
	if var10 then
		table.insert(tbl1, var10)
	end

	var7.FilterDescendantsInstances = tbl1
	local var14 = workspace:Raycast(var4, var6, var7)
	local var15 = var6.Unit
	local var16 = (var14.Position - var4).Magnitude - 0.5
	if var14 and (var14.Normal:Dot(var15) < 0 and var16 < var9) then
		return CFrame.new(arg1.Position + var15 * math.max(var16, 0.5)) * var3.Rotation
	end

	return var3
end

var9._updateStepRotation = function(arg1, arg2)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var3 = arg1:GetSubjectCFrame()
	local var4 = CFrame.new(var3 * arg1:_getThirdPersonLocalOffset():Lerp(arg1:_getFirstPersonLocalOffset(var3), (var10(var1, 0.5, arg1.assemblyRadius, 1, 0))) + Vector3.new(0, arg1:GetCameraHeight(), 0))
	if arg1.needsReset or arg1.recentered then
		arg1.lastOrbitalDir = nil
		arg1.needsReset = false
		arg1.recentered = false
	end

	local var7 = arg1.lastOrbitalDir
	if not var7 then
		arg1:StartFadeFromBlack()
		var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
	end

	local var9 = 2 < (arg1:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude
	if not var9 then
		local var11 = arg1:getRotation(arg2)
		if 0 < math.abs(var11) then
			var7 = (CFrame.Angles(0, -var11, 0) * CFrame.new(var7)).Position.Unit
			arg1.lastRotateTime = os.clock()
		end
	else
		var2.getRotation(arg2)
	end

	local var12 = nil
	if arg1:IsInFirstPerson() then
		if not arg1.wasInFirstPerson or var9 then
			arg1.wasInFirstPerson = true
			var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
		end

		local var14 = math.atan2(-var3.LookVector.X, -var3.LookVector.Z)
		local var15 = (var14 - arg1.lastVehicleYaw + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
		if arg1.lastVehicleYaw and 0.001 < math.abs(var15) then
			var7 = (CFrame.Angles(0, var15, 0) * CFrame.new(var7)).Position.Unit
		end

		arg1.lastVehicleYaw = var14
		var12 = CFrame.new(var4.Position + var7 * var1) * CFrame.Angles(0, math.atan2(var7.X, var7.Z), 0)
	else
		arg1.wasInFirstPerson = false
		arg1.lastVehicleYaw = nil
		local var17 = arg1.lastRotateTime
		if var17 then
			var17 = os.clock() - arg1.lastRotateTime < var6.autocorrectDelay
		end

		if var9 and (not var17) then
			local var19 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
			var7 = var7:Lerp(var19, (math.min(0.01 + math.acos((math.clamp(var7:Dot(var19), -1, 1))) / 3.1415926535897931 * 0.05 + math.abs((var3.YVector:Dot((arg1:GetSubjectRotVelocity())))) * 0.02, 0.15)))
		end

		var12 = vrOccludeDisplace(var4, var7, var1, arg1.vehicleModel)
	end

	arg1.lastOrbitalDir = var7
	return var12, var12 * CFrame.new(0, 0, -var1)
end

return var9

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCamera [ModuleScript]
-- y u r i

UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraUtils"
require(script.Parent:WaitForChild(str2))
local str3 = "VRCameraTeleportDetector"
local var1 = require(script.Parent:WaitForChild(str3))
local str4 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str4))
local str5 = "VRBaseCamera"
str4 = require(script.Parent:WaitForChild(str5))
local var2 = game:GetService("Players")
local var3 = game:GetService("VRService")
str3 = str2.getUserFlag("UserVRRemoveLuaEdgeBlur")
local var4 = str2.getUserFlag("UserVRRecenterOnExternalTeleport")
local var5 = setmetatable({}, str4)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str4.new(), var5)
	var1.lastUpdate = tick()
	var1.focusOffset = CFrame.new()
	var1:Reset()
	local str1 = "ControlModule"
	var1.controlModule = require(var2.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild(str1))
	var1.savedAutoRotate = true
	return var1
end

var5.Reset = function(arg1)
	arg1.needsReset = true
	arg1.needsBlackout = true
	arg1.motionDetTime = 0
	arg1.blackOutTimer = 0
	arg1.lastCameraResetPosition = nil
	str4.Reset(arg1)
end

var5.Update = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	arg1:GetHumanoid()
	local var4 = var1.CFrame
	local var5 = var1.Focus
	local var6 = var2.LocalPlayer
	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:UpdateFadeFromBlack(arg2)
	if not str3 then
		arg1:UpdateEdgeBlur(var6, arg2)
	end

	local var7 = arg1.lastSubjectPosition
	local var8 = arg1:GetSubjectPosition()
	if arg1.needsBlackout then
		arg1:StartFadeFromBlack()
		local var9 = arg1.blackOutTimer + math.clamp(arg2, 0.0001, 0.1)
		arg1.blackOutTimer = var9
		if 0.1 < arg1.blackOutTimer and game:IsLoaded() then
			arg1.needsBlackout = false
			arg1.needsReset = true
		end
	end

	if var8 then
		if var6 then
			if var1 then
				var5 = arg1:GetVRFocus(var8, arg2)
				if arg1:IsInFirstPerson() then
					if var3.AvatarGestures then
						local var20, var21 = arg1:UpdateImmersionCamera(arg2, var4, var5, var7, var8)
						var4 = var20
						var5 = var21
					else
						local var22, var23 = arg1:UpdateFirstPersonTransform(arg2, var4, var5, var7, var8)
						var4 = var22
						var5 = var23
					end
				else
					if var3.ThirdPersonFollowCamEnabled then
						local var26, var27 = arg1:UpdateThirdPersonFollowTransform(arg2, var4, var5, var7, var8)
						var4 = var26
						var5 = var27
					else
						local var28, var29 = arg1:UpdateThirdPersonComfortTransform(arg2, var4, var5, var7, var8)
						var4 = var28
						var5 = var29
					end
				end

				arg1.lastCameraTransform = var4
				arg1.lastCameraFocus = var5
			end
		end
	end

	arg1.lastUpdate = tick()
	return var4, var5
end

var5.GetAvatarFeetWorldYValue = function(_)
	local var2 = workspace.CurrentCamera.CameraSubject
	if not var2 then
		return nil
	end

	if var2:IsA("Humanoid") and var2.RootPart then
		local var4 = var2.RootPart
		return var4.Position.Y - var4.Size.Y / 2 - var2.HipHeight
	end

	return nil
end

var5.UpdateFirstPersonTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	if arg1.needsReset then
		arg1:StartFadeFromBlack()
		arg1.needsReset = false
	end

	local var1 = var2.LocalPlayer
	if not str3 and 0.01 < (arg5 - arg6).magnitude then
		arg1:StartVREdgeBlur(var1)
	end

	local var3 = arg1:GetCameraLookVector()
	local var4 = arg1:getRotation(arg2)
	local num1 = 0
	local var5 = arg1:CalculateNewLookVectorFromArg(Vector3.new(var3.X, 0, var3.Z).Unit, Vector2.new(var4, num1))
	local var6 = arg4.p
	return CFrame.new(var6 - 0.5 * var5, var6), arg4
end

var5.UpdateImmersionCamera = function(arg1, arg2, arg3, _, arg5, arg6)
	local var7 = arg1:GetHumanoid()
	local var8 = arg1:GetSubjectCFrame()
	local var9 = workspace.CurrentCamera
	local var10 = var2.LocalPlayer.Character
	if not var7 then
		return var9.CFrame, var9.Focus
	end

	local var12 = var10:FindFirstChild("HumanoidRootPart")
	if not var12 then
		return var9.CFrame, var9.Focus
	end

	local var13 = nil
	if var4 then
		var13 = if arg5 then Vector3.new(arg6.X - arg5.X, 0, arg6.Z - arg5.Z).Magnitude else 0
	end

	arg1.characterOrientation = var12:FindFirstChild("CharacterAlignOrientation")
	if not arg1.characterOrientation then
		local var15 = var12:FindFirstChild("RootAttachment")
		if not var15 then
			return
		end

		arg1.characterOrientation = Instance.new("AlignOrientation")
		arg1.characterOrientation.Name = "CharacterAlignOrientation"
		arg1.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		arg1.characterOrientation.Attachment0 = var15
		arg1.characterOrientation.RigidityEnabled = true
		arg1.characterOrientation.Parent = var12
	end

	if arg1.characterOrientation.Enabled == false then
		arg1.characterOrientation.Enabled = true
	end

	if arg1.needsReset then
		arg1.needsReset = false
		arg1.savedAutoRotate = var7.AutoRotate
		var7.AutoRotate = false
		if var4 then
			var3:RecenterUserHeadCFrame()
			arg1.lastTeleportRecenter = tick()
		end

		arg1:StartFadeFromBlack()
		arg3 = var8
	else
		if var7.Sit then
			arg3 = var8
			if not str3 and 0.01 < (arg3.Position - var9.CFrame.Position).Magnitude then
				arg1:StartVREdgeBlur(var2.LocalPlayer)
			end
		else
			arg1.characterOrientation.CFrame = var9.CFrame * arg1.controlModule:GetEstimatedVRTorsoFrame()
			if 0 < arg1.controlModule.inputMoveVector.Magnitude then
				arg1.motionDetTime = 0.1
			end

			if 0 < arg1.controlModule.inputMoveVector.Magnitude or 0 < arg1.motionDetTime then
				local var16 = arg1.motionDetTime - arg2
				arg1.motionDetTime = var16
				if not str3 then
					arg1:StartVREdgeBlur(var2.LocalPlayer)
				end

				var16 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				local var17 = var10.HumanoidRootPart
				local var18 = var17.CFrame.LookVector
				local var19 = arg6 - (var9.CFrame * (var16.Rotation + var16.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var17.Size.Y / 2, 0) - Vector3.new(var18.X, 0, var18.Z).Unit * var17.Size.Y * 0.125).Position + var9.CFrame.Position
				arg3 = var9.CFrame.Rotation + Vector3.new(var19.X, arg6.Y, var19.Z)
			else
				if var4 and var1.shouldRecenter(arg1.prevSubjStep, var13, arg1.lastTeleportRecenter, tick()) then
					local var23 = var3:GetUserCFrame(Enum.UserCFrame.Head)
					local var24 = var10.HumanoidRootPart
					local var25 = var24.CFrame.LookVector
					local var26 = arg6 - (var9.CFrame * (var23.Rotation + var23.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var24.Size.Y / 2, 0) - Vector3.new(var25.X, 0, var25.Z).Unit * var24.Size.Y * 0.125).Position + var9.CFrame.Position
					var3:RecenterUserHeadCFrame()
					arg1:StartFadeFromBlack()
					arg3 = var9.CFrame.Rotation + Vector3.new(var26.X, arg6.Y, var26.Z)
					arg1.lastTeleportRecenter = tick()
				else
					arg3 = var9.CFrame.Rotation + Vector3.new(var9.CFrame.Position.X, arg6.Y, var9.CFrame.Position.Z)
				end
			end

			local var27 = arg1:getRotation(arg2)
			if 0 < math.abs(var27) then
				local var30 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				var30 = var30.Rotation + var30.Position * var9.HeadScale
				local var31 = arg3 * var30
				arg3 = CFrame.new(var31.Position) * CFrame.Angles(0, -math.rad(var27 * 90), 0) * var31.Rotation * var30:Inverse()
			end
		end
	end

	if var4 then
		arg1.prevSubjStep = var13
	end

	return arg3, arg3 * CFrame.new(0, 0, -0.5)
end

var5.UpdateThirdPersonComfortTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var4 = arg1:GetCameraToSubjectDistance()
	if var4 < 0.5 then
		var4 = 0.5
	end

	if arg5 ~= nil then
		if arg1.lastCameraFocus ~= nil then
			local var5 = arg1.controlModule:GetMoveVector()
			local bool1 = true
			if 0.01 >= (arg5 - arg6).magnitude then
				bool1 = 0.01 < var5.magnitude
			end

			if bool1 then
				arg1.motionDetTime = 0.1
			end

			local var6 = arg1.motionDetTime - arg2
			arg1.motionDetTime = var6
			if 0 < arg1.motionDetTime then
				bool1 = true
			end

			if bool1 and (not arg1.needsReset) then
				arg1.VRCameraFocusFrozen = true
				arg4 = arg1.lastCameraFocus
				return arg3, arg4
			end

			var6 = true
			if arg1.lastCameraResetPosition ~= nil then
				var6 = 1 < (arg6 - arg1.lastCameraResetPosition).Magnitude
			end

			local var7 = arg1:getRotation(arg2)
			if 0 < math.abs(var7) then
				arg3 = arg4 * CFrame.Angles(0, -var7, 0) * arg4:ToObjectSpace(arg3)
			end

			if arg1.VRCameraFocusFrozen and var6 or arg1.needsReset then
				var3:RecenterUserHeadCFrame()
				arg1.VRCameraFocusFrozen = false
				arg1.needsReset = false
				arg1.lastCameraResetPosition = arg6
				arg1:ResetZoom()
				arg1:StartFadeFromBlack()
				local var8 = arg1:GetHumanoid()
				local var9 = var8.Torso and var8.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
				local var10 = arg4.Position - Vector3.new(var9.X, 0, var9.Z) * var4
				arg3 = CFrame.new(var10, (Vector3.new(arg4.Position.X, var10.Y, arg4.Position.Z)))
			end
		end
	end

	return arg3, arg4
end

var5.UpdateThirdPersonFollowTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = workspace.CurrentCamera
	local var4 = arg1:GetCameraToSubjectDistance()
	local var5 = arg1:GetVRFocus(arg6, arg2)
	if arg1.needsReset then
		arg1.needsReset = false
		var3:RecenterUserHeadCFrame()
		arg1:ResetZoom()
		arg1:StartFadeFromBlack()
	end

	if arg1.recentered then
		local var7 = arg1:GetSubjectCFrame()
		if not var7 then
			return var1.CFrame, var1.Focus
		end

		arg3 = var5 * var7.Rotation * CFrame.new(0, 0, var4)
		arg1.focusOffset = var5:ToObjectSpace(arg3)
		arg1.recentered = false
		return arg3, var5
	end

	local var8 = arg1.controlModule
	local var12 = var5:ToWorldSpace(arg1.focusOffset)
	if 0.01 < (arg5 - arg6).magnitude or 0 < var8:GetMoveVector().magnitude then
		local var13 = var8:GetEstimatedVRTorsoFrame()
		local var14 = var1.CFrame * (var13.Rotation + var13.Position * var1.HeadScale)
		local var15 = var14.LookVector
		arg3 = var12:Lerp(CFrame.new(var1.CFrame.Position + (var5.Position - Vector3.new(var15.X, 0, var15.Z).Unit * var4) - var14.Position) * var12.Rotation, 0.01)
	else
		arg3 = var12
	end

	local var16 = arg1:getRotation(arg2)
	if 0 < math.abs(var16) then
		arg3 = var5 * CFrame.Angles(0, -var16, 0) * var5:ToObjectSpace(arg3)
	end

	arg1.focusOffset = var5:ToObjectSpace(arg3)
	arg4 = arg3 * CFrame.new(0, 0, -var4)
	if not str3 and 0.01 < (arg4.Position - var1.Focus.Position).Magnitude then
		arg1:StartVREdgeBlur(var2.LocalPlayer)
	end

	return arg3, arg4
end

var5.LeaveFirstPerson = function(arg1)
	str4.LeaveFirstPerson(arg1)
	arg1.needsReset = true
	if arg1.VRBlur then
		arg1.VRBlur.Visible = false
	end

	if arg1.characterOrientation then
		arg1.characterOrientation.Enabled = false
	end

	local var2 = arg1:GetHumanoid()
	if var2 then
		var2.AutoRotate = arg1.savedAutoRotate
	end
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseCamera [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
require(var1:WaitForChild(str2))
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local str4 = "ZoomController"
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "CameraToggleStateController"
str1 = require(script.Parent:WaitForChild(str4))
local str6 = "CameraInput"
str2 = require(script.Parent:WaitForChild(str5))
local str7 = "CameraUI"
str3 = require(script.Parent:WaitForChild(str6))
str4 = require(script.Parent:WaitForChild(str7))
Vector2.new(0, 0)
local var4 = game:GetService("VRService")
local var5 = UserSettings():GetService("UserGameSettings")
str5 = game:GetService("Players").LocalPlayer
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = var2.new()
	var1.gamepadZoomLevels = { 0, 10, 20 }
	var1.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	var1.cameraType = nil
	var1.cameraMovementMode = nil
	var1.lastCameraTransform = nil
	var1.lastUserPanCamera = tick()
	var1.humanoidRootPart = nil
	var1.humanoidCache = {}
	var1.lastSubject = nil
	var1.lastSubjectPosition = Vector3.new(0, 5, 0)
	var1.lastSubjectCFrame = CFrame.new(var1.lastSubjectPosition)
	var1.currentSubjectDistance = math.clamp(12.5, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
	var1.inFirstPerson = false
	var1.inMouseLockedMode = false
	var1.resetCameraAngle = true
	var1.enabled = false
	var1.cameraChangedConn = nil
	var1.shouldUseVRRotation = false
	var1.VRRotationIntensityAvailable = false
	var1.lastVRRotationIntensityCheckTime = 0
	var1.lastVRRotationTime = 0
	var1.vrRotateKeyCooldown = {}
	var1.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	var1.humanoidJumpOrigin = nil
	var1.trackingHumanoid = nil
	var1.cameraFrozen = false
	var1.subjectStateChangedConn = nil
	var1.gamepadZoomPressConnection = nil
	var1.mouseLockOffset = Vector3.new(0, 0, 0)
	var5:SetCameraYInvertVisible()
	var5:SetGamepadCameraSensitivityVisible()
	return var1
end

tbl1.GetModuleName = function(_)
	return "BaseCamera"
end

tbl1._setUpConfigurations = function(arg1)
	local function fn2(arg1)
		arg1:OnCharacterAdded(arg1)
	end

	arg1._connections:trackConnection("CHARACTER_ADDED", str5.CharacterAdded:Connect(fn2))
	arg1.humanoidRootPart = nil
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MODE_CHANGED", str5:GetPropertyChangedSignal("CameraMode"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(fn2))
	arg1:OnPlayerCameraPropertyChange()
end

tbl1.OnCharacterAdded = function(arg1, _)
	local var1 = arg1.resetCameraAngle
	var1 = var1 or arg1:GetEnabled()
	arg1.resetCameraAngle = var1
	arg1.humanoidRootPart = nil
end

tbl1.GetHumanoidRootPart = function(arg1)
	local var2 = str5.Character:FindFirstChildOfClass("Humanoid")
	if not arg1.humanoidRootPart and (str5.Character and var2) then
		arg1.humanoidRootPart = var2.RootPart
	end

	return arg1.humanoidRootPart
end

tbl1.GetBodyPartToFollow = function(_, arg2, _)
	if arg2:GetState() == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			if var3:IsA("Model") then
				local var4 = var3:FindFirstChild("Head")
				return var4 or arg2.RootPart
			end
		end
	end

	return arg2.RootPart
end

tbl1.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectCFrame
	if not var2 then
		return var3
	end

	if var2:IsA("Humanoid") then
		local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
		local var5 = var2.CameraOffset
		if arg1:GetIsMouseLocked() then
			var5 = Vector3.new()
		end

		local var6 = var2.RootPart
		var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
		if var6 then
			if var6:IsA("BasePart") then
				local var13 = nil
				if var2.RigType == Enum.HumanoidRigType.R15 then
					if var2.AutomaticScalingEnabled then
						local var16 = var2.RootPart
						var13 = Vector3.new(0, 1.5, 0)
						if var6 == var16 then
							var13 = var13 + Vector3.new(0, (var16.Size.Y - 2) / 2, 0)
						end
					else
						var13 = Vector3.new(0, 2, 0)
					end
				else
					var13 = Vector3.new(0, 1.5, 0)
				end

				if var4 then
					var13 = Vector3.new(0, 0, 0)
				end

				var3 = var6.CFrame * CFrame.new(var13 + var5)
			end
		end
	else
		if var2:IsA("BasePart") then
			var3 = var2.CFrame
		else
			if var2:IsA("Model") then
				var3 = if var2.PrimaryPart then var2:GetPrimaryPartCFrame() else CFrame.new()
			end
		end
	end

	if var3 then
		arg1.lastSubjectCFrame = var3
	end

	return var3
end

tbl1.GetSubjectVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.Velocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.Velocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.Velocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetSubjectRotVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.RotVelocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.RotVelocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.RotVelocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.StepZoom = function(arg1)
	local var1 = str3.getZoomDelta()
	local var4 = arg1.currentSubjectDistance
	if 0 < math.abs(var1) then
		local var6 = nil
		var6 = if 0 < var1 then math.max(var4 + var1 * (var4 * 0.5 + 1), arg1.FIRST_PERSON_DISTANCE_THRESHOLD) else math.max((var4 + var1) / (1 - var1 * 0.5), 0.5)
		if var6 < arg1.FIRST_PERSON_DISTANCE_THRESHOLD then
			var6 = 0.5
		end

		arg1:SetCameraToSubjectDistance(var6)
	end

	return str1.GetZoomRadius()
end

tbl1.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectPosition
	if var2 then
		if var2:IsA("Humanoid") then
			local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
			local var5 = var2.CameraOffset
			if arg1:GetIsMouseLocked() then
				var5 = Vector3.new()
			end

			local var6 = var2.RootPart
			var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
			if var6 then
				if var6:IsA("BasePart") then
					local var10 = nil
					if var2.RigType == Enum.HumanoidRigType.R15 then
						if var2.AutomaticScalingEnabled then
							var10 = Vector3.new(0, 1.5, 0)
							if var6 == var2.RootPart then
								var10 = var10 + Vector3.new(0, var2.RootPart.Size.Y / 2 - 1, 0)
							end
						else
							var10 = Vector3.new(0, 2, 0)
						end
					else
						var10 = Vector3.new(0, 1.5, 0)
					end

					if var4 then
						var10 = Vector3.new(0, 0, 0)
					end

					var3 = var6.CFrame.p + var6.CFrame:vectorToWorldSpace(var10 + var5)
				end
			end
		else
			if var2:IsA("VehicleSeat") then
				var3 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
			else
				if var2:IsA("SkateboardPlatform") then
					var3 = var2.CFrame.p + Vector3.new(0, 5, 0)
				else
					if var2:IsA("BasePart") then
						var3 = var2.CFrame.p
					else
						if var2:IsA("Model") then
							if var2.PrimaryPart then
								var3 = var2:GetPrimaryPartCFrame().p
							else
								var3 = var2:GetModelCFrame().p
							end
						end
					end
				end
			end
		end
	else
		return nil
	end

	arg1.lastSubject = var2
	arg1.lastSubjectPosition = var3
	return var3
end

tbl1.OnCurrentCameraChanged = function(arg1)
	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
		arg1.cameraSubjectChangedConn = nil
	end

	local var2 = game.Workspace.CurrentCamera
	if var2 then
		arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			arg1:OnNewCameraSubject()
		end)

		arg1:OnNewCameraSubject()
	end
end

tbl1.OnPlayerCameraPropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.InputTranslationToCameraAngleChange = function(_, arg2, arg3)
	return arg2 * arg3
end

tbl1.GamepadZoomPress = function(arg1)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var2 = str5.CameraMaxZoomDistance
	for i1 = #arg1.gamepadZoomLevels, 1, -1 do
		local var3 = arg1.gamepadZoomLevels[i1]
		if var2 < var3 then
			continue
		end

		if var3 < str5.CameraMinZoomDistance then
			var3 = str5.CameraMinZoomDistance
			if var2 == var3 then
				break
			end
		end

		if var3 + (var2 - var3) / 2 < var1 then
			arg1:SetCameraToSubjectDistance(var3)
			return
		end

		local var4 = var3
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
		arg1:OnEnabledChanged()
	end
end

tbl1.OnEnabledChanged = function(arg1)
	if arg1.enabled then
		arg1:_setUpConfigurations()
		str3.setInputEnabled(true)
		arg1.gamepadZoomPressConnection = str3.gamepadZoomPress:Connect(function()
			arg1:GamepadZoomPress()
		end)

		if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		end

		if arg1.cameraChangedConn then
			arg1.cameraChangedConn:Disconnect()
			arg1.cameraChangedConn = nil
		end

		arg1.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			arg1:OnCurrentCameraChanged()
		end)

		arg1:OnCurrentCameraChanged()
		return
	end

	arg1._connections:disconnectAll()
	str3.setInputEnabled(false)
	if arg1.gamepadZoomPressConnection then
		arg1.gamepadZoomPressConnection:Disconnect()
		arg1.gamepadZoomPressConnection = nil
	end

	arg1:Cleanup()
end

tbl1.GetEnabled = function(arg1)
	return arg1.enabled
end

tbl1.Cleanup = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end

	if arg1.cameraChangedConn then
		arg1.cameraChangedConn:Disconnect()
		arg1.cameraChangedConn = nil
	end

	arg1.lastCameraTransform = nil
	arg1.lastSubjectCFrame = nil
	var3.restoreMouseBehavior()
end

tbl1.UpdateMouseBehavior = function(arg1)
	if arg1.isCameraToggle and var5.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove == false then
		str4.setCameraModeToastEnabled(true)
		str3.enableCameraToggleInput()
		str2(arg1.inFirstPerson)
		return
	end

	str4.setCameraModeToastEnabled(false)
	str3.disableCameraToggleInput()
	if arg1.inFirstPerson or arg1.inMouseLockedMode then
		var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
		return
	end

	var3.restoreRotationType()
	if str3.getRotationActivated() then
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
		return
	end

	var3.restoreMouseBehavior()
end

tbl1.UpdateForDistancePropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1.currentSubjectDistance
	if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
		arg1.currentSubjectDistance = 0.5
		if not arg1.inFirstPerson then
			arg1:EnterFirstPerson()
		end
	else
		local var3 = math.clamp(arg2, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
		if var3 < 1 then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		else
			arg1.currentSubjectDistance = var3
			if arg1.inFirstPerson then
				arg1:LeaveFirstPerson()
			end
		end
	end

	str1.SetZoomParameters(arg1.currentSubjectDistance, (math.sign(arg2 - var1)))
	return arg1.currentSubjectDistance
end

tbl1.SetCameraType = function(arg1, arg2)
	arg1.cameraType = arg2
end

tbl1.GetCameraType = function(arg1)
	return arg1.cameraType
end

tbl1.SetCameraMovementMode = function(arg1, arg2)
	arg1.cameraMovementMode = arg2
end

tbl1.GetCameraMovementMode = function(arg1)
	return arg1.cameraMovementMode
end

tbl1.SetIsMouseLocked = function(arg1, arg2)
	arg1.inMouseLockedMode = arg2
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.inMouseLockedMode
end

tbl1.SetMouseLockOffset = function(arg1, arg2)
	arg1.mouseLockOffset = arg2
end

tbl1.GetMouseLockOffset = function(arg1)
	return arg1.mouseLockOffset
end

tbl1.InFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.EnterFirstPerson = function(arg1)
	arg1.inFirstPerson = true
	arg1:UpdateMouseBehavior()
end

tbl1.LeaveFirstPerson = function(arg1)
	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
end

tbl1.GetCameraToSubjectDistance = function(arg1)
	return arg1.currentSubjectDistance
end

tbl1.GetMeasuredDistanceToFocus = function(_)
	local var2 = game.Workspace.CurrentCamera
	if var2 then
		return (var2.CoordinateFrame.p - var2.Focus.p).magnitude
	end

	return nil
end

tbl1.GetCameraLookVector = function(_)
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end

tbl1.CalculateNewLookCFrameFromArg = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 + -1.3962634015954636, var2 + 1.3962634015954636)))
	return CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)
end

tbl1.CalculateNewLookVectorFromArg = function(arg1, arg2, arg3)
	return arg1:CalculateNewLookCFrameFromArg(arg2, arg3).LookVector
end

tbl1.CalculateNewLookVectorVRFromArg = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, 0)
	return ((CFrame.Angles(0, -var1.X, 0) * CFrame.new(Vector3.new(0, 0, 0), ((arg1:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit) * CFrame.Angles(-var1.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end

tbl1.GetHumanoid = function(arg1)
	local var1 = str5
	var1 = var1 and str5.Character
	if var1 then
		local var4 = arg1.humanoidCache[str5]
		if var4 and var4.Parent == var1 then
			return var4
		end

		arg1.humanoidCache[str5] = nil
		local var6 = var1:FindFirstChildOfClass("Humanoid")
		if var6 then
			arg1.humanoidCache[str5] = var6
		end

		return var6
	end

	return nil
end

tbl1.GetHumanoidPartToFollow = function(_, arg2, arg3)
	if arg3 == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			local var4 = var3:FindFirstChild("Head")
			return var4 or arg2.Torso
		end

		return arg2.Torso
	end

	return arg2.Torso
end

tbl1.OnNewCameraSubject = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end
end

tbl1.IsInFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.Update = function(_, _)
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end

tbl1.GetCameraHeight = function(arg1)
	if var4.VREnabled and (not arg1.inFirstPerson) then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Invisicam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("Players")
local var3 = RaycastParams.new()
var3.FilterType = Enum.RaycastFilterType.Exclude
local var4 = RaycastParams.new()
var4.FilterType = Enum.RaycastFilterType.Include
local str2 = "BaseOcclusion"
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = setmetatable({}, var5)
var6.__index = var6
local tbl1 = {
	LIMBS = 2,
	MOVEMENT = 3,
	CORNERS = 4,
	CIRCLE1 = 5,
	CIRCLE2 = 6,
	LIMBMOVE = 7,
	SMART_CIRCLE = 8,
	CHAR_OUTLINE = 9,
}

var6.new = function()
	local var1 = setmetatable(var5.new(), var6)
	var1.char = nil
	var1.humanoidRootPart = nil
	var1.torsoPart = nil
	var1.headPart = nil
	var1.childAddedConn = nil
	var1.childRemovedConn = nil
	var1.behaviors = {}
	var1.behaviors[tbl1.LIMBS] = var1.LimbBehavior
	var1.behaviors[tbl1.MOVEMENT] = var1.MoveBehavior
	var1.behaviors[tbl1.CORNERS] = var1.CornerBehavior
	var1.behaviors[tbl1.CIRCLE1] = var1.CircleBehavior
	var1.behaviors[tbl1.CIRCLE2] = var1.CircleBehavior
	var1.behaviors[tbl1.LIMBMOVE] = var1.LimbMoveBehavior
	var1.behaviors[tbl1.SMART_CIRCLE] = var1.SmartCircleBehavior
	var1.behaviors[tbl1.CHAR_OUTLINE] = var1.CharacterOutlineBehavior
	var1.mode = tbl1.SMART_CIRCLE
	var1.behaviorFunction = var1.SmartCircleBehavior
	var1.savedHits = {}
	var1.trackedLimbs = {}
	var1.camera = game.Workspace.CurrentCamera
	var1.enabled = false
	return var1
end

var6.Enable = function(arg1, arg2)
	arg1.enabled = arg2
	if not arg2 then
		arg1:Cleanup()
	end
end

var6.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Invisicam
end

var6.LimbBehavior = function(arg1, arg2)
	for k1, v1 in pairs(arg1.trackedLimbs) do
		arg2[#arg2 + 1] = k1.Position
	end
end

var6.MoveBehavior = function(arg1, arg2)
	for i1 = 1, 3 do
		local var1 = arg1.humanoidRootPart.Velocity
		arg2[#arg2 + 1] = arg1.humanoidRootPart.Position + (i1 - 1) * arg1.humanoidRootPart.CFrame.lookVector * (Vector3.new(var1.X, 0, var1.Z).Magnitude / 2)
	end
end

local tbl2 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1),
}

var6.CornerBehavior = function(arg1, arg2)
	local var1 = arg1.humanoidRootPart.CFrame
	local var2 = var1.Position
	local var3 = arg1.char:GetExtentsSize() / 2
	arg2[#arg2 + 1] = var2
	for i1 = 1, #tbl2 do
		local var4 = var1 - var2
		arg2[#arg2 + 1] = var2 + var4 * (var3 * tbl2[i1])
	end
end

var6.CircleBehavior = function(arg1, arg2)
	local var2 = nil
	if arg1.mode == tbl1.CIRCLE1 then
		var2 = arg1.humanoidRootPart.CFrame
	else
		local var3 = arg1.camera.CoordinateFrame
		var2 = var3 - var3.Position + arg1.humanoidRootPart.Position
	end

	arg2[#arg2 + 1] = var2.Position
	for i1 = 0, 9 do
		local var4 = 0.62831853071795862 * i1
		arg2[#arg2 + 1] = var2 * (Vector3.new(math.cos(var4), math.sin(var4), 0) * 3)
	end
end

var6.LimbMoveBehavior = function(arg1, arg2)
	arg1:LimbBehavior(arg2)
	arg1:MoveBehavior(arg2)
end

var6.CharacterOutlineBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var3 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var3
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var3
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = CFrame.new(Vector3.new(0, 0, 0), (Vector3.new(arg1.camera.CoordinateFrame.lookVector.X, 0, arg1.camera.CoordinateFrame.lookVector.Z)))
	local var6 = arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position
	local tbl2 = { arg1.torsoPart }
	if arg1.headPart then
		tbl2[#tbl2 + 1] = arg1.headPart
	end

	for i1 = 1, 24 do
		local var7 = 6.2831853071795862 * i1 / 24
		local var8 = var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 3)
		var8 = Vector3.new(var8.X, math.max(var8.Y, -2.25), var8.Z)
		if var1 then
			var4.FilterDescendantsInstances = tbl2
			local var9 = game.Workspace:Raycast(var6 + var8, -3 * var8, var4)
			if not var9 then
				continue
			end

			local var10 = var9.Position
			arg2[#arg2 + 1] = var10 + 0.2 * (var6 - var10).unit
		else
			local var11, var12 = game.Workspace:FindPartOnRayWithWhitelist(Ray.new(var6 + var8, -3 * var8), tbl2, false)
			if not var11 then
				continue
			end

			arg2[#arg2 + 1] = var12 + 0.2 * (var6 - var12).unit
		end
	end
end

local function RayIntersection(arg1, arg2, arg3, arg4)
	local var1 = arg2:Cross(arg4)
	local var2 = -arg4.Y
	local var3 = var1.Z
	local var4 = var1.Y
	local var5 = -arg4.Z
	local var6 = arg2.Y
	local var7 = arg2.Z
	local var9 = arg2.X * (var2 * var3 - var4 * var5) - -arg4.X * (var6 * var3 - var4 * var7) + var1.X * (var6 * var5 - var2 * var7)
	local var10 = arg3.X - arg1.X
	local var11 = arg3.Y - arg1.Y
	local var12 = arg3.Z - arg1.Z
	if var9 == 0 then
		return Vector3.new(0, 0, 0)
	end

	var2 = -arg4.Y
	var5 = var1.Z
	var4 = var1.Y
	var7 = -arg4.Z
	local var13 = (var10 * (var2 * var5 - var4 * var7) - -arg4.X * (var11 * var5 - var4 * var12) + var1.X * (var11 * var7 - var2 * var12)) / var9
	var3 = var1.Z
	var7 = var1.Y
	var4 = arg2.Y
	var5 = arg2.Z
	var6 = arg3 + (arg2.X * (var11 * var3 - var7 * var12) - var10 * (var4 * var3 - var7 * var5) + var1.X * (var4 * var12 - var11 * var5)) / var9 * arg4
	local var14 = arg1 + var13 * arg2
	var2 = var14 + (var6 - var14) * 0.5
	if (var6 - var14).Magnitude < 0.25 then
		return var2
	end

	return Vector3.new(0, 0, 0)
end

var6.SmartCircleBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var4 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var4
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var4
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = arg1.camera.CFrame - arg1.camera.CFrame.p
	local var6 = Vector3.new(0, 0.5, 0) + (arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position)
	for i1 = 1, 24 do
		local var7 = 0.26179938779914941 * i1 - 1.5707963267948966
		local var8 = var6 + var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 2.5)
		local var9 = var8 - arg1.camera.CFrame.p
		if var1 then
			var3.FilterDescendantsInstances = { arg1.char }
			local var16 = game.Workspace:Raycast(var6, var8 - var6, var3)
			local var17 = var8
			if var16 then
				local var18 = var16.Normal
				local var19 = var16.Position + 0.1 * var18.unit
				local var20 = var19 - var6
				local var21 = var20:Cross(var9).unit:Cross(var18).unit
				if var20.unit:Dot(-var21) < var20.unit:Dot((var19 - arg1.camera.CFrame.p).unit) then
					var17 = RayIntersection(var19, var21, var8, var9)
					if 0 < var17.Magnitude then
						var16 = game.Workspace:Raycast(var19, var17 - var19, var3)
						if var16 then
							var17 = var16.Position + 0.1 * var16.Normal.Unit
						end
					else
						var17 = var19
					end
				else
					var17 = var19
				end

				var16 = game.Workspace:Raycast(var6, var17 - var6, var3)
				if var16 then
					var17 = var16.Position - 0.1 * (var17 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var17
		else
			local var28, var29, var30 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var8 - var6), { arg1.char }, false, false)
			local var31 = var8
			if var28 then
				local var32 = var29 + 0.1 * var30.unit
				local var33 = var32 - var6
				local var34 = var33:Cross(var9).unit:Cross(var30).unit
				if var33.unit:Dot(-var34) < var33.unit:Dot((var32 - arg1.camera.CFrame.p).unit) then
					var31 = RayIntersection(var32, var34, var8, var9)
					if 0 < var31.Magnitude then
						local var37, var38, var39 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var32, var31 - var32), { arg1.char }, false, false)
						if var37 then
							var31 = var38 + 0.1 * var39.unit
						end
					else
						var31 = var32
					end
				else
					var31 = var32
				end

				local var41, var42, var43 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var31 - var6), { arg1.char }, false, false)
				if var41 then
					var31 = var42 - 0.1 * (var31 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var31
		end
	end
end

var6.CheckTorsoReference = function(arg1)
	if arg1.char then
		arg1.torsoPart = arg1.char:FindFirstChild("Torso")
		if not arg1.torsoPart then
			arg1.torsoPart = arg1.char:FindFirstChild("UpperTorso")
			if not arg1.torsoPart then
				arg1.torsoPart = arg1.char:FindFirstChild("HumanoidRootPart")
			end
		end

		arg1.headPart = arg1.char:FindFirstChild("Head")
	end
end

str1 = {
	Head = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	LeftLowerArm = true,
	RightLowerArm = true,
	LeftUpperLeg = true,
	RightUpperLeg = true,
}

var6.CharacterAdded = function(arg1, arg2, arg3)
	if arg3 ~= var2.LocalPlayer then
		return
	end

	if arg1.childAddedConn then
		arg1.childAddedConn:Disconnect()
		arg1.childAddedConn = nil
	end

	if arg1.childRemovedConn then
		arg1.childRemovedConn:Disconnect()
		arg1.childRemovedConn = nil
	end

	arg1.char = arg2
	arg1.trackedLimbs = {}
	arg1.childAddedConn = arg2.ChildAdded:Connect(function(arg1)
		if arg1:IsA("BasePart") then
			if str1[arg1.Name] then
				arg1.trackedLimbs[arg1] = true
			end

			if arg1.Name == "Torso" or arg1.Name == "UpperTorso" then
				arg1.torsoPart = arg1
			end

			if arg1.Name == "Head" then
				arg1.headPart = arg1
			end
		end
	end)

	arg1.childRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		arg1.trackedLimbs[arg1] = nil
		arg1:CheckTorsoReference()
	end)

	for k1, v1 in pairs(arg1.char:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if str1[v1.Name] then
			arg1.trackedLimbs[v1] = true
		end

		if v1.Name == "Torso" or v1.Name == "UpperTorso" then
			arg1.torsoPart = v1
		end

		if v1.Name ~= "Head" then
			continue
		end

		arg1.headPart = v1
	end
end

local function AssertTypes(arg1, ...)
	local tbl1 = {}
	local str1 = ""
	for k1, v1 in pairs({ ... }) do
		tbl1[v1] = true
		local var1 = str1
		str1 = var1 .. (if str1 == "" then "" else " or ") .. v1
	end

	local var2 = type(arg1)
	assert(tbl1[var2], str1 .. " type expected, got: " .. var2)
end

var6.SetMode = function(arg1, arg2)
	AssertTypes(arg2, "number")
	for k1, v1 in pairs(tbl1) do
		if v1 ~= arg2 then
			continue
		end

		arg1.mode = arg2
		arg1.behaviorFunction = arg1.behaviors[arg1.mode]
		return
	end

	error("Invalid mode number")
end

var6.GetObscuredParts = function(arg1)
	return arg1.savedHits
end

var6.Cleanup = function(arg1)
	for k1, v1 in pairs(arg1.savedHits) do
		k1.LocalTransparencyModifier = v1
	end
end

var6.Update = function(arg1, _, arg3, arg4)
	if not arg1.enabled or (not arg1.char) then
		return arg3, arg4
	end

	arg1.camera = game.Workspace.CurrentCamera
	if not arg1.humanoidRootPart then
		local var3 = arg1.char:FindFirstChildOfClass("Humanoid")
		if var3 and var3.RootPart then
			arg1.humanoidRootPart = var3.RootPart
		else
			arg1.humanoidRootPart = arg1.char:FindFirstChild("HumanoidRootPart")
			if not arg1.humanoidRootPart then
				return arg3, arg4
			end
		end

		local var4 = nil
		arg1.humanoidRootPart.AncestryChanged:Connect(function(arg1, arg2)
			if arg1 == arg1.humanoidRootPart and (not arg2) then
				arg1.humanoidRootPart = nil
				if var4 and var4.Connected then
					var4:Disconnect()
					var4 = nil
				end
			end
		end)

	end

	if not arg1.torsoPart then
		arg1:CheckTorsoReference()
		if not arg1.torsoPart then
			return arg3, arg4
		end
	end

	local tbl1 = {}
	arg1.behaviorFunction(arg1, tbl1)
	local tbl2 = {}
	local tbl3 = { arg1.char }
	local var5 = nil
	var5 = arg1.camera:GetPartsObscuringTarget({
		arg1.headPart and arg1.headPart.CFrame.p or tbl1[1],
		arg1.torsoPart and arg1.torsoPart.CFrame.p or tbl1[2],
	}, tbl3)

	local num1 = 0
	local tbl4 = {}
	local num2 = 0.75
	local num3 = 0.75
	for i1 = 1, #var5 do
		local var6 = var5[i1]
		tbl4[var6] = true
		num1 = num1 + 1
		for k1, v1 in pairs(var6:GetChildren()) do
			if v1:IsA("Decal") or v1:IsA("Texture") then
				num1 = num1 + 1
				break
			end
		end
	end

	if 0 < num1 then
		num2 = math.pow(0.375 / num1 + 0.375, 1 / num1)
		num3 = math.pow(0.25 / num1 + 0.25, 1 / num1)
	end

	var5 = arg1.camera:GetPartsObscuringTarget(tbl1, tbl3)
	local tbl5 = {}
	for i2 = 1, #var5 do
		local var7 = var5[i2]
		tbl5[var7] = tbl4[var7] and num2 or num3
		if var7.Transparency < tbl5[var7] then
			tbl2[var7] = true
			if not arg1.savedHits[var7] then
				arg1.savedHits[var7] = var7.LocalTransparencyModifier
			end
		end

		for k2, v2 in pairs(var7:GetChildren()) do
			if (v2:IsA("Decal") or v2:IsA("Texture")) and v2.Transparency < tbl5[var7] then
				local var8 = tbl5[var7]
				tbl5[v2] = var8
				tbl2[v2] = true
				if arg1.savedHits[v2] then
					continue
				end

				arg1.savedHits[v2] = v2.LocalTransparencyModifier
			end
		end
	end

	for k3, v3 in pairs(arg1.savedHits) do
		if tbl2[k3] then
			k3.LocalTransparencyModifier = k3.Transparency < 1 and (tbl5[k3] - k3.Transparency) / (1 - k3.Transparency) or 0
		else
			k3.LocalTransparencyModifier = v3
			arg1.savedHits[k3] = nil
		end
	end

	return arg3, arg4
end

return var6

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
setmetatable(tbl1, { __call = function(_, ...)
	return tbl1.new(...)
end })

tbl1.new = function()
	return (setmetatable({}, tbl1))
end

tbl1.CharacterAdded = function(_, _, _)
end

tbl1.CharacterRemoving = function(_, _, _)
end

tbl1.OnCameraSubjectChanged = function(_, _)
end

tbl1.GetOcclusionMode = function(_)
	warn("BaseOcclusion GetOcclusionMode must be overridden by derived classes")
	return nil
end

tbl1.Enable = function(_, _)
	warn("BaseOcclusion Enable must be overridden by derived classes")
end

tbl1.Update = function(_, _, arg3, arg4)
	warn("BaseOcclusion Update must be overridden by derived classes")
	return arg3, arg4
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixOrbitalCameraAzimuth")
local str2 = "CameraUtils"
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
str2 = require(script.Parent:WaitForChild(str4))
local var3 = game:GetService("Players")
str3 = setmetatable({}, str2)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(str2.new(), str3)
	var1.lastUpdate = tick()
	var1.changedSignalConnections = {}
	var1.refAzimuthRad = nil
	var1.curAzimuthRad = nil
	var1.minAzimuthAbsoluteRad = nil
	var1.maxAzimuthAbsoluteRad = nil
	var1.useAzimuthLimits = nil
	var1.curElevationRad = nil
	var1.minElevationRad = nil
	var1.maxElevationRad = nil
	var1.curDistance = nil
	var1.minDistance = nil
	var1.maxDistance = nil
	var1.gamepadDollySpeedMultiplier = 1
	var1.lastUserPanCamera = tick()
	var1.externalProperties = {}
	var1.externalProperties.InitialDistance = 25
	var1.externalProperties.MinDistance = 10
	var1.externalProperties.MaxDistance = 100
	var1.externalProperties.InitialElevation = 35
	var1.externalProperties.MinElevation = 35
	var1.externalProperties.MaxElevation = 35
	var1.externalProperties.ReferenceAzimuth = -45
	var1.externalProperties.CWAzimuthTravel = 90
	var1.externalProperties.CCWAzimuthTravel = 90
	var1.externalProperties.UseAzimuthLimits = false
	var1:LoadNumberValueParameters()
	return var1
end

str3.LoadOrCreateNumberValueParameter = function(arg1, arg2, arg3, arg4)
	local var2 = script:FindFirstChild(arg2)
	if var2 and var2:IsA(arg3) then
		arg1.externalProperties[arg2] = var2.Value
	else
		if arg1.externalProperties[arg2] ~= nil then
			var2 = Instance.new(arg3)
			var2.Name = arg2
			var2.Parent = script
			var2.Value = arg1.externalProperties[arg2]
		else
			return
		end
	end

	if arg4 then
		if arg1.changedSignalConnections[arg2] then
			arg1.changedSignalConnections[arg2]:Disconnect()
		end

		arg1.changedSignalConnections[arg2] = var2.Changed:Connect(function(arg1)
			arg1.externalProperties[arg2] = arg1
			arg4(arg1)
		end)

	end
end

str3.SetAndBoundsCheckAzimuthValues = function(arg1)
	arg1.minAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) - math.abs((math.rad(arg1.externalProperties.CWAzimuthTravel)))
	arg1.maxAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) + math.abs((math.rad(arg1.externalProperties.CCWAzimuthTravel)))
	arg1.useAzimuthLimits = arg1.externalProperties.UseAzimuthLimits
	if arg1.useAzimuthLimits then
		local var1 = math.max(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
		var1 = math.min(arg1.curAzimuthRad, arg1.maxAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
	end
end

str3.SetAndBoundsCheckElevationValues = function(arg1)
	local var1 = math.max(arg1.externalProperties.MinElevation, -80)
	local var2 = math.min(arg1.externalProperties.MaxElevation, 80)
	arg1.minElevationRad = math.rad((math.min(var1, var2)))
	arg1.maxElevationRad = math.rad((math.max(var1, var2)))
	local var3 = math.max(arg1.curElevationRad, arg1.minElevationRad)
	arg1.curElevationRad = var3
	var3 = math.min(arg1.curElevationRad, arg1.maxElevationRad)
	arg1.curElevationRad = var3
end

str3.SetAndBoundsCheckDistanceValues = function(arg1)
	arg1.minDistance = arg1.externalProperties.MinDistance
	arg1.maxDistance = arg1.externalProperties.MaxDistance
	local var1 = math.max(arg1.curDistance, arg1.minDistance)
	arg1.curDistance = var1
	var1 = math.min(arg1.curDistance, arg1.maxDistance)
	arg1.curDistance = var1
end

str3.LoadNumberValueParameters = function(arg1)
	arg1:LoadOrCreateNumberValueParameter("InitialElevation", "NumberValue", nil)
	arg1:LoadOrCreateNumberValueParameter("InitialDistance", "NumberValue", nil)
	local str1 = "ReferenceAzimuth"
	local str2 = "NumberValue"
	arg1:LoadOrCreateNumberValueParameter(str1, str2, if var1 then arg1.SetAndBoundsCheckAzimuthValues else arg1.SetAndBoundsCheckAzimuthValue)
	arg1:LoadOrCreateNumberValueParameter("CWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("CCWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("MinElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MaxElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MinDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("MaxDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("UseAzimuthLimits", "BoolValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1.curAzimuthRad = math.rad(arg1.externalProperties.ReferenceAzimuth)
	arg1.curElevationRad = math.rad(arg1.externalProperties.InitialElevation)
	arg1.curDistance = arg1.externalProperties.InitialDistance
	arg1:SetAndBoundsCheckAzimuthValues()
	arg1:SetAndBoundsCheckElevationValues()
	arg1:SetAndBoundsCheckDistanceValues()
end

str3.GetModuleName = function(_)
	return "OrbitalCamera"
end

str3.SetInitialOrientation = function(arg1, arg2)
	if not arg2 or (not arg2.RootPart) then
		warn("OrbitalCamera could not set initial orientation due to missing humanoid")
		return
	end

	assert(arg2.RootPart, "")
	local var1 = (arg2.RootPart.CFrame.LookVector - Vector3.new(0, 0.23, 0)).Unit
	local var2 = math.asin(arg1:GetCameraLookVector().Y) - math.asin(var1.Y)
	if not str1.IsFinite((str1.GetAngleBetweenXZVectors(var1, arg1:GetCameraLookVector()))) then
	end

	if not str1.IsFinite(var2) then
	end
end

str3.GetCameraToSubjectDistance = function(arg1)
	return arg1.curDistance
end

str3.SetCameraToSubjectDistance = function(arg1, arg2)
	if var3.LocalPlayer then
		arg1.currentSubjectDistance = math.clamp(arg2, arg1.minDistance, arg1.maxDistance)
		local var1 = math.max(arg1.currentSubjectDistance, arg1.FIRST_PERSON_DISTANCE_THRESHOLD)
		arg1.currentSubjectDistance = var1
	end

	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
	return arg1.currentSubjectDistance
end

str3.CalculateNewLookVector = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 - 1.3962634015954636, var2 - -1.3962634015954636)))
	return (CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)).LookVector
end

str3.Update = function(arg1, arg2)
	local var1 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4
	var5 = var5 and var4.CameraSubject
	local var6 = var5
	local var7 = var5
	local var8 = var2.getRotation(arg2) ~= Vector2.new()
	local var9 = var4.CFrame
	local var10 = var4.Focus
	local var11 = var3.LocalPlayer
	var6 = var6 and var5:IsA("VehicleSeat")
	var7 = var7 and var5:IsA("SkateboardPlatform")
	if arg1.lastUpdate == nil or 1 < var1 - arg1.lastUpdate then
		arg1.lastCameraTransform = nil
	end

	if var8 then
		arg1.lastUserPanCamera = tick()
	end

	local var13 = arg1:GetSubjectPosition()
	if var13 then
		if var11 then
			if var4 then
				if arg1.gamepadDollySpeedMultiplier ~= 1 then
					arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance * arg1.gamepadDollySpeedMultiplier)
				end

				local var14 = var2.getRotation(arg2)
				var10 = CFrame.new(var13)
				local var15 = arg1.curAzimuthRad - var14.X
				arg1.curAzimuthRad = var15
				if arg1.useAzimuthLimits then
					var15 = math.clamp(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad, arg1.maxAzimuthAbsoluteRad)
					arg1.curAzimuthRad = var15
				else
					if arg1.curAzimuthRad ~= 0 then
						var15 = math.sign(arg1.curAzimuthRad) * (math.abs(arg1.curAzimuthRad) % 6.2831853071795862)
						var15 = var15 or 0
					end

					arg1.curAzimuthRad = 0
				end

				var15 = math.clamp(arg1.curElevationRad + var14.Y, arg1.minElevationRad, arg1.maxElevationRad)
				arg1.curElevationRad = var15
				var9 = CFrame.new(var13 + arg1.currentSubjectDistance * (CFrame.fromEulerAnglesYXZ(-arg1.curElevationRad, arg1.curAzimuthRad, 0) * Vector3.new(0, 0, 1)), var13)
				arg1.lastCameraTransform = var9
				arg1.lastCameraFocus = var10
				if (var6 or var7) and var5:IsA("BasePart") then
					arg1.lastSubjectCFrame = var5.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var1
	return var9, var10
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraInput [ModuleScript]
-- y u r i

game:GetService("RunService")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Instance.new("BindableEvent")
local var3 = nil
local var4 = Instance.new("BindableEvent")
local var5 = nil
local var6 = game:GetService("UserInputService")
var6.InputBegan:Connect(function(arg1, arg2)
	if not arg2 and arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var2:Fire()
	end
end)

var6.InputEnded:Connect(function(arg1, _)
	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var4:Fire()
	end
end)

var3 = var2.Event
var2 = nil
var5 = var4.Event
local var7 = game:GetService("Players").LocalPlayer
local num1 = 0
local var8 = game:GetService("ContextActionService")
local var9 = UserSettings():GetService("UserGameSettings")
local var10 = game:GetService("VRService")
local var11 = game:GetService("GuiService")
local var12 = var1.getUserFlag("UserPSSinkUnknownTouchEvents")
local var13 = var1.getUserFlag("UserPSTextboxResetCameraInput")
str1 = var1.getUserFlag("UserFixVRCameraGamepadReset")
local var14 = var1.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local var15 = Vector2.new(1, 0.77) * 0.069813170079773182 * 60
local var16 = Vector2.new(1, 0.77) * 0.0087266462599716477
local var17 = Vector2.new(1, 0.77) * 0.12217304763960307
local var18 = Vector2.new(1, 0.66) * 0.017453292519943295
local tbl1 = { Thumbstick2 = Vector2.new(), ButtonLeft = 0, ButtonRight = 0 }
local tbl2 = { Movement = Vector2.new(), Wheel = 0, Pinch = 0 }
tbl2.Pan = Vector2.new()
local var19 = Instance.new("BindableEvent")
local tbl3 = { Move = Vector2.new(), Pinch = 0 }
local var21 = Enum.ContextActionPriority.Medium.Value
var2 = function(arg1)
	return math.sign(arg1) * math.clamp((math.exp((math.abs(arg1) - 0.1) / 0.9 * 2) - 1) / 6.3890560989306504, 0, 1)
end

var4 = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return arg1
	end

	local var3 = var2.CFrame:ToEulerAnglesYXZ()
	if 0 <= arg1.Y * var3 then
		return arg1
	end

	return Vector2.new(1, (1 - (math.abs(var3) * 2 / 3.1415926535897931) ^ 0.75) * 0.75 + 0.25) * arg1
end

local function isInDynamicThumbstickArea(arg1)
	local var1 = var7:FindFirstChildOfClass("PlayerGui")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TouchGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("TouchControlFrame")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("DynamicThumbstickFrame")
	if not var4 then
		return false
	end

	if not var2.Enabled then
		return false
	end

	local var5 = var4.AbsolutePosition
	local var8 = var5 + var4.AbsoluteSize
	local bool2 = false
	if var5.X <= arg1.X then
		bool2 = false
		if var5.Y <= arg1.Y then
			bool2 = false
			if arg1.X <= var8.X then
				bool2 = arg1.Y <= var8.Y
			end
		end
	end

	return bool2
end

local function incPanInputCount()
	local var1 = math.max(0, num1 + 1)
	num1 = var1
end

local function decPanInputCount()
	local var1 = math.max(0, num1 - 1)
	num1 = var1
end

local function resetPanInputCount()
	num1 = 0
end

local var22 = nil
local tbl4 = { gamepadZoomPress = var19.Event }
local tbl5 = {}
local tbl6 = { Left = 0, Right = 0, I = 0, O = 0 }
if str1 then
	var22 = Instance.new("BindableEvent")
	tbl4.gamepadReset = var22.Event
else
	var22 = var10.VREnabled and Instance.new("BindableEvent") or nil
	if var10.VREnabled then
		tbl4.gamepadReset = var22.Event
	end
end

tbl4.getRotationActivated = function()
	if var14 then
		local bool3 = true
		if 0 >= num1 then
			bool3 = true
			if 0 >= tbl1.Thumbstick2.Magnitude then
				bool3 = tbl1.ButtonRight - tbl1.ButtonLeft ~= 0
			end
		end

		return bool3
	end

	local bool4 = true
	if 0 >= num1 then
		bool4 = 0 < tbl1.Thumbstick2.Magnitude
	end

	return bool4
end

tbl4.getRotation = function(arg1, arg2)
	local var2 = Vector2.new(1, var9:GetCameraYInvertValue())
	local var3 = Vector2.new(tbl6.Right - tbl6.Left, 0) * arg1
	local var5 = nil
	var5 = if var14 then (tbl1.Thumbstick2 + Vector2.new(tbl1.ButtonRight - tbl1.ButtonLeft, 0)) * var9.GamepadCameraSensitivity * arg1 else tbl1.Thumbstick2 * var9.GamepadCameraSensitivity * arg1
	local var6 = tbl2.Movement
	local var7 = tbl2.Pan
	local var8 = var4(tbl3.Move)
	if arg2 then
		var3 = Vector2.new()
	end

	return (var3 * 2.0943951023931953 + var5 * var15 + var6 * var16 + var7 * var17 + var8 * var18) * var2
end

tbl4.getZoomDelta = function()
	return (tbl6.O - tbl6.I) * 0.1 + (-tbl2.Wheel + tbl2.Pinch) * 1 + -tbl3.Pinch * 0.04
end

local var23 = nil
local tbl7 = {}
local var24 = nil
local var25 = nil
local var26 = nil
local var27 = nil
local var28 = nil
var24 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Begin)
	if var23 == nil and (isInDynamicThumbstickArea(arg1.Position) and (not arg2)) then
		var23 = arg1
		return
	end

	if not arg2 then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end

	tbl7[arg1] = arg2
end

var27 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Change)
	if arg1 == var23 then
		return
	end

	if tbl7[arg1] == nil then
		if var12 then
			tbl7[arg1] = true
		else
			tbl7[arg1] = arg2
		end
	end

	local tbl1 = {}
	for k1, v1 in pairs(tbl7) do
		if v1 then
			continue
		end

		table.insert(tbl1, k1)
	end

	if #tbl1 == 1 and tbl7[arg1] == false then
		local var3 = tbl3
		local var4 = arg1.Delta
		local var5 = var3.Move + Vector2.new(var4.X, var4.Y)
		var3.Move = var5
	end

	if #tbl1 == 2 then
		local var10 = (tbl1[1].Position - tbl1[2].Position).Magnitude
		if var25 then
			local var11 = tbl3
			local var13 = var11.Pinch + (var10 - var25)
			var11.Pinch = var13
		end

		var25 = var10
		return
	end

	var25 = nil
end

var26 = function(arg1, _)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.End)
	if arg1 == var23 then
		var23 = nil
	end

	if tbl7[arg1] == false then
		var25 = nil
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end

	tbl7[arg1] = nil
end

local bool1 = false
local function resetInputDevices()
	local var1 = tbl6
	for k1, v1 in pairs({ tbl1, var1, tbl2, tbl3 }) do
		for k2, v2 in pairs(v1) do
			if type(v2) == "boolean" then
				v1[k2] = false
			else
				local var2 = v1[k2] * 0
				v1[k2] = var2
			end
		end
	end

	num1 = 0
end

var28 = function()
	tbl7 = {}
	var23 = nil
	var25 = nil
	num1 = 0
end

local function thumbstick(_, _, arg3)
	local var1 = arg3.Position
	tbl1[arg3.KeyCode.Name] = Vector2.new(var2(var1.X), -var2(var1.Y))
	return Enum.ContextActionResult.Pass
end

local function directionalButtons(_, arg2, arg3)
	if arg2 == Enum.UserInputState.Cancel then
		tbl1[arg3.KeyCode.Name] = 0
	else
		tbl1[arg3.KeyCode.Name] = var2(arg3.Position.Z)
	end

	return Enum.ContextActionResult.Pass
end

local function keypress(_, arg2, arg3)
	local var1 = tbl6
	local var2 = arg3.KeyCode.Name
	var1[var2] = if arg2 == Enum.UserInputState.Begin then 1 else 0
end

local function gamepadReset(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var22:Fire()
	end
end

local function gamepadZoomPress(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var19:Fire()
	end
end

var23 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var24(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 and (not arg2) then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end
end

var25 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var27(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement then
		local var2 = arg1.Delta
		tbl2.Movement = Vector2.new(var2.X, var2.Y)
	end
end

local function inputEnded(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var26(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end
end

tbl7 = function(arg1, arg2, arg3, arg4)
	if not arg4 then
		tbl2.Wheel = arg1
		tbl2.Pan = arg2
		tbl2.Pinch = -arg3
	end
end

tbl4.setInputEnabled = function(arg1)
	if bool1 == arg1 then
		return
	end

	bool1 = arg1
	resetInputDevices()
	var28()
	local var1
	if bool1 then
		var8:BindActionAtPriority("RbxCameraThumbstick", thumbstick, false, var21, Enum.KeyCode.Thumbstick2)
		if var14 then
			var8:BindActionAtPriority("RbxCameraDirectionalButtons", directionalButtons, false, var21, Enum.KeyCode.ButtonLeft, Enum.KeyCode.ButtonRight)
		end

		var8:BindActionAtPriority("RbxCameraKeypress", keypress, false, var21, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.I, Enum.KeyCode.O)
		if var10.VREnabled then
			var8:BindAction("RbxCameraGamepadReset", gamepadReset, false, Enum.KeyCode.ButtonL3)
		end

		var8:BindAction("RbxCameraGamepadZoom", gamepadZoomPress, false, Enum.KeyCode.ButtonR3)
		var1 = var23
		table.insert(tbl5, var6.InputBegan:Connect(var1))
		var1 = var25
		table.insert(tbl5, var6.InputChanged:Connect(var1))
		var1 = inputEnded
		table.insert(tbl5, var6.InputEnded:Connect(var1))
		var1 = tbl7
		table.insert(tbl5, var6.PointerAction:Connect(var1))
		var1 = var28
		table.insert(tbl5, var11.MenuOpened:connect(var1))
		return
	end

	var8:UnbindAction("RbxCameraThumbstick")
	if var14 then
		var8:UnbindAction("RbxCameraDirectionalButtons")
	end

	var8:UnbindAction("RbxCameraMouseMove")
	var8:UnbindAction("RbxCameraMouseWheel")
	var8:UnbindAction("RbxCameraKeypress")
	var8:UnbindAction("RbxCameraGamepadZoom")
	if var10.VREnabled then
		var8:UnbindAction("RbxCameraGamepadReset")
	end

	for k1, v1 in pairs(tbl5) do
		v1:Disconnect()
	end

	tbl5 = {}
end

tbl4.getInputEnabled = function()
	return bool1
end

tbl4.resetInputForFrameEnd = function()
	tbl2.Movement = Vector2.new()
	tbl3.Move = Vector2.new()
	tbl3.Pinch = 0
	tbl2.Wheel = 0
	tbl2.Pan = Vector2.new()
	tbl2.Pinch = 0
end

var6.WindowFocused:Connect(resetInputDevices)
var6.WindowFocusReleased:Connect(resetInputDevices)
if var13 then
	var6.TextBoxFocusReleased:Connect(resetInputDevices)
end

tbl5 = false
tbl4.getHoldPan = function()
	return tbl5
end

num1 = false
tbl4.getTogglePan = function()
	return num1
end

tbl4.getPanning = function()
	local var1 = num1
	return var1 or tbl5
end

tbl4.setTogglePan = function(arg1)
	num1 = arg1
end

decPanInputCount = false
resetPanInputCount = nil
tbl1 = nil
incPanInputCount = 0
tbl4.enableCameraToggleInput = function()
	if decPanInputCount then
		return
	end

	decPanInputCount = true
	tbl5 = false
	num1 = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
	end

	if tbl1 then
		tbl1:Disconnect()
	end

	resetPanInputCount = var3:Connect(function()
		tbl5 = true
		incPanInputCount = tick()
	end)

	tbl1 = var5:Connect(function()
		tbl5 = false
		if tick() - incPanInputCount < 0.3 and (num1 or var6:GetMouseDelta().Magnitude < 2) then
			local var1 = not num1
			num1 = var1
		end
	end)
end

tbl4.disableCameraToggleInput = function()
	if not decPanInputCount then
		return
	end

	decPanInputCount = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
		resetPanInputCount = nil
	end

	if tbl1 then
		tbl1:Disconnect()
		tbl1 = nil
	end
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Poppercam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local str2 = "ZoomController"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag
local var2 = require(script.Parent:WaitForChild(str2))
var1 = var1("UserFixCameraFPError")
str1 = {}
str1.__index = str1
str2 = CFrame.new()
str1.new = function()
	return (setmetatable({ lastCFrame = nil }, str1))
end

str1.Step = function(arg1, arg2, arg3)
	local var1 = arg1.lastCFrame or arg3
	arg1.lastCFrame = arg3
	local var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13 = arg3:GetComponents()
	local var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25 = var1:GetComponents()
	local var26 = arg3.Position
	local var27 = CFrame.new(0, 0, 0, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	local var28, var29 = (var27 * CFrame.new(0, 0, 0, var17, var18, var19, var20, var21, var22, var23, var24, var25):inverse()):ToAxisAngle()
	var14 = (var26 - var1.p) / arg2
	var15 = var28 * var29 / arg2
	return {
		extrapolate = function(arg1)
			local var1 = var15 * arg1
			local var3 = var1.Magnitude
			local var4 = var14 * arg1 + var26
			return (if 1e-05 < var3 then CFrame.fromAxisAngle(var1, var3) else str2) * var27 + var4
		end,
		posVelocity = var14,
		rotVelocity = var15,
	}
end

str1.Reset = function(arg1)
	arg1.lastCFrame = nil
end

local function cframeToAxis(arg1)
	local var1, var2 = arg1:ToAxisAngle()
	return var1 * var2
end

local function extractRotation(arg1)
	local var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12 = arg1:GetComponents()
	local num1 = 0
	local num2 = 0
	local num3 = 0
	local var13 = var4
	local var14 = var5
	local var15 = var6
	local var16 = var7
	local var17 = var8
	local var18 = var9
	local var19 = var10
	local var20 = var11
	local var21 = var12
	return CFrame.new(num1, num2, num3, var13, var14, var15, var16, var17, var18, var19, var20, var21)
end

extractRotation = "BaseOcclusion"
local function axisToCFrame(arg1)
	local var4 = arg1.Magnitude
	if 1e-05 < var4 then
		local var5 = arg1
		local var6 = var4
		return CFrame.fromAxisAngle(var5, var6)
	end

	return str2
end

str2 = require(script.Parent:WaitForChild(extractRotation))
cframeToAxis = setmetatable({}, str2)
cframeToAxis.__index = cframeToAxis
cframeToAxis.new = function()
	local var1 = setmetatable(str2.new(), cframeToAxis)
	var1.focusExtrapolator = str1.new()
	return var1
end

cframeToAxis.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Zoom
end

cframeToAxis.Enable = function(arg1, _)
	arg1.focusExtrapolator:Reset()
end

cframeToAxis.Update = function(arg1, arg2, arg3, arg4, _)
	local var4 = nil
	var4 = if var1 then CFrame.lookAlong(arg4.p, -arg3.LookVector) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1) else CFrame.new(arg4.p, arg3.p) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	return var4 * CFrame.new(0, 0, (var2.Update(arg2, var4, (arg1.focusExtrapolator:Step(arg2, var4))))), arg4
end

cframeToAxis.CharacterAdded = function(_, _, _)
end

cframeToAxis.CharacterRemoving = function(_, _, _)
end

cframeToAxis.OnCameraSubjectChanged = function(_, _)
end

return cframeToAxis

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera [ModuleScript]
-- y u r i

local str1 = "BaseCamera"
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local str4 = "ZoomController"
require(script.Parent:WaitForChild(str4))
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "VehicleCameraCore"
local str6 = "VehicleCameraConfig"
str2 = require(script:WaitForChild(str5))
str3 = require(script:WaitForChild(str6))
local num1 = 0.016666666666666666
game:GetService("RunService").Stepped:Connect(function(_, arg2)
	num1 = arg2
end)

str4 = game:GetService("Players").LocalPlayer
local var4 = setmetatable({}, var1)
var4.__index = var4
var4.new = function()
	local var2 = setmetatable(var1.new(), var4)
	var2:Reset()
	return var2
end

str6 = var3.Spring
local tbl1 = { 0, 15, 30 }
var4.Reset = function(arg1)
	local var1 = str2.new(arg1:GetSubjectCFrame())
	arg1.vehicleCameraCore = var1
	arg1.pitchSpring = str6.new(0, -math.rad(str3.pitchBaseAngle))
	arg1.yawSpring = str6.new(0, 0)
	arg1.lastPanTick = 0
	var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var4, var5 = var3.getLooseBoundingSphere((var2:GetConnectedParts(true)))
	arg1.assemblyRadius = math.max(var5, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var4
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.assemblyRadius / 10)
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

local var5 = var3.sanitizeAngle
local var6 = var3.mapClamp
var4._StepRotation = function(arg1, arg2, arg3)
	local var1 = var2.getRotation(arg2, true)
	local var3 = arg1.yawSpring
	local var4 = var5(var3.pos + -var1.X)
	var3.pos = var4
	local var7 = arg1.pitchSpring
	var4 = var5((math.clamp(var7.pos + -var1.Y, -1.3962634015954636, 1.3962634015954636)))
	var7.pos = var4
	if var2.getRotationActivated() then
		arg1.lastPanTick = os.clock()
	end

	var4 = -math.rad(str3.pitchBaseAngle)
	local var8 = math.rad(str3.pitchDeadzoneAngle)
	if str3.autocorrectDelay < os.clock() - arg1.lastPanTick then
		local var9 = var6(arg3, str3.autocorrectMinCarSpeed, str3.autocorrectMaxCarSpeed, 0, str3.autocorrectResponse)
		var3.freq = var9
		var7.freq = var9
		if var3.freq < 0.001 then
			var3.vel = 0
		end

		if var7.freq < 0.001 then
			var7.vel = 0
		end

		if math.abs((var5(var4 - var7.pos))) <= var8 then
			var7.goal = var7.pos
		else
			var7.goal = var4
		end
	else
		var3.freq = 0
		var3.vel = 0
		var7.freq = 0
		var7.vel = 0
		var7.goal = var4
	end

	local var10 = var7:step(arg2)
	local var11 = var3:step(arg2)
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var10, var11, num1)
end

var4._GetThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * str3.verticalCenterOffset, 0)
end

var4._GetFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = str4.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_GetThirdPersonLocalOffset()
end

var4.Update = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var3 = num1
	num1 = 0
	local var4 = arg1:GetSubjectCFrame()
	str1 = arg1:GetSubjectRotVelocity()
	local var5 = arg1:StepZoom()
	local var7 = var6(var5, 0.5, arg1.assemblyRadius, 1, 0)
	local var8 = arg1.vehicleCameraCore
	var8:setTransform(var4)
	local var9 = CFrame.new(var4 * arg1:_GetThirdPersonLocalOffset():Lerp(arg1:_GetFirstPersonLocalOffset(var4), var7)) * var8:step(var3, math.abs((var4.XVector:Dot(str1))), math.abs((var4.YVector:Dot(str1))), var7) * arg1:_StepRotation(var3, (math.abs((arg1:GetSubjectVelocity():Dot(var4.ZVector)))))
	return var9 * CFrame.new(0, 0, var5), var9
end

var4.ApplyVRTransform = function(_)
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig [ModuleScript]
-- y u r i

return {
	pitchStiffness = 0.5,
	yawStiffness = 2.5,
	autocorrectDelay = 1,
	autocorrectMinCarSpeed = 16,
	autocorrectMaxCarSpeed = 32,
	autocorrectResponse = 0.5,
	cutoffMinAngularVelYaw = 60,
	cutoffMaxAngularVelYaw = 180,
	cutoffMinAngularVelPitch = 15,
	cutoffMaxAngularVelPitch = 60,
	pitchBaseAngle = 18,
	pitchDeadzoneAngle = 12,
	firstPersonResponseMul = 10,
	yawReponseDampingRising = 1,
	yawResponseDampingFalling = 3,
	pitchReponseDampingRising = 1,
	pitchResponseDampingFalling = 3,
	verticalCenterOffset = 0.33,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.CameraUtils)
local var2 = var1.sanitizeAngle
local var3 = require(script.Parent.VehicleCameraConfig)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	return (setmetatable({ fRising = arg1, fFalling = arg2, g = arg3, p = arg3, v = arg3 * 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.v
	local var2 = arg1.g
	local var3 = 6.2831853071795862 * (0 < var1 and arg1.fRising or arg1.fFalling)
	local var4 = arg1.p - var2
	local var5 = math.exp(-var3 * arg2)
	local var6 = (var4 * (1 + var3 * arg2) + var1 * arg2) * var5 + var2
	arg1.p = var6
	arg1.v = (var1 * (1 - var3 * arg2) - var4 * (var3 * var3 * arg2)) * var5
	return var6
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function(arg1)
	assert(typeof(arg1) == "CFrame")
	local var1, var4 = arg1:toEulerAnglesYXZ()
	local var5, var6 = arg1:toEulerAnglesYXZ()
	local tbl3 = { yawG = var2(var4), yawV = 0, pitchV = 0 }
	tbl3.yawP = var2(var6)
	tbl3.pitchG = var2((arg1:toEulerAnglesYXZ()))
	tbl3.pitchP = var2((arg1:toEulerAnglesYXZ()))
	tbl3.fSpringYaw = tbl1.new(var3.yawReponseDampingRising, var3.yawResponseDampingFalling, 0)
	tbl3.fSpringPitch = tbl1.new(var3.pitchReponseDampingRising, var3.pitchResponseDampingFalling, 0)
	return (setmetatable(tbl3, tbl2))
end

tbl2.setGoal = function(arg1, arg2)
	assert(typeof(arg2) == "CFrame")
	local var1, var3 = arg2:toEulerAnglesYXZ()
	arg1.yawG = var2(var3)
	arg1.pitchG = var2((arg2:toEulerAnglesYXZ()))
end

tbl2.getCFrame = function(arg1)
	local var1 = arg1.pitchP
	local var2 = arg1.yawP
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var1, var2, num1)
end

local var4 = var1.mapClamp
local var5 = var1.map
tbl2.step = function(arg1, arg2, arg3, arg4, arg5)
	assert(typeof(arg2) == "number")
	assert(typeof(arg4) == "number")
	assert(typeof(arg3) == "number")
	assert(typeof(arg5) == "number")
	local var1 = arg1.fSpringYaw
	var1.g = var4(var5(arg5, 0, 1, arg4, 0), math.rad(var3.cutoffMinAngularVelYaw), math.rad(var3.cutoffMaxAngularVelYaw), 1, 0)
	local var6 = arg1.fSpringPitch
	var6.g = var4(var5(arg5, 0, 1, arg3, 0), math.rad(var3.cutoffMinAngularVelPitch), math.rad(var3.cutoffMaxAngularVelPitch), 1, 0)
	local var7 = arg1.yawG
	local var8 = 6.2831853071795862 * var3.yawStiffness * var1:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var9 = var2(arg1.yawP - var7)
	local var10 = arg1.yawV
	local var11 = math.exp(-var8 * arg2)
	local var12 = 6.2831853071795862 * var3.pitchStiffness * var6:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var13 = var2((var9 * (1 + var8 * arg2) + var10 * arg2) * var11 + var7)
	arg1.yawP = var13
	arg1.yawV = (var10 * (1 - var8 * arg2) - var9 * (var8 * var8 * arg2)) * var11
	var7 = arg1.pitchG
	var9 = var2(arg1.pitchP - var7)
	var10 = arg1.pitchV
	var11 = math.exp(-var12 * arg2)
	var13 = var2((var9 * (1 + var12 * arg2) + var10 * arg2) * var11 + var7)
	arg1.pitchP = var13
	arg1.pitchV = (var10 * (1 - var12 * arg2) - var9 * (var12 * var12 * arg2)) * var11
	return arg1:getCFrame()
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.new = function(arg1)
	return (setmetatable({ vrs = tbl2.new(arg1) }, tbl3))
end

tbl3.step = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg2
	local var2 = arg3
	local var3 = arg4
	local var4 = arg5
	return arg1.vrs:step(var1, var2, var3, var4)
end

tbl3.setTransform = function(arg1, arg2)
	arg1.vrs:setGoal(arg2)
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUI [ModuleScript]
-- y u r i

local bool1 = false
local tbl1 = {}
local var1 = game:GetService("StarterGui")
tbl1.setCameraModeToastEnabled = function(arg1)
	if not arg1 and (not bool1) then
		return
	end

	if not bool1 then
		bool1 = true
	end

	if not arg1 then
		tbl1.setCameraModeToastOpen(false)
	end
end

tbl1.setCameraModeToastOpen = function(arg1)
	assert(bool1)
	if arg1 then
		var1:SetCore("SendNotification", { Title = "Camera Control Enabled", Text = "Right click to toggle", Duration = 3 })
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
script.Parent:WaitForChild("CommonUtils")
local str1 = "Keyboard"
local str2 = "Gamepad"
local var1 = require(script:WaitForChild(str1))
local str3 = "DynamicThumbstick"
local var2 = require(script:WaitForChild(str2))
local var3 = require(script:WaitForChild(str3))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local str4 = "TouchThumbstick"
local str5 = "ClickToMoveController"
success = require(script:WaitForChild(str4))
local str6 = "TouchJump"
result = require(script:WaitForChild(str5))
local str7 = "VehicleController"
local var4 = require(script:WaitForChild(str6))
str4 = require(script:WaitForChild(str7))
local success, result = pcall(function()
	local str1 = "UserPlayerScriptsSupportMicroGamepad"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str5 = nil
str5 = success and result
local var5 = game:GetService("Players")
local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("GuiService")
local var9 = game:GetService("Workspace")
local var10 = UserSettings():GetService("UserGameSettings")
local var11 = game:GetService("VRService")
success = Enum.ContextActionPriority.Medium.Value
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.controllers = {}
	var1.activeControlModule = nil
	var1.activeController = nil
	var1.touchJumpController = nil
	var1.moveFunction = var5.LocalPlayer.Move
	var1.humanoid = nil
	var1.controlsEnabled = true
	var1.humanoidSeatedConn = nil
	var1.vehicleController = nil
	var1.touchControlFrame = nil
	var1.currentTorsoAngle = 0
	var1.inputMoveVector = Vector3.new(0, 0, 0)
	var1.vehicleController = str4.new(success)
	var5.LocalPlayer.CharacterAdded:Connect(function(arg1)
		var1:OnCharacterAdded(arg1)
	end)

	var5.LocalPlayer.CharacterRemoving:Connect(function(arg1)
		var1:OnCharacterRemoving(arg1)
	end)

	if var5.LocalPlayer.Character then
		var1:OnCharacterAdded(var5.LocalPlayer.Character)
	end

	var6:BindToRenderStep("ControlScriptRenderstep", Enum.RenderPriority.Input.Value, function(arg1)
		var1:OnRenderStepped(arg1)
	end)

	var10:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var10:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = nil
	var1.touchGui = nil
	var1.playerGuiAddedConn = nil
	var8:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		var1:UpdateMovementMode()
		var1:UpdateActiveControlModuleEnabled()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = var5.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not var1.playerGui then
		var1.playerGuiAddedConn = var5.LocalPlayer.ChildAdded:Connect(function(arg1)
			if arg1:IsA("PlayerGui") then
				var1.playerGui = arg1
				var1.playerGuiAddedConn:Disconnect()
				var1.playerGuiAddedConn = nil
				var1:UpdateMovementMode()
			end
		end)

	end

	var1:UpdateMovementMode()
	return var1
end

tbl1.GetMoveVector = function(arg1)
	if arg1.activeController then
		return arg1.activeController:GetMoveVector()
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetEstimatedVRTorsoFrame = function(arg1)
	local var1 = var11:GetUserCFrame(Enum.UserCFrame.Head)
	local var2, var3, var4 = var1:ToEulerAnglesYXZ()
	var3 = -var3
	if not var11:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) or (not var11:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)) then
		arg1.currentTorsoAngle = var3
	else
		local var5 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.LeftHand).Position
		local var6 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.RightHand).Position
		local var7 = -math.atan2(var5.X, var5.Z)
		local var9 = (-math.atan2(var6.X, var6.Z) - var7 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var12 = (var7 + var9 / 2 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var12 then
			var12 = var12 - 6.2831853071795862
		end

		var9 = (var3 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var14 = (var12 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var14 then
			var14 = var14 - 6.2831853071795862
		end

		local bool1 = false
		if -1.5707963267948966 < var14 then
			bool1 = var14 < 1.5707963267948966
		end

		if not bool1 then
			var14 = var9
		end

		local var16 = math.min(var14, var9)
		local var17 = math.max(var14, var9)
		local num2 = 0
		if 0 < var16 then
			num2 = var16
		else
			if var17 < 0 then
				num2 = var17
			end
		end

		local var18 = num2 + arg1.currentTorsoAngle
		arg1.currentTorsoAngle = var18
	end

	return CFrame.new(var1.Position) * CFrame.fromEulerAnglesYXZ(0, -arg1.currentTorsoAngle, 0)
end

tbl1.GetActiveController = function(arg1)
	return arg1.activeController
end

tbl1.UpdateActiveControlModuleEnabled = function(arg1)
	local function fn2()
		if arg1.touchControlFrame then
			if var7.PreferredInput == Enum.PreferredInput.Touch then
				if arg1.activeControlModule ~= result then
					if arg1.activeControlModule == success or arg1.activeControlModule == var3 then
						if not arg1.controllers[var4] then
							arg1.controllers[var4] = var4.new()
						end

						arg1.touchJumpController = arg1.controllers[var4]
						arg1.touchJumpController:Enable(true, arg1.touchControlFrame)
					else
						if arg1.touchJumpController then
							arg1.touchJumpController:Enable(false)
						end
					end
				end
			else
				if arg1.touchJumpController then
					arg1.touchJumpController:Enable(false)
				end
			end
		else
			if arg1.touchJumpController then
				arg1.touchJumpController:Enable(false)
			end
		end

		if arg1.activeControlModule == result then
			arg1.activeController:Enable(true, var5.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, arg1.touchJumpController)
			return
		end

		if arg1.touchControlFrame then
			arg1.activeController:Enable(true, arg1.touchControlFrame)
			return
		end

		arg1.activeController:Enable(true)
	end

	if not arg1.activeController then
		return
	end

	if not arg1.controlsEnabled then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	if not var8.TouchControlsEnabled and (var7.PreferredInput == Enum.PreferredInput.Touch and (arg1.activeControlModule == result or (arg1.activeControlModule == success or arg1.activeControlModule == var3))) then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	fn2()
end

tbl1.Enable = function(arg1, arg2)
	arg2 = arg2 == nil and true
	if arg1.controlsEnabled == arg2 then
		return
	end

	arg1.controlsEnabled = arg2
	if not arg1.activeController then
		return
	end

	arg1:UpdateActiveControlModuleEnabled()
end

tbl1.Disable = function(arg1)
	arg1:Enable(false)
end

result = {
	[Enum.TouchMovementMode.DPad] = var3,
	[Enum.DevTouchMovementMode.DPad] = var3,
	[Enum.TouchMovementMode.Thumbpad] = var3,
	[Enum.DevTouchMovementMode.Thumbpad] = var3,
	[Enum.TouchMovementMode.Thumbstick] = success,
	[Enum.DevTouchMovementMode.Thumbstick] = success,
	[Enum.TouchMovementMode.DynamicThumbstick] = var3,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = var3,
	[Enum.TouchMovementMode.ClickToMove] = result,
	[Enum.DevTouchMovementMode.ClickToMove] = result,
	[Enum.TouchMovementMode.Default] = var3,
	[Enum.ComputerMovementMode.Default] = var1,
	[Enum.ComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = result,
	[Enum.DevComputerMovementMode.ClickToMove] = result,
}

tbl1.SelectComputerMovementModule = function(_)
	if not var7.KeyboardEnabled and (not var7.GamepadEnabled) then
		return nil, false
	end

	local var4 = var5.LocalPlayer.DevComputerMovementMode
	local var6 = nil
	if var4 == Enum.DevComputerMovementMode.UserChoice then
		local bool3 = false
		if str5 then
			pcall(function()
				bool3 = var7.PreferredInput == Enum.PreferredInput.MicroGamepad
			end)

		end

		if var7.PreferredInput == Enum.PreferredInput.Gamepad or bool3 then
			var6 = var2
		else
			if var7.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				var6 = var1
			end
		end

		if var10.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove and var6 == var1 then
			var6 = result
		end
	else
		var6 = result[var4]
		if not var6 and var4 ~= Enum.DevComputerMovementMode.Scriptable then
			warn("No character control module is associated with DevComputerMovementMode ", var4)
		end
	end

	if var6 then
		return var6, true
	end

	if var4 == Enum.DevComputerMovementMode.Scriptable then
		return nil, true
	end

	return nil, false
end

tbl1.SelectTouchModule = function(_)
	local var3 = var5.LocalPlayer.DevTouchMovementMode
	local var4 = nil
	if var3 == Enum.DevTouchMovementMode.UserChoice then
		var4 = result[var10.TouchMovementMode]
	else
		if var3 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end

		var4 = result[var3]
	end

	return var4, true
end

local function getGamepadRightThumbstickPosition()
	for k1, v1 in pairs((var7:GetGamepadState(Enum.UserInputType.Gamepad1))) do
		if v1.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end

		return v1.Position
	end

	return Vector3.new(0, 0, 0)
end

tbl1.calculateRawMoveVector = function(arg1, arg2, arg3)
	local var2 = var9.CurrentCamera
	if not var2 then
		return arg3
	end

	local var5 = var2.CFrame
	if var11.VREnabled then
		if arg2.RootPart then
			var11:GetUserCFrame(Enum.UserCFrame.Head)
			local var8 = arg1:GetEstimatedVRTorsoFrame()
			var5 = if (var2.Focus.Position - var5.Position).Magnitude < 3 then var5 * var8 else var2.CFrame * (var8.Rotation + var8.Position * var2.HeadScale)
		end
	end

	if arg2:GetState() == Enum.HumanoidStateType.Swimming then
		if var11.VREnabled then
			arg3 = Vector3.new(arg3.X, 0, arg3.Z)
			if arg3.Magnitude < 0.01 then
				return Vector3.new(0, 0, 0)
			end

			local var10, var12, var13 = var5:ToEulerAnglesYXZ()
			return CFrame.fromEulerAnglesYXZ(-getGamepadRightThumbstickPosition().Y * 1.3962634015954636, math.atan2(-arg3.X, -arg3.Z) + var12, 0).LookVector
		end

		local var14 = arg3
		return var5:VectorToWorldSpace(var14)
	end

	local var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40 = var5:GetComponents()
	local var41 = nil
	local var42 = nil
	if var37 < 1 and -1 < var37 then
		var41 = var40
		var42 = var34
	else
		var41 = var32
		var42 = -var33 * math.sign(var37)
	end

	local var43 = math.sqrt(var41 * var41 + var42 * var42)
	return (Vector3.new((var41 * arg3.X + var42 * arg3.Z) / var43, 0, (var41 * arg3.Z - var42 * arg3.X) / var43))
end

tbl1.OnRenderStepped = function(arg1, arg2)
	if arg1.activeController then
		if arg1.activeController.enabled then
			if arg1.humanoid then
				local var7 = arg1:GetClickToMoveController()
				local var8 = arg1.activeController:GetMoveVector()
				local var9 = arg1.activeController:IsMoveVectorCameraRelative()
				if arg1.activeController == var7 then
					var7:OnRenderStepped(arg2)
				else
					if 0 < var8.magnitude then
						var7:CleanupPath()
					else
						var7:OnRenderStepped(arg2)
						var8 = var7:GetMoveVector()
						var9 = var7:IsMoveVectorCameraRelative()
					end
				end

				if arg1.vehicleController then
					local var10, var12 = arg1.vehicleController:Update(var8, var9, arg1.activeControlModule == var2)
					var8 = var10
				end

				if var9 then
					var8 = arg1:calculateRawMoveVector(arg1.humanoid, var8)
				end

				arg1.inputMoveVector = var8
				if var11.VREnabled then
					var8 = arg1:updateVRMoveVector(var8)
				end

				arg1.moveFunction(var5.LocalPlayer, var8, false)
				local var13 = arg1.activeController:GetIsJumping()
				var13 = var13 or arg1.touchJumpController and arg1.touchJumpController:GetIsJumping()
				arg1.humanoid.Jump = var13
			end
		end
	end
end

tbl1.updateVRMoveVector = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	local bool2 = false
	if (var1.Focus.Position - var1.CFrame.Position).Magnitude < 5 then
		bool2 = true
	end

	if arg2.Magnitude == 0 and (bool2 and (var11.AvatarGestures and (arg1.humanoid and (not arg1.humanoid.Sit)))) then
		local var4 = var11:GetUserCFrame(Enum.UserCFrame.Head)
		local var5 = (var1.CFrame * (var4.Rotation + var4.Position * var1.HeadScale) * CFrame.new(0, -0.7 * arg1.humanoid.RootPart.Size.Y / 2, 0)).Position - arg1.humanoid.RootPart.CFrame.Position
		return (Vector3.new(var5.x, 0, var5.z))
	end

	return arg2
end

tbl1.OnHumanoidSeated = function(arg1, arg2, arg3)
	if arg2 then
		if not arg3 then
			return
		end

		if not arg3:IsA("VehicleSeat") then
			return
		end

		if not arg1.vehicleController then
			local var1 = arg1.vehicleController.new(success)
			arg1.vehicleController = var1
		end

		arg1.vehicleController:Enable(true, arg3)
		return
	end

	if arg1.vehicleController then
		arg1.vehicleController:Enable(false, arg3)
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2)
	arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	while not arg1.humanoid do
		arg2.ChildAdded:wait()
		arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	end

	if arg1.humanoidSeatedConn then
		arg1.humanoidSeatedConn:Disconnect()
		arg1.humanoidSeatedConn = nil
	end

	arg1.humanoidSeatedConn = arg1.humanoid.Seated:Connect(function(arg1, arg2)
		arg1:OnHumanoidSeated(arg1, arg2)
	end)

	arg1:UpdateMovementMode()
end

tbl1.OnCharacterRemoving = function(arg1, _)
	arg1.humanoid = nil
	arg1:UpdateMovementMode()
end

tbl1.UpdateTouchGuiVisibility = function(arg1)
	local var2 = arg1.humanoid
	if var2 then
		var2 = var8.TouchControlsEnabled
		if var2 then
			var2 = var7.PreferredInput == Enum.PreferredInput.Touch
		end
	end

	if var2 and (not arg1.touchGui) then
		arg1:CreateTouchGuiContainer()
	end

	if arg1.touchGui then
		arg1.touchGui.Enabled = not not var2
	end
end

tbl1.SwitchToController = function(arg1, arg2)
	if not arg2 then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = nil
		arg1.activeControlModule = nil
		return
	end

	if not arg1.controllers[arg2] then
		arg1.controllers[arg2] = arg2.new(success)
	end

	if arg1.activeController ~= arg1.controllers[arg2] then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = arg1.controllers[arg2]
		arg1.activeControlModule = arg2
		arg1:UpdateActiveControlModuleEnabled()
	end
end

tbl1.UpdateMovementMode = function(arg1)
	arg1:UpdateTouchGuiVisibility()
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		local var1, var2 = arg1:SelectTouchModule()
		if not (var2 and arg1.touchControlFrame) then
			return
		end

		if not arg1.touchControlFrame then
			return
		end

		arg1:SwitchToController(var1)
		return
	end

	arg1:SwitchToController((arg1:SelectComputerMovementModule()))
end

tbl1.CreateTouchGuiContainer = function(arg1)
	if not arg1.playerGui then
		return
	end

	if arg1.touchGui then
		arg1.touchGui:Destroy()
	end

	arg1.touchGui = Instance.new("ScreenGui")
	arg1.touchGui.Name = "TouchGui"
	arg1.touchGui.ResetOnSpawn = false
	arg1.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	if str1 then
		arg1.touchGui.ClipToDeviceSafeArea = false
	end

	arg1.touchControlFrame = Instance.new("Frame")
	arg1.touchControlFrame.Name = "TouchControlFrame"
	arg1.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
	arg1.touchControlFrame.BackgroundTransparency = 1
	arg1.touchControlFrame.Parent = arg1.touchGui
	arg1.touchGui.Parent = arg1.playerGui
end

tbl1.GetClickToMoveController = function(arg1)
	if not arg1.controllers[result] then
		arg1.controllers[result] = result.new(success)
	end

	return arg1.controllers[result]
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick [ModuleScript]
-- y u r i

local tbl1 = { 0.10999999999999999, 0.30000000000000004, 0.4, 0.5, 0.6, 0.7, 0.75 }
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local var2 = var1.getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
success = nil
local var3 = game:GetService("Players")
result = var3.LocalPlayer
local var4 = Enum.ContextActionPriority.High.Value
local var5 = #tbl1
local var6 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local var7 = game:GetService("GuiService")
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("ContextActionService")
local var10 = game:GetService("RunService")
local var11 = game:GetService("TweenService")
local var12 = var1.getUserFlag("UserAllowAbilityControlsBonus")
success = var2 and require(script.Parent:WaitForChild(str2))
if not result then
	var3:GetPropertyChangedSignal("LocalPlayer"):Wait()
	result = var3.LocalPlayer
end

local str3 = "BaseCharacterController"
local var13 = require(script.Parent:WaitForChild(str3))
local var14 = setmetatable({}, var13)
var14.__index = var14
var14.new = function()
	local var1 = setmetatable(var13.new(), var14)
	var1.moveTouchObject = nil
	var1.moveTouchLockedIn = false
	var1.moveTouchFirstChanged = false
	var1.moveTouchStartPosition = nil
	var1.startImage = nil
	var1.endImage = nil
	var1.middleImages = {}
	var1.startImageFadeTween = nil
	var1.endImageFadeTween = nil
	var1.middleImageFadeTweens = {}
	var1.isFirstTouch = true
	var1.thumbstickFrame = nil
	var1.onRenderSteppedConn = nil
	var1.fadeInAndOutBalance = 0.5
	var1.fadeInAndOutHalfDuration = 0.3
	var1.hasFadedBackgroundInPortrait = false
	var1.hasFadedBackgroundInLandscape = false
	var1.tweenInAlphaStart = nil
	var1.tweenOutAlphaStart = nil
	return var1
end

var14.GetIsJumping = function(arg1)
	local var1 = arg1.isJumping
	arg1.isJumping = false
	return var1
end

var14.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1:BindContextActions()
	else
		arg1:UnbindContextActions()
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
	arg1.thumbstickFrame.Visible = arg2
	return nil
end

var14.OnInputEnded = function(arg1)
	arg1.moveTouchObject = nil
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1:FadeThumbstick(false)
end

var14.FadeThumbstick = function(arg1, arg2)
	if not arg2 and arg1.moveTouchObject then
		return
	end

	if arg1.isFirstTouch then
		return
	end

	if arg1.startImageFadeTween then
		arg1.startImageFadeTween:Cancel()
	end

	if arg1.endImageFadeTween then
		arg1.endImageFadeTween:Cancel()
	end

	for i1 = 1, #arg1.middleImages do
		if not arg1.middleImageFadeTweens[i1] then
			continue
		end

		arg1.middleImageFadeTweens[i1]:Cancel()
	end

	if arg2 then
		arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 0 })
		arg1.startImageFadeTween:Play()
		arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 0.2 })
		arg1.endImageFadeTween:Play()
		for i2 = 1, #arg1.middleImages do
			arg1.middleImageFadeTweens[i2] = var11:Create(arg1.middleImages[i2], var6, { ImageTransparency = tbl1[i2] })
			arg1.middleImageFadeTweens[i2]:Play()
		end

		return
	end

	arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 1 })
	arg1.startImageFadeTween:Play()
	arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 1 })
	arg1.endImageFadeTween:Play()
	for i3 = 1, #arg1.middleImages do
		arg1.middleImageFadeTweens[i3] = var11:Create(arg1.middleImages[i3], var6, { ImageTransparency = 1 })
		arg1.middleImageFadeTweens[i3]:Play()
	end
end

var14.FadeThumbstickFrame = function(arg1, arg2, arg3)
	arg1.fadeInAndOutHalfDuration = arg2 * 0.5
	arg1.fadeInAndOutBalance = arg3
	arg1.tweenInAlphaStart = tick()
end

var14.InputInFrame = function(arg1, arg2)
	local var1 = arg1.thumbstickFrame.AbsolutePosition
	local var2 = arg2.Position
	local var4 = var1 + arg1.thumbstickFrame.AbsoluteSize
	if var1.X <= var2.X and (var1.Y <= var2.Y and (var2.X <= var4.X and var2.Y <= var4.Y)) then
		return true
	end

	return false
end

var14.DoFadeInBackground = function(arg1)
	local var2 = result:FindFirstChildOfClass("PlayerGui")
	local bool2 = false
	if var2 then
		if var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft or var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight then
			bool2 = arg1.hasFadedBackgroundInLandscape
			arg1.hasFadedBackgroundInLandscape = true
		else
			if var2.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait then
				bool2 = arg1.hasFadedBackgroundInPortrait
				arg1.hasFadedBackgroundInPortrait = true
			end
		end
	end

	if not bool2 then
		arg1.fadeInAndOutHalfDuration = 0.3
		arg1.fadeInAndOutBalance = 0.5
		arg1.tweenInAlphaStart = tick()
	end
end

var14.DoMove = function(arg1, arg2)
	local var1 = arg2
	if var1.Magnitude < arg1.radiusOfDeadZone then
		var1 = Vector3.new(0, 0, 0)
	else
		var1 = var1.Unit * (1 - math.max(0, (arg1.radiusOfMaxSpeed - var1.Magnitude) / arg1.radiusOfMaxSpeed))
		var1 = Vector3.new(var1.X, 0, var1.Y)
	end

	arg1.moveVector = var1
end

var14.LayoutMiddleImages = function(arg1, arg2, arg3)
	local var1 = arg3 - arg2
	local var4 = var1.Magnitude - arg1.thumbstickRingSize / 2 - arg1.middleSize
	local var6 = arg1.thumbstickSize / 2 + arg1.middleSize
	local var7 = var1.Unit
	local var8 = arg1.middleSpacing
	if arg1.middleSpacing * var5 < var4 then
		var8 = var4 / var5
	end

	for i1 = 1, var5 do
		local var10 = arg1.middleImages[i1]
		if var6 + var8 * (i1 - 2) < var4 then
			local var11 = var6 + var8 * (i1 - 1)
			local var12 = math.clamp(1 - (var11 - var4) / var8, 0, 1)
			var10.Visible = true
			local var13 = arg3 - var7 * var11
			var10.Position = UDim2.new(0, var13.X, 0, var13.Y)
			var10.Size = UDim2.new(0, arg1.middleSize * var12, 0, arg1.middleSize * var12)
		else
			var10.Visible = false
		end
	end
end

var14.MoveStick = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, arg2.Y) - arg1.thumbstickFrame.AbsolutePosition
	local var2 = Vector2.new(arg1.moveTouchStartPosition.X, arg1.moveTouchStartPosition.Y) - arg1.thumbstickFrame.AbsolutePosition
	arg1.endImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
	arg1:LayoutMiddleImages(var2, var1)
end

var14.BindContextActions = function(arg1)
	local function inputBegan(arg1)
		if arg1.moveTouchObject then
			return Enum.ContextActionResult.Pass
		end

		if not arg1:InputInFrame(arg1) then
			return Enum.ContextActionResult.Pass
		end

		if arg1.isFirstTouch then
			arg1.isFirstTouch = false
			local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
			var11:Create(arg1.startImage, var1, { Size = UDim2.new(0, 0, 0, 0) }):Play()
			local tbl1 = { Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize) }
			tbl1.ImageColor3 = Color3.new(0, 0, 0)
			var11:Create(arg1.endImage, var1, tbl1):Play()
		end

		arg1.moveTouchLockedIn = false
		arg1.moveTouchObject = arg1
		arg1.moveTouchStartPosition = arg1.Position
		arg1.moveTouchFirstChanged = true
		arg1:DoFadeInBackground()
		return Enum.ContextActionResult.Pass
	end

	var9:BindActionAtPriority("DynamicThumbstickAction", function(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Begin then
			return (inputBegan(arg3))
		end

		if arg2 == Enum.UserInputState.Change then
			if arg3 == arg1.moveTouchObject then
				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.End then
			if arg3 == arg1.moveTouchObject then
				arg1:OnInputEnded()
				if arg1.moveTouchLockedIn then
					return Enum.ContextActionResult.Sink
				end
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.Cancel then
			arg1:OnInputEnded()
		end
	end, false, var4, Enum.UserInputType.Touch)

	local function inputChanged(arg1)
		if arg1 == arg1.moveTouchObject then
			if arg1.moveTouchFirstChanged then
				arg1.moveTouchFirstChanged = false
				local var1 = Vector2.new(arg1.Position.X - arg1.thumbstickFrame.AbsolutePosition.X, arg1.Position.Y - arg1.thumbstickFrame.AbsolutePosition.Y)
				arg1.startImage.Visible = true
				arg1.startImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
				arg1.endImage.Visible = true
				arg1.endImage.Position = arg1.startImage.Position
				arg1:FadeThumbstick(true)
				arg1:MoveStick(arg1.Position)
			end

			arg1.moveTouchLockedIn = true
			local var2 = Vector2.new(arg1.Position.X - arg1.moveTouchStartPosition.X, arg1.Position.Y - arg1.moveTouchStartPosition.Y)
			if 0 < math.abs(var2.X) or 0 < math.abs(var2.Y) then
				arg1:DoMove(var2)
				arg1:MoveStick(arg1.Position)
			end

			return Enum.ContextActionResult.Sink
		end

		return Enum.ContextActionResult.Pass
	end

	arg1.TouchMovedCon = var8.TouchMoved:Connect(function(arg1, _)
		inputChanged(arg1)
	end)
end

var14.UnbindContextActions = function(arg1)
	var9:UnbindAction("DynamicThumbstickAction")
	if arg1.TouchMovedCon then
		arg1.TouchMovedCon:Disconnect()
	end
end

var14.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onRenderSteppedConn then
			arg1.onRenderSteppedConn:Disconnect()
			arg1.onRenderSteppedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var2 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	local var1 = if str1 then 100 else 0
	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.BorderSizePixel = 0
	arg1.thumbstickFrame.Name = "DynamicThumbstickFrame"
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	arg1.thumbstickFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	arg1.thumbstickFrame.Active = false
	arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
	arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	arg1.startImage = Instance.new("ImageLabel")
	arg1.startImage.Name = "ThumbstickStart"
	arg1.startImage.Visible = true
	arg1.startImage.BackgroundTransparency = 1
	arg1.startImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.startImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.startImage.ImageRectSize = Vector2.new(144, 144)
	arg1.startImage.ImageColor3 = Color3.new(0, 0, 0)
	arg1.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.startImage.ZIndex = 10
	arg1.startImage.Parent = arg1.thumbstickFrame
	arg1.endImage = Instance.new("ImageLabel")
	arg1.endImage.Name = "ThumbstickEnd"
	arg1.endImage.Visible = true
	arg1.endImage.BackgroundTransparency = 1
	arg1.endImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.endImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.endImage.ImageRectSize = Vector2.new(144, 144)
	arg1.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.endImage.ZIndex = 10
	arg1.endImage.Parent = arg1.thumbstickFrame
	local function layoutThumbstickFrame(arg1)
		if arg1 then
			arg1.thumbstickFrame.Size = UDim2.new(1, var1, 0.4, var1)
			arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.6, 0)
			return
		end

		arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
		arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	end

	for i1 = 1, var5 do
		arg1.middleImages[i1] = Instance.new("ImageLabel")
		arg1.middleImages[i1].Name = "ThumbstickMiddle"
		arg1.middleImages[i1].Visible = false
		arg1.middleImages[i1].BackgroundTransparency = 1
		arg1.middleImages[i1].Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.middleImages[i1].ImageRectOffset = Vector2.new(1, 1)
		arg1.middleImages[i1].ImageRectSize = Vector2.new(144, 144)
		arg1.middleImages[i1].ImageTransparency = tbl1[i1]
		arg1.middleImages[i1].AnchorPoint = Vector2.new(0.5, 0.5)
		arg1.middleImages[i1].ZIndex = 9
		arg1.middleImages[i1].Parent = arg1.thumbstickFrame
	end

	local function ResizeThumbstick()
		local var3 = arg2.AbsoluteSize
		local var5 = 500 < math.min(var3.X, var3.Y)
		if var2 then
			local var7 = if var5 then 2 else 1
			if var12 and (success.isEnabled() and var5) then
				var7 = 1.6216216216216217
			end

			arg1.thumbstickSize = 45 * var7
			arg1.thumbstickRingSize = 20 * var7
			arg1.middleSize = 10 * var7
			arg1.middleSpacing = 14 * var7
			arg1.radiusOfDeadZone = 2 * var7
			arg1.radiusOfMaxSpeed = 20 * var7
			local var8 = 74 * var7
			if success.isEnabled() then
				local var9 = if var5 then 100 else 64
				arg1.startImage.Position = UDim2.new(0, var8 * 0.5 + var1 + var9, 1, -var8 * 0.5 - var1 - (if var5 then 112 else 64))
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			else
				arg1.startImage.Position = UDim2.new(0, arg1.thumbstickRingSize * 3.3 + var1, 1, -arg1.thumbstickRingSize * 2.8 - var1)
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			end
		elseif var5 then
			arg1.thumbstickSize = 90
			arg1.thumbstickRingSize = 40
			arg1.middleSize = 20
			arg1.middleSpacing = 28
			arg1.radiusOfDeadZone = 4
			arg1.radiusOfMaxSpeed = 40
		else
			arg1.thumbstickSize = 45
			arg1.thumbstickRingSize = 20
			arg1.middleSize = 10
			arg1.middleSpacing = 14
			arg1.radiusOfDeadZone = 2
			arg1.radiusOfMaxSpeed = 20
		end

		arg1.endImage.Position = arg1.startImage.Position
		arg1.endImage.Size = UDim2.new(0, arg1.thumbstickSize * 0.8, 0, arg1.thumbstickSize * 0.8)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var2 then
		arg1.avatarAbilitiesEnabledChangedConn = success.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	local var3 = nil
	local function onCurrentCameraChanged()
		if var3 then
			var3:Disconnect()
			var3 = nil
		end

		local var2 = workspace.CurrentCamera
		if var2 then
			var3 = var2:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				local var1 = var2.ViewportSize
				layoutThumbstickFrame(var1.X < var1.Y)
			end)

			local var4 = var2.ViewportSize
			layoutThumbstickFrame(var4.X < var4.Y)
		end
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(onCurrentCameraChanged)
	if workspace.CurrentCamera then
		onCurrentCameraChanged()
	end

	arg1.moveTouchStartPosition = nil
	arg1.startImageFadeTween = nil
	arg1.endImageFadeTween = nil
	arg1.middleImageFadeTweens = {}
	arg1.onRenderSteppedConn = var10.RenderStepped:Connect(function()
		if arg1.tweenInAlphaStart ~= nil then
			local var3 = tick() - arg1.tweenInAlphaStart
			local var4 = arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = 1 - math.min(var3 / var4, 1) * 0.35
			if var4 >= var3 then
				return
			end

			arg1.tweenOutAlphaStart = tick()
			arg1.tweenInAlphaStart = nil
			return
		end

		if arg1.tweenOutAlphaStart ~= nil then
			local var7 = tick() - arg1.tweenOutAlphaStart
			local var8 = arg1.fadeInAndOutHalfDuration * 2 - arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = math.min(var7 / var8, 1) * 0.35 + 0.65
			if var8 < var7 then
				arg1.tweenOutAlphaStart = nil
			end
		end
	end)

	arg1.onTouchEndedConn = var8.TouchEnded:connect(function(arg1)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var7.MenuOpened:connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	local var4 = result:FindFirstChildOfClass("PlayerGui")
	while not var4 do
		result.ChildAdded:wait()
		var4 = result:FindFirstChildOfClass("PlayerGui")
	end

	local var6 = nil
	local bool1 = true
	if var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.LandscapeLeft then
		bool1 = var4.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight
	end

	var4:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		if bool1 and var4.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait or not bool1 and var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.Portrait then
			var6:disconnect()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
			if bool1 then
				arg1.hasFadedBackgroundInPortrait = true
				return
			end

			arg1.hasFadedBackgroundInLandscape = true
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
	if game:IsLoaded() then
		arg1.fadeInAndOutHalfDuration = 2.5
		arg1.fadeInAndOutBalance = 0.05
		arg1.tweenInAlphaStart = tick()
	else
		coroutine.wrap(function()
			game.Loaded:Wait()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
		end)()

	end
end

return var14

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController [ModuleScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "UserExcludeNonCollidableForPathfinding"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local success, result = pcall(function()
	local str1 = "UserClickToMoveSupportAgentCanClimb2"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

game:GetService("Debris")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("PathfindingService")
local var4 = game:GetService("Players")
local var5 = game:GetService("StarterGui")
local var6 = game:GetService("Workspace")
local var7 = game:GetService("CollectionService")
local var8 = game:GetService("GuiService")
local str2 = "ClickToMoveDisplay"
local var9 = require(script.Parent:WaitForChild(str2))
local var10 = RaycastParams.new()
var10.FilterType = Enum.RaycastFilterType.Exclude
local var11 = success and result
local var12 = success and result
local bool1 = true
str1 = true
local bool2 = false
local num1 = 1
local num2 = 8
local tbl1 = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true,
}

local var13 = var4.LocalPlayer
local tbl2 = {}
if not var1 then
	str2 = function(arg1)
		if arg1 then
			local var2 = arg1:FindFirstChildOfClass("Humanoid")
			if var2 then
				return arg1, var2
			end

			local var3 = arg1.Parent
			return str2(var3)
		end
	end

	tbl2.FindCharacterAncestor = str2
	local function Raycast(arg1, arg2, arg3)
		local var1 = arg3
		arg3 = var1 or {}
		local var7, var8, var9, var10 = var6:FindPartOnRayWithIgnoreList(arg1, arg3)
		if var7 then
			if arg2 then
				if var7.CanCollide == false then
					local var13
					if var7 then
						local var15 = var7:FindFirstChildOfClass("Humanoid")
						if var15 then
							local var16 = var7
							var13 = var15
						else
							local var17, var18 = str2(var7.Parent)
							local var19 = var17
							var13 = var18
						end
					else
						local var20 = nil
						var13 = nil
					end

					if var13 == nil then
						table.insert(arg3, var7)
						local var21 = arg1
						local var22 = arg2
						local var23 = arg3
						return Raycast(var21, var22, var23)
					end
				end
			end

			return var7, var8, var9, var10
		end

		return nil, nil
	end

	tbl2.Raycast = Raycast
end

str2 = {}
local var14 = nil
local var15 = nil
local var16 = nil
local var17 = nil
local function getCollidableExtentsSize(arg1)
	if arg1 == nil or arg1.PrimaryPart == nil then
		return
	end

	assert(arg1, "")
	assert(arg1.PrimaryPart, "")
	local var1 = arg1.PrimaryPart.CFrame:Inverse()
	local var2 = Vector3.new(inf, inf, inf)
	local var3 = Vector3.new(-inf, -inf, -inf)
	for k1, v1 in pairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if not v1.CanCollide then
			continue
		end

		local var4 = Vector3.new(v1.Size.X / 2, v1.Size.Y / 2, v1.Size.Z / 2)
		local var5 = Vector3.new(-var4.X, var4.Y, var4.Z)
		local var6 = var1 * v1.CFrame
		for k2, v2 in ipairs({
			Vector3.new(var4.X, var4.Y, var4.Z),
			Vector3.new(var4.X, var4.Y, -var4.Z),
			Vector3.new(var4.X, -var4.Y, var4.Z),
			Vector3.new(var4.X, -var4.Y, -var4.Z),
			var5,
			Vector3.new(-var4.X, var4.Y, -var4.Z),
			Vector3.new(-var4.X, -var4.Y, var4.Z),
			(Vector3.new(-var4.X, -var4.Y, -var4.Z)),
		}) do

			local var7 = var2
			local var8 = var6 * v2
			var2 = Vector3.new(math.min(var7.X, var8.X), math.min(var7.Y, var8.Y), (math.min(var7.Z, var8.Z)))
			var7 = var3
			var3 = Vector3.new(math.max(var7.X, var8.X), math.max(var7.Y, var8.Y), (math.max(var7.Z, var8.Z)))
		end
	end

	local var9 = var3 - var2
	if var9.X < 0 or (var9.Y < 0 or var9.Z < 0) then
		return nil
	end

	return var9
end

local var18 = nil
local var19 = nil
local var20 = nil
local function GetEquippedTool(arg1)
	if arg1 ~= nil then
		for k1, v1 in pairs(arg1:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			return v1
		end
	end
end

local function Pather(arg1, arg2, arg3)
	local var5 = nil
	local var7 = nil
	local tbl1 = {}
	if arg3 ~= nil then
		var5 = arg3
		var7 = arg3
	else
		var5 = bool2
		var7 = true
	end

	tbl1.Cancelled = false
	tbl1.Started = false
	tbl1.Finished = Instance.new("BindableEvent")
	tbl1.PathFailed = Instance.new("BindableEvent")
	tbl1.PathComputing = false
	tbl1.PathComputed = false
	tbl1.OriginalTargetPoint = arg1
	tbl1.TargetPoint = arg1
	tbl1.TargetSurfaceNormal = arg2
	tbl1.DiedConn = nil
	tbl1.SeatedConn = nil
	tbl1.BlockedConn = nil
	tbl1.TeleportedConn = nil
	tbl1.CurrentPoint = 0
	tbl1.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPosition = nil
	tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPlaneDistance = 0
	tbl1.CurrentWaypointNeedsJump = false
	tbl1.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	tbl1.CurrentHumanoidVelocity = 0
	tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
	tbl1.NextActionJump = false
	tbl1.Timeout = 0
	local var8 = var13
	local var14 = var8
	var14 = var14 and var8.Character
	local var16
	if var14 then
		local var19 = str2[var8]
		if var19 and var19.Parent == var14 then
			var16 = var19
		else
			str2[var8] = nil
			local var21 = var14:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var8] = var21
			end

			var16 = var21
		end
	else
		var16 = nil
	end

	tbl1.Humanoid = var16
	tbl1.OriginPoint = nil
	tbl1.AgentCanFollowPath = false
	tbl1.DirectPath = false
	tbl1.DirectPathRiseFirst = false
	tbl1.stopTraverseFunc = nil
	tbl1.setPointFunc = nil
	tbl1.pointList = nil
	var16 = tbl1.Humanoid
	var16 = var16 and tbl1.Humanoid.RootPart
	if var16 then
		tbl1.OriginPoint = var16.CFrame.Position
		local var24 = tbl1.Humanoid.SeatPart
		var8 = 2
		var14 = 5
		local bool3 = true
		if var24 then
			if var24:IsA("VehicleSeat") then
				local var27 = var24:FindFirstAncestorOfClass("Model")
				if var27 then
					local var28 = var27.PrimaryPart
					var27.PrimaryPart = var24
					if var7 then
						local var30 = var27:GetExtentsSize()
						var8 = num1 * 0.5 * math.sqrt(var30.X * var30.X + var30.Z * var30.Z)
						tbl1.AgentCanFollowPath = true
						tbl1.DirectPath = var7
						var14 = num1 * var30.Y
						bool3 = false
					end

					var27.PrimaryPart = var28
				end
			else
				local var33 = nil
				if var11 then
					local var34 = var13
					var34 = var34 and var13.Character
					if var34 ~= nil then
						var33 = getCollidableExtentsSize(var34)
					end
				end

				if var33 == nil then
					local var35 = var13
					var33 = (var35 and var13.Character):GetExtentsSize()
				end

				assert(var33, "")
				var8 = num1 * 0.5 * math.sqrt(var33.X * var33.X + var33.Z * var33.Z)
				tbl1.AgentCanFollowPath = true
				tbl1.DirectPath = var5
				tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
				var14 = num1 * var33.Y
				bool3 = 0 < tbl1.Humanoid.JumpPower
			end
		else
			local var38 = nil
			if var11 then
				local var39 = var13
				var39 = var39 and var13.Character
				if var39 ~= nil then
					var38 = getCollidableExtentsSize(var39)
				end
			end

			if var38 == nil then
				local var40 = var13
				var38 = (var40 and var13.Character):GetExtentsSize()
			end

			assert(var38, "")
			var8 = num1 * 0.5 * math.sqrt(var38.X * var38.X + var38.Z * var38.Z)
			tbl1.AgentCanFollowPath = true
			tbl1.DirectPath = var5
			tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
			var14 = num1 * var38.Y
			bool3 = 0 < tbl1.Humanoid.JumpPower
		end

		if var12 then
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3, AgentCanClimb = true })
		else
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3 })
		end
	end

	tbl1.Cleanup = function(_)
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		if tbl1.BlockedConn then
			tbl1.BlockedConn:Disconnect()
			tbl1.BlockedConn = nil
		end

		if tbl1.DiedConn then
			tbl1.DiedConn:Disconnect()
			tbl1.DiedConn = nil
		end

		if tbl1.SeatedConn then
			tbl1.SeatedConn:Disconnect()
			tbl1.SeatedConn = nil
		end

		if tbl1.TeleportedConn then
			tbl1.TeleportedConn:Disconnect()
			tbl1.TeleportedConn = nil
		end

		tbl1.Started = false
	end

	tbl1.Cancel = function(_)
		tbl1.Cancelled = true
		tbl1:Cleanup()
	end

	tbl1.IsActive = function(_)
		local var1 = tbl1.AgentCanFollowPath
		return var1 and (tbl1.Started and (not tbl1.Cancelled))
	end

	tbl1.OnPathInterrupted = function(_)
		tbl1.Cancelled = true
		tbl1:OnPointReached(false)
	end

	tbl1.ComputePath = function(_)
		if tbl1.OriginPoint then
			if tbl1.PathComputed or tbl1.PathComputing then
				return
			end

			tbl1.PathComputing = true
			if tbl1.AgentCanFollowPath then
				if tbl1.DirectPath then
					local var5 = tbl1.TargetPoint
					local var6 = tbl1.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk
					local tbl2 = {
						PathWaypoint.new(tbl1.OriginPoint, Enum.PathWaypointAction.Walk),
						PathWaypoint.new(var5, var6),
					}

					tbl1.pointList = tbl2
					tbl1.PathComputed = true
				else
					tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
					tbl1.pointList = tbl1.pathResult:GetWaypoints()
					tbl1.BlockedConn = tbl1.pathResult.Blocked:Connect(function(arg1)
						tbl1:OnPathBlocked(arg1)
					end)

					tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
				end
			end

			tbl1.PathComputing = false
		end
	end

	tbl1.IsValidPath = function(_)
		tbl1:ComputePath()
		local var1 = tbl1.PathComputed
		return var1 and tbl1.AgentCanFollowPath
	end

	tbl1.Recomputing = false
	tbl1.OnPathBlocked = function(_, arg2)
		if not (tbl1.CurrentPoint <= arg2) or tbl1.Recomputing then
			return
		end

		tbl1.Recomputing = true
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		tbl1.OriginPoint = tbl1.Humanoid.RootPart.CFrame.p
		tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
		tbl1.pointList = tbl1.pathResult:GetWaypoints()
		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = tbl1.pointList[1].Position - tbl1.OriginPoint
		end

		tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
		if bool1 then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if tbl1.PathComputed then
			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
		else
			tbl1.PathFailed:Fire()
			tbl1:Cleanup()
		end

		tbl1.Recomputing = false
	end

	tbl1.OnRenderStepped = function(_, arg2)
		if tbl1.Started and (not tbl1.Cancelled) then
			tbl1.Timeout = tbl1.Timeout + arg2
			if num2 < tbl1.Timeout then
				tbl1:OnPointReached(false)
				return
			end

			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			while tbl1.Started and tbl1:IsCurrentWaypointReached() do
				tbl1:OnPointReached(true)
			end

			if tbl1.Started then
				tbl1.NextActionMoveDirection = tbl1.CurrentWaypointPosition - tbl1.CurrentHumanoidPosition
				if 1e-06 < tbl1.NextActionMoveDirection.Magnitude then
					tbl1.NextActionMoveDirection = tbl1.NextActionMoveDirection.Unit
				else
					tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end

				if tbl1.CurrentWaypointNeedsJump then
					tbl1.NextActionJump = true
					tbl1.CurrentWaypointNeedsJump = false
					return
				end

				tbl1.NextActionJump = false
			end
		end
	end

	tbl1.IsCurrentWaypointReached = function(_)
		local bool1 = false
		if tbl1.CurrentWaypointPlaneNormal ~= Vector3.new(0, 0, 0) then
			bool1 = tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidPosition) - tbl1.CurrentWaypointPlaneDistance < math.max(1, 0.0625 * -tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidVelocity))
		else
			bool1 = true
		end

		if bool1 then
			tbl1.CurrentWaypointPosition = nil
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		return bool1
	end

	tbl1.OnPointReached = function(_, arg2)
		if arg2 then
			if not tbl1.Cancelled then
				if tbl1.setPointFunc then
					tbl1.setPointFunc(tbl1.CurrentPoint)
				end

				local var2 = tbl1.CurrentPoint + 1
				if #tbl1.pointList < var2 then
					if tbl1.stopTraverseFunc then
						tbl1.stopTraverseFunc()
					end

					tbl1.Finished:Fire()
					tbl1:Cleanup()
					return
				end

				local var4 = tbl1.Humanoid:GetState()
				local var5 = tbl1.pointList[tbl1.CurrentPoint]
				local var6 = tbl1.pointList[var2]
				local bool2 = true
				if var4 ~= Enum.HumanoidStateType.FallingDown then
					bool2 = true
					if var4 ~= Enum.HumanoidStateType.Freefall then
						bool2 = var4 == Enum.HumanoidStateType.Jumping
					end
				end

				if bool2 then
					local var10 = var6.Action == Enum.PathWaypointAction.Jump
					if not var10 then
						if 1 < tbl1.CurrentPoint then
							local var13 = var5.Position - tbl1.pointList[tbl1.CurrentPoint - 1].Position
							local var14 = var6.Position - var5.Position
							var10 = Vector2.new(var13.x, var13.z).Unit:Dot(Vector2.new(var14.x, var14.z).Unit) < 0.996
						end
					end

					if var10 then
						tbl1.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end

				tbl1:MoveToNextWayPoint(var5, var6, var2)
				return
			end
		end

		tbl1.PathFailed:Fire()
		tbl1:Cleanup()
	end

	tbl1.MoveToNextWayPoint = function(_, arg2, arg3, arg4)
		tbl1.CurrentWaypointPlaneNormal = arg2.Position - arg3.Position
		if not var12 or arg3.Label ~= "Climb" then
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(tbl1.CurrentWaypointPlaneNormal.X, 0, tbl1.CurrentWaypointPlaneNormal.Z)
		end

		if 1e-06 < tbl1.CurrentWaypointPlaneNormal.Magnitude then
			tbl1.CurrentWaypointPlaneNormal = tbl1.CurrentWaypointPlaneNormal.Unit
			tbl1.CurrentWaypointPlaneDistance = tbl1.CurrentWaypointPlaneNormal:Dot(arg3.Position)
		else
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		tbl1.CurrentWaypointNeedsJump = arg3.Action == Enum.PathWaypointAction.Jump
		tbl1.CurrentWaypointPosition = arg3.Position
		tbl1.CurrentPoint = arg4
		tbl1.Timeout = 0
	end

	tbl1.Start = function(_, arg2)
		if not tbl1.AgentCanFollowPath then
			tbl1.PathFailed:Fire()
			return
		end

		if tbl1.Started then
			return
		end

		tbl1.Started = true
		var9.CancelFailureAnimation()
		if bool1 and (arg2 == nil or arg2) then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList, tbl1.OriginalTargetPoint)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = Vector3.new(0, tbl1.pointList[1].Position.Y - tbl1.OriginPoint.Y, 0)
			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			tbl1.SeatedConn = tbl1.Humanoid.Seated:Connect(function(_, _)
				tbl1:OnPathInterrupted()
			end)

			tbl1.DiedConn = tbl1.Humanoid.Died:Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.TeleportedConn = tbl1.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
			return
		end

		tbl1.PathFailed:Fire()
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
		end
	end

	var8 = tbl1.TargetPoint + tbl1.TargetSurfaceNormal * 1.5
	if var1 then
		var14 = var10
		local var41
		if var17 then
			var41 = var17
		else
			var17 = {}
			assert(var17, "")
			local var42 = var13
			table.insert(var17, var42 and var13.Character)
			var41 = var17
		end

		var14.FilterDescendantsInstances = var41
		var14 = var6:Raycast(var8, Vector3.new(-0, -50, -0), var10)
		if var14 then
			tbl1.TargetPoint = var14.Position
		end
	else
		var41 = var6
		local var43 = Ray.new(var8, Vector3.new(0, -50, 0))
		local var44
		if var17 then
			var44 = var17
		else
			var17 = {}
			assert(var17, "")
			local var45 = var13
			table.insert(var17, var45 and var13.Character)
			var44 = var17
		end

		local var46, var47 = var41:FindPartOnRayWithIgnoreList(var43, var44)
		if var46 then
			tbl1.TargetPoint = var47
		end
	end

	tbl1:ComputePath()
	return tbl1
end

local function HandleMoveTo(arg1, arg2, arg3, arg4, arg5)
	if var18 then
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end

	var18 = arg1
	arg1:Start(arg5)
	var19 = arg1.Finished.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		local var2 = GetEquippedTool(arg4)
		if arg3 and var2 then
			var2:Activate()
		end
	end)

	var20 = arg1.PathFailed.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		if arg5 ~= nil then
			if not arg5 then
				return
			end
		end

		local var1 = str1
		if var1 and (not var18:IsActive()) then
			var9.PlayFailureAnimation()
		end

		var9.DisplayFailureWaypoint(arg2)
	end)
end

function OnTap(arg1, arg2, arg3)
	local var2 = var13
	local var3 = var2
	var3 = var3 and var2.Character
	local var8 = var6.CurrentCamera
	local var11 = var13.Character
	local var12
	if var3 then
		local var15 = str2[var2]
		if var15 and var15.Parent == var3 then
			var12 = var15
		else
			str2[var2] = nil
			local var21 = var3:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var2] = var21
			end

			var12 = var21
		end
	else
		var12 = nil
	end

	local bool1 = false
	if var12 ~= nil then
		bool1 = 0 < var12.Health
	end

	if not bool1 then
		return
	end

	if #arg1 ~= 1 then
		if arg2 then
			if not var8 then
				return
			end

			bool1 = var8:ScreenPointToRay(arg1[1].X, arg1[1].Y)
			if var1 then
				var12 = nil
				var2 = nil
				var3 = nil
				local var22
				if var17 then
					var22 = var17
				else
					var17 = {}
					assert(var17, "")
					local var23 = var13
					table.insert(var17, var23 and var13.Character)
					var22 = var17
				end

				var22 = var22 or {}
				repeat
					var10.FilterDescendantsInstances = var22
					var3 = var6:Raycast(bool1.Origin, bool1.Direction * 1000, var10)
					local bool2 = true
					if var3 then
						local var25 = var3.Instance
						if not var25.CanCollide then
							repeat
								var12 = var25:FindFirstChildOfClass("Humanoid")
								var2 = var25
								var25 = var25.Parent
							until var12 or (not var25)

							if not var12 and var25 then
								table.insert(var22, var25)
								var2 = nil
								bool2 = false
							end
						end
					end
				until bool2

				if arg3 then
					if var12 then
						if var5:GetCore("AvatarContextMenuEnabled") then
							if var4:GetPlayerFromCharacter(var12.Parent) then
								if var18 then
									var18:Cancel()
									var18 = nil
								end

								if var19 then
									var19:Disconnect()
									var19 = nil
								end

								if var20 then
									var20:Disconnect()
									var20 = nil
								end

								return
							end
						end
					end
				end

				if not var3 or (not var11) then
					return
				end

				local var27 = var3.Position
				if arg2 then
					var2 = nil
					var27 = arg2
				end

				if var18 then
					var18:Cancel()
					var18 = nil
				end

				if var19 then
					var19:Disconnect()
					var19 = nil
				end

				if var20 then
					var20:Disconnect()
					var20 = nil
				end

				local var28 = Pather(var27, var3.Normal)
				if var28:IsValidPath() then
					HandleMoveTo(var28, var27, var2, var11)
					return
				end

				var28:Cleanup()
				if var18 and var18:IsActive() then
					var18:Cancel()
				end

				if str1 then
					var9.PlayFailureAnimation()
				end

				var9.DisplayFailureWaypoint(var27)
				return
			end

			var2 = tbl2.Raycast
			var3 = Ray.new(bool1.Origin, bool1.Direction * 1000)
			var22 = true
			local var29
			if var17 then
				var29 = var17
			else
				var17 = {}
				assert(var17, "")
				local var30 = var13
				table.insert(var17, var30 and var13.Character)
				var29 = var17
			end

			local var31, var32, var33 = var2(var3, var22, var29)
			local var34, var35 = tbl2.FindCharacterAncestor(var31)
			if arg3 then
				if var35 then
					if var5:GetCore("AvatarContextMenuEnabled") then
						if var4:GetPlayerFromCharacter(var35.Parent) then
							if var18 then
								var18:Cancel()
								var18 = nil
							end

							if var19 then
								var19:Disconnect()
								var19 = nil
							end

							if var20 then
								var20:Disconnect()
								var20 = nil
							end

							return
						end
					end
				end
			end

			if arg2 then
				var32 = arg2
				var34 = nil
			end

			if not var32 then
				return
			end

			if not var11 then
				return
			end

			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var36 = Pather(var32, var33)
			if var36:IsValidPath() then
				HandleMoveTo(var36, var32, var34, var11)
				return
			end

			var36:Cleanup()
			if var18 and var18:IsActive() then
				var18:Cancel()
			end

			if str1 then
				var9.PlayFailureAnimation()
			end

			var9.DisplayFailureWaypoint(var32)
			return
		end
	end

	bool1 = GetEquippedTool(var11)
	if 2 <= (#arg1) and (var8 and bool1) then
		bool1:Activate()
	end
end

local str3 = "Keyboard"
local var21 = require(script.Parent:WaitForChild(str3))
local var22 = setmetatable({}, var21)
var22.__index = var22
var22.new = function(arg1)
	local var1 = setmetatable(var21.new(arg1), var22)
	var1.fingerTouches = {}
	var1.numUnsunkTouches = 0
	var1.mouse2DownTime = tick()
	var1.mouse2DownPos = Vector2.new()
	var1.mouse2UpTime = tick()
	var1.keyboardMoveVector = Vector3.new(0, 0, 0)
	var1.tapConn = nil
	var1.inputBeganConn = nil
	var1.inputChangedConn = nil
	var1.inputEndedConn = nil
	var1.humanoidDiedConn = nil
	var1.characterChildAddedConn = nil
	var1.onCharacterAddedConn = nil
	var1.characterChildRemovedConn = nil
	var1.renderSteppedConn = nil
	var1.menuOpenedConnection = nil
	var1.preferredInputChangedConnection = nil
	var1.running = false
	var1.wasdEnabled = false
	return var1
end

var22.DisconnectEvents = function(arg1)
	local var2 = arg1.tapConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputBeganConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputChangedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputEndedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.humanoidDiedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.onCharacterAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.renderSteppedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildRemovedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.menuOpenedConnection
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.preferredInputChangedConnection
	if var2 then
		var2:Disconnect()
	end
end

var22.OnTouchBegan = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil and (not arg3) then
		local var1 = arg1.numUnsunkTouches + 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = arg3
end

var22.OnTouchChanged = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil then
		arg1.fingerTouches[arg2] = arg3
		if not arg3 then
			local var1 = arg1.numUnsunkTouches + 1
			arg1.numUnsunkTouches = var1
		end
	end
end

var22.OnTouchEnded = function(arg1, arg2, _)
	if arg1.fingerTouches[arg2] ~= nil and arg1.fingerTouches[arg2] == false then
		local var1 = arg1.numUnsunkTouches - 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = nil
end

var22.OnPreferredInputChanged = function(_)
	local var3 = var13.Character
	if var3 then
		local var4 = var2.PreferredInput == Enum.PreferredInput.Touch
		for k1, v1 in pairs(var3:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			v1.ManualActivationOnly = var4
		end
	end
end

var22.OnCharacterAdded = function(arg1, arg2)
	arg1:DisconnectEvents()
	arg1.inputBeganConn = var2.InputBegan:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchBegan(arg1, arg2)
		end

		if arg1.wasdEnabled then
			if arg2 == false then
				if arg1.UserInputType == Enum.UserInputType.Keyboard then
					if tbl1[arg1.KeyCode] then
						if var18 then
							var18:Cancel()
							var18 = nil
						end

						if var19 then
							var19:Disconnect()
							var19 = nil
						end

						if var20 then
							var20:Disconnect()
							var20 = nil
						end

						var9.CancelFailureAnimation()
					end
				end
			end
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2DownTime = tick()
			arg1.mouse2DownPos = arg1.Position
		end
	end)

	arg1.inputChangedConn = var2.InputChanged:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchChanged(arg1, arg2)
		end
	end)

	arg1.inputEndedConn = var2.InputEnded:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchEnded(arg1, arg2)
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2UpTime = tick()
			local var2 = var18
			local var3 = arg1.Position
			if not var2 then
				var2 = arg1.keyboardMoveVector.Magnitude <= 0
			end

			if arg1.mouse2UpTime - arg1.mouse2DownTime < 0.25 and ((var3 - arg1.mouse2DownPos).magnitude < 5 and var2) then
				OnTap({ var3 })
			end
		end
	end)

	arg1.tapConn = var2.TouchTap:Connect(function(arg1, arg2)
		if not arg2 then
			OnTap(arg1, nil, true)
		end
	end)

	arg1.menuOpenedConnection = var8.MenuOpened:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end)

	local function OnCharacterChildAdded(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = true
		end

		if arg1:IsA("Humanoid") then
			local var4 = arg1.humanoidDiedConn
			if var4 then
				var4:Disconnect()
			end

			arg1.humanoidDiedConn = arg1.Died:Connect(function()
			end)

		end
	end

	arg1.characterChildAddedConn = arg2.ChildAdded:Connect(function(arg1)
		OnCharacterChildAdded(arg1)
	end)

	arg1.characterChildRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = false
		end
	end)

	for k1, v1 in pairs(arg2:GetChildren()) do
		OnCharacterChildAdded(v1)
	end

	arg1.preferredInputChangedConnection = var2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		arg1:OnPreferredInputChanged()
	end)
end

var22.Start = function(arg1)
	arg1:Enable(true)
end

var22.Stop = function(arg1)
	arg1:Enable(false)
end

var22.CleanupPath = function(_)
	if var18 then
		var18:Cancel()
		var18 = nil
	end

	if var19 then
		var19:Disconnect()
		var19 = nil
	end

	if var20 then
		var20:Disconnect()
		var20 = nil
	end
end

var22.Enable = function(arg1, arg2, arg3, arg4)
	if arg2 then
		if not arg1.running then
			if var13.Character then
				arg1:OnCharacterAdded(var13.Character)
			end

			arg1.onCharacterAddedConn = var13.CharacterAdded:Connect(function(arg1)
				arg1:OnCharacterAdded(arg1)
			end)

			arg1.running = true
		end

		arg1.touchJumpController = arg4
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(arg1.jumpEnabled)
		end
	else
		if arg1.running then
			arg1:DisconnectEvents()
			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var3 = var13.Character
			if var2.PreferredInput == Enum.PreferredInput.Touch and var3 then
				for k1, v1 in pairs(var3:GetChildren()) do
					if not v1:IsA("Tool") then
						continue
					end

					v1.ManualActivationOnly = false
				end
			end

			arg1.running = false
		end

		if arg1.touchJumpController and (not arg1.jumpEnabled) then
			arg1.touchJumpController:Enable(true)
		end

		arg1.touchJumpController = nil
	end

	var21.Enable(arg1, arg2)
	arg1.wasdEnabled = arg2 and arg3
	arg1.enabled = arg2
end

var22.OnRenderStepped = function(arg1, arg2)
	arg1.isJumping = false
	if var18 then
		var18:OnRenderStepped(arg2)
		if var18 then
			arg1.moveVector = var18.NextActionMoveDirection
			arg1.moveVectorIsCameraRelative = false
			if var18.NextActionJump then
				arg1.isJumping = true
			end
		else
			arg1.moveVector = arg1.keyboardMoveVector
			arg1.moveVectorIsCameraRelative = true
		end
	else
		arg1.moveVector = arg1.keyboardMoveVector
		arg1.moveVectorIsCameraRelative = true
	end

	if arg1.jumpRequested then
		arg1.isJumping = true
	end
end

var22.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.keyboardMoveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg1.wasdEnabled then
		arg1.keyboardMoveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
	end
end

var22.UpdateJump = function(_)
end

var22.SetShowPath = function(_, arg2)
	bool1 = arg2
end

var22.GetShowPath = function(_)
	return bool1
end

var22.SetWaypointTexture = function(_, arg2)
	var9.SetWaypointTexture(arg2)
end

var22.GetWaypointTexture = function(_)
	return var9.GetWaypointTexture()
end

var22.SetWaypointRadius = function(_, arg2)
	var9.SetWaypointRadius(arg2)
end

var22.GetWaypointRadius = function(_)
	return var9.GetWaypointRadius()
end

var22.SetEndWaypointTexture = function(_, arg2)
	var9.SetEndWaypointTexture(arg2)
end

var22.GetEndWaypointTexture = function(_)
	return var9.GetEndWaypointTexture()
end

var22.SetWaypointsAlwaysOnTop = function(_, arg2)
	var9.SetWaypointsAlwaysOnTop(arg2)
end

var22.GetWaypointsAlwaysOnTop = function(_)
	return var9.GetWaypointsAlwaysOnTop()
end

var22.SetFailureAnimationEnabled = function(_, arg2)
	str1 = arg2
end

var22.GetFailureAnimationEnabled = function(_)
	return str1
end

local function UpdateIgnoreTag(arg1)
	if arg1 == var14 then
		return
	end

	if var15 then
		var15:Disconnect()
		var15 = nil
	end

	if var16 then
		var16:Disconnect()
		var16 = nil
	end

	var14 = arg1
	local var1 = var13
	var17 = { var1 and var13.Character }
	if var14 ~= nil then
		for k1, v1 in ipairs((var7:GetTagged(var14))) do
			table.insert(var17, v1)
		end

		var15 = var7:GetInstanceAddedSignal(var14):Connect(function(arg1)
			table.insert(var17, arg1)
		end)

		var16 = var7:GetInstanceRemovedSignal(var14):Connect(function(arg1)
			for i1 = 1, #var17 do
				if var17[i1] ~= arg1 then
					continue
				end

				var17[i1] = var17[#var17]
				table.remove(var17)
				return
			end
		end)

	end
end

var22.SetIgnoredPartsTag = function(_, arg2)
	UpdateIgnoreTag(arg2)
end

var22.GetIgnoredPartsTag = function(_)
	return var14
end

var22.SetUseDirectPath = function(_, arg2)
	bool2 = arg2
end

var22.GetUseDirectPath = function(_)
	return bool2
end

var22.SetAgentSizeIncreaseFactor = function(_, arg2)
	num1 = arg2 / 100 + 1
end

var22.GetAgentSizeIncreaseFactor = function(_)
	return (num1 - 1) * 100
end

var22.SetUnreachableWaypointTimeout = function(_, arg2)
	num2 = arg2
end

var22.GetUnreachableWaypointTimeout = function(_)
	return num2
end

var22.SetUserJumpEnabled = function(arg1, arg2)
	arg1.jumpEnabled = arg2
	if arg1.touchJumpController then
		arg1.touchJumpController:Enable(arg2)
	end
end

var22.GetUserJumpEnabled = function(arg1)
	return arg1.jumpEnabled
end

var22.MoveTo = function(_, arg2, arg3, arg4)
	local var2 = var13.Character
	if var2 == nil then
		return false
	end

	local var4 = Pather(arg2, Vector3.new(0, 1, 0), arg4)
	if var4 and var4:IsValidPath() then
		HandleMoveTo(var4, arg2, nil, var2, arg3)
		return true
	end

	return false
end

return var22

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.PathDisplay [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = RaycastParams.new()
var2.FilterType = Enum.RaycastFilterType.Exclude
str1 = {
	spacing = 8,
	image = "rbxasset://textures/Cursors/Gamepad/Pointer.png",
	imageSize = Vector2.new(2, 2),
}

local var3 = Instance.new("Model")
var3.Name = "PathDisplayPoints"
local var4 = Instance.new("Part")
var4.Anchored = true
var4.CanCollide = false
var4.Transparency = 1
var4.Name = "PathDisplayAdornee"
var4.CFrame = CFrame.new(0, 0, 0)
var4.Parent = var3
local num1 = 30
local tbl1 = {}
local tbl2 = {}
local tbl3 = {}
for i1 = 1, num1 do
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Archivable = false
	var5.Adornee = var4
	var5.Image = str1.image
	var5.Size = str1.imageSize
	tbl3[i1] = var5
end

str1.setCurrentPoints = function(arg1)
	if typeof(arg1) == "table" then
		tbl1 = arg1
		return
	end

	tbl1 = {}
end

str1.clearRenderedPath = function()
	for k1, v1 in ipairs(tbl2) do
		v1.Parent = nil
		local var1 = num1 + 1
		num1 = var1
		tbl3[num1] = v1
	end

	tbl2 = {}
	var3.Parent = nil
end

local function renderPoint(arg1, _)
	if num1 == 0 then
		return nil
	end

	local var5 = tbl3[1]
	local var6
	if not var5 then
		var6 = nil
	else
		tbl3[1] = tbl3[num1]
		tbl3[num1] = nil
		local var7 = num1 - 1
		num1 = var7
		var6 = var5
	end

	if var1 then
		var2.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
		var5 = workspace:Raycast(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), var2)
		if not var5 then
			return nil
		end

		var6.CFrame = CFrame.lookAlong(var5.Position, var5.Normal)
		var6.Parent = var3
		return var6
	end

	local var8, var9, var10 = workspace:FindPartOnRayWithIgnoreList(Ray.new(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0)), { game.Players.LocalPlayer.Character, workspace.CurrentCamera })
	if not var8 then
		return nil
	end

	var6.CFrame = CFrame.new(var9, var9 + var10)
	var6.Parent = var3
	return var6
end

str1.renderPath = function()
	str1.clearRenderedPath()
	if not tbl1 or #tbl1 == 0 then
		return
	end

	local var1 = #tbl1
	tbl2[1] = renderPoint(tbl1[var1], true)
	local num1 = 0
	if not tbl2[1] then
		return
	end

	while true do
		local var2 = tbl1[var1]
		local var4 = tbl1[var1 - 1]
		if var1 < 2 then
			break
		end

		local var5 = var4 - var2
		local var7 = var5.magnitude
		if var7 < num1 then
			num1 = num1 - var7
		else
			local var9 = renderPoint(var2 + var5.unit * num1, false)
			if var9 then
				tbl2[#tbl2 + 1] = var9
			end
		end

		var1 = var1 - 1
		num1 = num1 + str1.spacing
	end

	var3.Parent = workspace.CurrentCamera
end

return str1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchJump [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "CharacterUtil"
local str3 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
str1 = require(var1:WaitForChild(str3)).getUserFlag("UserAllowAbilityControls")
local str4 = "AvatarAbilitiesInterface"
str2 = nil
str2 = str1 and require(script.Parent:WaitForChild(str4))
local str5 = "BaseCharacterController"
local var4 = require(script.Parent:WaitForChild(str5))
local var5 = game:GetService("GuiService")
str4 = setmetatable({}, var4)
str4.__index = str4
str4.new = function()
	local var1 = setmetatable(var4.new(), str4)
	var1.parentUIFrame = nil
	var1.jumpButton = nil
	var1.externallyEnabled = false
	var1.isJumping = false
	var1._active = false
	var1._connectionUtil = var2.new()
	return var1
end

str3 = {
	"rbxasset://textures/ui/Input/JumpButtonRegular.png",
	"rbxasset://textures/ui/Input/JumpButtonPressed.png",
}

str4._reset = function(arg1)
	arg1.isJumping = false
	arg1.touchObject = nil
	if arg1.jumpButton then
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[1]
			return
		end

		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end

str4.EnableButton = function(arg1, arg2)
	if arg2 == arg1._active then
		return
	end

	if arg2 then
		if not arg1.jumpButton then
			arg1:Create()
		end

		arg1.jumpButton.Visible = true
		local function fn2(arg1)
			if arg1 == arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("JUMP_INPUT_ENDED", arg1.jumpButton.InputEnded:Connect(fn2))
		fn2 = function()
			if arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("MENU_OPENED", var5.MenuOpened:Connect(fn2))
	else
		if arg1.jumpButton then
			arg1.jumpButton.Visible = false
		end

		arg1._connectionUtil:disconnect("JUMP_INPUT_ENDED")
		arg1._connectionUtil:disconnect("MENU_OPENED")
	end

	arg1:_reset()
	arg1._active = arg2
end

str4.UpdateEnabled = function(arg1)
	local var2 = var3.getChild("Humanoid", "Humanoid")
	if var2 and (arg1.externallyEnabled and (var2.UseJumpPower and 0 < var2.JumpPower or not var2.UseJumpPower and (0 < var2.JumpHeight and var2:GetStateEnabled(Enum.HumanoidStateType.Jumping)))) then
		arg1:EnableButton(true)
		return
	end

	arg1:EnableButton(false)
end

str4._setupConfigurations = function(arg1)
	local function update()
		arg1:UpdateEnabled()
	end

	arg1._connectionUtil:trackConnection("HUMANOID", (var3.onChild("Humanoid", "Humanoid", function(arg1)
		arg1:UpdateEnabled()
		arg1:_reset()
		local var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", arg1:GetPropertyChangedSignal("JumpPower"):Connect(var1))
		var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", arg1:GetPropertyChangedSignal("JumpHeight"):Connect(var1))
		var1 = function(arg1, arg2)
			if arg1 == Enum.HumanoidStateType.Jumping and arg2 ~= arg1._active then
				arg1:UpdateEnabled()
			end
		end

		arg1._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", arg1.StateEnabledChanged:Connect(var1))
	end)))
end

str4.Enable = function(arg1, arg2, arg3)
	if arg3 then
		arg1.parentUIFrame = arg3
	end

	if arg1.externallyEnabled == arg2 then
		return
	end

	arg1.externallyEnabled = arg2
	arg1:UpdateEnabled()
	if arg2 then
		arg1:_setupConfigurations()
		return
	end

	arg1._connectionUtil:disconnectAll()
end

str4.Create = function(arg1)
	if not arg1.parentUIFrame then
		return
	end

	if arg1.jumpButton then
		arg1.jumpButton:Destroy()
		arg1.jumpButton = nil
	end

	if arg1.absoluteSizeChangedConn then
		arg1.absoluteSizeChangedConn:Disconnect()
		arg1.absoluteSizeChangedConn = nil
	end

	if str1 and arg1.avatarAbilitiesEnabledChangedConn then
		arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
		arg1.avatarAbilitiesEnabledChangedConn = nil
	end

	arg1.jumpButton = Instance.new("ImageButton")
	arg1.jumpButton.Name = "JumpButton"
	arg1.jumpButton.Visible = false
	arg1.jumpButton.BackgroundTransparency = 1
	if str1 and str2.isEnabled() then
		arg1.jumpButton.Image = str3[1]
	else
		arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
		arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
	end

	local function ResizeJumpButton()
		local var2 = math.min(arg1.parentUIFrame.AbsoluteSize.x, arg1.parentUIFrame.AbsoluteSize.y) <= 500
		if str1 then
			if str2.isEnabled() then
				local var3 = if var2 then 72 else 120
				local var4 = if var2 then 64 else 100
				arg1.jumpButton.Image = str3[1]
				arg1.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				arg1.jumpButton.ImageRectSize = Vector2.new(0, 0)
				arg1.jumpButton.Size = UDim2.new(0, var3, 0, var3)
				arg1.jumpButton.Position = UDim2.new(1, -var3 - var4, 1, -var3 - (if var2 then 64 else 112))
				return
			end
		end

		local var5 = if var2 then 70 else 120
		if str1 then
			arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
		end

		arg1.jumpButton.Size = UDim2.new(0, var5, 0, var5)
		local var6 = var2 and UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 - 20) or UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 * 1.75)
		arg1.jumpButton.Position = var6
	end

	ResizeJumpButton()
	arg1.absoluteSizeChangedConn = arg1.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeJumpButton)
	if str1 then
		arg1.avatarAbilitiesEnabledChangedConn = str2.GetEnabledChangedSignal():Connect(ResizeJumpButton)
	end

	arg1.touchObject = nil
	arg1.jumpButton.InputBegan:connect(function(arg1)
		if arg1.touchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.touchObject = arg1
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[2]
		else
			arg1.jumpButton.ImageRectOffset = Vector2.new(146, 146)
		end

		arg1.isJumping = true
	end)

	arg1.jumpButton.Parent = arg1.parentUIFrame
end

return str4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick [ModuleScript]
-- y u r i

game:GetService("Players")
UserSettings():GetService("UserGameSettings")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
local var2 = nil
var2 = var1 and require(script.Parent:WaitForChild(str2))
str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var3 = game:GetService("GuiService")
local var4 = game:GetService("UserInputService")
local var5 = setmetatable({}, str1)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str1.new(), var5)
	var1.isFollowStick = false
	var1.thumbstickFrame = nil
	var1.moveTouchObject = nil
	var1.onTouchMovedConn = nil
	var1.onTouchEndedConn = nil
	var1.screenPos = nil
	var1.stickImage = nil
	var1.thumbstickSize = nil
	return var1
end

var5.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1.thumbstickFrame.Visible = true
	else
		arg1.thumbstickFrame.Visible = false
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
end

var5.OnInputEnded = function(arg1)
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickFrame.Size.X.Offset / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickFrame.Size.Y.Offset / 2 - arg1.thumbstickSize / 4)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.moveTouchObject = nil
end

var5.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onTouchMovedConn then
			arg1.onTouchMovedConn:Disconnect()
			arg1.onTouchMovedConn = nil
		end

		if arg1.onTouchEndedConn then
			arg1.onTouchEndedConn:Disconnect()
			arg1.onTouchEndedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var1 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.Name = "ThumbstickFrame"
	arg1.thumbstickFrame.Active = true
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	local var5 = Instance.new("ImageLabel")
	var5.Name = "OuterImage"
	var5.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	var5.ImageRectOffset = Vector2.new()
	var5.ImageRectSize = Vector2.new(220, 220)
	var5.BackgroundTransparency = 1
	var5.Position = UDim2.new(0, 0, 0, 0)
	arg1.stickImage = Instance.new("ImageLabel")
	arg1.stickImage.Name = "StickImage"
	arg1.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	arg1.stickImage.ImageRectOffset = Vector2.new(220, 0)
	arg1.stickImage.ImageRectSize = Vector2.new(111, 111)
	arg1.stickImage.BackgroundTransparency = 1
	arg1.stickImage.ZIndex = 2
	local function ResizeThumbstick()
		local var4 = math.min(arg2.AbsoluteSize.X, arg2.AbsoluteSize.Y) <= 500
		if var1 then
			if var2.isEnabled() then
				local var6 = if var4 then 64 else 100
				local var7 = if var4 then 64 else 112
				local var8 = arg1
				var8.thumbstickSize = if var4 then 72 else 120
				arg1.screenPos = UDim2.new(0, var6, 1, -arg1.thumbstickSize - var7)
			else
				local var9 = arg1
				var9.thumbstickSize = if var4 then 70 else 120
				local var10 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
				arg1.screenPos = var10
			end
		else
			local var11 = arg1
			var11.thumbstickSize = if var4 then 70 else 120
			local var12 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
			arg1.screenPos = var12
		end

		arg1.thumbstickFrame.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.thumbstickFrame.Position = arg1.screenPos
		var5.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.stickImage.Size = UDim2.new(0, arg1.thumbstickSize / 2, 0, arg1.thumbstickSize / 2)
		arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var1 then
		arg1.avatarAbilitiesEnabledChangedConn = var2.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	var5.Parent = arg1.thumbstickFrame
	arg1.stickImage.Parent = arg1.thumbstickFrame
	local var6 = nil
	arg1.thumbstickFrame.InputBegan:Connect(function(arg1)
		if arg1.moveTouchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.moveTouchObject = arg1
		arg1.thumbstickFrame.Position = UDim2.new(0, arg1.Position.X - arg1.thumbstickFrame.Size.X.Offset / 2, 0, arg1.Position.Y - arg1.thumbstickFrame.Size.Y.Offset / 2)
		var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
		Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y)
	end)

	local function MoveStick(arg1)
		local var1 = Vector2.new(arg1.X - var6.X, arg1.Y - var6.Y)
		local var5 = arg1.thumbstickFrame.AbsoluteSize.X / 2
		local var7 = var1.magnitude
		if arg1.isFollowStick and var5 < var7 then
			local var8 = var1.unit * var5
			arg1.thumbstickFrame.Position = UDim2.new(0, arg1.X - arg1.thumbstickFrame.AbsoluteSize.X / 2 - var8.X, 0, arg1.Y - arg1.thumbstickFrame.AbsoluteSize.Y / 2 - var8.Y)
		else
			var1 = var1.unit * math.min(var7, var5)
		end

		arg1.stickImage.Position = UDim2.new(0, var1.X + arg1.stickImage.AbsoluteSize.X / 2, 0, var1.Y + arg1.stickImage.AbsoluteSize.Y / 2)
	end

	arg1.onTouchMovedConn = var4.TouchMoved:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
			local var1 = Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y) / (arg1.thumbstickSize / 2)
			local var3 = var1.magnitude
			if var3 < 0.05 then
				var1 = Vector3.new()
			else
				var1 = var1.unit * math.min(1, (var3 - 0.05) / 0.95)
				var1 = Vector3.new(var1.X, 0, var1.Y)
			end

			arg1.moveVector = var1
			MoveStick(arg1.Position)
		end
	end)

	arg1.onTouchEndedConn = var4.TouchEnded:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var3.MenuOpened:Connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Keyboard [ModuleScript]
-- y u r i

script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "BaseCharacterController"
local var1 = require(script.Parent:WaitForChild(str1))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = Vector3.new()
local var5 = setmetatable({}, var1)
var5.__index = var5
var5.new = function(arg1)
	local var2 = setmetatable(var1.new(), var5)
	var2.CONTROL_ACTION_PRIORITY = arg1
	var2.forwardValue = 0
	var2.backwardValue = 0
	var2.leftValue = 0
	var2.rightValue = 0
	var2.jumpEnabled = true
	return var2
end

var5.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.moveVector = var4
	arg1.jumpRequested = false
	arg1:UpdateJump()
	if arg2 then
		arg1:BindContextActions()
		arg1:ConnectFocusEventListeners()
	else
		arg1._connectionUtil:disconnectAll()
	end

	arg1.enabled = arg2
	return true
end

var5.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.moveVector = var4
		return
	end

	arg1.moveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
end

var5.UpdateJump = function(arg1)
	arg1.isJumping = arg1.jumpRequested
end

var5.BindContextActions = function(arg1)
	var3:BindActionAtPriority("moveForwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.forwardValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterForward)

	var3:BindActionAtPriority("moveBackwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.backwardValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterBackward)

	var3:BindActionAtPriority("moveLeftAction", function(_, arg2, _)
		local var1 = arg1
		var1.leftValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterLeft)

	var3:BindActionAtPriority("moveRightAction", function(_, arg2, _)
		local var1 = arg1
		var1.rightValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterRight)

	var3:BindActionAtPriority("jumpAction", function(_, arg2, _)
		local var2 = arg1.jumpEnabled
		local var3 = arg1
		if var2 then
			var2 = arg2 == Enum.UserInputState.Begin
		end

		var3.jumpRequested = var2
		arg1:UpdateJump()
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterJump)

	arg1._connectionUtil:trackBoundFunction("moveForwardAction", function()
		var3:UnbindAction("moveForwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveBackwardAction", function()
		var3:UnbindAction("moveBackwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveLeftAction", function()
		var3:UnbindAction("moveLeftAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveRightAction", function()
		var3:UnbindAction("moveRightAction")
	end)

	arg1._connectionUtil:trackBoundFunction("jumpAction", function()
		var3:UnbindAction("jumpAction")
	end)
end

var5.ConnectFocusEventListeners = function(arg1)
	local function onFocusReleased()
		arg1.moveVector = var4
		arg1.forwardValue = 0
		arg1.backwardValue = 0
		arg1.leftValue = 0
		arg1.rightValue = 0
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	local var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("textBoxFocusReleased", var2.TextBoxFocusReleased:Connect(var1))
	var1 = function(_)
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	arg1._connectionUtil:trackConnection("textBoxFocused", var2.TextBoxFocused:Connect(var1))
	var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("windowFocusReleased", var2.WindowFocused:Connect(var1))
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay [ModuleScript]
-- y u r i

local var1 = UDim2.new(0, 42, 0, 50)
local var2 = Vector2.new(0, 0.5)
local var3 = Vector2.new(0, 1)
local var4 = Vector2.new(0, 0.5)
local var5 = Vector2.new(0.1, 0.5)
local var6 = Vector2.new(-0.1, 0.5)
local var7 = Vector2.new(1.5, 1.5)
local var8 = RaycastParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local str1 = "FlagUtil"
local bool1 = false
local str2 = "rbxasset://textures/ui/traildot.png"
local str3 = "rbxasset://textures/ui/waypoint.png"
local var9 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
str1 = function()
	local var3 = Instance.new("Part")
	var3.Size = Vector3.new(1, 1, 1)
	var3.Anchored = true
	var3.CanCollide = false
	var3.Name = "TrailDot"
	var3.Transparency = 1
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Name = "TrailDotImage"
	var5.Size = var7
	var5.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var5.AlwaysOnTop = bool1
	var5.Image = str2
	var5.Adornee = var3
	var5.Parent = var3
	local var6 = Instance.new("Part")
	var6.Size = Vector3.new(2, 2, 2)
	var6.Anchored = true
	var6.CanCollide = false
	var6.Name = "EndWaypoint"
	var6.Transparency = 1
	local var8 = Instance.new("ImageHandleAdornment")
	var8.Name = "TrailDotImage"
	var8.Size = var7
	var8.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var8.AlwaysOnTop = bool1
	var8.Image = str2
	var8.Adornee = var6
	var8.Parent = var6
	local var9 = Instance.new("BillboardGui")
	var9.Name = "EndWaypointBillboard"
	var9.Size = var1
	var9.LightInfluence = 0
	var9.SizeOffset = var2
	var9.AlwaysOnTop = true
	var9.Adornee = var6
	var9.Parent = var6
	local var10 = Instance.new("ImageLabel")
	var10.Image = str3
	var10.BackgroundTransparency = 1
	var10.Size = UDim2.new(1, 0, 1, 0)
	var10.Parent = var9
	local var11 = Instance.new("Part")
	var11.Size = Vector3.new(2, 2, 2)
	var11.Anchored = true
	var11.CanCollide = false
	var11.Name = "FailureWaypoint"
	var11.Transparency = 1
	local var12 = Instance.new("ImageHandleAdornment")
	var12.Name = "TrailDotImage"
	var12.Size = var7
	var12.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var12.AlwaysOnTop = bool1
	var12.Image = str2
	var12.Adornee = var11
	var12.Parent = var11
	local var13 = Instance.new("BillboardGui")
	var13.Name = "FailureWaypointBillboard"
	var13.Size = var1
	var13.LightInfluence = 0
	var13.SizeOffset = var4
	var13.AlwaysOnTop = true
	var13.Adornee = var11
	var13.Parent = var11
	local var14 = Instance.new("Frame")
	var14.BackgroundTransparency = 1
	var14.Size = UDim2.new(0, 0, 0, 0)
	var14.Position = UDim2.new(0.5, 0, 1, 0)
	var14.Parent = var13
	local var15 = Instance.new("ImageLabel")
	var15.Image = str3
	var15.BackgroundTransparency = 1
	var15.Position = UDim2.new(0, -var1.X.Offset / 2, 0, -var1.Y.Offset)
	var15.Size = var1
	var15.Parent = var14
	return var3, var6, var11
end

local var10 = game:GetService("Workspace")
local var11 = game:GetService("Players").LocalPlayer
local var12 = game:GetService("TweenService")
local var13 = game:GetService("RunService")
local var14, var15, var16 = str1()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

local function placePathWaypoint(arg1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var2 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if not var2 then
			return
		end

		arg1.CFrame = CFrame.lookAlong(var2.Position, var2.Normal)
		local var3 = var10.CurrentCamera
		local var5 = var3:FindFirstChild("ClickToMoveDisplay")
		if not var5 then
			var5 = Instance.new("Model")
			var5.Name = "ClickToMoveDisplay"
			var5.Parent = var3
		end

		arg1.Parent = var5
		return
	end

	local var12, var13, var14 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var12 then
		arg1.CFrame = CFrame.new(var13, var13 + var14)
		local var15 = var10.CurrentCamera
		local var17 = var15:FindFirstChild("ClickToMoveDisplay")
		if not var17 then
			var17 = Instance.new("Model")
			var17.Name = "ClickToMoveDisplay"
			var17.Parent = var15
		end

		arg1.Parent = var17
	end
end

tbl1.NewDisplayModel = function(_, arg2)
	local var1 = var14:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.ClosestWayPoint = arg2
	return var1
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.Destroy = function(arg1)
	arg1.Destroyed = true
	arg1.Tween:Cancel()
	arg1.DisplayModel:Destroy()
end

tbl2.NewDisplayModel = function(_, arg2)
	local var1 = var15:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl2.CreateTween = function(arg1)
	local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, -1, true)
	local var2 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, var1, { SizeOffset = var3 })
	var2:Play()
	return var2
end

tbl2.TweenInFrom = function(arg1, arg2)
	arg1.DisplayModel.EndWaypointBillboard.StudsOffset = Vector3.new(0, (arg2 - arg1.DisplayModel.Position).Y, 0)
	local var1 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), { StudsOffset = Vector3.new(0, 0, 0) })
	var1:Play()
	return var1
end

tbl2.new = function(arg1, arg2, arg3)
	local var1 = setmetatable({}, tbl2)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.Destroyed = false
	if arg3 and 5 < (arg3 - arg1).Magnitude then
		var2 = var1:TweenInFrom(arg3)
		var1.Tween = var2
		coroutine.wrap(function()
			var1.Tween.Completed:Wait()
			if not var1.Destroyed then
				var1.Tween = var1:CreateTween()
			end
		end)()

	else
		var2 = var1:CreateTween()
		var1.Tween = var2
	end

	var1.ClosestWayPoint = arg2
	return var1
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.Hide = function(arg1)
	arg1.DisplayModel.Parent = nil
end

tbl3.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

tbl3.NewDisplayModel = function(_, arg2)
	local var1 = var16:Clone()
	placePathWaypoint(var1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var3 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if var3 then
			var1.CFrame = CFrame.lookAlong(var3.Position, var3.Normal)
			local var4 = var10.CurrentCamera
			local var6 = var4:FindFirstChild("ClickToMoveDisplay")
			if not var6 then
				var6 = Instance.new("Model")
				var6.Name = "ClickToMoveDisplay"
				var6.Parent = var4
			end

			var1.Parent = var6
			return var1
		end
	end

	local var13, var14, var15 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var13 then
		var1.CFrame = CFrame.new(var14, var14 + var15)
		local var17 = var10.CurrentCamera
		local var19 = var17:FindFirstChild("ClickToMoveDisplay")
		if not var19 then
			var19 = Instance.new("Model")
			var19.Name = "ClickToMoveDisplay"
			var19.Parent = var17
		end

		var1.Parent = var19
	end

	return var1
end

tbl3.RunFailureTween = function(arg1)
	wait(0.125)
	local var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local var2 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var5 })
	var2:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 10 }):Play()
	var2.Completed:wait()
	local var3 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	local var7 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var3, { SizeOffset = var6 })
	var7:Play()
	var1 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame.ImageLabel, var1, { ImageColor3 = Color3.new(0.75, 0.75, 0.75) }):Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = -10 }):Play()
	var7.Completed:wait()
	var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	var3 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var4 })
	var3:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 0 }):Play()
	var3.Completed:wait()
	wait(0.125)
end

tbl3.new = function(arg1)
	local var1 = setmetatable({}, tbl3)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	return var1
end

local var17 = Instance.new("Animation")
var17.AnimationId = "rbxassetid://2874840706"
local var18 = nil
local num1 = 0
local function createTrailDots(arg1, arg2)
	local tbl3 = {}
	local num1 = 1
	for i1 = 1, #arg1 - 1 do
		local var1 = (arg1[i1].Position - arg1[#arg1].Position).Magnitude < 3
		local bool2 = false
		if i1 % 2 == 0 then
			bool2 = not var1
		end

		if not bool2 then
			continue
		end

		tbl3[num1] = tbl1.new(arg1[i1].Position, i1)
		num1 = num1 + 1
	end

	table.insert(tbl3, (tbl2.new(arg1[#arg1].Position, #arg1, arg2)))
	num1 = 1
	local tbl4 = {}
	for i2 = #tbl3, 1, -1 do
		tbl4[num1] = tbl3[i2]
		num1 = num1 + 1
	end

	return tbl4
end

local var19 = nil
return {
	CreatePathDisplay = function(arg1, arg2)
		local var1 = num1 + 1
		num1 = var1
		var1 = createTrailDots(arg1, arg2)
		local var2 = "ClickToMoveResizeTrail" .. num1
		var13:BindToRenderStep(var2, Enum.RenderPriority.Camera.Value - 1, function()
			if #var1 == 0 then
				var13:UnbindFromRenderStep(var2)
				return
			end

			local var3 = var10.CurrentCamera.CFrame.p
			for i1 = 1, #var1 do
				local var4 = var1[i1].DisplayModel:FindFirstChild("TrailDotImage")
				if not var4 then
					continue
				end

				var4.Size = var7 * (math.clamp((var1[i1].DisplayModel.Position - var3).Magnitude - 10, 0, 90) / 90 * 1.5 + 1)
			end
		end)

		local function removePathBeforePoint(arg1)
			for i1 = #var1, 1, -1 do
				local var2 = var1[i1]
				if var2.ClosestWayPoint > arg1 then
					break
				end

				var2:Destroy()
				var1[i1] = nil
				continue
			end
		end

		return function()
			removePathBeforePoint(#arg1)
		end, removePathBeforePoint
	end,
	DisplayFailureWaypoint = function(arg1)
		if var19 then
			var19:Hide()
		end

		local var1 = tbl3.new(arg1)
		var19 = var1
		coroutine.wrap(function()
			var1:RunFailureTween()
			var1:Destroy()
			var1 = nil
		end)()
	end,
	CreateEndWaypoint = function(arg1)
		local var1 = arg1
		return tbl2.new(var1)
	end,
	PlayFailureAnimation = function()
		local var2 = var11.Character
		local var4 = if var2 then var2:FindFirstChildOfClass("Humanoid") else nil
		if var4 then
			if var4 == nil then
				var2 = var18
			else
				var18 = var4:LoadAnimation(var17)
				assert(var18, "")
				var18.Priority = Enum.AnimationPriority.Action
				var18.Looped = false
				var2 = var18
			end

			var2:Play()
		end
	end,
	CancelFailureAnimation = function()
		if var18 ~= nil and var18.IsPlaying then
			var18:Stop()
		end
	end,
	SetWaypointTexture = function(arg1)
		str2 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointTexture = function()
		return str2
	end,
	SetWaypointRadius = function(arg1)
		var7 = Vector2.new(arg1, arg1)
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointRadius = function()
		return var7.X
	end,
	SetEndWaypointTexture = function(arg1)
		str3 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetEndWaypointTexture = function()
		return str3
	end,
	SetWaypointsAlwaysOnTop = function(arg1)
		bool1 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointsAlwaysOnTop = function()
		return bool1
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VehicleController [ModuleScript]
-- y u r i

local var1 = game:GetService("ContextActionService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var1 = setmetatable({}, tbl1)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.enabled = false
	var1.vehicleSeat = nil
	var1.throttle = 0
	var1.steer = 0
	var1.acceleration = 0
	var1.decceleration = 0
	var1.turningRight = 0
	var1.turningLeft = 0
	var1.vehicleMoveVector = Vector3.new(0, 0, 0)
	var1.autoPilot = {}
	var1.autoPilot.MaxSpeed = 0
	var1.autoPilot.MaxSteeringAngle = 0
	return var1
end

tbl1.BindContextActions = function(arg1)
	var1:BindActionAtPriority("throttleAccel", function(arg1, arg2, arg3)
		arg1:OnThrottleAccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonR2)

	var1:BindActionAtPriority("throttleDeccel", function(arg1, arg2, arg3)
		arg1:OnThrottleDeccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonL2)

	var1:BindActionAtPriority("arrowSteerRight", function(arg1, arg2, arg3)
		arg1:OnSteerRight(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Right)

	var1:BindActionAtPriority("arrowSteerLeft", function(arg1, arg2, arg3)
		arg1:OnSteerLeft(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Left)
end

tbl1.Enable = function(arg1, arg2, arg3)
	if arg2 == arg1.enabled and arg3 == arg1.vehicleSeat then
		return
	end

	arg1.enabled = arg2
	arg1.vehicleMoveVector = Vector3.new(0, 0, 0)
	if arg2 then
		if not arg3 then
			return
		end

		arg1.vehicleSeat = arg3
		arg1:SetupAutoPilot()
		arg1:BindContextActions()
		return
	end

	var1:UnbindAction("throttleAccel")
	var1:UnbindAction("throttleDeccel")
	var1:UnbindAction("arrowSteerRight")
	var1:UnbindAction("arrowSteerLeft")
	arg1.vehicleSeat = nil
end

tbl1.OnThrottleAccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.acceleration = 0
	else
		arg1.acceleration = -1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnThrottleDeccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.decceleration = 0
	else
		arg1.decceleration = 1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnSteerRight = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningRight = 0
	else
		arg1.turningRight = 1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.OnSteerLeft = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningLeft = 0
	else
		arg1.turningLeft = -1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.Update = function(arg1, arg2, arg3, arg4)
	if arg1.vehicleSeat then
		if arg3 then
			arg2 = arg2 + Vector3.new(arg1.steer, 0, arg1.throttle)
	if not arg4 then
				arg1.vehicleSeat.ThrottleFloat = -arg2.Z
			end

			arg1.vehicleSeat.SteerFloat = arg2.X
			return arg2, true
		end

		local var1 = arg1.vehicleSeat.Occupant.RootPart.CFrame:VectorToObjectSpace(arg2)
		arg1.vehicleSeat.ThrottleFloat = arg1:ComputeThrottle(var1)
		arg1.vehicleSeat.SteerFloat = arg1:ComputeSteer(var1)
		return Vector3.new(0, 0, 0), true
	end

	return arg2, false
end

tbl1.ComputeThrottle = function(_, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -arg2.Z
	end

	return 0
end

tbl1.ComputeSteer = function(arg1, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -math.atan2(-arg2.x, -arg2.z) * 57.295779513082323 / arg1.autoPilot.MaxSteeringAngle
	end

	return 0
end

tbl1.SetupAutoPilot = function(arg1)
	arg1.autoPilot.MaxSpeed = arg1.vehicleSeat.MaxSpeed
	arg1.autoPilot.MaxSteeringAngle = 35
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Vector3.new()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var3 = setmetatable({}, tbl1)
	var3.enabled = false
	var3.moveVector = var2
	var3.moveVectorIsCameraRelative = true
	var3.isJumping = false
	var3._connectionUtil = var1.new()
	return var3
end

tbl1.GetMoveVector = function(arg1)
	return arg1.moveVector
end

tbl1.IsMoveVectorCameraRelative = function(arg1)
	return arg1.moveVectorIsCameraRelative
end

tbl1.GetIsJumping = function(arg1)
	return arg1.isJumping
end

tbl1.Enable = function(_, _)
	error("BaseCharacterController:Enable must be overridden in derived classes and should not be called.")
	return false
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Gamepad [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = setmetatable({}, str1)
var4.__index = var4
local var5 = Enum.UserInputType.None
var4.new = function(arg1)
	local var1 = setmetatable(str1.new(), var4)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.forwardValue = 0
	var1.backwardValue = 0
	var1.leftValue = 0
	var1.rightValue = 0
	var1.thumbstickVector = Vector3.new(0, 0, 0)
	var1.activeGamepad = var5
	var1.gamepadConnectedConn = nil
	var1.gamepadDisconnectedConn = nil
	return var1
end

var4.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.thumbstickVector = Vector3.new(0, 0, 0)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		local var1 = arg1:GetHighestPriorityGamepad()
		arg1.activeGamepad = var1
		if arg1.activeGamepad ~= var5 then
			arg1:BindContextActions()
			arg1:ConnectGamepadConnectionListeners()
		else
			return false
		end
	else
		arg1:UnbindContextActions()
		arg1:DisconnectGamepadConnectionListeners()
		arg1.activeGamepad = var5
	end

	arg1.enabled = arg2
	return true
end

var4.GetHighestPriorityGamepad = function(_)
	local var1 = var5
	for k1, v1 in pairs((var2:GetConnectedGamepads())) do
		if v1.Value >= var1.Value then
			continue
		end

		var1 = v1
	end

	return var1
end

var4.UpdateMovement = function(arg1)
	arg1.moveVector = arg1.thumbstickVector + Vector3.new(0, 0, arg1.forwardValue + arg1.backwardValue)
end

var4.BindContextActions = function(arg1)
	if arg1.activeGamepad == var5 then
		return false
	end

	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	local function fn4(_, arg2, _)
		arg1.isJumping = arg2 == Enum.UserInputState.Begin
		return Enum.ContextActionResult.Sink
	end

	local function fn6(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			if var1 then
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
				arg1:UpdateMovement()
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end

			return Enum.ContextActionResult.Sink
		end

		if arg1.activeGamepad ~= arg3.UserInputType then
			return Enum.ContextActionResult.Pass
		end

		if arg3.KeyCode ~= Enum.KeyCode.Thumbstick1 then
			return
		end

		if var1 then
			if 0.2 < arg3.Position.magnitude then
				arg1.thumbstickVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
			end

			arg1:UpdateMovement()
		else
			if 0.2 < arg3.Position.magnitude then
				arg1.moveVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end
		end

		return Enum.ContextActionResult.Sink
	end

	local function fn8(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			arg1.forwardValue = 0
			arg1.backwardValue = 0
			arg1:UpdateMovement()
			return Enum.ContextActionResult.Sink
		end

		local num2 = 0
		if 0.2 < arg3.Position.magnitude then
			num2 = arg3.Position.Z
		end

		if arg3.KeyCode == Enum.KeyCode.ButtonUp then
			arg1.forwardValue = -num2
		else
			if arg3.KeyCode == Enum.KeyCode.ButtonDown then
				arg1.backwardValue = num2
			end
		end

		arg1:UpdateMovement()
		return Enum.ContextActionResult.Sink
	end

	if var1 then
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonCenter)
		var3:BindActionAtPriority("moveDirectionalButton", fn8, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonUp, Enum.KeyCode.ButtonDown)
	else
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
	end

	var3:BindActionAtPriority("moveThumbstick", fn6, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
	return true
end

var4.UnbindContextActions = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	if var1 then
		var3:UnbindAction("moveDirectionalButton")
	end

	var3:UnbindAction("moveThumbstick")
	var3:UnbindAction("jumpAction")
end

var4.OnNewGamepadConnected = function(arg1)
	local var2 = arg1:GetHighestPriorityGamepad()
	if var2 == arg1.activeGamepad then
		return
	end

	if var2 == var5 then
		warn("Gamepad:OnNewGamepadConnected found no connected gamepads")
		arg1:UnbindContextActions()
		return
	end

	if arg1.activeGamepad ~= var5 then
		arg1:UnbindContextActions()
	end

	arg1.activeGamepad = var2
	arg1:BindContextActions()
end

var4.OnCurrentGamepadDisconnected = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	local var2 = arg1:GetHighestPriorityGamepad()
	if arg1.activeGamepad ~= var5 and var2 == arg1.activeGamepad then
		warn("Gamepad:OnCurrentGamepadDisconnected found the supposedly disconnected gamepad in connectedGamepads.")
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	if var2 == var5 then
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	arg1.activeGamepad = var2
	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
end

var4.ConnectGamepadConnectionListeners = function(arg1)
	arg1.gamepadConnectedConn = var2.GamepadConnected:Connect(function(_)
		arg1:OnNewGamepadConnected()
	end)

	arg1.gamepadDisconnectedConn = var2.GamepadDisconnected:Connect(function(arg1)
		if arg1.activeGamepad == arg1 then
			arg1:OnCurrentGamepadDisconnected()
		end
	end)
end

var4.DisconnectGamepadConnectionListeners = function(arg1)
	if arg1.gamepadConnectedConn then
		arg1.gamepadConnectedConn:Disconnect()
		arg1.gamepadConnectedConn = nil
	end

	if arg1.gamepadDisconnectedConn then
		arg1.gamepadDisconnectedConn:Disconnect()
		arg1.gamepadDisconnectedConn = nil
	end
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VRNavigation [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = game:GetService("VRService")
local var3 = game:GetService("UserInputService")
local var4 = game:GetService("RunService")
local var5 = game:GetService("PathfindingService")
local var6 = game:GetService("ContextActionService")
local var7 = game:GetService("StarterGui")
local var8 = game:GetService("Players").LocalPlayer
str1 = RaycastParams.new()
str1.FilterType = Enum.RaycastFilterType.Exclude
local var9 = var1.getUserFlag("UserRaycastUpdateAPI2")
local var10 = Instance.new("BindableEvent")
var10.Name = "MovementUpdate"
var10.Parent = script
local var11 = nil
coroutine.wrap(function()
	local var2 = script.Parent:WaitForChild("PathDisplay")
	if var2 then
		var11 = require(var2)
	end
end)()

local str2 = "BaseCharacterController"
local var12 = require(script.Parent:WaitForChild(str2))
local var13 = setmetatable({}, var12)
var13.__index = var13
var13.new = function(arg1)
	local var1 = setmetatable(var12.new(), var13)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.navigationRequestedConn = nil
	var1.heartbeatConn = nil
	var1.currentDestination = nil
	var1.currentPath = nil
	var1.currentPoints = nil
	var1.currentPointIdx = 0
	var1.expectedTimeToNextPoint = 0
	var1.timeReachedLastPoint = tick()
	var1.moving = false
	var1.isJumpBound = false
	var1.moveLatch = false
	var1.userCFrameEnabledConn = nil
	return var1
end

var13.SetLaserPointerMode = function(_, arg2)
	pcall(function()
		var7:SetCore("VRLaserPointerMode", arg2)
	end)
end

var13.GetLocalHumanoid = function(_)
	local var2 = var8.Character
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2:GetChildren()) do
		if not v1:IsA("Humanoid") then
			continue
		end

		return v1
	end

	return nil
end

var13.HasBothHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 and var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.HasAnyHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 or var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.IsMobileVR = function(_)
	return var3.TouchEnabled
end

var13.HasGamepad = function(_)
	return var3.GamepadEnabled
end

var13.ShouldUseNavigationLaser = function(arg1)
	if arg1:IsMobileVR() then
		return true
	end

	if arg1:HasBothHandControllers() then
		return false
	end

	if not arg1:HasAnyHandControllers() then
		return not arg1:HasGamepad()
	end

	return true
end

var13.StartFollowingPath = function(arg1, arg2)
	currentPath = arg2
	currentPoints = currentPath:GetPointCoordinates()
	currentPointIdx = 1
	moving = true
	timeReachedLastPoint = tick()
	local var2 = arg1:GetLocalHumanoid()
	if var2 and (var2.Torso and 1 <= (#currentPoints)) then
		expectedTimeToNextPoint = (currentPoints[1] - var2.Torso.Position).magnitude / var2.WalkSpeed
	end

	var10:Fire("targetPoint", arg1.currentDestination)
end

var13.GoToPoint = function(arg1, arg2)
	currentPath = true
	currentPoints = { arg2 }
	currentPointIdx = 1
	moving = true
	local var1 = arg1:GetLocalHumanoid()
	timeReachedLastPoint = tick()
	expectedTimeToNextPoint = (var1.Torso.Position - arg2).magnitude / var1.WalkSpeed
	var10:Fire("targetPoint", arg2)
end

var13.StopFollowingPath = function(arg1)
	currentPath = nil
	currentPoints = nil
	currentPointIdx = 0
	moving = false
	arg1.moveVector = Vector3.new(0, 0, 0)
end

var13.TryComputePath = function(_, arg2, arg3)
	local num1 = 0
	local var1 = nil
	while not var1 do
		if num1 >= 5 then
			break
		end

		var1 = var5:ComputeSmoothPathAsync(arg2, arg3, 200)
		if var1.Status == Enum.PathStatus.ClosestNoPath or var1.Status == Enum.PathStatus.ClosestOutOfRange then
			var1 = nil
			return var1
		end

		if var1 then
			if var1.Status == Enum.PathStatus.FailStartNotEmpty then
				var1 = nil
			end
		end

		if not var1 then
			continue
		end

		if var1.Status ~= Enum.PathStatus.FailFinishNotEmpty then
			continue
		end

		arg2 = arg2 + (arg3 - arg2).Unit
		arg3 = arg3 + Vector3.new(0, 1, 0)
		num1 = num1 + 1
		var1 = nil
	end

	return var1
end

var13.OnNavigationRequest = function(arg1, arg2, _)
	local var1 = arg2.Position
	local var3 = var1.x
	local var4 = arg1.currentDestination
	local bool2 = false
	if var3 == var3 then
		bool2 = false
		if var3 ~= math.huge then
			bool2 = var3 ~= -math.huge
		end
	end

	if bool2 then
		var3 = var1.y
		bool2 = false
		if var3 == var3 then
			bool2 = false
			if var3 ~= math.huge then
				bool2 = var3 ~= -math.huge
			end
		end

		if bool2 then
			var3 = var1.z
			bool2 = false
			if var3 == var3 then
				bool2 = false
				if var3 ~= math.huge then
					bool2 = var3 ~= -math.huge
				end
			end
		end
	end

	if not bool2 then
		return
	end

	arg1.currentDestination = var1
	bool2 = arg1:GetLocalHumanoid()
	if not bool2 or (not bool2.Torso) then
		return
	end

	var3 = bool2.Torso.Position
	if (arg1.currentDestination - var3).magnitude < 12 then
		arg1:GoToPoint(arg1.currentDestination)
		return
	end

	if var4 then
		if 4 < (arg1.currentDestination - var4).magnitude then
			local var8 = arg1:TryComputePath(var3, arg1.currentDestination)
			if var8 then
				arg1:StartFollowingPath(var8)
				if not var11 then
					return
				end

				var11.setCurrentPoints(arg1.currentPoints)
				var11.renderPath()
				return
			end

			arg1:StopFollowingPath()
			if not var11 then
				return
			end

			var11.clearRenderedPath()
			return
		end
	end

	if moving then
		arg1.currentPoints[#currentPoints] = arg1.currentDestination
		return
	end

	arg1:GoToPoint(arg1.currentDestination)
end

var13.OnJumpAction = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1.isJumping = true
	end

	return Enum.ContextActionResult.Sink
end

var13.BindJumpAction = function(arg1, arg2)
	if arg2 then
		if not not arg1.isJumpBound then
			return
		end

		arg1.isJumpBound = true
		var6:BindActionAtPriority("VRJumpAction", function()
			return arg1:OnJumpAction()
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)

		return
	end

	if arg1.isJumpBound then
		arg1.isJumpBound = false
		var6:UnbindAction("VRJumpAction")
	end
end

var13.ControlCharacterGamepad = function(arg1, _, arg3, arg4)
	if arg4.KeyCode ~= Enum.KeyCode.Thumbstick1 then
		return
	end

	if arg3 == Enum.UserInputState.Cancel then
		arg1.moveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg3 ~= Enum.UserInputState.End then
		arg1:StopFollowingPath()
		if var11 then
			var11.clearRenderedPath()
		end

		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(true)
			arg1:SetLaserPointerMode("Hidden")
		end

		if 0.22 < arg4.Position.magnitude then
			arg1.moveVector = Vector3.new(arg4.Position.X, 0, -arg4.Position.Y)
			if 0 < arg1.moveVector.magnitude then
				local var1 = arg1.moveVector.unit * math.min(1, arg4.Position.magnitude)
				arg1.moveVector = var1
			end

			arg1.moveLatch = true
		end
	else
		arg1.moveVector = Vector3.new(0, 0, 0)
		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(false)
			arg1:SetLaserPointerMode("Navigation")
		end

		if arg1.moveLatch then
			arg1.moveLatch = false
			var10:Fire("offtrack")
		end
	end

	return Enum.ContextActionResult.Sink
end

var13.OnHeartbeat = function(arg1, arg2)
	local var2 = arg1:GetLocalHumanoid()
	local var3 = arg1.moveVector
	if not var2 or (not var2.Torso) then
		return
	end

	if arg1.moving then
		if arg1.currentPoints then
			local var13 = var2.Torso.Position
			local var14 = (currentPoints[1] - var13) * Vector3.new(1, 0, 1)
			local var15 = var14.magnitude
			if var15 < 1 then
				local var16 = var14 / var15
				local num1 = 0
				local var17 = currentPoints[1]
				for k1, v1 in pairs(currentPoints) do
					if k1 == 1 then
						continue
					end

					local var18 = (v1 - var17).magnitude
					num1 = num1 + var18 / var2.WalkSpeed
					var17 = v1
				end

				table.remove(currentPoints, 1)
				local var19 = currentPointIdx + 1
				currentPointIdx = var19
				if #currentPoints == 0 then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					return
				end

				if var11 then
					var11.setCurrentPoints(currentPoints)
					var11.renderPath()
				end

				expectedTimeToNextPoint = (currentPoints[1] - var13).magnitude / var2.WalkSpeed
				timeReachedLastPoint = tick()
			else
				if var9 then
					str1.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var22 = workspace:Raycast(var13 - Vector3.new(0, 1, 0), var16 * 3, str1)
					local var23 = workspace:Raycast(var22.Position + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0), str1).Position.Y - var13.Y
					if var22 and (var23 < 6 and -2 < var23) then
						var2.Jump = true
					end
				else
					local tbl1 = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var29, var30, var31 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var13 - Vector3.new(0, 1, 0), var16 * 3), tbl1)
					local var32, var33, var34 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var30 + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0)), tbl1)
					local var35 = var33.Y - var13.Y
					if var29 and (var35 < 6 and -2 < var35) then
						var2.Jump = true
					end
				end

				if expectedTimeToNextPoint + 2 < tick() - timeReachedLastPoint then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					var10:Fire("offtrack")
				end

				var3 = arg1.moveVector:Lerp(var16, arg2 * 10)
			end
		end
	end

	local var37 = var3.x
	local bool2 = false
	if var37 == var37 then
		bool2 = false
		if var37 ~= math.huge then
			bool2 = var37 ~= -math.huge
		end
	end

	if bool2 then
		var37 = var3.y
		bool2 = false
		if var37 == var37 then
			bool2 = false
			if var37 ~= math.huge then
				bool2 = var37 ~= -math.huge
			end
		end

		if bool2 then
			var37 = var3.z
			bool2 = false
			if var37 == var37 then
				bool2 = false
				if var37 ~= math.huge then
					bool2 = var37 ~= -math.huge
				end
			end
		end
	end

	if bool2 then
		arg1.moveVector = var3
	end
end

var13.OnUserCFrameEnabled = function(arg1)
	if arg1:ShouldUseNavigationLaser() then
		arg1:BindJumpAction(false)
		arg1:SetLaserPointerMode("Navigation")
		return
	end

	arg1:BindJumpAction(true)
	arg1:SetLaserPointerMode("Hidden")
end

var13.Enable = function(arg1, arg2)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		arg1.navigationRequestedConn = var2.NavigationRequested:Connect(function(arg1, arg2)
			arg1:OnNavigationRequest(arg1, arg2)
		end)

		arg1.heartbeatConn = var4.Heartbeat:Connect(function(arg1)
			arg1:OnHeartbeat(arg1)
		end)

		var6:BindAction("MoveThumbstick", function(arg1, arg2, arg3)
			local var1 = arg1
			local var2 = arg2
			local var3 = arg3
			return arg1:ControlCharacterGamepad(var1, var2, var3)
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)

		var6:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		arg1.userCFrameEnabledConn = var2.UserCFrameEnabled:Connect(function()
			arg1:OnUserCFrameEnabled()
		end)

		arg1:OnUserCFrameEnabled()
		var2:SetTouchpadMode(Enum.VRTouchpad.Left, Enum.VRTouchpadMode.VirtualThumbstick)
		var2:SetTouchpadMode(Enum.VRTouchpad.Right, Enum.VRTouchpadMode.ABXY)
		arg1.enabled = true
		return
	end

	arg1:StopFollowingPath()
	var6:UnbindAction("MoveThumbstick")
	var6:UnbindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	arg1:BindJumpAction(false)
	arg1:SetLaserPointerMode("Disabled")
	if arg1.navigationRequestedConn then
		arg1.navigationRequestedConn:Disconnect()
		arg1.navigationRequestedConn = nil
	end

	if arg1.heartbeatConn then
		arg1.heartbeatConn:Disconnect()
		arg1.heartbeatConn = nil
	end

	if arg1.userCFrameEnabledConn then
		arg1.userCFrameEnabledConn:Disconnect()
		arg1.userCFrameEnabledConn = nil
	end

	arg1.enabled = false
end

return var13

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
if require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls") then
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = Instance.new("BindableEvent")
	local bool2 = false
	local var10 = game:GetService("Players")
	local function fn3(arg1)
		var6 = nil
		var7 = nil
		if var8 then
			var8:Disconnect()
			var8 = nil
		end

		if arg1 then
			var6 = arg1:FindFirstChild("AbilityManagerActor")
			var7 = arg1:FindFirstChildOfClass("Humanoid")
			while not var7 do
				arg1.ChildAdded:wait()
				var7 = arg1:FindFirstChildOfClass("Humanoid")
			end

			var9:Fire()
			var8 = var7:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				var9:Fire()
			end)

		end
	end

	return {
		isEnabled = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			local bool3 = false
			if var6 ~= nil then
				bool3 = var7
				bool3 = bool3 and (not var7.EvaluateStateMachine)
			end

			return bool3
		end,
		GetEnabledChangedSignal = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			return var9.Event
		end,
	}

end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = {}
	return var1
end

tbl1.trackConnection = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = function()
		arg3:Disconnect()
	end
end

tbl1.trackBoundFunction = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = arg3
end

tbl1.disconnect = function(arg1, arg2)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
		arg1._connections[arg2] = nil
	end
end

tbl1.disconnectAll = function(arg1)
	for k1, v1 in pairs(arg1._connections) do
		v1()
	end

	arg1._connections = {}
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.ConnectionUtil)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.AppCommonLib).Signal
var2.describe("ConnectionUtil", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should track a connection", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		var4.new():trackConnection("Signal", var1:Connect(fn2))
		var1:fire("Testing")
		var5(str1).toBe("Testing")
	end)

	var3("should disconnect from signal", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		var2:disconnect("Signal")
		var1:fire("Testing")
		var5(str1).toBe("")
	end)

	var3("should disconnect from all", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		local str2 = ""
		fn2 = function(arg1)
			str2 = arg1
		end

		var2:trackConnection("Signal1", var6.new():Connect(fn2))
		local str3 = ""
		fn2 = function(arg1)
			str3 = arg1
		end

		var2:trackConnection("Signal2", var6.new():Connect(fn2))
		var2:disconnectAll()
		var1:fire("TestingPrimary")
		var1:fire("TestingSecondary")
		var1:fire("TestingTertiary")
		var5(str1).toBe("")
		var5(str2).toBe("")
		var5(str3).toBe("")
	end)

	var3("should call manual disconnect", function()
		local str1 = ""
		local var1 = var4.new()
		var1:trackBoundFunction("Manual", function()
			str1 = "Disconnected"
		end)

		var1:disconnect("Manual")
		var5(str1).toBe("Disconnected")
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = game:GetService("Players")
local tbl1 = { _connectionUtil = require(script.Parent:WaitForChild(str1)).new() }
tbl1._boundEvents = {}
tbl1.getLocalPlayer = function()
	return var1.LocalPlayer
end

tbl1.onLocalPlayer = function(arg1)
	local var3 = tbl1.getLocalPlayer()
	if var3 then
		arg1(var3)
	end

	local function fn2()
		local var1 = tbl1.getLocalPlayer()
		assert(var1)
		tbl1._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(var1)
	end

	tbl1._connectionUtil:trackConnection("LOCAL_PLAYER", var1:GetPropertyChangedSignal("LocalPlayer"):Connect(fn2))
	local var4 = arg1
	return tbl1._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(var4)
end

tbl1.getCharacter = function()
	local var2 = tbl1.getLocalPlayer()
	if not var2 then
		return nil
	end

	return var2.Character
end

tbl1.onCharacter = function(arg1)
	local function fn2(arg1)
		local var2 = tbl1.getCharacter()
		if var2 then
			arg1(var2)
		end

		local function fn2(arg1)
			assert(arg1)
			tbl1._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(arg1)
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_ADDED", arg1.CharacterAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_LOCAL_PLAYER", tbl1.onLocalPlayer(fn2))
	local var1 = arg1
	return tbl1._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(var1)
end

tbl1.getChild = function(arg1, arg2)
	local var2 = tbl1.getCharacter()
	if not var2 then
		return nil
	end

	local var4 = var2:FindFirstChild(arg1)
	if var4 and var4:IsA(arg2) then
		return var4
	end

	return nil
end

tbl1.onChild = function(arg1, arg2, arg3)
	local function fn2(arg1)
		local var2 = tbl1.getChild(arg1, arg2)
		if var2 then
			arg3(var2)
		end

		local function fn2(arg1)
			if arg1.Name == arg1 and arg1:IsA(arg2) then
				tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2):Fire(arg1)
			end
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", arg1.ChildAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_CHARACTER", tbl1.onCharacter(fn2))
	local var1 = arg3
	return tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2).Event:Connect(var1)
end

tbl1._getOrCreateBoundEvent = function(arg1)
	if not tbl1._boundEvents[arg1] then
		tbl1._boundEvents[arg1] = Instance.new("BindableEvent")
	end

	return tbl1._boundEvents[arg1]
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.CameraWrapper)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.TestUtils).DeferredLuaHelpers.waitForEvents
var2.describe("CameraWrapper", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should return updated camera", function()
		local var1 = var4.new()
		var1:Enable()
		local var2 = Instance.new("Camera")
		var2.Parent = game.Workspace
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).never.toBe(var2)
		game.Workspace.CurrentCamera = var2
		var6()
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).toBe(var2)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.FlagUtil [ModuleScript]
-- y u r i

return { getUserFlag = function(arg1)
	local success, result = pcall(function()
		local var1 = arg1
		return UserSettings():IsUserFeatureEnabled(var1)
	end)

	return success and result
end }

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper [ModuleScript]
-- y u r i

local var1 = require(script.Parent.ConnectionUtil)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	return (setmetatable({
		_camera = game.Workspace.CurrentCamera,
		_callbacks = {},
		_connectionUtil = var1.new(),
		_enabled = false,
	}, tbl1))
end

tbl1._connectCallbacks = function(arg1)
	arg1._camera = game.Workspace.CurrentCamera
	if not arg1._camera then
		return
	end

	for k1, v1 in arg1._callbacks, nil do
		local var1 = v1
		arg1._connectionUtil:trackConnection(k1, arg1._camera:GetPropertyChangedSignal(k1):Connect(var1))
		v1()
	end
end

tbl1.Enable = function(arg1)
	if arg1._enabled then
		return
	end

	arg1._enabled = true
	arg1._cameraChangedConnection = game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		arg1:_connectCallbacks()
	end)

	arg1:_connectCallbacks()
end

tbl1.Disable = function(arg1)
	if not arg1._enabled then
		return
	end

	arg1._enabled = false
	if arg1._cameraChangedConnection then
		arg1._cameraChangedConnection:Disconnect()
		arg1._cameraChangedConnection = nil
	end

	arg1._connectionUtil:disconnectAll()
end

tbl1.Connect = function(arg1, arg2, arg3)
	arg1._callbacks[arg2] = arg3
	if not arg1._camera then
		return
	end

	local var1 = arg3
	arg1._connectionUtil:trackConnection(arg2, arg1._camera:GetPropertyChangedSignal(arg2):Connect(var1))
end

tbl1.Disconnect = function(arg1, arg2)
	arg1._connectionUtil:disconnect(arg2)
	arg1._callbacks[arg2] = nil
end

tbl1.getCamera = function(arg1)
	return arg1._camera
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerScriptsLoader [LocalScript]
-- y u r i

local str1 = "PlayerModule"
require(script.Parent:WaitForChild(str1))

--- Players.LocalPlayer.PlayerGui.HUD.Buttons.Inventory.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.HUD.Buttons.Shop.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.HUD.Buttons.Trade.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.HUD.MusicFrames.Template.ImageLabel.LocalScript [LocalScript]
-- y u r i

local var1 = script.Parent
game:GetService("RunService").RenderStepped:Connect(function(arg1)
	var1.Rotation = (var1.Rotation + 100 * arg1) % 360
	if 360 <= var1.Rotation then
		var1.Rotation = 0
	end
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.PlayerHolder.PlayerFrame.PossibleButtons.EnabledOptions.Trade.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.PlayerHolder.PlayerFrame.PossibleButtons.EnabledOptions.Sent.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.PlayerHolder.PlayerFrame.PossibleButtons.EnabledOptions.History.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.PlayerHolder.PlayerFrame.PossibleButtons.Disabled.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.Taolakoibel.PlayerFrame.PossibleButtons.EnabledOptions.Trade.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.Taolakoibel.PlayerFrame.PossibleButtons.EnabledOptions.Sent.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.Taolakoibel.PlayerFrame.PossibleButtons.EnabledOptions.History.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.List.ScrollingFrame.Taolakoibel.PlayerFrame.PossibleButtons.Disabled.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.RequestsFrame.HistoryButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeRequests.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Summon.SummonFrame.Crates.List.Crates.Basic Crate.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Summon.SummonFrame.Buttons.Summon1Button.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Summon.SummonFrame.Buttons.Summon10Button.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Summon.SummonFrame.Index.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Summon.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.InventoryFrame.List.StrokeManager [LocalScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = script.Parent.ScrollingFrame
local var3 = var1.TouchEnabled and var2.ScrollBarThickness / 2 or var2.ScrollBarThickness
var2.ScrollBarThickness = var3

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.InventoryFrame.Buttons.UnequipAll.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.InventoryFrame.Buttons.SellUnits.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.InventoryFrame.Filters.Towers.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.InventoryFrame.Filters.Items.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Inventory.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.StrokeManager [LocalScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = script.Parent.ScrollingFrame
local var3 = var1.TouchEnabled and var2.ScrollBarThickness / 2 or var2.ScrollBarThickness
var2.ScrollBarThickness = var3

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Coins.List.Coins1.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Coins.List.Coins2.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Coins.List.Coins3.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Coins.List.Coins4.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Packs.Pack1.Jetpack Pack.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Packs.Pack2.Epic Pack.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.CoinsPotion.PurchaseBoosts.CoinBoost1.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.CoinsPotion.PurchaseBoosts.CoinBoost10.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.CoinsPotion.BoostInfo.UseBoost.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.LuckPotion.PurchaseBoosts.LuckBoost1.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.LuckPotion.PurchaseBoosts.LuckBoost10.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Potions.List.LuckPotion.BoostInfo.UseBoost.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Gamepasses.List.DoubleLuck.DoubleLuck.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Gamepasses.List.DoubleCoins.DoubleCoins.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.ShopFrame.List.ScrollingFrame.Codes.RedeemButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Shop.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.TradeFrame.TradeMenu.TradeProcessing.LoadingRing.LoadingRing.SpinScript [LocalScript]
-- y u r i

local var1 = script.Parent
game:GetService("RunService").RenderStepped:Connect(function(arg1)
	if var1.Parent.Parent.Visible ~= true then
		return
	end

	local var2 = var1
	local var3 = var2.Rotation + 720 * arg1
	var2.Rotation = var3
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.TradeFrame.TradeMenu.Arrows.LocalScript [LocalScript]
-- y u r i

local var1 = game:GetService("TweenService")
local var2 = script.Parent
while true do
	local var3 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
	local var4 = var1:Create(var2, var3, { Rotation = var2.Rotation + 720 })
	var4:Play()
	var4.Completed:Wait()
	if 3600 <= var2.Rotation then
		var2.Rotation = 0
	end

	task.wait(5)
end

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.TradeFrame.TradeActions.UIStroke.UIGradient.LocalScript [LocalScript]
-- y u r i

while true do
	local var1 = script.Parent
	local var2 = var1.Rotation + 1
	var1.Rotation = var2
	if 360 <= script.Parent.Rotation then
		script.Parent.Rotation = 0
	end

	task.wait(0.1)
end

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.TradeFrame.TradeActions.Decline.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.TradeFrame.TradeActions.Accept.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.InventoryFrame.List.StrokeManager [LocalScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = script.Parent.ScrollingFrame
local var3 = var1.TouchEnabled and var2.ScrollBarThickness / 2 or var2.ScrollBarThickness
var2.ScrollBarThickness = var3

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.InventoryFrame.Filters.Towers.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Trade.InventoryFrame.Filters.Items.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.UpdateLog.UpdateLogFrame.Controller.Buttons.FastBackward.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.UpdateLog.UpdateLogFrame.Controller.Buttons.Backward.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.UpdateLog.UpdateLogFrame.Controller.Buttons.Forward.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.UpdateLog.UpdateLogFrame.Controller.Buttons.FastForward.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.UpdateLog.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Settings.SettingsFrame.List.ScrollingFrame.Music.Holder.PossibleButtons.SwitchButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Settings.SettingsFrame.List.ScrollingFrame.Trades.Holder.PossibleButtons.SwitchButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Settings.SettingsFrame.List.ScrollingFrame.Sounds.Holder.PossibleButtons.SwitchButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Settings.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.Index.IndexFrame.List.StrokeManager [LocalScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = script.Parent.ScrollingFrame
local var3 = var1.TouchEnabled and var2.ScrollBarThickness / 2 or var2.ScrollBarThickness
var2.ScrollBarThickness = var3

--- Players.LocalPlayer.PlayerGui.Main.Main.Index.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeHistory.HistoryFrame.TradeMenu.Arrows.LocalScript [LocalScript]
-- y u r i

local var1 = game:GetService("TweenService")
local var2 = script.Parent
while true do
	local var3 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
	local var4 = var1:Create(var2, var3, { Rotation = var2.Rotation + 720 })
	var4:Play()
	var4.Completed:Wait()
	if 3600 <= var2.Rotation then
		var2.Rotation = 0
	end

	task.wait(5)
end

--- Players.LocalPlayer.PlayerGui.Main.Main.TradeHistory.Close.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.SummonedFrame.Pattern1.LocalScript [LocalScript]
-- y u r i

while true do
	local var1 = script.Parent
	local var2 = var1.Rotation + 1
	var1.Rotation = var2
	if 360 <= script.Parent.Rotation then
		script.Parent.Rotation = 0
	end

	task.wait(0.1)
end

--- Players.LocalPlayer.PlayerGui.Main.SummonedFrame.Close.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.NotificationFrame.BigNotification.Buttons.NoButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.NotificationFrame.BigNotification.Buttons.YesButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.NotificationFrame.BigNotification.Buttons.OkButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.TutorialUI.CloseButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Time.LocalScript [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = os.time({ year = 2026, month = 9, day = 24, hour = 16, min = 0, sec = 0 })
local function formatTime(arg1)
	if arg1 <= 0 then
		return var1:Destroy()
	end

	local var10 = math.floor(arg1 / 86400)
	local var11 = math.floor(arg1 % 86400 / 3600)
	local var12 = math.floor(arg1 % 3600 / 60)
	local var13 = arg1 % 60
	if 0 < var10 then
		local var14 = var13
		local str2 = "%d:%s:%s:%s"
		local var15 = var10
		local var16 = string.format("%02d", var11)
		local var17 = string.format("%02d", var12)
		return string.format(str2, var15, var16, var17, pad(var14))
	end

	if 0 < var11 then
		local var21 = var13
		local str4 = "%s:%s:%s"
		local var22 = string.format("%02d", var11)
		local var23 = string.format("%02d", var12)
		return string.format(str4, var22, var23, pad(var21))
	end

	if 0 < var12 then
		local var26 = var13
		local str6 = "%s:%s"
		local var27 = string.format("%02d", var12)
		return string.format(str6, var27, pad(var26))
	end

	local str7 = "%ds"
	local var28 = var13
	return string.format(str7, var28)
end

while true do
	local var3 = os.difftime(var2, os.time())
	var1.Text = formatTime(var3)
	if var3 <= 0 then
		break
	end

	task.wait(1)
end

--- Players.LocalPlayer.PlayerGui.Main.Time.MovementScript [Script]
-- y u r i

local num1 = 0
local var1 = script.Parent
game:GetService("RunService").RenderStepped:Connect(function(arg1)
	local var2 = num1 + arg1
	num1 = var2
	var1.Position = UDim2.new(0.21, 0, math.sin(num1 * 2) * 0.0195 + 0.0905, 0)
end)

--- Players.LocalPlayer.PlayerGui.Main.Time.FollowButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- Players.LocalPlayer.PlayerGui.Main.Time.FollowButton.LocalScript [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = game:GetService("SocialService")
local success, result = pcall(function()
	local str1 = "2797913782041576208"
	return var2:GetEventRsvpStatusAsync(str1)
end)

if not success then
	warn("Failed to get RSVP status:", result)
	return
end

if result == Enum.RsvpStatus.Going then
	var1.Visible = true
else
	var1.Visible = true
end

var1.Activated:Connect(function(_)
	if var2:PromptRsvpToEventAsync("2797913782041576208") == Enum.RsvpStatus.Going then
		var1.Visible = true
		return
	end

	var1.Visible = true
end)

--- Players.LocalPlayer.PlayerGui.ElevatorGui.QueueFrame.ReadyButton.LocalScript [LocalScript]
-- y u r i

local tbl1 = {}
local var1 = script.Parent
local var2 = game:GetService("TweenService")
if var1:IsA("GuiObject") then
	tbl1[var1] = { Background = var1.BackgroundColor3 }
end

for k1, v1 in ipairs(var1:GetDescendants()) do
	if not v1:IsA("GuiObject") then
		continue
	end

	tbl1[v1] = { Background = v1.BackgroundColor3 }
end

local function setDarkened(arg1)
	local var1 = TweenInfo.new(0.055, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for k1, v1 in pairs(tbl1) do
		local tbl2 = {}
		if v1.Background then
			local var4 = v1.Background
			local var5 = arg1 and Color3.new(var4.R * 0.85, var4.G * 0.85, var4.B * 0.85) or v1.Background
			tbl2.BackgroundColor3 = var5
		end

		var2:Create(k1, var1, tbl2):Play()
	end
end

var1.MouseEnter:Connect(function()
	setDarkened(true)
end)

var1.MouseLeave:Connect(function()
	setDarkened(false)
end)

--- ReplicatedStorage.ModuleLoader [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local num1 = 0
local var2 = var1:IsServer() and game:GetService("ServerScriptService"):WaitForChild("Server") or nil
local var3 = script:WaitForChild("Configs")
local var4 = script:WaitForChild("Client")
local var5 = script:WaitForChild("Shared")
local var6 = script:WaitForChild("Libs")
shared.Modules = {}
local function LoadModulesInFolder(arg1, arg2)
	for k1, v1 in arg1:GetChildren() do
		if not v1:IsA("ModuleScript") then
			continue
		end

		if shared.Modules[v1.Name] then
			warn((("[ModuleLoader] Duplicate module name '%*' from %* ignored"):format(v1.Name, (v1:GetFullName()))))
		elseif arg2 then
			local success, result = pcall(require, v1)
			local var2 = shared.Modules
			local var3 = v1.Name
			local var4
			if not success then
				warn((("[ModuleLoader] Failed to load %*: %*"):format(v1:GetFullName(), result)))
				var4 = nil
			elseif result ~= nil then
				local var5 = num1 + 1
				num1 = var5
			end

			var2[var3] = var4
		else
			task.spawn(function()
				local var1 = v1
				local success, result = pcall(require, var1)
				local var3 = shared.Modules
				local var4 = v1.Name
				local var5
				if not success then
					warn((("[ModuleLoader] Failed to load %*: %*"):format(var1:GetFullName(), result)))
					var5 = nil
				elseif result ~= nil then
					local var6 = num1 + 1
					num1 = var6
				end

				var3[var4] = var5
			end)

		end
	end
end

LoadModulesInFolder(var6, true)
LoadModulesInFolder(var5, true)
LoadModulesInFolder(var3, true)
local var7 = LoadModulesInFolder
var7(if var1:IsServer() then var2 else var4, false)
for k1, v1 in shared.Modules, nil do
	if typeof(v1) ~= "table" then
		continue
	end

	if typeof(v1.Init) == "function" then
		task.spawn(v1.Init)
	else
		if typeof(v1.Start) ~= "function" then
			continue
		end

		task.spawn(v1.Start)
	end
end

return true

--- ReplicatedStorage.ModuleLoader.Client.UI [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local num1 = 0
local var2 = shared.Modules.UIConfetti
local var3 = var1:WaitForChild("PlayerGui")
local tbl1 = {}
local var4 = game:GetService("SoundService")
local var5 = Color3.fromRGB(180, 180, 180)
local var6 = game:GetService("TweenService")
local var7 = game:GetService("RunService")
local var8 = nil
local var9 = shared.Modules.Replication
local tbl2 = {};
(function(arg1, arg2)
	for k1, v1 in arg1:GetChildren() do
		if not v1:IsA("ModuleScript") then
			continue
		end

		local var1 = v1.Name
		if arg2[var1] then
			warn((("[UI] Duplicate module name '%*' from %* ignored"):format(var1, (v1:GetFullName()))))
		else
			local success, result = pcall(require, v1)
			local var2
			if not success then
				var2 = nil
			else
				local var3 = num1 + 1
				num1 = var3
				var2 = result
			end

			if var2 == nil then
				continue
			end

			arg2[var1] = var2
		end
	end
end)(script, tbl2)

local var10 = shared.Modules.StrokeScaler
local var11 = shared.Modules.Network
local function UpdateStats()
	if var8 then
		var8:Disconnect()
		var8 = nil
	end

	local var4 = var9.GetCurrentReplica()
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Settings"):WaitForChild("SettingsFrame"):WaitForChild("Stats")
	if not var4 then
		return
	end

	var5.Coins.Text = ("Total Coins: %*"):format(var4.Data.TotalMoney)
	var5.Loses.Text = ("Loses: %*"):format(var4.Data.Loses)
	var5.Spent.Text = ("Total Spent\238\128\130: %*"):format(var4.Data.Spent)
	var5.SummonedCount.Text = ("Total Summons: %*"):format(var4.Data.TotalSummons)
	var5.Traded.Text = ("Total Trades: %*"):format(var4.Data.TradedEver)
	var5.Wins.Text = ("Wins: %*"):format(var4.Data.Wins)
	var5.Time.Text = ("Total Time: %*"):format(var1.Playtime.Value)
	var8 = var1.Playtime.Changed:Connect(function(arg1)
		var5.Time.Text = ("Total Time: %*"):format(arg1)
	end)
end

local function CallInitOnModules(arg1)
	for k1, v1 in pairs(arg1) do
		if type(v1) ~= "table" then
			continue
		end

		if type(v1.Init) == "function" then
			task.spawn(v1.Init)
		else
			if type(v1.Start) == "function" then
				task.spawn(v1.Start)
			end
		end

		CallInitOnModules(v1)
	end
end

local function launchConfettiBurst(arg1)
	local tbl2 = {}
	for i1 = 1, arg1 or 40 do
		local tbl3 = { Parent = var3:WaitForChild("Main") }
		tbl3.Position = UDim2.new(0.05, 0, 1, 10)
		local num1 = -38
		local num2 = -22
		tbl3.Force = Vector2.new(math.random(10, 28), math.random(num1, num2))
		tbl3.Gravity = Vector2.new(0, 0.75)
		local var1 = var2.new(tbl3)
		local tbl4 = { Parent = var3:WaitForChild("Main") }
		tbl4.Position = UDim2.new(0.95, 0, 1, 10)
		num2 = -38
		local num3 = -22
		tbl4.Force = Vector2.new(math.random(-28, -10), math.random(num2, num3))
		tbl4.Gravity = Vector2.new(0, 0.75)
		tbl3 = var2.new(tbl4)
		if var1 then
			var1:Toggle()
			table.insert(tbl1, var1)
			table.insert(tbl2, var1)
		end

		if not tbl3 then
			continue
		end

		tbl3:Toggle()
		table.insert(tbl1, tbl3)
		table.insert(tbl2, tbl3)
	end

	task.delay(1, function()
		for k1, v1 in tbl2, nil do
			if not v1.Toggle then
				continue
			end

			v1:Toggle()
		end

		task.wait(3)
		for k2, v2 in tbl2, nil do
			local var2 = table.find(tbl1, v2)
			if var2 then
				table.remove(tbl1, var2)
			end

			if not v2.Destroy then
				continue
			end

			v2:Destroy()
		end
	end)
end

local function setupEqualizer()
	local var8 = var4:WaitForChild("Background", 10)
	local var9 = var3:WaitForChild("HUD", 10)
	if not var8 or (not var9) then
		return
	end

	local var11 = var9:WaitForChild("MusicFrames", 10):WaitForChild("Template", 10)
	if not var11 then
		return
	end

	local var13 = var11:FindFirstChild("Bars", true)
	if not var13 then
		warn("[UI] Equalizer frame 'Bars' not found in Main Gui")
		return
	end

	if not var13:FindFirstChildOfClass("UIListLayout") then
		local var14 = Instance.new("UIListLayout")
		var14.FillDirection = Enum.FillDirection.Horizontal
		var14.HorizontalAlignment = Enum.HorizontalAlignment.Left
		var14.VerticalAlignment = Enum.VerticalAlignment.Bottom
		var14.SortOrder = Enum.SortOrder.LayoutOrder
		var14.Padding = UDim.new(0, 2)
		var14.Parent = var13
	end

	for i1 = 1, 50 do
		local var15 = Instance.new("Frame")
		var15.Name = "Bar_" .. i1
		var15.LayoutOrder = i1
		var15.BackgroundColor3 = var5
		var15.BorderSizePixel = 0
		var15.Size = UDim2.new(0, 5, 0.05, 0)
		var15.AnchorPoint = Vector2.new(0, 1)
		local var16 = Instance.new("UICorner")
		var16.CornerRadius = UDim.new(1, 0)
		var16.BottomLeftRadius = UDim.new(0, 0)
		var16.BottomRightRadius = UDim.new(0, 0)
		var16.Parent = var15
		var15.Parent = var13
	end

	local var17 = var13:GetChildren()
	local var18 = UDim2.new(1.1, 0, 0.07, 0)
	var11.Position = var18
	local var19 = UDim2.new(0.778, 0, 0.07, 0)
	var11.Visible = false
	task.wait(3)
	var11.Visible = true
	local var20 = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	var6:Create(var11, var20, { Position = var19 }):Play()
	local var21 = nil
	task.wait(8)
	var21 = var7.RenderStepped:Connect(function()
		local var1 = math.clamp(var8.PlaybackLoudness / 500, 0.05, 1)
		for k1, v1 in ipairs(var17) do
			if not v1:IsA("Frame") then
				continue
			end

			local var2 = v1.Size:Lerp(UDim2.new(v1.Size.X.Scale, v1.Size.X.Offset, math.clamp(var1 * (0.6 + math.noise(tick() * 5, k1 * 0.3, 0) * 0.4), 0.05, 1), 0), 0.3)
			v1.Size = var2
		end
	end)

	local var22 = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	local var23 = var6:Create(var11, var22, { Position = var18 })
	var23:Play()
	var23.Completed:Connect(function()
		if var21 then
			var21:Disconnect()
			var21 = nil
		end

		var11.Visible = false
	end)
end

local var12 = game:GetService("UserInputService")
local var13 = var1:GetMouse()
local var14 = game:GetService("ReplicatedStorage")
local tbl3 = { Start = function()
	while not var9 or (not var2) or (not var10) or (not var11) do
		task.wait()
		var9 = shared.Modules.Replication
		var10 = shared.Modules.StrokeScaler
		var2 = shared.Modules.UIConfetti
		var11 = shared.Modules.Network
	end

	repeat
		task.wait()
		if var11 then
			if var11.Get("UpdateLeaderstats") then
				break
			end
		end
	until var11.Get("UpdateLeaderstats")

	local var1 = var9.GetCurrentReplica()
	var1:OnSet({ "Money" }, function()
		var11.Get("UpdateLeaderstats"):FireServer()
		UpdateStats()
	end)

	var1:OnSet({ "Wins" }, function()
		var11.Get("UpdateLeaderstats"):FireServer()
		UpdateStats()
	end)

	var1:OnSet({ "TotalMoney" }, function()
		UpdateStats()
	end)

	var1:OnSet({ "Loses" }, function()
		UpdateStats()
	end)

	var1:OnSet({ "TotalSummons" }, function()
		UpdateStats()
	end)

	var1:OnSet({ "Spent" }, function()
		UpdateStats()
	end)

	var1:OnSet({ "TradedEver" }, function()
		UpdateStats()
	end)

	UpdateStats()
	CallInitOnModules(tbl2)
	var10.TagScreenGui(var3)
	var11.Get("ConfettiUI").OnClientEvent:Connect(launchConfettiBurst)
	task.spawn(setupEqualizer)
	var12.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
			local var1 = var13.Y + game:GetService("GuiService"):GetGuiInset().Y
			local var2 = var14:WaitForChild("Assets"):WaitForChild("CircleTemplate"):Clone()
			var2.Parent = var3:WaitForChild("Main"):WaitForChild("TrashFrames")
			var2.Visible = true
			var2.Position = UDim2.new(0, var13.X, 0, var1)
			var2.Size = UDim2.new(0, 0, 0, 0)
			var2.BackgroundTransparency = 0.45
			local var4 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			var6:Create(var2, var4, { Size = UDim2.new(0.038, 0, 0.075, 0), BackgroundTransparency = 1 }):Play()
			task.wait(0.25)
			var2:Destroy()
		end
	end)

	var7.RenderStepped:Connect(function()
		for k1, v1 in tbl1, nil do
			v1:Update()
		end
	end)
end }

for k1, v2 in tbl2, nil do
	if k1 == "Start" then
		continue
	end

	tbl3[k1] = v2
end

print([[
 ██████╗ █████╗ ███╗   ███╗███████╗██████╗  █████╗ ███╗   ███╗█████╗ ███╗   ██╗
██╔════╝██╔══██╗████╗ ████║██╔════╝██╔══██╗██╔══██╗████╗ ████║██╔══██╗████╗  ██║
██║     ███████║██╔████╔██║█████╗  ██████╔╝███████║██╔████╔██║███████║██╔██╗ ██║
██║     ██╔══██║██║╚██╔╝██║██╔══╝  ██╔══██╗██╔══██║██║╚██╔╝██║██╔══██║██║╚██╗██║
╚██████╗██║  ██║██║ ╚═╝ ██║███████╗██║  ██║██║  ██║██║ ╚═╝ ██║██║  ██║██║ ╚████║
 ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝

  ████████╗ ██████╗ ██╗  ██╗   ██╗  ███████╗██████╗ 
  ╚══██╔══╝██╔═══██╗██║  ██║   ██║  ██╔════╝██╔══██╗
     ██║   ██║   ██║██║  ██║█╗ ██║  █████╗  ██████╔╝
     ██║   ██║   ██║██║  █████╗██║  ██╔══╝  ██╔══██╗
     ██║   ╚██████╔╝╚██████╔████╔╝  ███████╗██║  ██║
     ╚═╝    ╚═════╝  ╚═════╝╚═══╝   ╚══════╝╚═╝  ╚═╝

  ██████╗ ███████╗███████╗███████╗███╗   ██╗███████╗███████╗
  ██╔══██╗██╔════╝██╔════╝██╔════╝████╗  ██║██╔════╝██╔════╝
  ██║  ██║█████╗  █████╗  █████╗  ██╔██╗ ██║███████╗█████╗  
  ██║  ██║██╔══╝  ██╔══╝  ██╔══╝  ██║╚██╗██║╚════██║██╔══╝  
  ██████╔╝███████╗██║     ███████╗██║ ╚████║███████║███████╗
  ╚═════╝ ╚══════╝╚═╝     ╚══════╝╚═╝  ╚═══╝╚══════╝╚══════╝

]])

return tbl3

--- ReplicatedStorage.ModuleLoader.Client.UI.HUD [ModuleScript]
-- y u r i

game:GetService("Lighting")
local var1 = shared.Modules.Replication
local var2 = shared.Modules.TweenButtons
local var3 = shared.Modules.InfoFrame
local var4 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var5 = shared.Modules.Config
local var6 = game:GetService("SoundService")
local var7 = game:GetService("TweenService")
local var8 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
return { Start = function()
	while not var1 do
		task.wait()
		var1 = shared.Modules.Replication
	end

	while not var2 do
		task.wait()
		var2 = shared.Modules.TweenButtons
	end

	while not var3 do
		task.wait()
		var3 = shared.Modules.InfoFrame
	end

	local var10 = var4:WaitForChild("HUD")
	if not var10 then
		warn("[HUD] HUD not found in PlayerGui")
		return
	end

	local var12 = var1.GetCurrentReplica()
	if not var12 then
		return
	end

	local var16 = var10:WaitForChild("Slots")
	local var17 = var10:WaitForChild("Currencies")
	local var18 = var10:WaitForChild("Buttons")
	local var19 = var4:WaitForChild("Main"):WaitForChild("Boosts")
	if not var16 or (not var17 or (not var18)) then
		warn("[HUD] Missing required folders")
		return
	end

	local var21 = var16:WaitForChild("Template")
	if not var21 then
		warn("[HUD] Missing Example instances")
		return
	end

	var21.Visible = false
	for i1 = 1, var5.GameSettings.HotbarSlots do
		local var22 = var21:Clone()
		var22.Name = "Slot" .. i1
		var22.TroopFrame.Keybind.Text = i1
		var22.LayoutOrder = i1
		var22.Parent = var16
		var22.Visible = true
		var22.MouseEnter:Connect(function()
			var2.Tween(var22.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Scale", 1.025, false)
			var6:WaitForChild("HoverSFX"):Play()
		end)

		var22.MouseLeave:Connect(function()
			var2.Tween(var22.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Scale", 1, false)
		end)

	end

	for k1, v1 in var18:GetChildren() do
		if not v1:IsA("TextButton") then
			continue
		end

		v1.MouseEnter:Connect(function()
			var2.Tween(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.In), "Scale", 1.05, false)
			var6:WaitForChild("HoverSFX"):Play()
		end)

		v1.MouseLeave:Connect(function()
			var2.Tween(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Scale", 1, false)
		end)

		v1.MouseButton1Up:Connect(function()
			var2.Tween(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), "Scale", 1.05, false)
		end)

		v1.MouseButton1Down:Connect(function()
			var2.Tween(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), "Scale", 0.95, false)
		end)

	end

	local tbl1 = {}
	local function FormatWithCommas(arg1)
		local var1 = tostring((math.floor(arg1)))
		local var2 = nil
		repeat
			local var3, var4 = string.gsub(var1, "^(-?%d+)(%d%d%d)", "%1,%2")
			var1 = var3
		until var4 == 0

		return var1
	end

	local function UpdateCurrency(arg1)
		local var3 = var17:FindFirstChild(arg1)
		local var4 = var1.GetCurrentReplica().Data[arg1] or 0
		if not var3 then
			return
		end

		local var6 = var3.CurrencyFrame.AmountLabel
		if not var6 then
			return
		end

		if tbl1[arg1] then
			tbl1[arg1]:Cancel()
		end

		local str1 = "[%d%.]+"
		local var8 = Instance.new("NumberValue")
		var8.Value = tonumber(var6.Text:match(str1)) or var4
		local var9 = nil
		var9 = var8:GetPropertyChangedSignal("Value"):Connect(function()
			if var6 then
				var6.Text = FormatWithCommas(var8.Value)
			end
		end)

		local var10 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local var11 = var7:Create(var8, var10, { Value = var4 })
		tbl1[arg1] = var11
		var11.Completed:Connect(function()
			var9:Disconnect()
			var8:Destroy()
			if tbl1[arg1] == var11 then
				tbl1[arg1] = nil
			end
		end)

		var11:Play()
	end

	var1.GetCurrentReplica():OnSet({ "Money" }, function()
		UpdateCurrency("Money")
	end)

	UpdateCurrency("Money")
	local tbl2 = {}
	local function UpdateSlots()
		for k1, v1 in tbl2, nil do
			v1:Disconnect()
		end

		table.clear(tbl2)
		for i1 = 1, var5.GameSettings.HotbarSlots do
			local var1 = "Slot" .. i1
			local var2 = var16:FindFirstChild(var1)
			if not var2 then
				continue
			end

			var2.TroopFrame.TroopIcon.Image = ""
			var2.TroopFrame.Price.Text = ""
			var1 = false
			var2.TroopFrame.Price.Visible = var1
		end

		local var9 = var12.Data.Towers
		if not var9 then
			return
		end

		for k2, v2 in var9, nil do
			local var10 = v2.Equipped
			if type(var10) ~= "number" or 1 > var10 then
				continue
			end

			if var10 > var5.GameSettings.HotbarSlots then
				continue
			end

			local var11 = var16:FindFirstChild("Slot" .. var10)
			if not var11 then
				continue
			end

			local var13 = var5.Towers[v2.Name]
			if not var13 then
				continue
			end

			var11.TroopFrame.TroopIcon.Image = var13.Icon or ""
			local var14 = var13.Upgrades[1].Price and ("$%*"):format(var13.Upgrades[1].Price) or ""
			var11.TroopFrame.Price.Text = var14
			var11.TroopFrame.Price.Visible = true
			local function fn2()
				local var2 = var8:FindFirstChild(var13.Rarity)
				if var2 then
					local var4 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
					var7:Create(var11.TroopFrame.Background.UIShadow, var4, { Transparency = 0.45, Color = var2.Color.Keypoints[1].Value }):Play()
				else
					local var5 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
					var7:Create(var11.TroopFrame.Background.UIShadow, var5, { Transparency = 0.45, Color = Color3.fromRGB(0, 0, 0) }):Play()
				end

				var3:MoveInfoUI(v2)
				var6:WaitForChild("HoverSFX"):Play()
			end

			table.insert(tbl2, var11.MouseEnter:Connect(fn2))
			fn2 = function()
				var3:MoveInfoUI(v2)
			end

			table.insert(tbl2, var11.MouseMoved:Connect(fn2))
			fn2 = function()
				var3:HideInfoUI()
				local var1 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
				var7:Create(var11.TroopFrame.Background.UIShadow, var1, { Transparency = 0.6, Color = Color3.fromRGB(0, 0, 0) }):Play()
			end

			table.insert(tbl2, var11.MouseLeave:Connect(fn2))
		end
	end

	var12:OnSet({ "Towers" }, UpdateSlots)
	UpdateSlots()
	local function UpdateGamepasses()
		local var2 = var12.Data.ActivatedGamepasses
		if not var2 then
			return
		end

		for k1, v1 in var19:GetChildren() do
			if not v1:IsA("GuiObject") then
				continue
			end

			if v1.Name == "UIGridLayout" then
				continue
			end

			local var4 = var2[v1.Name] == true
			if v1.Name == "PremiumPass" then
				var4 = false
			end

			v1.Visible = var4
		end
	end

	var12:OnSet({ "ActivatedGamepasses" }, UpdateGamepasses)
	UpdateGamepasses()
	local var24 = var18:FindFirstChild("Shop")
	if var24 then
		var24.Activated:Connect(function()
			var2.OnButtonClick("Shop")
		end)

	end

	local var26 = var18:FindFirstChild("Inventory")
	if var26 then
		var26.Activated:Connect(function()
			var2.OnButtonClick("Inventory")
		end)

	end

	local var28 = var18:FindFirstChild("Trade")
	if var28 then
		var28.Activated:Connect(function()
			var2.OnButtonClick("TradeRequests")
		end)

	end

	for k2, v2 in var4:WaitForChild("Main"):WaitForChild("Main"):GetChildren() do
		if not v2:FindFirstChild("CloseButton") then
			continue
		end

		v2.CloseButton.Activated:Connect(function()
			var2.OnButtonClick(v2.Name)
		end)

	end

	var4:WaitForChild("Main"):WaitForChild("Hider").Activated:Connect(function()
		if var4:WaitForChild("Main"):WaitForChild("Main"):FindFirstChild("Trade").Visible then
			return
		end

		if var4:WaitForChild("Main"):FindFirstChild("SummonedFrame").Visible then
			return
		end

		var2.OnButtonClick()
	end)

	local function connectButton(arg1)
		if (arg1:IsA("TextButton") or arg1:IsA("ImageButton")) and (not arg1:GetAttribute("ClickConnected")) then
			arg1.Activated:Connect(function()
				if var6:FindFirstChild("ClickSound") then
					var6.ClickSound:Play()
				end
			end)

			arg1:SetAttribute("ClickConnected", true)
		end
	end

	for k3, v3 in ipairs(var4:GetDescendants()) do
		connectButton(v3)
	end

	var4.DescendantAdded:Connect(connectButton)
end }

--- ReplicatedStorage.ModuleLoader.Client.UI.Inventory [ModuleScript]
-- y u r i

game:GetService("RunService")
local var1 = shared.Modules.Replication
local var2 = shared.Modules.InfoFrame
local var3 = shared.Modules.BigNotify
local var4 = shared.Modules.TweenButtons
local tbl1 = {}
local tbl2 = {}
local bool1 = false
local var5 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var6 = shared.Modules.Network
local bool2 = false
local tbl3 = {}
local var7 = shared.Modules.Config
local str1 = "Towers"
local var8 = game:GetService("TweenService")
local var9 = game:GetService("UserInputService")
local var10 = game:GetService("GamepadService")
local var11 = game:GetService("SoundService")
local var12 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
tbl2.Start = function()
	while not var1 or (not var2) or (not var3) or (not var4) do
		task.wait()
		var1 = shared.Modules.Replication
		var3 = shared.Modules.BigNotify
		var2 = shared.Modules.InfoFrame
		var4 = shared.Modules.TweenButtons
	end

	local var11 = var1.GetCurrentReplica()
	if var11.Data and var11.Data.Items then
		for k1 in pairs(var11.Data.Items) do
			tbl1[k1] = true
		end
	end

	tbl2.Update()
	var11:OnSet({ "Towers" }, tbl2.Update)
	var11:OnSet({ "Items" }, function()
		local var1 = var11.Data.Items
		for k1 in pairs(var1 or {}) do
			if tbl1[k1] then
				continue
			end

			bool1 = true
			break
		end

		tbl2.Update()
	end)

	local var12 = var5:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Inventory")
	var12:WaitForChild("InventoryFrame"):WaitForChild("Buttons"):WaitForChild("UnequipAll").Activated:Connect(function()
		var6.Get("EquipPart"):FireServer("UnequipAll")
	end)

	local var13 = var12:WaitForChild("InventoryFrame"):WaitForChild("Buttons"):WaitForChild("SellUnits")
	var13.Activated:Connect(function()
		if not bool2 then
			bool2 = true
			var13.UIStroke.Color = Color3.fromRGB(29, 97, 0)
			var13.UIShadow.Color = Color3.fromRGB(61, 200, 1)
			var13.UI1.Visible = false
			var13.UI2.Visible = true
			if 0 < (#tbl3) then
				var13.TextLabel.Text = "Submit"
			else
				var13.TextLabel.Text = "Cancel"
			end
		else
			if 0 < (#tbl3) then
				local var4 = var11.Data.Towers
				local num1 = 0
				if var4 then
					for k1, v1 in tbl3, nil do
						local var5 = var4[v1]
						if not var5 then
							continue
						end

						local var8 = var7.Towers
						var8 = var8 and var7.Towers[var5.Name]
						if not var8 then
							continue
						end

						num1 = num1 + (var7.GameSettings.SellValues[var8.Rarity] or 0)
					end
				end

				if var3.Show(("Are you sure you want to sell %* units for %* coins? This action cannot be reversed!"):format(#tbl3, num1), "YesNo") == "YesButton" then
					var6.Get("SellPart"):FireServer(tbl3)
					tbl3 = {}
					tbl2.Update()
					bool2 = false
					var13.UIStroke.Color = Color3.fromRGB(98, 87, 0)
					var13.UIShadow.Color = Color3.fromRGB(172, 161, 0)
					var13.UI1.Visible = true
					var13.UI2.Visible = false
					var13.TextLabel.Text = "Sell Units"
				end
			else
				bool2 = false
				var13.UIStroke.Color = Color3.fromRGB(98, 87, 0)
				var13.UIShadow.Color = Color3.fromRGB(172, 161, 0)
				var13.UI1.Visible = true
				var13.UI2.Visible = false
				var13.TextLabel.Text = "Sell Units"
			end
		end

		var2:HideInfoUI()
	end)

	local var14 = var12:WaitForChild("InventoryFrame"):WaitForChild("Buttons"):WaitForChild("UnequipAll")
	for k2, v1 in var12.InventoryFrame.Filters:GetChildren() do
		if not v1:IsA("TextButton") then
			continue
		end

		v1.Activated:Connect(function()
			if str1 == v1.Name then
				return
			end

			str1 = v1.Name
			if str1 == "Items" then
				bool1 = false
			end

			for k1, v2 in var12.InventoryFrame.Filters:GetChildren() do
				if not v2:IsA("TextButton") then
					continue
				end

				if v2.Name == str1 then
					continue
				end

				var8:Create(v2.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), { Scale = 1 }):Play()
			end

			var14.Visible = str1 == "Towers"
			var13.Visible = str1 == "Towers"
			tbl2.Update()
			var8:Create(v1.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), { Scale = 1.15 }):Play()
		end)

	end

	var12:GetPropertyChangedSignal("Visible"):Connect(function()
		if var12.Visible then
			if not var9.GamepadEnabled then
				return
			end

			var10:EnableGamepadCursor(var12)
			return
		end

		var2:HideInfoUI()
		var10:DisableGamepadCursor()
	end)

	local var15 = var12:WaitForChild("InventoryFrame").TopButtons.SearchBar.SearchBarBox
	var15:GetPropertyChangedSignal("Text"):Connect(function()
		local var1 = var15.Text:lower()
		for k1, v1 in ipairs(var12:WaitForChild("InventoryFrame").List.ScrollingFrame:GetChildren()) do
			if not v1:IsA("Frame") then
				continue
			end

			if v1.Name == "TroopFrame" then
				continue
			end

			if var1 == "" or string.find((v1:GetAttribute("SearchName") or ""):lower(), var1, 1, true) then
				v1.Visible = true
			else
				v1.Visible = false
			end
		end
	end)
end

local tbl4 = {}
tbl2.Update = function()
	if tbl2.EquipConn then
		tbl2.EquipConn:Disconnect()
		tbl2.EquipConn = nil
	end

	local var9 = var1.GetCurrentReplica().Data.Towers
	if not var9 then
		return
	end

	local var13 = var1.GetCurrentReplica().Data.Items
	if not var13 then
		return
	end

	local tbl5 = {}
	for k1 in pairs(var13) do
		tbl5[k1] = true
	end

	tbl1 = tbl5
	local var14 = var5:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Inventory"):WaitForChild("InventoryFrame")
	local var15 = var14:WaitForChild("List"):WaitForChild("ScrollingFrame"):WaitForChild("TroopFrame")
	local var16 = var14:WaitForChild("Buttons"):WaitForChild("SellUnits")
	var15.Visible = false
	local num1 = 0
	local tbl6 = {}
	local tbl7 = {}
	if str1 == "Towers" then
		for k2, v1 in var9, nil do
			local var17 = var7.Towers[v1.Name]
			if not var17 then
				continue
			end

			table.insert(tbl7, {
				UUID = k2,
				Data = v1,
				Config = var17,
				RarityValue = var7.GameSettings.RarityOrder[var17.Rarity] or 0,
				Name = v1.Name,
				Type = "Tower",
			})

			num1 = num1 + 1
		end
	else
		for k3, v2 in var13, nil do
			local var18 = var7.Ids
			var18 = var18 and var7.Ids.Products[v2.Name]
			if not var18 then
				continue
			end

			table.insert(tbl7, {
				UUID = k3,
				Data = v2,
				Config = var18,
				RarityValue = var7.GameSettings.RarityOrder[var18.Rarity] or 0,
				Name = v2.Name,
				Type = v2.Type or "Item",
				Title = var18.PassName,
			})

			num1 = num1 + 1
		end
	end

	table.sort(tbl7, function(arg1, arg2)
		local var3 = arg1.RarityValue * 100
		local var4 = arg2.RarityValue * 100
		if var3 ~= var4 then
			return var4 < var3
		end

		return arg1.Name < arg2.Name
	end)

	if str1 == "Items" then
		bool1 = false
	end

	local var19 = var14:WaitForChild("Filters"):WaitForChild("Items"):WaitForChild("Important")
	var19.Visible = bool1
	var19 = var14:WaitForChild("List"):WaitForChild("NoItemsFound")
	var19.Visible = #tbl7 == 0
	local var20 = num1
	local var21 = var1.GetCurrentReplica().Data.InventorySpace
	var19 = var14:WaitForChild("TopButtons"):WaitForChild("UnitLimit"):WaitForChild("UnitAmount")
	var19.Text = ("%*/%*"):format(var20, var21)
	for k4, v3 in tbl7, nil do
		local var22 = v3.Config
		local var23 = v3.UUID
		tbl6[var23] = true
		local var24 = v3.Data
		tbl4[var23] = { Data = var24, Type = v3.Type }
		local var25 = var14.List.ScrollingFrame:FindFirstChild(var23)
		local var26 = var25
		var26 = var26 or var15:Clone()
		var26.Visible = true
		var26.Name = var23
		var26.Parent = var14.List.ScrollingFrame
		local var27 = var22.Rarity
		local var28 = var25 == nil
		var26.LayoutOrder = if v3.Name == var7.GameSettings.StarterTower then 99999999 else k4
		var26:SetAttribute("SearchName", var24.Name)
		local var29 = var26.TroopsFrame
		var29.TroopIcon.Image = var22.Icon
		local var30 = var22 and (var22.Upgrades and (var22.Upgrades[1] and (var22.Upgrades[1].Price and ("$%*"):format(var22.Upgrades[1].Price)))) or ""
		var29.Price.Text = var30
		if v3.Type ~= "Tower" then
			var29.Price.Text = v3.Title or ""
		end

		local var32 = var29.Background:FindFirstChildWhichIsA("UIGradient")
		if var32 and var32.Name ~= "UIGradient" then
			var32:Destroy()
		end

		if var12:FindFirstChild(var27) then
			var30 = var12:FindFirstChild(var27):Clone()
			var30.Parent = var29.Background
		end

		var30 = table.find(tbl3, var23) ~= nil
		var29.Equipped.Visible = var24.Equipped
		var29.BulkSellIcon.Visible = var30
		if not var28 then
			continue
		end

		var29.InteractiveButton.MouseEnter:Connect(function()
			local var3 = tbl4[var23]
			if var3 and var3.Type == "Tower" then
				var2:MoveInfoUI(var3.Data)
			end

			var4.Tween(var29.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), "Scale", 1.05, false)
			var11:WaitForChild("HoverSFX"):Play()
		end)

		var29.InteractiveButton.MouseMoved:Connect(function()
			local var3 = tbl4[var23]
			if var3 and var3.Type == "Tower" then
				var2:MoveInfoUI(var3.Data)
			end
		end)

		var29.InteractiveButton.MouseLeave:Connect(function()
			var2:HideInfoUI()
			var4.Tween(var29.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Scale", 1, false)
		end)

		var29.InteractiveButton.Activated:Connect(function()
			local var2 = tbl4[var23]
			if bool2 then
				if var2 and var2.Type ~= "Tower" then
					return
				end

				if var2 and var2.Data.Name == var7.GameSettings.StarterTower then
					var3.Show("You cannot to sell starter unit")
					return
				end

				local var5 = table.find(tbl3, var23)
				if var5 then
					table.remove(tbl3, var5)
				else
					table.insert(tbl3, var23)
				end

				if 0 < (#tbl3) then
					var16.TextLabel.Text = "Submit"
				else
					var16.TextLabel.Text = "Cancel"
				end

				tbl2.Update()
				return
			end

			if var2 and var2.Type == "Tower" then
				var6.Get("EquipPart"):FireServer(var23)
				return
			end

			if var3.Show("Are you sure you want to open this item?", "YesNo") == "YesButton" then
				var6.Get("OpenGamepass"):InvokeServer(var22.Id, var23)
			end
		end)

	end

	for k5, v4 in var14.List.ScrollingFrame:GetChildren() do
		if not v4:IsA("Frame") then
			continue
		end

		if v4.Name == "TroopFrame" then
			continue
		end

		if tbl6[v4.Name] then
			continue
		end

		v4:Destroy()
	end
end

return tbl2

--- ReplicatedStorage.ModuleLoader.Client.UI.Shop [ModuleScript]
-- y u r i

game:GetService("RunService")
local var1 = game:GetService("Players")
local var2 = var1.LocalPlayer
local var3 = var2:WaitForChild("PlayerGui")
local var4 = nil
local var5 = game:GetService("PolicyService")
local var6 = game:GetService("MarketplaceService")
local var7 = shared.Modules.Network
local var8 = shared.Modules.Replication
local var9 = shared.Modules.InfoFrame
local tbl1 = {}
local var10 = game:GetService("UserInputService")
local var11 = game:GetService("GamepadService")
local var12 = shared.Modules.Config
local var13 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
tbl1.Start = function()
	while not var8 do
		task.wait()
		var8 = shared.Modules.Replication
	end

	while not var9 do
		task.wait()
		var9 = shared.Modules.InfoFrame
	end

	local var13 = var8.GetCurrentReplica()
	var13:OnSet({ "Boosts" }, tbl1.LoadBoosts)
	var13:OnSet({ "StoredBoosts" }, tbl1.LoadBoosts)
	tbl1.LoadBoosts()
	var1.PlayerAdded:Connect(function()
		task.wait(1)
		tbl1.UpdateFriendBoost()
	end)

	var1.PlayerRemoving:Connect(function()
		task.wait(0.5)
		tbl1.UpdateFriendBoost()
	end)

	task.spawn(tbl1.UpdateFriendBoost)
	local var14 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Shop"):WaitForChild("ShopFrame")
	local var15 = var14:WaitForChild("List"):WaitForChild("ScrollingFrame")
	local var16 = var15:WaitForChild("Potions"):WaitForChild("List")
	var16.CoinsPotion.BoostInfo.UseBoost.Activated:Connect(function()
		var7.Get("UseBoost"):FireServer("Coins")
	end)

	var16.LuckPotion.BoostInfo.UseBoost.Activated:Connect(function()
		var7.Get("UseBoost"):FireServer("Lucky")
	end)

	var14:GetPropertyChangedSignal("Visible"):Connect(function()
		if var14.Visible then
			if not var10.GamepadEnabled then
				return
			end

			var11:EnableGamepadCursor(var14)
			return
		end

		var11:DisableGamepadCursor()
	end)

	for k1, v1 in var15:GetDescendants() do
		if v1 then
			if v1:IsA("TextButton") then
				if v1.Name == "Jetpack Cameraman" then
					v1.MouseEnter:Connect(function()
						var9:MoveInfoUI({ Name = "Jetpack Cameraman" })
					end)

					v1.MouseMoved:Connect(function()
						var9:MoveInfoUI({ Name = "Jetpack Cameraman" })
					end)

					v1.MouseLeave:Connect(function()
						var9:HideInfoUI()
					end)

				end

				if v1.Name == "Large Cameraman" then
					v1.MouseEnter:Connect(function()
						var9:MoveInfoUI({ Name = "Large Cameraman" })
					end)

					v1.MouseMoved:Connect(function()
						var9:MoveInfoUI({ Name = "Large Cameraman" })
					end)

					v1.MouseLeave:Connect(function()
						var9:HideInfoUI()
					end)

				end

				local var17 = var12.Ids.Products[v1.Name]
				if not var17 then
					continue
				end

				v1.Activated:Connect(function()
					if not var4 then
						var4 = var5:GetPolicyInfoForPlayerAsync(var2)
					end

					if var4.ArePaidRandomItemsRestricted then
						return
					end

					var6:PromptProductPurchase(var2, var17.Id)
				end)

			end
		end

		if not v1 then
			continue
		end

		if not v1:IsA("Frame") then
			continue
		end

		local var18 = v1:FindFirstChild("RedeemButton")
		if not var18 then
			continue
		end

		var18.Activated:Connect(function()
			var7.Get("RedeemCode"):FireServer(v1:WaitForChild("CodesInput"):WaitForChild("InputMessage").Text)
			local var1 = v1:WaitForChild("CodesInput"):WaitForChild("InputMessage")
			var1.Text = ""
		end)

	end
end

local function GetFriendsInServerCount()
	local num1 = 0
	for k1, v1 in var1:GetPlayers() do
		if v1 == var2 then
			continue
		end

		local success, result = pcall(function()
			local var1 = v1.UserId
			return var2:IsFriendsWithAsync(var1)
		end)

		if not success or (not result) then
			continue
		end

		num1 = num1 + 1
	end

	return num1
end

tbl1.UpdateFriendBoost = function()
	local var2 = var3:WaitForChild("Main"):WaitForChild("Boosts"):FindFirstChild("FriendBoost")
	if not var2 then
		return
	end

	local var5 = GetFriendsInServerCount()
	if 0 < var5 then
		local var7 = var2:FindFirstChild("BoostAmount")
		local var8 = var5 * 0.1 + 1
		if var7 then
			var7.Text = string.format("%.1fx", var8)
		end

		var2.Visible = true
		return
	end

	var2.Visible = false
end

local function FormatTime(arg1)
	if arg1 <= 0 then
		return "00:00:00"
	end

	local var1 = arg1 % 3600
	return string.format("%02d", (math.floor(arg1 / 3600))) .. ":" .. string.format("%02d", (math.floor(var1 / 60))) .. ":" .. string.format("%02d", var1 % 60)
end

tbl1.UpdateBoostTimers = function()
	if not var8 then
		return
	end

	local var2 = var8.GetCurrentReplica()
	if not var2 then
		return
	end

	local var4 = var3:WaitForChild("Main"):WaitForChild("Boosts")
	local var5 = var4:FindFirstChild("FriendBoost")
	local var6 = os.time()
	local tbl2 = {}
	for k1, v1 in var2.Data.Boosts, nil do
		local var7 = math.max(0, v1.ExpireTime - var6)
		if 0 >= var7 then
			continue
		end

		if not var4:FindFirstChild(v1.Name) then
			continue
		end

		var4[v1.Name].Visible = true
		var4[v1.Name].BoostAmount.Text = FormatTime(var7)
		table.insert(tbl2, v1.Name)
	end

	tbl1.UpdateFriendBoost()
	if var5 and var5.Visible then
		table.insert(tbl2, "FriendBoost")
	end

	for k2, v2 in var4:GetChildren() do
		if not v2:IsA("GuiObject") then
			continue
		end

		if v2.Name == "FriendBoost" then
			continue
		end

		if v2.Name == "DoubleCoins" then
			continue
		end

		if v2.Name == "DoubleLuck" then
			continue
		end

		if table.find(tbl2, v2.Name) then
			continue
		end

		v2.Visible = false
	end
end

tbl1.LoadBoosts = function()
	local var4 = var8.GetCurrentReplica()
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Shop"):WaitForChild("ShopFrame"):WaitForChild("List"):WaitForChild("ScrollingFrame"):WaitForChild("Potions"):WaitForChild("List")
	if var8 and var4 then
		var5.CoinsPotion.BoostInfo.BoostOwnAmount.Text = "You have: " .. var4.Data.StoredBoosts.Coins
		var5.LuckPotion.BoostInfo.BoostOwnAmount.Text = "You have: " .. var4.Data.StoredBoosts.Lucky
		tbl1.UpdateBoostTimers()
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.Summon [ModuleScript]
-- y u r i

game:GetService("Lighting")
game:GetService("GamepadService")
game:GetService("UserInputService")
local var1 = game:GetService("ReplicatedStorage").Assets
local var2 = shared.Modules.Config
local var3 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var4 = shared.Modules.Replication
local function GetPlayerLuckMultiplier()
	local var1 = var4
	var1 = var1 and var4.GetCurrentReplica()
	if not var1 or (not var1.Data) then
		return 1
	end

	local var2 = var1.Data
	local num1 = 1
	if var2.ActivatedGamepasses then
		if var2.ActivatedGamepasses.DoubleLuck then
			num1 = num1 + 1
		end
	end

	local bool1 = false
	if var2.Boosts then
		local var3 = os.time()
		for k1, v1 in ipairs(var2.Boosts) do
			if v1.Name ~= "Lucky" then
				continue
			end

			if var3 >= v1.ExpireTime then
				continue
			end

			bool1 = true
			break
		end
	end

	if bool1 then
		num1 = num1 + 1
	end

	return num1
end

local var5 = shared.Modules.TweenButtons
local var6 = shared.Modules.InfoFrame
local tbl1 = {}
local str1 = "Basic Crate"
local var7 = shared.Modules.Network
local var8 = game:GetService("RunService")
local var9 = game:GetService("SoundService")
local var10 = game:GetService("TweenService")
tbl1.Start = function()
	while not var4 do
		task.wait()
		var4 = shared.Modules.Replication
	end

	while not var5 do
		task.wait()
		var5 = shared.Modules.TweenButtons
	end

	while not var6 do
		task.wait()
		var6 = shared.Modules.InfoFrame
	end

	local var2 = var4.GetCurrentReplica()
	if not var2 then
		return
	end

	local var9 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Summon")
	if not var9 then
		return
	end

	task.spawn(tbl1.StartTimer)
	local var10 = var9:WaitForChild("SummonFrame")
	local var11 = var10:WaitForChild("Buttons")
	var11:WaitForChild("Summon1Button").Activated:Connect(function()
		if not str1 then
			return
		end

		local var1 = str1
		local num1 = 1
		tbl1.SummonedTowers(var7.Get("SummonTowers"):InvokeServer(var1, num1))
	end)

	var11:WaitForChild("Summon10Button").Activated:Connect(function()
		if not str1 then
			return
		end

		local var1 = str1
		local num1 = 10
		tbl1.SummonedTowers(var7.Get("SummonTowers"):InvokeServer(var1, num1))
	end)

	var10:WaitForChild("Index").Activated:Connect(function()
		var5.OnButtonClick("Index")
	end)

	var2:OnSet({ "Boosts" }, function()
		tbl1.Update()
	end)

	var2:OnSet({ "ActivatedGamepasses" }, function()
		tbl1.Update()
	end)

	tbl1.Update()
	var7.Get("SummonSetUpdated").OnClientEvent:Connect(tbl1.Update)
	for k1, v1 in var10:WaitForChild("Crates"):WaitForChild("List"):WaitForChild("Crates"):GetChildren() do
		if not v1:IsA("ImageButton") then
			continue
		end

		v1.Activated:Connect(function()
			str1 = v1.Name
			tbl1.Update()
		end)

	end
end

local tbl2 = { Basic = Color3.fromRGB(180, 180, 180) }
tbl2.Uncommon = Color3.fromRGB(85, 255, 127)
tbl2.Rare = Color3.fromRGB(85, 170, 255)
tbl2.Epic = Color3.fromRGB(170, 85, 255)
tbl2.Legendary = Color3.fromRGB(255, 170, 0)
tbl2.Mythic = Color3.fromRGB(255, 85, 85)
local function GetBestRarity(arg1)
	local var1 = nil
	local num1 = 0
	for k1, v1 in arg1, nil do
		local var3 = var2.Towers[typeof(v1) == "table" and v1.Name or v1]
		if not var3 then
			continue
		end

		local var4 = var2.GameSettings.SummonRarities
		local var5 = var3.Rarity
		local var6 = table.find(var4 or {}, var5) or 999
		if not var6 or num1 >= var6 then
			continue
		end

		var1 = var5
		local var7 = var6
	end

	return var1
end

local var11 = var1.RaritiesGradients
tbl1.SummonedTowers = function(arg1)
	if not arg1 or #arg1 == 0 then
		return
	end

	local var4 = var3:WaitForChild("Main"):WaitForChild("SummonedFrame")
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Summon")
	local var6 = var4:WaitForChild("ViewportFrame")
	local var7 = var4:FindFirstChild("Pattern")
	local var12 = var4:WaitForChild("SummonTroop")
	local var13 = var4:WaitForChild("Close")
	var13.Visible = false
	local var15 = GetBestRarity(arg1)
	if var7 and (var15 and tbl2[var15]) then
		local var16 = TweenInfo.new(0.5)
		var10:Create(var7, var16, { ImageColor3 = tbl2[var15] }):Play()
	end

	local var17 = var9:WaitForChild("Background").EqualizerSoundEffect
	var17.Enabled = true
	var17 = var9:WaitForChild("Background").EqualizerSoundEffect
	var17.MidGain = 0
	var17 = var9:WaitForChild("Background").EqualizerSoundEffect
	var17.HighGain = 0
	var10:Create(var9:WaitForChild("Background").EqualizerSoundEffect, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), { MidGain = -20 }):Play()
	local var18 = Enum.EasingStyle.Cubic
	var10:Create(var9:WaitForChild("Background").EqualizerSoundEffect, TweenInfo.new(0.3, var18, Enum.EasingDirection.Out), { HighGain = -80 }):Play()
	var4.Visible = true
	var5.Visible = false
	var6.ImageTransparency = 1
	var17 = var6:FindFirstChild("WorldModel")
	for k1, v1 in var17:GetChildren() do
		v1:Destroy()
	end

	local var20 = var1:WaitForChild("Crates"):FindFirstChild(str1)
	if not var20 then
		return
	end

	local var21 = var20:Clone()
	var21.Parent = var17
	local var22 = var21:FindFirstChild("RootPart")
	var22 = var22 or var21.PrimaryPart
	if not var22 then
		return
	end

	local var23 = CFrame.new(0, -2, -6) * CFrame.Angles(0.087266462599716474, 1.0471975511965976, 0.17453292519943295)
	local var24 = CFrame.new(2, -2, -8) * CFrame.Angles(0.087266462599716474, 1.5707963267948966, 0.17453292519943295)
	var22.CFrame = var24
	var10:Create(var6, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { ImageTransparency = 0 }):Play()
	local var25 = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local var26 = var10:Create(var22, var25, { CFrame = var23 })
	var26:Play()
	var26.Completed:Wait()
	local var27 = os.clock()
	var25 = CFrame.new()
	local var28 = nil
	local var29 = var21:FindFirstChild("Main")
	local var30 = var29
	var30 = var30 and var29:FindFirstChild("Roof")
	local var31 = var30
	var31 = var31 and var30.C0
	var28 = var8.RenderStepped:Connect(function()
		local var1 = os.clock() - var27
		local var2 = math.cos(var1 * 1.4) * 0.034906585039886591
		var25 = CFrame.new(0, math.sin(var1 * 2) * 0.25, 0) * CFrame.Angles(var2, 0, var2)
		var22.CFrame = var23 * var25
	end)

	local var32
	if var30 and var31 then
		local var33 = var31 * CFrame.Angles(0, 0, -1.7453292519943295)
		var32 = TweenInfo.new(0.7, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		var10:Create(var30, var32, { C0 = var33 }):Play()
		var9:WaitForChild("Crate"):WaitForChild("OpenSound"):Play()
		task.wait(0.3)
	end

	for k2, v2 in var4:GetChildren() do
		local num1 = 1
		if v2.Name:sub(num1, 5) ~= "Card_" then
			continue
		end

		v2:Destroy()
	end

	local tbl1 = {}
	local function updateGridPositions(arg1, arg2)
		local var1 = arg1
		var1 = var1 or tbl1
		local var2 = #var1
		for k1, v1 in ipairs(var1) do
			local var3 = v1.card
			local var4 = var3:FindFirstChildOfClass("UIScale")
			local var5 = math.floor((k1 - 1) / 5)
			var4 = var4 or var3:WaitForChild("UIScale")
			local var6 = UDim2.fromScale(0.075 + 0.85 / (math.min(5, var2 - var5 * 5) + 1) * ((k1 - 1) % 5 + 1), var5 * 0.3 + 0.2)
			v1.basePos = var6
			local var7 = math.random(-3, 3)
			v1.targetRotation = var7
			local var8 = if arg2 then 0.75 else 0.65
			local var9 = TweenInfo.new(var8, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
			var10:Create(var3, var9, { Position = var6 }):Play()
			var10:Create(var4, TweenInfo.new(var8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 0.9 }):Play()
			var3.ZIndex = 10 + k1
		end
	end

	local function setupCardHoverEffect(arg1)
		local var1 = arg1.card
		local var2 = var1:FindFirstChildOfClass("UIScale")
		var2 = var2 or var1:WaitForChild("UIScale")
		var1.MouseEnter:Connect(function()
			var1.ZIndex = 100
			arg1.targetRotation = 0
			var10:Create(var2, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 0.98 }):Play()
		end)

		var1.MouseLeave:Connect(function()
			var1.ZIndex = 10
			arg1.targetRotation = arg1.baseRotation or 0
			var10:Create(var2, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 0.9 }):Play()
		end)
	end

	for k3, v3 in ipairs(arg1) do
		local var34 = typeof(v3) == "table" and v3.Name or v3
		local var35 = var12:Clone()
		var35.Name = "Card_" .. k3
		var35.Parent = var4
		var35.Visible = true
		var35.AnchorPoint = Vector2.new(0.5, 0.5)
		var35.Size = var12.Size
		local var37 = var35:FindFirstChildOfClass("UIScale")
		local var38 = var2.Towers[var34]
		if not var37 then
			var37 = Instance.new("UIScale")
			var37.Parent = var35
		end

		for k4, v4 in var35:WaitForChild("Holder"):WaitForChild("RarityFrame"):GetChildren() do
			if not v4:IsA("UIGradient") then
				continue
			end

			v4:Destroy()
		end

		local var40 = var35:WaitForChild("Holder"):FindFirstChild("TroopIcon", true)
		if var40 and var38 then
			var40.Image = var38.Icon
		end

		local var42 = var35:WaitForChild("Holder"):FindFirstChild("UnitName", true)
		if var42 then
			var42.Text = var34
		end

		local var44 = var35:WaitForChild("Holder"):FindFirstChild("RarityFrame", true)
		if var44 then
			local var45 = var44:WaitForChild("Rarity")
			var45.Text = var38.Rarity
			var44.UIShadow.Color = tbl2[var38.Rarity]
		end

		local var47 = var11:FindFirstChild(var38.Rarity)
		if var47 then
			local var48 = var47:Clone()
			var48.Parent = var35:WaitForChild("Holder"):FindFirstChild("RarityFrame")
		end

		var35.Position = UDim2.fromScale(0.5, 0.8)
		var35.Rotation = math.random(-25, 25)
		var35.ZIndex = 100
		var37.Scale = 0
		local var49 = UDim2.fromScale(0.5, 0.45)
		local var50 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var10:Create(var35, var50, { Position = var49, Rotation = 0 }):Play()
		var9:WaitForChild("Crate"):WaitForChild("Swap"):Play()
		local var51 = var10:Create(var37, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 1.25 })
		var51:Play()
		var51.Completed:Wait()
		task.wait(0.1)
		local var52 = var2.GameSettings.SummonRarities
		local tbl3 = {
			card = var35,
			rarity = var38.Rarity,
			rarityOrder = table.find(var52 or {}, var38.Rarity) or 999,
			baseRotation = 0,
			targetRotation = 0,
		}

		tbl3.basePos = var49
		tbl3.seed = math.random() * 100
		setupCardHoverEffect(tbl3)
		table.insert(tbl1, tbl3)
		updateGridPositions()
	end

	task.wait(0.3)
	table.sort(tbl1, function(arg1, arg2)
		return arg1.rarityOrder < arg2.rarityOrder
	end)

	var9:WaitForChild("Crate"):WaitForChild("Grid"):Play()
	updateGridPositions(nil, true)
	task.wait(0.75)
	for k5, v5 in ipairs(tbl1) do
		v5.baseRotation = v5.targetRotation
	end

	local var53 = os.clock()
	local var54 = nil
	var54 = var8.RenderStepped:Connect(function()
		local var1 = os.clock() - var53
		local var2 = math.clamp(var1 / 1, 0, 1)
		for k1, v1 in ipairs(tbl1) do
			local var3 = v1.card
			if not var3 then
				continue
			end

			if not var3.Parent then
				continue
			end

			if not v1.basePos then
				continue
			end

			local var4 = math.cos(var1 * 1.8 + v1.seed) * 1.5 * var2
			var3.Position = UDim2.fromScale(v1.basePos.X.Scale, v1.basePos.Y.Scale + math.sin(var1 * 2.2 + v1.seed) * 0.012 * var2)
			local var5 = var3.Rotation
			var3.Rotation = var5 + (v1.targetRotation + var4 - var5) * 0.15
		end
	end)

	var13.Visible = true
	local var55 = nil
	var13.Activated:Connect(function()
		var55:Disconnect()
		if var54 then
			var54:Disconnect()
			var54 = nil
		end

		if var28 then
			var28:Disconnect()
			var28 = nil
		end

		local tbl2 = {}
		for k1, v1 in ipairs(tbl1) do
			local tbl3 = {
				card = v1.card,
				posX = v1.card.Position.X.Scale,
				posY = v1.card.Position.Y.Scale,
				velX = math.random(-100, 100) / 1000,
				transparency = 0,
			}

			tbl3.velY = -math.random(150, 250) / 1000
			tbl3.rot = v1.card.Rotation
			tbl3.rotVel = math.random(-25, 25)
			table.insert(tbl2, tbl3)
		end

		var9:WaitForChild("Crate"):WaitForChild("Close"):Play()
		local var1 = nil
		var10:Create(var6, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { ImageTransparency = 1 }):Play()
		var1 = var8.RenderStepped:Connect(function(arg1)
			for k1, v1 in ipairs(tbl2) do
				local var1 = v1.card
				if not var1 then
					continue
				end

				if not var1.Parent then
					continue
				end

				local var2 = v1.velY - 0.45 * arg1
				v1.velY = var2
				var2 = v1.posX + v1.velX * arg1
				v1.posX = var2
				var2 = v1.posY + v1.velY * arg1
				v1.posY = var2
				var2 = v1.rot + v1.rotVel * arg1
				v1.rot = var2
				var2 = math.clamp(v1.transparency + 1.8 * arg1, 0, 1)
				v1.transparency = var2
				var1.Position = UDim2.fromScale(v1.posX, v1.posY)
				var1.Rotation = v1.rot
				for k2, v2 in ipairs(var1:GetDescendants()) do
					if v2:IsA("GuiObject") then
						local var3 = math.max(v2.BackgroundTransparency, v1.transparency)
						v2.BackgroundTransparency = var3
					end

					if v2:IsA("ImageLabel") then
						local var4 = math.max(v2.ImageTransparency, v1.transparency)
						v2.ImageTransparency = var4
					end

					if v2:IsA("UIStroke") then
						local var5 = math.max(v2.Transparency, v1.transparency)
						v2.Transparency = var5
					end

					if v2:IsA("TextLabel") then
						local var6 = math.max(v2.TextTransparency, v1.transparency)
						v2.TextTransparency = var6
					end

					if not v2:IsA("UIShadow") then
						continue
					end

					local var7 = math.max(v2.Transparency, v1.transparency)
					v2.Transparency = var7
				end
			end
		end)

		var22.CFrame = var22.CFrame
		local var2 = TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		local tbl4 = { CFrame = var24 }
		var10:Create(var22, var2, tbl4):Play()
		if var30 and var31 then
			var2 = TweenInfo.new(0.5)
			tbl4 = { C0 = var31 }
			var10:Create(var30, var2, tbl4):Play()
		end

		task.wait(0.7)
		if var1 then
			var1:Disconnect()
		end

		for k2, v2 in ipairs(tbl1) do
			v2.card:Destroy()
		end

		if var21 then
			var21:Destroy()
		end

		var13.Visible = false
		var4.Visible = false
		var5.Visible = true
		var10:Create(var9:WaitForChild("Background").EqualizerSoundEffect, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), { MidGain = 0 }):Play()
		var10:Create(var9:WaitForChild("Background").EqualizerSoundEffect, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), { HighGain = 0 }):Play()
		task.delay(0.3, function()
			local var1 = var9:WaitForChild("Background").EqualizerSoundEffect
			var1.Enabled = false
		end)
	end)
end

local function GetCalculatedChances(arg1)
	local var2 = GetPlayerLuckMultiplier()
	if var2 <= 1 then
		return arg1
	end

	local tbl1 = {}
	local num1 = 0
	for k1, v1 in pairs(arg1) do
		if v1 >= 10 then
			continue
		end

		num1 = num1 + v1 * (var2 - 1)
	end

	for k2, v2 in pairs(arg1) do
		if v2 < 10 then
			tbl1[k2] = v2 * var2
		elseif k2 == "Basic" then
			tbl1[k2] = math.max(0.1, v2 - num1)
		else
			tbl1[k2] = v2
		end
	end

	return tbl1
end

tbl1.Update = function(arg1)
	local var1 = arg1
	var1 = var1 or var7.Get("GetSummonSet"):InvokeServer()
	if not var1 then
		return
	end

	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Summon")
	local var5 = var4:WaitForChild("SummonFrame"):WaitForChild("List"):WaitForChild("Units")
	local var8 = str1
	for k1, v1 in var2.GameSettings.SummonCrates, nil do
		local var9 = v1.Name
		if var9 ~= var8 then
			continue
		end

		local var10 = v1
	end

	local var13 = nil
	var8 = var1[str1]
	if not var13 or (not var8) then
		return
	end

	local var14 = GetCalculatedChances(var13.SummonChances)
	for k2, v2 in var5:GetChildren() do
		if not v2:IsA("Frame") then
			continue
		end

		if v2.Name == "UnitHolder" then
			continue
		end

		v2:Destroy()
	end

	for k3, v3 in pairs(var13.SummonChances) do
		local var15 = var8[k3]
		local var16 = var2.Towers[var15]
		if not var16 then
			continue
		end

		local var17 = var5:WaitForChild("UnitHolder"):Clone()
		var17.Name = k3
		var17.Visible = true
		var17.Parent = var5
		local var18 = var2.GameSettings.SummonRarities
		var17.LayoutOrder = table.find(var18 or {}, k3) or 999
		var17:WaitForChild("UnitFrame").UnitName.Text = var15
		local var19 = var17:WaitForChild("UnitFrame").UnitIcon
		var19.Image = var16.Icon
		var19 = var17:WaitForChild("UnitFrame").UnitChance
		var19.Text = (var14[k3] or v3) .. "%"
		var19 = { Name = var15 }
		var17:WaitForChild("UnitFrame").UnitIcon.MouseEnter:Connect(function()
			var6:MoveInfoUI(var19)
		end)

		var17:WaitForChild("UnitFrame").UnitIcon.MouseLeave:Connect(function()
			var6:HideInfoUI()
		end)

		var17:WaitForChild("UnitFrame").UnitIcon.MouseMoved:Connect(function()
			var6:MoveInfoUI(var19)
		end)

		local var20 = k3
		if not var11:FindFirstChild(var20) then
			continue
		end

		var18 = var11:FindFirstChild(k3):Clone()
		var18.Parent = var17:WaitForChild("UnitFrame")
	end

	local var21 = var3:FindFirstChild("SummonBoardUI")
	var21 = var21 or workspace:FindFirstChild("SummonBoardUI", true)
	if var21 then
		local var22 = var21:FindFirstChild("SummonHolder", true)
		var22 = var22 and (var21.SummonHolder:FindFirstChild("MainFrame") and var21.SummonHolder.MainFrame:FindFirstChild("UnitList"))
		if var22 then
			local str2 = "Units2"
			for k4, v4 in ipairs({ "Units1", str2 }) do
				local var23 = var22:FindFirstChild(v4)
				if not var23 then
					continue
				end

				for k5, v5 in var23:GetChildren() do
					if not v5:IsA("GuiObject") then
						continue
					end

					local var24 = v5.Name
					local var25 = var14[var24]
					local var26 = var8[var24]
					if not var25 or (not var26) then
						continue
					end

					v5.Visible = true
					local var27 = v5:FindFirstChild("UnitName", true)
					local var28 = v5:FindFirstChild("Chance", true)
					local var29 = v5:FindFirstChild("UnitIcon", true)
					var27 = var27 or v5:FindFirstChild("Title", true)
					var28 = var28 or v5:FindFirstChild("UnitChance", true)
					var29 = var29 or v5:FindFirstChild("Icon", true)
					if var27 and var27:IsA("TextLabel") then
						var27.Text = var26
					end

					if var28 and var28:IsA("TextLabel") then
						var28.Text = var25 .. "%"
					end

					local var31 = var2.Towers[var26]
					if var29 and (var29:IsA("ImageLabel") and var31) then
						var29.Image = var31.Icon
					end

					var31 = { Name = var26 }
					v5.MouseEnter:Connect(function()
						var6:MoveInfoUI(var31)
					end)

					v5.MouseLeave:Connect(function()
						var6:HideInfoUI()
					end)

					v5.MouseMoved:Connect(function()
						var6:MoveInfoUI(var31)
					end)

				end
			end
		end
	end

	local var32 = var13.SummonPrice
	var4:WaitForChild("SummonFrame"):WaitForChild("Buttons"):WaitForChild("Summon1Button"):WaitForChild("CurrencyFrame"):WaitForChild("AmountLabel").Text = var32
	local var33 = var4:WaitForChild("SummonFrame"):WaitForChild("Buttons"):WaitForChild("Summon10Button"):WaitForChild("CurrencyFrame"):WaitForChild("AmountLabel")
	var33.Text = var32 * 9
	var33 = var4:WaitForChild("SummonFrame"):WaitForChild("List").Title
	var33.Text = str1
end

tbl1.StartTimer = function()
	local var1 = var3:FindFirstChild("SummonBoardUI")
	var1 = var1 or workspace:FindFirstChild("SummonBoardUI", true)
	local var4 = var1
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Summon"):WaitForChild("SummonFrame"):WaitForChild("Timer")
	var4 = var4 and var1:FindFirstChild("ResetTimer", true)
	while true do
		local var6 = os.time()
		local var7 = var2.GameSettings.SummonInterval or 3600
		local var8 = (math.floor(var6 / var7) + 1) * var7 - var6
		local var9 = string.format("%02d:%02d", math.floor(var8 / 60), var8 % 60)
		var5.Text = "Resetting in: " .. var9
		if var4 and var4:IsA("TextLabel") then
			var4.Text = "Resetting in: " .. var9
		end

		task.wait(1)
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.Staff [ModuleScript]
-- y u r i

game:GetService("SoundService")
game:GetService("UserInputService")
local var1 = game:GetService("Players")
local var2 = var1.LocalPlayer
local var3 = nil
local var4 = nil
local var5 = var2:WaitForChild("PlayerGui")
local var6 = shared.Modules.Network
local var7 = var2:GetMouse()
local function updateStaffUI(arg1, arg2)
	if not arg1 or (not arg2) then
		return
	end

	if not var4 then
		local var1 = var5:WaitForChild("Main"):WaitForChild("Main"):FindFirstChild("TroopTeamInspector")
		var1 = var1 or var5:FindFirstChild("TroopTeamInspector", true)
		var4 = var1
	end

	if var4 then
		local var2 = arg2:FindFirstChild("HumanoidRootPart")
		var4.Adornee = var2 or arg2.PrimaryPart or arg2
		var4.Enabled = true
	end

	local var7 = var6.Get("GetPlayerSlots", "RemoteFunction"):InvokeServer(arg1)
	if not var7 then
		return
	end

	local var9 = var4:FindFirstChild("PlayerUnits", true)
	if not var9 then
		return
	end

	for i1 = 1, 5 do
		local var10 = var9:FindFirstChild("Troop" .. i1)
		if not var10 then
			continue
		end

		local var11 = var7[i1]
		if not var10:IsA("GuiObject") or (not var11) then
			continue
		end

		var10.Image = var11.Icon
	end
end

local var8 = shared.Modules.TweenButtons
local var9 = shared.Modules.InfoFrame
local function handleClick()
	local var5 = var7.Target
	if not var5 then
		if var3 then
			var3 = nil
		end

		if var4 then
			var4.Adornee = nil
			var4.Enabled = false
		end

		return
	end

	local var8 = var5:FindFirstAncestorOfClass("Model")
	if not var8 then
		if var3 then
			var3 = nil
		end

		if var4 then
			var4.Adornee = nil
			var4.Enabled = false
		end

		return
	end

	local var10 = var1:GetPlayerFromCharacter(var8)
	if var8:FindFirstChildOfClass("Humanoid") then
		if not var10 then
			if var3 then
				var3 = nil
			end

			if var4 then
				var4.Adornee = nil
				var4.Enabled = false
			end

			return
		end
	end

	if var3 == var10 then
		if var3 then
			var3 = nil
		end

		if not var4 then
			return
		end

		var4.Adornee = nil
		var4.Enabled = false
		return
	end

	var3 = var10
	updateStaffUI(var10, var8)
end

local var10 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
return { Start = function()
	while not var8 do
		task.wait()
		var8 = shared.Modules.TweenButtons
	end

	while not var9 do
		task.wait()
		var9 = shared.Modules.InfoFrame
	end

	local var2 = var5:WaitForChild("Main"):WaitForChild("Main"):FindFirstChild("TroopTeamInspector")
	var2 = var2 or var5:FindFirstChild("TroopTeamInspector", true)
	var4 = var2
	if var4 then
		var4.Enabled = false
		var4.Adornee = nil
	end

	var7.Button1Down:Connect(handleClick)
	var1.PlayerRemoving:Connect(function(arg1)
		if var3 then
			if var3.Name == arg1.Name then
				if var3 then
					var3 = nil
				end

				if var4 then
					var4.Adornee = nil
					var4.Enabled = false
				end
			end
		end
	end)
end }

--- ReplicatedStorage.ModuleLoader.Client.UI.Notification [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
game:GetService("RunService")
local var1 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var2 = shared.Modules.Network
local tbl1 = { Create = function(arg1, arg2, arg3)
	local var2 = var1:WaitForChild("Main"):WaitForChild("Notifications")
	local var3 = var2:WaitForChild("Actions")
	local var4 = var2:WaitForChild("Title"):Clone()
	var4.Parent = var3
	var4.Visible = true
	var4.Text = arg1
	var4.TextColor3 = arg3
	var4.UIShadow.Color = arg3
	task.delay(arg2 or 5, function()
		var4:Destroy()
	end)
end }

tbl1.Init = function()
	while not var2 do
		task.wait()
		var2 = shared.Modules.Network
	end

	var2.Get("Notificate").OnClientEvent:Connect(tbl1.Create)
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.UpdateLog [ModuleScript]
-- y u r i

game:GetService("MarketplaceService")
game:GetService("RunService")
game:GetService("GamepadService")
game:GetService("UserInputService")
game:GetService("PolicyService")
local var1 = game:GetService("ReplicatedStorage"):WaitForChild("Assets"):WaitForChild("UI"):WaitForChild("UpdateLog")
local var2 = shared.Modules.Updates
local var3 = #var2
local var4 = var1:WaitForChild("UpdateTitle")
local var5 = var1:WaitForChild("UpdateDate")
local var6 = var1:WaitForChild("UpdateInfo")
local var7 = shared.Modules.Replication
local var8 = shared.Modules.TweenButtons
local var9 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local function renderUpdate(arg1, arg2)
	local var1 = var2
	local var7 = var1
	var7 = var7 and var1[var3]
	if not var7 then
		return
	end

	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("TextLabel") then
			continue
		end

		v1:Destroy()
	end

	local var8 = var4:Clone()
	var8.Text = var7.Title
	var8.Parent = arg1
	local var9 = var5:Clone()
	var9.Text = var7.Date
	var9.Parent = arg1
	for k2, v2 in ipairs(var7.Logs) do
		local var10 = var6:Clone()
		var10.Text = v2
		var10.Parent = arg1
	end

	if arg2 then
		arg2.Text = string.format("%d/%d", var3, #var1)
	end
end

local var10 = shared.Modules.Network
return { Start = function()
	while not var7 or (not var2) or (not var8) do
		task.wait()
		var7 = shared.Modules.Replication
		var2 = shared.Modules.Updates
		var8 = shared.Modules.TweenButtons
	end

	local var1 = var9:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("UpdateLog"):WaitForChild("UpdateLogFrame")
	local var4 = var1:WaitForChild("Controller"):WaitForChild("Buttons")
	local var5 = var1:WaitForChild("List"):WaitForChild("ScrollingFrame")
	local var6 = var4:WaitForChild("UpdateNumber")
	var3 = #var2
	renderUpdate(var5, var6)
	var10.Get("CheckUpdateLog").OnClientEvent:Connect(function(arg1)
		if arg1 then
			var3 = #var2
			renderUpdate(var5, var6)
			var8.OnButtonClick("UpdateLog")
			var10.Get("MarkUpdateLogRead"):InvokeServer()
		end
	end)

	var4:WaitForChild("Forward").Activated:Connect(function()
		if var2 and var3 < (#var2) then
			local var1 = var3 + 1
			var3 = var1
			renderUpdate(var5, var6)
		end
	end)

	var4:WaitForChild("Backward").Activated:Connect(function()
		if 1 < var3 then
			local var1 = var3 - 1
			var3 = var1
			renderUpdate(var5, var6)
		end
	end)

	var4:WaitForChild("FastForward").Activated:Connect(function()
		if var2 and var3 ~= (#var2) then
			var3 = #var2
			renderUpdate(var5, var6)
		end
	end)

	var4:WaitForChild("FastBackward").Activated:Connect(function()
		if var3 ~= 1 then
			var3 = 1
			renderUpdate(var5, var6)
		end
	end)
end }

--- ReplicatedStorage.ModuleLoader.Client.UI.Settings [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
game:GetService("RunService")
local var1 = shared.Modules.Replication
local var2 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local tbl1 = {}
local var3 = shared.Modules.Network
local var4 = game:GetService("SoundService")
tbl1.Start = function()
	while not var1 do
		task.wait()
		var1 = shared.Modules.Replication
	end

	local var5 = var2:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Settings"):WaitForChild("SettingsFrame")
	if not var5 then
		return
	end

	var1.GetCurrentReplica()
	for k1, v1 in var5:WaitForChild("List"):WaitForChild("ScrollingFrame"):GetChildren() do
		if not v1:IsA("Frame") then
			continue
		end

		tbl1.UpdateSettingUI(var3.Get("UpdateSetting"):InvokeServer(false, v1.Name), v1)
		v1:WaitForChild("Holder"):WaitForChild("PossibleButtons"):WaitForChild("SwitchButton").Activated:Connect(function()
			tbl1.UpdateSettingUI(var3.Get("UpdateSetting"):InvokeServer(true, v1.Name), v1)
		end)

	end
end

tbl1.UpdateSettingUI = function(arg1, arg2)
	local var2 = arg2:WaitForChild("Holder"):WaitForChild("PossibleButtons"):WaitForChild("SwitchButton")
	if arg2.Name == "Trades" then
		if arg1 == "All" then
			local var3 = var2:WaitForChild("UI3")
			var3.Visible = false
			var3 = var2:WaitForChild("UI1")
			var3.Visible = false
			var3 = var2:WaitForChild("UI")
			var3.Visible = true
			var2.UIStroke.Color = Color3.fromRGB(29, 97, 0)
			var2.UIShadow.Color = Color3.fromRGB(61, 200, 1)
		elseif arg1 == "Friends" then
			local var5 = var2:WaitForChild("UI3")
			var5.Visible = true
			var5 = var2:WaitForChild("UI1")
			var5.Visible = false
			var5 = var2:WaitForChild("UI")
			var5.Visible = false
			var2.UIStroke.Color = Color3.fromRGB(98, 87, 0)
			var2.UIShadow.Color = Color3.fromRGB(172, 161, 0)
		else
			local var6 = var2:WaitForChild("UI1")
			var6.Visible = true
			var6 = var2:WaitForChild("UI")
			var6.Visible = false
			var6 = var2:WaitForChild("UI3")
			var6.Visible = false
			var2.UIStroke.Color = Color3.fromRGB(106, 0, 0)
			var2.UIShadow.Color = Color3.fromRGB(172, 0, 0)
		end

		var2:WaitForChild("TextLabel").Text = arg1
		return
	end

	if arg2.Name == "Music" then
		local var7 = var4:WaitForChild("Music")
		var7.Volume = if arg1 then 1 else 0
	else
		if arg2.Name == "Sounds" then
			local var8 = var4:WaitForChild("Sounds")
			var8.Volume = if arg1 then 1 else 0
		end
	end

	if arg1 then
		local var9 = var2:WaitForChild("UI1")
		var9.Visible = false
		var9 = var2:WaitForChild("UI")
		var9.Visible = true
		var2.UIStroke.Color = Color3.fromRGB(29, 97, 0)
		var2.UIShadow.Color = Color3.fromRGB(61, 200, 1)
		var9 = var2:WaitForChild("TextLabel")
		var9.Text = "On"
		return
	end

	local var10 = var2:WaitForChild("UI1")
	var10.Visible = true
	var10 = var2:WaitForChild("UI")
	var10.Visible = false
	var2.UIStroke.Color = Color3.fromRGB(106, 0, 0)
	var2.UIShadow.Color = Color3.fromRGB(172, 0, 0)
	var10 = var2:WaitForChild("TextLabel")
	var10.Text = "Off"
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.Index [ModuleScript]
-- y u r i

game:GetService("RunService")
game:GetService("TweenService")
local var1 = shared.Modules.Replication
local var2 = shared.Modules.InfoFrame
local var3 = shared.Modules.BigNotify
local var4 = shared.Modules.TweenButtons
local tbl1 = {}
local var5 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var6 = game:GetService("UserInputService")
local var7 = game:GetService("GamepadService")
local var8 = game:GetService("SoundService")
local var9 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
tbl1.Start = function()
	while not var1 or (not var2) or (not var3) or (not var4) do
		task.wait()
		var1 = shared.Modules.Replication
		var3 = shared.Modules.BigNotify
		var2 = shared.Modules.InfoFrame
		var4 = shared.Modules.TweenButtons
	end

	tbl1.Update()
	local var8 = var1.GetCurrentReplica()
	var8:OnSet({ "Towers" }, tbl1.Update)
	var8:OnSet({ "Items" }, tbl1.Update)
	local var9 = var5:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Index")
	var9:GetPropertyChangedSignal("Visible"):Connect(function()
		if var9.Visible then
			if not var6.GamepadEnabled then
				return
			end

			var7:EnableGamepadCursor(var9)
			return
		end

		var2:HideInfoUI()
		var7:DisableGamepadCursor()
	end)

	local var10 = var9:WaitForChild("IndexFrame").TopButtons.SearchBar.SearchBarBox
	var10:GetPropertyChangedSignal("Text"):Connect(function()
		local var1 = var10.Text:lower()
		for k1, v1 in ipairs(var9:WaitForChild("IndexFrame").List.ScrollingFrame:GetChildren()) do
			if not v1:IsA("Frame") then
				continue
			end

			if v1.Name == "TroopFrame" then
				continue
			end

			if var1 == "" or string.find((v1:GetAttribute("SearchName") or ""):lower(), var1, 1, true) then
				v1.Visible = true
			else
				v1.Visible = false
			end
		end
	end)
end

local var10 = shared.Modules.Config
local tbl2 = {}
tbl1.Update = function()
	if tbl1.EquipConn then
		tbl1.EquipConn:Disconnect()
		tbl1.EquipConn = nil
	end

	local var3 = var1.GetCurrentReplica().Data
	local var6 = var3 and var3.Towers or {}
	if not var3 or (not var3.Items) then
	end

	local var7 = var5:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Index"):WaitForChild("IndexFrame")
	local var11 = var7:WaitForChild("List"):WaitForChild("ScrollingFrame"):WaitForChild("TroopFrame")
	var11.Visible = false
	local tbl3 = {}
	local num1 = 0
	local tbl4 = {}
	local var12
	if var10.Towers then
		for k1, v1 in pairs(var10.Towers) do
			num1 = num1 + 1
			for k2, v2 in pairs(var6) do
				if v2.Name ~= k1 then
					continue
				end

				local var13 = k2
				local var14 = v2
			end

			local var15 = var10.GameSettings.RarityOrder[v1.Rarity]
			local var16 = nil ~= nil
			table.insert(tbl4, {
				UUID = nil or k1,
				Data = { Name = k1, Equipped = false },
				Config = v1,
				RarityValue = var15 or 0,
				Name = k1,
				Type = "Tower",
				IsOwned = var16,
			})

		end
	end

	table.sort(tbl4, function(arg1, arg2)
		local var3 = arg1.RarityValue * 100
		local var4 = arg2.RarityValue * 100
		if var3 ~= var4 then
			return var4 < var3
		end

		return arg1.Name < arg2.Name
	end)

	local var17 = var7:WaitForChild("List"):WaitForChild("NoItemsFound")
	var17.Visible = #tbl4 == 0
	local var18 = num1
	var17 = var7:WaitForChild("TopButtons"):WaitForChild("UnitLimit"):WaitForChild("UnitAmount")
	var17.Text = ("%* Units"):format(var18)
	for k3, v3 in ipairs(tbl4) do
		local var19 = v3.Config
		local var20 = v3.UUID
		tbl3[var20] = true
		local var21 = v3.Data
		tbl2[var20] = { Data = var21, Type = v3.Type, IsOwned = v3.IsOwned }
		local var22 = var7.List.ScrollingFrame:FindFirstChild(var20)
		local var23 = var22
		var23 = var23 or var11:Clone()
		var23.Visible = true
		var23.Name = var20
		var23.Parent = var7.List.ScrollingFrame
		local var24 = var19.Rarity
		local var25 = var22 == nil
		var23.LayoutOrder = if v3.Name == var10.GameSettings.StarterTower then 99999999 else k3
		var23:SetAttribute("SearchName", var21.Name)
		local var26 = var23.TroopsFrame
		var26.TroopIcon.Image = var19.Icon or ""
		local var27 = var19 and (var19.Upgrades and (var19.Upgrades[1] and (var19.Upgrades[1].Price and ("$%*"):format(var19.Upgrades[1].Price)))) or ""
		var26.Price.Text = var27
		if v3.Type ~= "Tower" then
			var26.Price.Text = v3.Title or ""
		end

		local var29 = var26.Background:FindFirstChildWhichIsA("UIGradient")
		if var29 and var29.Name ~= "UIGradient" then
			var29:Destroy()
		end

		if var9:FindFirstChild(var24) then
			var27 = var9:FindFirstChild(var24):Clone()
			var27.Parent = var26.Background
		end

		var26.Equipped.Visible = var21.Equipped or false
		if var26:FindFirstChild("BulkSellIcon") then
			var26.BulkSellIcon.Visible = false
		end

		if not var25 then
			continue
		end

		var26.InteractiveButton.MouseEnter:Connect(function()
			local var3 = tbl2[var20]
			if var3 and var3.Type == "Tower" then
				var2:MoveInfoUI(var3.Data)
			end

			var4.Tween(var26.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), "Scale", 1.05, false)
			var8:WaitForChild("HoverSFX"):Play()
		end)

		var26.InteractiveButton.MouseMoved:Connect(function()
			local var3 = tbl2[var20]
			if var3 and var3.Type == "Tower" then
				var2:MoveInfoUI(var3.Data)
			end
		end)

		var26.InteractiveButton.MouseLeave:Connect(function()
			var2:HideInfoUI()
			var4.Tween(var26.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Scale", 1, false)
		end)

	end

	for k4, v4 in var7.List.ScrollingFrame:GetChildren() do
		if not v4:IsA("Frame") then
			continue
		end

		if v4.Name == "TroopFrame" then
			continue
		end

		if tbl3[v4.Name] then
			continue
		end

		v4:Destroy()
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.Trade [ModuleScript]
-- y u r i

game:GetService("RunService")
local var1 = game:GetService("Players")
local var2 = var1.LocalPlayer
local var3 = var2:WaitForChild("PlayerGui")
local var4 = shared.Modules.Config
local var5 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
local function ApplyItemVisual(arg1, arg2, arg3, arg4)
	local var16
	local var1 = arg1:FindFirstChild("TroopsFrame") or arg1
	local var3 = var1:FindFirstChild("TroopIcon", true)
	local var6 = var1:FindFirstChild("Background") or var1
	if var3 and arg2 then
		var3.Image = arg2.Icon or ""
	end

	local var8 = var1:FindFirstChild("Price", true)
	if var8 then
		if arg2 and arg2.PlacePrice then
			var8.Text = ("$%*"):format(arg2.PlacePrice)
		else
			if arg2 and (arg2.Upgrades and arg2.Upgrades[1]) then
				var8.Text = ("$%*"):format(arg2.Upgrades[1].Price)
			elseif arg2 then
				local var9 = arg2.PassName
				var9 = var9 or (arg2.Name or (arg3 and arg3.PassName or (arg3.Name or "")))
			end
		end
	end

	local var11 = var1:FindFirstChild("BulkSellIcon", true)
	if var11 then
		if var4 and (arg3 and arg3.Name == var4.GameSettings.StarterTower) then
			var11.Visible = true
		else
			var11.Visible = false
		end
	end

	local var13 = var1:FindFirstChild("Equipped", true)
	if var13 then
		var13.Visible = arg3 and arg3.Equipped
	end

	if arg2 then
		local var15 = arg2.Rarity
		if not var15 then
			var15 = if arg4 == "Gamepass" then "Legendary" else "Common"
		end
	end

	for k1, v1 in ipairs(var6:GetChildren()) do
		if not v1:IsA("UIGradient") then
			continue
		end

		v1:Destroy()
	end

	local var18 = var5:FindFirstChild(var16)
	if var18 then
		var18:Clone().Parent = var6
		local var19 = var1:FindFirstChild("UIStroke", true)
		var19 = var19 or var6:FindFirstChild("UIStroke")
		if var19 then
			if arg3 and arg3.Equipped then
				var19.Color = Color3.fromRGB(255, 255, 255)
				local var21 = var19:FindFirstChild("UIGradient")
				if var21 then
					var21.Enabled = true
				end
			else
				local var22 = var18.Color.Keypoints[1].Value
				var19.Color = Color3.new(var22.R * 0.45, var22.G * 0.45, var22.B * 0.45)
				local var24 = var19:FindFirstChild("UIGradient")
				if var24 then
					var24.Enabled = false
				end
			end
		end
	end

	local var25 = var4.GameSettings.RarityOrder and var4.GameSettings.RarityOrder[var16] or 1
	if arg1:GetAttribute("OriginalName") ~= var4.GameSettings.StarterTower then
		local var26 = -var25
		var26 = var26 or 999999999
	end

	arg1.LayoutOrder = 999999999
end

local var6 = shared.Modules.InfoFrame
local var7 = shared.Modules.TweenButtons
local var8 = game:GetService("SoundService")
local var9 = game:GetService("Lighting")
local var10 = game:GetService("TweenService")
local function AddTradeItem(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var2 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade"):WaitForChild("InventoryFrame"):WaitForChild("List"):WaitForChild("ScrollingFrame"):FindFirstChild("TroopFrame")
	if var2 then
		var2.Visible = false
	end

	if not var2 or (not arg1) then
		return
	end

	local var4 = var2:Clone()
	var4.Name = arg3
	var4:SetAttribute("OriginalName", arg2)
	ApplyItemVisual(var4, arg4, arg6, arg5)
	var4.Visible = true
	var4.Parent = arg1
	local var5 = var4:FindFirstChild("TroopsFrame") or var4
	local var9 = var5:FindFirstChild("InteractiveButton")
	var9 = var9 or (var4:IsA("GuiButton") and var4 or var4:FindFirstChildOfClass("GuiButton"))
	if arg7 and var9 then
		var9.Activated:Connect(function()
			var6:HideInfoUI()
			arg7()
		end)

	end

	local var10 = arg6
	local var11 = table.clone(var10 or {})
	var11.Name = arg2
	if var9 then
		if arg5 == "Tower" then
			var10 = var5:FindFirstChild("UIScale")
			var10 = var10 or var4:FindFirstChild("UIScale")
			var9.MouseEnter:Connect(function()
				var6:MoveInfoUI(var11, nil, arg5)
				if var10 and var7 then
					var7.Tween(var10, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), "Scale", 1.05, false)
				end

				local var2 = var8:FindFirstChild("HoverSFX")
				if var2 then
					var2:Play()
				end
			end)

			var9.MouseMoved:Connect(function()
				var6:MoveInfoUI(var11, nil, arg5)
			end)

			var9.MouseLeave:Connect(function()
				var6:HideInfoUI()
				if var10 and var7 then
					var7.Tween(var10, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Scale", 1, false)
				end
			end)

		end
	end
end

local tbl1 = {
	CurrentTradeData = nil,
	LastChatCount = 0,
	_checkReadyRunning = false,
	_refreshListConnection = nil,
	_historyCloseConnection = nil,
}

tbl1.ShowHistoryDetails = function(arg1)
	local var2 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("TradeHistory")
	if not var2 then
		return
	end

	var2.HistoryFrame.OtherPlayer.PlayerDisplay.Text = arg1.DisplayName
	var2.HistoryFrame.OtherPlayer.PlayerUser.Text = "@" .. arg1.Name
	var2.HistoryFrame.OtherPlayer.PlayerPFP.Image = ("https://www.roblox.com/headshot-thumbnail/image?userId=%*&width=420&height=420&format=png"):format(arg1.UserId)
	local var5 = var2.HistoryFrame.TradeMenu:WaitForChild("YourItemsOffer"):WaitForChild("Items")
	local var6 = var2.HistoryFrame.TradeMenu:WaitForChild("PlayerItemsOffer"):WaitForChild("Items")
	for k1, v1 in var5:GetChildren() do
		if not v1:IsA("TextButton") then
			continue
		end

		if v1.Name == "Template" then
			continue
		end

		v1:Destroy()
	end

	for k2, v2 in var6:GetChildren() do
		if not v2:IsA("TextButton") then
			continue
		end

		if v2.Name == "Template" then
			continue
		end

		v2:Destroy()
	end

	local function renderHistoryItems(arg1, arg2)
		if not arg2 then
			return
		end

		for k1, v1 in ipairs(arg2) do
			local var3 = v1.Type or "Tower"
			local var5 = v1.Name
			local var6
			if var3 == "Tower" then
				var6 = var4.Towers
				if var6 then
					var6 = var4.Towers[var5]
				end
			else
				var6 = var4.Ids
				var6 = var6 and (var4.Ids.Products and var4.Ids.Products[var5])
			end

			if not var6 then
				continue
			end

			AddTradeItem(arg1, var5, "HistoryItem_" .. k1, var6, var3, { Name = var5, ItemType = var3, Modifier = "None", Level = 1 }, nil)
		end
	end

	renderHistoryItems(var5, arg1.GaveItems)
	renderHistoryItems(var6, arg1.TookItems)
	var2.Visible = true
	if var7 and var9:FindFirstChild("Blur") then
		var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 24, false)
	end

	if tbl1._historyCloseConnection then
		tbl1._historyCloseConnection:Disconnect()
	end

	tbl1._historyCloseConnection = var2.Close.Activated:Connect(function()
		var2.Visible = false
		tbl1._historyCloseConnection:Disconnect()
		tbl1._historyCloseConnection = nil
	end)
end

local var11 = shared.Modules.Replication
local str1 = "Towers"
local var12 = shared.Modules.Network
tbl1.OfferTrade = function()
	local var5 = var11.GetCurrentReplica()
	if not var5 or (not var5.Data) then
		return
	end

	local var6 = var5.Data.Towers
	local var7 = var5.Data.Items
	local var8 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	local var9 = var8:WaitForChild("InventoryFrame"):WaitForChild("List"):WaitForChild("ScrollingFrame")
	var6 = var6 or {}
	var7 = var7 or {}
	local var10 = var8:WaitForChild("TradeFrame"):WaitForChild("TradeMenu"):WaitForChild("YourItemsOffer"):WaitForChild("Items")
	for k1, v1 in var9:GetChildren() do
		if v1.Name == "TroopFrame" then
			continue
		end

		if v1.Name == "Template" then
			continue
		end

		local str2 = "UIComponent"
		if v1:IsA(str2) then
			continue
		end

		v1:Destroy()
	end

	for k2, v2 in var10:GetChildren() do
		if v2.Name == "TroopFrame" then
			continue
		end

		if v2.Name == "Template" then
			continue
		end

		local str3 = "UIComponent"
		if v2:IsA(str3) then
			continue
		end

		v2:Destroy()
	end

	local var14 = tbl1.CurrentTradeData
	local tbl3 = {}
	if var14 then
		local var15 = (var14.Player1.Player == var2 and var14.Player1 or var14.Player2).Items
		tbl3 = var15 or {}
	end

	for k3, v3 in var6, nil do
		local var16 = var4.Towers
		var16 = var16 and var4.Towers[v3.Name]
		if not var16 then
			continue
		end

		local var19 = tbl3[k3] ~= nil
		if not var19 then
			local var20 = str1 == "Towers"
			if not var20 then
				continue
			end
		end

		AddTradeItem(var19 and var10 or var9, v3.Name, k3, var16, "Tower", v3, function()
			if var19 then
				var12.Get("TradeRemoveItem"):InvokeServer(k3)
				return
			end

			var12.Get("TradeAddItem"):InvokeServer(k3, "Tower")
		end)

	end

	for k4, v4 in var7, nil do
		local var23 = v4.Type or "Item"
		local var24 = v4.Name
		local var25
		if var23 == "Tower" then
			var25 = var4.Towers
			if var25 then
				var25 = var4.Towers[var24]
			end
		else
			var25 = var4.Ids
			var25 = var25 and (var4.Ids.Products and var4.Ids.Products[var24])
		end

		if not var25 then
			continue
		end

		var24 = tbl3[k4] ~= nil
		if not var24 then
			if str1 ~= "Items" then
				continue
			end
		end

		AddTradeItem(var24 and var10 or var9, v4.Name, k4, var25, var23, v4, function()
			if var24 then
				var12.Get("TradeRemoveItem"):InvokeServer(k4)
				return
			end

			var12.Get("TradeAddItem"):InvokeServer(k4, "Item")
		end)

	end
end

tbl1.ChatHandler = function(arg1)
	if not arg1 then
		return
	end

	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	local var5 = var4:WaitForChild("TradeChat")
	local var6 = var5:WaitForChild("Messages")
	local var7 = var6:WaitForChild("TheirMessage")
	local var8 = var6:WaitForChild("YourMessage")
	if #arg1 < tbl1.LastChatCount then
		for k1, v1 in var6:GetChildren() do
			if not v1:IsA("Frame") then
				continue
			end

			if v1.Name == "TheirMessage" then
				continue
			end

			if v1.Name == "YourMessage" then
				continue
			end

			v1:Destroy()
		end

		tbl1.LastChatCount = 0
	end

	for i1 = tbl1.LastChatCount + 1, #arg1 do
		local var9 = arg1[i1]
		local var10 = (var9.Player == var2 and var8 or var7):Clone()
		var10.Name = "ChatMessage_" .. i1
		var10.MessageFrame.MessageText.Text = var9.Message
		var10.MessageFrame.PlayerPFP.Image = var1:GetUserThumbnailAsync(var9.Player.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size60x60)
		var10.Visible = true
		var10.Parent = var6
		if var5.Visible then
			continue
		end

		local var11 = var4:WaitForChild("TradeFrame").TradeMenu.ToggleChat.UnreadMessages
		var11.Visible = true
		local var12 = tostring((tonumber(var11.Text) or 0) + 1)
		var11.Text = var12
	end

	tbl1.LastChatCount = #arg1
end

tbl1.OpponentTrade = function(_, arg2)
	if not arg2 then
		return
	end

	local var1 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade"):WaitForChild("TradeFrame"):WaitForChild("TradeMenu"):WaitForChild("PlayerItemsOffer"):WaitForChild("Items")
	for k1, v1 in var1:GetChildren() do
		local var5 = v1.Name
		if var5 == "TroopFrame" then
			continue
		end

		var5 = v1.Name
		if var5 == "Template" then
			continue
		end

		var5 = v1:IsA("UIComponent")
		if var5 then
			continue
		end

		v1:Destroy()
	end

	for k2, v2 in arg2.Player1.Player == var2 and arg2.Player2.Items or arg2.Player1.Items, nil do
		local var6 = v2.Type
		var6 = var6 or (v2.ItemType or "Item")
		local var8 = v2.Name
		local var9
		if var6 == "Tower" then
			var9 = var4.Towers
			if var9 then
				var9 = var4.Towers[var8]
			end
		else
			var9 = var4.Ids
			var9 = var9 and (var4.Ids.Products and var4.Ids.Products[var8])
		end

		if not var9 then
			continue
		end

		AddTradeItem(var1, v2.Name, k2, var9, var6, v2, nil)
	end
end

tbl1.UpdateApprovalUI = function(arg1)
	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	if not var4 or typeof(arg1) ~= "table" then
		return
	end

	local var5 = arg1.Player1.Accepted
	local var7 = var4:FindFirstChild("InventoryFrame")
	local var8 = var4:FindFirstChild("TradeChat")
	local var9 = var4:WaitForChild("TradeFrame").TradeMenu:FindFirstChild("ToggleChat")
	local var10 = arg1.Player1.Player == var2 and arg1.Player1 or arg1.Player2
	local var11 = arg1.Player1.Player == var2 and arg1.Player2 or arg1.Player1
	var5 = var5 and arg1.Player2.Accepted
	if var7 then
		var7.Visible = not var5
	end

	local var12 = var4:WaitForChild("TradeFrame").TradeActions.Accept
	if var12:FindFirstChild("TextLabel") then
		if arg1.Locked then
			var12.TextLabel.Text = "Cancel"
		elseif var5 then
			local var13 = var12.TextLabel
			var13.Text = if var10.Confirmed then "Cancel" else "Confirm"
		else
			local var14 = var12.TextLabel
			var14.Text = if var10.Accepted then "Cancel" else "Accept"
		end
	end

	if var8 then
		local var15 = not var5
		var15 = var15 and var8.Visible
		var8.Visible = var15
	end

	if var9 then
		var9.Visible = not var5
	end

	local var18 = Color3.fromRGB(21, 255, 0)
	local var19 = Color3.fromRGB(0, 77, 129)
	if var5 then
		local var20 = var4:WaitForChild("TradeFrame").TradeMenu.YourItemsOffer.UIStroke
		var20.Color = var10.Confirmed and var18 or var19
		var20 = var4:WaitForChild("TradeFrame").TradeMenu.PlayerItemsOffer.UIStroke
		var20.Color = var11.Confirmed and var18 or var19
		return
	end

	local var21 = var4:WaitForChild("TradeFrame").TradeMenu.YourItemsOffer.UIStroke
	var21.Color = var10.Accepted and var18 or var19
	var21 = var4:WaitForChild("TradeFrame").TradeMenu.PlayerItemsOffer.UIStroke
	var21.Color = var11.Accepted and var18 or var19
end

tbl1.CheckAllReady = function(arg1)
	local var2 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	if not var2 then
		return
	end

	if arg1.Locked and (arg1.Player1.Accepted and (arg1.Player2.Accepted and (arg1.Player1.Confirmed and arg1.Player2.Confirmed))) then
		tbl1._checkReadyRunning = false
		task.wait(0.15)
		tbl1._checkReadyRunning = true
		local var4 = var2:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
		var4.Visible = true
		var4 = 5
		while true do
			if 0 >= var4 then
				break
			end

			if not tbl1._checkReadyRunning then
				break
			end

			local var6 = tbl1.CurrentTradeData
			if not var6 or (not var6.Locked or (not var6.Player1.Accepted or (not var6.Player2.Accepted or (not var6.Player1.Confirmed or (not var6.Player2.Confirmed))))) then
				local var8 = var2:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
				var8.Visible = false
				tbl1._checkReadyRunning = false
				return
			end

			var4 = var4 - 0.1
			local var10 = var2:WaitForChild("TradeFrame").TradeMenu.TradeCountdown.Timer
			var10.Text = string.format("%.1f", (math.max(0, var4)))
			task.wait(0.1)
		end

		if not (tbl1._checkReadyRunning and (tbl1.CurrentTradeData and (tbl1.CurrentTradeData.Locked and (tbl1.CurrentTradeData.Player1.Confirmed and tbl1.CurrentTradeData.Player2.Confirmed)))) then
			return
		end

		if not (tbl1.CurrentTradeData and (tbl1.CurrentTradeData.Locked and (tbl1.CurrentTradeData.Player1.Confirmed and tbl1.CurrentTradeData.Player2.Confirmed))) then
			return
		end

		if not (tbl1.CurrentTradeData.Locked and (tbl1.CurrentTradeData.Player1.Confirmed and tbl1.CurrentTradeData.Player2.Confirmed)) then
			return
		end

		if not (tbl1.CurrentTradeData.Player1.Confirmed and tbl1.CurrentTradeData.Player2.Confirmed) then
			return
		end

		if not tbl1.CurrentTradeData.Player2.Confirmed then
			return
		end

		var2.Visible = false
		local var11 = var2:WaitForChild("TradeFrame").TradeMenu.YourItemsOffer.UIStroke
		var11.Color = Color3.fromRGB(255, 255, 255)
		var11 = var2:WaitForChild("TradeFrame").TradeMenu.PlayerItemsOffer.UIStroke
		var11.Color = Color3.fromRGB(255, 255, 255)
		var11 = var2:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
		var11.Visible = false
		var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 0, false)
		tbl1._checkReadyRunning = false
		return
	end

	tbl1._checkReadyRunning = false
	local var12 = var2:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
	var12.Visible = false
end

tbl1.TradeHandle = function(arg1, arg2)
	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("TradeRequests")
	if not var4 or (not var5) then
		return
	end

	if not arg1 then
		var4.Visible = false
		var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 0, false)
		return
	end

	var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 24, false)
	var5.Visible = false
	local var6 = var3:WaitForChild("Main"):WaitForChild("Hider")
	var6.Visible = true
	var6 = var4:WaitForChild("TradeFrame").OtherPlayer.PlayerDisplay
	var6.Text = arg1.DisplayName
	var6 = var4:WaitForChild("TradeFrame").OtherPlayer.PlayerUser
	var6.Text = "@" .. arg1.Name
	var6 = var4:WaitForChild("TradeFrame").OtherPlayer.PlayerPFP
	var6.Image = ("https://www.roblox.com/headshot-thumbnail/image?userId=%*&width=420&height=420&format=png"):format(arg1.UserId)
	var6 = var4:WaitForChild("TradeFrame").OtherPlayer
	var6.Visible = true
	var6 = var4:WaitForChild("TradeFrame").TradeActions
	var6.Visible = true
	var6 = var4:WaitForChild("TradeFrame").ThisPlayer
	var6.Visible = true
	var4.TradeChat.Visible = false
	var6 = var4:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
	var6.Visible = false
	var6 = var4:WaitForChild("TradeFrame").TradeMenu.TradeProcessing
	var6.Visible = false
	var6 = var4:WaitForChild("TradeFrame").TradeActions.Accept.TextLabel
	var6.Text = "Accept"
	tbl1.UpdateApprovalUI(arg2)
	var6 = var4:WaitForChild("TradeFrame").TradeMenu.ToggleChat.UnreadMessages
	var6.Text = "0"
	var6 = var4:WaitForChild("TradeFrame").TradeMenu.ToggleChat.UnreadMessages
	var6.Visible = false
	tbl1.LastChatCount = 0
	for k1, v1 in var4:WaitForChild("TradeChat"):WaitForChild("Messages"):GetChildren() do
		if not v1:IsA("Frame") then
			continue
		end

		if v1.Name == "YourMessage" then
			continue
		end

		if v1.Name == "TheirMessage" then
			continue
		end

		v1:Destroy()
	end

	var4.Visible = true
	task.spawn(tbl1.OpponentTrade, arg1, arg2)
	task.spawn(tbl1.OfferTrade)
end

local var13 = shared.Modules.BigNotify
local str2 = "Trades"
tbl1.Start = function()
	while not var11 or (not var6) or (not var7) or (not var13) do
		task.wait()
		var11 = shared.Modules.Replication
		var6 = shared.Modules.InfoFrame
		var7 = shared.Modules.TweenButtons
		var13 = shared.Modules.BigNotify
	end

	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
	local var5 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("TradeRequests"):WaitForChild("RequestsFrame")
	var4.Visible = false
	var4.TradeChat.Visible = false
	local var8 = var4:WaitForChild("TradeChat")
	local var14 = var8:WaitForChild("Messages"):WaitForChild("TheirMessage")
	var14.Visible = false
	var14 = var8:WaitForChild("Messages"):WaitForChild("YourMessage")
	var14.Visible = false
	var5:WaitForChild("HistoryButton").Activated:Connect(function()
		if str2 == "Trades" then
			str2 = "History"
			tbl1.RefreshList()
			return
		end

		str2 = "Trades"
		tbl1.RefreshList()
	end)

	var1.PlayerAdded:Connect(function()
		if str2 == "Trades" then
			tbl1.RefreshList()
		end
	end)

	var1.PlayerRemoving:Connect(function()
		tbl1.RefreshList()
	end)

	tbl1.RefreshList()
	var12.Get("TradeSendRequest").OnClientEvent:Connect(function(arg1, _)
		local var3 = var13.Show(arg1.Name .. " sent you a trade request!", "YesNo")
		if var3 == "YesButton" then
			local var5 = var12.Get("TradeAcceptRequest"):InvokeServer(arg1)
			if var5 == "IN_TRADE" then
				var13.Show("Player is already in a trade!")
				return
			end

			if var5 ~= "NO_REQUEST" then
				return
			end

			var13.Show("Trade request expired.")
			return
		end

		if var3 == "NoButton" then
			var12.Get("TradeDeclineRequest"):FireServer(arg1)
		end
	end)

	var14 = var12.Get("TradeAcceptRequest")
	var14.OnClientInvoke = function(arg1, arg2)
		tbl1.TradeHandle(arg1, arg2)
	end

	var14 = var12.Get("TradeAddItem")
	var14.OnClientInvoke = function(arg1)
		tbl1.CurrentTradeData = arg1
		tbl1.OfferTrade()
		tbl1.UpdateApprovalUI(arg1)
		tbl1.OpponentTrade(arg1.Player1.Player == var2 and arg1.Player2.Player or arg1.Player1.Player, arg1)
		return true
	end

	var14 = var12.Get("TradeRemoveItem")
	var14.OnClientInvoke = function(arg1)
		tbl1.CurrentTradeData = arg1
		tbl1.OfferTrade()
		tbl1.UpdateApprovalUI(arg1)
		tbl1.OpponentTrade(arg1.Player1.Player == var2 and arg1.Player2.Player or arg1.Player1.Player, arg1)
		return true
	end

	var12.Get("TradeDecline").OnClientEvent:Connect(function(arg1)
		tbl1.CurrentTradeData = nil
		tbl1._checkReadyRunning = false
		var4.Visible = false
		local var1 = var3:WaitForChild("Main"):WaitForChild("Hider")
		var1.Visible = false
		var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 0, false)
		var13.Show("Your Trade with " .. (arg1.Player1.Player == var2 and arg1.Player2.Player or arg1.Player1.Player).Name .. " has been cancelled.")
	end)

	var12.Get("TradeAccept").OnClientEvent:Connect(function(arg1)
		if typeof(arg1) == "boolean" then
			if arg1 == true then
				tbl1.CurrentTradeData = nil
				tbl1._checkReadyRunning = false
				local var1 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade")
				var1.Visible = false
				local var4 = var1:WaitForChild("TradeFrame").TradeMenu.YourItemsOffer.UIStroke
				var4.Color = Color3.fromRGB(0, 0, 0)
				var4 = var1:WaitForChild("TradeFrame").TradeMenu.PlayerItemsOffer.UIStroke
				var4.Color = Color3.fromRGB(0, 0, 0)
				var4 = var1:WaitForChild("TradeFrame").TradeMenu.TradeCountdown
				var4.Visible = false
				var4 = var1:WaitForChild("TradeFrame").TradeMenu.TradeProcessing
				var4.Visible = false
				var4 = var3:WaitForChild("Main"):WaitForChild("Hider")
				var4.Visible = false
				var7.Tween(var9.Blur, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), "Size", 0, false)
				var13.Show("This trade has successfully processed!")
			end

			return
		end

		if typeof(arg1) ~= "table" then
			return
		end

		tbl1.CurrentTradeData = arg1
		tbl1.OfferTrade()
		tbl1.OpponentTrade(arg1.Player1.Player == var2 and arg1.Player2.Player or arg1.Player1.Player, arg1)
		tbl1.UpdateApprovalUI(arg1)
		tbl1.CheckAllReady(arg1)
	end)

	var12.Get("TradeChat").OnClientEvent:Connect(function(arg1)
		tbl1.ChatHandler(arg1)
	end)

	var4:WaitForChild("TradeFrame"):WaitForChild("TradeActions"):WaitForChild("Decline").Activated:Connect(function()
		var12.Get("TradeDecline"):FireServer()
	end)

	var4:WaitForChild("TradeFrame"):WaitForChild("TradeActions"):WaitForChild("Accept").Activated:Connect(function()
		var12.Get("TradeAccept"):FireServer()
	end)

	var14 = var4:WaitForChild("TradeChat")
	local var15 = var14:WaitForChild("BottomBar"):WaitForChild("MessageBar"):WaitForChild("InputMessage")
	var14:WaitForChild("BottomBar"):WaitForChild("SendMessage"):WaitForChild("Button").Activated:Connect(function()
		if var15.Text ~= "" then
			var12.Get("TradeChat"):FireServer(var15.Text)
			var15.Text = ""
		end
	end)

	var15.FocusLost:Connect(function(arg1)
		if arg1 and var15.Text ~= "" then
			var12.Get("TradeChat"):FireServer(var15.Text)
			var15.Text = ""
		end
	end)

	var4:WaitForChild("TradeFrame"):WaitForChild("TradeMenu"):WaitForChild("ToggleChat"):WaitForChild("ToggleButton").Activated:Connect(function()
		local var1 = var4:WaitForChild("TradeChat")
		var1.Visible = not var4:WaitForChild("TradeChat").Visible
		if var4:WaitForChild("TradeChat").Visible then
			var1 = var4:WaitForChild("TradeFrame"):WaitForChild("TradeMenu"):WaitForChild("ToggleChat"):WaitForChild("UnreadMessages")
			var1.Text = "0"
			var1 = var4:WaitForChild("TradeFrame"):WaitForChild("TradeMenu"):WaitForChild("ToggleChat"):WaitForChild("UnreadMessages")
			var1.Visible = false
		end
	end)

	for k1, v1 in var4:WaitForChild("InventoryFrame"):WaitForChild("Filters"):GetChildren() do
		if not v1:IsA("TextButton") then
			continue
		end

		v1.Activated:Connect(function()
			if str1 == v1.Name then
				return
			end

			str1 = v1.Name
			for k1, v2 in var4:WaitForChild("InventoryFrame"):WaitForChild("Filters"):GetChildren() do
				if not v2:IsA("TextButton") then
					continue
				end

				if v2.Name == str1 then
					continue
				end

				var10:Create(v2.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), { Scale = 1 }):Play()
			end

			tbl1.OfferTrade()
			var10:Create(v1.UIScale, TweenInfo.new(0.05, Enum.EasingStyle.Sine, Enum.EasingDirection.In), { Scale = 1.15 }):Play()
		end)

	end
end

local function formatTimeAgo(arg1)
	local var2 = os.time() - arg1
	if var2 < 60 then
		return var2 .. " sec"
	end

	if var2 < 3600 then
		return math.floor(var2 / 60) .. " min"
	end

	if var2 < 86400 then
		return math.floor(var2 / 3600) .. " hour"
	end

	if var2 < 2592000 then
		return math.floor(var2 / 86400) .. " day"
	end

	if var2 < 31104000 then
		return math.floor(var2 / 2592000) .. " month"
	end

	return math.floor(var2 / 31104000) .. " year"
end

tbl1.RefreshList = function()
	local var4 = var3:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("TradeRequests"):WaitForChild("RequestsFrame")
	local var5 = var4:WaitForChild("List"):WaitForChild("ScrollingFrame")
	local var6 = var5:WaitForChild("PlayerHolder")
	for k1, v1 in var5:GetChildren() do
		local str1 = "Frame"
		local var7 = v1:IsA(str1)
		if not var7 then
			continue
		end

		var7 = v1.Name
		if var7 == "PlayerHolder" then
			continue
		end

		v1:Destroy()
	end

	if tbl1._refreshListConnection then
		tbl1._refreshListConnection:Disconnect()
		tbl1._refreshListConnection = nil
	end

	local var8
	if str2 == "Trades" then
		var4.List.NoPlayers.Text = "There's looks like no players on server :("
		var4.TextLabel.Text = "Trading"
		local bool1 = false
		for k2, v2 in var1:GetPlayers() do
			if v2 == var2 then
				continue
			end

			local var9 = var6:Clone()
			var9.Name = v2.Name
			var9.PlayerFrame.ProfilePic.Image = ("https://www.roblox.com/headshot-thumbnail/image?userId=%*&width=420&height=420&format=png"):format(v2.UserId)
			var9.PlayerFrame.PlayerInfo.PlayerUsername.Text = "@" .. v2.Name
			var9.PlayerFrame.PlayerInfo.PlayerDisplayName.Text = v2.DisplayName
			var9.PlayerFrame.PossibleButtons.EnabledOptions.Trade.Visible = true
			var9.PlayerFrame.PossibleButtons.EnabledOptions.Sent.Visible = false
			var9.PlayerFrame.PossibleButtons.EnabledOptions.History.Visible = false
			var9.Visible = true
			var9.Parent = var5
			var9.PlayerFrame.PossibleButtons.EnabledOptions.Trade.Activated:Connect(function()
				var9.PlayerFrame.PossibleButtons.EnabledOptions.Trade.Visible = false
				var9.PlayerFrame.PossibleButtons.EnabledOptions.Sent.Visible = true
				var12.Get("TradeSendRequest"):FireServer(v2)
				task.delay(5, function()
					if var9 and var9.Parent then
						var9.PlayerFrame.PossibleButtons.EnabledOptions.Trade.Visible = true
						var9.PlayerFrame.PossibleButtons.EnabledOptions.Sent.Visible = false
					end
				end)
			end)

			bool1 = true
		end

		var4.List.NoPlayers.Visible = not bool1
		return
	end

	if str2 == "History" then
		local var13 = var11.GetCurrentReplica()
		var4.List.NoPlayers.Text = "There's looks like no history :("
		var4.TextLabel.Text = "Trading History"
		local var14 = var13 and var13.Data.TradeHistory or {}
		local var15 = 0 < (#var14)
		for k3, v3 in var14, nil do
			local var16 = var6:Clone()
			var16.Name = v3.Name or "Unknown"
			var16.PlayerFrame.ProfilePic.Image = ("https://www.roblox.com/headshot-thumbnail/image?userId=%*&width=420&height=420&format=png"):format(v3.UserId or 0)
			var16.PlayerFrame.PossibleButtons.EnabledOptions.Trade.Visible = false
			var16.PlayerFrame.PossibleButtons.EnabledOptions.Sent.Visible = false
			var16.PlayerFrame.PossibleButtons.EnabledOptions.History.Visible = true
			local var17 = v3.Timestamp
			local var18 = formatTimeAgo(var17 or os.time())
			var16.PlayerFrame.PlayerInfo.PlayerDisplayName.Text = v3.Name or "Unknown"
			var16.PlayerFrame.PlayerInfo.PlayerUsername.Text = "(" .. var18 .. ")"
			var16.Visible = true
			var16.Parent = var5
			var16.PlayerFrame.PossibleButtons.EnabledOptions.History.Activated:Connect(function()
				tbl1.ShowHistoryDetails(v3)
			end)

		end

		var4.List.NoPlayers.Visible = not var15
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.UI.Admin [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = shared.Modules.Config
local var3 = shared.Modules.TweenButtons
local var4 = var1:WaitForChild("PlayerGui")
local var5 = nil
local var6 = game:GetService("ReplicatedStorage").Assets.RaritiesGradients
local var7 = shared.Modules.Network
local var8 = game:GetService("UserInputService")
return { Start = function()
	while not var2 do
		task.wait()
		var2 = shared.Modules.Config
	end

	while not var3 do
		task.wait()
		var3 = shared.Modules.TweenButtons
	end

	if 254 <= var1:GetRankInGroup(game.CreatorId) then
		local var13 = var4:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Admin"):WaitForChild("AdminGuiFrame")
		local var14 = var13:WaitForChild("List"):WaitForChild("ScrollingFrame")
		local var15 = var13:WaitForChild("SelectedFrame")
		local var16 = var15:WaitForChild("AmountFrame")
		local var17 = var16:FindFirstChildOfClass("TextBox")
		local var18 = var14:WaitForChild("TroopFrame")
		local var19 = var15:WaitForChild("SelectedTroop")
		local var20 = var15:WaitForChild("Title")
		local var21 = var15:WaitForChild("Buttons"):WaitForChild("GiveButton")
		var17 = var17 or var16:FindFirstChild("TextBox")
		var18.Visible = false
		local function selectTroop(arg1, arg2)
			var5 = arg1
			var20.Text = arg1
			if var19:FindFirstChild("TroopsFrame") then
				local var2 = var19.TroopsFrame:FindFirstChild("TroopIcon")
				if var2 and (arg2 and arg2.Icon) then
					var2.Image = arg2.Icon
				end

				local var4 = var19.TroopsFrame.Background:FindFirstChildWhichIsA("UIGradient")
				if var4 and var4.Name ~= "UIGradient" then
					var4:Destroy()
				end

				if var6:FindFirstChild(arg2.Rarity) then
					local var7 = var6:FindFirstChild(arg2.Rarity):Clone()
					var7.Parent = var19.TroopsFrame.Background
				end

				local var9 = var19.TroopsFrame:FindFirstChild("Price")
				if var9 then
					local var10 = arg2 and (arg2.Upgrades and (arg2.Upgrades[1] and (arg2.Upgrades[1].Price and ("$%*"):format(arg2.Upgrades[1].Price)))) or ""
					var9.Text = var10
				end
			end
		end

		for k1, v1 in var2.Towers, nil do
			local var22 = var18:Clone()
			var22.Name = k1
			var22.Visible = true
			var22.Parent = var14
			var22.LayoutOrder = if k1 == var2.GameSettings.StarterTower then 99999999 else -var2.GameSettings.RarityOrder[v1.Rarity] or 0
			local var24 = var22:WaitForChild("TroopsFrame"):FindFirstChild("Price")
			if var24 then
				local var25 = v1 and (v1.Upgrades and (v1.Upgrades[1] and (v1.Upgrades[1].Price and ("$%*"):format(v1.Upgrades[1].Price)))) or ""
				var24.Text = var25
			end

			local var27 = var22:WaitForChild("TroopsFrame").Background:FindFirstChildWhichIsA("UIGradient")
			if var27 and var27.Name ~= "UIGradient" then
				var27:Destroy()
			end

			if var6:FindFirstChild(v1.Rarity) then
				local var28 = var6:FindFirstChild(v1.Rarity):Clone()
				var28.Parent = var22:WaitForChild("TroopsFrame").Background
			end

			local var30 = var22:WaitForChild("TroopsFrame"):FindFirstChild("TroopIcon")
			if var30 then
				var30.Image = v1.Icon
			end

			var22:WaitForChild("TroopsFrame"):FindFirstChild("InteractiveButton").Activated:Connect(function()
				selectTroop(k1, v1)
			end)

		end

		var21.MouseButton1Click:Connect(function()
			if not var5 then
				return
			end

			local num1 = 1
			if var17 and tonumber(var17.Text) then
				num1 = tonumber(var17.Text)
			end

			var7.Get("Give"):FireServer(var1.Name, var5, num1, false)
		end)

		var8.InputBegan:Connect(function(arg1, arg2)
			if arg2 then
				return
			end

			if arg1.KeyCode == Enum.KeyCode.F2 then
				var3.OnButtonClick("Admin")
			end
		end)

	end
end }

--- ReplicatedStorage.ModuleLoader.Client.InfoFrame [ModuleScript]
-- y u r i

game:GetService("TweenService")
local var1 = game:GetService("ReplicatedStorage"):WaitForChild("Assets")
local var2 = game:GetService("UserInputService")
local var3 = workspace.CurrentCamera
local var4 = shared.Modules.ExistClient
local var5 = shared.Modules.Config
local var6 = var1:WaitForChild("RaritiesGradients")
local var7 = shared.Modules.FormatModule
local var8 = var1:WaitForChild("UI"):WaitForChild("Tag")
local var9 = game:GetService("RunService")
local var10 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local var11 = var2:GetMouseLocation()
local var12 = nil
local var13 = nil
local bool1 = false
local var14 = Vector2.zero
local var15 = Vector2.zero
local num1 = 0
local tbl1 = { LoadInfoUI = function(arg1, arg2)
	var4 = shared.Modules.ExistClient
	local var2 = var5.Towers[arg1.Name]
	local var3 = var4.GetExist(arg1.Name)
	if not var2 then
		warn("[InfoFrame] Tower config not found or tower is not exists")
		return
	end

	if type(var2) ~= "table" then
		return
	end

	local var9 = var2.Rarity
	local var10 = var6[var9]:Clone()
	local var11 = var6[var9]:Clone()
	arg2.Items.ItemName.Text = arg1.Name
	arg2.Items.ItemRarity.Rarity.Text = var9
	local var12 = var2.Upgrades[1]
	local var13 = var2.Upgrades[#var2.Upgrades]
	if arg2.Items.ItemRarity.Rarity:FindFirstChildOfClass("UIGradient") then
		arg2.Items.ItemRarity.Rarity:FindFirstChildOfClass("UIGradient"):Destroy()
	end

	if arg2.Items.ItemRarity.Rarity.UIStroke:FindFirstChildOfClass("UIGradient") then
		arg2.Items.ItemRarity.Rarity.UIStroke:FindFirstChildOfClass("UIGradient"):Destroy()
	end

	if var9 == "Uncommon" or (var9 == "Legendary" or var9 == "Exclusive") then
		arg2.Items.ItemRarity.Size = UDim2.new(0.701, 0, 0.064, 0)
	elseif var9 == "Rare" then
		arg2.Items.ItemRarity.Size = UDim2.new(0.386, 0, 0.064, 0)
	else
		arg2.Items.ItemRarity.Size = UDim2.new(0.402, 0, 0.064, 0)
	end

	arg2.Items.ItemExist.Text = ("\240\159\146\142 %* Exists"):format((var7.FormatCompact(var3)))
	var11.Parent = arg2.Items.ItemRarity.Rarity
	var10.Parent = arg2.Items.ItemRarity.Rarity.UIStroke
	local var15 = arg2.Items
	if var15 then
		for k1, v1 in ipairs(var15:GetChildren()) do
			if not v1:IsA("Frame") then
				continue
			end

			if v1.Name ~= "Tag" then
				continue
			end

			v1:Destroy()
		end

		if var2.Tags then
			for k2, v2 in pairs(var2.Tags) do
				local var16 = var8:Clone()
				var16.Name = "Tag"
				local var18 = var16:FindFirstChildOfClass("TextLabel")
				if var18 then
					var18.Text = k2
				end

				if v2.Color then
					local var20 = v2.Color
					local var22 = var16:FindFirstChildOfClass("TextLabel")
					local var23 = var20:Lerp(Color3.fromRGB(0, 0, 0), 0.3)
					if var22 then
						var22.TextColor3 = var20
					end

					local var25 = var16:FindFirstChildOfClass("UIStroke")
					if var25 then
						var25.Color = var23
					end
				end

				var16.Parent = var15
			end
		end
	end

	if var12 and (var12.Damage and 0 < var12.Damage) then
		arg2.Items.Damage.Visible = true
		local var26 = var13.Damage
		arg2.Items.Damage.Text = "Damage: " .. var12.Damage .. " -> " .. (var26 or var12.Damage)
	else
		arg2.Items.Damage.Visible = false
	end

	if var12 and (var12.Cooldown and 0 < var12.Cooldown) then
		arg2.Items.Cooldown.Visible = true
		local var27 = var13.Cooldown
		arg2.Items.Cooldown.Text = "Cooldown: " .. var12.Cooldown .. " -> " .. (var27 or var12.Cooldown)
	else
		arg2.Items.Cooldown.Visible = false
	end

	if var12 and (var12.Range and 0 < var12.Range) then
		arg2.Items.Range.Visible = true
		local var28 = var13.Range
		arg2.Items.Range.Text = "Range: " .. var12.Range .. " -> " .. (var28 or var12.Range)
	else
		arg2.Items.Range.Visible = false
	end

	if var12 then
		if var12.Damage then
			if var12.Cooldown then
				if 0 < var12.Cooldown then
					local var29 = math.floor(var12.Damage / var12.Cooldown * 10) / 10
					var29 = var29 or 0
				end
			end
		end
	end

	local num1 = 0
	if var13 then
		if var13.Damage then
			if var13.Cooldown then
				if 0 < var13.Cooldown then
					local var30 = math.floor(var13.Damage / var13.Cooldown * 10) / 10
					var30 = var30 or num1
				end
			end
		end
	end

	if 0 < num1 then
		arg2.Items.DPS.Visible = true
		arg2.Items.DPS.Text = "DPS: " .. num1 .. " -> " .. num1
		return
	end

	arg2.Items.DPS.Visible = false
end }

tbl1.MoveInfoUI = function(_, arg2)
	if not arg2 then
		if var13 then
			var13.Visible = false
		end

		return
	end

	local var4 = var10:FindFirstChild("Main") and var10:WaitForChild("Main"):FindFirstChild("InfoFrames") or var10:FindFirstChild("GameUI") and var10:WaitForChild("GameUI"):FindFirstChild("InfoFrames")
	if not var13 or (not var13.Parent) then
		var13 = var1:WaitForChild("HoverInfo"):Clone()
		var13.AnchorPoint = Vector2.new(0.5, 0.5)
		var13.Visible = true
		var13.Parent = var4
		local var5 = var2:GetMouseLocation()
		var14 = var5
		var15 = var5
	end

	var13.AnchorPoint = Vector2.new(0.5, 0.5)
	var13.Visible = true
	local var6 = var13.AbsoluteSize
	local var7 = var2:GetMouseLocation()
	local var8 = var3.ViewportSize
	local var16 = var8.X < var7.X + 15 + var6.X
	bool1 = var16
	local var19 = var6 / 2
	local var20 = var8.Y < var7.Y + 15 + var6.Y
	local var21 = nil
	var21 = if var16 then var7.X - 15 - var19.X else var7.X + 15 + var19.X
	local var23 = nil
	var15 = Vector2.new(math.clamp(var21, var19.X, var8.X - var19.X), (math.clamp(if var20 then var7.Y - 15 - var19.Y else var7.Y + 15 + var19.Y, var19.Y, var8.Y - var19.Y)))
	if var13:GetAttribute("LoadedTower") ~= arg2.Name then
		var13:SetAttribute("LoadedTower", arg2.Name)
		tbl1.LoadInfoUI(arg2, var13)
	end

	if var12 then
		return
	end

	var12 = var9.RenderStepped:Connect(function(arg1)
		if var13 then
			if not var13.Parent or (not var13.Visible) then
				if var12 then
					var12:Disconnect()
					var12 = nil
				end

				return
			end
		end

		local var1 = var2:GetMouseLocation()
		local var3 = var1 - var11
		var11 = var1
		local var4 = math.clamp(var3.X * 0.2 * (if bool1 then 1 else -1), -30, 30)
		local var5 = var14:Lerp(var15, (math.clamp(arg1 * 15, 0, 1)))
		var14 = var5
		var5 = num1 + (var4 - num1) * math.clamp(arg1 * 15, 0, 1)
		num1 = var5
		var13.Position = UDim2.new(0, var14.X, 0, var14.Y)
		var13.Rotation = num1
	end)
end

tbl1.HideInfoUI = function(_)
	if var13 then
		var13.Visible = false
		if var12 then
			var12:Disconnect()
			var12 = nil
		end
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.ExistClient [ModuleScript]
-- y u r i

game:GetService("Players")
local tbl1 = {}
local var1 = game:GetService("RunService"):IsClient()
local var2 = require(game:GetService("ReplicatedStorage").ReplicaShared.Signal).New()
local var3 = shared.Modules.Replication
local var4 = shared.Modules.Network
local bool1 = false
return {
	GetExist = function(arg1)
		local var1
		if not arg1 or type(arg1) ~= "string" then
			var1 = false
		else
			var1 = if not shared.Modules.Config.Towers[arg1] then false else true
		end

		if not var1 then
			return 0
		end

		return tbl1[arg1] or 0
	end,
	GetAllExists = function()
		local var1 = tbl1
		return table.clone(var1)
	end,
	OnExistChanged = function(arg1)
		local var1 = arg1
		return var2:Connect(var1)
	end,
	Start = function()
		if not var1 then
			warn("[Exist] Exist client module should only run on client")
			return
		end

		while not var3 do
			task.wait()
			var3 = shared.Modules.Replication
		end

		var4.Get("GetExist")
		local var5 = var4.Get("UpdateExist")
		local var6 = var4.Get("GetAllExists")
		while not var5 do
			task.wait(1)
			var4.Get("GetExist")
			var5 = var4.Get("UpdateExist")
			var6 = var4.Get("GetAllExists")
		end

		var5.OnClientEvent:Connect(function(arg1, arg2)
			if arg1 == "INIT" and type(arg2) == "table" then
				tbl1 = arg2
				bool1 = true
				return
			end

			local var1
			if not arg1 or type(arg1) ~= "string" then
				var1 = false
			else
				var1 = if not shared.Modules.Config.Towers[arg1] then false else true
			end

			if var1 and type(arg2) == "number" then
				tbl1[arg1] = arg2
				var2:Fire(arg1, arg2)
			end
		end)

		task.spawn(function()
			task.wait(1)
			local var1 = var6:InvokeServer()
			if not bool1 and (var6 and type(var1) == "table") then
				tbl1 = var1
				bool1 = true
				warn("[Exist] Loaded exists via request")
			end
		end)
	end,
}

--- ReplicatedStorage.ModuleLoader.Client.Elevators [ModuleScript]
-- y u r i

game:GetService("TweenService")
local var1 = game:GetService("Players").LocalPlayer
local var2 = shared.Modules.Network
local var3 = var1:WaitForChild("PlayerGui")
local tbl1 = {}
local var4 = nil
local bool1 = false
local function UpdateUI()
	local var2 = var4
	local var5
	if not var2 then
		var5 = nil
	else
		local var7 = workspace:FindFirstChild("Elevators")
		var5 = if not var7 then nil else var7:FindFirstChild(var2)
	end

	if not var5 then
		var2 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var2.Visible == false then
			return
		end

		var2.Visible = false
		return
	end

	var2 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
	var2.PlayerAmount.PlayerAmount.Text = ("%*/%*"):format(var5:GetAttribute("Players") or 0, var5:GetAttribute("MaxPlayers") or 5)
	var2.StartingIn.TimeLeft.Text = tostring(var5:GetAttribute("Time") or 0)
	var2.MapName.Text = tostring(var5:GetAttribute("Map") or 0)
	var2.ReadyButton.Visible = bool1
	local var8 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
	if var8.Visible == true then
		return
	end

	var8.Visible = true
end

local bool2 = false
local bool3 = false
local function WaitForRemote(arg1)
	local var1 = var2.Get(arg1)
	while not var1 do
		task.wait()
		var1 = var2.Get(arg1)
	end

	return var1
end

local function WatchElevator(arg1)
	for k1, v1 in ipairs(tbl1) do
		v1:Disconnect()
	end

	table.clear(tbl1)
	if not arg1 then
		return
	end

	local str1 = "Players"
	for k2, v2 in ipairs({ "Time", str1, "MaxPlayers", "Title" }) do
		local var1 = UpdateUI
		table.insert(tbl1, arg1:GetAttributeChangedSignal(v2):Connect(var1))
	end
end

local function GetElevatorModel(arg1)
	if not arg1 then
		return nil
	end

	local var2 = workspace:FindFirstChild("Elevators")
	if not var2 then
		return nil
	end

	local var3 = arg1
	return var2:FindFirstChild(var3)
end

local function UpdateVoterIcons(arg1)
	local var2 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame"):FindFirstChild("VotersFrame")
	if not var2 then
		return
	end

	local var5 = var2:FindFirstChild("Voter")
	if not var5 then
		return
	end

	var5.Visible = false
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("ImageLabel") or v1 == var5 then
			continue
		end

		v1:Destroy()
	end

	if arg1 then
		for k2, v2 in ipairs(arg1) do
			local var6 = var5:Clone()
			var6.Name = ("Voter_%*"):format(v2)
			var6.Visible = true
			var6.Parent = var2
			task.spawn(function()
				if var6 and var6.Parent then
					var6.Image = ("https://www.roblox.com/headshot-thumbnail/image?userId=%*&width=420&height=420&format=png"):format(v2)
				end
			end)

		end
	end
end

local var5 = shared.Modules.Replication
local var6 = game:GetService("RunService")
local function DetectElevator()
	local var3 = var1.Character
	local var5 = if not var3 then nil else var3:FindFirstChild("HumanoidRootPart")
	if not var5 then
		return nil
	end

	var3 = workspace:FindFirstChild("Elevators")
	if not var3 then
		return nil
	end

	local var6 = nil
	local num1 = math.huge
	for k1, v1 in ipairs(var3:GetChildren()) do
		if not v1:IsA("Model") then
			continue
		end

		local var7 = v1:FindFirstChild("Hitbox")
		var7 = var7 or v1:FindFirstChildWhichIsA("BasePart")
		if not var7 then
			continue
		end

		if not var7:IsA("BasePart") then
			continue
		end

		local var8 = var7.CFrame:PointToObjectSpace(var5.Position)
		local var9 = var7.Size * 0.5
		local bool2 = false
		if math.abs(var8.X) <= var9.X then
			bool2 = false
			if math.abs(var8.Y) <= var9.Y then
				bool2 = math.abs(var8.Z) <= var9.Z
			end
		end

		if not bool2 then
			continue
		end

		bool2 = (var7.Position - var5.Position).Magnitude
		if bool2 >= num1 then
			continue
		end

		var6 = v1.Name
		local var10 = bool2
	end

	return var6
end

local function IsInsideElevator(arg1)
	local var3 = var1.Character
	local var4 = if not var3 then nil else var3:FindFirstChild("HumanoidRootPart")
	if not arg1 then
		var3 = nil
	else
		local var6 = workspace:FindFirstChild("Elevators")
		var3 = if not var6 then nil else var6:FindFirstChild(arg1)
	end

	if not var4 or (not var3) then
		return false
	end

	local var7 = var3:FindFirstChild("Area")
	var7 = var7 or (var3:FindFirstChild("Hitbox") or var3:FindFirstChildWhichIsA("BasePart"))
	local var10 = var7
	if var10 then
		var10 = var7:IsA("BasePart")
		if var10 then
			local var12 = var7.CFrame:PointToObjectSpace(var4.Position)
			local var13 = var7.Size * 0.5
			var10 = false
			if math.abs(var12.X) <= var13.X then
				var10 = false
				if math.abs(var12.Y) <= var13.Y then
					var10 = math.abs(var12.Z) <= var13.Z
				end
			end
		end
	end

	return var10
end

return { Start = function()
	while not var5 do
		task.wait()
		var5 = shared.Modules.Replication
	end

	WaitForRemote("ElevatorEnter")
	WaitForRemote("ElevatorLeave")
	WaitForRemote("ElevatorStart")
	WaitForRemote("ElevatorPlayersUpdated").OnClientEvent:Connect(function(arg1)
		UpdateVoterIcons(arg1)
	end)

	WaitForRemote("ElevatorEntered").OnClientEvent:Connect(function(arg1, arg2)
		var4 = arg1
		bool1 = arg2 == true
		local var1 = arg1
		WatchElevator(GetElevatorModel(var1))
		UpdateUI()
	end)

	WaitForRemote("ElevatorLeft").OnClientEvent:Connect(function()
		var4 = nil
		bool1 = false
		for k1, v1 in ipairs(tbl1) do
			v1:Disconnect()
		end

		table.clear(tbl1)
		local var1 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var1.Visible ~= false then
			var1.Visible = false
		end

		UpdateVoterIcons(nil)
	end)

	WaitForRemote("ElevatorTeleporting").OnClientEvent:Connect(function()
		bool2 = true
		local var1 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var1.Visible ~= false then
			var1.Visible = false
		end

		task.delay(5, function()
			bool2 = false
		end)
	end)

	var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame").ReadyButton.Activated:Connect(function()
		if not var4 then
			return
		end

		WaitForRemote("ElevatorStart"):InvokeServer(var4)
	end)

	var1.CharacterAdded:Connect(function()
		var4 = nil
		bool1 = false
		for k1, v1 in ipairs(tbl1) do
			v1:Disconnect()
		end

		table.clear(tbl1)
		local var1 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var1.Visible ~= false then
			var1.Visible = false
		end

		UpdateVoterIcons(nil)
	end)

	local num1 = 0
	local var2 = nil
	local num2 = 0
	var6.RenderStepped:Connect(function(arg1)
		if bool2 or bool3 then
			return
		end

		local var1 = num1 + arg1
		num1 = var1
		if num1 < 0.08 then
			return
		end

		num1 = 0
		var1 = DetectElevator()
		if var4 then
			if IsInsideElevator(var4) then
				var1 = var4
			end
		end

		if var1 ~= var2 then
			var2 = var1
			num2 = 0
		else
			local var5 = num2 + 0.08
			num2 = var5
		end

		if not var4 then
			if var1 then
				if 0.18 <= num2 then
					local var6
					if not bool2 then
						if bool3 then
						else
		if var4 ~= var1 then
								bool3 = true
								local var7 = WaitForRemote("ElevatorEnter"):InvokeServer(var1)
								bool3 = false
								if var7 then
									var4 = var1
									var6 = var1
									WatchElevator(GetElevatorModel(var6))
									UpdateUI()
								end
							end
						end
					end
				else
					if var4 then
						if not var1 then
							if 0.18 <= num2 then
		if not not var4 then
									local var8 = var4
									var4 = nil
									bool1 = false
									for k1, v1 in ipairs(tbl1) do
										v1:Disconnect()
									end

									table.clear(tbl1)
									local var9 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var9.Visible ~= false then
										var9.Visible = false
									end

									UpdateVoterIcons(nil)
									WaitForRemote("ElevatorLeave"):InvokeServer(var8)
								end
							end
						end
					end
				end
			else
				if var4 then
					if not var1 then
						if 0.18 <= num2 then
		if not not var4 then
								local var10 = var4
								var4 = nil
								bool1 = false
								for k2, v2 in ipairs(tbl1) do
									v2:Disconnect()
								end

								table.clear(tbl1)
								local var11 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var11.Visible ~= false then
									var11.Visible = false
								end

								UpdateVoterIcons(nil)
								WaitForRemote("ElevatorLeave"):InvokeServer(var10)
							end
						end
					end
				end
			end
		else
			if var4 then
				if not var1 then
					if 0.18 <= num2 then
		if not not var4 then
							local var12 = var4
							var4 = nil
							bool1 = false
							for k3, v3 in ipairs(tbl1) do
								v3:Disconnect()
							end

							table.clear(tbl1)
							local var13 = var3:WaitForChild("ElevatorGui"):WaitForChild("QueueFrame")
		if var13.Visible ~= false then
								var13.Visible = false
							end

							UpdateVoterIcons(nil)
							WaitForRemote("ElevatorLeave"):InvokeServer(var12)
						end
					end
				end
			end
		end

		if var4 then
			UpdateUI()
		end
	end)
end }

--- ReplicatedStorage.ModuleLoader.Client.Animation [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
game:GetService("RunService")
local var1 = shared.Modules.Effects
local var2 = game:GetService("Players").LocalPlayer
return {
	Play = function(arg1, arg2, _, arg4, arg5, arg6, arg7)
		local var2 = arg1:FindFirstChildOfClass("Humanoid")
		var2 = var2 or arg1:FindFirstChildOfClass("AnimationController")
		local var3
		if not var2 then
			var3 = nil
		else
			local var5 = var2:FindFirstChildOfClass("Animator")
			if not var5 then
				var5 = Instance.new("Animator")
				var5.Parent = var2
			end

			var3 = var5
		end

		if not var3 then
			return
		end

		if arg2 == "Attack" then
			task.spawn(var1.ShowEffect, arg5, arg1, arg6, arg7)
		end

		local var7 = arg1:FindFirstChild("Animations")
		if not var7 then
			var2 = nil
		else
			local var9 = var7:FindFirstChild(arg2)
			if not var9 then
				var2 = nil
			else
				local var11 = var3:LoadAnimation(var9)
				var2 = if not var11 then nil else var11
			end
		end

		if not var2 then
			return
		end

		var2:Play()
		var7 = arg4
		var2.Priority = var7 or Enum.AnimationPriority.Action
		return var2
	end,
	Stop = function(arg1, arg2)
		local var1 = arg1:FindFirstChildOfClass("Humanoid")
		var1 = var1 or arg1:FindFirstChildOfClass("AnimationController")
		local var2
		if not var1 then
			var2 = nil
		else
			local var4 = var1:FindFirstChildOfClass("Animator")
			if not var4 then
				var4 = Instance.new("Animator")
				var4.Parent = var1
			end

			var2 = var4
		end

		if not var2 then
			return
		end

		var1 = var2:GetPlayingAnimationTracks()
		if #var1 == 0 then
			return
		end

		for k1, v1 in var1, nil do
			if not v1 then
				continue
			end

			if not v1.IsPlaying then
				continue
			end

			v1:Stop(arg2 or 0.1)
		end
	end,
	Init = function()
		while not var1 do
			task.wait()
			var1 = shared.Modules.Effects
		end
	end,
}

--- ReplicatedStorage.ModuleLoader.Client.ZoneClient [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
local var1 = shared.Modules.QuickZone
local var2 = shared.Modules.TweenButtons
local var3 = var1.Group
local var4 = game:GetService("CollectionService")
local var5 = var1.Zone
local var6 = var1.Observer
local var7 = game:GetService("Players").LocalPlayer.PlayerGui
return { Start = function()
	while not var2 do
		task.wait()
		var2 = shared.Modules.TweenButtons
	end

	local var1 = var3.localPlayer()
	while #var4:GetTagged("Zone") < 1 do
		task.wait()
	end

	for k1, v1 in var4:GetTagged("Zone") do
		local var7 = var6.new():subscribe(var1):attach((var5.fromPart(v1)))
		var7:onLocalPlayerEnter(function()
			var2.OnButtonClick(v1:GetAttribute("Zone"), true)
		end)

		var7:onLocalPlayerExit(function()
			var2.OnButtonClick(v1:GetAttribute("Zone"), false)
		end)

	end
end }

--- ReplicatedStorage.ModuleLoader.Client.TweenButtons [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
local var1 = shared.Modules.Replication
local var2 = game:GetService("TweenService")
local var3 = game:GetService("Lighting")
local var4 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local bool1 = false
local tbl1 = { Tween = function(arg1, arg2, arg3, arg4, arg5)
	while not var1 do
		task.wait()
		var1 = shared.Modules.Replication
	end

	local var3 = var2:Create(arg1, arg2, { [arg3] = arg4 })
	var3:Play()
	if arg5 then
		var3.Completed:Wait()
	end
end }

tbl1.OnButtonClick = function(arg1, arg2)
	if bool1 then
		return
	end

	local var1
	if arg1 == nil then
		for k1, v1 in var4.Main.Main:GetChildren() do
			var1 = v1:IsA("Frame")
			if not var1 then
				continue
			end

			var1 = v1.Visible
			if not var1 then
				continue
			end

			var1 = v1.Name
			if var1 == arg1 then
				continue
			end

			tbl1.Tween(var3.Blur, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Size", 0, false)
			v1.Visible = false
			var1 = var4.Main.Hider
			var1.Visible = false
			return
		end
	end

	local var5 = var4:WaitForChild("Main"):WaitForChild("Main"):FindFirstChild(arg1)
	if not var5 then
		return
	end

	if var4:WaitForChild("Main"):WaitForChild("Main"):WaitForChild("Trade").Visible then
		return
	end

	bool1 = true
	for k2, v2 in var4.Main.Main:GetChildren() do
		if not v2:IsA("Frame") then
			continue
		end

		if not v2.Visible then
			continue
		end

		if v2.Name == arg1 then
			continue
		end

		tbl1.Tween(var3.Blur, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Size", 0, false)
		v2.Visible = false
	end

	if var5.Visible and (not arg2) or arg2 == false then
		tbl1.Tween(var3.Blur, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Size", 0, false)
		var5.Visible = false
		var4.Main.Hider.Visible = false
		var4.HUD.Buttons.Visible = true
	else
		if arg2 == true or (not var5.Visible) then
			var5.Position = UDim2.new(0.5, 0, 0.485, 0)
			var5.Visible = true
			var4.Main.Hider.Visible = true
			tbl1.Tween(var3.Blur, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), "Size", 24, false)
			tbl1.Tween(var5, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), "Position", UDim2.new(0.5, 0, 0.5, 0), false)
		end
	end

	bool1 = false
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Client.Replication [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = nil
local var3 = var1.LocalPlayer
local var4 = nil
local var5 = shared.Modules.ReplicaClient
return {
	GetCurrentReplica = function()
		if not var2 or var2 and (not var2:IsActive()) then
			var2 = nil
			repeat
				task.wait(0.5)
				if var2 then
					if var2:IsActive() then
						break
					end
				end
			until var2:IsActive()
		end

		return var2
	end,
	Start = function()
		if not var3 then
			var3 = var1.LocalPlayer
			while not var3 do
				task.wait(0.5)
				var3 = var1:WaitForChild("LocalPlayer")
			end
		end

		if var4 then
			var4:Disconnect()
			var4 = nil
		end

		var2 = nil
		var5.RequestData()
		var4 = var5.OnNew("Replication", function(arg1)
			if not var3 or (not var3:IsA("Player")) then
				warn("[ReplicationManager] LocalPlayer is not valid")
				return
			end

			if arg1.Tags.UserId ~= var3.UserId then
				return
			end

			if arg1:IsActive() then
				var2 = arg1
			end
		end)
	end,
}

--- ReplicatedStorage.ModuleLoader.Client.StrokeScaler [ModuleScript]
-- y u r i

local var1 = Vector2.new(1616, 880)
local tbl1 = {}
local tbl2 = {}
local function registerWorldStroke(arg1, arg2)
	if not arg2:IsA("UIStroke") or tbl2[arg2] then
		return
	end

	local var1 = arg2:GetAttribute("OriginalThickness")
	var1 = var1 or arg2.Thickness
	arg2:SetAttribute("OriginalThickness", var1)
	tbl2[arg2] = { original = var1, gui = arg1 }
	arg2.AncestryChanged:Connect(function()
		if not arg2:IsDescendantOf(game) then
			tbl2[arg2] = nil
		end
	end)
end

local function updateScreenStrokes()
	local var2 = workspace.CurrentCamera
	local var3 = var2 and var2.ViewportSize or Vector2.new(1366, 768)
	local var4 = var1.X
	local var5 = math.min(var4, var1.Y)
	local var6 = math.min(var3.X, var3.Y) / var5
	for k1, v1 in pairs(tbl1) do
		if k1 and k1.Parent then
			k1.Thickness = v1 * var6
		else
			tbl1[k1] = nil
		end
	end
end

local function getGuiWorldPosition(arg1)
	local var1 = arg1.Adornee
	var1 = var1 or arg1:FindFirstAncestorWhichIsA("Model")
	if not var1 then
		return nil
	end

	if var1:IsA("BasePart") then
		return var1.Position
	end

	if var1:IsA("Model") then
		return var1:GetPivot().Position
	end

	if var1:IsA("Attachment") then
		return var1.WorldPosition
	end

	return nil
end

game:GetService("RunService").RenderStepped:Connect(function()
	updateScreenStrokes()
	local var2 = workspace.CurrentCamera
	if not var2 then
		return
	end

	for k1, v1 in pairs(tbl2) do
		local var4 = v1.gui
		if not k1 or (not k1.Parent or (not var4 or (not var4.Parent or (not var4.Enabled)))) then
			tbl2[k1] = nil
		else
			local var5 = getGuiWorldPosition(var4)
			if not var5 then
				continue
			end

			local var6 = var2:WorldToViewportPoint(var5).Z
			if var6 <= 0.1 then
				continue
			end

			local var8 = var4.DistanceLowerLimit or 0
			local var9 = var4.DistanceUpperLimit or 0
			local var10
			if 0 < var8 and var6 < var8 then
				var10 = false
			else
				var10 = if 0 < var9 and var9 < var6 then false else true
			end

			if not var10 then
				continue
			end

			k1.Thickness = math.clamp(v1.original * math.max(1, var6 / 10), v1.original, 0.2)
		end
	end
end)

workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
	updateScreenStrokes()
end)

local function registerScreenStroke(arg1)
	if not arg1:IsA("UIStroke") or tbl1[arg1] then
		return
	end

	local var1 = arg1:GetAttribute("OriginalThickness")
	var1 = var1 or arg1.Thickness
	arg1:SetAttribute("OriginalThickness", var1)
	tbl1[arg1] = var1
	arg1.AncestryChanged:Connect(function()
		if not arg1:IsDescendantOf(game) then
			tbl1[arg1] = nil
		end
	end)
end

local function registerWorldGui(arg1)
	local function addStroke(arg1)
		registerWorldStroke(arg1, arg1)
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		registerWorldStroke(arg1, v1)
	end

	arg1.DescendantAdded:Connect(addStroke)
end

return {
	TagScreenGui = function(arg1)
		if not arg1 then
			return
		end

		for k1, v1 in ipairs(arg1:GetDescendants()) do
			registerScreenStroke(v1)
		end

		arg1.DescendantAdded:Connect(registerScreenStroke)
		updateScreenStrokes()
	end,
	TagBillboardGui = function(arg1)
		if arg1 then
			registerWorldGui(arg1)
		end
	end,
	AutoTagAllBillboards = function(arg1)
		local var1 = arg1
		arg1 = var1 or workspace
		var1 = function(arg1)
			if arg1:IsA("BillboardGui") then
				registerWorldGui(arg1)
			end
		end

		for k1, v1 in ipairs(arg1:GetDescendants()) do
			if not v1:IsA("BillboardGui") then
				continue
			end

			registerWorldGui(v1)
		end

		arg1.DescendantAdded:Connect(var1)
	end,
}

--- ReplicatedStorage.ModuleLoader.Client.UIConfetti [ModuleScript]
-- y u r i

local num1 = 253
local num2 = 255
local num3 = 106
local var1 = script:WaitForChild("ConfettiShapes", 5)
local tbl1 = {
	Color3.fromRGB(168, 100, 253),
	Color3.fromRGB(41, 205, 255),
	Color3.fromRGB(120, 255, 68),
	Color3.fromRGB(255, 113, 141),
	Color3.fromRGB(num1, num2, num3),
}

local var2 = workspace.CurrentCamera
return { new = function(arg1)
	if not arg1 then
		return nil
	end

	local var3
	if not var1 then
		var3 = nil
	else
		local var4 = var1:GetChildren()
		var3 = if #var4 == 0 then nil else var4[math.random(#var4)]
	end

	if not var3 then
		return nil
	end

	local var5 = arg1.Gravity
	var5 = var5 or Vector2.new(0, 0.6)
	local tbl2 = { Gravity = var5 }
	var5 = arg1.Position
	var5 = var5 or UDim2.new(0.5, 0, 1, 0)
	tbl2.EmitterPosition = var5
	var5 = arg1.Force
	var5 = var5 or Vector2.new(0, -25)
	tbl2.EmitterPower = var5
	tbl2.Position = Vector2.new(0, 0)
	tbl2.Power = var5
	local var6 = arg1.Colors
	tbl2.Colors = var6 or tbl1
	tbl2.CurrentColor = tbl2.Colors[math.random(#tbl2.Colors)]
	var6 = var3:Clone()
	var6.ImageColor3 = tbl2.CurrentColor
	var6.Parent = arg1.Parent
	var6.Rotation = math.random(360)
	var6.Visible = false
	var6.ZIndex = 20
	tbl2.Label = var6
	tbl2.DefaultSize = 25
	tbl2.Size = 25
	tbl2.Side = -1
	tbl2.RotationSpeed = math.random(-10, 10)
	tbl2.OutOfBounds = false
	tbl2.Enabled = false
	tbl2.Cycles = 0
	tbl2.Toggle = function(arg1)
		local var1 = not arg1.Enabled
		arg1.Enabled = var1
	end

	tbl2.Update = function(arg1)
		if not arg1.Label then
			return
		end

		if arg1.Enabled and arg1.OutOfBounds then
			arg1.CurrentColor = arg1.Colors[math.random(#arg1.Colors)]
			arg1.Label.ImageColor3 = arg1.CurrentColor
			arg1.Position = Vector2.new(0, 0)
			arg1.Power = Vector2.new(arg1.EmitterPower.X + math.random(-8, 8), arg1.EmitterPower.Y + math.random(-5, 5))
			local var1 = arg1.Cycles + 1
			arg1.Cycles = var1
			arg1.OutOfBounds = false
		end

		if not arg1.Enabled and (arg1.OutOfBounds or arg1.Cycles == 0) then
			arg1.Label.Visible = false
			arg1.OutOfBounds = true
			return
		end

		arg1.Label.Visible = true
		local var3 = Vector2.new(arg1.Position.X + arg1.Power.X, arg1.Position.Y + arg1.Power.Y)
		local var4 = Vector2.new(arg1.Power.X * 0.96 + arg1.Gravity.X, arg1.Power.Y * 0.96 + arg1.Gravity.Y)
		arg1.Label.Position = UDim2.new(arg1.EmitterPosition.X.Scale, arg1.EmitterPosition.X.Offset + var3.X, arg1.EmitterPosition.Y.Scale, arg1.EmitterPosition.Y.Offset + var3.Y)
		local var5 = arg1.Label
		local var6 = var5.Rotation + arg1.RotationSpeed
		var5.Rotation = var6
		var6 = arg1.Label.AbsolutePosition
		var5 = var2.ViewportSize
		local bool2 = true
		if var5.Y + 60 >= var6.Y then
			bool2 = true
			if var6.X >= -100 then
				bool2 = var5.X + 100 < var6.X
			end
		end

		arg1.OutOfBounds = bool2
		arg1.Position = var3
		arg1.Power = var4
		if arg1.Size <= 0 then
			arg1.Side = 1
			arg1.Label.ImageColor3 = arg1.CurrentColor
		else
			if arg1.DefaultSize <= arg1.Size then
				arg1.Side = -1
				arg1.Label.ImageColor3 = Color3.new(arg1.CurrentColor.R * 0.8, arg1.CurrentColor.G * 0.8, arg1.CurrentColor.B * 0.8)
			end
		end

		local var7 = arg1.Size + arg1.Side * 2
		arg1.Size = var7
		arg1.Label.Size = UDim2.new(0, arg1.DefaultSize, 0, (math.clamp(arg1.Size, 0, arg1.DefaultSize)))
	end

	tbl2.Destroy = function(arg1)
		if arg1.Label then
			arg1.Label:Destroy()
		end

		table.clear(arg1)
	end

	return tbl2
end }

--- ReplicatedStorage.ModuleLoader.Client.MovingModels [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
game:GetService("UserInputService")
local var1 = game:GetService("Players").LocalPlayer
local function resetIKLook(arg1)
	local var3 = arg1:FindFirstChild("Head")
	local var4 = arg1:FindFirstChild("UpperTorso")
	if not var3 or (not var4) then
		return
	end

	local var7 = var3:FindFirstChild("Neck")
	local var8 = var4:FindFirstChild("Waist")
	if not var7 or (not var8) then
		return
	end

	local var10 = var7:GetAttribute("OriginalC0")
	local var11 = var8:GetAttribute("OriginalC0")
	if var10 then
		var7.C0 = var10
	end

	if var11 then
		var8.C0 = var11
	end
end

local function getBezierLength(arg1, arg2, arg3, arg4)
	arg4 = arg4 or 10
	local num1 = 0
	local var1 = arg1
	for i1 = 1, arg4 do
		local var2 = i1 / arg4
		local var3 = (1 - var2) ^ 2 * arg1 + 2 * (1 - var2) * var2 * arg2 + var2 ^ 2 * arg3
		num1 = num1 + (var3 - var1).Magnitude
		local var4 = var3
	end

	return num1
end

local var2 = game:GetService("RunService")
local function makeModelFall(arg1)
	arg1:SetAttribute("IsFalling", true)
	resetIKLook(arg1)
	local var1 = arg1:FindFirstChildOfClass("Humanoid")
	var1 = var1 or arg1:FindFirstChildOfClass("AnimationController")
	local var2
	if not var1 then
		var2 = nil
	else
		local var4 = var1:FindFirstChildOfClass("Animator")
		if not var4 then
			var4 = Instance.new("Animator")
			var4.Parent = var1
		end

		var2 = var4
	end

	var1 = arg1:FindFirstChild("Animations")
	if var2 then
		for k1, v1 in ipairs(var2:GetPlayingAnimationTracks()) do
			v1:Stop(0.1)
		end
	end

	local var7 = nil
	if var2 then
		if var1 then
			local var10 = var1:FindFirstChild("Falling")
			if var10 then
				var7 = var2:LoadAnimation(var10)
				var7.Priority = Enum.AnimationPriority.Action4
				var7:Play(0.1)
			else
				warn("\208\144\208\189\208\184\208\188\208\176\209\134\208\184\209\143 'Falling' \208\189\208\181 \208\189\208\176\208\185\208\180\208\181\208\189\208\176 \208\178 " .. arg1.Name .. ".Animations!")
			end
		end
	end

	local num2 = 2.5
	if var7 and 0 < var7.Length then
		num2 = var7.Length
	end

	task.wait(num2)
	if var7 and var7.IsPlaying then
		var7:Stop(0.2)
	end

	arg1:SetAttribute("IsFalling", nil)
end

local function moveToTarget(arg1, arg2)
	local var1 = arg1:GetPivot().Position
	local var4 = (Vector3.new(arg2.X, 0, arg2.Z) - Vector3.new(var1.X, 0, var1.Z)).Magnitude
	if var4 <= 1 then
		return
	end

	local var5 = (var1 + arg2) / 2 + CFrame.Angles(0, math.rad((math.random(-15, 15))), 0).LookVector * (var4 * 0.15)
	var5 = Vector3.new(var5.X, var1.Y, var5.Z)
	local var6 = arg1:FindFirstChildOfClass("Humanoid")
	var6 = var6 or arg1:FindFirstChildOfClass("AnimationController")
	local var7 = getBezierLength(var1, var5, arg2, 10) / 8
	local num1 = 0
	local var8
	if not var6 then
		var8 = nil
	else
		local var10 = var6:FindFirstChildOfClass("Animator")
		if not var10 then
			var10 = Instance.new("Animator")
			var10.Parent = var6
		end

		var8 = var10
	end

	var6 = arg1:FindFirstChild("Animations")
	local var11 = nil
	local var12 = nil
	if var8 then
		if var6 then
			local var14 = var6:FindFirstChild("Walk")
			local var15 = var6:FindFirstChild("Idle")
			if var14 then
				var11 = var8:LoadAnimation(var14)
			end

			if var15 then
				var12 = var8:LoadAnimation(var15)
			end
		end
	end

	if var12 and var12.IsPlaying then
		var12:Stop(0.2)
	end

	if var11 and (not var11.IsPlaying) then
		var11:Play(0.2)
	end

	resetIKLook(arg1)
	local bool2 = false
	if math.random(1, 100) <= 10 then
		bool2 = not arg1:GetAttribute("IsMeeting")
	end

	local var16 = math.random(30, 70) / 100
	while num1 < var7 do
		if arg1:GetAttribute("CancelMove") then
			break
		end

		if arg1:GetAttribute("IsFalling") then
			break
		end

		local var17 = var2.Heartbeat:Wait()
		num1 = math.min(num1 + var17, var7)
		if not arg1 then
			break
		end

		if not arg1.Parent then
			break
		end

		local var19 = num1 / var7
		if bool2 then
			if var16 <= var19 then
				if var11 and var11.IsPlaying then
					var11:Stop(0.1)
				end

				makeModelFall(arg1)
				break
			end
		end

		local var20 = math.min(var19 + 0.02, 1)
		local var21 = (1 - var19) ^ 2 * var1 + 2 * (1 - var19) * var19 * var5 + var19 ^ 2 * arg2
		var20 = ((1 - var20) ^ 2 * var1 + 2 * (1 - var20) * var20 * var5 + var20 ^ 2 * arg2 - var21) * Vector3.new(1, 0, 1)
		if 0.001 >= var20.Magnitude then
			continue
		end

		arg1:PivotTo((arg1:GetPivot():Lerp(CFrame.lookAt(var21, var21 + var20), (math.clamp(var17 * 10, 0, 1)))))
		local bool3 = false
	end

	if var11 and var11.IsPlaying then
		var11:Stop(0.2)
	end

	if var12 and (not var12.IsPlaying and (not arg1:GetAttribute("IsFalling"))) then
		var12:Play(0.2)
	end
end

local function makeModelsMeet(arg1, arg2, arg3)
	arg1:SetAttribute("CancelMove", true)
	arg2:SetAttribute("CancelMove", true)
	arg1:SetAttribute("IsMeeting", true)
	arg2:SetAttribute("IsMeeting", true)
	task.wait(0.05)
	arg1:SetAttribute("CancelMove", nil)
	arg2:SetAttribute("CancelMove", nil)
	local var1 = arg3.Size
	local var3 = arg3.CFrame * Vector3.new(math.random(-var1.X / 2, var1.X / 2), var1.Y / 2, (math.random(-var1.Z / 2, var1.Z / 2)))
	local var4 = var3 + Vector3.new(-2.5, arg1:GetExtentsSize().Y / 2, 0)
	local var5 = var3 + Vector3.new(2.5, arg2:GetExtentsSize().Y / 2, 0)
	local var6 = task.spawn(function()
		moveToTarget(arg1, var4)
	end)

	local var7 = task.spawn(function()
		moveToTarget(arg2, var5)
	end)

	repeat
		var2.Heartbeat:Wait()
		if coroutine.status(var6) == "dead" then
			if coroutine.status(var7) == "dead" then
				break
			end
		end
	until coroutine.status(var7) == "dead"

	if arg1 then
		if arg1.Parent then
			if arg2 then
				if arg2.Parent then
					local var16 = arg1:GetPivot().Position
					local var17 = arg2:GetPivot().Position
					local var18 = CFrame.lookAt(var16, (Vector3.new(var17.X, var16.Y, var17.Z)))
					local var19 = CFrame.lookAt(var17, (Vector3.new(var16.X, var17.Y, var16.Z)))
					local num1 = 0
					local var20 = arg1:GetPivot()
					local var21 = arg2:GetPivot()
					while num1 < 0.3 do
						num1 = num1 + var2.Heartbeat:Wait()
						local var22 = math.min(num1 / 0.3, 1)
						local var23 = var18
						local var24 = var22
						arg1:PivotTo(var20:Lerp(var23, var24))
						var23 = var19
						var24 = var22
						arg2:PivotTo(var21:Lerp(var23, var24))
					end

					local var25 = arg1:FindFirstChildOfClass("Humanoid")
					var25 = var25 or arg1:FindFirstChildOfClass("AnimationController")
					local var26
					if not var25 then
						var26 = nil
					else
						local var28 = var25:FindFirstChildOfClass("Animator")
						if not var28 then
							var28 = Instance.new("Animator")
							var28.Parent = var25
						end

						var26 = var28
					end

					local var29 = arg2:FindFirstChildOfClass("Humanoid")
					var29 = var29 or arg2:FindFirstChildOfClass("AnimationController")
					if not var29 then
						var25 = nil
					else
						local var31 = var29:FindFirstChildOfClass("Animator")
						if not var31 then
							var31 = Instance.new("Animator")
							var31.Parent = var29
						end

						var25 = var31
					end

					var29 = arg1:FindFirstChild("Animations")
					local var33 = arg2:FindFirstChild("Animations")
					local var34 = nil
					local var35 = nil
					if var26 and (var29 and var29:FindFirstChild("Hello")) then
						var34 = var26:LoadAnimation(var29.Hello)
						var34.Priority = Enum.AnimationPriority.Action
						var34:Play(0.2)
					end

					if var25 and (var33 and var33:FindFirstChild("Hello")) then
						var35 = var25:LoadAnimation(var33.Hello)
						var35.Priority = Enum.AnimationPriority.Action
						var35:Play(0.2)
					end

					local num3 = 2
					if var34 and 0 < var34.Length then
						num3 = var34.Length
					else
						if var35 and 0 < var35.Length then
							num3 = var35.Length
						end
					end

					local var36 = os.clock()
					while os.clock() - var36 < num3 do
						var2.Heartbeat:Wait()
					end

					if var34 and var34.IsPlaying then
						var34:Stop(0.2)
					end

					if var35 and var35.IsPlaying then
						var35:Stop(0.2)
					end
				end
			end
		end
	end

	arg1:SetAttribute("IsMeeting", nil)
	arg2:SetAttribute("IsMeeting", nil)
end

local function updateIKLook(arg1, arg2)
	if arg1:GetAttribute("IsFalling") then
		return
	end

	local var4 = arg1:FindFirstChild("Head")
	local var5 = arg1:FindFirstChild("UpperTorso")
	if not var4 or (not var5) then
		return
	end

	local var8 = var4:FindFirstChild("Neck")
	local var9 = var5:FindFirstChild("Waist")
	if not var8 or (not var9) then
		return
	end

	if not var8:GetAttribute("OriginalC0") then
		var8:SetAttribute("OriginalC0", var8.C0)
	end

	if not var9:GetAttribute("OriginalC0") then
		var9:SetAttribute("OriginalC0", var9.C0)
	end

	local var10 = var1.Character
	local var11 = var10
	var11 = var11 and var10:FindFirstChild("HumanoidRootPart")
	local var15 = var11.Position
	local var16 = var5.Position
	local var17 = var8:GetAttribute("OriginalC0")
	local var18 = var9:GetAttribute("OriginalC0")
	local bool2 = false
	if var11 and (var15 - var16).Magnitude <= arg2 then
		local var19 = var5.CFrame:VectorToObjectSpace((var15 - var16).Unit)
		local var20 = math.clamp(math.asin(var19.Y), -0.52359877559829882, 0.52359877559829882)
		local var21 = math.clamp(math.atan2(-var19.X, -var19.Z), -1.2217304763960306, 1.2217304763960306)
		local var22 = var18 * CFrame.Angles(var20 * 0.5, var21 * 0.5, 0)
		local var23 = var8.C0:Lerp(var17 * CFrame.Angles(var20 * 0.5, var21 * 0.5, 0), 0.1)
		var8.C0 = var23
		var23 = var9.C0:Lerp(var22, 0.1)
		var9.C0 = var23
		bool2 = true
	end

	if not bool2 then
		var16 = var8.C0:Lerp(var17, 0.1)
		var8.C0 = var16
		var16 = var9.C0:Lerp(var18, 0.1)
		var9.C0 = var16
	end
end

return { Init = function()
	local var1 = workspace:WaitForChild("MovingParts")
	var1:WaitForChild("Birds")
	local var3 = var1:WaitForChild("MovingModels")
	local var4 = var1:WaitForChild("MovingPart")
	for k1, v1 in ipairs(var3:GetChildren()) do
		if not v1:IsA("Model") then
			continue
		end

		task.spawn(function()
			local var1 = v1
			local var3 = var1:FindFirstChildOfClass("Humanoid")
			var3 = var3 or var1:FindFirstChildOfClass("AnimationController")
			local var5
			if not var3 then
				var5 = nil
			else
				local var7 = var3:FindFirstChildOfClass("Animator")
				if not var7 then
					var7 = Instance.new("Animator")
					var7.Parent = var3
				end

				var5 = var7
			end

			var1 = v1:FindFirstChild("Animations")
			var3 = nil
			local var8 = nil
			if var5 then
				if var1 then
					local var10 = var1:FindFirstChild("Walk")
					local var11 = var1:FindFirstChild("Idle")
					if var10 then
						var3 = var5:LoadAnimation(var10)
						var3.Priority = Enum.AnimationPriority.Movement
					end

					if var11 then
						var8 = var5:LoadAnimation(var11)
						var8.Priority = Enum.AnimationPriority.Idle
					end
				end
			end

			while true do
				if not v1 then
					break
				end

				if not v1.Parent then
					break
				end

				if v1:GetAttribute("IsMeeting") or v1:GetAttribute("IsFalling") then
					var2.Heartbeat:Wait()
				else
					if var3 and var3.IsPlaying then
						var3:Stop(0.2)
					end

					if var8 and (not var8.IsPlaying) then
						var8:Play(0.2)
					end

					local var12 = math.random(3, 6)
					local var13 = os.clock()
					while true do
						if os.clock() - var13 >= var12 then
							break
						end

						var2.Heartbeat:Wait()
						if not v1 then
							break
						end

						if not v1.Parent then
							break
						end

						if v1:GetAttribute("IsMeeting") then
							break
						end

						if v1:GetAttribute("IsFalling") then
							break
						end

						updateIKLook(v1, 15)
					end

					if v1:GetAttribute("IsMeeting") then
						continue
					end

					if v1:GetAttribute("IsFalling") then
						continue
					end

					local var14 = var4
					local var15 = var14.Size
					local var16 = var14.CFrame * Vector3.new(math.random(-var15.X / 2, var15.X / 2), var15.Y / 2, (math.random(-var15.Z / 2, var15.Z / 2)))
					moveToTarget(v1, var16 + Vector3.new(0, v1:GetExtentsSize().Y / 2, 0))
				end
			end
		end)

	end

	task.spawn(function()
		while true do
			local num1 = 12
			local num2 = 40
			task.wait(math.random(num1, num2))
			local tbl1 = {}
			for k1, v1 in ipairs(var3:GetChildren()) do
				if not v1:IsA("Model") then
					continue
				end

				if v1:GetAttribute("IsMeeting") then
					continue
				end

				if v1:GetAttribute("IsFalling") then
					continue
				end

				table.insert(tbl1, v1)
			end

			if 2 > (#tbl1) then
				continue
			end

			local num3 = 1
			local var1 = #tbl1
			local var2 = table.remove(tbl1, math.random(num3, var1))
			var1 = 1
			local var5 = #tbl1
			var1 = table.remove(tbl1, math.random(var1, var5))
			makeModelsMeet(var2, var1, var4)
		end
	end)
end }

--- ReplicatedStorage.ModuleLoader.Shared.Network [ModuleScript]
-- y u r i

local tbl2 = {}
local tbl3 = {}
if game:GetService("RunService"):IsServer() then
	tbl3.Create = function(arg1, arg2)
		if not arg1 or (not arg2) then
			warn("[Network] Either name or class name is nil")
			return nil
		end

		if tbl2[arg1] then
			warn((("[Network] Duplicate network part name '%*' ignored"):format(arg1)))
			return nil
		end

		local var2 = script:FindFirstChild(arg2)
		if not var2 then
			var2 = Instance.new("Folder")
			var2.Name = arg2
			var2.Parent = script
		end

		local var3 = Instance.new(arg2)
		var3.Name = arg1
		var3.Parent = var2
		tbl2[arg1] = var3
		return var3
	end

end

tbl3.Get = function(arg1)
	local tbl1 = {}
	for k1, v1 in script:GetChildren() do
		for k2, v2 in v1:GetChildren() do
			tbl1[v2.Name] = v2
		end
	end

	return tbl1[arg1]
end

return tbl3

--- ReplicatedStorage.ModuleLoader.Shared.FormatModule [ModuleScript]
-- y u r i

local tbl1 = {}
local tbl2 = {
	"k",
	"m",
	"b",
	"t",
	"Qa",
	"Qn",
	"Sx",
	"Sp",
	"Oc",
	"N",
	"Dc",
	"Ud",
	"Dd",
	"Td",
	"Qad",
	"Qu",
	"Sd",
	"St",
	"O",
	"Nod",
	"Vg",
	"Uvg",
	"Dvg",
	"Tvg",
	"Qavg",
	"Qivg",
	"Sxvg",
	"Spvg",
	"Ocvg",
}

tbl1.FormatCompact = function(arg1, arg2)
	if arg1 == "HUGE" then
		return 1
	end

	if typeof(arg1) == "string" then
		if tbl1.FormatToNumber(arg1) ~= arg1 then
			arg1 = tbl1.FormatToNumber(arg1)
		else
			return arg1
		end
	end

	if not arg1 then
		return
	end

	if arg1 <= 0 then
		return "0"
	end

	if not arg2 then
		arg2 = 2
	elseif arg2 == "DetailSave" then
		arg2 = 8
	end

	local var1 = math.floor((math.log(arg1, 1000)))
	local var3 = math.pow(10, var1 * 3)
	if arg2 == 0 and arg1 < 1000 then
		return string.split(("%.1f"):format(arg1 / var3):gsub("%.?0+$", "") .. (tbl2[var1] or ""), ".")[1]
	end

	return ("%." .. arg2 .. "f"):format(arg1 / var3):gsub("%.?0+$", "") .. (tbl2[var1] or "")
end

tbl1.FormatToNumber = function(arg1, arg2)
	local var8
	if typeof(arg1) == "number" then
		if tbl1.FormatCompact(arg1) ~= arg1 then
			arg1 = tbl1.FormatCompact(arg1)
		else
			return arg1
		end
	end

	if arg1 == nil then
		return
	end

	if arg1 == "0" then
		return 0
	end

	if arg1 == "" then
		return 0
	end

	local var3, var4 = string.match(arg1, "(.-)([a-zA-Z]*)$")
	if var3 then
		if var4 then
			local var5 = table.find(tbl2, (string.lower(var4):gsub("^%l", string.upper))) or 0
			if tonumber(var3) then
				if arg2 then
					local var7 = math.floor(tonumber(var3) * math.pow(10, var5 * 3))
					if not var7 then
						var7 = tonumber(var3) * math.pow(10, var5 * 3)
					end
				end

				return var8
			end

			return nil
		end
	end

	return (math.round((tonumber(arg1))))
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Shared.SyncedTime [ModuleScript]
-- y u r i

local tbl1 = {
	Jan = 1,
	Feb = 2,
	Mar = 3,
	Apr = 4,
	May = 5,
	Jun = 6,
	Jul = 7,
	Aug = 8,
	Sep = 9,
	Oct = 10,
	Nov = 11,
	Dec = 12,
}

local bool1 = false
local var1 = game:GetService("HttpService")
local var2 = nil
local function RFC2616DateStringToUnixTimestamp(arg1)
	local var1, var2, var3, var4, var5, var6 = arg1:match(".*, (.*) (.*) (.*) (.*):(.*):(.*) .*")
	local tbl2 = { day = var1, month = tbl1[var2], year = var3, hour = var4, min = var5, sec = var6 }
	return os.time(tbl2)
end

local var3 = nil
local var4 = nil
local function init()
	if not bool1 then
		if not pcall(function()
			local var5 = tick()
			var2 = RFC2616DateStringToUnixTimestamp(var1:RequestAsync({ Url = "http://google.com" }).Headers.date)
			var3 = tick()
			var4 = (var3 - var5) / 2
		end) then

			warn("Cannot get time from google.com. Make sure that http requests are enabled!")
			var2 = os.time()
			var3 = tick()
			var4 = 0
		end

		bool1 = true
	end
end

return {
	inited = function()
		return bool1
	end,
	init = init,
	time = function()
		if not bool1 then
			init()
		end

		return var2 + tick() - var3 - var4
	end,
}

--- ReplicatedStorage.ModuleLoader.Shared.BigNotify [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local num1 = 0
local num2 = 0
local var2 = game:GetService("TweenService")
local var3 = game:GetService("SoundService")
return { Show = function(arg1, arg2)
	local var4 = var1:WaitForChild("PlayerGui"):WaitForChild("Main"):WaitForChild("NotificationFrame")
	local var5 = var4:WaitForChild("BigNotification")
	local var6 = var5:WaitForChild("Buttons")
	local var7 = var5:WaitForChild("NotificationMessage")
	local var8 = num1 + 1
	num1 = var8
	var8 = num1
	while var8 ~= num2 + 1 do
		task.wait(0.05)
	end

	var7.Text = arg1
	local tbl1 = { "OkButton" }
	if arg2 == "YesNo" then
		tbl1 = { "YesButton", "NoButton" }
	else
		if type(arg2) == "table" then
			tbl1 = arg2
		end
	end

	local var9 = Instance.new("BindableEvent")
	local tbl2 = {}
	for k1, v1 in ipairs(var6:GetChildren()) do
		local var10 = v1:IsA("TextButton")
		if not var10 then
			continue
		end

		var10 = table.find(tbl1, v1.Name) ~= nil
		v1.Visible = var10
		if not var10 then
			continue
		end

		table.insert(tbl2, (v1.Activated:Connect(function()
			var9:Fire(v1.Name)
		end)))

		table.insert(tbl2, (v1.MouseEnter:Connect(function()
			var2:Create(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), { Scale = 1.025 }):Play()
			var3:WaitForChild("HoverSFX"):Play()
		end)))

		table.insert(tbl2, (v1.MouseLeave:Connect(function()
			var2:Create(v1.UIScale, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), { Scale = 1 }):Play()
		end)))

	end

	var4.Visible = true
	local var11 = var9.Event:Wait()
	for k2, v2 in ipairs(tbl2) do
		v2:Disconnect()
	end

	var9:Destroy()
	var4.Visible = false
	local var12 = num2 + 1
	num2 = var12
	return var11
end }

--- ReplicatedStorage.ModuleLoader.Libs.ProfileStore [ModuleScript]
-- y u r i

local var1 = nil
local function AcquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
tbl2.__index = tbl2
tbl1.Disconnect = function(arg1)
	if arg1.is_connected == false then
		return
	end

	arg1.is_connected = false
	local var1 = arg1.signal
	local var2 = var1.listener_count - 1
	var1.listener_count = var2
	if var1.head == arg1 then
		var1.head = arg1.next
		return
	end

	var2 = var1.head
	while var2 ~= nil and var2.next ~= arg1 do
		var2 = var2.next
	end

	if var2 ~= nil then
		var2.next = arg1.next
	end
end

tbl2.New = function()
	local tbl1 = { head = nil, listener_count = 0 }
	setmetatable(tbl1, tbl2)
	return tbl1
end

tbl2.Connect = function(arg1, arg2)
	if type(arg2) ~= "function" then
		error((("[%*]: \"listener\" must be a function; Received %*"):format(script.Name, (typeof(arg2)))))
	end

	local tbl2 = { listener = arg2, signal = arg1, next = arg1.head, is_connected = true }
	setmetatable(tbl2, tbl1)
	arg1.head = tbl2
	local var1 = arg1.listener_count + 1
	arg1.listener_count = var1
	return tbl2
end

tbl2.GetListenerCount = function(arg1)
	return arg1.listener_count
end

local function RunEventHandlerInFreeThread(...)
	AcquireRunnerThreadAndCallEventHandler(...)
	while true do
		AcquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl2.Fire = function(arg1, ...)
	local var2 = arg1.head
	while var2 ~= nil do
		if var2.is_connected == true then
			if not var1 then
				var1 = coroutine.create(RunEventHandlerInFreeThread)
			end

			task.spawn(var1, var2.listener, ...)
		end

		var2 = var2.next
	end
end

tbl2.Wait = function(arg1)
	local var1 = nil
	local var2 = coroutine.running()
	arg1:Connect(function(...)
		var1:Disconnect()
		task.spawn(var2, ...)
	end)

	return coroutine.yield()
end

local var2 = nil
var2 = table.freeze({ New = tbl2.New })
local var3 = game:GetService("RunService")
local num1 = 300
local num2 = 10
local num3 = 5
local num4 = 40
local num5 = 630
local num6 = 120
local num7 = 5
local num8 = 120
local num9 = 120
local num10 = 1000
var1 = {}
AcquireRunnerThreadAndCallEventHandler = {}
RunEventHandlerInFreeThread = {}
tbl1 = game:GetService("DataStoreService")
tbl2 = game:GetService("MessagingService")
local var4 = game:GetService("HttpService")
if var3:IsClient() then
	return nil
end

local tbl3 = {}
local str1 = "NotReady"
local function DeepCopyTable(arg1)
	local tbl1 = {}
	for k1, v1 in pairs(arg1) do
		if type(v1) == "table" then
			tbl1[k1] = DeepCopyTable(v1)
		else
			tbl1[k1] = v1
		end
	end

	return tbl1
end

local var5 = var2.New()
local var6 = var2.New()
local function NewMockDataStoreKeyInfo(arg1)
	local var1 = arg1.MetaData
	local var2 = arg1.UserIds
	local var3 = tostring(arg1.VersionId or 0)
	var1 = var1 or {}
	local tbl1 = {
		CreatedTime = arg1.CreatedTime,
		UpdatedTime = arg1.UpdatedTime,
		Version = string.rep("0", 16) .. "." .. string.rep("0", 10 - string.len(var3)) .. var3 .. "." .. string.rep("0", 16) .. "." .. "01",
	}

	tbl1.GetMetadata = function()
		return (DeepCopyTable(var1))
	end

	var2 = var2 or {}
	tbl1.GetUserIds = function()
		return (DeepCopyTable(var2))
	end

	return tbl1
end

local function WaitInUpdateQueue(arg1)
	local bool2 = false
	if tbl3[arg1] == nil then
		tbl3[arg1] = {}
		bool2 = true
	end

	local var2 = tbl3[arg1]
	if bool2 == false then
		table.insert(var2, coroutine.running())
		coroutine.yield()
	end

	return function()
		local var3 = table.remove(var2, 1)
		if var3 ~= nil then
			coroutine.resume(var3)
			return
		end

		tbl3[arg1] = nil
	end
end

local function MockUpdateAsync(arg1, arg2, arg3, arg4, arg5)
	local var2 = arg1[arg2]
	if var2 == nil then
		var2 = {}
		arg1[arg2] = var2
	end

	local var4 = var2[arg3]
	local var5 = math.floor(os.time() * 1000)
	local bool2 = false
	if var4 == nil then
		bool2 = true
		if arg5 ~= true then
			var4 = {
				Data = nil,
				CreatedTime = var5,
				UpdatedTime = var5,
				VersionId = 0,
				UserIds = {},
				MetaData = {},
			}

			var2[arg3] = var4
		end
	end

	local var6 = var4
	local var10, var11, var12 = arg4(var6 and var4.Data, bool2 == false and NewMockDataStoreKeyInfo(var4) or nil)
	if var10 == nil then
		return nil
	end

	if var4 ~= nil and arg5 ~= true then
		var4.Data = DeepCopyTable(var10)
		local var13 = var11
		var4.UserIds = DeepCopyTable(var13 or {})
		var13 = var12
		var4.MetaData = DeepCopyTable(var13 or {})
		local var14 = var4.VersionId + 1
		var4.VersionId = var14
		var4.UpdatedTime = var5
	end

	return DeepCopyTable(var10), var4 ~= nil and NewMockDataStoreKeyInfo(var4) or nil
end

local tbl4 = {}
local tbl5 = {}
local var7 = game.PlaceId
local var8 = game.JobId
local bool1 = false
local num11 = 1
local var9 = os.clock()
local num12 = 0
local function UpdateAsync(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = nil
	local var2 = nil
	local var3 = WaitInUpdateQueue
	local str3 = "L_"
	local var4 = arg1.Name
	if arg4 == true then
		str3 = "U_"
	else
		if str1 ~= "Access" then
			str3 = "M_"
		end
	end

	var3 = var3(str3 .. var4 .. "\0" .. arg2)
	var3()
	local success, result = pcall(function()
		local function fn4(arg1)
			local bool2 = false
			local bool3 = false
			local tbl1 = { 0, {} }
			if arg1 == nil then
				bool2 = true
			else
				if type(arg1) ~= "table" then
					bool2 = true
					bool3 = true
				else
					if type(arg1.Data) == "table" and (type(arg1.MetaData) == "table" and type(arg1.GlobalUpdates) == "table") then
						arg1.WasOverwritten = false
						tbl1 = arg1.GlobalUpdates
						if arg3.ExistingProfileHandle ~= nil then
							arg3.ExistingProfileHandle(arg1)
						end
					else
						if arg1.Data == nil and (arg1.MetaData == nil and type(arg1.GlobalUpdates) == "table") then
							arg1.WasOverwritten = false
							bool2 = true
							tbl1 = arg1.GlobalUpdates or tbl1
						else
							bool2 = true
							bool3 = true
						end
					end
				end
			end

			if bool2 == true then
				arg1 = { GlobalUpdates = tbl1 }
				if arg3.MissingProfileHandle ~= nil then
					arg3.MissingProfileHandle(arg1)
				end
			end

			if arg3.EditProfile ~= nil then
				arg3.EditProfile(arg1)
			end

			if bool3 == true then
				arg1.WasOverwritten = true
			end

			return arg1, arg1.UserIds, arg1.RobloxMetaData
		end

		if arg4 == true then
			local var3, var4 = MockUpdateAsync(tbl4, arg1.Name, arg2, fn4, arg5)
			var1 = var3
			var2 = var4
			task.wait()
			return
		end

		if str1 ~= "Access" then
			local var5, var6 = MockUpdateAsync(tbl5, arg1.Name, arg2, fn4, arg5)
			var1 = var5
			var2 = var6
			task.wait()
			return
		end

		if arg5 == true then
			if arg6 ~= nil then
				local success, result = pcall(function()
					local var3, var4 = arg1.data_store:GetVersionAsync(arg2, arg6)
					var1 = var3
					var2 = var4
				end)

				if success == false and (type(result) == "string" and string.find(result, "not valid") ~= nil) then
					warn(([=[[%*]: Passed version argument is not valid; Traceback:
]=]):format(script.Name) .. debug.traceback())

				end
			else
				local var7, var8 = arg1.data_store:GetAsync(arg2)
				var1 = var7
				var2 = var8
			end

			local var9 = fn4(var1)
			var1 = var9
			return
		end

		local var10, var11 = arg1.data_store:UpdateAsync(arg2, fn4)
		var1 = var10
		var2 = var11
	end)

	if success == true then
		if type(var1) == "table" then
			if var1.WasOverwritten == true and arg5 ~= true then
				local var9 = arg1.Name
				warn((("[%*]: Invalid profile was overwritten (STORE:%*; KEY:%*)"):format(script.Name, var9, arg2)))
				var6:Fire(var9, arg2)
			end

			return var1, var2
		end
	end

	local var10 = arg1.Name
	local var11 = result or "Undefined error"
	warn((("[%*]: DataStore API error (STORE:%*; KEY:%*) - %*"):format(script.Name, var10, arg2, (tostring(var11)))))
	table.insert(RunEventHandlerInFreeThread, os.clock())
	var5:Fire(tostring(var11), var10, arg2)
	return nil
end

local var10 = var3:IsStudio()
local function ReconcileTable(arg1, arg2)
	for k1, v1 in pairs(arg2) do
		if type(k1) ~= "string" then
			continue
		end

		if arg1[k1] == nil then
			if type(v1) == "table" then
				arg1[k1] = DeepCopyTable(v1)
			else
				arg1[k1] = v1
				continue
			end
		else
			if type(arg1[k1]) ~= "table" then
				continue
			end

			if type(v1) ~= "table" then
				continue
			end

			ReconcileTable(arg1[k1], v1)
		end
	end
end

local function SaveProfileAsync(arg1, arg2, arg3, arg4)
	if type(arg1.Data) ~= "table" then
		error((("[%*]: Developer code likely set \"Profile.Data\" to a non-table value! (STORE:%*; KEY:%*)"):format(script.Name, arg1.ProfileStore.Name, arg1.Key)))
	end

	arg1.OnSave:Fire()
	if arg2 == true then
		arg1.OnLastSave:Fire(arg4 or "Manual")
	end

	if arg2 == true then
		if arg3 ~= true then
			if arg1.roblox_message_subscription ~= nil then
				arg1.roblox_message_subscription:Disconnect()
			end

			var1[arg1.session_token] = nil
			local var3 = table.find(AcquireRunnerThreadAndCallEventHandler, arg1)
			if var3 ~= nil then
				table.remove(AcquireRunnerThreadAndCallEventHandler, var3)
				if var3 < num11 then
					local var4 = num11 - 1
					num11 = var4
				end

				if AcquireRunnerThreadAndCallEventHandler[num11] == nil then
					num11 = 1
				end
			end

			arg1.OnSessionEnd:Fire()
		end
	end

	local var5 = num12 + 1
	num12 = var5
	var5 = true
	local num1 = 1
	while var5 ~= true and arg2 ~= true do
	end

	local var6 = num12 - 1
	num12 = var6
end

local tbl6 = {}
tbl6.__index = tbl6
tbl6.New = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = arg1.Data
	local var3 = arg1.GlobalUpdates and arg1.GlobalUpdates[2] or {}
	var1 = var1 or {}
	local var4 = arg1.MetaData and arg1.MetaData.ActiveSession or nil
	local tbl1 = {}
	for k1, v1 in ipairs(var3) do
		tbl1[v1[1]] = true
	end

	local tbl2 = { Data = var1, LastSavedData = DeepCopyTable(var1) }
	tbl2.FirstSessionTime = arg1.MetaData and arg1.MetaData.ProfileCreateTime or 0
	tbl2.SessionLoadCount = arg1.MetaData and arg1.MetaData.SessionLoadCount or 0
	local var6 = var4
	if var6 then
		var6 = { PlaceId = var4[1], JobId = var4[2] }
	end

	tbl2.Session = var6
	var6 = arg1.RobloxMetaData
	tbl2.RobloxMetaData = var6 or {}
	var6 = arg1.UserIds
	tbl2.UserIds = var6 or {}
	tbl2.KeyInfo = arg2
	tbl2.OnAfterSave = var2.New()
	tbl2.OnSave = var2.New()
	tbl2.OnLastSave = var2.New()
	tbl2.OnSessionEnd = var2.New()
	tbl2.ProfileStore = arg3
	tbl2.Key = arg4
	tbl2.load_timestamp = os.clock()
	tbl2.is_mock = arg5
	tbl2.session_token = arg6 or ""
	tbl2.load_index = arg1.MetaData and arg1.MetaData.SessionLoadCount or 0
	tbl2.locked_global_updates = {}
	tbl2.received_global_updates = tbl1
	tbl2.message_handlers = {}
	tbl2.global_updates = var3
	setmetatable(tbl2, tbl6)
	return tbl2
end

tbl6.IsActive = function(arg1)
	return var1[arg1.session_token] == arg1
end

tbl6.Reconcile = function(arg1)
	ReconcileTable(arg1.Data, arg1.ProfileStore.template)
end

tbl6.EndSession = function(arg1)
	if arg1:IsActive() == true then
		task.spawn(SaveProfileAsync, arg1, true, nil, "Manual")
	end
end

tbl6.AddUserId = function(arg1, arg2)
	if type(arg2) ~= "number" or arg2 % 1 ~= 0 then
		warn(([=[[%*]: Invalid UserId argument for :AddUserId() (%*); Traceback:
]=]):format(script.Name, (tostring(arg2))) .. debug.traceback())

		return
	end

	if arg2 < 0 and (arg1.is_mock ~= true and str1 == "Access") then
		return
	end

	if table.find(arg1.UserIds, arg2) == nil then
		table.insert(arg1.UserIds, arg2)
	end
end

tbl6.RemoveUserId = function(arg1, arg2)
	if type(arg2) ~= "number" or arg2 % 1 ~= 0 then
		warn(([=[[%*]: Invalid UserId argument for :RemoveUserId() (%*); Traceback:
]=]):format(script.Name, (tostring(arg2))) .. debug.traceback())

		return
	end

	local var2 = table.find(arg1.UserIds, arg2)
	if var2 ~= nil then
		table.remove(arg1.UserIds, var2)
	end
end

tbl6.SetAsync = function(arg1)
	if arg1.view_mode ~= true then
		error((("[%*]: :SetAsync() can only be used in view mode"):format(script.Name)))
	end

	SaveProfileAsync(arg1, nil, true)
end

tbl6.MessageHandler = function(arg1, arg2)
	if type(arg2) ~= "function" then
		error((("[%*]: fn argument is not a function"):format(script.Name)))
	end

	if arg1.view_mode ~= true and arg1:IsActive() ~= true then
		return
	end

	table.insert(arg1.message_handlers, arg2)
	local var1 = arg1.locked_global_updates
	for k1, v1 in ipairs(arg1.global_updates) do
		local var2 = v1[1]
		if var1[var2] == true then
			continue
		end

		task.spawn(arg2, DeepCopyTable(v1[#v1]), function()
			var1[var2] = true
		end)

	end
end

tbl6.Save = function(arg1)
	if arg1.view_mode == true then
		error((("[%*]: Can't save profile in view mode; Should you be calling :SetAsync() instead?"):format(script.Name)))
	end

	if arg1:IsActive() == false then
		warn(("[%*]: Attempted saving an inactive profile (STORE:%*; KEY:%*);"):format(script.Name, arg1.ProfileStore.Name, arg1.Key) .. [[ Traceback:
]] .. debug.traceback())

		return
	end

	var1[arg1.session_token] = nil
	local var3 = table.find(AcquireRunnerThreadAndCallEventHandler, arg1)
	if var3 ~= nil then
		table.remove(AcquireRunnerThreadAndCallEventHandler, var3)
		if var3 < num11 then
			local var4 = num11 - 1
			num11 = var4
		end

		if AcquireRunnerThreadAndCallEventHandler[num11] == nil then
			num11 = 1
		end
	end

	var1[arg1.session_token] = arg1
	table.insert(AcquireRunnerThreadAndCallEventHandler, num11, arg1)
	if 1 < (#AcquireRunnerThreadAndCallEventHandler) then
		var3 = num11 + 1
		num11 = var3
	else
		if #AcquireRunnerThreadAndCallEventHandler == 1 then
			var9 = os.clock()
		end
	end

	task.spawn(SaveProfileAsync, arg1)
end

local tbl7 = {
	IsClosing = false,
	IsCriticalState = false,
	OnError = var5,
	OnOverwrite = var6,
	OnCriticalToggle = var2.New(),
	DataStoreState = "NotReady",
}

tbl7.__index = tbl7
tbl7.SetConstant = function(arg1, arg2)
	if type(arg2) ~= "number" then
		error((("[%*]: Invalid value type"):format(script.Name)))
	end

	if arg1 == "AUTO_SAVE_PERIOD" then
		num1 = arg2
		return
	end

	if arg1 == "LOAD_REPEAT_PERIOD" then
		num2 = arg2
		return
	end

	if arg1 == "FIRST_LOAD_REPEAT" then
		num3 = arg2
		return
	end

	if arg1 == "SESSION_STEAL" then
		num4 = arg2
		return
	end

	if arg1 == "ASSUME_DEAD" then
		num5 = arg2
		return
	end

	if arg1 == "START_SESSION_TIMEOUT" then
		num6 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_ERROR_COUNT" then
		num7 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_ERROR_EXPIRE" then
		num8 = arg2
		return
	end

	if arg1 == "CRITICAL_STATE_EXPIRE" then
		num9 = arg2
		return
	end

	if arg1 == "MAX_MESSAGE_QUEUE" then
		num10 = arg2
		return
	end

	error((("[%*]: Invalid constant name was provided"):format(script.Name)))
end

local num13 = 0
tbl7.Test = function()
	return {
		ActiveSessionCheck = var1,
		AutoSaveList = AcquireRunnerThreadAndCallEventHandler,
		ActiveProfileLoadJobs = num13,
		ActiveProfileSaveJobs = num12,
		MockStore = tbl5,
		UserMockStore = tbl4,
		UpdateQueue = tbl3,
	}
end

tbl7.New = function(arg1, arg2)
	local var1 = arg2
	arg2 = var1 or {}
	if type(arg1) ~= "string" then
		error((("[%*]: Invalid or missing \"store_name\""):format(script.Name)))
	else
		if string.len(arg1) == 0 then
			error((("[%*]: store_name cannot be an empty string"):format(script.Name)))
		else
			if 50 < string.len(arg1) then
				error((("[%*]: store_name is too long"):format(script.Name)))
			end
		end
	end

	if type(arg2) ~= "table" then
		error((("[%*]: Invalid template argument"):format(script.Name)))
	end

	var1 = nil
	var1 = {
		Mock = {
			Name = arg1,
			StartSessionAsync = function(_, arg2)
				bool1 = true
				local var2 = arg2
				return var1:StartSessionAsync(var2)
			end,
			MessageAsync = function(_, arg2, arg3)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				return var1:MessageAsync(var2, var3)
			end,
			GetAsync = function(_, arg2, arg3)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				return var1:GetAsync(var2, var3)
			end,
			VersionQuery = function(_, arg2, arg3, arg4, arg5)
				bool1 = true
				local var2 = arg2
				local var3 = arg3
				local var4 = arg4
				local var5 = arg5
				return var1:VersionQuery(var2, var3, var4, var5)
			end,
			RemoveAsync = function(_, arg2)
				bool1 = true
				local var2 = arg2
				return var1:RemoveAsync(var2)
			end,
		},
		Name = arg1,
		template = arg2,
		data_store = nil,
		load_jobs = {},
		mock_load_jobs = {},
		is_ready = true,
	}

	setmetatable(var1, tbl7)
	local var2 = Instance.new("DataStoreOptions")
	var2:SetExperimentalFeatures({ v2 = true })
	if str1 == "NotReady" then
		var1.is_ready = false
		task.spawn(function()
			repeat
				task.wait()
			until str1 ~= "NotReady"

			if str1 == "Access" then
				var1.data_store = tbl1:GetDataStore(arg1, nil, var2)
			end

			var1.is_ready = true
		end)

	else
		if str1 == "Access" then
			var1.data_store = tbl1:GetDataStore(arg1, nil, var2)
		end
	end

	return var1
end

local num14 = 0
local function RobloxMessageSubscription(arg1, arg2)
	local num1 = 0
	local var1 = tbl2:SubscribeAsync("PS_" .. arg2, function(arg1)
		if type(arg1.Data) == "table" and (arg1.Data.LoadCount == arg1.SessionLoadCount and 6 < os.clock() - num1) then
			num1 = os.clock()
			if arg1:IsActive() == true then
				if arg1.Data.EndSession == true then
					SaveProfileAsync(arg1, true, false, "External")
					return
				end

				arg1:Save()
			end
		end
	end)

	if arg1:IsActive() == true then
		arg1.roblox_message_subscription = var1
	else
		var1:Disconnect()
	end
end

tbl7.StartSessionAsync = function(arg1, arg2, arg3)
	local var38
	local var40
	local var44
	local var2 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if arg3 ~= nil and type(arg3) ~= "table" then
		error((("[%*]: Invalid params"):format(script.Name)))
	end

	local var3 = arg3
	arg3 = var3 or {}
	if tbl7.IsClosing == true then
		return nil
	end

	while arg1.is_ready == false do
		task.wait()
	end

	var3 = "L_"
	local var5 = arg1.Name
	if var2 == true then
		var3 = "U_"
	else
		if str1 ~= "Access" then
			var3 = "M_"
		end
	end

	var3 = var3 .. var5 .. "\0" .. arg2
	if var1[var3] ~= nil then
		error((("[%*]: Profile (STORE:%*; KEY:%*) is already loaded in this session"):format(script.Name, arg1.Name, arg2)))
	end

	var5 = num13 + 1
	num13 = var5
	var5 = false
	local var6 = arg3.Steal == true
	local num1 = 0
	local bool2 = true
	local bool3 = false
	local var10 = os.clock()
	local num7 = 1
	while true do
		if tbl7.IsClosing ~= false then
			break
		end

		local var11
		if var5 == false then
			if arg3.Cancel ~= nil then
				var5 = arg3.Cancel() == true
			end

			var11 = var5
		else
			var11 = true
		end

		if var11 ~= false then
			break
		end

		var11 = num14 + 1
		num14 = var11
		local var12 = var2 == true and arg1.mock_load_jobs or arg1.load_jobs
		local var14 = var12[arg2]
		var11 = num14
		local var15 = nil
		local var16 = nil
		local var17 = var4:GenerateGUID(false)
		if var14 ~= nil then
			var14[1] = var11
			while var14[2] == nil do
				task.wait()
			end

			if var14[1] == var11 then
				local var18, var19 = table.unpack(var14[2])
				var15 = var18
				var12[arg2] = nil
				var16 = var19
			else
				local var20 = num13 - 1
				num13 = var20
				return nil
			end
		else
			var14 = { var11, nil }
			var12[arg2] = var14
			local var21 = arg1
			local var22 = arg2
			local tbl1 = {
				ExistingProfileHandle = function(arg1)
					if tbl7.IsClosing ~= true then
						local var1
						if var5 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var5 = var2
							end

							var1 = var5
						else
							var1 = true
						end

						if var1 == true then
							return
						end
					end

					var1 = arg1.MetaData.ActiveSession
					local var3 = arg1.MetaData.ForceLoadSession
					if var1 == nil then
						arg1.MetaData.ActiveSession = { var7, var8, var17 }
						arg1.MetaData.ForceLoadSession = nil
						return
					end

					if type(var1) == "table" then
						local bool1 = false
						if var1[1] == var7 then
							bool1 = var1[2] == var8
						end

						if bool1 == false then
							bool1 = arg1.MetaData.LastUpdate
							if bool1 ~= nil and num5 < os.time() - bool1 then
								arg1.MetaData.ActiveSession = { var7, var8, var17 }
								arg1.MetaData.ForceLoadSession = nil
								return
							end

							if bool3 ~= true then
								if var6 == true then
									local var4
									if var3 ~= nil then
										local bool4 = false
										if var3[1] == var7 then
											bool4 = var3[2] == var8
										end

										var4 = not bool4
									else
										var4 = true
									end

									if not (var4 == false or var6 == true) then
										return
									end

									if var6 ~= true then
										return
									end

									arg1.MetaData.ActiveSession = { var7, var8, var17 }
									arg1.MetaData.ForceLoadSession = nil
									return
								end
							end

							if bool2 ~= true then
								return
							end

							arg1.MetaData.ForceLoadSession = { var7, var8 }
							return
						end

						arg1.MetaData.ForceLoadSession = nil
					end
				end,
				MissingProfileHandle = function(arg1)
					local bool1 = true
					if tbl7.IsClosing ~= true then
						local var1
						if var5 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var5 = var2
							end

							var1 = var5
						else
							var1 = true
						end

						bool1 = var1 == true
					end

					arg1.Data = DeepCopyTable(arg1.template)
					var1 = { ProfileCreateTime = os.time(), SessionLoadCount = 0, ForceLoadSession = nil }
					local var3
					if bool1 == false then
						var3 = { var7, var8, var17 }
					else
						var3 = nil
					end

					var1.ActiveSession = var3
					var1.MetaTags = {}
					arg1.MetaData = var1
				end,
				EditProfile = function(arg1)
					if tbl7.IsClosing ~= true then
						local var1
						if var5 == false then
							if arg3.Cancel ~= nil then
								local var2 = arg3.Cancel() == true
								var5 = var2
							end

							var1 = var5
						else
							var1 = true
						end

						if var1 == true then
							return
						end
					end

					var1 = arg1.MetaData.ActiveSession
					if var1 ~= nil then
						local bool1 = false
						if var1[1] == var7 then
							bool1 = var1[2] == var8
						end

						if bool1 == true then
							arg1.MetaData.SessionLoadCount = arg1.MetaData.SessionLoadCount + 1
							arg1.MetaData.LastUpdate = os.time()
						end
					end
				end,
			}

			local var23 = var2
			var14[2] = table.pack(UpdateAsync(var21, var22, tbl1, var23))
			if var14[1] == var11 then
				local var24, var25 = table.unpack(var14[2])
				var15 = var24
				var12[arg2] = nil
				var16 = var25
			else
				local var26 = num13 - 1
				num13 = var26
				return nil
			end
		end

		local var27
		if var15 ~= nil then
			if var16 ~= nil then
				local var28 = var15.MetaData.ActiveSession
				if type(var28) == "table" then
					local bool4 = false
					if var28[1] == var7 then
						bool4 = var28[2] == var8
					end

					if bool4 == true then
						bool4 = tbl6.New(var15, var16, arg1, arg2, var2, var3)
						var1[bool4.session_token] = bool4
						table.insert(AcquireRunnerThreadAndCallEventHandler, num11, bool4)
						if 1 < (#AcquireRunnerThreadAndCallEventHandler) then
							local var29 = num11 + 1
							num11 = var29
						else
							if #AcquireRunnerThreadAndCallEventHandler == 1 then
								var9 = os.clock()
							end
						end

						if var2 ~= true and str1 == "Access" then
							task.spawn(RobloxMessageSubscription, bool4, var17)
						end

						if tbl7.IsClosing ~= true then
							local var30
							if var5 == false then
								if arg3.Cancel ~= nil then
									var5 = arg3.Cancel() == true
								end

								var30 = var5
							else
								var30 = true
							end

							if var30 == true then
								SaveProfileAsync(bool4, true)
								bool4 = nil
							end
						end

						var30 = num13 - 1
						num13 = var30
						return bool4
					end

					if tbl7.IsClosing ~= true then
						if var5 == false then
							if arg3.Cancel ~= nil then
								var5 = arg3.Cancel() == true
							end

							bool4 = var5
						else
							bool4 = true
						end

						if bool4 == true then
							bool4 = num13 - 1
							num13 = bool4
							return nil
						end
					end

					bool4 = var15.MetaData.ForceLoadSession
					if bool4 ~= nil then
						local bool5 = false
						if bool4[1] == var7 then
							bool5 = bool4[2] == var8
						end

						var30 = not bool5
					else
						var30 = true
					end

					local var31
					if var30 == false then
						if bool2 == false then
							num1 = num1 + 1
							if math.ceil(num4 / num2) <= num1 then
							end
						end

						if type(var28[3]) == "string" then
							task.spawn(tbl2.PublishAsync, tbl2, "PS_" .. var28[3], { LoadCount = var15.MetaData.SessionLoadCount or 0, EndSession = true })
						end

						local var32 = os.clock()
						local var33 = var32 + (if bool2 == true then num3 else num2)
						while true do
							task.wait()
							if var33 > os.clock() and tbl7.IsClosing ~= true then
								continue
							end
						end
					else
						local var34 = num13 - 1
						num13 = var34
						return nil
					end
				else
					local var35 = num13 - 1
					num13 = var35
					return nil
				end
			else
				local bool6 = false
				if arg3.Cancel == nil then
					bool6 = num6 <= os.clock() - var10
				end

				if bool6 ~= true then
					if tbl7.IsClosing ~= true then
						local var36
						if var5 == false then
							if arg3.Cancel ~= nil then
								var5 = arg3.Cancel() == true
							end

							var36 = var5
						else
							var36 = true
						end

						if var36 == true then
							var36 = num13 - 1
							num13 = var36
							return nil
						end
					end
				end

				task.wait(num7)
			end

			local var37 = math.min(20, num7 * 2)
		else
			local bool7 = false
			if var38.Cancel == nil then
				bool7 = num6 <= os.clock() - var40
			end

			if bool7 ~= true then
				if tbl7.IsClosing ~= true then
					local var45
					if var44 == false then
						if var38.Cancel ~= nil then
							var45 = var38.Cancel() == true
						end

						var36 = var45
					else
						var36 = true
					end

					if var36 == true then
						var36 = num13 - 1
						num13 = var36
						return nil
					end
				end
			end

			task.wait(var37)
		end

		local var46 = math.min(20, var37 * 2)
	end

	var11 = num13 - 1
	num13 = var11
	return nil
end

tbl7.MessageAsync = function(arg1, arg2, arg3)
	local var2 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if type(arg3) ~= "table" then
		error((("[%*]: message must be a table"):format(script.Name)))
	end

	if tbl7.IsClosing == true then
		return false
	end

	while arg1.is_ready == false do
		task.wait()
	end

	local num1 = 1
	while tbl7.IsClosing == false do
		local var4 = UpdateAsync(arg1, arg2, {
			ExistingProfileHandle = nil,
			MissingProfileHandle = nil,
			EditProfile = function(arg1)
				local var1 = arg1.GlobalUpdates
				local var2 = var1[1] + 1
				var1[1] = var2
				local var3 = var1[2]
				table.insert(var3, { var1[1], arg3 })
				while num10 < (#var3) do
					table.remove(var3, 1)
				end
			end,
		}, var2)

		if var4 ~= nil then
			local str4 = "L_"
			local var5 = arg1.Name
			if var2 == true then
				str4 = "U_"
			else
				if str1 ~= "Access" then
					str4 = "M_"
				end
			end

			var5 = var1[str4 .. var5 .. "\0" .. arg2]
			if var5 ~= nil then
				var5:Save()
			else
				local var6 = var4.MetaData
				var6 = var6 or {}
				local var7 = var6.ActiveSession
				local var8 = var6.SessionLoadCount or 0
				if type(var7) == "table" and type(var7[3]) == "string" then
					task.spawn(tbl2.PublishAsync, tbl2, "PS_" .. var7[3], { LoadCount = var8 })
				end
			end

			return true
		end

		task.wait(num1)
		local var9 = math.min(20, num1 * 2)
	end

	return false
end

tbl7.GetAsync = function(arg1, arg2, arg3)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" then
		error((("[%*]: profile_key must be a string"):format(script.Name)))
	else
		if string.len(arg2) == 0 then
			error((("[%*]: Invalid profile_key"):format(script.Name)))
		else
			if 50 < string.len(arg2) then
				error((("[%*]: profile_key is too long"):format(script.Name)))
			end
		end
	end

	if tbl7.IsClosing == true then
		return nil
	end

	while arg1.is_ready == false do
		task.wait()
	end

	if arg3 ~= nil and (var1 or str1 ~= "Access") then
		return nil
	end

	local num1 = 1
	while tbl7.IsClosing == false do
		local var4, var5 = UpdateAsync(arg1, arg2, {
			ExistingProfileHandle = nil,
			MissingProfileHandle = function(arg1)
				arg1.Data = DeepCopyTable(arg1.template)
				local tbl1 = {
					ProfileCreateTime = os.time(),
					SessionLoadCount = 0,
					ActiveSession = nil,
					ForceLoadSession = nil,
				}

				tbl1.MetaTags = {}
				arg1.MetaData = tbl1
			end,
			EditProfile = nil,
		}, var1, true, arg3)

		if var4 ~= nil then
			if var5 == nil then
				return nil
			end

			local var6 = tbl6.New(var4, var5, arg1, arg2, var1)
			var6.view_mode = true
			return var6
		end

		task.wait(num1)
		local var7 = math.min(20, num1 * 2)
	end

	return nil
end

tbl7.RemoveAsync = function(arg1, arg2)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" or string.len(arg2) == 0 then
		error((("[%*]: Invalid profile_key"):format(script.Name)))
	end

	if tbl7.IsClosing == true then
		return false
	end

	while arg1.is_ready == false do
		task.wait()
	end

	local bool2 = false
	local var2 = WaitInUpdateQueue
	local str3 = "L_"
	local var3 = arg1.Name
	if var1 == true then
		str3 = "U_"
	else
		if str1 ~= "Access" then
			str3 = "M_"
		end
	end

	var2 = var2(str3 .. var3 .. "\0" .. arg2)
	if var1 == true then
		str3 = tbl4[arg1.Name]
		if str3 ~= nil then
			str3[arg2] = nil
			if next(str3) == nil then
				tbl4[arg1.Name] = nil
			end
		end

		task.wait()
		bool2 = true
	else
		if str1 ~= "Access" then
			str3 = tbl5[arg1.Name]
			if str3 ~= nil then
				str3[arg2] = nil
				if next(str3) == nil then
					tbl5[arg1.Name] = nil
				end
			end

			task.wait()
			bool2 = true
		else
			bool2 = pcall(function()
				arg1.data_store:RemoveAsync(arg2)
			end)

		end
	end

	var2()
	return bool2
end

local tbl8 = {}
tbl8.__index = tbl8
tbl8.New = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local tbl1 = {
		profile_store = arg1,
		profile_key = arg2,
		sort_direction = arg3,
		min_date = arg4,
		max_date = arg5,
		query_pages = nil,
		query_index = 0,
		query_failure = false,
		is_query_yielded = false,
		query_queue = {},
		is_mock = arg6,
	}

	setmetatable(tbl1, tbl8)
	return tbl1
end

function MoveVersionQueryQueue(arg1)
	repeat
		if 0 >= (#arg1.query_queue) then
			break
		end

		task.spawn((table.remove(arg1.query_queue, 1)))
	until arg1.is_query_yielded == true
end

local bool2 = false
local bool3 = false
tbl8.NextAsync = function(arg1)
	local var1 = bool2 == true
	bool2 = false
	local var2 = arg1.profile_store
	while var2.is_ready == false do
		task.wait()
	end

	if tbl7.IsClosing == true then
		return nil
	end

	if arg1.is_mock ~= true then
		if str1 ~= "Access" then
			if var10 == true and bool3 == false then
				bool3 = true
				warn((("[%*]: :VersionQuery() is not supported in mock mode!"):format(script.Name)))
			end

			return nil
		end
	end

	local bool1 = false
	var2 = nil
	local function query_job()
		if arg1.query_failure == true then
			bool1 = true
			return
		end

		if arg1.query_pages == nil then
			arg1.is_query_yielded = true
			task.spawn(function()
				bool2 = true
				var2 = arg1:NextAsync()
				bool1 = true
			end)

			local success, result = pcall(function()
				arg1.query_pages = arg1.profile_store.data_store:ListVersionsAsync(arg1.profile_key, arg1.sort_direction, arg1.min_date, arg1.max_date)
				arg1.query_index = 0
			end)

			if success == false or arg1.query_pages == nil then
				warn((("[%*]: Version query fail - %*"):format(script.Name, (tostring(result)))))
				arg1.query_failure = true
			end

			arg1.is_query_yielded = false
			MoveVersionQueryQueue(arg1)
			return
		end

		local var3 = arg1.query_pages:GetCurrentPage()[arg1.query_index + 1]
		if arg1.query_pages.IsFinished == true and var3 == nil then
			bool1 = true
			return
		end

		if var3 == nil then
			arg1.is_query_yielded = true
			task.spawn(function()
				bool2 = true
				var2 = arg1:NextAsync()
				bool1 = true
			end)

			local success, result = pcall(function()
				arg1.query_pages:AdvanceToNextPageAsync()
				arg1.query_index = 0
			end)

			if success == false or #arg1.query_pages:GetCurrentPage() == 0 then
				arg1.query_failure = true
			end

			arg1.is_query_yielded = false
			MoveVersionQueryQueue(arg1)
			return
		end

		local var4 = arg1
		local var5 = var4.query_index + 1
		var4.query_index = var5
		var2 = arg1.profile_store:GetAsync(arg1.profile_key, var3.Version)
		bool1 = true
	end

	if arg1.is_query_yielded == false then
		query_job()
	elseif var1 == true then
		table.insert(arg1.query_queue, 1, query_job)
	else
		table.insert(arg1.query_queue, query_job)
	end

	while bool1 == false do
		task.wait()
	end

	return var2
end

tbl7.VersionQuery = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = bool1
	bool1 = false
	if type(arg2) ~= "string" or string.len(arg2) == 0 then
		error((("[%*]: Invalid profile_key"):format(script.Name)))
	end

	if arg3 ~= nil and (typeof(arg3) ~= "EnumItem" or arg3.EnumType ~= Enum.SortDirection) then
		error((("[%*]: Invalid sort_direction (%*)"):format(script.Name, (tostring(arg3)))))
	end

	if arg4 ~= nil and (typeof(arg4) ~= "DateTime" and typeof(arg4) ~= "number") then
		error((("[%*]: Invalid min_date (%*)"):format(script.Name, (tostring(arg4)))))
	end

	if arg5 ~= nil and (typeof(arg5) ~= "DateTime" and typeof(arg5) ~= "number") then
		error((("[%*]: Invalid max_date (%*)"):format(script.Name, (tostring(arg5)))))
	end

	local var2 = arg1
	local var3 = arg2
	local var4 = arg3
	local var5 = typeof(arg4) == "DateTime" and arg4.UnixTimestampMillis or arg4
	local var6 = typeof(arg5) == "DateTime" and arg5.UnixTimestampMillis or arg5
	local var7 = var1
	return tbl8.New(var2, var3, var4, var5, var6, var7)
end

local num15 = 0
if var10 == true then
	task.spawn(function()
		local success, result = pcall(function()
			tbl1:GetDataStore("____PS"):SetAsync("____PS", os.time())
		end)

		local str2 = "NoAccess"
		local bool1 = false
		if success == false then
			bool1 = string.find(result, "ConnectFail", 1, true) ~= nil
		end

		if bool1 == true then
			warn((("[%*]: No internet access - check your network connection"):format(script.Name)))
		end

		if success == false then
			if string.find(result, "403", 1, true) ~= nil or (string.find(result, "must publish", 1, true) ~= nil or bool1 == true) then
				print((("[%*]: Roblox API services unavailable - data will not be saved"):format(script.Name)))
				str2 = if bool1 == true then "NoInternet" else "NoAccess"
			else
				print((("[%*]: Roblox API services available - data will be saved"):format(script.Name)))
				str2 = "Access"
			end
		else
			print((("[%*]: Roblox API services available - data will be saved"):format(script.Name)))
			str2 = "Access"
		end

		str1 = str2
		tbl7.DataStoreState = str2
	end)

else
	tbl7.DataStoreState = "Access"
	str1 = "Access"
end

var3.Heartbeat:Connect(function()
	local var4 = #AcquireRunnerThreadAndCallEventHandler
	local var5 = os.clock()
	local var6 = num1 / var4
	if 0 < var4 and var6 < var5 - var9 then
		local var7 = var9 + var6
		var9 = var7
		var7 = AcquireRunnerThreadAndCallEventHandler[num11]
		if var5 - var7.load_timestamp < num1 / 2 then
			var7 = nil
			for i1 = 1, var4 - 1 do
				local var8 = num11 + 1
				num11 = var8
				if var4 < num11 then
					num11 = 1
				end

				var7 = AcquireRunnerThreadAndCallEventHandler[num11]
				if num1 / 2 <= var5 - var7.load_timestamp then
					break
				end

				var7 = nil
			end
		end

		local var10 = num11 + 1
		num11 = var10
		if var4 < num11 then
			num11 = 1
		end

		if var7 ~= nil then
			task.spawn(SaveProfileAsync, var7)
		end
	end

	if tbl7.IsCriticalState == false then
		if num7 <= (#RunEventHandlerInFreeThread) then
			tbl7.IsCriticalState = true
			tbl7.OnCriticalToggle:Fire(true)
			num15 = os.clock()
			warn((("[%*]: Entered critical state"):format(script.Name)))
		end
	else
		if num7 <= (#RunEventHandlerInFreeThread) then
			num15 = os.clock()
		else
			if num9 < os.clock() - num15 then
				tbl7.IsCriticalState = false
				tbl7.OnCriticalToggle:Fire(false)
				warn((("[%*]: Critical state ended"):format(script.Name)))
			end
		end
	end

	while true do
		var6 = RunEventHandlerInFreeThread[1]
		if var6 == nil then
			return
		end

		if num8 >= os.clock() - var6 then
			break
		end

		table.remove(RunEventHandlerInFreeThread, 1)
		continue
	end
end)

task.spawn(function()
	while str1 == "NotReady" do
		task.wait()
	end

	if str1 ~= "Access" then
		game:BindToClose(function()
			tbl7.IsClosing = true
			task.wait()
		end)

		return
	end

	game:BindToClose(function()
		tbl7.IsClosing = true
		local num1 = 0
		local tbl1 = {}
		for k1, v1 in ipairs(AcquireRunnerThreadAndCallEventHandler) do
			tbl1[k1] = v1
		end

		for k2, v2 in ipairs(tbl1) do
			if v2:IsActive() ~= true then
				continue
			end

			num1 = num1 + 1
			task.spawn(function()
				SaveProfileAsync(v2, true, nil, "Shutdown")
				local var1 = num1 - 1
				num1 = var1
			end)

		end

		while 0 < num1 or 0 < num13 or 0 < num12 do
			task.wait()
		end
	end)
end)

return tbl7

--- ReplicatedStorage.ModuleLoader.Libs.SafeTeleport [ModuleScript]
-- y u r i

local var1 = game:GetService("TeleportService")
local function SafeTeleport(arg1, arg2, arg3)
	local num1 = 0
	local var2 = nil
	local var3 = nil
	repeat
		local success, result = pcall(function()
			local var2 = arg1
			local var3 = arg2
			local var4 = arg3
			return var1:TeleportAsync(var2, var3, var4)
		end)

		var2 = success
		num1 = num1 + 1
		var3 = result
		if not var2 then
			task.wait(1)
		end
	until var2 or num1 == 5

	return var2, var3
end

var1.TeleportInitFailed:Connect(function(arg1, arg2, arg3, arg4, arg5)
	if arg2 == Enum.TeleportResult.Flooded then
		task.wait(15)
	else
		if arg2 == Enum.TeleportResult.Failure then
			task.wait(1)
		else
			local var1 = arg2.Name
			local var2 = arg3
			error(("Invalid teleport [%s]: %s"):format(var1, var2))
		end
	end

	SafeTeleport(arg4, { arg1 }, arg5)
end)

return SafeTeleport

--- ReplicatedStorage.ModuleLoader.Libs.ReplicaServer [ModuleScript]
-- y u r i

local var1 = game.ReplicatedStorage.ReplicaShared
local var2 = require(var1.RateLimit)
local var3 = require(var1.Remote)
local var4 = require(var1.Signal)
local var5 = require(var1.Maid)
local tbl1 = {}
local tbl2 = {}
local var6 = game:GetService("CollectionService")
local var7 = game:GetService("ReplicatedStorage")
local var8 = game:GetService("Players")
if game:GetService("RunService"):IsClient() then
	return nil
end

local var9 = var2.New(120)
local var10 = var3.New("ReplicaRequestData")
local var11 = var3.New("ReplicaSet")
local var12 = var3.New("ReplicaSetValues")
local var13 = var3.New("ReplicaTableInsert")
local var14 = var3.New("ReplicaTableRemove")
local var15 = var3.New("ReplicaWrite")
local var16 = var3.New("ReplicaSignal")
local var17 = var3.New("ReplicaParent")
local var18 = var3.New("ReplicaCreate")
local var19 = var3.New("ReplicaBind")
local var20 = var3.New("ReplicaDestroy")
local var21 = var3.New("ReplicaSignalUnreliable", true)
local var22 = Instance.new("NumberValue")
var22.Name = "ReplicaBind"
var6:AddTag(var22, "REPLICA")
local tbl3 = {}
local function IterateGroup(arg1, arg2)
	arg2(arg1)
	for k1 in pairs(arg1.Children) do
		IterateGroup(k1, arg2)
	end
end

function GenerateCreation(arg1)
	local tbl1 = {}
	local tbl2 = {}
	local function fn2(arg1)
		local var1 = arg1.self_creation
		var1[4] = if arg1.Parent == nil then 0 else arg1.Parent.Id
		tbl1[tostring(arg1.Id)] = var1
		arg1.creation = tbl1
		arg1.replication = tbl2
	end

	local var1 = arg1.self_creation
	var1[4] = if arg1.Parent == nil then 0 else arg1.Parent.Id
	tbl1[tostring(arg1.Id)] = var1
	arg1.creation = tbl1
	arg1.replication = tbl2
	for k1 in pairs(arg1.Children) do
		IterateGroup(k1, fn2)
	end
end

local tbl4 = {}
local tbl5 = { ReadyPlayers = tbl4, NewReadyPlayer = var4.New() }
tbl5.RemovingReadyPlayer = var4.New()
tbl5.__index = tbl5
local tbl6 = {}
tbl6.__index = tbl6
local tbl7 = {}
tbl7.__index = tbl7
local tbl8 = {}
local tbl9 = {}
tbl5.Token = function(arg1)
	if type(arg1) ~= "string" then
		error((("[%*]: name must be a string"):format(script.Name)))
	end

	if tbl8[arg1] == true then
		error((("[%*]: Token \"%*\" duplicate"):format(script.Name, arg1)))
	end

	tbl8[arg1] = true
	local var1 = setmetatable({ Name = arg1 }, tbl6)
	tbl9[var1] = true
	return var1
end

local function LoadWriteLib(arg1)
	local var2 = tbl3[arg1]
	if var2 ~= nil then
		return var2
	end

	if typeof(arg1) ~= "Instance" or arg1:IsA("ModuleScript") ~= true then
		error((("[%*]: \"WriteLib\" is not a ModuleScript"):format(script.Name)))
	else
		if arg1:IsDescendantOf(var7) == false then
			error((("[%*]: \"WriteLib\" module must be a descendant of ReplicatedStorage"):format(script.Name)))
		end
	end

	local var3 = require(arg1)
	if type(var3) ~= "table" then
		error((("[%*]: A \"WriteLib\" ModuleScript must return a table"):format(script.Name)))
	end

	local tbl1 = {}
	for k1, v1 in pairs(var3) do
		if type(k1) ~= "string" then
			error((("[%*]: \"WriteLib\" table keys must be strings"):format(script.Name)))
		else
			if type(v1) ~= "function" then
				error((("[%*]: \"WriteLib\" table values must be functions"):format(script.Name)))
			end
		end

		table.insert(tbl1, { k1, v1 })
	end

	table.sort(tbl1, function(arg1, arg2)
		return arg1[1] < arg2[1]
	end)

	var2 = {}
	for k2, v2 in ipairs(tbl1) do
		local tbl2 = { Id = k2, fn = v2[2] }
		var2[v2[1]] = tbl2
		var2[k2] = tbl2
	end

	tbl3[arg1] = var2
	return var2
end

local num1 = 0
local tbl10 = {}
tbl5.New = function(arg1)
	local var1 = arg1.Tags
	local var2 = arg1.Data
	local var3 = arg1.Token
	var1 = var1 or {}
	var2 = var2 or {}
	local var6 = nil
	if tbl9[var3] == nil then
		error((("[%*]: \"Token\" is not valid (%*)"):format(script.Name, (tostring(var3)))))
	else
		if type(var1) ~= "table" then
			error((("[%*]: \"Tags\" is not a table"):format(script.Name)))
		else
			if type(var2) ~= "table" then
				error((("[%*]: \"Data\" is not a table"):format(script.Name)))
			else
				if var1.Bind ~= nil then
					error((("[%*]: \"Tags.Bind\" key is reserved"):format(script.Name)))
				end
			end
		end
	end

	if arg1.WriteLib ~= nil then
		var6 = LoadWriteLib(arg1.WriteLib)
	end

	local var7 = num1 + 1
	num1 = var7
	local tbl2 = {
		Tags = var1,
		Data = var2,
		Id = num1,
		Token = var3.Name,
		Parent = nil,
		Children = {},
		BoundInstance = nil,
		OnServerEvent = var4.New(),
		creation = nil,
		replication = nil,
		bind_value = nil,
	}

	tbl2.Maid = var5.New(tbl1)
	tbl2.self_creation = { var3.Name, var1, var2, 0, arg1.WriteLib }
	tbl2.write_lib = var6
	tbl2.write_lib_module = arg1.WriteLib
	var7 = setmetatable(tbl2, tbl5)
	tbl10[num1] = var7
	return var7
end

tbl5.FromId = function(arg1)
	return tbl10[arg1]
end

local tbl11 = {}
local tbl12 = {}
local tbl13 = {}
tbl5.Test = function()
	return {
		Replicas = tbl10,
		TopReplicas = tbl11,
		ReplicationAllReplicas = tbl12,
		SelectiveSubscriptions = tbl13,
	}
end

local bool1 = false
tbl5.Set = function(arg1, arg2, arg3)
	local var1 = arg1.Data
	for i1 = 1, #arg2 - 1 do
		var1 = var1[arg2[i1]]
	end

	var1[arg2[#arg2]] = arg3
	if bool1 == false then
		local var2 = arg1.Id
		if arg1.replication ~= nil then
			local var3
			if arg1.replication.ALL == true then
				for k1 in pairs(tbl4) do
					var11:FireClient(k1, var2, arg2, arg3)
				end

				return
			end

			for k2 in pairs(arg1.replication) do
				var11:FireClient(k2, var2, arg2, arg3)
			end
		end
	end
end

tbl5.SetValues = function(arg1, arg2, arg3)
	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	for k2, v2 in pairs(arg3) do
		var1[k2] = v2
	end

	if bool1 == false then
		local var2 = arg1.Id
		if arg1.replication ~= nil then
			local var3
			if arg1.replication.ALL == true then
				for k3 in pairs(tbl4) do
					var12:FireClient(k3, var2, arg2, arg3)
				end

				return
			end

			for k4 in pairs(arg1.replication) do
				var12:FireClient(k4, var2, arg2, arg3)
			end
		end
	end
end

tbl5.TableInsert = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	if arg4 ~= nil then
		table.insert(var1, arg4, arg3)
	else
		table.insert(var1, arg3)
	end

	if bool1 == false then
		local var2 = arg1.Id
		if arg1.replication ~= nil then
			if arg1.replication.ALL == true then
				for k2 in pairs(tbl4) do
					var13:FireClient(k2, var2, arg2, arg3, arg4)
				end
			else
				for k3 in pairs(arg1.replication) do
					var13:FireClient(k3, var2, arg2, arg3, arg4)
				end
			end
		end
	end

	local var3 = arg4
	return var3 or (#var1)
end

tbl5.TableRemove = function(arg1, arg2, arg3)
	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	local var2 = table.remove(var1, arg3)
	if bool1 == false then
		local var3 = arg1.Id
		if arg1.replication ~= nil then
			local var4
			if arg1.replication.ALL == true then
				for k2 in pairs(tbl4) do
					var14:FireClient(k2, var3, arg2, arg3)
				end

				return var2
			end

			for k3 in pairs(arg1.replication) do
				var14:FireClient(k3, var3, arg2, arg3)
			end
		end
	end

	return var2
end

tbl5.Write = function(arg1, arg2, ...)
	local var3 = arg1.write_lib[arg2]
	if bool1 == true then
		local var4 = arg1
		return var3.fn(var4, ...)
	end

	bool1 = true
	local var5 = var3.fn
	local var6 = arg1
	local var7 = table.pack(pcall(var5, var6, ...))
	bool1 = false
	if var7[1] ~= true then
		error(("[%*]: (WriteLib) "):format(script.Name) .. tostring(var7[2]))
	end

	table.remove(var7, 1)
	local var8 = arg1.Id
	var5 = var3.Id
	if arg1.replication ~= nil then
		if arg1.replication.ALL == true then
			for k1 in pairs(tbl4) do
				var15:FireClient(k1, var8, var5, ...)
			end
		else
			for k2 in pairs(arg1.replication) do
				var15:FireClient(k2, var8, var5, ...)
			end
		end
	end

	local var9 = var7
	return table.unpack(var9)
end

tbl5.FireClient = function(arg1, arg2, ...)
	if arg1.replication ~= nil and (arg1.replication.ALL == true and tbl4[arg2] == true or arg1.replication[arg2] ~= nil) then
		var16:FireClient(arg2, arg1.Id, ...)
	end
end

tbl5.FireAllClients = function(arg1, ...)
	local var1 = arg1.Id
	if arg1.replication ~= nil then
		local var2
		if arg1.replication.ALL == true then
			for k1 in pairs(tbl4) do
				var16:FireClient(k1, var1, ...)
			end

			return
		end

		for k2 in pairs(arg1.replication) do
			var16:FireClient(k2, var1, ...)
		end
	end
end

tbl5.UFireClient = function(arg1, arg2, ...)
	if arg1.replication ~= nil and (arg1.replication.ALL == true and tbl4[arg2] == true or arg1.replication[arg2] ~= nil) then
		var21:FireClient(arg2, arg1.Id, ...)
	end
end

tbl5.UFireAllClients = function(arg1, ...)
	local var1 = arg1.Id
	if arg1.replication ~= nil then
		local var2
		if arg1.replication.ALL == true then
			for k1 in pairs(tbl4) do
				var21:FireClient(k1, var1, ...)
			end

			return
		end

		for k2 in pairs(arg1.replication) do
			var21:FireClient(k2, var1, ...)
		end
	end
end

tbl5.SetParent = function(arg1, arg2)
	if type(arg2) ~= "table" or getmetatable(arg2) ~= tbl5 then
		error((("[%*]: new_parent is not a Replica (%*)"):format(script.Name, (tostring(arg2)))))
	else
		if tbl10[arg2.Id] == nil then
			error((("[%*]: Can't set destroyed Replica as parent"):format(script.Name)))
		end
	end

	if tbl11[arg1] ~= nil then
		error((("[%*]: Can't change parent for top level Replica"):format(script.Name)))
	end

	if arg1.BoundInstance ~= nil then
		error((("[%*]: Can't change parent for bound Replica"):format(script.Name)))
	end

	local var1 = arg2
	var1 = var1.Parent
	while var1 == nil and var1 == arg1 do
	end

	local var3 = arg1.Parent
	if var3 == arg2 then
		return
	end

	arg1.Parent = arg2
	if var3 ~= nil then
		var3.Children[arg1] = nil
	end

	arg2.Children[arg1] = true
	local function fn2(arg1)
		local var1 = tostring(arg1.Id)
		if var3 ~= nil and var3.creation ~= nil then
			var3.creation[var1] = nil
		end

		if arg2.creation ~= nil then
			local var2 = arg1.self_creation
			var2[4] = arg1.Parent.Id
			arg2.creation[var1] = var2
		end

		arg1.creation = arg2.creation
		arg1.replication = arg2.replication
	end

	local var4 = tostring(arg1.Id)
	if var3 ~= nil and var3.creation ~= nil then
		var3.creation[var4] = nil
	end

	if arg2.creation ~= nil then
		local var5 = arg1.self_creation
		var5[4] = arg1.Parent.Id
		arg2.creation[var4] = var5
	end

	arg1.creation = arg2.creation
	arg1.replication = arg2.replication
	for k1 in pairs(arg1.Children) do
		local var6 = fn2
		IterateGroup(k1, var6)
	end

	fn2 = arg1.Id
	var4 = arg2.Id
	local var8 = arg2.creation
	local var9 = tbl2
	if var3 ~= nil then
		if var3.replication ~= nil then
			var9 = if var3.replication.ALL == true then tbl4 else var3.replication
		end
	end

	local var11 = tbl2
	if arg2 ~= nil then
		if arg2.replication ~= nil then
			var11 = if arg2.replication.ALL == true then tbl4 else arg2.replication
		end
	end

	if var3 ~= nil and (var3.replication ~= nil and (arg2.replication ~= var3.replication and var11 ~= tbl4)) then
		for k2 in pairs(var9) do
			if var11[k2] ~= nil then
				continue
			end

			var20:FireClient(k2, fn2)
		end
	end

	if arg2.replication ~= nil then
		local var12 = nil
		for k3 in pairs(var11) do
			local var13
			if var9[k3] == true then
				var13 = var4
				var17:FireClient(k3, fn2, var13)
			elseif var12 == nil then
				var12 = {}
				local var14 = tostring(arg1.Id)
				var12[var14] = var8[var14]
				local function fn4(arg1)
					local var1 = tostring(arg1.Id)
					var12[var1] = var8[var1]
				end

				for k4 in pairs(arg1.Children) do
					IterateGroup(k4, fn4)
				end
			end
		end
	end
end

tbl5.BindToInstance = function(arg1, arg2)
	local var1
	if typeof(arg2) ~= "Instance" then
		var1 = arg2
		error((("[%*]: \"instance\" argument is not an Instance (%*)"):format(script.Name, (tostring(var1)))))
	end

	if arg1.Parent ~= nil then
		error((("[%*]: Can't bind Replica parented to another Replica"):format(script.Name)))
	end

	if arg1.BoundInstance ~= nil then
		error((("[%*]: Can't change Replica bind to another Instance"):format(script.Name)))
	end

	if arg2:IsA("Model") == true and (arg2.ModelStreamingMode == Enum.ModelStreamingMode.Default or arg2.ModelStreamingMode == Enum.ModelStreamingMode.Nonatomic) then
		warn(([=[[%*]: Bound Replica to a model that has improper "ModelStreamingMode" setup; Traceback:
]=]):format(script.Name) .. debug.traceback())

	end

	local var2 = var22:Clone()
	var2.Value = arg1.Id
	arg1.Tags.Bind = true
	arg1.BoundInstance = arg2
	arg1.bind_value = var2
	var2.Parent = arg2
	local var3 = arg1.Id
	if arg1.replication ~= nil then
		if arg1.replication.ALL == true then
			for k1 in pairs(tbl4) do
				var19:FireClient(k1, var3)
			end

			return
		end

		for k2 in pairs(arg1.replication) do
			var19:FireClient(k2, var3)
		end
	end
end

tbl5.Replicate = function(arg1)
	if arg1.Parent ~= nil then
		error((("[%*]: Can't selectively replicate Replica parented to another Replica"):format(script.Name)))
	end

	if arg1.creation == nil then
		GenerateCreation(arg1)
		tbl11[arg1] = true
	else
		if arg1.replication.ALL == true then
			return
		end
	end

	local var1 = arg1.creation
	local var2 = arg1.replication
	for k1 in pairs(tbl4) do
		if var2[k1] == nil then
			var18:FireClient(k1, var1)
		else
			tbl13[k1][arg1] = nil
		end
	end

	table.clear(var2)
	var2.ALL = true
	tbl12[arg1] = true
end

tbl5.DontReplicate = function(arg1)
	if arg1.Parent ~= nil then
		error((("[%*]: Can't selectively replicate Replica parented to another Replica"):format(script.Name)))
	end

	local var2 = arg1.replication
	if var2 == nil or next(var2) == nil then
		return
	end

	tbl12[arg1] = nil
	local var3 = arg1.Id
	if var2.ALL == true then
		for k1 in pairs(tbl4) do
			var20:FireClient(k1, var3)
		end
	else
		for k2 in pairs(var2) do
			var20:FireClient(k2, var3)
			tbl13[k2][arg1] = nil
		end
	end

	table.clear(var2)
end

tbl5.Subscribe = function(arg1, arg2)
	if arg1.Parent ~= nil then
		error((("[%*]: Can't selectively replicate Replica parented to another Replica"):format(script.Name)))
	end

	if arg1.creation == nil then
		GenerateCreation(arg1)
		tbl11[arg1] = true
	else
		if arg1.replication.ALL == true then
			error((([=[[%*]: "Subscribe()" is locked after calling "Replicate()"]=]):format(script.Name)))
		end
	end

	if tbl4[arg2] == nil then
		warn(([=[[%*]: Called "Subscribe()" on a non-ready player; Traceback:
]=]):format(script.Name) .. debug.traceback())

		return
	end

	local var1 = arg1.replication
	local var2 = arg1.creation
	if var1[arg2] ~= nil then
		return
	end

	var1[arg2] = true
	tbl13[arg2][arg1] = true
	var18:FireClient(arg2, var2)
end

tbl5.Unsubscribe = function(arg1, arg2)
	if arg1.Parent ~= nil then
		error((("[%*]: Can't selectively replicate Replica parented to another Replica"):format(script.Name)))
	end

	local var2 = arg1.replication
	if var2 == nil then
		return
	end

	if var2.ALL == true then
		error((([=[[%*]: "Unsubscribe()" is locked after calling "Replicate()"]=]):format(script.Name)))
	end

	if var2[arg2] ~= nil then
		var2[arg2] = nil
		tbl13[arg2][arg1] = nil
		var20:FireClient(arg2, arg1.Id)
	end
end

tbl5.Identify = function(arg1)
	local str1 = ""
	local bool1 = true
	for k1, v1 in pairs(arg1.Tags) do
		local var1 = str1
		local str2 = "%*%*=%*"
		str1 = var1 .. str2:format(if bool1 == true then "" else ";", tostring(k1), (tostring(v1)))
		local bool2 = false
	end

	return (("[Id:%*;Token:%*;Tags:[%*]]"):format(arg1.Id, arg1.Token, str1))
end

tbl5.IsActive = function(arg1)
	return arg1.Maid:IsActive()
end

local function DestroyReplica(arg1)
	for k1 in pairs(arg1.Children) do
		DestroyReplica(k1)
	end

	local var1 = arg1.Id
	tbl10[var1] = nil
	arg1.Maid:Unlock(tbl1)
	arg1.Maid:Cleanup()
	if arg1.BoundInstance ~= nil then
		arg1.BoundInstance = nil
		arg1.bind_value:Destroy()
		arg1.bind_value = nil
	end

	if arg1.creation ~= nil then
		local var2 = tostring(var1)
		arg1.creation[var2] = nil
	end

	setmetatable(arg1, tbl7)
end

tbl5.Destroy = function(arg1)
	local var1 = arg1.Id
	if tbl10[var1] == nil then
		return
	end

	local var2 = tbl11[arg1] == true
	if arg1.replication ~= nil then
		if arg1.replication.ALL == true then
			for k1 in pairs(tbl4) do
				var20:FireClient(k1, var1)
			end
		else
			for k2 in pairs(arg1.replication) do
				var20:FireClient(k2, var1)
				if var2 ~= true then
					continue
				end

				tbl13[k2][arg1] = nil
			end
		end
	end

	tbl11[arg1] = nil
	tbl12[arg1] = nil
	if arg1.Parent ~= nil then
		arg1.Parent.Children[arg1] = nil
	end

	DestroyReplica(arg1)
end

local tbl14 = { Identify = true, Destroy = true }
for k1, v3 in pairs(tbl5) do
	if k1 == "__index" then
		continue
	end

	if tbl14[k1] == true then
		tbl7[k1] = v3
	else
		tbl7[k1] = function(arg1)
			error((("[%*]: Tried to call method \"%*\" for a destroyed replica; %*"):format(script.Name, k1, (arg1:Identify()))))
		end

	end
end

var10.OnServerEvent:Connect(function(arg1)
	if tbl4[arg1] ~= nil and arg1:IsDescendantOf(var8) == true then
		return
	end

	local tbl1 = {}
	for k1 in pairs(tbl12) do
		table.insert(tbl1, k1.creation)
	end

	var18:FireClient(arg1, tbl1)
	var10:FireClient(arg1)
	tbl4[arg1] = true
	tbl13[arg1] = {}
	tbl5.NewReadyPlayer:Fire(arg1)
end)

tbl14 = function(arg1, arg2, ...)
	if tbl4[arg1] == nil or (var9:CheckRate(arg1) == false or type(arg2) ~= "number") then
		return
	end

	local var2 = tbl10[arg2]
	if var2 ~= nil and (var2.replication ~= nil and (var2.replication.ALL == true or var2.replication[arg1] ~= nil)) then
		var2.OnServerEvent:Fire(arg1, ...)
	end
end

var16.OnServerEvent:Connect(tbl14)
var21.OnServerEvent:Connect(tbl14)
var8.PlayerRemoving:Connect(function(arg1)
	if tbl4[arg1] == nil then
		return
	end

	local var1 = tbl13
	for k1 in pairs(var1[arg1]) do
		k1.replication[arg1] = nil
	end

	tbl4[arg1] = nil
	tbl13[arg1] = nil
	tbl5.RemovingReadyPlayer:Fire(arg1)
end)

return tbl5

--- ReplicatedStorage.ModuleLoader.Libs.ReplicaClient [ModuleScript]
-- y u r i

local var1 = game.ReplicatedStorage.ReplicaShared
game:GetService("ReplicatedStorage")
game:GetService("Players")
local var2 = require(var1.Remote)
local var3 = require(var1.Signal)
local var4 = require(var1.Maid)
local tbl1 = {}
local var5 = game:GetService("CollectionService")
if game:GetService("RunService"):IsServer() then
	return nil
end

local tbl2 = {}
local var6 = nil
local function AcquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var1 = var6
	var6 = nil
	arg1(...)
	var6 = var1
end

local var7 = var2.New("ReplicaRequestData")
local var8 = var2.New("ReplicaSet")
local var9 = var2.New("ReplicaSetValues")
local var10 = var2.New("ReplicaTableInsert")
local var11 = var2.New("ReplicaTableRemove")
local var12 = var2.New("ReplicaWrite")
local var13 = var2.New("ReplicaSignal")
local var14 = var2.New("ReplicaParent")
local var15 = var2.New("ReplicaCreate")
local var16 = var2.New("ReplicaBind")
local var17 = var2.New("ReplicaDestroy")
local var18 = var2.New("ReplicaSignalUnreliable", true)
local tbl3 = { IsReady = false, OnLocalReady = var3.New() }
tbl3.__index = tbl3
local function LoadWriteLib(arg1)
	local var2 = tbl2[arg1]
	if var2 ~= nil then
		return var2
	end

	local tbl1 = {}
	for k1, v1 in pairs((require(arg1))) do
		table.insert(tbl1, { k1, v1 })
	end

	table.sort(tbl1, function(arg1, arg2)
		return arg1[1] < arg2[1]
	end)

	var2 = {}
	for k2, v2 in ipairs(tbl1) do
		local tbl3 = { Name = v2[1], Id = k2, fn = v2[2] }
		var2[v2[1]] = tbl3
		var2[k2] = tbl3
	end

	tbl2[arg1] = var2
	return var2
end

local tbl4 = {}
local tbl5 = {}
local bool1 = false
tbl3.RequestData = function()
	if bool1 == true then
		return
	end

	bool1 = true
	task.spawn(function()
		var7:FireServer()
		while task.wait(2) and tbl3.IsReady ~= true do
			var7:FireServer()
		end
	end)
end

local tbl6 = {}
local tbl7 = {}
local function RunEventHandlerInFreeThread(...)
	AcquireRunnerThreadAndCallEventHandler(...)
	while true do
		AcquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl3.OnNew = function(arg1, arg2)
	if type(arg1) ~= "string" then
		error((("[%*]: \"token\" must be a string"):format(script.Name)))
	end

	local var2 = tbl6[arg1]
	if var2 == nil then
		var2 = var3.New()
		tbl6[arg1] = var2
	end

	local var5 = tbl7[arg1]
	local var7 = var2:Connect(arg2)
	if var5 ~= nil then
		local tbl1 = {}
		for k1 in pairs(var5) do
			tbl1[k1] = true
		end

		task.defer(function()
			for k1 in pairs(tbl1) do
				if var7.IsConnected ~= true then
					break
				end

				if not var6 then
					var6 = coroutine.create(RunEventHandlerInFreeThread)
				end

				task.spawn(var6, arg2, k1)
			end
		end)

	end

	return var7
end

tbl3.FromId = function(arg1)
	return tbl5[arg1]
end

local tbl8 = {}
tbl3.Test = function()
	return { TokenReplicas = tbl7, Replicas = tbl5, BindReplicas = tbl4, BindInstances = tbl8 }
end

tbl3.OnSet = function(arg1, arg2, arg3)
	local var1 = table.concat(arg2, ".")
	local var4 = arg1.set_listeners[var1]
	if var4 == nil then
		var4 = var3.New()
		arg1.set_listeners[var1] = var4
	end

	local var5 = arg3
	return var4:Connect(var5)
end

tbl3.OnWrite = function(arg1, arg2, arg3)
	local var2 = arg1.write_listeners[arg2]
	if var2 == nil then
		var2 = var3.New()
		arg1.write_listeners[arg2] = var2
	end

	local var4 = arg3
	return var2:Connect(var4)
end

tbl3.OnChange = function(arg1, arg2)
	local var1 = arg2
	return arg1.changed_listeners:Connect(var1)
end

tbl3.GetChild = function(arg1, arg2)
	local var2
	if type(arg2) ~= "string" then
		var2 = script.Name
		error((("[%*]: \"token\" must be a string"):format(var2)))
	end

	for k1 in pairs(arg1.Children) do
		if k1.Token ~= arg2 then
			continue
		end

		return k1
	end

	return nil
end

tbl3.FireServer = function(arg1, ...)
	var13:FireServer(arg1.Id, ...)
end

tbl3.UFireServer = function(arg1, ...)
	var18:FireServer(arg1.Id, ...)
end

tbl3.Identify = function(arg1)
	local str1 = ""
	local bool1 = true
	for k1, v1 in pairs(arg1.Tags) do
		local var1 = str1
		local str2 = "%*%*=%*"
		str1 = var1 .. str2:format(if bool1 == true then "" else ";", tostring(k1), (tostring(v1)))
		local bool2 = false
	end

	return (("[Id:%*;Token:%*;Tags:[%*]]"):format(arg1.Id, arg1.Token, str1))
end

tbl3.IsActive = function(arg1)
	return arg1.Maid:IsActive()
end

local bool2 = false
tbl3.Set = function(arg1, arg2, arg3)
	if bool2 ~= true then
		error((("[%*]: \"Set()\" can't be called outside of WriteLibs client-side"):format(script.Name)))
	end

	local var1 = arg1.Data
	for i1 = 1, #arg2 - 1 do
		var1 = var1[arg2[i1]]
	end

	local var2 = arg2[#arg2]
	local var3 = var1[var2]
	var1[var2] = arg3
	local var5 = arg1.set_listeners[table.concat(arg2, ".")]
	if next(arg1.set_listeners) ~= nil and var5 ~= nil then
		var5:Fire(arg3, var3)
	end

	arg1.changed_listeners:Fire("Set", arg2, arg3, var3)
end

tbl3.SetValues = function(arg1, arg2, arg3)
	if bool2 ~= true then
		error((("[%*]: \"SetValues()\" can't be called outside of WriteLibs client-side"):format(script.Name)))
	end

	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	for k2, v2 in pairs(arg3) do
		var1[k2] = v2
	end

	arg1.changed_listeners:Fire("SetValues", arg2, arg3)
end

tbl3.TableInsert = function(arg1, arg2, arg3, arg4)
	if bool2 ~= true then
		error((("[%*]: \"TableInsert()\" can't be called outside of WriteLibs client-side"):format(script.Name)))
	end

	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	if arg4 ~= nil then
		table.insert(var1, arg4, arg3)
	else
		table.insert(var1, arg3)
		arg4 = #var1
	end

	arg1.changed_listeners:Fire("TableInsert", arg2, arg3, arg4)
	return arg4
end

tbl3.TableRemove = function(arg1, arg2, arg3)
	if bool2 ~= true then
		error((("[%*]: \"TableRemove()\" can't be called outside of WriteLibs client-side"):format(script.Name)))
	end

	local var1 = arg1.Data
	for k1, v1 in ipairs(arg2) do
		var1 = var1[v1]
	end

	local var2 = table.remove(var1, arg3)
	arg1.changed_listeners:Fire("TableRemove", arg2, var2, arg3)
	return var2
end

tbl3.Write = function(arg1, arg2, ...)
	if bool2 ~= true then
		error((("[%*]: \"Write()\" can't be called outside of WriteLibs client-side"):format(script.Name)))
	end

	local var1 = arg1
	local var2 = table.pack(arg1.write_lib[arg2].fn(var1, ...))
	local var4 = arg1.write_listeners[arg2]
	if var4 ~= nil then
		var4:Fire(...)
	end

	local var5 = var2
	return table.unpack(var5)
end

local function ReplicaNew(arg1, arg2)
	local var2 = nil
	if arg2[5] ~= nil then
		var2 = LoadWriteLib(arg2[5])
	end

	local var5 = tbl4[arg2[4]]
	var5 = var5 or tbl5[arg2[4]]
	local tbl2 = {
		Tags = arg2[2],
		Data = arg2[3],
		Id = arg1,
		Token = arg2[1],
		Parent = var5,
		Children = {},
		BoundInstance = nil,
		OnClientEvent = var3.New(),
	}

	tbl2.Maid = var4.New(tbl1)
	tbl2.self_creation = arg2
	tbl2.write_lib = var2
	tbl2.set_listeners = {}
	tbl2.write_listeners = {}
	tbl2.changed_listeners = var3.New()
	local var7 = setmetatable(tbl2, tbl3)
	if var5 ~= nil then
		var5.Children[var7] = true
	end

	return var7
end

local function DestroyReplica(arg1, arg2)
	for k1 in pairs(arg1.Children) do
		DestroyReplica(k1, true)
	end

	if arg2 ~= true and arg1.Parent ~= nil then
		arg1.Parent.Children[arg1] = nil
	end

	local var2 = tbl7[arg1.Token]
	local var3 = arg1.Id
	if var2 ~= nil then
		var2[arg1] = nil
	end

	if tbl5[var3] == arg1 then
		tbl5[var3] = nil
	end

	if tbl4[var3] == arg1 then
		tbl4[var3] = nil
	end

	arg1.Maid:Unlock(tbl1)
	arg1.Maid:Cleanup()
	arg1.BoundInstance = nil
end

local function CreationScan(arg1, arg2, arg3)
	local var2 = arg1[arg3]
	if var2 ~= nil then
		table.sort(var2, function(arg1, arg2)
			return arg1.Id < arg2.Id
		end)

		for k1, v1 in ipairs(var2) do
			arg2(v1.Id, v1.SelfCreation)
			CreationScan(arg1, arg2, v1.Id)
		end
	end
end

var7.OnClientEvent:Connect(function()
	if tbl3.IsReady == true then
		return
	end

	tbl3.IsReady = true
	tbl3.OnLocalReady:Fire()
end)

var8.OnClientEvent:Connect(function(arg1, arg2, arg3)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	bool2 = true
	local success, result = pcall(var1.Set, var1, arg2, arg3)
	bool2 = false
	if success ~= true then
		error(([=[[%*]: Error while updating replica:
%*
]=]):format(script.Name, (var1:Identify())) .. result)

	end
end)

var9.OnClientEvent:Connect(function(arg1, arg2, arg3)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	bool2 = true
	local success, result = pcall(var1.SetValues, var1, arg2, arg3)
	bool2 = false
	if success ~= true then
		error(([=[[%*]: Error while updating replica:
%*
]=]):format(script.Name, (var1:Identify())) .. result)

	end
end)

var10.OnClientEvent:Connect(function(arg1, arg2, arg3, arg4)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	bool2 = true
	local success, result = pcall(var1.TableInsert, var1, arg2, arg3, arg4)
	bool2 = false
	if success ~= true then
		error(([=[[%*]: Error while updating replica:
%*
]=]):format(script.Name, (var1:Identify())) .. result)

	end
end)

var11.OnClientEvent:Connect(function(arg1, arg2, arg3)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	bool2 = true
	local success, result = pcall(var1.TableRemove, var1, arg2, arg3)
	bool2 = false
	if success ~= true then
		error(([=[[%*]: Error while updating replica:
%*
]=]):format(script.Name, (var1:Identify())) .. result)

	end
end)

var12.OnClientEvent:Connect(function(arg1, arg2, ...)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	bool2 = true
	local success, result = pcall(var1.Write, var1, var1.write_lib[arg2].Name, ...)
	bool2 = false
	if success ~= true then
		error(([=[[%*]: Error while updating replica:
%*
]=]):format(script.Name, (var1:Identify())) .. result)

	end
end)

local function RemoteSignalHandle(arg1, ...)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	var1.OnClientEvent:Fire(...)
end

var13.OnClientEvent:Connect(RemoteSignalHandle)
var18.OnClientEvent:Connect(RemoteSignalHandle)
local function ReplicaFromBindBuffer(arg1, arg2)
	local bool2 = false
	if arg2 == nil then
		arg2 = {}
		bool2 = true
	end

	tbl4[arg1.Id] = nil
	local var1 = arg1.Token
	local var3 = tbl7[var1]
	if var3 == nil then
		var3 = {}
		tbl7[var1] = var3
	end

	var3[arg1] = true
	tbl5[arg1.Id] = arg1
	table.insert(arg2, arg1)
	for k1 in pairs(arg1.Children) do
		ReplicaFromBindBuffer(k1, arg2)
	end

	if bool2 == true then
		for k2, v1 in ipairs(arg2) do
			local var4 = tbl6[v1.Token]
			if var4 == nil then
				continue
			end

			var4:Fire(v1)
		end
	end
end

local function ReplicaToBindBuffer(arg1, arg2)
	local var1 = ReplicaNew(arg1.Id, arg1.self_creation)
	tbl4[arg1.Id] = var1
	for k1 in pairs(arg1.Children) do
		ReplicaToBindBuffer(k1, true)
	end

	if arg2 ~= true then
		DestroyReplica(arg1)
	end

	return var1
end

var14.OnClientEvent:Connect(function(arg1, arg2)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	local var2 = tbl5[arg2]
	var2 = var2 or tbl4[arg2]
	local var3 = var1.Parent
	if var2 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg2)))
	end

	var3.Children[var1] = nil
	var2.Children[var1] = true
	var1.Parent = var2
	var1.self_creation[4] = arg2
	if tbl4[var3.Id] ~= nil and tbl5[arg2] ~= nil then
		ReplicaFromBindBuffer(var1)
		return
	end

	if tbl5[var3.Id] ~= nil and tbl4[arg2] ~= nil then
		ReplicaToBindBuffer(var1)
	end
end)

local function BreadthCreationSort(arg1, arg2, arg3)
	local tbl1 = {}
	local tbl2 = {}
	local tbl3 = {}
	local var1
	local var2
	local var3
	if type(arg1[1]) == "table" then
		for k1, v1 in ipairs(arg1) do
			for k2, v2 in pairs(v1) do
				local tbl4 = { Id = tonumber(k2) }
				tbl4.SelfCreation = v2
				local var5 = v2[4]
				if var5 == 0 or tbl4.Id == arg2 then
					var1 = tbl1
					table.insert(var1, tbl4)
				else
					if v1[tostring(var5)] ~= nil then
						var3 = tbl2[var5]
						if var3 == nil then
							var3 = {}
							tbl2[var5] = var3
						end

						table.insert(var3, tbl4)
					else
						var1 = tbl3
						table.insert(var1, tbl4)
					end
				end
			end
		end
	else
		for k3, v3 in pairs(arg1) do
			var2 = { Id = tonumber(k3) }
			var2.SelfCreation = v3
			local var7 = v3[4]
			if var7 == 0 or var2.Id == arg2 then
				table.insert(tbl1, var2)
			else
				if arg1[tostring(var7)] ~= nil then
					local var10 = tbl2[var7]
					if var10 == nil then
						var10 = {}
						tbl2[var7] = var10
					end

					table.insert(var10, var2)
				else
					table.insert(tbl3, var2)
				end
			end
		end
	end

	table.sort(tbl1, function(arg1, arg2)
		return arg1.Id < arg2.Id
	end)

	local tbl5 = {}
	for k4, v4 in ipairs(tbl1) do
		arg3(v4.Id, v4.SelfCreation)
		CreationScan(tbl2, arg3, v4.Id)
	end

	if #tbl3 ~= 0 then
		local var11 = ([=[[%*]: GROUP REPLICATION ERROR - Missing parents for:
]=]):format(script.Name)

		for i1 = 1, math.min(#tbl3, 50) do
			local var12 = tbl3[i1]
			local var13 = var12.SelfCreation
			local str1 = ""
			local bool1 = true
			for k5, v5 in pairs(var13[2]) do
				local var14 = str1
				local str2 = "%*%*=%*"
				str1 = var14 .. str2:format(if bool1 == true then "" else ";", tostring(k5), (tostring(v5)))
				local bool2 = false
			end

			local var15 = var12.Id
			local var16 = var13[4]
			var11 = var11 .. ("[Id:%*;ParentId:%*;Token:%*;Tags:[%*]]\n"):format(var15, var16, var13[1], str1)
		end

		if 50 < (#tbl3) then
			var11 = var11 .. ([[(hiding %* more)
]]):format(50 - #tbl3)

		end

		warn(var11 .. [[Traceback:
]] .. debug.traceback())

	end

	return tbl5
end

var15.OnClientEvent:Connect(function(arg1, arg2)
	local tbl1 = {}
	BreadthCreationSort(arg1, arg2, function(arg1, arg2)
		local var3 = arg2[4]
		local var4 = ReplicaNew(arg1, arg2)
		local bool1 = false
		if var3 == 0 then
			if var4.Tags.Bind == true then
				local var5 = tbl8[arg1]
				var4.BoundInstance = var5
				if var5 == nil then
					bool1 = true
				end
			end
		else
			if tbl4[var3] ~= nil then
				bool1 = true
			end
		end

		if bool1 == true then
			tbl4[arg1] = var4
			return
		end

		local var6 = var4.Token
		local var8 = tbl7[var6]
		if var8 == nil then
			var8 = {}
			tbl7[var6] = var8
		end

		var8[var4] = true
		tbl5[arg1] = var4
		table.insert(tbl1, var4)
	end)

	for k1, v1 in ipairs(tbl1) do
		local var1 = tbl6[v1.Token]
		if var1 == nil then
			continue
		end

		var1:Fire(v1)
	end
end)

var16.OnClientEvent:Connect(function(arg1)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	var1.Tags.Bind = true
	local var2 = tbl8[arg1]
	var1.BoundInstance = var2
	if var2 == nil then
		ReplicaToBindBuffer(var1)
	end
end)

var17.OnClientEvent:Connect(function(arg1)
	local var1 = tbl5[arg1]
	var1 = var1 or tbl4[arg1]
	if var1 == nil then
		error((("[%*]: Received update for missing replica [Id:%*]"):format(script.Name, arg1)))
	end

	DestroyReplica(var1)
end)

var5:GetInstanceAddedSignal("REPLICA"):Connect(function(arg1)
	if arg1:IsA("NumberValue") == true then
		local var1 = arg1.Parent
		local var2 = arg1.Value
		tbl8[var2] = var1
		local var4 = tbl4[var2]
		if var4 ~= nil then
			var4.BoundInstance = var1
			ReplicaFromBindBuffer(var4)
		end
	end
end)

var5:GetInstanceRemovedSignal("REPLICA"):Connect(function(arg1)
	if arg1:IsA("NumberValue") == true then
		local var1 = arg1.Value
		tbl8[var1] = nil
		local var3 = tbl5[var1]
		if var3 ~= nil then
			ReplicaToBindBuffer(var3)
		end
	end
end)

local str1 = "REPLICA"
for k1, v5 in pairs(var5:GetTagged(str1)) do
	if v5:IsA("NumberValue") ~= true then
		continue
	end

	local var19 = v5.Parent
	local var20 = v5.Value
	tbl8[var20] = var19
	local var21 = tbl4[var20]
	if var21 == nil then
		continue
	end

	var21.BoundInstance = var19
	ReplicaFromBindBuffer(var21)
end

return tbl3

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone [ModuleScript]
-- y u r i

require(script.Types)
local var1 = require(script.Core.State)
local var2 = game:GetService("RunService")
local var3 = require(script.Config)
local var4 = require(script.Core.Scheduler)
local var5 = require(script.Utils.LinearBVH).queryPoint
local var6 = require(script.Utils.Geometry).isPointInShape
local tbl1 = { Zone = require(script.Classes.Zone) }
tbl1.Observer = require(script.Classes.Observer)
tbl1.Group = require(script.Classes.Group)
tbl1.configure = function(arg1, arg2)
	if arg2.enabled ~= nil then
		arg1:setEnabled(arg2.enabled)
	end

	if arg2.autoSyncRate ~= nil then
		arg1:setAutoSyncRate(arg2.autoSyncRate)
	end

	if arg2.frameBudget ~= nil then
		arg1:setFrameBudget(arg2.frameBudget)
	end

	return arg1
end

tbl1.setEnabled = function(arg1, arg2)
	var4.setEnabled(arg2)
	return arg1
end

tbl1.update = function(arg1, arg2)
	var4.update(arg2)
	return arg1
end

tbl1.setAutoSyncRate = function(arg1, arg2)
	var4.setAutoSyncRate(arg2)
	return arg1
end

tbl1.rebuild = function(arg1)
	var4.rebuildTrees()
	return arg1
end

local var7 = var1.entityToReference
local var8 = var1.referenceToEntity
tbl1.setReference = function(arg1, arg2, arg3)
	local var1 = var7[arg2]
	if arg3 == nil then
		if typeof(var1) == "Instance" then
			if not var1:IsA("Player") then
				if var1 then
					var8[var1] = nil
				end

				var7[arg2] = nil
			end
		end

		return arg1
	end

	if typeof(arg3) ~= "Instance" or (not arg3:IsA("Player")) then
		var7[arg2] = arg3
		var8[arg3] = arg2
	end

	return arg1
end

tbl1.setFrameBudget = function(arg1, arg2)
	var4.setFrameBudget(arg2 / 1000)
	return arg1
end

local var9 = var1.entityToGroups
local var10 = var1.groups
tbl1.removeEntity = function(arg1, arg2)
	arg2 = var8[arg2] or arg2
	local var2 = var9[arg2]
	if not var2 then
		return arg1
	end

	local tbl1 = {}
	for k1 in var2, nil do
		table.insert(tbl1, k1)
	end

	for k2, v1 in tbl1, nil do
		local var3 = var10[v1]
		if not var3 then
			continue
		end

		var3:remove(arg2)
	end

	return arg1
end

tbl1.getEntityOfReference = function(_, arg2)
	local var2 = var8[arg2]
	if var2 then
		return var2
	end

	var2 = arg2
	if typeof(var2) == "Instance" then
		if var2:IsA("BasePart") or (var2:IsA("Attachment") or (var2:IsA("Bone") or (var2:IsA("Camera") or var2:IsA("Model")))) then
			return var2
		end
	else
		if typeof(var2) == "table" and (var2.Position or (var2.CFrame or (var2.WorldPosition or var2.GetPivot))) then
			return var2
		end
	end

	return nil
end

tbl1.getReferenceOfEntity = function(_, arg2)
	return var7[arg2] or arg2
end

local var11 = var1.observerIdToObserverObj
tbl1.getObservers = function(_)
	local tbl1 = {}
	for k1, v1 in var11, nil do
		table.insert(tbl1, v1)
	end

	return tbl1
end

tbl1.getGroups = function(_)
	local tbl1 = {}
	for k1, v1 in var10, nil do
		table.insert(tbl1, v1)
	end

	return tbl1
end

local var12 = var1.zoneIdToZoneObj
tbl1.getZones = function(_)
	local tbl1 = {}
	for k1, v1 in var12, nil do
		table.insert(tbl1, v1)
	end

	return tbl1
end

local var13 = var1.entityData
tbl1.getEntities = function(_)
	local tbl1 = {}
	local num1 = 0
	for k1 in var13, nil do
		num1 = num1 + 1
		tbl1[num1] = var7[k1] or k1
	end

	return tbl1
end

local var14 = var1.dynamicTree
local var15 = var1.dynamicCFrames
local var16 = var1.dynamicHalfSizes
local var17 = var1.dynamicTypes
local var18 = var1.staticTree
local var19 = var1.staticCFrames
local var20 = var1.staticHalfSizes
local var21 = var1.staticTypes
tbl1.getZonesAtPoint = function(_, arg2)
	local num1 = 0
	local tbl1 = {}
	var5(var14, arg2, function(arg1)
		local var1 = var12[arg1]
		if var6(arg2, var15[arg1], var16[arg1], var17[arg1]) and var1 then
			local var2 = num1 + 1
			num1 = var2
			tbl1[num1] = var1
		end
	end)

	var5(var18, arg2, function(arg1)
		local var1 = var12[arg1]
		if var6(arg2, var19[arg1], var20[arg1], var21[arg1]) and var1 then
			local var2 = num1 + 1
			num1 = var2
			tbl1[num1] = var1
		end
	end)

	return tbl1
end

tbl1.getZonesOfEntity = function(_, arg2)
	local var2 = var13[var8[arg2] or arg2]
	if not var2 or (not var2.activeObserverMemberships) then
		return {}
	end

	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in var2.activeObserverMemberships, nil do
		if tbl2[v1] then
			continue
		end

		tbl2[v1] = true
		local var3 = var12[v1]
		if not var3 then
			continue
		end

		table.insert(tbl1, var3)
	end

	return tbl1
end

tbl1.getGroupsOfEntity = function(_, arg2)
	local var2 = var9[var8[arg2] or arg2]
	if not var2 then
		return {}
	end

	local tbl1 = {}
	local num1 = 0
	for k1 in var2, nil do
		local var3 = var10[k1]
		if not var3 then
			continue
		end

		num1 = num1 + 1
		tbl1[num1] = var3
	end

	return tbl1
end

tbl1.iterGroups = function(_)
	local var1 = nil
	return function()
		local var2 = next(var10, var1)
		var1 = var2
		return var1 and var10[var1] or nil
	end
end

tbl1.iterZones = function(_)
	local var1 = nil
	return function()
		local var2 = next(var12, var1)
		var1 = var2
		return var1 and var12[var1] or nil
	end
end

tbl1.iterEntities = function(_)
	local var1 = nil
	return function()
		local var2 = next(var13, var1)
		var1 = var2
		if var1 then
			var2 = var7[var1]
			return var2 or var1
		end

		return var1
	end
end

tbl1.iterObservers = function(_)
	local var1 = nil
	return function()
		local var2 = next(var11, var1)
		var1 = var2
		return var1 and var11[var1] or nil
	end
end

tbl1.iterGroupsOfEntity = function(_, arg2)
	local var2 = var9[var8[arg2] or arg2]
	if not var2 then
		return function()
			return nil
		end

	end

	local var3 = nil
	return function()
		local var1 = next(var2, var3)
		var3 = var1
		return var3 and var10[var3] or nil
	end
end

tbl1.iterZonesOfEntity = function(_, arg2)
	local var2 = var13[var8[arg2] or arg2]
	if not var2 or (not var2.activeObserverMemberships) then
		return function()
			return nil
		end

	end

	local var3 = nil
	local var4 = var2.activeObserverMemberships
	local tbl1 = {}
	return function()
		while true do
			local var1 = next(var4, var3)
			var3 = var1
			if not var3 then
				return nil
			end

			var1 = var4[var3]
			if tbl1[var1] then
				continue
			end

			tbl1[var1] = true
			local var2 = var12[var1]
			if not var2 then
				continue
			end

			return var2
		end
	end
end

tbl1.iterZonesAtPoint = function(_, arg2)
	local bool1 = true
	local num1 = 1
	local var1 = var14.count or 0
	local var2 = var14.nodes
	local var3 = arg2.X
	local var4 = arg2.Y
	local var5 = arg2.Z
	local var7 = var18.count or 0
	local var8 = var18.nodes
	return function()
		if bool1 then
			while true do
				if num1 > var1 then
					break
				end

				local var13 = var2[num1]
				local var14 = var13.min
				local var22 = var13.max
				if var3 < var14.X or (var22.X < var3 or (var4 < var14.Y or (var22.Y < var4 or (var5 < var14.Z or var22.Z < var5)))) then
					num1 = var13.skipIndex
				else
					local var23 = num1 + 1
					num1 = var23
					var23 = var13.id
					if 0 >= var23 then
						continue
					end

					if not var6(arg2, var15[var23], var16[var23], var17[var23]) then
						continue
					end

					return var12[var23]
				end
			end

			bool1 = false
			num1 = 1
		end

		if not bool1 then
			while true do
				if num1 > var7 then
					break
				end

				local var27 = var8[num1]
				local var28 = var27.min
				local var30 = var27.max
				if var3 < var28.X or (var30.X < var3 or (var4 < var28.Y or (var30.Y < var4 or (var5 < var28.Z or var30.Z < var5)))) then
					num1 = var27.skipIndex
				else
					local var31 = num1 + 1
					num1 = var31
					var31 = var27.id
					if 0 >= var31 then
						continue
					end

					if not var6(arg2, var19[var31], var20[var31], var21[var31]) then
						continue
					end

					return var12[var31]
				end
			end
		end

		return nil
	end
end

local var22 = nil
local var23 = nil
local tbl2 = {}
local var24 = var1.zoneAttachedObservers
tbl1.visualize = function(arg1, arg2)
	if var22 then
		var22:Disconnect()
		var22 = nil
	end

	if var23 then
		var23:Destroy()
		var23 = nil
	end

	table.clear(tbl2)
	if not arg2 then
		return arg1
	end

	local var1 = Instance.new("Folder")
	var1.Name = "QuickZone_Debug_Visuals"
	var1.Parent = workspace
	var23 = var1
	var22 = (var2:IsClient() and var2.PreRender or var2.Heartbeat):Connect(function()
		if not var23 then
			return
		end

		for k1, v1 in var19, nil do
			local var2 = tbl2[k1]
			if not var2 then
				local var4 = Instance.new("BoxHandleAdornment")
				var4.Name = "Zone_" .. k1
				var4.Adornee = workspace.Terrain
				var4.Transparency = var3.Debug.transparency
				var4.AlwaysOnTop = true
				var4.ZIndex = 1
				var4.Parent = var23
				tbl2[k1] = var4
				var2 = var4
			end

			local var5 = var24[k1]
			local var7 = var5
			local var8 = var20[k1]
			if var7 then
				var7 = next(var5) ~= nil
			end

			var2.Size = var8 * 2
			var2.CFrame = v1
			var2.Color3 = var7 and var3.Debug.staticActive or var3.Debug.staticInactive
		end

		for k2, v2 in var15, nil do
			local var10 = tbl2[k2]
			if not var10 then
				local var11 = Instance.new("BoxHandleAdornment")
				var11.Name = "Zone_" .. k2
				var11.Adornee = workspace.Terrain
				var11.Transparency = var3.Debug.transparency
				var11.AlwaysOnTop = true
				var11.ZIndex = 1
				var11.Parent = var23
				tbl2[k2] = var11
				var10 = var11
			end

			local var12 = var24[k2]
			local var14 = var12
			local var17 = var16[k2]
			if var14 then
				var14 = next(var12) ~= nil
			end

			var10.Size = var17 * 2
			var10.CFrame = v2
			var10.Color3 = var14 and var3.Debug.dynamicActive or var3.Debug.dynamicInactive
		end

		for k3, v3 in tbl2, nil do
			if var19[k3] then
				continue
			end

			if var15[k3] then
				continue
			end

			v3:Destroy()
			tbl2[k3] = nil
		end
	end)

	return arg1
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Config [ModuleScript]
-- y u r i

local tbl1 = { staticActive = Color3.fromRGB(0, 204, 255), transparency = 0.6 }
tbl1.staticInactive = Color3.fromRGB(40, 114, 133)
tbl1.dynamicActive = Color3.fromRGB(94, 255, 0)
tbl1.dynamicInactive = Color3.fromRGB(80, 141, 46)
return {
	Strategy = { POS = 1, PRIM = 2, WORLD = 3, CFRAME = 4, TRANSFORM = 5, PIVOT = 6 },
	Group = { autoClean = true },
	Scheduler = { enabled = true, frameBudget = 0.001, autoSyncRate = 30 },
	Observer = { updateRate = 30, precision = 0.1, safety = true },
	Debug = tbl1,
}

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Types [ModuleScript]
-- y u r i

return nil

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Classes.Group [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local var1 = require(script.Parent.Parent.Config)
local var2 = game:GetService("CollectionService")
local var3 = game:GetService("Players")
local var4 = require(script.Parent.Parent.Core.PlayerTracker)
local var5 = require(script.Parent.Parent.Core.State)
local var6 = require(script.Parent.Parent.Utils.Log)
local var7 = game:GetService("RunService"):IsClient()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var2 = var5
	local var3 = var2.nextGroupId + 1
	var2.nextGroupId = var3
	local var4 = var5.nextGroupId
	var2 = var1.Group.autoClean
	if arg1 and arg1.autoClean ~= nil then
		var2 = arg1.autoClean
	end

	var3 = setmetatable({ id = var4, entities = {}, entityIndices = {}, autoClean = var2 }, tbl1)
	var5.groups[var4] = var3
	var5.groupToObservers[var4] = {}
	var5.groupEntityCleanups[var4] = {}
	if arg1 and arg1.entities then
		var3:_addBulk(arg1.entities)
	end

	return var3
end

tbl1.fromTag = function(arg1)
	local var1 = tbl1.new({ autoClean = false, entities = nil })
	var1.isManaged = true
	local tbl2 = {}
	local function startWatching(arg1)
		if tbl2[arg1] then
			return
		end

		if not arg1:IsA("BasePart") and (not arg1:IsA("Model") and (not arg1:IsA("Attachment") and (not arg1:IsA("Bone") and (not arg1:IsA("Camera"))))) then
			return
		end

		tbl2[arg1] = arg1.AncestryChanged:Connect(function()
			local var2 = arg1
			if var2:IsDescendantOf(workspace) then
				var1:_add(var2)
				return
			end

			var1:_remove(var2)
		end)

		if arg1:IsDescendantOf(workspace) then
			var1:_add(arg1)
			return
		end

		var1:_remove(arg1)
	end

	local var3 = var2:GetInstanceAddedSignal(arg1):Connect(startWatching)
	local var4 = var2:GetInstanceRemovedSignal(arg1):Connect(function(arg1)
		local var3 = tbl2[arg1]
		if var3 then
			var3:Disconnect()
			tbl2[arg1] = nil
		end

		var1:_remove(arg1)
	end)

	for k1, v1 in var2:GetTagged(arg1) do
		startWatching(v1)
	end

	var1:onDestroy(function()
		var3:Disconnect()
		var4:Disconnect()
		for k1, v1 in tbl2, nil do
			local var5 = tbl2[k1]
			if var5 then
				var5:Disconnect()
				tbl2[k1] = nil
			end

			var1:_remove(k1)
		end
	end)

	return var1
end

tbl1.players = function()
	local var1 = tbl1.new({ autoClean = false, entities = nil })
	var1.isManaged = true
	local var2 = var3.PlayerAdded:Connect(function(arg1)
		var1:_add(arg1)
	end)

	for k1, v1 in var3:GetPlayers() do
		var1:_add(v1)
	end

	var1:onDestroy(function()
		var2:Disconnect()
	end)

	return var1
end

tbl1.localPlayer = function()
	if not var7 then
		var6.fatal("Group.localPlayer() can only be called on the Client.", nil)
	end

	local var1 = tbl1.new({ autoClean = false, entities = nil })
	var1.isManaged = true
	var1:_add(var3.LocalPlayer)
	return var1
end

tbl1.setAutoClean = function(arg1, arg2)
	if arg1.isManaged then
		var6.warn("Cannot set autoClean on a Managed Group. Ignoring request.", nil)
		return arg1
	end

	if arg1.autoClean == arg2 then
		return arg1
	end

	arg1.autoClean = arg2
	local var1 = var5.groupEntityCleanups[arg1.id]
	local var2
	local var3
	if arg2 then
		for k1, v1 in arg1.entities, nil do
			if typeof(v1) ~= "Instance" then
				continue
			end

			if var1[v1] then
				continue
			end

			var1[v1] = v1.AncestryChanged:Connect(function(_, arg2)
				if not arg2 then
					arg1:_remove(v1)
				end
			end)

		end

		return arg1
	end

	for k2, v2 in var1, nil do
		v2:Disconnect()
		var1[k2] = nil
	end

	return arg1
end

tbl1.add = function(arg1, arg2)
	if arg1.isManaged then
		var6.warn("Cannot manually add to a Managed Group. Ignoring request.", nil)
		return arg1
	end

	local var1 = arg2
	return arg1:_add(var1)
end

tbl1.addBulk = function(arg1, arg2)
	if arg1.isManaged then
		var6.warn("Cannot manually addBulk to a Managed Group. Ignoring request.", nil)
		return arg1
	end

	local var1 = arg2
	return arg1:_addBulk(var1)
end

tbl1.remove = function(arg1, arg2)
	if arg1.isManaged then
		var6.warn("Cannot manually remove from a Managed Group. Ignoring request.", nil)
		return arg1
	end

	local var1 = arg2
	return arg1:_remove(var1)
end

tbl1.removeBulk = function(arg1, arg2)
	if arg1.isManaged then
		var6.warn("Cannot manually removeBulk from a Managed Group. Ignoring request.", nil)
		return arg1
	end

	local var1 = arg2
	return arg1:_removeBulk(var1)
end

tbl1.clear = function(arg1)
	if arg1.isManaged then
		var6.warn("Cannot clear a Managed Group. Ignoring request.", nil)
		return arg1
	end

	return arg1:_clear()
end

tbl1.contains = function(arg1, arg2)
	local var3
	local var2 = var5.entityToGroups[var5.referenceToEntity[arg2] or arg2]
	if var2 then
		local bool3 = true
		if var2[arg1.id] ~= true then
			bool3 = false
		end
	end

	return var3
end

tbl1.getId = function(arg1)
	return arg1.id
end

tbl1.getEntities = function(arg1)
	local var1 = table.create(#arg1.entities)
	for k1, v1 in ipairs(arg1.entities) do
		var1[k1] = var5.entityToReference[v1] or v1
	end

	return var1
end

tbl1.iterEntities = function(arg1)
	local var1 = nil
	return function()
		local var2 = next(arg1.entityIndices, var1)
		var1 = var2
		if var1 then
			var2 = var5.entityToReference[var1]
			return var2 or var1
		end

		return var1
	end
end

tbl1.onDestroy = function(arg1, arg2)
	if not arg1.onDestroyCallbacks then
		arg1.onDestroyCallbacks = {}
	end

	table.insert(arg1.onDestroyCallbacks, arg2)
	return function()
		local var2 = table.find(arg1.onDestroyCallbacks, arg2)
		if var2 then
			table.remove(arg1.onDestroyCallbacks, var2)
		end
	end
end

tbl1.destroy = function(arg1)
	if arg1.onDestroyCallbacks then
		for k1, v1 in arg1.onDestroyCallbacks, nil do
			task.spawn(v1)
		end

		table.clear(arg1.onDestroyCallbacks)
	end

	for i1 = #arg1.entities, 1, -1 do
		arg1:_remove(arg1.entities[i1])
	end

	var5.groupToObservers[arg1.id] = nil
	var5.groups[arg1.id] = nil
	var5.groupEntityCleanups[arg1.id] = nil
	setmetatable(arg1, nil)
end

local var8 = var1.Strategy.POS
local var9 = var1.Strategy.WORLD
local var10 = var1.Strategy.CFRAME
local var11 = var1.Strategy.PRIM
local var12 = var1.Strategy.PIVOT
local var13 = var1.Strategy.TRANSFORM
local var14 = var1.Observer.precision ^ 2
tbl1._add = function(arg1, arg2)
	if typeof(arg2) == "Instance" and arg2:IsA("Player") then
		var4.subscribe(arg2, arg1)
		return arg1
	end

	local var1 = var5.referenceToEntity[arg2] or arg2
	if not var5.entityToGroups[var1] then
		var5.entityToGroups[var1] = {}
	end

	if var5.entityToGroups[var1][arg1.id] then
		return arg1
	end

	var5.entityToGroups[var1][arg1.id] = true
	if not var5.entityData[var1] then
		local var3 = nil
		if typeof(var1) == "Instance" then
			if var1:IsA("BasePart") then
				var3 = var8
			else
				if var1:IsA("Attachment") or var1:IsA("Bone") then
					var3 = var9
				else
					if var1:IsA("Camera") then
						var3 = var10
					else
						if var1:IsA("Model") then
							var3 = var1.PrimaryPart and var11 or var12
						end
					end
				end
			end
		else
			if typeof(var1) == "table" then
				if var1.Position then
					var3 = var8
				else
					if var1.CFrame then
						var3 = var10
					else
						if var1.Transform then
							var3 = var13
						else
							if var1.WorldPosition then
								var3 = var9
							else
								if var1.GetPivot then
									var3 = var12
								end
							end
						end
					end
				end
			end
		end

		if not var3 then
			var6.nonFatal("Invalid entity (%s). Expected BasePart, Model, Bone, Attachment, Camera, or a valid EntityTable.", nil, (tostring(var1)))
			var5.entityToGroups[var1][arg1.id] = nil
			return arg1
		end

		var5.entityData[var1] = {
			strategy = var3,
			lastPosition = Vector3.new(0, 0, 0),
			activeObserverMemberships = {},
			precisionSq = var14,
			updateRate = -1,
			bucketIndex = 0,
			dynamicVersion = -1,
			staticVersion = -1,
			logicVersion = -1,
			needsStatic = false,
			needsDynamic = false,
		}

	end

	local var7 = #arg1.entities + 1
	arg1.entities[var7] = var1
	arg1.entityIndices[var1] = var7
	var5.dirtyProfiles[var1] = true
	var5.dirtyTopology[var1] = true
	var5.entityData[var1].logicVersion = -1
	if arg1.autoClean and (typeof(var1) == "Instance" and (not var5.groupEntityCleanups[arg1.id][var1])) then
		var5.groupEntityCleanups[arg1.id][var1] = var1.AncestryChanged:Connect(function(_, arg2)
			if not arg2 then
				arg1:_remove(var1)
			end
		end)

	end

	return arg1
end

tbl1._addBulk = function(arg1, arg2)
	for k1, v1 in arg2, nil do
		arg1:_add(v1)
	end

	return arg1
end

tbl1._remove = function(arg1, arg2)
	if typeof(arg2) == "Instance" and arg2:IsA("Player") then
		var4.unsubscribe(arg2, arg1)
		return arg1
	end

	local var1 = var5.referenceToEntity[arg2] or arg2
	if not var5.entityToGroups[var1] or (not var5.entityToGroups[var1][arg1.id]) then
		return arg1
	end

	local var3 = var5.groupEntityCleanups[arg1.id][var1]
	if var3 then
		var3:Disconnect()
		var5.groupEntityCleanups[arg1.id][var1] = nil
	end

	var5.entityToGroups[var1][arg1.id] = nil
	local var8 = arg1.entityIndices[var1]
	local var9 = #arg1.entities
	local var10 = var5.entityData[var1]
	if var8 == var9 then
		arg1.entities[var9] = nil
		arg1.entityIndices[var1] = nil
	else
		local var11 = arg1.entities[var9]
		arg1.entities[var8] = var11
		arg1.entityIndices[var11] = var8
		arg1.entities[var9] = nil
		arg1.entityIndices[var1] = nil
	end

	var5.dirtyProfiles[var1] = true
	var5.dirtyTopology[var1] = true
	for k1, v1 in var10.activeObserverMemberships, nil do
		local var12 = var5.entityToGroups
		local bool1 = false
		for k2 in var12[var1], nil do
			if not var5.groupToObservers[k2] then
				continue
			end

			if not var5.groupToObservers[k2][k1] then
				continue
			end

			bool1 = true
			break
		end

		if bool1 then
			continue
		end

		var10.activeObserverMemberships[k1] = nil
		if var5.observerTrackingEntities[k1] then
			var5.observerTrackingEntities[k1][var1] = nil
		end

		local var13 = var5.observerExitedCallbacks[k1]
		if not var13 then
			continue
		end

		local var14 = var5.observerSafety[k1]
		local var15 = var5.zoneIdToZoneObj[v1]
		local var16 = var5.entityToReference[var1] or var1
		for k3, v2 in var13, nil do
			if var14 then
				task.spawn(v2, var16, var15, var1)
			else
				v2(var16, var15, var1)
			end
		end
	end

	if next(var5.entityToGroups[var1]) == nil then
		local var25 = var10.updateRate
		if var25 then
			if 0 < var25 then
				if var5.buckets[var25] then
					local var32 = var5.buckets[var25]
					local var33 = #var32
					local var35 = var10.bucketIndex
					local var36 = var32[var33]
					if var35 ~= var33 then
						var32[var35] = var36
						if var5.entityData[var36] then
							var5.entityData[var36].bucketIndex = var35
						end
					end

					var32[var33] = nil
				end
			end
		end

		var5.entityData[var1] = nil
		var5.entityToGroups[var1] = nil
		var5.entityToObservers[var1] = nil
		var5.dirtyProfiles[var1] = nil
		var5.dirtyTopology[var1] = nil
		local var38 = var5.entityToReference[var1]
		if var38 and (typeof(var38) ~= "Instance" or (not var38:IsA("Player"))) then
			var5.entityToReference[var1] = nil
			if var5.referenceToEntity[var38] == var1 then
				var5.referenceToEntity[var38] = nil
			end
		end
	end

	return arg1
end

tbl1._removeBulk = function(arg1, arg2)
	for k1, v1 in arg2, nil do
		arg1:_remove(v1)
	end

	return arg1
end

tbl1._clear = function(arg1)
	local var1 = arg1.entities
	for i1 = #var1, 1, -1 do
		arg1:_remove(var1[i1])
	end

	return arg1
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Classes.Observer [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local var1 = require(script.Parent.Parent.Core.State)
local var2 = var1.dirtyProfiles
local var3 = var1.dirtyTopology
local var4 = game:GetService("Players")
local var5 = require(script.Parent.Parent.Config)
local var6 = require(script.Parent.Parent.Utils.Log)
local var7 = require(script.Parent.Parent.Utils.Geometry).isPointInShape
local var8 = game:GetService("RunService"):IsClient()
local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
local tbl3 = {}
tbl1.new = function(arg1)
	local var2 = var1
	local var3 = var2.nextObserverId + 1
	var2.nextObserverId = var3
	local var4 = var1.nextObserverId
	var2 = setmetatable({ id = var4 }, tbl1)
	var1.observerPriorityMap[var4] = arg1 and arg1.priority or 0
	var1.observerUpdateRate[var4] = arg1 and arg1.updateRate or var5.Observer.updateRate
	var1.observerPrecisionSq[var4] = (arg1 and arg1.precision or var5.Observer.precision) ^ 2
	var1.observerEnteredCallbacks[var4] = {}
	var1.observerExitedCallbacks[var4] = {}
	var1.observerTransitionedCallbacks[var4] = {}
	var1.observerTrackingEntities[var4] = {}
	var1.observerIdToObserverObj[var4] = var2
	var3 = var1.observerEnabled
	var3[var4] = if arg1 and arg1.enabled ~= nil then arg1.enabled else true
	var3 = var1.observerSafety
	var3[var4] = if arg1 and arg1.safety ~= nil then arg1.safety else var5.Observer.safety
	var1.observerStaticCount[var4] = 0
	var1.observerDynamicCount[var4] = 0
	tbl2[var4] = false
	tbl3[var4] = false
	local var7
	if arg1 and arg1.zones then
		for k1, v1 in arg1.zones, nil do
			var2:attach(v1)
		end
	end

	if arg1 and arg1.groups then
		for k2, v2 in arg1.groups, nil do
			var2:subscribe(v2)
		end
	end

	var3 = arg1
	if var3 then
		var3 = arg1.zones ~= nil
	end

	local var9 = arg1
	if var9 then
		var9 = arg1.groups ~= nil
	end

	local var10 = not var3
	local var11 = not var9
	var10 = var10 and (not tbl2[var4])
	var11 = var11 and (not tbl3[var4])
	if var10 or var11 then
		local var13 = debug.traceback("", 2)
		task.defer(function()
			if not var1.observerIdToObserverObj[var4] or (not var2:isEnabled()) then
				return
			end

			if var10 and (not tbl2[var4]) then
				var6.warn("Observer %d has no attached zones. It will not detect spatial queries.", var13, var4)
			end

			if var11 and (not tbl3[var4]) then
				var6.warn("Observer %d has no subscribed groups. It will not track any entities.", var13, var4)
			end
		end)

	end

	return var2
end

tbl1.subscribe = function(arg1, arg2)
	tbl3[arg1.id] = true
	local var4 = arg2.id
	if not var1.groupToObservers[var4] then
		var1.groupToObservers[var4] = {}
	end

	var1.groupToObservers[var4][arg1.id] = true
	for k1, v1 in arg2.entities, nil do
		var2[v1] = true
		var3[v1] = true
	end

	return arg1
end

local function disconnectObserverFromGroup(arg1, arg2)
	local var4 = var1.observerSafety[arg1]
	local var5 = var1.observerEnabled[arg1]
	for k1, v1 in arg2.entities, nil do
		local var6 = var1.entityData[v1]
		if not var6 then
			continue
		end

		var2[v1] = true
		var3[v1] = true
		local var7 = var6.activeObserverMemberships[arg1]
		if not var7 then
			continue
		end

		local bool1 = false
		local var9
		if var5 then
			local var10 = var1.entityToGroups
			for k2 in var10[v1], nil do
				if not var1.groupToObservers[k2] then
					continue
				end

				var9 = var1.groupToObservers
				if not var9[k2][arg1] then
					continue
				end

				bool1 = true
				break
			end
		end

		if bool1 then
			continue
		end

		var6.activeObserverMemberships[arg1] = nil
		if var1.observerTrackingEntities[arg1] then
			var1.observerTrackingEntities[arg1][v1] = nil
		end

		local var11 = var1.observerExitedCallbacks[arg1]
		if not var11 then
			continue
		end

		local var12 = var1.zoneIdToZoneObj[var7]
		local var13 = var1.entityToReference[v1] or v1
		for k3, v2 in var11, nil do
			if var4 then
				task.spawn(v2, var13, var12, v1)
			else
				v2(var13, var12, v1)
			end
		end
	end
end

tbl1.unsubscribe = function(arg1, arg2)
	local var2 = arg2.id
	if var1.groupToObservers[var2] then
		var1.groupToObservers[var2][arg1.id] = nil
	end

	disconnectObserverFromGroup(arg1.id, arg2)
	return arg1
end

tbl1.attach = function(arg1, arg2)
	tbl2[arg1.id] = true
	arg2:attach(arg1)
	return arg1
end

tbl1.detach = function(arg1, arg2)
	arg2:detach(arg1)
	return arg1
end

tbl1.observe = function(arg1, arg2)
	local num1 = 0
	local tbl1 = {}
	local tbl2 = {}
	local var1 = arg1:onEnter(function(arg1, arg2, arg3)
		local var1 = num1 + 1
		num1 = var1
		var1 = num1
		tbl1[arg3] = var1
		local var2 = arg2(arg1, arg2, arg3)
		if tbl1[arg3] ~= var1 then
			if type(var2) == "function" then
				var2()
			end

			return
		end

		if type(var2) == "function" then
			tbl2[arg3] = var2
		end
	end)

	local var2 = arg1:onExit(function(_, _, arg3)
		tbl1[arg3] = nil
		local var2 = tbl2[arg3]
		if var2 then
			tbl2[arg3] = nil
			var2()
		end
	end)

	local function disconnect()
		var1()
		var2()
		table.clear(tbl1)
		for k1, v1 in tbl2, nil do
			tbl2[k1] = nil
			task.spawn(v1)
		end
	end

	local var3 = arg1:onDestroy(disconnect)
	return function()
		var3()
		disconnect()
	end
end

tbl1.onEnter = function(arg1, arg2)
	table.insert(var1.observerEnteredCallbacks[arg1.id], arg2)
	return function()
		local var3 = table.find(var1.observerEnteredCallbacks[arg1.id], arg2)
		if var3 then
			table.remove(var1.observerEnteredCallbacks[arg1.id], var3)
		end
	end
end

tbl1.onExit = function(arg1, arg2)
	table.insert(var1.observerExitedCallbacks[arg1.id], arg2)
	return function()
		local var3 = table.find(var1.observerExitedCallbacks[arg1.id], arg2)
		if var3 then
			table.remove(var1.observerExitedCallbacks[arg1.id], var3)
		end
	end
end

tbl1.observePlayer = function(arg1, arg2)
	local num1 = 0
	local tbl1 = {}
	local tbl2 = {}
	local var1 = arg1:onEnter(function(arg1, arg2, arg3)
		if typeof(arg1) ~= "Instance" or (not arg1:IsA("Player")) then
			return
		end

		local var1 = num1 + 1
		num1 = var1
		var1 = num1
		tbl1[arg3] = var1
		local var2 = arg2(arg1, arg2, arg3)
		if tbl1[arg3] ~= var1 then
			if type(var2) == "function" then
				var2()
			end

			return
		end

		if type(var2) == "function" then
			tbl2[arg3] = var2
		end
	end)

	local var2 = arg1:onExit(function(_, _, arg3)
		if not tbl1[arg3] then
			return
		end

		tbl1[arg3] = nil
		local var2 = tbl2[arg3]
		if var2 then
			tbl2[arg3] = nil
			var2()
		end
	end)

	local function disconnect()
		var1()
		var2()
		table.clear(tbl1)
		for k1, v1 in tbl2, nil do
			tbl2[k1] = nil
			task.spawn(v1)
		end
	end

	local var3 = arg1:onDestroy(disconnect)
	return function()
		var3()
		disconnect()
	end
end

tbl1.onPlayerEnter = function(arg1, arg2)
	local function fn2(arg1, arg2, arg3)
		if typeof(arg1) == "Instance" and arg1:IsA("Player") then
			arg2(arg1, arg2, arg3)
		end
	end

	return arg1:onEnter(fn2)
end

tbl1.onPlayerExit = function(arg1, arg2)
	local function fn2(arg1, arg2, arg3)
		if typeof(arg1) == "Instance" and arg1:IsA("Player") then
			arg2(arg1, arg2, arg3)
		end
	end

	return arg1:onExit(fn2)
end

tbl1.observeLocalPlayer = function(arg1, arg2)
	if not var8 then
		var6.fatal("Observer:observeLocalPlayer can only be called on the Client.", nil)
	end

	local num1 = 0
	local tbl1 = {}
	local tbl2 = {}
	local var1 = arg1:onEnter(function(arg1, arg2, arg3)
		if arg1 ~= var4.LocalPlayer then
			return
		end

		local var1 = num1 + 1
		num1 = var1
		var1 = num1
		tbl1[arg3] = var1
		local var2 = arg2(arg2, arg3)
		if tbl1[arg3] ~= var1 then
			if type(var2) == "function" then
				var2()
			end

			return
		end

		if type(var2) == "function" then
			tbl2[arg3] = var2
		end
	end)

	local var2 = arg1:onExit(function(_, _, arg3)
		if not tbl1[arg3] then
			return
		end

		tbl1[arg3] = nil
		local var2 = tbl2[arg3]
		if var2 then
			tbl2[arg3] = nil
			var2()
		end
	end)

	local function disconnect()
		var1()
		var2()
		table.clear(tbl1)
		for k1, v1 in tbl2, nil do
			tbl2[k1] = nil
			task.spawn(v1)
		end
	end

	local var3 = arg1:onDestroy(disconnect)
	return function()
		var3()
		disconnect()
	end
end

tbl1.onLocalPlayerEnter = function(arg1, arg2)
	if not var8 then
		var6.fatal("Observer:onLocalPlayerEnter can only be called on the Client.", nil)
	end

	local function fn2(arg1, arg2, arg3)
		if arg1 == var4.LocalPlayer then
			arg2(arg2, arg3)
		end
	end

	return arg1:onEnter(fn2)
end

tbl1.onLocalPlayerExit = function(arg1, arg2)
	if not var8 then
		var6.fatal("Observer:onLocalPlayerExit can only be called on the Client.", nil)
	end

	local function fn2(arg1, arg2, arg3)
		if arg1 == var4.LocalPlayer then
			arg2(arg2, arg3)
		end
	end

	return arg1:onExit(fn2)
end

tbl1.observeGroup = function(arg1, arg2)
	local tbl1 = {}
	local tbl2 = {}
	local function fn2(_, arg2, arg3)
		local var3 = var1.entityToGroups[arg3]
		if not var3 then
			return nil
		end

		for k1, v1 in var3, nil do
			local var4 = var1.groups[k1]
			if not var4 then
				continue
			end

			if not var1.groupToObservers[k1][arg1.id] then
				continue
			end

			if not tbl1[k1] then
				tbl1[k1] = {}
			end

			if next(tbl1[k1]) == nil then
				tbl1[k1][arg3] = true
				local var5 = arg2(var4, arg2, arg3)
				if typeof(var5) ~= "function" then
					continue
				end

				tbl2[k1] = var5
			else
				tbl1[k1][arg3] = true
			end
		end

		return function()
			for k1, v1 in tbl1, nil do
				if not v1[arg3] then
					continue
				end

				v1[arg3] = nil
				if next(v1) ~= nil then
					continue
				end

				tbl1[k1] = nil
				local var1 = tbl2[k1]
				if not var1 then
					continue
				end

				var1()
				tbl2[k1] = nil
			end
		end
	end

	return arg1:observe(fn2)
end

tbl1.onGroupEnter = function(arg1, arg2)
	local tbl1 = {}
	local function fn2(_, arg2, arg3)
		local var3 = var1.entityToGroups[arg3]
		if not var3 then
			return nil
		end

		for k1, v1 in var3, nil do
			if not var1.groupToObservers[k1] then
				continue
			end

			if not var1.groupToObservers[k1][arg1.id] then
				continue
			end

			if not tbl1[k1] then
				tbl1[k1] = {}
			end

			local var4 = next(tbl1[k1]) == nil
			tbl1[k1][arg3] = true
			if not var4 then
				continue
			end

			local var5 = var1.groups[k1]
			if not var5 then
				continue
			end

			arg2(var5, arg2, arg3)
		end

		return function()
			for k1, v1 in tbl1, nil do
				if not v1[arg3] then
					continue
				end

				v1[arg3] = nil
				if next(v1) ~= nil then
					continue
				end

				tbl1[k1] = nil
			end
		end
	end

	return arg1:observe(fn2)
end

tbl1.onGroupExit = function(arg1, arg2)
	local tbl1 = {}
	local function fn2(_, arg2, arg3)
		local var3 = var1.entityToGroups[arg3]
		if not var3 then
			return nil
		end

		for k1, v1 in var3, nil do
			if not var1.groupToObservers[k1] then
				continue
			end

			if not var1.groupToObservers[k1][arg1.id] then
				continue
			end

			if not tbl1[k1] then
				tbl1[k1] = {}
			end

			tbl1[k1][arg3] = true
		end

		return function()
			for k1, v1 in tbl1, nil do
				if not v1[arg3] then
					continue
				end

				v1[arg3] = nil
				if next(v1) ~= nil then
					continue
				end

				tbl1[k1] = nil
				local var2 = var1.groups[k1]
				if not var2 then
					continue
				end

				arg2(var2, arg2, arg3)
			end
		end
	end

	return arg1:observe(fn2)
end

tbl1.onTransition = function(arg1, arg2)
	table.insert(var1.observerTransitionedCallbacks[arg1.id], arg2)
	return function()
		local var3 = table.find(var1.observerTransitionedCallbacks[arg1.id], arg2)
		if var3 then
			table.remove(var1.observerTransitionedCallbacks[arg1.id], var3)
		end
	end
end

tbl1.onPlayerTransition = function(arg1, arg2)
	local function fn2(arg1, arg2, arg3)
		local var2 = var1.entityToReference[arg1] or arg1
		if typeof(var2) == "Instance" and var2:IsA("Player") then
			arg2(var2, arg2, arg3)
		end
	end

	return arg1:onTransition(fn2)
end

tbl1.onLocalPlayerTransition = function(arg1, arg2)
	if not var8 then
		var6.fatal("Observer:onLocalPlayerTransition can only be called on the Client.", nil)
	end

	local function fn2(arg1, arg2, arg3)
		if (var1.entityToReference[arg1] or arg1) == var4.LocalPlayer then
			arg2(arg2, arg3)
		end
	end

	return arg1:onTransition(fn2)
end

local function updateAllEntitiesForObserver(arg1)
	for k1, v1 in var1.groupToObservers, nil do
		if not v1[arg1] then
			continue
		end

		local var4 = var1.groups[k1]
		if not var4 then
			continue
		end

		for k2, v2 in var4.entities, nil do
			var2[v2] = true
			var3[v2] = true
		end
	end
end

tbl1.setEnabled = function(arg1, arg2)
	if arg1:isEnabled() == arg2 then
		return arg1
	end

	local var2 = arg1.id
	var1.observerEnabled[var2] = arg2
	local var3 = var1
	local var4 = var3.logicVersion + 1
	var3.logicVersion = var4
	if not arg2 then
		for k1, v1 in var1.groupToObservers, nil do
			if not v1[var2] then
				continue
			end

			local var5 = var1.groups[k1]
			if not var5 then
				continue
			end

			disconnectObserverFromGroup(var2, var5)
		end
	end

	updateAllEntitiesForObserver(arg1.id)
	return arg1
end

tbl1.setSafety = function(arg1, arg2)
	var1.observerSafety[arg1.id] = arg2
	return arg1
end

tbl1.setPriority = function(arg1, arg2)
	var1.observerPriorityMap[arg1.id] = arg2
	local var2 = var1
	local var3 = var2.logicVersion + 1
	var2.logicVersion = var3
	return arg1
end

tbl1.setUpdateRate = function(arg1, arg2)
	if arg2 < 0 then
		var6.fatal("updateRate must be non-negative.", nil)
	end

	var1.observerUpdateRate[arg1.id] = arg2
	updateAllEntitiesForObserver(arg1.id)
	return arg1
end

tbl1.setPrecision = function(arg1, arg2)
	if arg2 < 0 then
		var6.fatal("precision must be non-negative.", nil)
	end

	var1.observerPrecisionSq[arg1.id] = arg2 ^ 2
	updateAllEntitiesForObserver(arg1.id)
	return arg1
end

tbl1.isEnabled = function(arg1)
	return var1.observerEnabled[arg1.id] ~= false
end

local var9 = var1.dynamicTree
local var10 = var1.zoneAttachedObservers
local var11 = var1.dynamicCFrames
local var12 = var1.dynamicHalfSizes
local var13 = var1.dynamicTypes
local var14 = var1.staticTree
local var15 = var1.staticCFrames
local var16 = var1.staticHalfSizes
local var17 = var1.staticTypes
tbl1.isPointInside = function(arg1, arg2)
	local var1 = arg2.X
	local var2 = arg2.Y
	local var3 = arg2.Z
	local var4 = arg1.id
	local var5 = var9.nodes
	local num1 = 1
	local var6 = var9.count
	while num1 <= var6 do
		local var8 = var5[num1]
		local var18 = var8.min
		local var20 = var8.max
		if var1 < var18.X or (var20.X < var1 or (var2 < var18.Y or (var20.Y < var2 or (var3 < var18.Z or var20.Z < var3)))) then
			num1 = var8.skipIndex
		else
			local var21 = var8.id
			if var21 == 0 then
				continue
			end

			local var22 = var10[var21]
			if not var22 then
				continue
			end

			if not table.find(var22, var4) then
				continue
			end

			if not var7(arg2, var11[var21], var12[var21], var13[var21]) then
				continue
			end

			return true
		end
	end

	var5 = var14.nodes
	num1 = 1
	var6 = var14.count
	while num1 <= var6 do
		local var23 = var5[num1]
		local var24 = var23.min
		local var26 = var23.max
		if var1 < var24.X or (var26.X < var1 or (var2 < var24.Y or (var26.Y < var2 or (var3 < var24.Z or var26.Z < var3)))) then
			num1 = var23.skipIndex
		else
			local var27 = var23.id
			if var27 == 0 then
				continue
			end

			local var28 = var10[var27]
			if not var28 then
				continue
			end

			if not table.find(var28, var4) then
				continue
			end

			if not var7(arg2, var15[var27], var16[var27], var17[var27]) then
				continue
			end

			return true
		end

		num1 = num1 + 1
	end

	return false
end

tbl1.isSafe = function(arg1)
	return var1.observerSafety[arg1.id]
end

tbl1.getId = function(arg1)
	return arg1.id
end

tbl1.getPriority = function(arg1)
	return var1.observerPriorityMap[arg1.id]
end

tbl1.getUpdateRate = function(arg1)
	return var1.observerUpdateRate[arg1.id]
end

tbl1.getPrecision = function(arg1)
	return (math.sqrt(var1.observerPrecisionSq[arg1.id]))
end

tbl1.getEntitiesInside = function(arg1)
	local var3 = var1.observerTrackingEntities[arg1.id]
	if not var3 then
		return {}
	end

	local tbl1 = {}
	for k1, v1 in var3, nil do
		table.insert(tbl1, var1.entityToReference[k1] or k1)
	end

	return tbl1
end

tbl1.getPlayersInside = function(arg1)
	local tbl1 = {}
	for k1 in var1.observerTrackingEntities[arg1.id], nil do
		local var2 = var1.entityToReference[k1] or k1
		if typeof(var2) ~= "Instance" then
			continue
		end

		if not var2:IsA("Player") then
			continue
		end

		if table.find(tbl1, var2) then
			continue
		end

		table.insert(tbl1, var2)
	end

	return tbl1
end

tbl1.getZones = function(arg1)
	local tbl1 = {}
	for k1, v1 in var1.zoneAttachedObservers, nil do
		if not table.find(v1, arg1.id) then
			continue
		end

		local var2 = var1.zoneIdToZoneObj[k1]
		if not var2 then
			continue
		end

		table.insert(tbl1, var2)
	end

	return tbl1
end

tbl1.getGroups = function(arg1)
	local tbl1 = {}
	for k1, v1 in var1.groupToObservers, nil do
		if not v1[arg1.id] then
			continue
		end

		local var2 = var1.groups[k1]
		if not var2 then
			continue
		end

		table.insert(tbl1, var2)
	end

	return tbl1
end

tbl1.getZoneOfEntity = function(arg1, arg2)
	local var3 = var1.entityData[var1.referenceToEntity[arg2] or arg2]
	if not var3 then
		return nil
	end

	local var5 = var3.activeObserverMemberships[arg1.id]
	if var5 then
		return var1.zoneIdToZoneObj[var5]
	end

	return nil
end

tbl1.getZoneOfPlayer = function(arg1, arg2)
	local var1 = arg2
	return arg1:getZoneOfEntity(var1)
end

tbl1.getEntitiesInZone = function(arg1, arg2)
	local tbl1 = {}
	for k1 in arg1:iterEntitiesInZone(arg2) do
		table.insert(tbl1, k1)
	end

	return tbl1
end

tbl1.getPlayersInZone = function(arg1, arg2)
	local tbl1 = {}
	for k1 in arg1:iterPlayersInZone(arg2) do
		table.insert(tbl1, k1)
	end

	return tbl1
end

tbl1.iterZones = function(arg1)
	local var2 = nil
	local var3 = nil
	local var4 = arg1.id
	return function()
		while true do
			local var5, var6 = next(var10, var2)
			var2 = var5
			var3 = var6
			if not var2 then
				return nil
			end

			if not table.find(var3, var4) then
				continue
			end

			var5 = var1.zoneIdToZoneObj[var2]
			if not var5 then
				continue
			end

			return var5
		end
	end
end

tbl1.iterGroups = function(arg1)
	local var2 = nil
	local var3 = nil
	local var4 = arg1.id
	return function()
		while true do
			local var5, var6 = next(var1.groupToObservers, var2)
			var2 = var5
			var3 = var6
			if not var2 then
				return nil
			end

			if not var3[var4] then
				continue
			end

			var5 = var1.groups[var2]
			if not var5 then
				continue
			end

			return var5
		end
	end
end

tbl1.iterEntitiesInside = function(arg1)
	local var2 = var1.observerTrackingEntities[arg1.id]
	local var3 = nil
	var2 = var2 or {}
	local var4 = arg1.id
	return function()
		while true do
			local var5 = next(var2, var3)
			var3 = var5
			if not var3 then
				return nil
			end

			var5 = var1.entityData[var3]
			if not var5 then
				continue
			end

			local var6 = var5.activeObserverMemberships[var4]
			if not var6 then
				continue
			end

			local var7 = var1.entityToReference[var3]
			return var7 or var3, var1.zoneIdToZoneObj[var6]
		end
	end
end

tbl1.iterPlayersInside = function(arg1)
	local var2 = var1.observerTrackingEntities[arg1.id]
	local var3 = nil
	var2 = var2 or {}
	local var4 = arg1.id
	return function()
		while true do
			local var5 = next(var2, var3)
			var3 = var5
			if not var3 then
				return nil, nil
			end

			var5 = var1.entityData[var3]
			if not var5 then
				continue
			end

			local var6 = var5.activeObserverMemberships[var4]
			if not var6 then
				continue
			end

			local var7 = var1.entityToReference[var3]
			var7 = var7 or var3
			if typeof(var7) ~= "Instance" then
				continue
			end

			if not var7:IsA("Player") then
				continue
			end

			return var7, var1.zoneIdToZoneObj[var6]
		end
	end
end

tbl1.iterEntitiesInZone = function(arg1, arg2)
	local var3 = var1.observerTrackingEntities[arg1.id]
	if not var3 then
		return function()
			return nil
		end

	end

	local var4 = nil
	local var5 = arg1.id
	local var6 = arg2:getId()
	return function()
		while true do
			local var2 = next(var3, var4)
			var4 = var2
			if not var4 then
				return nil
			end

			var2 = var1.entityData[var4]
			if not var2 then
				continue
			end

			if var2.activeObserverMemberships[var5] ~= var6 then
				continue
			end

			local var7 = var1.entityToReference[var4]
			return var7 or var4
		end
	end
end

tbl1.iterPlayersInZone = function(arg1, arg2)
	local var3 = var1.observerTrackingEntities[arg1.id]
	if not var3 then
		return function()
			return nil
		end

	end

	local var4 = nil
	local var5 = arg1.id
	local var6 = arg2:getId()
	return function()
		while true do
			local var2 = next(var3, var4)
			var4 = var2
			if not var4 then
				return nil
			end

			var2 = var1.entityData[var4]
			if not var2 then
				continue
			end

			if var2.activeObserverMemberships[var5] ~= var6 then
				continue
			end

			local var7 = var1.entityToReference[var4]
			var7 = var7 or var4
			if typeof(var7) ~= "Instance" then
				continue
			end

			if not var7:IsA("Player") then
				continue
			end

			return var7
		end
	end
end

tbl1.onDestroy = function(arg1, arg2)
	if not arg1.onDestroyCallbacks then
		arg1.onDestroyCallbacks = {}
	end

	table.insert(arg1.onDestroyCallbacks, arg2)
	return function()
		local var2 = table.find(arg1.onDestroyCallbacks, arg2)
		if var2 then
			table.remove(arg1.onDestroyCallbacks, var2)
		end
	end
end

tbl1.destroy = function(arg1)
	local var2
	if arg1.onDestroyCallbacks then
		for k1, v1 in arg1.onDestroyCallbacks, nil do
			task.spawn(v1)
		end

		table.clear(arg1.onDestroyCallbacks)
	end

	arg1:setEnabled(false)
	local var3 = arg1.id
	for k2, v2 in var1.groupToObservers, nil do
		v2[var3] = nil
	end

	for k3, v3 in var1.zoneAttachedObservers, nil do
		local var4 = table.find(v3, var3)
		if not var4 then
			continue
		end

		local var6 = #v3
		if var4 ~= var6 then
			local var7 = v3[var6]
			v3[var4] = var7
		end

		v3[var6] = nil
	end

	var1.observerPriorityMap[var3] = nil
	var1.observerEnteredCallbacks[var3] = nil
	var1.observerExitedCallbacks[var3] = nil
	var1.observerTransitionedCallbacks[var3] = nil
	var1.observerTrackingEntities[var3] = nil
	var1.observerIdToObserverObj[var3] = nil
	var1.observerEnabled[var3] = nil
	var1.observerSafety[var3] = nil
	var1.observerUpdateRate[var3] = nil
	var1.observerPrecisionSq[var3] = nil
	var1.observerStaticCount[var3] = nil
	var1.observerDynamicCount[var3] = nil
	tbl2[var3] = nil
	tbl3[var3] = nil
	local var8 = var1
	local var9 = var8.logicVersion + 1
	var8.logicVersion = var9
	setmetatable(arg1, nil)
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Classes.Zone [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local var1 = require(script.Parent.Parent.Core.State)
local var2 = game:GetService("CollectionService")
local var3 = require(script.Parent.Parent.Utils.Log)
local var4 = require(script.Parent.Zones)
local var5 = require(script.Parent.Parent.Utils.Geometry).isPointInShape
local var6 = var1.dynamicHalfSizes
local var7 = var1.dynamicTypes
local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {
	Block = Enum.PartType.Block.Value,
	Cylinder = Enum.PartType.Cylinder.Value,
	Ball = Enum.PartType.Ball.Value,
	Wedge = Enum.PartType.Wedge.Value,
	CornerWedge = Enum.PartType.CornerWedge.Value,
}

local function newZoneInternal(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var2 = var1
	local var3 = var2.nextZoneId + 1
	var2.nextZoneId = var3
	local var4 = var1.nextZoneId
	var2 = arg2 * 0.5
	if arg5 then
		var1.dynamicCFrames[var4] = arg1
		var1.dynamicHalfSizes[var4] = var2
		var1.dynamicTypes[var4] = arg3
		var1.pendingDynamicRebuild = true
	else
		var1.staticCFrames[var4] = arg1
		var1.staticHalfSizes[var4] = var2
		var1.staticTypes[var4] = arg3
		var1.pendingStaticRebuild = true
	end

	var3 = setmetatable({ id = var4, reference = arg4, dynamic = arg5, metadata = arg6, autoSync = false }, tbl1)
	var1.zoneIdToZoneObj[var4] = var3
	if arg7 then
		var3:setAutoSync(true)
	end

	return var3
end

tbl1.new = function(arg1)
	local var4 = Enum.PartType.Block.Value
	if arg1.shape then
		local var6 = tbl2[arg1.shape]
		if var6 then
			var4 = var6
		else
			var3.warn("Invalid shape '%s'. Defaulting to Block.", nil, (tostring(arg1.shape)))
		end
	end

	return (newZoneInternal(arg1.cframe, arg1.size, var4, arg1.reference, arg1.isDynamic or false, arg1.metadata, arg1.autoSync or false))
end

tbl1.fromPart = function(arg1, arg2)
	local var2 = Enum.PartType.Block.Value
	if arg1:IsA("Part") then
		var2 = arg1.Shape.Value
	else
		if arg1:IsA("WedgePart") then
			var2 = Enum.PartType.Wedge.Value
		else
			if arg1:IsA("CornerWedgePart") then
				var2 = Enum.PartType.CornerWedge.Value
			end
		end
	end

	local var3 = arg2
	return (newZoneInternal(arg1.CFrame, arg1.ExtentsSize, var2, arg1, arg2 and arg2.isDynamic, var3 and arg2.metadata, arg2 and arg2.autoSync))
end

tbl1.fromParts = function(arg1, arg2)
	local var1 = if arg2 and arg2.isDynamic ~= nil then arg2.isDynamic else false
	local var2 = if arg2 and arg2.metadata ~= nil then arg2.metadata else nil
	local var3 = if arg2 and arg2.autoSync ~= nil then arg2.autoSync else false
	local var5 = var4.new({ isDynamic = var1, metadata = var2, autoSync = var3 })
	for k1, v1 in arg1, nil do
		if not v1:IsA("BasePart") then
			continue
		end

		var5:add((tbl1.fromPart(v1, { isDynamic = var1, metadata = var5.metadata, autoSync = var3 })))
	end

	return var5
end

tbl1.fromChildren = function(arg1, arg2)
	local var1 = if arg2 and arg2.isDynamic ~= nil then arg2.isDynamic else false
	local var2 = if arg2 and arg2.metadata ~= nil then arg2.metadata else nil
	local tbl2 = {}
	local var3 = var4.new({
		isDynamic = var1,
		metadata = var2,
		autoSync = if arg2 and arg2.autoSync ~= nil then arg2.autoSync else false,
	})

	local function onAdded(arg1)
		if arg1:IsA("BasePart") and (not tbl2[arg1]) then
			local var2 = tbl1.fromPart(arg1, { isDynamic = var1, metadata = var3.metadata })
			tbl2[arg1] = var2
			var3:add(var2)
		end
	end

	local var5 = arg1.ChildAdded:Connect(onAdded)
	local var6 = arg1.ChildRemoved:Connect(function(arg1)
		local var2 = tbl2[arg1]
		if var2 then
			tbl2[arg1] = nil
			var2:destroy()
		end
	end)

	for k1, v1 in arg1:GetChildren() do
		onAdded(v1)
	end

	var3:onDestroy(function()
		var5:Disconnect()
		var6:Disconnect()
		for k1, v1 in tbl2, nil do
			local var1 = tbl2[k1]
			if not var1 then
				continue
			end

			tbl2[k1] = nil
			var1:destroy()
		end

		table.clear(tbl2)
	end)

	return var3
end

tbl1.fromDescendants = function(arg1, arg2)
	local var1 = if arg2 and arg2.isDynamic ~= nil then arg2.isDynamic else false
	local var2 = if arg2 and arg2.metadata ~= nil then arg2.metadata else nil
	local tbl2 = {}
	local var3 = var4.new({
		isDynamic = var1,
		metadata = var2,
		autoSync = if arg2 and arg2.autoSync ~= nil then arg2.autoSync else false,
	})

	local function onAdded(arg1)
		if arg1:IsA("BasePart") and (not tbl2[arg1]) then
			local var2 = tbl1.fromPart(arg1, { isDynamic = var1, metadata = var3.metadata })
			tbl2[arg1] = var2
			var3:add(var2)
		end
	end

	local var5 = arg1.DescendantAdded:Connect(onAdded)
	local var6 = arg1.DescendantRemoving:Connect(function(arg1)
		local var2 = tbl2[arg1]
		if var2 then
			tbl2[arg1] = nil
			var2:destroy()
		end
	end)

	for k1, v1 in arg1:GetDescendants() do
		onAdded(v1)
	end

	var3:onDestroy(function()
		var5:Disconnect()
		var6:Disconnect()
		for k1, v1 in tbl2, nil do
			local var1 = tbl2[k1]
			if not var1 then
				continue
			end

			tbl2[k1] = nil
			var1:destroy()
		end

		table.clear(tbl2)
	end)

	return var3
end

tbl1.fromTag = function(arg1, arg2)
	local var1 = if arg2 and arg2.isDynamic ~= nil then arg2.isDynamic else false
	local var3 = if arg2 and arg2.metadata ~= nil then arg2.metadata else nil
	local var5 = if arg2 and arg2.autoSync ~= nil then arg2.autoSync else false
	local tbl2 = {}
	local var6 = var4.new({ isDynamic = var1, metadata = var3, autoSync = var5 })
	local tbl3 = {}
	local function addPart(arg1)
		local var2 = (tbl2[arg1] or 0) + 1
		tbl2[arg1] = var2
		if var2 == 1 then
			local var3 = tbl1.fromPart(arg1, { isDynamic = var1, metadata = var6.metadata, autoSync = var5 })
			tbl3[arg1] = var3
			var6:add(var3)
		end
	end

	local tbl4 = {}
	local tbl5 = {}
	local function processTaggedInstance(arg1)
		local var1
		if arg1:IsDescendantOf(workspace) then
			if arg1:IsA("BasePart") then
				addPart(arg1)
				return
			end

			if not not tbl4[arg1] then
				return
			end

			local tbl1 = {
				arg1.DescendantAdded:Connect(function(arg1)
					if arg1:IsA("BasePart") then
						addPart(arg1)
					end
				end),
				(arg1.DescendantRemoving:Connect(function(arg1)
					if arg1:IsA("BasePart") then
						local var3 = (tbl2[arg1] or 0) - 1
						if var3 <= 0 then
							tbl2[arg1] = nil
							local var5 = tbl3[arg1]
							if not var5 then
								return
							end

							tbl3[arg1] = nil
							var5:destroy()
							return
						end

						tbl2[arg1] = var3
					end
				end)),
			}

			tbl4[arg1] = tbl1
			for k1, v1 in arg1:GetDescendants() do
				if not v1:IsA("BasePart") then
					continue
				end

				addPart(v1)
			end

			return
		end

		if arg1:IsA("BasePart") then
			local var4 = (tbl2[arg1] or 0) - 1
			if var4 <= 0 then
				tbl2[arg1] = nil
				local var6 = tbl3[arg1]
				if not var6 then
					return
				end

				tbl3[arg1] = nil
				var6:destroy()
				return
			end

			tbl2[arg1] = var4
			return
		end

		local var8 = tbl4[arg1]
		if var8 then
			var8[1]:Disconnect()
			var8[2]:Disconnect()
			tbl4[arg1] = nil
		end

		for k2, v2 in arg1:GetDescendants() do
			if not v2:IsA("BasePart") then
				continue
			end

			local var10 = (tbl2[v2] or 0) - 1
			if var10 <= 0 then
				tbl2[v2] = nil
				local var11 = tbl3[v2]
				if not var11 then
					continue
				end

				tbl3[v2] = nil
				var11:destroy()
			else
				tbl2[v2] = var10
			end
		end
	end

	local function stopWatching(arg1)
		local var2 = tbl5[arg1]
		if var2 then
			var2:Disconnect()
			tbl5[arg1] = nil
		end

		if arg1:IsA("BasePart") then
			local var5 = (tbl2[arg1] or 0) - 1
			if var5 <= 0 then
				tbl2[arg1] = nil
				local var7 = tbl3[arg1]
				if not var7 then
					return
				end

				tbl3[arg1] = nil
				var7:destroy()
				return
			end

			tbl2[arg1] = var5
			return
		end

		local var9 = tbl4[arg1]
		if var9 then
			var9[1]:Disconnect()
			var9[2]:Disconnect()
			tbl4[arg1] = nil
		end

		for k1, v1 in arg1:GetDescendants() do
			if not v1:IsA("BasePart") then
				continue
			end

			local var11 = (tbl2[v1] or 0) - 1
			if var11 <= 0 then
				tbl2[v1] = nil
				local var12 = tbl3[v1]
				if not var12 then
					continue
				end

				tbl3[v1] = nil
				var12:destroy()
			else
				tbl2[v1] = var11
			end
		end
	end

	local var7 = var2:GetInstanceAddedSignal(arg1):Connect(function(arg1)
		if tbl5[arg1] then
			return
		end

		tbl5[arg1] = arg1.AncestryChanged:Connect(function()
			processTaggedInstance(arg1)
		end)

		processTaggedInstance(arg1)
	end)

	local var8 = var2:GetInstanceRemovedSignal(arg1):Connect(stopWatching)
	for k1, v1 in var2:GetTagged(arg1) do
	if not tbl5[v1] then
			tbl5[v1] = v1.AncestryChanged:Connect(function()
				processTaggedInstance(v1)
			end)

			processTaggedInstance(v1)
		end
	end

	var6:onDestroy(function()
		var7:Disconnect()
		var8:Disconnect()
		for k1 in tbl5, nil do
			stopWatching(k1)
		end

		table.clear(tbl5)
		table.clear(tbl4)
		table.clear(tbl3)
		table.clear(tbl2)
	end)

	return var6
end

local function updateObserverZoneCount(arg1, arg2, arg3)
	local var2 = arg2 and var1.observerDynamicCount or var1.observerStaticCount
	local var3 = var2[arg1] or 0
	local var4 = var3 + arg3
	var2[arg1] = var4
	if var3 == 0 then
		if var4 ~= 1 then
			if not (var3 == 1 and var4 == 0) then
				return
			end

			if var4 ~= 0 then
				return
			end
		end
	end

	if var3 == 1 and var4 == 0 then
		local var10 = var1
		local var11 = var10.logicVersion + 1
		var10.logicVersion = var11
	end

	for k1, v1 in var1.groupToObservers, nil do
		if not v1[arg1] then
			continue
		end

		local var12 = var1.groups[k1]
		if not var12 then
			continue
		end

		for k2, v2 in var12.entities, nil do
			var1.dirtyTopology[v2] = true
		end
	end
end

tbl1.attach = function(arg1, arg2)
	local var2 = var1.zoneAttachedObservers[arg1.id]
	var2 = var2 or {}
	var1.zoneAttachedObservers[arg1.id] = var2
	if not table.find(var2, arg2.id) then
		table.insert(var2, arg2.id)
		updateObserverZoneCount(arg2.id, arg1.dynamic, 1)
	end

	if arg1.dynamic then
		local var4 = var1
		local var5 = var4.dynamicVersion + 1
		var4.dynamicVersion = var5
		return arg1
	end

	local var6 = var1
	local var7 = var6.staticVersion + 1
	var6.staticVersion = var7
	return arg1
end

tbl1.detach = function(arg1, arg2)
	local var3 = var1.zoneAttachedObservers[arg1.id]
	if not var3 then
		return arg1
	end

	local var6 = table.find(var3, arg2.id)
	if var6 then
		local var8 = #var3
		if var6 ~= var8 then
			local var9 = var3[var8]
			var3[var6] = var9
		end

		var3[var8] = nil
		updateObserverZoneCount(arg2.id, arg1.dynamic, -1)
	end

	if #var3 == 0 then
		var1.zoneAttachedObservers[arg1.id] = nil
	end

	if arg1.dynamic then
		local var11 = var1
		local var12 = var11.dynamicVersion + 1
		var11.dynamicVersion = var12
		return arg1
	end

	local var13 = var1
	local var14 = var13.staticVersion + 1
	var13.staticVersion = var14
	return arg1
end

local function setupAutoSync(arg1, arg2)
	var1.autoSyncZones[arg1.id] = arg1
	local var2 = arg1.syncConnections
	var2 = var2 or {}
	if arg2:IsA("BasePart") then
		local function fn4()
			local var3 = arg2.ExtentsSize * 0.5
			if var6[arg1.id] ~= var3 then
				var6[arg1.id] = var3
				var1.pendingDynamicRebuild = true
			end
		end

		table.insert(var2, arg2:GetPropertyChangedSignal("Size"):Connect(fn4))
	end

	if arg2:IsA("Part") then
		fn4 = function()
			local var3 = arg2.Shape.Value
			if var7[arg1.id] ~= var3 then
				var7[arg1.id] = var3
				var1.pendingDynamicRebuild = true
			end
		end

		table.insert(var2, arg2:GetPropertyChangedSignal("Shape"):Connect(fn4))
	end

	arg1.syncConnections = var2
	arg1:sync()
end

tbl1.setAutoSync = function(arg1, arg2)
	if arg1.autoSync == arg2 then
		return arg1
	end

	arg1.autoSync = arg2
	if arg2 then
		if not arg1.dynamic then
			arg1:setDynamic(true)
		end

		if arg1.reference then
			setupAutoSync(arg1, arg1.reference)
			return arg1
		end

		var3.warn("Cannot autoSync Zone %d without a tracked reference.", nil, arg1.id)
		return arg1
	end

	var1.autoSyncZones[arg1.id] = nil
	if arg1.syncConnections then
		for k1, v1 in arg1.syncConnections, nil do
			v1:Disconnect()
		end

		arg1.syncConnections = nil
	end

	return arg1
end

tbl1.setReference = function(arg1, arg2)
	arg1.reference = arg2
	if arg1.autoSync then
		var1.autoSyncZones[arg1.id] = nil
		if arg1.syncConnections then
			for k1, v1 in arg1.syncConnections, nil do
				v1:Disconnect()
			end

			arg1.syncConnections = nil
		end

		if arg2 then
			setupAutoSync(arg1, arg2)
		end
	end

	return arg1
end

local function getShapeEnumValue(arg1)
	if arg1:IsA("Part") then
		return arg1.Shape.Value
	end

	if arg1:IsA("WedgePart") then
		return Enum.PartType.Wedge.Value
	end

	if arg1:IsA("CornerWedgePart") then
		return Enum.PartType.CornerWedge.Value
	end

	return Enum.PartType.Block.Value
end

local var8 = var1.dynamicCFrames
local var9 = var1.staticCFrames
local var10 = var1.staticHalfSizes
local var11 = var1.staticTypes
tbl1.sync = function(arg1)
	local var4 = arg1.reference
	if not var4 then
		var3.warn("Zone:sync failed for Zone %d. No reference found.", nil, arg1.id)
		return arg1
	end

	local var13 = arg1.id
	if var4:IsA("BasePart") then
		local var15 = var4.CFrame
		local var16 = var4.ExtentsSize * 0.5
		local var17 = getShapeEnumValue(var4)
		if arg1.dynamic then
			local bool1 = false
			if var8[var13] ~= var15 then
				var8[var13] = var15
				bool1 = true
			end

			if var6[var13] ~= var16 then
				var6[var13] = var16
				bool1 = true
			end

			if var7[var13] ~= var17 then
				var7[var13] = var17
				bool1 = true
			end

			if bool1 then
				var1.pendingDynamicRebuild = true
				return arg1
			end
		end

		local bool2 = false
		if var9[var13] ~= var15 then
			var9[var13] = var15
			bool2 = true
		end

		if var10[var13] ~= var16 then
			var10[var13] = var16
			bool2 = true
		end

		if var11[var13] ~= var17 then
			var11[var13] = var17
			bool2 = true
		end

		if bool2 then
			var1.pendingStaticRebuild = true
		end

		return arg1
	end

	if not var4:IsA("Attachment") then
		if var4:IsA("Bone") then
			local var21 = var4.WorldCFrame
			if arg1.dynamic then
				if var8[var13] == var21 then
					return arg1
				end

				var8[var13] = var21
				var1.pendingDynamicRebuild = true
				return arg1
			end

			if var9[var13] == var21 then
				return arg1
			end

			var9[var13] = var21
			var1.pendingStaticRebuild = true
			return arg1
		end
	end

	return arg1
end

tbl1.setDynamic = function(arg1, arg2)
	if arg1.dynamic == arg2 then
		return arg1
	end

	arg1.dynamic = arg2
	local var2 = arg1.id
	local var4 = var1.zoneAttachedObservers[var2]
	if var4 then
		for k1, v1 in var4, nil do
			updateObserverZoneCount(v1, not arg2, -1)
			updateObserverZoneCount(v1, arg2, 1)
		end
	end

	if arg2 then
		var8[var2] = var9[var2]
		var6[var2] = var10[var2]
		var7[var2] = var11[var2]
		var9[var2] = nil
		var10[var2] = nil
		var11[var2] = nil
	else
		if arg1.autoSync then
			arg1:setAutoSync(false)
		end

		var9[var2] = var8[var2]
		var10[var2] = var6[var2]
		var11[var2] = var7[var2]
		var8[var2] = nil
		var6[var2] = nil
		var7[var2] = nil
	end

	var1.pendingStaticRebuild = true
	var1.pendingDynamicRebuild = true
	return arg1
end

tbl1.setCFrame = function(arg1, arg2)
	if arg1.dynamic then
		var8[arg1.id] = arg2
		var1.pendingDynamicRebuild = true
		return arg1
	end

	var9[arg1.id] = arg2
	var1.pendingStaticRebuild = true
	return arg1
end

tbl1.setPosition = function(arg1, arg2)
	local var1 = (arg1.dynamic and var8[arg1.id] or var9[arg1.id]).Rotation + arg2
	return arg1:setCFrame(var1)
end

tbl1.setSize = function(arg1, arg2)
	local var2 = arg2 * 0.5
	if arg1.dynamic then
		var6[arg1.id] = var2
		var1.pendingDynamicRebuild = true
		return arg1
	end

	var10[arg1.id] = var2
	var1.pendingStaticRebuild = true
	return arg1
end

tbl1.setShape = function(arg1, arg2)
	local var5 = tbl2[arg2]
	local var6 = Enum.PartType.Block.Value
	if var5 then
		var6 = var5
	else
		var3.warn("Invalid shape '%s'. Defaulting to Block.", nil, (tostring(arg2)))
	end

	if arg1.dynamic then
		var7[arg1.id] = var6
	else
		var11[arg1.id] = var6
	end

	if arg1.dynamic then
		local var9 = var1
		local var10 = var9.dynamicVersion + 1
		var9.dynamicVersion = var10
		return arg1
	end

	local var12 = var1
	local var13 = var12.staticVersion + 1
	var12.staticVersion = var13
	return arg1
end

tbl1.setMetadata = function(arg1, arg2)
	arg1.metadata = arg2
	return arg1
end

tbl1.getMetadata = function(arg1)
	return arg1.metadata
end

tbl1.getId = function(arg1)
	return arg1.id
end

tbl1.getReference = function(arg1)
	return arg1.reference
end

tbl1.getPosition = function(arg1)
	return (arg1.dynamic and var8[arg1.id] or var9[arg1.id]).Position
end

tbl1.getCFrame = function(arg1)
	return arg1.dynamic and var8[arg1.id] or var9[arg1.id]
end

tbl1.getSize = function(arg1)
	return (arg1.dynamic and var6[arg1.id] or var10[arg1.id]) * 2
end

tbl1.getShape = function(arg1)
	local var2 = arg1.dynamic and var7[arg1.id] or var11[arg1.id]
	if var2 == Enum.PartType.Block.Value then
		return "Block"
	end

	if var2 == Enum.PartType.Ball.Value then
		return "Ball"
	end

	if var2 == Enum.PartType.Cylinder.Value then
		return "Cylinder"
	end

	if var2 == Enum.PartType.Wedge.Value then
		return "Wedge"
	end

	if var2 == Enum.PartType.CornerWedge.Value then
		return "CornerWedge"
	end

	return "Block"
end

tbl1.isPointInside = function(arg1, arg2)
	local var13 = arg1.id
	if arg1.dynamic then
		local var14 = arg2
		local var15 = var8[var13]
		local var16 = var6[var13]
		local var17 = var7[var13]
		return var5(var14, var15, var16, var17)
	end

	local var18 = arg2
	local var19 = var9[var13]
	local var20 = var10[var13]
	local var21 = var11[var13]
	return var5(var18, var19, var20, var21)
end

tbl1.isDynamic = function(arg1)
	return arg1.dynamic
end

tbl1.onDestroy = function(arg1, arg2)
	if not arg1.onDestroyCallbacks then
		arg1.onDestroyCallbacks = {}
	end

	table.insert(arg1.onDestroyCallbacks, arg2)
	return function()
		local var2 = table.find(arg1.onDestroyCallbacks, arg2)
		if var2 then
			table.remove(arg1.onDestroyCallbacks, var2)
		end
	end
end

tbl1.destroy = function(arg1)
	var1.autoSyncZones[arg1.id] = nil
	local var2
	if arg1.syncConnections then
		for k1, v1 in arg1.syncConnections, nil do
			v1:Disconnect()
		end

		arg1.syncConnections = nil
	end

	local var3 = arg1.id
	local var5 = var1.zoneAttachedObservers[var3]
	local var12
	if var5 then
		for k2, v2 in var5, nil do
			updateObserverZoneCount(v2, arg1.dynamic, -1)
			var12 = var1.observerTrackingEntities[v2]
			if not var12 then
				continue
			end

			for k3, v3 in var12, nil do
				local var13 = var1.entityData[k3]
				if not var13 then
					continue
				end

				if var13.activeObserverMemberships[v2] ~= var3 then
					continue
				end

				var13.activeObserverMemberships[v2] = nil
				var12[k3] = nil
				local var14 = var1.observerExitedCallbacks[v2]
				if not var14 then
					continue
				end

				local var15 = var1.observerSafety[v2]
				local var16 = var1.entityToReference[k3] or k3
				for k4, v4 in var14, nil do
					if var15 then
						task.spawn(v4, var16, arg1, k3)
					else
						v4(var16, arg1, k3)
					end
				end
			end
		end
	end

	var1.zoneAttachedObservers[var3] = nil
	if arg1.onDestroyCallbacks then
		for k5, v5 in table.clone(arg1.onDestroyCallbacks) do
			task.spawn(v5)
		end

		table.clear(arg1.onDestroyCallbacks)
	end

	var1.zoneIdToZoneObj[var3] = nil
	if arg1.dynamic then
		var8[var3] = nil
		var6[var3] = nil
		var7[var3] = nil
		var1.pendingDynamicRebuild = true
	else
		var9[var3] = nil
		var10[var3] = nil
		var11[var3] = nil
		var1.pendingStaticRebuild = true
	end

	setmetatable(arg1, nil)
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Classes.Zones [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var1 = if arg1 and arg1.isDynamic ~= nil then arg1.isDynamic else false
	local var2 = if arg1 then arg1.metadata else nil
	return (setmetatable({
		dynamic = var1,
		metadata = var2,
		autoSync = if arg1 and arg1.autoSync ~= nil then arg1.autoSync else false,
		zones = {},
		observers = {},
		onDestroyObserverCleanups = {},
		onDestroyZoneCleanups = {},
	}, tbl1))
end

tbl1.attach = function(arg1, arg2)
	if arg1.observers[arg2] then
		return arg1
	end

	arg1.observers[arg2] = true
	local function fn2()
		arg1:detach(arg2)
	end

	arg1.onDestroyObserverCleanups[arg2] = arg2:onDestroy(fn2)
	for k1, v1 in arg1.zones, nil do
		arg2:attach(k1)
	end

	return arg1
end

tbl1.detach = function(arg1, arg2)
	if not arg1.observers[arg2] then
		return arg1
	end

	arg1.observers[arg2] = nil
	local var2 = arg1.onDestroyObserverCleanups[arg2]
	if var2 then
		var2()
		arg1.onDestroyObserverCleanups[arg2] = nil
	end

	for k1, v1 in arg1.zones, nil do
		arg2:detach(k1)
	end

	return arg1
end

tbl1.sync = function(arg1)
	if not arg1.dynamic then
		return arg1
	end

	for k1, v1 in arg1.zones, nil do
		k1:sync()
	end

	return arg1
end

tbl1.getZones = function(arg1)
	local tbl1 = {}
	for k1, v1 in arg1.zones, nil do
		table.insert(tbl1, k1)
	end

	return tbl1
end

tbl1.isDynamic = function(arg1)
	return arg1.dynamic
end

tbl1.isPointInside = function(arg1, arg2)
	for k1, v1 in arg1.zones, nil do
		if not k1:isPointInside(arg2) then
			continue
		end

		return true
	end

	return false
end

tbl1.setAutoSync = function(arg1, arg2)
	if arg1.autoSync == arg2 then
		return arg1
	end

	arg1.autoSync = arg2
	for k1, v1 in arg1.zones, nil do
		k1:setAutoSync(arg2)
	end

	return arg1
end

tbl1.setDynamic = function(arg1, arg2)
	if arg1.dynamic == arg2 then
		return arg1
	end

	arg1.dynamic = arg2
	for k1, v1 in arg1.zones, nil do
		k1:setDynamic(arg2)
	end

	return arg1
end

tbl1.setMetadata = function(arg1, arg2)
	arg1.metadata = arg2
	for k1, v1 in arg1.zones, nil do
		k1:setMetadata(arg2)
	end

	return arg1
end

tbl1.getMetadata = function(arg1)
	return arg1.metadata
end

tbl1.contains = function(arg1, arg2)
	return arg1.zones[arg2] == true
end

tbl1.iterZones = function(arg1)
	local var1 = nil
	return function()
		local var2 = next(arg1.zones, var1)
		var1 = var2
		return var1
	end
end

tbl1.getReferences = function(arg1)
	local tbl1 = {}
	for k1, v1 in arg1.zones, nil do
		local var1 = k1:getReference()
		if not var1 then
			continue
		end

		table.insert(tbl1, var1)
	end

	return tbl1
end

tbl1.iterReferences = function(arg1)
	local var1 = nil
	return function()
		while true do
			local var2 = next(arg1.zones, var1)
			var1 = var2
			if not var1 then
				return nil, nil
			end

			var2 = var1:getReference()
			if not var2 then
				continue
			end

			return var2, var1
		end
	end
end

tbl1.onDestroy = function(arg1, arg2)
	if not arg1.onDestroyCallbacks then
		arg1.onDestroyCallbacks = {}
	end

	table.insert(arg1.onDestroyCallbacks, arg2)
	return function()
		local var2 = table.find(arg1.onDestroyCallbacks, arg2)
		if var2 then
			table.remove(arg1.onDestroyCallbacks, var2)
		end
	end
end

tbl1.destroy = function(arg1)
	local var1
	if arg1.onDestroyCallbacks then
		for k1, v1 in arg1.onDestroyCallbacks, nil do
			task.spawn(v1)
		end

		table.clear(arg1.onDestroyCallbacks)
	end

	for k2, v2 in arg1.onDestroyObserverCleanups, nil do
		v2()
	end

	for k3, v3 in arg1.onDestroyZoneCleanups, nil do
		v3()
		k3:destroy()
	end

	table.clear(arg1.zones)
	table.clear(arg1.observers)
	table.clear(arg1.onDestroyObserverCleanups)
	table.clear(arg1.onDestroyZoneCleanups)
	setmetatable(arg1, nil)
end

tbl1.add = function(arg1, arg2)
	if arg1.zones[arg2] then
		return
	end

	if arg1.metadata ~= nil and arg2:getMetadata() == nil then
		arg2:setMetadata(arg1.metadata)
	end

	if arg1.dynamic and (not arg2:isDynamic()) then
		arg2:setDynamic(true)
	end

	if arg1.autoSync then
		arg2:setAutoSync(true)
	end

	arg1.zones[arg2] = true
	local function fn2()
		arg1:remove(arg2)
	end

	arg1.onDestroyZoneCleanups[arg2] = arg2:onDestroy(fn2)
	for k1, v1 in arg1.observers, nil do
		k1:attach(arg2)
	end
end

tbl1.remove = function(arg1, arg2)
	if not arg1.zones[arg2] then
		return
	end

	arg1.zones[arg2] = nil
	local var2 = arg1.onDestroyZoneCleanups[arg2]
	if var2 then
		var2()
		arg1.onDestroyZoneCleanups[arg2] = nil
	end

	for k1, v1 in arg1.observers, nil do
		k1:detach(arg2)
	end
end

return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Core.Scheduler [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local var1 = require(script.Parent.Parent.Utils.LinearBVH)
local var2 = require(script.Parent.State)
local var3 = require(script.Parent.Parent.Config)
local var4 = var2.entityToGroups
local var5 = var2.entityToObservers
local var6 = var2.groupToObservers
local var7 = var2.observerPrecisionSq
local var8 = var2.observerUpdateRate
local var9 = var2.entityData
local var10 = var2.buckets
local var11 = var2.bucketList
local var12 = var2.observerStaticCount
local var13 = var2.observerDynamicCount
local var14 = var2.zoneAttachedObservers
local var15 = nil
local var16 = var2.observerEnabled
local var17 = table.create(16)
local var18 = var2.observerPriorityMap
local num1 = 0
local var19 = table.create(16)
local var20 = table.create(16)
local var21 = nil
local var22 = nil
local var23 = require(script.Parent.Parent.Utils.Geometry).isPointInShape
local var24 = nil
local var25 = var2.staticCFrames
local var26 = var2.staticHalfSizes
local var27 = var2.staticTypes
local function processZoneHit(arg1)
	local var2 = var14[arg1]
	if not var2 then
		return
	end

	for k1, v1 in var2, nil do
		if not var15[v1] then
			continue
		end

		if var16[v1] == false then
			continue
		end

		local var4 = var17[v1]
		local var5 = var18[v1] or 0
		if not var4 then
			local var6 = num1 + 1
			num1 = var6
			var19[num1] = v1
			var20[v1] = arg1
			var17[v1] = var5
			if var21 >= var5 then
				continue
			end

			var21 = var5
		elseif var4 < var5 then
			var20[v1] = arg1
			var17[v1] = var5
			if var21 >= var5 then
				continue
			end

			var21 = var5
		else
			if var5 ~= var4 then
				continue
			end

			if var22[v1] ~= arg1 then
				continue
			end

			var20[v1] = arg1
		end
	end
end

local var28 = var2.dynamicCFrames
local var29 = var2.dynamicHalfSizes
local var30 = var2.dynamicTypes
local var31 = var2.dirtyProfiles
local function processProfileChange(arg1)
	local var2 = var4[arg1]
	if not var2 then
		return
	end

	local var12 = var5[arg1]
	if var12 then
		table.clear(var12)
	else
		var12 = {}
	end

	local num1 = math.huge
	local num2 = 0
	for k1, v1 in var2, nil do
		local var13 = var6[k1]
		if not var13 then
			continue
		end

		for k2, v2 in var13, nil do
			var12[k2] = true
			local var15 = var7[k2]
			local var16 = var8[k2]
			if var15 < num1 then
				num1 = var15
			end

			if num2 >= var16 then
				continue
			end

			num2 = var16
		end
	end

	local var17 = var9[arg1]
	local var22 = var17.updateRate
	if var22 ~= num2 then
		if var22 then
			if 0 < var22 then
				if var10[var22] then
					local var32 = var10[var22]
					local var33 = #var32
					local var35 = var17.bucketIndex
					local var36 = var32[var33]
					if var35 ~= var33 then
						var32[var35] = var36
						if var9[var36] then
							var9[var36].bucketIndex = var35
						end
					end

					var32[var33] = nil
					if #var32 == 0 then
						var10[var22] = nil
						local var38 = table.find(var11, var22)
						if var38 then
							table.remove(var11, var38)
						end
					end
				end
			end
		end

		if 0 < num2 then
			if not var10[num2] then
				var10[num2] = {}
				table.insert(var11, num2)
				table.sort(var11, function(arg1, arg2)
					return arg2 < arg1
				end)

			end

			local var39 = var10[num2]
			local var40 = #var39 + 1
			var39[var40] = arg1
			var17.bucketIndex = var40
		else
			var17.bucketIndex = 0
		end

		var17.updateRate = num2
	end

	if 0 < num2 then
		var17.precisionSq = num1
		var5[arg1] = var12
		return
	end

	var5[arg1] = nil
end

local var32 = var2.dirtyTopology
local function processTopologyChange(arg1)
	local var2 = var9[arg1]
	if not var2 then
		return
	end

	local var4 = var5[arg1]
	local bool1 = false
	local bool2 = false
	if var4 then
		for k1, v1 in var4, nil do
			if 0 < (var12[k1] or 0) then
				bool1 = true
			end

			if 0 < (var13[k1] or 0) then
				bool2 = true
			end

			if not bool1 then
				continue
			end

			if bool2 then
				break
			end
		end
	end

	var2.needsStatic = bool1
	var2.needsDynamic = bool2
end

local var33 = var3.Scheduler.autoSyncRate
local num2 = 0
local var34 = var2.autoSyncZones
local tbl1 = {}
local var35 = var3.Scheduler.frameBudget
local num3 = 1
local tbl2 = {}
local var36 = var3.Strategy.POS
local var37 = var3.Strategy.WORLD
local var38 = var3.Strategy.CFRAME
local var39 = var3.Strategy.TRANSFORM
local var40 = var3.Strategy.PRIM
local var41 = var3.Strategy.PIVOT
local var42 = var1.queryPoint
local var43 = var2.dynamicTree
local function queryCallbackDynamic(arg1)
	if var23(var24, var28[arg1], var29[arg1], var30[arg1]) then
		processZoneHit(arg1)
	end
end

local var44 = var2.staticTree
local function queryCallbackStatic(arg1)
	if var23(var24, var25[arg1], var26[arg1], var27[arg1]) then
		processZoneHit(arg1)
	end
end

local var45 = var2.observerTrackingEntities
local var46 = var2.observerExitedCallbacks
local var47 = var2.observerSafety
local var48 = var2.zoneIdToZoneObj
local var49 = var2.entityToReference
local function fireCallback(arg1, arg2, arg3, arg4, arg5)
	local var1
	if arg5 then
		for k1, v1 in arg1, nil do
			task.spawn(v1, arg2, arg3, arg4)
		end

		return
	end

	for k2, v2 in arg1, nil do
		v2(arg2, arg3, arg4)
	end
end

local var50 = var2.observerEnteredCallbacks
local var51 = var2.observerTransitionedCallbacks
local var52 = game:GetService("RunService")
local var53 = require(script.Parent.Parent.Utils.Log)
tbl1.update = function(arg1)
	local var1 = os.clock()
	for k1, v1 in var31, nil do
		var31[k1] = nil
		if not var9[k1] then
			continue
		end

		processProfileChange(k1)
	end

	for k2, v2 in var32, nil do
		var32[k2] = nil
		local var3 = var9
		local var4 = var3[k2]
		if not var4 then
			continue
		end

		var3 = k2
		processTopologyChange(var3)
	end

	if 0 < var33 then
		local var6 = num2 + arg1
		num2 = var6
		if 1 / var33 <= num2 then
			num2 = 0
			var6 = false
			for k3, v3 in var34, nil do
				local var7 = v3.reference
				if not var7 then
					continue
				end

				local var8 = var7:IsA("Attachment") and var7.WorldCFrame or var7.CFrame
				if var28[k3] == var8 then
					continue
				end

				var28[k3] = var8
				var6 = true
			end

			if var6 then
				var2.pendingDynamicRebuild = true
			end
		end
	end

	tbl1.rebuildTrees()
	if var35 < os.clock() - var1 then
		return
	end

	local var13 = #var11
	if var13 == 0 then
		return
	end

	if var13 < num3 then
		num3 = 1
	end

	local var14 = var2.dynamicVersion
	local var16 = var2.staticVersion
	local var18 = var2.logicVersion
	for i1 = 1, var13 do
		local var23 = var11[num3]
		local var25 = num3 % var13 + 1
		num3 = var25
		var25 = var10[var23]
		local var26 = #var25
		if var26 == 0 then
			continue
		end

		local var29 = tbl2[var23] or 1
		local var30 = math.clamp(math.ceil(var26 * var23 * arg1), 1, var26)
		local num4 = 0
		if var26 < var29 then
			var29 = 1
		end

		local num5 = 32
		repeat
			if num4 >= var30 then
				break
			end

			local var52 = var25[var29]
			local var53 = var9[var52]
			local var56 = var53.strategy
			local var57 = nil
			if var56 == var36 then
				var57 = var52.Position
			else
				if var56 == var37 then
					var57 = var52.WorldPosition
				else
					if var56 == var38 then
						var57 = var52.CFrame.Position
					else
						if var56 == var39 then
							var57 = var52.Transform.Position
						else
							if var56 == var40 then
								local var59 = var52.PrimaryPart
								var57 = var59 and var59.Position or var52:GetPivot().Position
							else
								if var56 == var41 then
									var57 = var52:GetPivot().Position
								end
							end
						end
					end
				end
			end

			local var61 = var53.needsDynamic
			local var62 = var53.needsStatic
			local bool1 = false
			local var63
			local var64
			if var53.logicVersion ~= var18 or (var61 and var53.dynamicVersion ~= var14 or var62 and var53.staticVersion ~= var16) then
				bool1 = true
			else
				local var65 = var53.lastPosition
				local var66 = var57.X - var65.X
				local var67 = var57.Y - var65.Y
				local var68 = var57.Z - var65.Z
				var64 = var53.precisionSq
				var63 = var66 * var66 + var67 * var67 + var68 * var68
				bool1 = var64 <= var63 and true
			end

			if bool1 then
				var53.lastPosition = var57
				var53.dynamicVersion = var14
				var53.logicVersion = var18
				var53.staticVersion = var16
				var15 = var5[var52]
				var22 = var53.activeObserverMemberships
				var24 = var57
				num1 = 0
				var21 = -math.huge
				if var61 then
					var42(var43, var57, queryCallbackDynamic)
				end

				if var62 then
					var42(var44, var57, queryCallbackStatic)
				end

				local var69 = var53.activeObserverMemberships
				for k4, v4 in var69, nil do
					local var71 = var17[k4]
					if not var71 or var21 > var71 then
						var69[k4] = nil
						if var45[k4] then
							var45[k4][var52] = nil
						end

						local var72 = var46[k4]
						if not var72 then
							continue
						end

						fireCallback(var72, var49[var52] or var52, var48[v4], var52, var47[k4])
					end
				end

				for i2 = 1, num1 do
					local var73 = var19[i2]
					var17[var73] = nil
					var20[var73] = nil
					var19[i2] = nil
					local var74 = var17[var73]
					if not var45[var73] or var74 < var21 then
						continue
					end

					local var75 = var69[var73]
					local var76 = var20[var73]
					if var75 == var76 then
						continue
					end

					var69[var73] = var76
					local var77 = var47[var73]
					if not var75 then
						var45[var73][var52] = true
						local var78 = var50[var73]
						if not var78 then
							continue
						end

						fireCallback(var78, var49[var52] or var52, var48[var76], var52, var77)
					else
						local var79 = var51[var73]
						if not var79 then
							continue
						end

						fireCallback(var79, var49[var52] or var52, var48[var76], var52, var77)
					end
				end
			end

			var29 = var29 + 1
			if var26 < var29 then
				var29 = 1
			end

			num5 = num5 - 1
			if num5 == 0 then
				if var35 < os.clock() - var1 then
					break
				end
			end

			num4 = num4 + 1
			local num6 = 32
		until var35 < os.clock() - var1

		tbl2[var23] = var29
		if var35 < os.clock() - var1 then
			return
		end
	end
end

local var54 = nil
tbl1.setEnabled = function(arg1)
	if arg1 then
		if not not var54 then
			return
		end

		var54 = var52.PostSimulation:Connect(tbl1.update)
		return
	end

	if var54 then
		var54:Disconnect()
		var54 = nil
	end
end

tbl1.setAutoSyncRate = function(arg1)
	if arg1 <= 0 then
		var33 = 0
		return
	end

	var33 = arg1
end

tbl1.setFrameBudget = function(arg1)
	if arg1 <= 0 then
		var53.fatal("frameBudget must be greater than 0.", nil)
	end

	var35 = arg1
end

tbl1.rebuildTrees = function()
	if var2.pendingDynamicRebuild then
		var1.build(var43, var28, var29)
		var2.pendingDynamicRebuild = false
		local var3 = var2
		local var4 = var3.dynamicVersion + 1
		var3.dynamicVersion = var4
	end

	if var2.pendingStaticRebuild then
		var1.build(var44, var25, var26)
		var2.pendingStaticRebuild = false
		local var5 = var2
		local var6 = var5.staticVersion + 1
		var5.staticVersion = var6
	end
end

tbl1.setEnabled(var3.Scheduler.enabled)
return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Core.State [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local tbl1 = {
	nextZoneId = 1,
	nextObserverId = 1,
	nextGroupId = 1,
	staticCFrames = {},
	staticHalfSizes = {},
	staticTypes = {},
	dynamicCFrames = {},
	dynamicHalfSizes = {},
	dynamicTypes = {},
	staticTree = { nodes = {}, count = 0 },
	dynamicTree = { nodes = {}, count = 0 },
	pendingStaticRebuild = false,
	pendingDynamicRebuild = false,
	staticVersion = 0,
	dynamicVersion = 0,
	logicVersion = 0,
	groups = {},
	groupToObservers = {},
	groupEntityCleanups = {},
	entityToGroups = {},
	entityData = {},
	entityToObservers = {},
	entityToReference = setmetatable({}, { __mode = "kv" }),
}

tbl1.referenceToEntity = setmetatable({}, { __mode = "kv" })
tbl1.dirtyProfiles = {}
tbl1.dirtyTopology = {}
tbl1.bucketList = {}
tbl1.buckets = {}
tbl1.observerTrackingEntities = {}
tbl1.observerPriorityMap = {}
tbl1.observerEnteredCallbacks = {}
tbl1.observerExitedCallbacks = {}
tbl1.observerTransitionedCallbacks = {}
tbl1.observerEnabled = {}
tbl1.observerSafety = {}
tbl1.observerUpdateRate = {}
tbl1.observerPrecisionSq = {}
tbl1.observerDynamicCount = {}
tbl1.observerStaticCount = {}
tbl1.autoSyncZones = {}
tbl1.zoneAttachedObservers = {}
tbl1.zoneIdToZoneObj = {}
tbl1.observerIdToObserverObj = {}
return tbl1

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Core.PlayerTracker [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local tbl1 = {}
local tbl2 = {}
local var1 = require(script.Parent.State)
local function trackPlayer(arg1)
	if tbl1[arg1] then
		return
	end

	local var2 = nil
	local var3 = nil
	local function clearHrp(arg1)
		if arg1 and arg1 ~= var2 then
			return
		end

		if var3 then
			var3:Disconnect()
			var3 = nil
		end

		if var2 then
			local var6 = tbl2[arg1]
			if var6 then
				for k1, v1 in var6, nil do
					if var1.groups[k1] then
						v1:_remove(var2)
					else
						var6[k1] = nil
					end
				end
			end

			var1.entityToReference[var2] = nil
			if var1.referenceToEntity[arg1] == var2 then
				var1.referenceToEntity[arg1] = nil
			end

			var2 = nil
		end
	end

	local var4 = nil
	local var5 = nil
	local function checkHrp(arg1)
		if arg1 ~= var5 then
			return
		end

		local var6 = arg1:FindFirstChild("HumanoidRootPart")
		if var6 and (var6:IsA("BasePart") and var6 ~= var2) then
			clearHrp()
			var2 = var6
			var1.entityToReference[var6] = arg1
			var1.referenceToEntity[arg1] = var6
			local var8 = tbl2[arg1]
			if var8 then
				for k1, v1 in var8, nil do
					if var1.groups[k1] then
						v1:_add(var6)
					else
						var8[k1] = nil
					end
				end
			end

			var3 = var6.AncestryChanged:Connect(function(_, arg2)
				if not arg2 then
					clearHrp(var6)
				end
			end)

		end
	end

	local var6 = arg1.CharacterAdded:Connect(function(arg1)
		clearHrp()
		if var4 then
			var4:Disconnect()
			var4 = nil
		end

		var5 = nil
		var5 = arg1
		checkHrp(arg1)
		var4 = arg1.ChildAdded:Connect(function(arg1)
			if arg1.Name == "HumanoidRootPart" then
				checkHrp(arg1)
			end
		end)
	end)

	local var7 = arg1.CharacterRemoving:Connect(function(arg1)
		if var5 == arg1 then
			clearHrp()
			if var4 then
				var4:Disconnect()
				var4 = nil
			end

			var5 = nil
		end
	end)

	tbl1[arg1] = function()
		var6:Disconnect()
		var7:Disconnect()
		clearHrp()
		if var4 then
			var4:Disconnect()
			var4 = nil
		end

		var5 = nil
	end

	if arg1.Character then
		clearHrp()
		local var8 = arg1.Character
		if var4 then
			var4:Disconnect()
		end

		checkHrp(var8)
		var8.ChildAdded:Connect(function(arg1)
			if arg1.Name == "HumanoidRootPart" then
				checkHrp(var8)
			end
		end)

	end
end

local var2 = game:GetService("Players")
var2.PlayerRemoving:Connect(function(arg1)
	local var2 = tbl1[arg1]
	if var2 then
		var2()
	end

	tbl1[arg1] = nil
	tbl2[arg1] = nil
end)

return {
	subscribe = function(arg1, arg2)
		if not tbl2[arg1] then
			tbl2[arg1] = {}
		end

		tbl2[arg1][arg2.id] = arg2
		trackPlayer(arg1)
		local var3 = var1.referenceToEntity[arg1]
		if var3 then
			arg2:_add(var3)
		end
	end,
	unsubscribe = function(arg1, arg2)
		if tbl2[arg1] then
			tbl2[arg1][arg2.id] = nil
		end

		local var3 = var1.referenceToEntity[arg1]
		if var3 then
			arg2:_remove(var3)
		end
	end,
}

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Utils.Geometry [ModuleScript]
-- y u r i

local var1 = Enum.PartType.Block.Value
local var2 = Enum.PartType.Ball.Value
local var3 = Enum.PartType.Cylinder.Value
local var4 = Enum.PartType.Wedge.Value
local var5 = Enum.PartType.CornerWedge.Value
local var6 = table.create(1024)
for i1 = 0, 1023 do
	local var7 = i1
	var7 = bit32.band(bit32.bor(bit32.lshift(var7, 16), var7), 4278190335)
	var7 = bit32.band(bit32.bor(bit32.lshift(var7, 8), var7), 251719695)
	var7 = bit32.band(bit32.bor(bit32.lshift(var7, 4), var7), 51130563)
	var7 = bit32.band(bit32.bor(bit32.lshift(var7, 2), var7), 153391689)
	var6[i1 + 1] = var7
end

return {
	unionBounds = function(arg1, arg2, arg3, arg4)
		return vector.min(arg1, arg3), (vector.max(arg2, arg4))
	end,
	getObjectBounds = function(arg1, arg2)
		local var1 = arg1.RightVector
		local var2 = arg1.UpVector
		local var3 = arg1.LookVector
		local var4 = arg1.Position
		local var5 = Vector3.new(math.abs(var1.X) * arg2.X + math.abs(var2.X) * arg2.Y + math.abs(var3.X) * arg2.Z, math.abs(var1.Y) * arg2.X + math.abs(var2.Y) * arg2.Y + math.abs(var3.Y) * arg2.Z, math.abs(var1.Z) * arg2.X + math.abs(var2.Z) * arg2.Y + math.abs(var3.Z) * arg2.Z)
		return var4 - var5, var4 + var5
	end,
	getMortonScale = function(arg1, arg2)
		local var1 = arg2 - arg1
		return 1023 / var1.X, 1023 / var1.Y, 1023 / var1.Z
	end,
	positionToMortonCode = function(arg1, arg2, arg3, arg4, arg5)
		return (bit32.bor(var6[bit32.band(math.floor((math.clamp((arg1.X - arg2.X) * arg3, 0, 1023))), 1023) + 1], bit32.lshift(var6[bit32.band(math.floor((math.clamp((arg1.Y - arg2.Y) * arg4, 0, 1023))), 1023) + 1], 1), (bit32.lshift(var6[bit32.band(math.floor((math.clamp((arg1.Z - arg2.Z) * arg5, 0, 1023))), 1023) + 1], 2))))
	end,
	isPointInShape = function(arg1, arg2, arg3, arg4)
		if arg4 == var1 then
			local var6 = vector.abs((arg2:PointToObjectSpace(arg1)))
			return vector.min(var6, arg3) == var6
		end

		if arg4 == var3 then
			local var9 = arg3.X
			local var10 = arg2.Position - arg2.RightVector * var9
			local var11 = arg2.RightVector
			local var14 = vector.dot(arg1 - var10, var11)
			if 0 <= var14 then
				if var14 <= var9 * 2 then
					local var16 = var10 + var11 * var14
					return vector.dot(arg1 - var16, arg1 - var16) <= arg3.Y * arg3.Y
				end
			end

			return false
		end

		if arg4 == var2 then
			local var18 = arg2.Position
			return vector.dot(var18 - arg1, var18 - arg1) <= arg3.X * arg3.X
		end

		if arg4 == var4 then
			local var19 = arg2:PointToObjectSpace(arg1)
			local var20 = vector.abs(var19)
			if vector.min(var20, arg3) == var20 then
				local var22 = arg3 * 2
				return var19.Y / var22.Y - var19.Z / var22.Z <= 0
			end

			return false
		end

		if arg4 == var5 then
			local var24 = arg3 * 2
			local var25 = arg2:PointToObjectSpace(arg1)
			if 0 < vector.dot(var25, (vector.normalize((Vector3.new(0, var24.Z, var24.Y))))) then
				return false
			end

			if 0 < vector.dot(var25, (vector.normalize((Vector3.new(-var24.Y, var24.X, 0))))) then
				return false
			end

			local var26 = vector.abs(var25)
			return vector.min(var26, arg3) == var26
		end

		return false
	end,
}

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Utils.LinearBVH [ModuleScript]
-- y u r i

require(script.Parent.Parent.Types)
local var1 = Vector3.new(1, 1, 1) * math.huge
local var2 = require(script.Parent.Geometry)
local function getSplitPos(arg1, arg2, arg3)
	if arg3 == arg2 + 1 then
		return arg2 + 1
	end

	local var3 = arg1[arg2].mortonCode
	local var4 = arg1[arg3].mortonCode
	if var3 == var4 then
		return (arg2 + arg3) // 2
	end

	local var5 = bit32.lshift(1, 31 - bit32.countlz((bit32.bxor(var3, var4))))
	local var6 = bit32.band(var3, var5)
	local var7 = arg2
	local var8 = arg3
	while true do
		if 1 >= var8 - var7 then
			break
		end

		local var9 = (var7 + var8) // 2
		if bit32.band(arg1[var9].mortonCode, var5) == var6 then
			var7 = var9
		else
		end

		local var10 = var9
	end

	return var7 + 1
end

local var3 = var2.unionBounds
local tbl1 = {}
local tbl2 = {}
local var4 = -var1
local var5 = var2.getObjectBounds
local tbl3 = {}
local tbl4 = {}
local var6 = var2.getMortonScale
local var7 = var2.positionToMortonCode
local function buildFlatTree(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var2 = arg6.nodes[arg7]
	if not var2 then
		var2 = {}
		arg6.nodes[arg7] = var2
	end

	if arg4 == arg5 then
		local var5 = arg1[arg4].id
		local var6 = arg2[var5]
		var2.min = var6
		local var7 = arg3[var5]
		var2.max = var7
		var2.id = var5
		var2.skipIndex = arg7 + 1
		return arg7 + 1, var6, var7
	end

	local var8 = getSplitPos(arg1, arg4, arg5)
	var2.id = -1
	local var9, var10, var11 = buildFlatTree(arg1, arg2, arg3, arg4, var8 - 1, arg6, arg7 + 1)
	local var12, var13, var14 = buildFlatTree(arg1, arg2, arg3, var8, arg5, arg6, var9)
	local var15, var16 = var3(var10, var11, var13, var14)
	var2.min = var15
	var2.max = var16
	var2.skipIndex = var12
	return var12, var15, var16
end

return {
	build = function(arg1, arg2, arg3)
		table.clear(tbl1)
		table.clear(tbl2)
		local var2 = var1
		local var3 = var4
		local num1 = 0
		for k1, v1 in arg2, nil do
			local var8, var9 = var5(v1, arg3[k1])
			tbl1[k1] = var8
			tbl2[k1] = var9
			num1 = num1 + 1
			local var12 = tbl3[num1]
			var2 = vector.min(var2, var8)
			var3 = vector.max(var3, var9)
			if not var12 then
				local var14 = #tbl4
				if 0 < var14 then
					tbl4[var14] = nil
					var12 = tbl4[var14]
				else
					var12 = { id = 0, mortonCode = 0 }
				end

				tbl3[num1] = var12
			end

			var12.id = k1
		end

		if num1 == 0 then
			arg1.count = 0
			return
		end

		local var16 = #tbl3
		if num1 < var16 then
			local var17 = #tbl4
			for i1 = num1 + 1, var16 do
				var17 = var17 + 1
				tbl4[var17] = tbl3[i1]
				tbl3[i1] = nil
			end
		end

		local var18 = vector.max(Vector3.new(1, 1, 1), (var3 - var2) * 0.01)
		local var19 = var2 - var18
		local var20, var21, var22 = var6(var19, var3 + var18)
		for i2 = 1, num1 do
			local var23 = tbl3[i2]
			var23.mortonCode = var7(arg2[var23.id].Position, var19, var20, var21, var22)
		end

		table.sort(tbl3, function(arg1, arg2)
			return arg1.mortonCode < arg2.mortonCode
		end)

		local var24 = buildFlatTree(tbl3, tbl1, tbl2, 1, num1, arg1, 1) - 1
		arg1.count = var24
	end,
	queryPoint = function(arg1, arg2, arg3)
		local var1 = arg1.nodes
		local var2 = arg1.count
		local var3 = arg2.X
		local var4 = arg2.Y
		local var5 = arg2.Z
		local num1 = 1
		while num1 <= var2 do
			local var6 = var1[num1]
			local var7 = var6.min
			local var10 = var6.max
			if var7.X <= var3 then
				if var3 <= var10.X then
					if var7.Y <= var4 then
						if var4 <= var10.Y then
							if var7.Z <= var5 then
								if var5 <= var10.Z then
									local var16 = var6.id
									if 0 >= var16 then
										continue
									end

									arg3(var16)
								else
									num1 = num1 + 1
								end
							else
								local var17 = var6.skipIndex
							end
						else
						end
					else
						local var18 = var6.skipIndex
					end
				else
				end
			else
				local var19 = var6.skipIndex
			end
		end
	end,
}

--- ReplicatedStorage.ModuleLoader.Libs.QuickZone.Utils.Log [ModuleScript]
-- y u r i

local function formatLog(arg1, arg2, ...)
	local var1 = arg2
	var1 = var1 or debug.traceback("", 3)
	local var2 = ("[QuickZone] %*"):format((string.format(arg1, ...)))
	if var1 ~= "" then
		var2 = var2 .. ([[ 
---- Stack trace ----
%*]]):format(var1)

	end

	return (var2:gsub([[
]], [[
    ]]))
end

return {
	info = function(arg1, arg2, ...)
		local var1 = arg1
		local var2 = arg2
		print(formatLog(var1, var2, ...))
	end,
	warn = function(arg1, arg2, ...)
		local var1 = arg1
		local var2 = arg2
		warn(formatLog(var1, var2, ...))
	end,
	fatal = function(arg1, arg2, ...)
		error(formatLog(arg1, arg2, ...), 0)
	end,
	nonFatal = function(arg1, arg2, ...)
		task.spawn(error, formatLog(arg1, arg2, ...), 0)
	end,
}

--- ReplicatedStorage.ModuleLoader.Configs.DataTemplate [ModuleScript]
-- y u r i

local tbl1 = {
	Money = 0,
	Wins = 0,
	FirstJoined = true,
	GroupJoined = false,
	UpdateLogChecked = 0,
	Towers = {},
	Items = {},
	ActiveQuests = {},
	TradeHistory = {},
	RedeemedCodes = {},
	Boosts = {},
	StoredBoosts = { Coins = 0, Lucky = 0 },
	Settings = { Trades = "All", Sounds = true, Music = true },
	OnlineTime = 0,
	ClaimedGifts = {},
	SessionStart = 0,
	Streak = 0,
	Playtime = 0,
	DailyClaimed = 0,
	LastClaimedDaily = 0,
	TradedEver = 0,
	TotalMoney = 0,
	Loses = 0,
	TotalSummons = 0,
	Spent = 0,
	InventorySpace = 500,
	Luck = 1,
	CoinsMultiplier = 1,
	ActivatedGamepasses = {},
	StarterPack = false,
	PackTimeToLeft = 0,
}

return table.freeze(tbl1)

--- ReplicatedStorage.ModuleLoader.Configs.Updates [ModuleScript]
-- y u r i

return {
	{
		Title = "Release",
		Date = "09/19/2026",
		Logs = {
			"\240\159\147\186 11 Units",
			"\240\159\146\165 3 Modes",
			"\240\159\146\176 Jetpack Cameraman",
			"\240\159\148\168 Keybinds for Placing Troops",
			"\240\159\148\151 Codes (RELEASE)",
		},
	},
	{
		Title = "Update 1",
		Date = "09/24/2026",
		Logs = {
			"\240\159\148\138 Cinemaman (Mythic)",
			"\240\159\147\185 Titan Cameraman (Legendary)",
			"\240\159\147\186 Titan TV Man (Legendary)",
			"\240\159\159\163 Insane Mode",
			"\240\159\143\156 New Desert Map",
			"\226\153\191 Trades",
		},
	},
}

--- ReplicatedStorage.ModuleLoader.Configs.Config [ModuleScript]
-- y u r i

local str1 = "Rare"
local tbl1 = {
	GameSettings = {
		SellValues = {
			Basic = 5,
			Uncommon = 10,
			Rare = 25,
			Epic = 50,
			Legendary = 100,
			Mythic = 250,
			Exclusive = 50,
		},
		RarityOrder = { Basic = 1, Uncommon = 2, Rare = 3, Epic = 4, Legendary = 5, Mythic = 6, Exclusive = 7 },
		HotbarSlots = 5,
		StarterTower = "Speakerman",
		SummonRarities = { "Basic", "Uncommon", str1, "Epic", "Legendary", "Mythic" },
		SummonCrates = { {
			Name = "Basic Crate",
			SummonChances = { Basic = 49.9, Uncommon = 30, Rare = 15, Epic = 4, Legendary = 1, Mythic = 0.1 },
			SummonPrice = 100,
		} },
		SummonInterval = 1800,
	},
	Ids = {
		Passes = {},
		Products = {
			Coins1 = {
				PassName = "400 Coins",
				Rarity = "Exclusive",
				Id = 3710768175,
				Icon = "rbxassetid://108572549430689",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica:Set({ "Money" }, (var2.Replica.Data.Money or 0) + 400)
					return true
				end,
			},
			Coins2 = {
				PassName = "1000 Coins",
				Rarity = "Exclusive",
				Id = 3710768219,
				Icon = "rbxassetid://108572549430689",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica:Set({ "Money" }, (var2.Replica.Data.Money or 0) + 1000)
					return true
				end,
			},
			Coins3 = {
				PassName = "3000 Coins",
				Rarity = "Exclusive",
				Id = 3710768257,
				Icon = "rbxassetid://108572549430689",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica:Set({ "Money" }, (var2.Replica.Data.Money or 0) + 3000)
					return true
				end,
			},
			Coins4 = {
				PassName = "10000 Coins",
				Rarity = "Exclusive",
				Id = 3710768326,
				Icon = "rbxassetid://108572549430689",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica:Set({ "Money" }, (var2.Replica.Data.Money or 0) + 10000)
					return true
				end,
			},
			DoubleCoins = {
				PassName = "Double Coins",
				Rarity = "Legendary",
				Id = 3712996813,
				Icon = "rbxassetid://110975131493020",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica.Data.ActivatedGamepasses.DoubleCoins = true
					var2.Replica:Set({ "ActivatedGamepasses" }, var2.Replica.Data.ActivatedGamepasses)
					return true
				end,
			},
			DoubleLuck = {
				PassName = "Double Luck",
				Rarity = "Uncommon",
				Id = 3712996790,
				Icon = "rbxassetid://125310343115552",
				Reward = function(arg1)
					local var2 = shared.Modules.Session.GetSession(arg1)
					if not var2 then
						warn((("[DeveloperProducts] No active session for player %*"):format(arg1.Name)))
						return false
					end

					var2.Replica.Data.ActivatedGamepasses.DoubleLuck = true
					var2.Replica:Set({ "ActivatedGamepasses" }, var2.Replica.Data.ActivatedGamepasses)
					return true
				end,
			},
			CoinBoost1 = {
				PassName = "Coin Boost 1",
				Rarity = "Exclusive",
				Id = 3712754158,
				Icon = "",
				Reward = function(_)
				end,
			},
			CoinBoost10 = {
				PassName = "Coin Boost 10",
				Rarity = "Exclusive",
				Id = 3712754426,
				Icon = "",
				Reward = function(_)
				end,
			},
			LuckBoost1 = {
				PassName = "Luck Boost 1",
				Rarity = "Exclusive",
				Id = 3712754946,
				Icon = "",
				Reward = function(_)
				end,
			},
			LuckBoost10 = {
				PassName = "Luck Boost 10",
				Rarity = "Exclusive",
				Id = 3712754983,
				Icon = "",
				Reward = function(_)
				end,
			},
			["Jetpack Pack"] = {
				PassName = "Jetpack Pack",
				Rarity = "Exclusive",
				Id = 3713415844,
				Icon = "",
				Reward = function(_)
				end,
			},
			["Epic Pack"] = {
				PassName = "Epic Pack",
				Rarity = "Exclusive",
				Id = 3713586813,
				Icon = "",
				Reward = function(_)
				end,
			},
		},
	},
	Towers = {},
}

for k1, v1 in script.Towers:GetChildren() do
	local var1, var2 = xpcall(function()
		local var1 = v1
		return require(var1)
	end, function(arg1)
		warn((([=[[Config] Error while loading config %*: %* 

%*
]=]):format(v1:GetFullName(), arg1, (debug.traceback()))))
	end)

	if not var1 then
		continue
	end

	tbl1.Towers[v1.Name] = var2
end

tbl1.Enemies = {}
for k2, v2 in script.Enemies:GetChildren() do
	local var3, var4 = xpcall(function()
		local var1 = v2
		return require(var1)
	end, function(arg1)
		warn((([=[[Config] Error while loading config %*: %* 

%*
]=]):format(v2:GetFullName(), arg1, (debug.traceback()))))
	end)

	if not var3 then
		continue
	end

	tbl1.Enemies[v2.Name] = var4
end

local var5 = tbl1
return table.freeze(var5)

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Camo Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Camo Toilet",
	MoneyForDeath = 150,
	BaseHealth = 1600,
	Speed = 6,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Toilet",
	MoneyForDeath = 10,
	BaseHealth = 50,
	Speed = 5,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Small Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Small Toilet",
	MoneyForDeath = 5,
	BaseHealth = 25,
	Speed = 8,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Large Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Large Toilet",
	MoneyForDeath = 50,
	BaseHealth = 600,
	Speed = 3.5,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Boss Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Boss Toilet",
	MoneyForDeath = 100,
	BaseHealth = 3000,
	Speed = 2.5,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Jetpack Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Jetpack Toilet",
	MoneyForDeath = 10,
	BaseHealth = 90,
	Speed = 3,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Assassin Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Assassin Toilet",
	MoneyForDeath = 15,
	BaseHealth = 150,
	Speed = 10,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Spider Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Spider Toilet",
	MoneyForDeath = 30,
	BaseHealth = 200,
	Speed = 4.5,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.DJ Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "DJ Toilet",
	MoneyForDeath = 40,
	BaseHealth = 300,
	Speed = 4,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Brown Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Brown Toilet",
	MoneyForDeath = 15,
	BaseHealth = 100,
	Speed = 4.5,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Boss Toilet 2.0 [ModuleScript]
-- y u r i

return {
	DisplayName = "Boss Toilet 2.0",
	MoneyForDeath = 200,
	BaseHealth = 10000,
	Speed = 3,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Glasses Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Glasses Toilet",
	MoneyForDeath = 40,
	BaseHealth = 500,
	Speed = 3,
	HideDetection = true,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Large Glasses Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Large Glasses Toilet",
	MoneyForDeath = 100,
	BaseHealth = 1000,
	Speed = 3.5,
	HideDetection = true,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Vacuum Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Vacuum Toilet",
	MoneyForDeath = 100,
	BaseHealth = 7500,
	Speed = 4,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Boss Toilet 2.5 [ModuleScript]
-- y u r i

return {
	DisplayName = "Boss Toilet 2.5",
	MoneyForDeath = 300,
	BaseHealth = 30000,
	Speed = 2,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Rocket Toilet [ModuleScript]
-- y u r i

return {
	DisplayName = "Rocket Toilet",
	MoneyForDeath = 150,
	BaseHealth = 10000,
	Speed = 6,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Boss Toilet 3.0 [ModuleScript]
-- y u r i

return {
	DisplayName = "Boss Toilet 3.0",
	MoneyForDeath = 300,
	BaseHealth = 92593,
	Speed = 4,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Enemies.Infected Titan Speakerman [ModuleScript]
-- y u r i

return {
	DisplayName = "Infected Titan Speakerman",
	MoneyForDeath = 300,
	BaseHealth = 92593,
	Speed = 7,
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Basic",
	Icon = "rbxassetid://103892795367767",
	Tags = {},
	Upgrades = {
		{ Price = 80, Damage = 25, Cooldown = 3, Range = 8 },
		{ Price = 150, Damage = 50, Cooldown = 2, Range = 10 },
		{ Price = 300, Damage = 100, Cooldown = 1, Range = 12 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Speakerman [ModuleScript]
-- y u r i

return {
	Rarity = "Basic",
	Icon = "rbxassetid://89277376766701",
	NotInSummon = true,
	Tags = {},
	Upgrades = {
		{ Price = 100, Damage = 10, Cooldown = 1, Range = 6 },
		{ Price = 150, Damage = 25, Cooldown = 0.7, Range = 8 },
		{ Price = 300, Damage = 50, Cooldown = 0.5, Range = 10 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Large Speakerman [ModuleScript]
-- y u r i

return {
	Rarity = "Epic",
	Icon = "rbxassetid://96347180362433",
	Tags = {},
	Upgrades = {
		{ Price = 180, Damage = 50, Cooldown = 1, Range = 8 },
		{ Price = 225, Damage = 100, Cooldown = 0.7, Range = 12 },
		{ Price = 450, Damage = 125, Cooldown = 0.5, Range = 15 },
		{ Price = 600, Damage = 200, Cooldown = 0.5, Range = 15 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Titan Speakerman [ModuleScript]
-- y u r i

return {
	Rarity = "Legendary",
	Icon = "rbxassetid://77149806010872",
	Tags = {},
	PlacementLimit = 10,
	Upgrades = {
		{ Price = 500, Damage = 100, Cooldown = 1, Range = 15 },
		{ Price = 400, Damage = 150, Cooldown = 0.7, Range = 17 },
		{ Price = 600, Damage = 250, Cooldown = 0.5, Range = 19 },
		{ Price = 1000, Damage = 500, Cooldown = 0.5, Range = 22 },
		{ Price = 1500, Damage = 1000, Cooldown = 0.5, Range = 25 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Ninja Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Legendary",
	Icon = "rbxassetid://93549529680407",
	Tags = {},
	Upgrades = {
		{ Price = 200, Damage = 50, Cooldown = 1, Range = 10 },
		{ Price = 200, Damage = 75, Cooldown = 0.7, Range = 12 },
		{ Price = 300, Damage = 100, Cooldown = 0.5, Range = 15 },
		{ Price = 500, Damage = 200, Cooldown = 0.4, Range = 17 },
		{ Price = 600, Damage = 400, Cooldown = 0.4, Range = 20 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.TV Man [ModuleScript]
-- y u r i

local tbl1 = { Color = Color3.fromRGB(235, 0, 0) }
local tbl2 = {
	Rarity = "Rare",
	Icon = "rbxassetid://129989219815177",
	HideDetection = true,
	Tags = { AOE = tbl1 },
}

tbl1 = {
	Price = 200,
	Damage = 10,
	Cooldown = 0.5,
	Range = 6,
	AOE = true,
	Angle = 60,
	CircleColor = Color3.fromRGB(181, 0, 151),
}

local tbl3 = { tbl1 }
tbl1 = {
	Price = 200,
	Damage = 25,
	Cooldown = 0.5,
	Range = 7,
	AOE = true,
	Angle = 70,
	CircleColor = Color3.fromRGB(181, 0, 151),
}

tbl3[2] = tbl1
tbl1 = {
	Price = 400,
	Damage = 70,
	Cooldown = 0.5,
	Range = 9,
	AOE = true,
	Angle = 80,
	CircleColor = Color3.fromRGB(181, 0, 151),
}

tbl3[3] = tbl1
tbl1 = {
	Price = 600,
	Damage = 125,
	Cooldown = 0.5,
	Range = 12,
	AOE = true,
	Angle = 90,
	CircleColor = Color3.fromRGB(181, 0, 151),
}

tbl3[4] = tbl1
tbl2.Upgrades = tbl3
tbl2.Model = script:WaitForChild(script.Name)
return tbl2

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Jetpack Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Exclusive",
	Icon = "rbxassetid://105319023614751",
	Tags = {},
	Upgrades = {
		{ Price = 300, Damage = 250, Cooldown = 3, Range = 10 },
		{ Price = 200, Damage = 600, Cooldown = 3, Range = 10 },
		{ Price = 500, Damage = 1200, Cooldown = 3, Range = 15 },
		{ Price = 1000, Damage = 1500, Cooldown = 2, Range = 20 },
		{ Price = 1500, Damage = 2500, Cooldown = 2, Range = 25 },
		{ Price = 3000, Damage = 2500, Cooldown = 1, Range = 30 },
		{ Price = 4000, Damage = 5000, Cooldown = 1, Range = 30 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Large TV Man [ModuleScript]
-- y u r i

local tbl1 = { Color = Color3.fromRGB(235, 0, 0) }
local tbl2 = {
	Rarity = "Epic",
	Icon = "rbxassetid://131172136126111",
	HideDetection = true,
	Tags = { AOE = tbl1 },
}

tbl2.Upgrades = {
	{ Price = 400, Damage = 20, Cooldown = 0.5, Range = 9, AOE = true, Angle = 60 },
	{ Price = 500, Damage = 25, Cooldown = 0.4, Range = 12, AOE = true, Angle = 70 },
	{ Price = 800, Damage = 35, Cooldown = 0.2, Range = 15, AOE = true, Angle = 80 },
	{ Price = 1000, Damage = 50, Cooldown = 0.2, Range = 18, AOE = true, Angle = 90 },
	{ Price = 1500, Damage = 100, Cooldown = 0.2, Range = 20, AOE = true, Angle = 100 },
}

tbl2.Model = script:WaitForChild(script.Name)
return tbl2

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Car Speakerman [ModuleScript]
-- y u r i

return {
	Rarity = "Uncommon",
	Icon = "rbxassetid://117662618626656",
	Tags = {},
	Upgrades = {
		{ Price = 150, Damage = 40, Cooldown = 3, Range = 10 },
		{ Price = 250, Damage = 75, Cooldown = 2, Range = 15 },
		{ Price = 500, Damage = 150, Cooldown = 1, Range = 20 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Large Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Epic",
	Icon = "rbxassetid://127937461041556",
	Tags = {},
	Upgrades = {
		{ Price = 200, Damage = 25, Cooldown = 0.5, Range = 12 },
		{ Price = 300, Damage = 50, Cooldown = 0.4, Range = 15 },
		{ Price = 600, Damage = 50, Cooldown = 0.2, Range = 18 },
		{ Price = 800, Damage = 100, Cooldown = 0.2, Range = 20 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Brown Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Uncommon",
	Icon = "rbxassetid://100869291191022",
	Tags = {},
	Upgrades = {
		{ Price = 100, Damage = 10, Cooldown = 1, Range = 9 },
		{ Price = 200, Damage = 20, Cooldown = 0.8, Range = 12 },
		{ Price = 400, Damage = 75, Cooldown = 0.5, Range = 15 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Titan Cameraman [ModuleScript]
-- y u r i

return {
	Rarity = "Legendary",
	Icon = "rbxassetid://103372398653705",
	Tags = {},
	PlacementLimit = 9,
	Upgrades = {
		{ Price = 800, Damage = 25, Cooldown = 0.25, Range = 20 },
		{ Price = 700, Damage = 50, Cooldown = 0.2, Range = 22 },
		{ Price = 1000, Damage = 125, Cooldown = 0.2, Range = 24 },
		{ Price = 1500, Damage = 300, Cooldown = 0.2, Range = 27 },
		{ Price = 2500, Damage = 600, Cooldown = 0.2, Range = 30 },
	},
	Model = script:WaitForChild(script.Name),
}

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Titan TV Man [ModuleScript]
-- y u r i

local tbl1 = { Color = Color3.fromRGB(235, 0, 0) }
local tbl2 = {
	Rarity = "Legendary",
	Icon = "rbxassetid://88032027568087",
	HideDetection = true,
	Tags = { AOE = tbl1 },
	PlacementLimit = 7,
}

tbl1 = {
	Price = 1000,
	Damage = 100,
	Cooldown = 1,
	Range = 15,
	AOE = true,
	Angle = 70,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

local tbl3 = { tbl1 }
tbl1 = {
	Price = 1000,
	Damage = 200,
	Cooldown = 1,
	Range = 15,
	AOE = true,
	Angle = 75,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

tbl3[2] = tbl1
tbl1 = {
	Price = 2000,
	Damage = 200,
	Cooldown = 0.5,
	Range = 20,
	AOE = true,
	Angle = 80,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

tbl3[3] = tbl1
tbl1 = {
	Price = 3000,
	Damage = 400,
	Cooldown = 0.5,
	Range = 20,
	AOE = true,
	Angle = 85,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

tbl3[4] = tbl1
tbl1 = {
	Price = 4000,
	Damage = 500,
	Cooldown = 0.4,
	Range = 25,
	AOE = true,
	Angle = 90,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

tbl3[5] = tbl1
tbl1 = {
	Price = 5000,
	Damage = 500,
	Cooldown = 0.25,
	Range = 25,
	AOE = true,
	Angle = 100,
	CircleColor = Color3.fromRGB(181, 0, 0),
}

tbl3[6] = tbl1
tbl2.Upgrades = tbl3
tbl2.Model = script:WaitForChild(script.Name)
return tbl2

--- ReplicatedStorage.ModuleLoader.Configs.Config.Towers.Titan Cinemaman [ModuleScript]
-- y u r i

local tbl1 = { Color = Color3.fromRGB(235, 0, 0) }
local tbl2 = {
	Rarity = "Mythic",
	Icon = "rbxassetid://71565370415952",
	Tags = { AOE = tbl1 },
	PlacementLimit = 5,
}

tbl1 = {
	Price = 2000,
	Damage = 1000,
	Cooldown = 2,
	Range = 13,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://104972401609921",
}

local tbl3 = { tbl1 }
tbl1 = {
	Price = 2000,
	Damage = 1400,
	Cooldown = 1,
	Range = 15,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://104972401609921",
}

tbl3[2] = tbl1
tbl1 = {
	Price = 4000,
	Damage = 1000,
	Cooldown = 1,
	Range = 15,
	AOE = true,
	Angle = 80,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://119830399004186",
}

tbl3[3] = tbl1
tbl1 = {
	Price = 5000,
	Damage = 1000,
	Cooldown = 0.5,
	Range = 20,
	AOE = true,
	Angle = 85,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://119830399004186",
}

tbl3[4] = tbl1
tbl1 = {
	Price = 8000,
	Damage = 1400,
	Cooldown = 0.4,
	Range = 25,
	AOE = true,
	Angle = 90,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://119830399004186",
}

tbl3[5] = tbl1
tbl1 = {
	Price = 15000,
	Damage = 1400,
	Cooldown = 0.2,
	Range = 30,
	AOE = true,
	Angle = 100,
	CircleColor = Color3.fromRGB(181, 0, 0),
	Attack = "rbxassetid://119830399004186",
}

tbl3[6] = tbl1
tbl2.Upgrades = tbl3
tbl2.Model = script:WaitForChild(script.Name)
return tbl2

--- ReplicatedStorage.TopbarPlus.Icon [ModuleScript]
-- y u r i

game:GetService("LocalizationService")
game:GetService("RunService")
game:GetService("TextService")
local var1 = script
local var2 = require(var1.Reference)
local var3 = var2.getObject()
local var4 = var3
var4 = var4 and var3.Value
local var6 = game:GetService("UserInputService")
local var7 = game:GetService("StarterGui")
local var8 = game:GetService("GuiService")
local var9 = game:GetService("Players")
if var4 and var4 ~= var1 then
	local var10 = var4
	return require(var10)
end

if not var3 then
	var2.addToReplicatedStorage()
end

require(var1.Attribute)
local var11 = require(var1.Packages.GoodSignal)
local var12 = require(var1.Packages.Janitor)
local var13 = require(var1.Utility)
local var14 = require(var1.Features.Themes)
local var15 = require(var1.Features.Gamepad)
local var16 = require(var1.Features.Overflow)
local tbl1 = {}
tbl1.__index = tbl1
local var17 = var1.Features.Themes
local var18 = var9.LocalPlayer:WaitForChild("PlayerGui")
local tbl2 = {}
local var19 = var11.new()
local var20 = var1.Elements
local num1 = 0
if var8.TopbarInset.Height == 0 then
	var8:GetPropertyChangedSignal("TopbarInset"):Wait()
end

tbl1.baseDisplayOrderChanged = var11.new()
tbl1.baseDisplayOrder = 10
tbl1.baseTheme = require(var17.Default)
tbl1.isOldTopbar = var8.TopbarInset.Height == 36
tbl1.iconsDictionary = tbl2
local var21 = require(var20.Container)(tbl1)
tbl1.container = var21
tbl1.topbarEnabled = true
tbl1.iconAdded = var11.new()
tbl1.iconRemoved = var11.new()
tbl1.iconChanged = var11.new()
tbl1.getIcons = function()
	return tbl1.iconsDictionary
end

tbl1.getIconByUID = function(arg1)
	local var2 = tbl1.iconsDictionary[arg1]
	if var2 then
		return var2
	end
end

tbl1.getIcon = function(arg1)
	local var2 = tbl1.getIconByUID(arg1)
	if var2 then
		return var2
	end

	for k1, v1 in pairs(tbl2) do
		if v1.name ~= arg1 then
			continue
		end

		return v1
	end
end

tbl1.setTopbarEnabled = function(arg1, arg2)
	if typeof(arg1) ~= "boolean" then
		arg1 = tbl1.topbarEnabled
	end

	if not arg2 then
		tbl1.topbarEnabled = arg1
	end

	for k1, v1 in pairs(tbl1.container) do
		v1.Enabled = arg1
	end
end

tbl1.modifyBaseTheme = function(arg1)
	for k1, v1 in pairs((var14.getModifications(arg1))) do
		for k2, v2 in pairs(tbl1.baseTheme) do
			var14.merge(v2, v1)
		end
	end

	for k3, v3 in pairs(tbl2) do
		v3:setTheme(tbl1.baseTheme)
	end
end

tbl1.setDisplayOrder = function(arg1)
	tbl1.baseDisplayOrder = arg1
	tbl1.baseDisplayOrderChanged:Fire(arg1)
end

task.defer(var15.start, tbl1)
task.defer(var16.start, tbl1)
for k1, v1 in pairs(tbl1.container) do
	v1.Parent = var18
end

if tbl1.isOldTopbar then
	local var23 = var17.Classic
	tbl1.modifyBaseTheme(require(var23))
end

tbl1.new = function()
	local tbl3 = {}
	setmetatable(tbl3, tbl1)
	local var2 = var12.new()
	tbl3.janitor = var2
	tbl3.themesJanitor = var2:add(var12.new())
	tbl3.singleClickJanitor = var2:add(var12.new())
	tbl3.captionJanitor = var2:add(var12.new())
	tbl3.joinJanitor = var2:add(var12.new())
	tbl3.menuJanitor = var2:add(var12.new())
	tbl3.dropdownJanitor = var2:add(var12.new())
	local var3 = var13.generateUID()
	tbl2[var3] = tbl3
	var2:add(function()
		tbl2[var3] = nil
	end)

	tbl3.selected = var2:add(var11.new())
	tbl3.deselected = var2:add(var11.new())
	tbl3.toggled = var2:add(var11.new())
	tbl3.viewingStarted = var2:add(var11.new())
	tbl3.viewingEnded = var2:add(var11.new())
	tbl3.stateChanged = var2:add(var11.new())
	tbl3.notified = var2:add(var11.new())
	tbl3.noticeStarted = var2:add(var11.new())
	tbl3.noticeChanged = var2:add(var11.new())
	tbl3.endNotices = var2:add(var11.new())
	tbl3.toggleKeyAdded = var2:add(var11.new())
	tbl3.fakeToggleKeyChanged = var2:add(var11.new())
	tbl3.alignmentChanged = var2:add(var11.new())
	tbl3.updateSize = var2:add(var11.new())
	tbl3.resizingComplete = var2:add(var11.new())
	tbl3.joinedParent = var2:add(var11.new())
	tbl3.menuSet = var2:add(var11.new())
	tbl3.dropdownSet = var2:add(var11.new())
	tbl3.updateMenu = var2:add(var11.new())
	tbl3.startMenuUpdate = var2:add(var11.new())
	tbl3.childThemeModified = var2:add(var11.new())
	tbl3.indicatorSet = var2:add(var11.new())
	tbl3.dropdownChildAdded = var2:add(var11.new())
	tbl3.menuChildAdded = var2:add(var11.new())
	tbl3.iconModule = var1
	tbl3.UID = var3
	tbl3.isEnabled = true
	tbl3.isSelected = false
	tbl3.isViewing = false
	tbl3.joinedFrame = false
	tbl3.parentIconUID = false
	tbl3.deselectWhenOtherIconSelected = true
	tbl3.totalNotices = 0
	tbl3.activeState = "Deselected"
	tbl3.alignment = ""
	tbl3.originalAlignment = ""
	tbl3.appliedTheme = {}
	tbl3.appearance = {}
	tbl3.cachedInstances = {}
	tbl3.cachedNamesToInstances = {}
	tbl3.cachedCollectives = {}
	tbl3.bindedToggleKeys = {}
	tbl3.customBehaviours = {}
	tbl3.toggleItems = {}
	tbl3.bindedEvents = {}
	tbl3.notices = {}
	tbl3.menuIcons = {}
	tbl3.dropdownIcons = {}
	tbl3.childIconsDict = {}
	tbl3.isOldTopbar = tbl1.isOldTopbar
	tbl3.creationTime = os.clock()
	local var4 = tbl3
	local var5 = tbl1
	tbl3.widget = var2:add(require(var20.Widget)(var4, var5))
	tbl3:setAlignment()
	local var8 = num1 + 1
	num1 = var8
	tbl3:setOrder(num1)
	tbl3:setTheme(tbl1.baseTheme)
	local var9 = tbl3:getInstance("ClickRegion")
	var5 = false
	local bool1 = false
	var9.MouseButton1Click:Connect(function()
		if var5 then
			return
		end

		bool1 = true
		task.delay(0.01, function()
			bool1 = false
		end)

		if tbl3.locked then
			return
		end

		if tbl3.isSelected then
			tbl3:deselect("User", tbl3)
			return
		end

		tbl3:select("User", tbl3)
	end)

	var9.TouchTap:Connect(function()
		if bool1 then
			return
		end

		var5 = true
		task.delay(0.01, function()
			var5 = false
		end)

		if tbl3.locked then
			return
		end

		if tbl3.isSelected then
			tbl3:deselect("User", tbl3)
			return
		end

		tbl3:select("User", tbl3)
	end)

	local function fn2(arg1, arg2)
		if tbl3.locked then
			return
		end

		if tbl3.bindedToggleKeys[arg1.KeyCode] then
			if not arg2 then
				if tbl3.locked then
					return
				end

				if tbl3.isSelected then
					tbl3:deselect("User", tbl3)
					return
				end

				tbl3:select("User", tbl3)
			end
		end
	end

	var2:add(var6.InputBegan:Connect(fn2))
	tbl3.joinedParent:Connect(function()
		if tbl3.isViewing then
			if tbl3.locked then
				return
			end

			tbl3.isViewing = false
			tbl3.viewingEnded:Fire(true)
			tbl3:setState(nil, "User", tbl3)
		end
	end)

	var9.MouseEnter:Connect(function()
		local var1 = not var6.KeyboardEnabled
		if tbl3.locked then
			return
		end

		tbl3.isViewing = true
		tbl3.viewingStarted:Fire(true)
		if not var1 then
			tbl3:setState("Viewing", "User", tbl3)
		end
	end)

	local function viewingEnded()
		if tbl3.locked then
			return
		end

		tbl3.isViewing = false
		tbl3.viewingEnded:Fire(true)
		tbl3:setState(nil, "User", tbl3)
	end

	local var10 = viewingEnded
	var2:add(var6.TouchEnded:Connect(var10))
	var9.MouseLeave:Connect(viewingEnded)
	var9.SelectionGained:Connect(function(arg1)
		if tbl3.locked then
			return
		end

		tbl3.isViewing = true
		tbl3.viewingStarted:Fire(true)
		if not arg1 then
			tbl3:setState("Viewing", "User", tbl3)
		end
	end)

	var9.SelectionLost:Connect(viewingEnded)
	local num2 = 0
	var9.MouseButton1Down:Connect(function()
		if not tbl3.locked and var6.TouchEnabled then
			local var1 = num2 + 1
			num2 = var1
			var1 = num2
			task.delay(0.2, function()
				if var1 == num2 then
					if tbl3.locked then
						return
					end

					tbl3.isViewing = true
					tbl3.viewingStarted:Fire(true)
					tbl3:setState("Viewing", "User", tbl3)
				end
			end)

		end
	end)

	var9.MouseButton1Up:Connect(function()
		local var1 = num2 + 1
		num2 = var1
	end)

	local var14 = tbl3:getInstance("IconOverlay")
	tbl3.viewingStarted:Connect(function()
		var14.Visible = not tbl3.overlayDisabled
	end)

	tbl3.viewingEnded:Connect(function()
		var14.Visible = false
	end)

	local function fn5(arg1)
		if arg1 ~= tbl3 and (tbl3.deselectWhenOtherIconSelected and arg1.deselectWhenOtherIconSelected) then
			tbl3:deselect("AutoDeselect", arg1)
		end
	end

	var2:add(var19:Connect(fn5))
	local var15 = game
	var10 = nil
	for k1, v1 in pairs((string.split(debug.info(2, "s"), "."))) do
		var15 = var15:FindFirstChild(v1)
		if not var15 then
			break
		end

		if not var15:IsA("ScreenGui") then
			continue
		end

		var10 = var15
	end

	if var15 and (var10 and var10.ResetOnSpawn == true) then
		var13.localPlayerRespawned(function()
			tbl3:destroy()
		end)

	end

	tbl3:getInstance("NoticeLabel")
	tbl3.toggled:Connect(function(arg1)
		tbl3.noticeChanged:Fire(tbl3.totalNotices)
		for k1, v1 in pairs(tbl3.childIconsDict) do
			local var1 = tbl1.getIconByUID(k1)
			var1.noticeChanged:Fire(var1.totalNotices)
			if arg1 then
				continue
			end

			if not var1.isSelected then
				continue
			end

			for k2, v2 in pairs(var1.childIconsDict) do
				var1:deselect("HideParentFeature", tbl3)
			end
		end
	end)

	tbl3.selected:Connect(function()
		if 0 < (#tbl3.dropdownIcons) then
			if var7:GetCore("ChatActive") and tbl3.alignment ~= "Right" then
				tbl3.chatWasPreviouslyActive = true
				var7:SetCore("ChatActive", false)
			end

			if var7:GetCoreGuiEnabled("PlayerList") and tbl3.alignment ~= "Left" then
				tbl3.playerlistWasPreviouslyActive = true
				var7:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false)
			end
		end
	end)

	tbl3.deselected:Connect(function()
		if tbl3.chatWasPreviouslyActive then
			tbl3.chatWasPreviouslyActive = nil
			var7:SetCore("ChatActive", true)
		end

		if tbl3.playerlistWasPreviouslyActive then
			tbl3.playerlistWasPreviouslyActive = nil
			var7:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, true)
		end
	end)

	task.delay(0.1, function()
		if tbl3.activeState == "Deselected" then
			tbl3.stateChanged:Fire("Deselected")
			tbl3:refresh()
		end
	end)

	tbl1.iconAdded:Fire(tbl3)
	return tbl3
end

tbl1.setName = function(arg1, arg2)
	arg1.widget.Name = arg2
	arg1.name = arg2
	return arg1
end

tbl1.setState = function(arg1, arg2, arg3, arg4)
	if not arg2 then
		arg2 = if arg1.isSelected then "Selected" else "Deselected"
	end

	local var2 = var13.formatStateName(arg2)
	if arg1.activeState == var2 then
		return
	end

	arg1.activeState = var2
	local var3 = arg1.isSelected
	if var2 == "Deselected" then
		arg1.isSelected = false
		if var3 then
			arg1.toggled:Fire(false, arg3, arg4)
			arg1.deselected:Fire(arg3, arg4)
		end

		arg1:_setToggleItemsVisible(false, arg3, arg4)
	elseif var2 == "Selected" then
		arg1.isSelected = true
		if not var3 then
			arg1.toggled:Fire(true, arg3, arg4)
			arg1.selected:Fire(arg3, arg4)
			var19:Fire(arg1, arg3, arg4)
		end

		arg1:_setToggleItemsVisible(true, arg3, arg4)
	end

	arg1.stateChanged:Fire(var2, arg3, arg4)
end

tbl1.getInstance = function(arg1, arg2)
	local var2 = arg1.cachedNamesToInstances[arg2]
	if var2 then
		return var2
	end

	local function cacheInstance(arg1, arg2)
		if not arg1.cachedInstances[arg2] then
			local var2 = arg2:GetAttribute("Collective")
			local var3 = var2
			var3 = var3 and arg1.cachedCollectives[var2]
			if var3 then
				table.insert(var3, arg2)
			end

			arg1.cachedNamesToInstances[arg1] = arg2
			arg1.cachedInstances[arg2] = true
			arg2.Destroying:Once(function()
				arg1.cachedNamesToInstances[arg1] = nil
				arg1.cachedInstances[arg2] = nil
			end)

		end
	end

	local var3 = arg1.widget
	cacheInstance("Widget", var3)
	if arg2 == "Widget" then
		return var3
	end

	local var4 = nil
	local function scanChildren(arg1)
		for k1, v1 in pairs(arg1:GetChildren()) do
			local var5 = v1:GetAttribute("WidgetUID")
			if var5 then
				if var5 ~= arg1.UID then
					continue
				end
			end

			local var8 = var14.getRealInstance(v1)
			if var8 then
				local var9 = v1
				v1 = var8
			end

			scanChildren(v1)
			if v1:IsA("GuiBase") or (v1:IsA("UIBase") or v1:IsA("ValueBase")) then
				local var11 = v1.Name
				cacheInstance(var11, v1)
				if var11 ~= arg2 then
					continue
				end

				var4 = v1
			end
		end
	end

	scanChildren(var3)
	return var4
end

tbl1.getCollective = function(arg1, arg2)
	local var2 = arg1.cachedCollectives[arg2]
	if var2 then
		return var2
	end

	var2 = {}
	for k1, v1 in pairs(arg1.cachedInstances) do
		if k1:GetAttribute("Collective") ~= arg2 then
			continue
		end

		table.insert(var2, k1)
	end

	arg1.cachedCollectives[arg2] = var2
	return var2
end

tbl1.getInstanceOrCollective = function(arg1, arg2)
	local var2 = arg1:getInstance(arg2)
	local tbl1 = {}
	if var2 then
		table.insert(tbl1, var2)
	end

	if #tbl1 == 0 then
		tbl1 = arg1:getCollective(arg2)
	end

	return tbl1
end

tbl1.getStateGroup = function(arg1, arg2)
	local var1 = arg2
	var1 = var1 or arg1.activeState
	local var3 = arg1.appearance[var1]
	if not var3 then
		var3 = {}
		arg1.appearance[var1] = var3
	end

	return var3
end

tbl1.refreshAppearance = function(arg1, arg2, arg3)
	var14.refresh(arg1, arg2, arg3)
	return arg1
end

tbl1.refresh = function(arg1)
	arg1:refreshAppearance(arg1.widget)
	arg1.updateSize:Fire()
	return arg1
end

tbl1.updateParent = function(arg1)
	local var2 = tbl1.getIconByUID(arg1.parentIconUID)
	if var2 then
		var2.updateSize:Fire()
	end
end

tbl1.setBehaviour = function(arg1, arg2, arg3, arg4, arg5)
	arg1.customBehaviours[arg2 .. "-" .. arg3] = arg4
	if arg5 then
		for k1, v1 in pairs((arg1:getInstanceOrCollective(arg2))) do
			arg1:refreshAppearance(v1, arg3)
		end
	end
end

tbl1.modifyTheme = function(arg1, arg2, arg3)
	return arg1, (var14.modify(arg1, arg2, arg3))
end

tbl1.modifyChildTheme = function(arg1, arg2, arg3)
	arg1.childModifications = arg2
	arg1.childModificationsUID = arg3
	for k1, v1 in pairs(arg1.childIconsDict) do
		tbl1.getIconByUID(k1):modifyTheme(arg2, arg3)
	end

	arg1.childThemeModified:Fire()
	return arg1
end

tbl1.removeModification = function(arg1, arg2)
	var14.remove(arg1, arg2)
	return arg1
end

tbl1.removeModificationWith = function(arg1, arg2, arg3, arg4)
	var14.removeWith(arg1, arg2, arg3, arg4)
	return arg1
end

tbl1.setTheme = function(arg1, arg2)
	var14.set(arg1, arg2)
	return arg1
end

tbl1.setEnabled = function(arg1, arg2)
	arg1.isEnabled = arg2
	arg1.widget.Visible = arg2
	arg1:updateParent()
	return arg1
end

tbl1.select = function(arg1, arg2, arg3)
	arg1:setState("Selected", arg2, arg3)
	return arg1
end

tbl1.deselect = function(arg1, arg2, arg3)
	arg1:setState("Deselected", arg2, arg3)
	return arg1
end

tbl1.notify = function(arg1, arg2, arg3)
	if not arg1.notice then
		local var1 = require(var20.Notice)(arg1, tbl1)
		arg1.notice = var1
	end

	arg1.noticeStarted:Fire(arg2, arg3)
	return arg1
end

tbl1.clearNotices = function(arg1)
	arg1.endNotices:Fire()
	return arg1
end

tbl1.disableOverlay = function(arg1, arg2)
	arg1.overlayDisabled = arg2
	return arg1
end

tbl1.disableStateOverlay = tbl1.disableOverlay
tbl1.setImage = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconImage", "Image", arg2, arg3 })
	return arg1
end

tbl1.setLabel = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconLabel", "Text", arg2, arg3 })
	return arg1
end

tbl1.setOrder = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "Widget", "LayoutOrder", arg2, arg3 })
	return arg1
end

tbl1.setCornerRadius = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconCorners", "CornerRadius", arg2, arg3 })
	return arg1
end

tbl1.align = function(arg1, arg2, arg3)
	local var2 = tostring(arg2):lower()
	if var2 ~= "mid" then
		if var2 == "centre" then
			var2 = "center"
		end
	end

	if var2 ~= "left" then
		if var2 ~= "center" and var2 ~= "right" then
			var2 = "left"
		end
	end

	local var3 = var2 == "center" and tbl1.container.TopbarCentered or tbl1.container.TopbarStandard
	local var4 = var3.Holders
	local var5 = string.upper((string.sub(var2, 1, 1))) .. string.sub(var2, 2)
	if not arg3 then
		arg1.originalAlignment = var5
	end

	arg1.screenGui = var3
	local var6 = var4[var5]
	arg1.alignmentHolder = var6
	local var7 = arg1.joinedFrame
	if not arg1.isDestroyed then
		arg1.widget.Parent = var7 or var6
	end

	arg1.alignment = var5
	arg1.alignmentChanged:Fire(var5)
	tbl1.iconChanged:Fire(arg1)
	return arg1
end

tbl1.setAlignment = tbl1.align
tbl1.setLeft = function(arg1)
	arg1:setAlignment("Left")
	return arg1
end

tbl1.setMid = function(arg1)
	arg1:setAlignment("Center")
	return arg1
end

tbl1.setRight = function(arg1)
	arg1:setAlignment("Right")
	return arg1
end

tbl1.setWidth = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "Widget", "Size", UDim2.fromOffset(arg2, arg1.widget.Size.Y.Offset), arg3 })
	arg1:modifyTheme({ "Widget", "DesiredWidth", arg2, arg3 })
	return arg1
end

tbl1.setImageScale = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconImageScale", "Value", arg2, arg3 })
	return arg1
end

tbl1.setImageRatio = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconImageRatio", "AspectRatio", arg2, arg3 })
	return arg1
end

tbl1.setTextSize = function(arg1, arg2, arg3)
	arg1:modifyTheme({ "IconLabel", "TextSize", arg2, arg3 })
	return arg1
end

tbl1.setTextFont = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg3
	arg3 = var1 or Enum.FontWeight.Regular
	var1 = arg4
	arg4 = var1 or Enum.FontStyle.Normal
	local var3 = typeof(arg2)
	var1 = nil
	if var3 == "number" then
		var1 = Font.fromId(arg2, arg3, arg4)
	elseif var3 == "EnumItem" then
		var1 = Font.fromEnum(arg2)
	else
		if var3 == "string" and (not arg2:match("rbxasset")) then
			var1 = Font.fromName(arg2, arg3, arg4)
		end
	end

	arg1:modifyTheme({ "IconLabel", "FontFace", var1 or Font.new(arg2, arg3, arg4), arg5 })
	return arg1
end

tbl1.bindToggleItem = function(arg1, arg2)
	if not arg2:IsA("GuiObject") and (not arg2:IsA("LayerCollector")) then
		error("Toggle item must be a GuiObject or LayerCollector!")
	end

	arg1.toggleItems[arg2] = true
	arg1:_updateSelectionInstances()
	return arg1
end

tbl1.unbindToggleItem = function(arg1, arg2)
	arg1.toggleItems[arg2] = nil
	arg1:_updateSelectionInstances()
	return arg1
end

tbl1._updateSelectionInstances = function(arg1)
	for k1, v1 in pairs(arg1.toggleItems) do
		local tbl1 = {}
		for k2, v2 in pairs(k1:GetDescendants()) do
			if (v2:IsA("TextButton") or v2:IsA("ImageButton")) and v2.Active then
				table.insert(tbl1, v2)
			end
		end

		arg1.toggleItems[k1] = tbl1
	end
end

tbl1._setToggleItemsVisible = function(arg1, arg2, _, arg4)
	for k1, v1 in pairs(arg1.toggleItems) do
		if arg4 then
			if arg4 == arg1 or arg4.toggleItems[k1] == nil then
				local str4 = "Visible"
				if k1:IsA("LayerCollector") then
					str4 = "Enabled"
				end

				k1[str4] = arg2
			end
		end
	end
end

tbl1.bindEvent = function(arg1, arg2, arg3)
	local var1 = arg1[arg2]
	local var3 = var1
	if var3 then
		var3 = false
		if typeof(var1) == "table" then
			var3 = var1.Connect
		end
	end

	assert(var3, "argument[1] must be a valid topbarplus icon event name!")
	assert(typeof(arg3) == "function", "argument[2] must be a function!")
	arg1.bindedEvents[arg2] = var1:Connect(function(...)
		arg3(arg1, ...)
	end)

	return arg1
end

tbl1.unbindEvent = function(arg1, arg2)
	local var2 = arg1.bindedEvents[arg2]
	if var2 then
		var2:Disconnect()
		arg1.bindedEvents[arg2] = nil
	end

	return arg1
end

tbl1.bindToggleKey = function(arg1, arg2)
	assert(typeof(arg2) == "EnumItem", "argument[1] must be a KeyCode EnumItem!")
	arg1.bindedToggleKeys[arg2] = true
	arg1.toggleKeyAdded:Fire(arg2)
	arg1:setCaption("_hotkey_")
	return arg1
end

tbl1.unbindToggleKey = function(arg1, arg2)
	assert(typeof(arg2) == "EnumItem", "argument[1] must be a KeyCode EnumItem!")
	arg1.bindedToggleKeys[arg2] = nil
	return arg1
end

tbl1.call = function(arg1, arg2, ...)
	local var1 = table.pack(...)
	task.spawn(function()
		local var2 = var1
		arg2(arg1, table.unpack(var2))
	end)

	return arg1
end

tbl1.addToJanitor = function(arg1, arg2)
	arg1.janitor:add(arg2)
	return arg1
end

tbl1.lock = function(arg1)
	local var1 = arg1:getInstance("ClickRegion")
	var1.Visible = false
	arg1.locked = true
	return arg1
end

tbl1.unlock = function(arg1)
	local var1 = arg1:getInstance("ClickRegion")
	var1.Visible = true
	arg1.locked = false
	return arg1
end

tbl1.debounce = function(arg1, arg2)
	arg1:lock()
	task.wait(arg2)
	arg1:unlock()
	return arg1
end

tbl1.autoDeselect = function(arg1, arg2)
	arg1.deselectWhenOtherIconSelected = arg2 == nil and true
	return arg1
end

tbl1.oneClick = function(arg1, arg2)
	local var1 = arg1.singleClickJanitor
	var1:clean()
	if arg2 or arg2 == nil then
		local function fn4()
			arg1:deselect("OneClick", arg1)
		end

		var1:add(arg1.selected:Connect(fn4))
	end

	arg1.oneClickEnabled = true
	return arg1
end

tbl1.setCaption = function(arg1, arg2)
	if arg2 == "_hotkey_" and arg1.captionText then
		return arg1
	end

	arg1.captionJanitor:clean()
	local var1 = arg1.captionJanitor
	if not arg2 or arg2 == "" then
		arg1.caption = nil
		arg1.captionText = nil
		return arg1
	end

	local var2 = arg1
	local var3 = var1:add(require(var20.Caption)(var2))
	var3:SetAttribute("CaptionText", arg2)
	arg1.caption = var3
	arg1.captionText = arg2
	return arg1
end

tbl1.setCaptionHint = function(arg1, arg2)
	assert(typeof(arg2) == "EnumItem", "argument[1] must be a KeyCode EnumItem!")
	arg1.fakeToggleKey = arg2
	arg1.fakeToggleKeyChanged:Fire(arg2)
	arg1:setCaption("_hotkey_")
	return arg1
end

tbl1.leave = function(arg1)
	arg1.joinJanitor:clean()
	return arg1
end

tbl1.joinMenu = function(arg1, arg2)
	local str1 = "Menu"
	var13.joinFeature(arg1, arg2, arg2.menuIcons, arg2:getInstance(str1))
	arg2.menuChildAdded:Fire(arg1)
	return arg1
end

tbl1.setMenu = function(arg1, arg2)
	arg1.menuSet:Fire(arg2)
	return arg1
end

tbl1.setFrozenMenu = function(arg1, arg2)
	arg1:freezeMenu(arg2)
	arg1:setMenu(arg2)
end

tbl1.freezeMenu = function(arg1)
	arg1:select("FrozenMenu", arg1)
	arg1:bindEvent("deselected", function(arg1)
		arg1:select("FrozenMenu", arg1)
	end)

	arg1:modifyTheme({ "IconSpot", "Visible", false })
end

tbl1.joinDropdown = function(arg1, arg2)
	arg2:getDropdown()
	local str1 = "DropdownScroller"
	var13.joinFeature(arg1, arg2, arg2.dropdownIcons, arg2:getInstance(str1))
	arg2.dropdownChildAdded:Fire(arg1)
	return arg1
end

tbl1.getDropdown = function(arg1)
	local var2 = arg1.dropdown
	if not var2 then
		var2 = require(var20.Dropdown)(arg1)
		arg1.dropdown = var2
		arg1:clipOutside(var2)
	end

	return var2
end

tbl1.setDropdown = function(arg1, arg2)
	arg1:getDropdown()
	arg1.dropdownSet:Fire(arg2)
	return arg1
end

tbl1.clipOutside = function(arg1, arg2)
	arg1:refreshAppearance(arg2)
	return arg1, (var13.clipOutside(arg1, arg2))
end

tbl1.setIndicator = function(arg1, arg2)
	if not arg1.indicator then
		local var3 = arg1
		local var4 = tbl1
		arg1.indicator = arg1.janitor:add(require(var20.Indicator)(var3, var4))
	end

	arg1.indicatorSet:Fire(arg2)
end

tbl1.destroy = function(arg1)
	if arg1.isDestroyed then
		return
	end

	arg1:clearNotices()
	if arg1.parentIconUID then
		arg1:leave()
	end

	arg1.isDestroyed = true
	arg1.janitor:clean()
	tbl1.iconRemoved:Fire(arg1)
end

tbl1.Destroy = tbl1.destroy
return tbl1

--- ReplicatedStorage.TopbarPlus.Icon.Attribute [ModuleScript]
-- y u r i

game:GetService("GroupService")
game:GetService("Players")
if not game:GetService("RunService"):IsStudio() then
	print((("\240\159\141\141 Running TopbarPlus %* by ForeverHD"):format((require(script.Parent.VERSION)))))
end

return {}

--- ReplicatedStorage.TopbarPlus.Icon.Reference [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = { objectName = "TopbarPlusReference" }
tbl1.addToReplicatedStorage = function()
	if var1:FindFirstChild(tbl1.objectName) then
		return false
	end

	local var2 = Instance.new("ObjectValue")
	var2.Name = tbl1.objectName
	var2.Value = script.Parent
	var2.Parent = var1
	return var2
end

tbl1.getObject = function()
	local var3 = var1:FindFirstChild(tbl1.objectName)
	if var3 then
		return var3
	end

	return false
end

return tbl1

--- ReplicatedStorage.TopbarPlus.Icon.VERSION [ModuleScript]
-- y u r i

return "v3.0.2"

--- ReplicatedStorage.TopbarPlus.Icon.Utility [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local tbl1 = {
	createStagger = function(arg1, arg2, arg3)
		local bool1 = false
		local bool2 = false
		if not arg1 or arg1 == 0 then
			arg1 = 0.01
		end

		local function staggeredCallback(...)
			if bool1 then
				bool2 = true
				return
			end

			local var1 = table.pack(...)
			bool1 = true
			bool2 = false
			task.spawn(function()
				if arg3 then
					task.wait(arg1)
				end

				local var2 = var1
				arg2(table.unpack(var2))
			end)

			task.delay(arg1, function()
				bool1 = false
				if bool2 then
					local var2 = var1
					staggeredCallback(table.unpack(var2))
				end
			end)
		end

		return staggeredCallback
	end,
	round = function(arg1)
		return (math.floor(arg1 + 0.5))
	end,
	reverseTable = function(arg1)
		for i1 = 1, math.floor(#arg1 / 2) do
			local var1 = #arg1 - i1 + 1
			local var2 = arg1[var1]
			local var3 = arg1[i1]
			arg1[i1] = var2
			arg1[var1] = var3
		end
	end,
}

tbl1.copyTable = function(arg1)
	assert(type(arg1) == "table", "First argument must be a table")
	local var1 = table.create(#arg1)
	for k1, v1 in pairs(arg1) do
		if type(v1) == "table" then
			var1[k1] = tbl1.copyTable(v1)
		else
			var1[k1] = v1
		end
	end

	return var1
end

local tbl2 = {
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h",
	"i",
	"j",
	"k",
	"l",
	"m",
	"n",
	"o",
	"p",
	"q",
	"r",
	"s",
	"t",
	"u",
	"v",
	"w",
	"x",
	"y",
	"z",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"0",
	"<",
	">",
	"?",
	"@",
	"{",
	"}",
	"[",
	"]",
	"!",
	"(",
	")",
	"=",
	"+",
	"~",
	"#",
}

tbl1.generateUID = function(arg1)
	local var1 = tbl2
	local str1 = ""
	for i1 = 1, arg1 or 8 do
		local var2 = #var1
		str1 = str1 .. var1[math.random(1, var2)]
	end

	return str1
end

local tbl3 = {}
tbl1.setVisible = function(arg1, arg2, arg3)
	local var2 = tbl3[arg1]
	if not var2 then
		var2 = {}
		tbl3[arg1] = var2
		arg1.Destroying:Once(function()
			tbl3[arg1] = nil
		end)

	end

	if not arg2 then
		var2[arg3] = true
	else
		var2[arg3] = nil
	end

	local var3 = arg2
	if arg2 then
		for k1, v1 in pairs(var2) do
			var3 = false
			break
		end
	end

	arg1.Visible = var3
end

tbl1.formatStateName = function(arg1)
	return string.upper((string.sub(arg1, 1, 1))) .. string.lower((string.sub(arg1, 2)))
end

tbl1.localPlayerRespawned = function(arg1)
	var1.CharacterRemoving:Connect(arg1)
end

tbl1.getClippedContainer = function(arg1)
	local var2 = arg1:FindFirstChild("ClippedContainer")
	if not var2 then
		var2 = Instance.new("Folder")
		var2.Name = "ClippedContainer"
		var2.Parent = arg1
	end

	return var2
end

local var2 = require(script.Parent.Packages.Janitor)
local var3 = game:GetService("GuiService")
tbl1.clipOutside = function(arg1, arg2)
	local var1 = arg1.janitor:add(var2.new())
	arg2.Destroying:Once(function()
		var1:Destroy()
	end)

	arg1.janitor:add(arg2)
	local str1 = "Frame"
	local var4 = var1:add(Instance.new(str1))
	var4:SetAttribute("IsAClippedClone", true)
	var4.Name = arg2.Name
	var4.AnchorPoint = arg2.AnchorPoint
	var4.Size = arg2.Size
	var4.Position = arg2.Position
	var4.BackgroundTransparency = 1
	var4.LayoutOrder = arg2.LayoutOrder
	local var5 = arg2.Parent
	var4.Parent = var5
	local var6 = Instance.new("ObjectValue")
	var6.Name = "OriginalInstance"
	var6.Value = arg2
	var6.Parent = var4
	arg2:SetAttribute("HasAClippedClone", true)
	local var7 = var6:Clone()
	var7.Name = "ClippedClone"
	var7.Value = var4
	var7.Parent = arg2
	str1 = nil
	local function updateScreenGui()
		local var1 = var5:FindFirstAncestorWhichIsA("ScreenGui")
		local var2 = if string.match(var1.Name, "Clipped") then var1 else var1.Parent[var1.Name .. "Clipped"]
		str1 = var2
		arg2.AnchorPoint = Vector2.new(0, 0)
		arg2.Parent = tbl1.getClippedContainer(str1)
	end

	local var8 = updateScreenGui
	var1:add(arg1.alignmentChanged:Connect(var8))
	updateScreenGui()
	for k1, v1 in pairs(arg2:GetChildren()) do
		if not v1:IsA("UIAspectRatioConstraint") then
			continue
		end

		v1:Clone().Parent = var4
	end

	local var9 = arg2:GetAttribute("IgnoreVisibilityUpdater")
	local var10 = arg1.widget
	local bool1 = false
	local function updateVisibility()
		if var9 then
			return
		end

		local var2 = var10.Visible
		if bool1 then
			var2 = false
		end

		tbl1.setVisible(arg2, var2, "ClipHandler")
	end

	var1:add(var10:GetPropertyChangedSignal("Visible"):Connect(updateVisibility))
	local var11 = require(arg1.iconModule)
	local var12 = nil
	local var13 = workspace.CurrentCamera
	updateVisibility = arg2:GetAttribute("AdditionalOffsetX") or 0
	local function checkIfOutsideParentXBounds()
		task.defer(function()
			local var2 = arg1.UID
			local var3 = nil
			local var4 = var2
			if arg2:GetAttribute("ClipToJoinedParent") then
				for i1 = 1, 10 do
					local var5 = var11.getIconByUID(var4)
					if not var5 then
						break
					end

					local var6 = var5.joinedFrame
					if not var6 then
						break
					end

					var3 = var6
					local var7 = var5.parentIconUID
				end
			end

			if not var3 then
				bool1 = false
				if var9 then
					return
				end

				local var13 = var10.Visible
				if bool1 then
					var13 = false
				end

				tbl1.setVisible(arg2, var13, "ClipHandler")
				return
			end

			local var14 = arg2.AbsolutePosition + arg2.AbsoluteSize / 2
			local var15 = var3.AbsolutePosition
			local var16 = var3.AbsoluteSize
			local var17 = var14.X < var15.X
			var17 = var17 or (var15.X + var16.X < var14.X or (var14.Y < var15.Y or var15.Y + var16.Y < var14.Y))
			if var17 ~= bool1 then
				bool1 = var17
				if var9 then
				else
					local var19 = var10.Visible
					if bool1 then
						var19 = false
					end

					tbl1.setVisible(arg2, var19, "ClipHandler")
				end
			end

			if var3:IsA("ScrollingFrame") and var12 ~= var3 then
				var12 = var3
				var1:add(var3:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(function()
					checkIfOutsideParentXBounds()
				end), "Disconnect", "TrackUtilityScroller-" .. var2)

			end
		end)
	end

	task.delay(0.1, checkIfOutsideParentXBounds)
	task.defer(function()
		local var2 = arg1.UID
		local var3 = nil
		local var4 = var2
		if arg2:GetAttribute("ClipToJoinedParent") then
			for i1 = 1, 10 do
				local var5 = var11.getIconByUID(var4)
				if not var5 then
					break
				end

				local var6 = var5.joinedFrame
				if not var6 then
					break
				end

				var3 = var6
				local var7 = var5.parentIconUID
			end
		end

		if not var3 then
			bool1 = false
			if var9 then
				return
			end

			local var13 = var10.Visible
			if bool1 then
				var13 = false
			end

			tbl1.setVisible(arg2, var13, "ClipHandler")
			return
		end

		local var14 = arg2.AbsolutePosition + arg2.AbsoluteSize / 2
		local var15 = var3.AbsolutePosition
		local var16 = var3.AbsoluteSize
		local var17 = var14.X < var15.X
		var17 = var17 or (var15.X + var16.X < var14.X or (var14.Y < var15.Y or var15.Y + var16.Y < var14.Y))
		if var17 ~= bool1 then
			bool1 = var17
			if var9 then
			else
				local var19 = var10.Visible
				if bool1 then
					var19 = false
				end

				tbl1.setVisible(arg2, var19, "ClipHandler")
			end
		end

		if var3:IsA("ScrollingFrame") and var12 ~= var3 then
			var12 = var3
			var1:add(var3:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(function()
				checkIfOutsideParentXBounds()
			end), "Disconnect", "TrackUtilityScroller-" .. var2)

		end
	end)

	local function trackProperty(arg1)
		local var2 = "Absolute" .. arg1
		local function updateProperty()
			local var5 = var4[var2]
			local var8 = UDim2.fromOffset(var5.X, var5.Y)
			if arg1 == "Position" then
				local var15 = var8.X.Offset
				local var16 = var13.ViewportSize.X - arg2.AbsoluteSize.X - 4
				if var15 < 4 then
					var15 = 4
				elseif var16 < var15 then
					var15 = var16
				end

				local var17 = var3.TopbarInset
				local var18 = str1.AbsolutePosition.X
				var8 = UDim2.fromOffset(var15, var8.Y.Offset)
				local var19 = workspace.CurrentCamera.ViewportSize.X
				local var20 = str1.AbsoluteSize.X
				task.defer(function()
					local var2 = arg1.UID
					local var3 = nil
					local var4 = var2
					if arg2:GetAttribute("ClipToJoinedParent") then
						for i1 = 1, 10 do
							local var5 = var11.getIconByUID(var4)
							if not var5 then
								break
							end

							local var6 = var5.joinedFrame
							if not var6 then
								break
							end

							var3 = var6
							local var7 = var5.parentIconUID
						end
					end

					if not var3 then
						bool1 = false
						if var9 then
							return
						end

						local var13 = var10.Visible
						if bool1 then
							var13 = false
						end

						tbl1.setVisible(arg2, var13, "ClipHandler")
						return
					end

					local var14 = arg2.AbsolutePosition + arg2.AbsoluteSize / 2
					local var15 = var3.AbsolutePosition
					local var16 = var3.AbsoluteSize
					local var17 = var14.X < var15.X
					var17 = var17 or (var15.X + var16.X < var14.X or (var14.Y < var15.Y or var15.Y + var16.Y < var14.Y))
					if var17 ~= bool1 then
						bool1 = var17
						if var9 then
						else
							local var19 = var10.Visible
							if bool1 then
								var19 = false
							end

							tbl1.setVisible(arg2, var19, "ClipHandler")
						end
					end

					if var3:IsA("ScrollingFrame") and var12 ~= var3 then
						var12 = var3
						var1:add(var3:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(function()
							checkIfOutsideParentXBounds()
						end), "Disconnect", "TrackUtilityScroller-" .. var2)

					end
				end)

				var8 = var8 + UDim2.fromOffset(-((if arg1.isOldTopbar then var18 else var19 - var20 - 0) - updateVisibility), var17.Height)
			end

			arg2[arg1] = var8
		end

		local var5 = tbl1.createStagger(0.01, updateProperty)
		var1:add(var4:GetPropertyChangedSignal(var2):Connect(var5))
		local var6 = tbl1.createStagger(0.5, updateProperty, true)
		var1:add(var4:GetPropertyChangedSignal(var2):Connect(var6))
	end

	if var9 then
	else
		local var15 = var10.Visible
		if bool1 then
			var15 = false
		end

		tbl1.setVisible(arg2, var15, "ClipHandler")
	end

	trackProperty("Position")
	local function fn5()
	end

	var1:add(arg2:GetPropertyChangedSignal("Visible"):Connect(fn5))
	if arg2:GetAttribute("TrackCloneSize") then
		trackProperty("Size")
	else
		local function fn7()
			local var1 = arg2.AbsoluteSize
			var4.Size = UDim2.fromOffset(var1.X, var1.Y)
		end

		var1:add(arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(fn7))
	end

	return var4
end

tbl1.joinFeature = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.joinJanitor
	var1:clean()
	if not arg4 then
		arg1:leave()
		return
	end

	arg1.parentIconUID = arg2.UID
	arg1.joinedFrame = arg4
	local function updateAlignent()
		local var2 = arg2.alignment
		if var2 == "Center" then
			var2 = "Left"
		end

		arg1:setAlignment(var2, true)
	end

	var1:add(arg2.alignmentChanged:Connect(updateAlignent))
	local var3 = arg2.alignment
	if var3 == "Center" then
		var3 = "Left"
	end

	arg1:setAlignment(var3, true)
	arg1:modifyTheme({ "IconButton", "BackgroundTransparency", 1 }, "JoinModification")
	arg1:modifyTheme({ "ClickRegion", "Active", false }, "JoinModification")
	if arg2.childModifications then
		task.defer(function()
			arg1:modifyTheme(arg2.childModifications, arg2.childModificationsUID)
		end)

	end

	var3 = arg1:getInstance("ClickRegion")
	local function makeSelectable()
		var3.Selectable = arg2.isSelected
	end

	local var4 = makeSelectable
	var1:add(arg2.toggled:Connect(var4))
	task.defer(makeSelectable)
	var1:add(function()
		var3.Selectable = true
	end)

	local var5 = arg1.UID
	table.insert(arg3, var5)
	arg2:autoDeselect(false)
	arg2.childIconsDict[var5] = true
	if not arg2.isEnabled then
		arg2:setEnabled(true)
	end

	arg1.joinedParent:Fire(arg2)
	var1:add(function()
		if not arg1.joinedFrame then
			return
		end

		for k1, v1 in pairs(arg3) do
			if v1 ~= var5 then
				continue
			end

			table.remove(arg3, k1)
			break
		end

		local var2 = require(arg1.iconModule).getIconByUID(arg1.parentIconUID)
		if not var2 then
			return
		end

		arg1:setAlignment(arg1.originalAlignment)
		arg1.parentIconUID = false
		arg1.joinedFrame = false
		arg1:setBehaviour("IconButton", "BackgroundTransparency", nil, true)
		arg1:removeModification("JoinModification")
		local var3 = var2.childIconsDict
		var3[var5] = nil
		local bool1 = true
		for k2, v2 in pairs(var3) do
			bool1 = false
			break
		end

		if bool1 and (not var2.isAnOverflow) then
			var2:setEnabled(false)
		end

		local var6 = arg2.alignment
		if var6 == "Center" then
			var6 = "Left"
		end

		arg1:setAlignment(var6, true)
	end)
end

return tbl1

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Caption [ModuleScript]
-- y u r i

return function(arg1)
	local var1 = arg1:getInstance("ClickRegion")
	local var2 = Instance.new("CanvasGroup")
	var2.Name = "Caption"
	var2.AnchorPoint = Vector2.new(0.5, 0)
	var2.BackgroundTransparency = 1
	var2.BorderSizePixel = 0
	var2.GroupTransparency = 1
	var2.Position = UDim2.fromOffset(0, 0)
	var2.Visible = true
	var2.ZIndex = 30
	var2.Parent = var1
	local var3 = Instance.new("Frame")
	var3.Name = "Box"
	var3.AutomaticSize = Enum.AutomaticSize.XY
	var3.BackgroundColor3 = Color3.fromRGB(101, 102, 104)
	var3.Position = UDim2.fromOffset(4, 7)
	var3.ZIndex = 12
	var3.Parent = var2
	local var4 = Instance.new("TextLabel")
	var4.Name = "Header"
	var4.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	var4.Text = "Caption"
	var4.TextColor3 = Color3.fromRGB(255, 255, 255)
	var4.TextSize = 14
	var4.TextTruncate = Enum.TextTruncate.None
	var4.TextWrapped = false
	var4.TextXAlignment = Enum.TextXAlignment.Left
	var4.AutomaticSize = Enum.AutomaticSize.X
	var4.BackgroundTransparency = 1
	var4.LayoutOrder = 1
	var4.Size = UDim2.fromOffset(0, 16)
	var4.ZIndex = 18
	var4.Parent = var3
	local var5 = Instance.new("UIListLayout")
	var5.Name = "Layout"
	var5.Padding = UDim.new(0, 8)
	var5.SortOrder = Enum.SortOrder.LayoutOrder
	var5.Parent = var3
	local var6 = Instance.new("UICorner")
	var6.Name = "CaptionCorner"
	var6.Parent = var3
	local var7 = Instance.new("UIPadding")
	var7.Name = "Padding"
	var7.PaddingBottom = UDim.new(0, 12)
	var7.PaddingLeft = UDim.new(0, 12)
	var7.PaddingRight = UDim.new(0, 12)
	var7.PaddingTop = UDim.new(0, 12)
	var7.Parent = var3
	local var8 = Instance.new("Frame")
	var8.Name = "Hotkeys"
	var8.AutomaticSize = Enum.AutomaticSize.Y
	var8.BackgroundTransparency = 1
	var8.LayoutOrder = 3
	var8.Size = UDim2.fromScale(1, 0)
	var8.Visible = false
	var8.Parent = var3
	local var9 = Instance.new("UIListLayout")
	var9.Name = "Layout1"
	var9.Padding = UDim.new(0, 6)
	var9.FillDirection = Enum.FillDirection.Vertical
	var9.HorizontalAlignment = Enum.HorizontalAlignment.Center
	var9.HorizontalFlex = Enum.UIFlexAlignment.None
	var9.ItemLineAlignment = Enum.ItemLineAlignment.Automatic
	var9.VerticalFlex = Enum.UIFlexAlignment.None
	var9.SortOrder = Enum.SortOrder.LayoutOrder
	var9.Parent = var8
	local var10 = Instance.new("ImageLabel")
	var10.Name = "Key1"
	var10.Image = "rbxasset://textures/ui/Controls/key_single.png"
	var10.ImageTransparency = 0.7
	var10.ScaleType = Enum.ScaleType.Slice
	var10.SliceCenter = Rect.new(5, 5, 23, 24)
	var10.AutomaticSize = Enum.AutomaticSize.X
	var10.BackgroundTransparency = 1
	var10.LayoutOrder = 1
	var10.Size = UDim2.fromOffset(0, 30)
	var10.ZIndex = 15
	var10.Parent = var8
	local var11 = Instance.new("UIPadding")
	var11.Name = "Inset"
	var11.PaddingLeft = UDim.new(0, 8)
	var11.PaddingRight = UDim.new(0, 8)
	var11.Parent = var10
	local var12 = Instance.new("TextLabel")
	var12.AutoLocalize = false
	var12.Name = "LabelContent"
	var12.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	var12.Text = ""
	var12.TextColor3 = Color3.fromRGB(189, 190, 190)
	var12.TextSize = 14
	var12.AutomaticSize = Enum.AutomaticSize.X
	var12.BackgroundTransparency = 1
	var12.Position = UDim2.fromOffset(0, -1)
	var12.Size = UDim2.fromScale(1, 1)
	var12.ZIndex = 16
	var12.Parent = var10
	local var13 = Instance.new("ImageLabel")
	var13.Name = "Caret"
	var13.Image = "rbxasset://LuaPackages/Packages/_Index/UIBlox/UIBlox/AppImageAtlas/img_set_1x_1.png"
	var13.ImageColor3 = Color3.fromRGB(101, 102, 104)
	var13.ImageRectOffset = Vector2.new(260, 440)
	var13.ImageRectSize = Vector2.new(16, 8)
	var13.AnchorPoint = Vector2.new(0, 0.5)
	var13.BackgroundTransparency = 1
	var13.Position = UDim2.new(0, 0, 0, 4)
	var13.Rotation = 180
	var13.Size = UDim2.fromOffset(16, 8)
	var13.ZIndex = 12
	var13.Parent = var2
	local var14 = Instance.new("ImageLabel")
	var14.Name = "DropShadow"
	var14.Image = "rbxasset://LuaPackages/Packages/_Index/UIBlox/UIBlox/AppImageAtlas/img_set_1x_1.png"
	var14.ImageColor3 = Color3.fromRGB(0, 0, 0)
	var14.ImageRectOffset = Vector2.new(217, 486)
	var14.ImageRectSize = Vector2.new(25, 25)
	var14.ImageTransparency = 0.45
	var14.ScaleType = Enum.ScaleType.Slice
	var14.SliceCenter = Rect.new(12, 12, 13, 13)
	var14.BackgroundTransparency = 1
	var14.Position = UDim2.fromOffset(0, 5)
	var14.Size = UDim2.new(1, 0, 0, 48)
	var14.Parent = var2
	var3:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		var14.Size = UDim2.new(1, 0, 0, var3.AbsoluteSize.Y + 8)
	end)

	local var15, var16 = arg1:clipOutside(var2)
	var16.AutomaticSize = Enum.AutomaticSize.None
	local function matchSize()
		local var1 = var2.AbsoluteSize
		var16.Size = UDim2.fromOffset(var1.X, var1.Y)
	end

	local var17 = arg1.captionJanitor
	var17:add(var2:GetPropertyChangedSignal("AbsoluteSize"):Connect(matchSize))
	local var18 = var2.AbsoluteSize
	var16.Size = UDim2.fromOffset(var18.X, var18.Y)
	local var19 = game:GetService("UserInputService")
	local var20 = var2.Box.Header
	local function updateHotkey(arg1)
		local var1 = var2:GetAttribute("CaptionText") or ""
		local var5 = var19.KeyboardEnabled
		local var6 = var1 == "_hotkey_"
		if not var5 and var6 then
			arg1:setCaption()
			return
		end

		var20.Text = var1
		var20.Visible = not var6
		if arg1 then
			var12.Text = arg1.Name
			var8.Visible = true
		end

		if not var5 then
			var8.Visible = false
		end
	end

	var2:GetAttributeChangedSignal("CaptionText"):Connect(updateHotkey)
	matchSize = Enum.EasingStyle.Quad
	var18 = false
	local var21 = TweenInfo.new(0.2, matchSize, Enum.EasingDirection.In)
	local var22 = TweenInfo.new(0.2, matchSize, Enum.EasingDirection.Out)
	local var23 = game:GetService("TweenService")
	local var24 = game:GetService("RunService")
	local function updatePosition(arg1)
		if not var18 then
			return
		end

		local var3 = if arg1 ~= nil then arg1 else var18
		local var5 = not var3
		local var6 = UDim2.new(0.5, 0, 1, if if var5 ~= nil then var5 else var18 then 10 else 2)
		var5 = UDim2.new(0.5, 0, 1, if if var3 ~= nil then var3 else var18 then 10 else 2)
		if var3 then
			var13.Position = UDim2.fromOffset(0, var13.Position.Y.Offset)
			var2.AutomaticSize = Enum.AutomaticSize.XY
			var2.Size = UDim2.fromOffset(32, 53)
		else
			var2.AutomaticSize = Enum.AutomaticSize.Y
			local var7 = var2.AbsoluteSize
			var2.Size = UDim2.fromOffset(var7.X, var7.Y)
		end

		local var8 = nil
		var16.Position = var6
		local function updateCaret()
			local var3 = var1.AbsolutePosition.X - var2.AbsolutePosition.X + var1.AbsoluteSize.X / 2 - var13.AbsoluteSize.X / 2
			local var4 = var13.Position.Y.Offset
			local var5 = UDim2.fromOffset(var3, var4)
			if var8 ~= var3 then
				var8 = var3
				var13.Position = UDim2.fromOffset(0, var4)
				task.wait()
			end

			var13.Position = var5
		end

		updateCaret()
		local var9 = var23:Create(var16, var3 and var21 or var22, { Position = var5 })
		var9:Play()
		local var10 = var24.Heartbeat:Connect(updateCaret)
		var9.Completed:Once(function()
			var10:Disconnect()
		end)
	end

	local function fn5()
		updatePosition()
	end

	var17:add(var1:GetPropertyChangedSignal("AbsoluteSize"):Connect(fn5))
	updatePosition(false)
	fn5 = updateHotkey
	var17:add(arg1.toggleKeyAdded:Connect(fn5))
	for k1, v1 in pairs(arg1.bindedToggleKeys) do
		local var25 = var2:GetAttribute("CaptionText") or ""
		local var28 = var19.KeyboardEnabled
		local var29 = var25 == "_hotkey_"
		if not var28 and var29 then
			arg1:setCaption()
			break
		end

		var20.Text = var25
		var20.Visible = not var29
		if k1 then
			var12.Text = k1.Name
			var8.Visible = true
		end

		if var28 then
			break
		end

		var8.Visible = false
		break
	end

	local var30 = updateHotkey
	var17:add(arg1.fakeToggleKeyChanged:Connect(var30))
	local var33 = arg1.fakeToggleKey
	if var33 then
		local var34 = var2:GetAttribute("CaptionText") or ""
		local var37 = var19.KeyboardEnabled
		local var38 = var34 == "_hotkey_"
		if not var37 and var38 then
			arg1:setCaption()
		else
			var20.Text = var34
			var20.Visible = not var38
			if var33 then
				var12.Text = var33.Name
				var8.Visible = true
			end

			if not var37 then
				var8.Visible = false
			end
		end
	end

	local var39 = require(arg1.iconModule)
	local function setCaptionEnabled(arg1)
		if var18 == arg1 then
			return
		end

		local var3 = arg1.joinedFrame
		if var3 and string.match(var3.Name, "Dropdown") then
			arg1 = false
		end

		var18 = arg1
		var23:Create(var2, arg1 and var21 or var22, { GroupTransparency = if arg1 then 0 else 1 }):Play()
		updatePosition()
		local var4 = var2:GetAttribute("CaptionText") or ""
		local var7 = var19.KeyboardEnabled
		local var9 = var4 == "_hotkey_"
		if not var7 and var9 then
			arg1:setCaption()
			return
		end

		var20.Text = var4
		var20.Visible = not var9
		if not var7 then
			var8.Visible = false
		end
	end

	local function fn8(arg1)
		if arg1 == "Viewing" then
			local var2 = var39.captionLastClosedClock
			task.delay(if (var2 and os.clock() - var2 or 999) < 0.3 then 0 else 0.5, function()
				if arg1.activeState == "Viewing" then
					setCaptionEnabled(true)
				end
			end)

			return
		end

		var39.captionLastClosedClock = os.clock()
		setCaptionEnabled(false)
	end

	var17:add(arg1.stateChanged:Connect(fn8))
	return var2
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Container [ModuleScript]
-- y u r i

return function(arg1)
	local var1 = game:GetService("GuiService")
	local var3 = arg1.isOldTopbar
	local var4 = var1:GetGuiInset()
	local var5 = var1:IsTenFootInterface()
	local var6 = if var3 then 12 else var4.Y - 46
	var6 = var5 and 10
	local var7 = Instance.new("ScreenGui")
	var7:SetAttribute("StartInset", var6)
	var7.Name = "TopbarStandard"
	var7.Enabled = true
	var7.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	var7.IgnoreGuiInset = true
	var7.ResetOnSpawn = false
	var7.ScreenInsets = Enum.ScreenInsets.TopbarSafeInsets
	var7.DisplayOrder = arg1.baseDisplayOrder
	arg1.baseDisplayOrderChanged:Connect(function()
		var7.DisplayOrder = arg1.baseDisplayOrder
	end)

	local var8 = Instance.new("Frame")
	local tbl1 = { [var7.Name] = var7 }
	local var9 = if var3 then 2 else 0
	local num2 = -2
	if var5 then
		var9 = var9 + 13
		num2 = 50
	end

	var8.Name = "Holders"
	var8.BackgroundTransparency = 1
	var8.Position = UDim2.new(0, 0, 0, var9)
	var8.Size = UDim2.new(1, 0, 1, num2)
	var8.Visible = true
	var8.ZIndex = 1
	var8.Parent = var7
	local var10 = var7:Clone()
	local var11 = var10.Holders
	local var12 = game:GetService("GuiService")
	var10.Name = "TopbarCentered"
	var10.ScreenInsets = Enum.ScreenInsets.None
	arg1.baseDisplayOrderChanged:Connect(function()
		var10.DisplayOrder = arg1.baseDisplayOrder
	end)

	tbl1[var10.Name] = var10
	var12:GetPropertyChangedSignal("TopbarInset"):Connect(function()
		var11.Size = UDim2.new(1, 0, 0, var12.TopbarInset.Height + num2)
	end)

	var11.Size = UDim2.new(1, 0, 0, var12.TopbarInset.Height + num2)
	local var13 = var7:Clone()
	local var14 = var13.Name .. "Clipped"
	var13.Name = var14
	var14 = var13.DisplayOrder + 1
	var13.DisplayOrder = var14
	arg1.baseDisplayOrderChanged:Connect(function()
		var13.DisplayOrder = arg1.baseDisplayOrder + 1
	end)

	tbl1[var13.Name] = var13
	var14 = var10:Clone()
	local var15 = var14.Name .. "Clipped"
	var14.Name = var15
	var15 = var14.DisplayOrder + 1
	var14.DisplayOrder = var15
	arg1.baseDisplayOrderChanged:Connect(function()
		var14.DisplayOrder = arg1.baseDisplayOrder + 1
	end)

	tbl1[var14.Name] = var14
	if var3 then
		task.defer(function()
			var12:GetPropertyChangedSignal("MenuIsOpen"):Connect(function()
				if var12.MenuIsOpen then
					arg1.setTopbarEnabled(false, true)
					return
				end

				arg1.setTopbarEnabled()
			end)

			if var12.MenuIsOpen then
				arg1.setTopbarEnabled(false, true)
				return
			end

			arg1.setTopbarEnabled()
		end)

	end

	var15 = Instance.new("ScrollingFrame")
	var15:SetAttribute("IsAHolder", true)
	var15.Name = "Left"
	var15.Position = UDim2.fromOffset(var6, 0)
	var15.Size = UDim2.new(1, -24, 1, 0)
	var15.BackgroundTransparency = 1
	var15.Visible = true
	var15.ZIndex = 1
	var15.Active = false
	var15.ClipsDescendants = true
	var15.HorizontalScrollBarInset = Enum.ScrollBarInset.None
	var15.CanvasSize = UDim2.new(0, 0, 1, -1)
	var15.AutomaticCanvasSize = Enum.AutomaticSize.X
	var15.ScrollingDirection = Enum.ScrollingDirection.X
	var15.ScrollBarThickness = 0
	var15.BorderSizePixel = 0
	var15.Selectable = false
	var15.ScrollingEnabled = false
	var15.ElasticBehavior = Enum.ElasticBehavior.Never
	var15.Parent = var8
	local var16 = Instance.new("UIListLayout")
	var16.Padding = UDim.new(0, var6)
	var16.FillDirection = Enum.FillDirection.Horizontal
	var16.SortOrder = Enum.SortOrder.LayoutOrder
	var16.VerticalAlignment = Enum.VerticalAlignment.Bottom
	var16.HorizontalAlignment = Enum.HorizontalAlignment.Left
	var16.Parent = var15
	local var17 = var15:Clone()
	var17.ScrollingEnabled = false
	var17.UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	var17.Name = "Center"
	var17.Parent = var11
	local var18 = var15:Clone()
	var18.UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right
	var18.Name = "Right"
	var18.AnchorPoint = Vector2.new(1, 0)
	var18.Position = UDim2.new(1, -12, 0, 0)
	var18.Parent = var8
	return tbl1
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Dropdown [ModuleScript]
-- y u r i

return function(arg1)
	local var1 = Instance.new("Frame")
	var1.Name = "Dropdown"
	var1.AutomaticSize = Enum.AutomaticSize.XY
	var1.BackgroundTransparency = 1
	var1.BorderSizePixel = 0
	var1.AnchorPoint = Vector2.new(0.5, 0)
	var1.Position = UDim2.new(0.5, 0, 1, 10)
	var1.ZIndex = -2
	var1.ClipsDescendants = true
	var1.Parent = arg1.widget
	local var2 = Instance.new("UICorner")
	var2.Name = "DropdownCorner"
	var2.CornerRadius = UDim.new(0, 10)
	var2.Parent = var1
	local var3 = Instance.new("ScrollingFrame")
	var3.Name = "DropdownScroller"
	var3.AutomaticSize = Enum.AutomaticSize.X
	var3.BackgroundTransparency = 1
	var3.BorderSizePixel = 0
	var3.AnchorPoint = Vector2.new(0, 0)
	var3.Position = UDim2.new(0, 0, 0, 0)
	var3.ZIndex = -1
	var3.ClipsDescendants = true
	var3.Visible = true
	var3.VerticalScrollBarInset = Enum.ScrollBarInset.ScrollBar
	var3.VerticalScrollBarPosition = Enum.VerticalScrollBarPosition.Right
	var3.Active = false
	var3.ScrollingEnabled = true
	var3.AutomaticCanvasSize = Enum.AutomaticSize.Y
	var3.ScrollBarThickness = 5
	var3.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255)
	var3.ScrollBarImageTransparency = 0.8
	var3.CanvasSize = UDim2.new(0, 0, 0, 0)
	var3.Selectable = false
	var3.Active = true
	var3.Parent = var1
	local var4 = Instance.new("UIPadding")
	var4.Name = "DropdownPadding"
	var4.PaddingTop = UDim.new(0, 8)
	var4.PaddingBottom = UDim.new(0, 8)
	var4.Parent = var3
	local var5 = Instance.new("UIListLayout")
	var5.Name = "DropdownList"
	var5.FillDirection = Enum.FillDirection.Vertical
	var5.SortOrder = Enum.SortOrder.LayoutOrder
	var5.HorizontalAlignment = Enum.HorizontalAlignment.Center
	var5.HorizontalFlex = Enum.UIFlexAlignment.SpaceEvenly
	var5.Parent = var3
	arg1.dropdownChildAdded:Connect(function(arg1)
		local num1 = 0
		local num2 = 4
		local num3 = 25
		local num4 = 0
		num4 = 1
		local num5 = -24
		local num6 = 0
		local num7 = 5
		num6 = 1
		num7 = -8
		local num8 = 1
		local num9 = -8
		num7 = 0
		num8 = 4
		num9 = 0
		local num10 = 4
		local var1, var2 = arg1:modifyTheme({
			{ "Widget", "BorderSize", 0 },
			{ "IconCorners", "CornerRadius", UDim.new(num1, num2) },
			{ "Widget", "MinimumWidth", 190 },
			{ "Widget", "MinimumHeight", 56 },
			{ "IconLabel", "TextSize", 19 },
			{ "PaddingLeft", "Size", UDim2.fromOffset(num3, num4) },
			{ "Notice", "Position", UDim2.new(num4, num5, num6, num7) },
			{ "ContentsList", "HorizontalAlignment", Enum.HorizontalAlignment.Left },
			{ "Selection", "Size", UDim2.new(num6, num7, num8, num9) },
			{ "Selection", "Position", UDim2.new(num7, num8, num9, num10) },
		})

		task.defer(function()
			arg1.joinJanitor:add(function()
				arg1:removeModification(var2)
			end)
		end)
	end)

	local var6 = require(arg1.iconModule)
	arg1.dropdownSet:Connect(function(arg1)
		for k1, v1 in pairs(arg1.dropdownIcons) do
			local var1 = var6.getIconByUID(v1)
			var1:destroy()
		end

		if type(arg1) == "table" then
			for k2, v2 in pairs(arg1) do
				v2:joinDropdown(arg1)
			end
		end
	end)

	local var7 = require(script.Parent.Parent.Utility)
	local function updateVisibility()
		var7.setVisible(var1, arg1.isSelected, "InternalDropdown")
	end

	local var8 = arg1.dropdownJanitor
	var8:add(arg1.toggled:Connect(updateVisibility))
	var7.setVisible(var1, arg1.isSelected, "InternalDropdown")
	local num1 = 0
	local bool1 = false
	local function updateMaxIcons()
		local var2 = num1 + 1
		num1 = var2
		if bool1 then
			return
		end

		bool1 = true
		var2 = num1
		task.defer(function()
			bool1 = false
			if num1 ~= var2 then
				updateMaxIcons()
			end
		end)

		local var7 = var1:GetAttribute("MaxIcons")
		if not var7 then
			return
		end

		local tbl1 = {}
		for k1, v1 in pairs(var3:GetChildren()) do
			if not v1:IsA("GuiObject") then
				continue
			end

			table.insert(tbl1, { v1, v1.AbsolutePosition.Y })
		end

		table.sort(tbl1, function(arg1, arg2)
			return arg1[2] < arg2[2]
		end)

		local num2 = 0
		local bool2 = false
		for i1 = 1, var7 do
			local var8 = tbl1[i1]
			if not var8 then
				break
			end

			local var9 = var8[1]
			local var10 = var9:GetAttribute("WidgetUID")
			local var11 = var10
			var11 = var11 and var6.getIconByUID(var10)
			if not var11 then
				continue
			end

			local var12 = nil
			var12 = bool2 or arg1:getInstance("ClickRegion")
			var11:getInstance("ClickRegion").NextSelectionUp = var12
			num2 = num2 + var9.AbsoluteSize.Y
			local bool3 = true
		end

		var3.Size = UDim2.fromOffset(0, num2 + var4.PaddingTop.Offset + var4.PaddingBottom.Offset)
	end

	local var9 = updateMaxIcons
	var8:add(var3:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(var9))
	var9 = updateMaxIcons
	var8:add(var3.ChildAdded:Connect(var9))
	var9 = updateMaxIcons
	var8:add(var3.ChildRemoved:Connect(var9))
	var9 = updateMaxIcons
	var8:add(var1:GetAttributeChangedSignal("MaxIcons"):Connect(var9))
	var9 = updateMaxIcons
	var8:add(arg1.childThemeModified:Connect(var9))
	updateMaxIcons()
	return var1
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Indicator [ModuleScript]
-- y u r i

return function(arg1, _)
	local var1 = arg1:getInstance("Contents")
	local var2 = Instance.new("Frame")
	var2.Name = "Indicator"
	var2.LayoutOrder = 9999999
	var2.ZIndex = 6
	var2.Size = UDim2.new(0, 42, 0, 42)
	var2.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var2.BackgroundTransparency = 1
	var2.Position = UDim2.new(1, 0, 0.5, 0)
	var2.BorderSizePixel = 0
	var2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	var2.Parent = var1
	local var3 = Instance.new("Frame")
	var3.Name = "IndicatorButton"
	var3.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var3.AnchorPoint = Vector2.new(0.5, 0.5)
	var3.BorderSizePixel = 0
	var3.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	var3.Parent = var2
	local var4 = game:GetService("GuiService")
	local var5 = arg1:getInstance("ClickRegion")
	local function selectionChanged()
		if var4.SelectedObject == var5 then
			var3.BackgroundTransparency = 1
			var3.Position = UDim2.new(0.5, -2, 0.5, 0)
			var3.Size = UDim2.fromScale(1.2, 1.2)
			return
		end

		var3.BackgroundTransparency = 0.75
		var3.Position = UDim2.new(0.5, 2, 0.5, 0)
		var3.Size = UDim2.fromScale(1, 1)
	end

	local var6 = selectionChanged
	arg1.janitor:add(var4:GetPropertyChangedSignal("SelectedObject"):Connect(var6))
	selectionChanged()
	local var7 = game:GetService("GamepadService")
	local var8 = Instance.new("ImageLabel")
	var8.LayoutOrder = 2
	var8.ZIndex = 15
	var8.AnchorPoint = Vector2.new(0.5, 0.5)
	var8.Size = UDim2.new(1, 0, 1, 0)
	var8.BackgroundTransparency = 1
	var8.Position = UDim2.new(0.5, 0, 0.5, 0)
	var8.Image = "rbxasset://textures/ui/Controls/XboxController/DPadUp@2x.png"
	var8.Parent = var3
	local var9 = Instance.new("UICorner")
	var9.CornerRadius = UDim.new(1, 0)
	var9.Parent = var3
	local function setIndicatorVisible(arg1)
		if arg1 == nil then
			arg1 = var2.Visible
		end

		if var7.GamepadCursorEnabled then
			arg1 = false
		end

		if arg1 then
			local num5 = 0
			local num6 = 0
			local num7 = 1
			local num8 = 0
			arg1:modifyTheme({ "PaddingRight", "Size", UDim2.new(num5, num6, num7, num8) }, "IndicatorPadding")
		else
			if var2.Visible then
				arg1:removeModification("IndicatorPadding")
			end
		end

		arg1:modifyTheme({ "Indicator", "Visible", arg1 })
		arg1.updateSize:Fire()
	end

	local var10 = setIndicatorVisible
	arg1.janitor:add(var7:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(var10))
	local var11 = game:GetService("UserInputService")
	arg1.indicatorSet:Connect(function(arg1)
		local bool1 = false
		if arg1 then
			var8.Image = var11:GetImageForKeyCode(arg1)
			bool1 = true
		end

		setIndicatorVisible(bool1)
	end)

	local var12 = arg1.widget
	var12:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		local var1 = var12.AbsoluteSize.Y * 0.96
		var2.Size = UDim2.new(0, var1, 0, var1)
	end)

	local var13 = var12.AbsoluteSize.Y * 0.96
	var2.Size = UDim2.new(0, var13, 0, var13)
	return var2
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Menu [ModuleScript]
-- y u r i

return function(arg1)
	local var1 = Instance.new("ScrollingFrame")
	var1.Name = "Menu"
	var1.BackgroundTransparency = 1
	var1.Visible = true
	var1.ZIndex = 1
	var1.Size = UDim2.fromScale(1, 1)
	var1.ClipsDescendants = true
	var1.TopImage = ""
	var1.BottomImage = ""
	var1.HorizontalScrollBarInset = Enum.ScrollBarInset.Always
	var1.CanvasSize = UDim2.new(0, 0, 1, -1)
	var1.ScrollingEnabled = true
	var1.ScrollingDirection = Enum.ScrollingDirection.X
	var1.ZIndex = 20
	var1.ScrollBarThickness = 3
	var1.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255)
	var1.ScrollBarImageTransparency = 0.8
	var1.BorderSizePixel = 0
	var1.Selectable = false
	local var2 = require(arg1.iconModule)
	local var3 = var2.container.TopbarStandard:FindFirstChild("UIListLayout", true):Clone()
	var3.Name = "MenuUIListLayout"
	var3.VerticalAlignment = Enum.VerticalAlignment.Center
	var3.Parent = var1
	local var4 = Instance.new("Frame")
	var4.Name = "MenuGap"
	var4.BackgroundTransparency = 1
	var4.Visible = false
	var4.AnchorPoint = Vector2.new(0, 0.5)
	var4.ZIndex = 5
	var4.Parent = var1
	local bool1 = false
	local var5 = require(script.Parent.Parent.Features.Themes)
	arg1.menuChildAdded:Connect(function()
		local var4 = arg1.menuJanitor
		local var6 = #arg1.menuIcons
		if bool1 then
			if var6 <= 0 then
				var4:clean()
				bool1 = false
			end

			return
		end

		bool1 = true
		local function fn2()
			if 0 < (#arg1.menuIcons) then
				arg1.updateSize:Fire()
			end
		end

		var4:add(arg1.toggled:Connect(fn2))
		local var7, var8 = arg1:modifyTheme({ { "Menu", "Active", true } })
		task.defer(function()
			var4:add(function()
				arg1:removeModification(var8)
			end)
		end)

		local var9 = var1.AbsoluteCanvasSize.X
		local function rightAlignCanvas()
			if arg1.alignment == "Right" then
				local var3 = var1.AbsoluteCanvasSize.X
				local var4 = var9 - var3
				var9 = var3
				var1.CanvasPosition = Vector2.new(var1.CanvasPosition.X - var4, 0)
			end
		end

		local var10 = rightAlignCanvas
		var4:add(arg1.selected:Connect(var10))
		var10 = rightAlignCanvas
		var4:add(var1:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(var10))
		fn2 = arg1:getStateGroup()
		if var5.getThemeValue(fn2, "IconImage", "Image", "Deselected") == var5.getThemeValue(fn2, "IconImage", "Image", "Selected") then
			arg1:removeModificationWith("IconLabel", "Text", "Viewing")
			arg1:removeModificationWith("IconLabel", "Image", "Viewing")
			arg1:modifyTheme({
				{
					"IconLabel",
					"FontFace",
					Font.new("rbxasset://fonts/families/FredokaOne.json", Enum.FontWeight.Light, Enum.FontStyle.Normal),
					"Selected",
				},
				{ "IconLabel", "Text", "X", "Selected" },
				{ "IconLabel", "TextSize", 20, "Selected" },
				{ "IconLabel", "TextStrokeTransparency", 0.8, "Selected" },
				{ "IconImage", "Image", "", "Selected" },
			})

		end

		local var11 = arg1:getInstance("IconSpot")
		var10 = arg1:getInstance("MenuGap")
		local function updateAlignent()
			if arg1.alignment == "Right" then
				var11.LayoutOrder = 99999
				var10.LayoutOrder = 99998
				return
			end

			var11.LayoutOrder = -99999
			var10.LayoutOrder = -99998
		end

		var4:add(arg1.alignmentChanged:Connect(updateAlignent))
		if arg1.alignment == "Right" then
			var11.LayoutOrder = 99999
			var10.LayoutOrder = 99998
		else
			var11.LayoutOrder = -99999
			var10.LayoutOrder = -99998
		end

		var1:GetAttributeChangedSignal("MenuCanvasWidth"):Connect(function()
			local var2 = var1.CanvasSize.Y
			var1.CanvasSize = UDim2.new(0, var1:GetAttribute("MenuCanvasWidth"), var2.Scale, var2.Offset)
		end)

		updateAlignent = function()
			local var4 = var1:GetAttribute("MaxIcons")
			if not var4 then
				return
			end

			local tbl1 = {}
			for k1, v1 in pairs(var1:GetChildren()) do
				if not v1:GetAttribute("WidgetUID") then
					continue
				end

				if not v1.Visible then
					continue
				end

				table.insert(tbl1, { v1, v1.AbsolutePosition.X })
			end

			table.sort(tbl1, function(arg1, arg2)
				return arg1[2] < arg2[2]
			end)

			local num1 = 0
			for i1 = 1, var4 do
				local var5 = tbl1[i1]
				if not var5 then
					break
				end

				num1 = num1 + (var5[1].AbsoluteSize.X + var3.Padding.Offset)
			end

			var1:SetAttribute("MenuWidth", num1)
		end

		var4:add(arg1.updateMenu:Connect(updateAlignent))
		local function startMenuUpdate()
			task.delay(0.1, function()
				arg1.startMenuUpdate:Fire()
			end)
		end

		local var12 = startMenuUpdate
		var4:add(var1.ChildAdded:Connect(var12))
		var12 = startMenuUpdate
		var4:add(var1.ChildRemoved:Connect(var12))
		var12 = startMenuUpdate
		var4:add(var1:GetAttributeChangedSignal("MaxIcons"):Connect(var12))
		var12 = startMenuUpdate
		var4:add(var1:GetAttributeChangedSignal("MaxWidth"):Connect(var12))
		task.delay(0.1, function()
			arg1.startMenuUpdate:Fire()
		end)
	end)

	arg1.menuSet:Connect(function(arg1)
		for k1, v1 in pairs(arg1.menuIcons) do
			local var1 = var2.getIconByUID(v1)
			var1:destroy()
		end

		if type(arg1) == "table" then
			for k2, v2 in pairs(arg1) do
				v2:joinMenu(arg1)
			end
		end
	end)

	return var1
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Selection [ModuleScript]
-- y u r i

return function(_)
	local var1 = Instance.new("Frame")
	var1.Name = "SelectionContainer"
	var1.Visible = false
	local var2 = Instance.new("Frame")
	var2.Name = "Selection"
	var2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var2.BackgroundTransparency = 1
	var2.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var2.BorderSizePixel = 0
	var2.Parent = var1
	local var3 = Instance.new("UIStroke")
	var3.Name = "UIStroke"
	var3.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	var3.Color = Color3.fromRGB(255, 255, 255)
	var3.Thickness = 3
	var3.Parent = var2
	local var4 = Instance.new("UIGradient")
	var4.Name = "SelectionGradient"
	var4.Parent = var3
	local var5 = Instance.new("UICorner")
	var5:SetAttribute("Collective", "IconCorners")
	var5.Name = "UICorner"
	var5.CornerRadius = UDim.new(1, 0)
	var5.Parent = var2
	local num1 = 1
	var2:GetAttributeChangedSignal("RotationSpeed"):Connect(function()
		num1 = var2:GetAttribute("RotationSpeed")
	end)

	local var6 = game:GetService("GuiService")
	game:GetService("RunService").Heartbeat:Connect(function()
		if not var6.SelectedObject then
			return
		end

		var4.Rotation = os.clock() * num1 * 100 % 360
	end)

	return var1
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Widget [ModuleScript]
-- y u r i

return function(arg1, arg2)
	local var1 = Instance.new("Frame")
	var1:SetAttribute("WidgetUID", arg1.UID)
	var1.Name = "Widget"
	var1.BackgroundTransparency = 1
	var1.Visible = true
	var1.ZIndex = 20
	var1.Active = false
	var1.ClipsDescendants = true
	local var2 = Instance.new("Frame")
	var2.Name = "IconButton"
	var2.Visible = true
	var2.ZIndex = 2
	var2.BorderSizePixel = 0
	var2.Parent = var1
	var2.ClipsDescendants = true
	var2.Active = false
	arg1.deselected:Connect(function()
		var2.ClipsDescendants = true
	end)

	arg1.selected:Connect(function()
		task.defer(function()
			arg1.resizingComplete:Once(function()
				if arg1.isSelected then
					var2.ClipsDescendants = false
				end
			end)
		end)
	end)

	local var3 = Instance.new("UICorner")
	var3:SetAttribute("Collective", "IconCorners")
	var3.Parent = var2
	local var4 = require(script.Parent.Menu)(arg1)
	var4.Parent = var2
	local var5 = Instance.new("Frame")
	var5.Name = "IconSpot"
	var5.BackgroundColor3 = Color3.fromRGB(225, 225, 225)
	var5.BackgroundTransparency = 0.9
	var5.Visible = true
	var5.AnchorPoint = Vector2.new(0, 0.5)
	var5.ZIndex = 5
	var5.Parent = var4
	var3:Clone().Parent = var5
	local var6 = var5:Clone()
	var6.Name = "IconOverlay"
	var6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var6.ZIndex = var5.ZIndex + 1
	var6.Size = UDim2.new(1, 0, 1, 0)
	var6.Position = UDim2.new(0, 0, 0, 0)
	var6.AnchorPoint = Vector2.new(0, 0)
	var6.Visible = false
	var6.Parent = var5
	local var7 = Instance.new("TextButton")
	var7:SetAttribute("CorrespondingIconUID", arg1.UID)
	var7.Name = "ClickRegion"
	var7.BackgroundTransparency = 1
	var7.Visible = true
	var7.Text = ""
	var7.ZIndex = 20
	var7.Selectable = true
	var7.SelectionGroup = true
	var7.Parent = var5
	require(script.Parent.Parent.Features.Gamepad).registerButton(var7)
	var3:Clone().Parent = var7
	local var8 = Instance.new("Frame")
	var8.Name = "Contents"
	var8.BackgroundTransparency = 1
	var8.Size = UDim2.fromScale(1, 1)
	var8.Parent = var5
	local var9 = Instance.new("UIListLayout")
	var9.Name = "ContentsList"
	var9.FillDirection = Enum.FillDirection.Horizontal
	var9.VerticalAlignment = Enum.VerticalAlignment.Center
	var9.SortOrder = Enum.SortOrder.LayoutOrder
	var9.VerticalFlex = Enum.UIFlexAlignment.SpaceEvenly
	var9.Padding = UDim.new(0, 3)
	var9.Parent = var8
	local var10 = Instance.new("Frame")
	var10.Name = "PaddingLeft"
	var10.LayoutOrder = 1
	var10.ZIndex = 5
	var10.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var10.BackgroundTransparency = 1
	var10.BorderSizePixel = 0
	var10.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var10.Parent = var8
	local var11 = Instance.new("Frame")
	var11.Name = "PaddingCenter"
	var11.LayoutOrder = 3
	var11.ZIndex = 5
	var11.Size = UDim2.new(0, 0, 1, 0)
	var11.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var11.BackgroundTransparency = 1
	var11.BorderSizePixel = 0
	var11.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var11.Parent = var8
	local var12 = Instance.new("Frame")
	var12.Name = "PaddingRight"
	var12.LayoutOrder = 5
	var12.ZIndex = 5
	var12.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var12.BackgroundTransparency = 1
	var12.BorderSizePixel = 0
	var12.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var12.Parent = var8
	local var13 = Instance.new("Frame")
	var13.Name = "IconLabelContainer"
	var13.LayoutOrder = 4
	var13.ZIndex = 3
	var13.AnchorPoint = Vector2.new(0, 0.5)
	var13.Size = UDim2.new(0, 0, 0.5, 0)
	var13.BackgroundTransparency = 1
	var13.Position = UDim2.new(0.5, 0, 0.5, 0)
	var13.Parent = var8
	local var14 = Instance.new("TextLabel")
	var14.Name = "IconLabel"
	var14.LayoutOrder = 4
	var14.ZIndex = 15
	var14.AnchorPoint = Vector2.new(0, 0)
	local var15 = workspace.CurrentCamera.ViewportSize.X + 200
	var14.Size = UDim2.new(0, var15, 1, 0)
	var14.ClipsDescendants = false
	var14.BackgroundTransparency = 1
	var14.Position = UDim2.fromScale(0, 0)
	var14.RichText = true
	var14.TextColor3 = Color3.fromRGB(255, 255, 255)
	var14.TextXAlignment = Enum.TextXAlignment.Left
	var14.Text = ""
	var14.TextWrapped = true
	var14.TextWrap = true
	var14.TextScaled = false
	var14.Active = false
	var14.AutoLocalize = true
	var14.Parent = var13
	local var16 = Instance.new("ImageLabel")
	var16.Name = "IconImage"
	var16.LayoutOrder = 2
	var16.ZIndex = 15
	var16.AnchorPoint = Vector2.new(0, 0.5)
	var16.Size = UDim2.new(1, 0, 1, 0)
	var16.BackgroundTransparency = 1
	var16.Position = UDim2.new(0, 11, 0.5, 0)
	var16.ScaleType = Enum.ScaleType.Stretch
	var16.Active = false
	var16.Parent = var8
	local var17 = var3:Clone()
	var17:SetAttribute("Collective", nil)
	var17.CornerRadius = UDim.new(0, 0)
	var17.Name = "IconImageCorner"
	var17.Parent = var16
	local var18 = var4.MenuUIListLayout
	local var19 = var4.MenuGap
	local var20 = game:GetService("TweenService")
	local num1 = 0
	local var21 = require(script.Parent.Parent.Utility).createStagger(0.01, function(_)
		task.defer(function()
			local var3 = arg1.indicator
			local var6 = var3
			var6 = var6 and var3.Visible
			local var21 = var6
			if not var21 then
				var21 = var14.Text ~= ""
			end

			local bool1 = false
			if var16.Image ~= "" then
				bool1 = var16.Image ~= nil
			end

			local var22 = UDim2.fromScale(1, 1)
			if bool1 and (not var21) then
				var13.Visible = false
				var16.Visible = true
				var10.Visible = false
				var11.Visible = false
				var12.Visible = false
			elseif not bool1 and var21 then
				var13.Visible = true
				var16.Visible = false
				var10.Visible = true
				var11.Visible = false
				var12.Visible = true
			elseif bool1 and var21 then
				var13.Visible = true
				var16.Visible = true
				var10.Visible = true
				var11.Visible = not var6
				var12.Visible = not var6
			end

			var2.Size = var22
			local var23 = var9.Padding.Offset
			var13.Size = UDim2.new(0, var14.TextBounds.X, var14.Size.Y.Scale, 0)
			local var24 = var23
			for k1, v1 in pairs(var8:GetChildren()) do
				if not v1:IsA("GuiObject") then
					continue
				end

				if v1.Visible ~= true then
					continue
				end

				local var25 = v1:GetAttribute("TargetWidth")
				var24 = var24 + ((var25 or v1.AbsoluteSize.X) + var23)
			end

			local var26 = var1:GetAttribute("MinimumWidth")
			local var27 = 0 < (#arg1.menuIcons)
			var27 = var27 and arg1.isSelected
			local var28 = var1:GetAttribute("MinimumHeight")
			local var29 = var1:GetAttribute("BorderSize")
			local var30 = math.clamp(var24, var26, var15)
			local num2 = 0
			if var27 then
				for k2, v2 in pairs(var4:GetChildren()) do
					if v2 == var5 then
						continue
					end

					if not v2:IsA("GuiObject") then
						continue
					end

					if not v2.Visible then
						continue
					end

					local var31 = v2:GetAttribute("TargetWidth")
					num2 = num2 + ((var31 or v2.AbsoluteSize.X) + var18.Padding.Offset)
				end

				if not var5.Visible then
					local var34 = var5
					local var35 = var34:GetAttribute("TargetWidth")
					var35 = var35 or var34.AbsoluteSize.X
					var30 = var30 - (var35 + var18.Padding.Offset * 2 + var29)
				end

				num2 = num2 - var29 * 0.5
				var30 = var30 + (num2 - var29 * 0.75)
			end

			local var36 = var27
			var19.Visible = var36 and var5.Visible
			local var38 = var1:GetAttribute("DesiredWidth")
			if var38 and var30 < var38 then
				var30 = var38
			end

			arg1.updateMenu:Fire()
			local var39 = var4:GetAttribute("MenuWidth")
			local var40 = var39
			local var41 = math.max(var30 - num2, var26) - var29 * 2
			var40 = var40 and var39 + var41 + var18.Padding.Offset + 10
			if var40 then
				local var43 = var4:GetAttribute("MaxWidth")
				if var43 then
					var40 = math.max(var43, var26)
				end

				var4:SetAttribute("MenuCanvasWidth", var30)
				if var40 < var30 then
					var30 = var40
				end
			end

			local var44 = var5
			local var45 = var44:GetAttribute("TargetWidth")
			var45 = var45 or var44.AbsoluteSize.X
			local var46 = var1
			var44 = var46:GetAttribute("TargetWidth")
			var44 = var44 or var46.AbsoluteSize.X
			local var47 = math.max(var41, var45, var5.AbsoluteSize.X)
			local var48 = math.max(var30, var44, var1.AbsoluteSize.X)
			local var49 = Enum.EasingStyle.Quint
			local var50 = Enum.EasingDirection.Out
			var45 = TweenInfo.new(var47 / 750, var49, var50)
			var44 = TweenInfo.new(var48 / 750, var49, var50)
			local tbl1 = { Position = UDim2.new(0, var29, 0.5, 0) }
			tbl1.Size = UDim2.new(0, var41, 1, -var29 * 2)
			var20:Create(var5, var45, tbl1):Play()
			var20:Create(var7, var45, { Size = UDim2.new(0, var41, 1, 0) }):Play()
			var46 = UDim2.fromOffset(var30, var28)
			if var1.Size.Y.Offset ~= var28 then
				var1.Size = var46
			end

			var1:SetAttribute("TargetWidth", var46.X.Offset)
			var20:Create(var1, var44, { Size = var46 }):Play()
			local var51 = num1 + 1
			num1 = var51
			for i1 = 1, var44.Time * 100 do
				task.delay(i1 / 100, function()
					arg2.iconChanged:Fire(arg1)
				end)

			end

			task.delay(var44.Time - 0.2, function()
				local var1 = num1 - 1
				num1 = var1
				task.defer(function()
					if num1 == 0 then
						arg1.resizingComplete:Fire()
					end
				end)
			end)

			arg1:updateParent()
		end)
	end)

	arg1:setBehaviour("IconLabel", "Text", var21)
	local bool1 = true
	arg1:setBehaviour("IconLabel", "FontFace", function(arg1)
		if var14.FontFace == arg1 then
			return
		end

		task.spawn(function()
			var21()
			if bool1 then
				bool1 = false
				for i1 = 1, 10 do
					task.wait(1)
					var21()
				end
			end
		end)
	end)

	local function updateBorderSize()
		task.defer(function()
			local var2 = var1:GetAttribute("BorderSize")
			local var3 = arg1.alignment
			local var6
			if var5.Visible == false then
				var6 = 0
			elseif var3 == "Right" then
				var6 = -var2
				var6 = var6 or var2
			end

			var4.Position = UDim2.new(0, var6, 0, 0)
			var19.Size = UDim2.fromOffset(var2, 0)
			var18.Padding = UDim.new(0, 0)
			var21()
		end)
	end

	arg1:setBehaviour("Widget", "BorderSize", updateBorderSize)
	arg1:setBehaviour("IconSpot", "Visible", updateBorderSize)
	arg1.startMenuUpdate:Connect(var21)
	arg1.updateSize:Connect(var21)
	arg1:setBehaviour("ContentsList", "HorizontalAlignment", var21)
	arg1:setBehaviour("Widget", "Visible", var21)
	arg1:setBehaviour("Widget", "DesiredWidth", var21)
	arg1:setBehaviour("Widget", "MinimumWidth", var21)
	arg1:setBehaviour("Widget", "MinimumHeight", var21)
	arg1:setBehaviour("Indicator", "Visible", var21)
	arg1:setBehaviour("IconImageRatio", "AspectRatio", var21)
	arg1:setBehaviour("IconImage", "Image", function(arg1)
		local var2 = tonumber(arg1) and "http://www.roblox.com/asset/?id=" .. arg1 or (arg1 or "")
		if var16.Image ~= var2 then
			var21()
		end

		return var2
	end)

	arg1.alignmentChanged:Connect(function(arg1)
		if arg1 == "Center" then
			arg1 = "Left"
		end

		var18.HorizontalAlignment = Enum.HorizontalAlignment[arg1]
		task.defer(function()
			local var2 = var1:GetAttribute("BorderSize")
			local var3 = arg1.alignment
			local var6
			if var5.Visible == false then
				var6 = 0
			elseif var3 == "Right" then
				var6 = -var2
				var6 = var6 or var2
			end

			var4.Position = UDim2.new(0, var6, 0, 0)
			var19.Size = UDim2.fromOffset(var2, 0)
			var18.Padding = UDim.new(0, 0)
			var21()
		end)
	end)

	local var22 = Instance.new("NumberValue")
	var22.Name = "IconImageScale"
	var22.Parent = var16
	var22:GetPropertyChangedSignal("Value"):Connect(function()
		var16.Size = UDim2.new(var22.Value, 0, var22.Value, 0)
	end)

	local var23 = Instance.new("UIAspectRatioConstraint")
	var23.Name = "IconImageRatio"
	var23.AspectType = Enum.AspectType.FitWithinMaxSize
	var23.DominantAxis = Enum.DominantAxis.Height
	var23.Parent = var16
	local var24 = Instance.new("UIGradient")
	var24.Name = "IconGradient"
	var24.Enabled = true
	var24.Parent = var2
	local var25 = Instance.new("UIGradient")
	var25.Name = "IconSpotGradient"
	var25.Enabled = true
	var25.Parent = var5
	return var1
end

--- ReplicatedStorage.TopbarPlus.Icon.Elements.Notice [ModuleScript]
-- y u r i

return function(arg1, arg2)
	local var1 = Instance.new("Frame")
	var1.Name = "Notice"
	var1.ZIndex = 25
	var1.AutomaticSize = Enum.AutomaticSize.X
	var1.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var1.BorderSizePixel = 0
	var1.BackgroundTransparency = 0.1
	var1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	var1.Visible = false
	var1.Parent = arg1.widget
	local var2 = Instance.new("UICorner")
	var2.CornerRadius = UDim.new(1, 0)
	var2.Parent = var1
	Instance.new("UIStroke").Parent = var1
	local var3 = Instance.new("TextLabel")
	var3.Name = "NoticeLabel"
	var3.ZIndex = 26
	var3.AnchorPoint = Vector2.new(0.5, 0.5)
	var3.AutomaticSize = Enum.AutomaticSize.X
	var3.Size = UDim2.new(1, 0, 1, 0)
	var3.BackgroundTransparency = 1
	var3.Position = UDim2.new(0.5, 0, 0.515, 0)
	var3.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	var3.FontSize = Enum.FontSize.Size14
	var3.TextColor3 = Color3.fromRGB(0, 0, 0)
	var3.Text = "1"
	var3.TextWrapped = true
	var3.TextWrap = true
	var3.Font = Enum.Font.Arial
	var3.Parent = var1
	local var4 = script.Parent.Parent
	local var5 = var4.Packages
	local var6 = require(var4.Utility)
	arg1.noticeChanged:Connect(function(arg1)
		if not arg1 then
			return
		end

		local var4 = 99 < arg1
		var3.Text = if var4 then "99+" else arg1
		if var4 then
			var3.TextSize = 11
		end

		local bool2 = true
		if arg1 < 1 then
			bool2 = false
		end

		local var5 = arg2.getIconByUID(arg1.parentIconUID)
		local bool3 = true
		if 0 >= (#arg1.dropdownIcons) then
			bool3 = 0 < (#arg1.menuIcons)
		end

		if arg1.isSelected and bool3 then
			bool2 = false
		else
			if var5 and (not var5.isSelected) then
				bool2 = false
			end
		end

		var6.setVisible(var1, bool2, "NoticeHandler")
	end)

	local var7 = require(var5.Janitor)
	local var8 = require(var5.GoodSignal)
	arg1.noticeStarted:Connect(function(arg1, arg2)
		local var2 = arg2.getIconByUID(arg1.parentIconUID)
		arg1 = arg1 or arg1.deselected
		if var2 then
			var2:notify(arg1)
		end

		local var3 = arg1.janitor:add(var7.new())
		local var4 = var3:add(var8.new())
		local function fn2()
			var4:Fire()
		end

		var3:add(arg1.endNotices:Connect(fn2))
		fn2 = function()
			var4:Fire()
		end

		var3:add(arg1:Connect(fn2))
		local var5 = arg2
		arg2 = var5 or var6.generateUID()
		arg1.notices[arg2] = { completeSignal = var4, clearNoticeEvent = arg1 }
		arg1:getInstance("NoticeLabel")
		arg1.notified:Fire(arg2)
		local var9 = arg1
		local var10 = var9.totalNotices + 1
		var9.totalNotices = var10
		arg1.noticeChanged:Fire(arg1.totalNotices)
		var4:Once(function()
			var3:destroy()
			local var1 = arg1
			local var2 = var1.totalNotices - 1
			var1.totalNotices = var2
			arg1.notices[arg2] = nil
			arg1.noticeChanged:Fire(arg1.totalNotices)
		end)
	end)

	var1:SetAttribute("ClipToJoinedParent", true)
	arg1:clipOutside(var1)
	return var1
end

--- ReplicatedStorage.TopbarPlus.Icon.Features.Gamepad [ModuleScript]
-- y u r i

local var1 = nil
local var2 = game:GetService("GuiService")
local var3 = game:GetService("UserInputService")
local tbl1 = {}
local var4 = game:GetService("GamepadService")
tbl1.start = function(arg1)
	var1 = arg1
	var1.highlightKey = Enum.KeyCode.DPadUp
	var1.highlightIcon = false
	task.delay(1, function()
		local var5 = var1.iconsDictionary
		require(script.Parent.Parent.Utility)
		local var6 = require(script.Parent.Parent.Elements.Selection)
		local var7 = nil
		local bool1 = false
		local bool2 = false
		local function updateSelectedObject()
			local var4 = var2.SelectedObject
			local var8 = var4
			var8 = var8 and var4:GetAttribute("CorrespondingIconUID")
			local var9 = var8
			var9 = var9 and var5[var8]
			var4 = var3.GamepadEnabled
			if var9 then
				if var4 then
					local var16 = var9.selection
					var8 = var9:getInstance("ClickRegion")
					if not var16 then
						local var17 = var1
						var16 = var9.janitor:add(var6(var17))
						var16:SetAttribute("IgnoreVisibilityUpdater", true)
						var16.Parent = var9.widget
						var9.selection = var16
						var9:refreshAppearance(var16)
					end

					var8.SelectionImageObject = var16.Selection
				end

				if var7 and var7 ~= var9 then
					var7:setIndicator()
				end

				var7 = var9
				var1.lastHighlightedIcon = var9
				var9:setIndicator(if var4 and (not bool1 and (not var9.parentIconUID)) then Enum.KeyCode.ButtonB else nil)
				return
			end

			var8 = if var4 and (not bool2) then var1.highlightKey else nil
			if not var7 then
				var7 = tbl1.getIconToHighlight()
			end

			if var8 == var1.highlightKey then
				bool2 = true
			end

			if var7 then
				var7:setIndicator(var8)
			end
		end

		var2:GetPropertyChangedSignal("SelectedObject"):Connect(updateSelectedObject)
		var3:GetPropertyChangedSignal("GamepadEnabled"):Connect(function()
			if not var3.GamepadEnabled then
				bool2 = false
				bool1 = false
			end

			updateSelectedObject()
		end)

		if not var3.GamepadEnabled then
		end

		updateSelectedObject()
		var3.InputBegan:Connect(function(arg1, _)
			if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
				local var8 = var2.SelectedObject
				local var9 = var8
				var9 = var9 and var8:GetAttribute("CorrespondingIconUID")
				local var10 = var9
				if var10 and var5[var9] then
					var2.SelectedObject = nil
				end

				return
			end

			if arg1.KeyCode ~= var1.highlightKey then
				return
			end

			local var12 = tbl1.getIconToHighlight()
			if var12 then
				if var4.GamepadCursorEnabled then
					task.wait(0.2)
					var4:DisableGamepadCursor()
				end

				local var13 = var12:getInstance("ClickRegion")
				var2.SelectedObject = var13
			end
		end)
	end)
end

tbl1.getIconToHighlight = function()
	local var2 = var1.highlightIcon
	var2 = var2 or var1.lastHighlightedIcon
	local var3 = var1.iconsDictionary
	if not var2 then
		local var4 = nil
		for k1, v1 in pairs(var3) do
			if v1.parentIconUID then
				continue
			end

			if not var4 or v1.widget.AbsolutePosition.X < var4 then
				var2 = v1
			end

			local var5 = var2.widget.AbsolutePosition.X
		end
	end

	return var2
end

tbl1.registerButton = function(arg1)
	local bool1 = false
	arg1.InputBegan:Connect(function(_)
		bool1 = true
		task.wait()
		task.wait()
		bool1 = false
	end)

	local var1 = var3.InputBegan:Connect(function(arg1)
		task.wait()
		if arg1.KeyCode == Enum.KeyCode.ButtonA and bool1 then
			task.wait(0.2)
			var4:DisableGamepadCursor()
			var2.SelectedObject = arg1
			return
		end

		local var1 = arg1.KeyCode.Name
		if table.find({ "ButtonB", "ButtonSelect" }, var1) and (var2.SelectedObject == arg1 and (var1 ~= "ButtonSelect" or var4.GamepadCursorEnabled)) then
			var2.SelectedObject = nil
		end
	end)

	arg1.Destroying:Once(function()
		var1:Disconnect()
	end)
end

return tbl1

--- ReplicatedStorage.TopbarPlus.Icon.Features.Overflow [ModuleScript]
-- y u r i

local var1 = nil
local var2 = nil
local tbl1 = {}
local var3 = require(script.Parent.Parent.Utility)
local tbl2 = {}
local var4 = workspace.CurrentCamera
tbl2.start = function(arg1)
	var1 = arg1
	var2 = var1.iconsDictionary
	local var5 = nil
	for k1, v1 in pairs(var1.container) do
		if var5 == nil and v1.ScreenInsets == Enum.ScreenInsets.TopbarSafeInsets then
			var5 = v1
		end

		for k2, v2 in pairs(v1.Holders:GetChildren()) do
			if not v2:GetAttribute("IsAHolder") then
				continue
			end

			tbl1[v2.Name] = v2
		end
	end

	local bool1 = false
	local var6 = var3.createStagger(0.1, function(arg1)
		if not bool1 then
			return
		end

		if not arg1 then
			tbl2.updateAvailableIcons("Center")
		end

		tbl2.updateBoundary("Left")
		tbl2.updateBoundary("Right")
	end)

	task.delay(1, function()
		bool1 = true
		var6()
	end)

	var1.iconAdded:Connect(var6)
	var1.iconRemoved:Connect(var6)
	var1.iconChanged:Connect(var6)
	var4:GetPropertyChangedSignal("ViewportSize"):Connect(function()
		var6(true)
	end)

	var5:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		var6(true)
	end)
end

tbl2.getWidth = function(arg1, _)
	local var1 = arg1.widget
	local var2 = var1:GetAttribute("TargetWidth")
	return var2 or var1.AbsoluteSize.X
end

local tbl3 = {}
tbl2.getAvailableIcons = function(arg1)
	local var1 = tbl3[arg1]
	return var1 or tbl2.updateAvailableIcons(arg1)
end

local tbl4 = {}
tbl2.updateAvailableIcons = function(arg1)
	local num1 = 0
	local tbl2 = {}
	for k1, v1 in pairs(var2) do
		local var1 = v1.parentIconUID
		local var3 = not var1
		if not (var3 or tbl4[var1]) then
			continue
		end

		if v1.alignment ~= arg1 or tbl4[v1.UID] then
			continue
		end

		table.insert(tbl2, v1)
		num1 = num1 + 1
	end

	if num1 <= 0 then
		return {}
	end

	table.sort(tbl2, function(arg1, arg2)
		local var5 = arg1.parentIconUID
		local var6 = arg2.parentIconUID
		local var7 = arg1.widget.LayoutOrder
		local var8 = arg2.widget.LayoutOrder
		if var5 == var6 then
			if var7 < var8 then
				return true
			end

			if var8 < var7 then
				return false
			end

			return arg1.widget.AbsolutePosition.X < arg2.widget.AbsolutePosition.X
		end

		if var6 then
			return false
		end

		if var5 then
			return true
		end
	end)

	tbl3[arg1] = tbl2
	return tbl2
end

tbl2.getRealXPositions = function(arg1, arg2)
	local var1 = tbl1[arg1]
	local var2 = arg1 == "Left"
	local var4 = var1.AbsolutePosition.X
	local var5 = var1.UIListLayout.Padding.Offset
	local var6 = var2 and var4 or var4 + var1.AbsoluteSize.X
	local tbl3 = {}
	if var2 then
		var3.reverseTable(arg2)
	end

	for i1 = #arg2, 1, -1 do
		local var7 = arg2[i1]
		local var8 = tbl2.getWidth(var7)
		var6 = var2 or var6 - var8
		tbl3[var7.UID] = var6
		var6 = (var2 and var6 + var8) + (var2 and var5 or (-var5))
	end

	return tbl3
end

local tbl5 = {}
tbl2.updateBoundary = function(arg1)
	local var2 = tbl1[arg1]
	local var4 = var2.UIListLayout
	local var5 = tbl2.updateAvailableIcons(arg1)
	local var6 = var2.AbsolutePosition.X
	local var7 = var2.AbsoluteSize.X
	local var8 = var4.Padding.Offset
	local var9 = var4.Padding.Offset
	local num1 = 0
	local num2 = 0
	for k1, v1 in pairs(var5) do
		num1 = num1 + (tbl2.getWidth(v1) + var9)
		num2 = num2 + 1
	end

	if num2 <= 0 then
		return
	end

	local var10 = arg1 == "Left"
	local var12 = tbl5[arg1]
	local var13 = not var10
	if not var12 then
		if not (arg1 == "Central") then
			if 0 < (#var5) then
				var12 = var1.new()
				var12:setImage(6069276526, "Deselected")
				var12:setName("Overflow" .. arg1)
				var12:setOrder(if var10 then -9999999 else 9999999)
				var12:setAlignment(arg1)
				var12:autoDeselect(false)
				var12.isAnOverflow = true
				var12:select("OverflowStart", var12)
				var12:setEnabled(false)
				tbl5[arg1] = var12
				tbl4[var12.UID] = true
			end
		end
	end

	local var14 = if arg1 == "Left" then "Right" else "Left"
	local var15 = tbl2.updateAvailableIcons(var14)
	local var17 = var10 and var15[1] or var13 and var15[#var15]
	local var18 = tbl5[var14]
	local var19 = var10 and var6 + var7 or var6
	if var17 then
		local var20 = tbl2.getRealXPositions(var14, var15)[var17.UID]
		var19 = var10 and var20 - var8 or var20 + tbl2.getWidth(var17) + var8
		local var21 = var17.widget
	end

	local var22 = tbl2.getAvailableIcons("Center")
	local var25 = var22[if var10 then 1 else #var22]
	if var25 then
		if not var25.hasRelocatedInOverflow then
			local var27 = var10 and var5[#var5] or var13 and var5[1]
			local var28 = var25.widget.AbsolutePosition.X
			local var29 = var27.widget.AbsolutePosition.X
			local var32 = var10 and var28 - var8 or var28 + tbl2.getWidth(var25) + var8
			local var33 = var10 and var29 + tbl2.getWidth(var27) or var29
			if var10 then
				if var32 < var33 then
					var25:align("Left")
					var25.hasRelocatedInOverflow = true
				end
			elseif var13 and var33 < var32 then
				var25:align("Right")
				var25.hasRelocatedInOverflow = true
			end
		end
	end

	if var12 then
		local var35 = var12:getInstance("Menu")
		local var36 = var19
		local var37 = var6 + var7
		local var38 = var7
		if var35 then
			if var18 then
				local var39 = var18.widget.AbsolutePosition.X
				local var40 = var6 + var7 / 2
				var36 = var10 and var40 - var8 / 2 or var40 + var8 / 2
				local var41 = var10 and var39 - var8 or var39 + tbl2.getWidth(var18) + var8
				if var18:getInstance("Menu").AbsoluteCanvasSize.X <= var35.AbsoluteCanvasSize.X then
					var36 = var41
				end

				var38 = var10 and var36 - var6 or var37 - var36
			end
		end

		local var42 = var35
		var38 = var3.round(var38)
		if var35 and (var42 and var35:GetAttribute("MaxWidth")) ~= var38 then
			var35:SetAttribute("MaxWidth", var38)
		end
	end

	local bool1 = false
	local var43 = tbl2.getRealXPositions(arg1, var5)
	for i1 = #var5, 1, -1 do
		local var44 = var5[i1]
		local var46 = var43[var44.UID]
		if var10 and var19 <= var46 + tbl2.getWidth(var44) or var13 and var46 <= var19 then
			bool1 = true
		end
	end

	for i2 = #var5, 1, -1 do
		local var47 = var5[i2]
		if tbl4[var47.UID] then
			continue
		end

		if bool1 and (not var47.parentIconUID) then
			var47:joinMenu(var12)
		else
			if bool1 then
				continue
			end

			if not var47.parentIconUID then
				continue
			end

			var47:leave()
		end
	end

	if var12.isEnabled ~= bool1 then
		var12:setEnabled(bool1)
	end

	if var12.isEnabled and (not var12.overflowAlreadyOpened) then
		var12.overflowAlreadyOpened = true
		var12:select()
	end
end

return tbl2

--- ReplicatedStorage.TopbarPlus.Icon.Features.Themes [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Utility)
local var2 = require(script.Default)
local tbl1 = {
	getThemeValue = function(arg1, arg2, arg3, _)
		if arg1 then
			for k1, v1 in pairs(arg1) do
				local var1, var2, var3 = unpack(v1)
				if arg2 ~= var1 or arg3 ~= var2 then
					continue
				end

				return var3
			end
		end
	end,
	getInstanceValue = function(arg1, arg2)
		local success, result = pcall(function()
			return arg1[arg2]
		end)

		if not success then
			result = arg1:GetAttribute(arg2)
		end

		return result
	end,
	getRealInstance = function(arg1)
		if not arg1:GetAttribute("IsAClippedClone") then
			return
		end

		local var2 = arg1:FindFirstChild("OriginalInstance")
		if not var2 then
			return
		end

		return var2.Value
	end,
	getClippedClone = function(arg1)
		if not arg1:GetAttribute("HasAClippedClone") then
			return
		end

		local var2 = arg1:FindFirstChild("ClippedClone")
		if not var2 then
			return
		end

		return var2.Value
	end,
}

tbl1.refresh = function(arg1, arg2, arg3)
	if arg3 then
		local var1 = tbl1.getThemeValue(arg1:getStateGroup(), arg2.Name, arg3)
		tbl1.apply(arg1, arg2, arg3, var1 or tbl1.getInstanceValue(arg2, arg3), true)
		return
	end

	local var3 = arg1:getStateGroup()
	if not var3 then
		return
	end

	local tbl2 = { [arg2.Name] = arg2 }
	for k1, v1 in pairs(arg2:GetDescendants()) do
		local var5 = v1:GetAttribute("Collective")
		if var5 then
			tbl2[var5] = v1
		end

		tbl2[v1.Name] = v1
	end

	for k2, v2 in pairs(var3) do
		local var6, var7, var8 = unpack(v2)
		local var9 = tbl2[var6]
		if not var9 then
			continue
		end

		tbl1.apply(arg1, var9.Name, var7, var8, true)
	end
end

tbl1.apply = function(arg1, arg2, arg3, arg4, arg5)
	if arg1.isDestroyed then
		return
	end

	local var1 = nil
	local var2 = arg2
	if typeof(arg2) == "Instance" then
		var1 = { arg2 }
		var2 = arg2.Name
	else
		var1 = arg1:getInstanceOrCollective(arg2)
	end

	local var3 = arg1.customBehaviours[var2 .. "-" .. arg3]
	for k1, v1 in pairs(var1) do
		local var4 = tbl1.getClippedClone(v1)
		if not var4 then
			continue
		end

		table.insert(var1, var4)
	end

	for k2, v2 in pairs(var1) do
		if arg3 == "Position" and tbl1.getClippedClone(v2) then
		elseif arg3 == "Size" then
			if tbl1.getRealInstance(v2) then
				continue
			end
		end
	end
end

tbl1.getModifications = function(arg1)
	if typeof(arg1[1]) ~= "table" then
		arg1 = { arg1 }
	end

	return arg1
end

tbl1.merge = function(arg1, arg2, arg3)
	local var9, var10, var11, var12 = table.unpack(arg2)
	local var13, var14, var15, var16 = table.unpack(arg1)
	if var9 == var13 and (var10 == var14 and tbl1.statesMatch(var12, var16)) then
		arg1[3] = var11
		if arg3 then
			arg3(arg1)
		end

		return true
	end

	return false
end

tbl1.modify = function(arg1, arg2, arg3)
	task.spawn(function()
		local var2 = arg3
		var2 = var2 or var1.generateUID()
		arg3 = var2
		var2 = tbl1.getModifications(arg2)
		arg2 = var2
		for k1, v1 in pairs(arg2) do
			local var7, var8, var9, var10 = table.unpack(v1)
			if var10 == nil then
				tbl1.modify(arg1, { var7, var8, var9, "Selected" }, arg3)
				tbl1.modify(arg1, { var7, var8, var9, "Viewing" }, arg3)
			end

			local var11 = var1.formatStateName(var10 or "Deselected")
			local var12 = arg1:getStateGroup(var11);
			(function()
				for k1, v2 in pairs(var12) do
					if not tbl1.merge(v2, v1, function(arg1)
						arg1[5] = arg3
						if var11 == arg1.activeState then
							tbl1.apply(arg1, var7, var8, var9)
						end
					end) then

						continue
					end

					return
				end

				table.insert(var12, { var7, var8, var9, var11, arg3 })
				if var11 == arg1.activeState then
					tbl1.apply(arg1, var7, var8, var9)
				end
			end)()

		end
	end)

	return arg3
end

tbl1.remove = function(arg1, arg2)
	for k1, v1 in pairs(arg1.appearance) do
		for i1 = #v1, 1, -1 do
			if v1[i1][5] ~= arg2 then
				continue
			end

			table.remove(v1, i1)
		end
	end

	tbl1.rebuild(arg1)
end

tbl1.removeWith = function(arg1, arg2, arg3, arg4)
	for k1, v1 in pairs(arg1.appearance) do
		if arg4 == k1 or (not arg4) then
			for i1 = #v1, 1, -1 do
				local var1 = v1[i1]
				if var1[1] ~= arg2 or var1[2] ~= arg3 then
					continue
				end

				table.remove(v1, i1)
			end
		end
	end

	tbl1.rebuild(arg1)
end

tbl1.change = function(arg1)
	for k1, v1 in pairs((arg1:getStateGroup())) do
		local var1, var2, var3 = unpack(v1)
		tbl1.apply(arg1, var1, var2, var3)
	end
end

tbl1.set = function(arg1, arg2)
	local var1 = arg1.themesJanitor
	var1:clean()
	local function fn2()
		tbl1.change(arg1)
	end

	var1:add(arg1.stateChanged:Connect(fn2))
	if typeof(arg2) == "Instance" and arg2:IsA("ModuleScript") then
		arg2 = require(arg2)
	end

	arg1.appliedTheme = arg2
	tbl1.rebuild(arg1)
end

tbl1.statesMatch = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	local bool2 = true
	if (var1 and string.lower(arg1)) ~= (var2 and string.lower(arg2)) then
		bool2 = not arg1
		bool2 = bool2 or (not arg2)
	end

	return bool2
end

tbl1.rebuild = function(arg1)
	local tbl2 = { "Deselected", "Selected", "Viewing" }
	local var3 = arg1.appliedTheme;
	(function()
		for k1, v1 in pairs(tbl2) do
			local tbl3 = {}
			local function updateDetails(arg1, arg2)
				if not arg1 then
					return
				end

				for k1, v1 in pairs(arg1) do
					if not tbl1.statesMatch(arg2, v1[4]) then
						continue
					end

					local var2 = var1.copyTable(v1)
					var2[5] = v1[5]
					tbl3[v1[1] .. "-" .. v1[2]] = var2
				end
			end

			if v1 == "Selected" then
				updateDetails(var2, "Deselected")
			end

			updateDetails(var2, "Empty")
			updateDetails(var2, v1)
			if var3 ~= var2 then
				if v1 == "Selected" then
					updateDetails(var3, "Deselected")
				end

				updateDetails(var2, "Empty")
				updateDetails(var3, v1)
			end

			local var5 = arg1.appearance[v1]
			local tbl4 = {}
			local var6
			if var5 then
				for k2, v2 in pairs(var5) do
					var6 = v2[5]
					if var6 == nil then
						continue
					end

					table.insert(tbl4, { v2[1], v2[2], v2[3], v1, var6 })
				end
			end

			updateDetails(tbl4, v1)
			local tbl5 = {}
			for k3, v3 in pairs(tbl3) do
				table.insert(tbl5, v3)
			end

			arg1.appearance[v1] = tbl5
		end

		tbl1.change(arg1)
	end)()
end

return tbl1

--- ReplicatedStorage.TopbarPlus.Icon.Features.Themes.Classic [ModuleScript]
-- y u r i

local num1 = 1
local num2 = -6
local num3 = 1
local num4 = -5
num2 = 0
num3 = 3
num4 = 0
local num5 = 3
return {
	{ "Selection", "Size", UDim2.new(num1, num2, num3, num4) },
	{ "Selection", "Position", UDim2.new(num2, num3, num4, num5) },
	{ "Widget", "MinimumWidth", 32, "Deselected" },
	{ "Widget", "MinimumHeight", 32, "Deselected" },
	{ "Widget", "BorderSize", 0, "Deselected" },
	{ "IconCorners", "CornerRadius", UDim.new(0, 9), "Deselected" },
	{ "IconButton", "BackgroundTransparency", 0.5, "Deselected" },
	{ "IconLabel", "TextSize", 14, "Deselected" },
	{ "Dropdown", "BackgroundTransparency", 0.5, "Deselected" },
	{ "Notice", "Position", UDim2.new(1, -12, 0, -3), "Deselected" },
	{ "Notice", "Size", UDim2.new(0, 15, 0, 15), "Deselected" },
	{ "NoticeLabel", "TextSize", 11, "Deselected" },
	{ "IconSpot", "BackgroundColor3", Color3.fromRGB(0, 0, 0), "Selected" },
	{ "IconSpot", "BackgroundTransparency", 0.702, "Selected" },
	{ "IconSpotGradient", "Enabled", false, "Selected" },
	{ "IconOverlay", "BackgroundTransparency", 0.97, "Selected" },
}

--- ReplicatedStorage.TopbarPlus.Icon.Features.Themes.Default [ModuleScript]
-- y u r i

local num1 = 1
local num2 = 0
local num3 = 1
local num4 = 0
local num5 = 1
local num6 = 1
num4 = 0
num5 = 0
num6 = 0
local num7 = 0
local num8 = 255
local num9 = 255
local num10 = 255
num6 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num8, num9, num10))
num9 = 86
num10 = 86
local num11 = 86
local num12 = 1
num5 = { num6, ColorSequenceKeypoint.new(num12, Color3.fromRGB(num9, num10, num11)) }
local num13 = 77
local num14 = 78
local num15 = 80
return {
	{ "IconCorners", "CornerRadius", UDim.new(num1, num2) },
	{ "Selection", "RotationSpeed", 1 },
	{ "Selection", "Size", UDim2.new(num3, num4, num5, num6) },
	{ "Selection", "Position", UDim2.new(num4, num5, num6, num7) },
	{ "SelectionGradient", "Color", ColorSequence.new(num5) },
	{ "IconImage", "Image", "", "Deselected" },
	{ "IconLabel", "Text", "", "Deselected" },
	{ "IconLabel", "Position", UDim2.fromOffset(0, 0), "Deselected" },
	{ "Widget", "MinimumWidth", 44, "Deselected" },
	{ "Widget", "MinimumHeight", 44, "Deselected" },
	{ "Widget", "BorderSize", 4, "Deselected" },
	{ "IconButton", "BackgroundColor3", Color3.fromRGB(0, 0, 0), "Deselected" },
	{ "IconButton", "BackgroundTransparency", 0.3, "Deselected" },
	{ "IconImageScale", "Value", 0.5, "Deselected" },
	{ "IconImageCorner", "CornerRadius", UDim.new(0, 0), "Deselected" },
	{ "IconImage", "ImageColor3", Color3.fromRGB(255, 255, 255), "Deselected" },
	{ "IconImage", "ImageTransparency", 0, "Deselected" },
	{
		"IconLabel",
		"FontFace",
		Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal),
		"Deselected",
	},
	{ "IconLabel", "TextSize", 16, "Deselected" },
	{ "IconSpot", "BackgroundTransparency", 1, "Deselected" },
	{ "IconOverlay", "BackgroundTransparency", 0.925, "Deselected" },
	{ "IconSpotGradient", "Enabled", false, "Deselected" },
	{ "IconGradient", "Enabled", false, "Deselected" },
	{ "ClickRegion", "Active", true, "Deselected" },
	{ "Menu", "Active", false, "Deselected" },
	{ "ContentsList", "HorizontalAlignment", Enum.HorizontalAlignment.Center, "Deselected" },
	{ "Dropdown", "BackgroundColor3", Color3.fromRGB(0, 0, 0), "Deselected" },
	{ "Dropdown", "BackgroundTransparency", 0.3, "Deselected" },
	{ "Dropdown", "MaxIcons", 4, "Deselected" },
	{ "Menu", "MaxIcons", 4, "Deselected" },
	{ "Notice", "Position", UDim2.new(1, -12, 0, -1), "Deselected" },
	{ "Notice", "Size", UDim2.new(0, 20, 0, 20), "Deselected" },
	{ "NoticeLabel", "TextSize", 13, "Deselected" },
	{ "PaddingLeft", "Size", UDim2.new(0, 9, 1, 0), "Deselected" },
	{ "PaddingRight", "Size", UDim2.new(0, 11, 1, 0), "Deselected" },
	{ "IconSpot", "BackgroundTransparency", 0.7, "Selected" },
	{ "IconSpot", "BackgroundColor3", Color3.fromRGB(255, 255, 255), "Selected" },
	{ "IconSpotGradient", "Enabled", true, "Selected" },
	{ "IconSpotGradient", "Rotation", 45, "Selected" },
	{
		"IconSpotGradient",
		"Color",
		ColorSequence.new(Color3.fromRGB(96, 98, 100), Color3.fromRGB(num13, num14, num15)),
		"Selected",
	},
}

--- ReplicatedStorage.TopbarPlus.Icon.Packages.GoodSignal [ModuleScript]
-- y u r i

local var1 = nil
local function acquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	return (setmetatable({ _connected = true, _signal = arg1, _fn = arg2, _next = false }, tbl1))
end

tbl1.Disconnect = function(arg1)
	arg1._connected = false
	if arg1._signal._handlerListHead == arg1 then
		arg1._signal._handlerListHead = arg1._next
		return
	end

	local var1 = arg1._signal._handlerListHead
	while var1 and var1._next ~= arg1 do
		var1 = var1._next
	end

	if var1 then
		var1._next = arg1._next
	end
end

tbl1.Destroy = tbl1.Disconnect
setmetatable(tbl1, {
	__index = function(_, arg2)
		error(("Attempt to get Connection::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
	__newindex = function(_, arg2, _)
		error(("Attempt to set Connection::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
})

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function()
	return (setmetatable({ _handlerListHead = false }, tbl2))
end

tbl2.Connect = function(arg1, arg2)
	local var1 = tbl1.new(arg1, arg2)
	if arg1._handlerListHead then
		var1._next = arg1._handlerListHead
		arg1._handlerListHead = var1
		return var1
	end

	arg1._handlerListHead = var1
	return var1
end

tbl2.DisconnectAll = function(arg1)
	arg1._handlerListHead = false
end

tbl2.Destroy = tbl2.DisconnectAll
local function runEventHandlerInFreeThread()
	while true do
		acquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl2.Fire = function(arg1, ...)
	local var2 = arg1._handlerListHead
	while var2 do
		if var2._connected then
			if not var1 then
				var1 = coroutine.create(runEventHandlerInFreeThread)
				coroutine.resume(var1)
			end

			task.spawn(var1, var2._fn, ...)
		end

		var2 = var2._next
	end
end

tbl2.Wait = function(arg1)
	local var1 = nil
	local var2 = coroutine.running()
	arg1:Connect(function(...)
		var1:Disconnect()
		task.spawn(var2, ...)
	end)

	return coroutine.yield()
end

tbl2.Once = function(arg1, arg2)
	local var1 = nil
	return (arg1:Connect(function(...)
		if var1._connected then
			var1:Disconnect()
		end

		arg2(...)
	end))
end

setmetatable(tbl2, {
	__index = function(_, arg2)
		error(("Attempt to get Signal::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
	__newindex = function(_, arg2, _)
		error(("Attempt to set Signal::%s (not a valid member)"):format((tostring(arg2))), 2)
	end,
})

return tbl2

--- ReplicatedStorage.TopbarPlus.Icon.Packages.Janitor [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = newproxy(true)
local var3 = getmetatable(var2)
var3.__tostring = function()
	return "IndicesReference"
end

var3 = newproxy(true)
local var4 = getmetatable(var3)
var4.__tostring = function()
	return "LinkToInstanceIndex"
end

var4 = {
	IGNORE_MEMORY_DEBUG = true,
	ClassName = "Janitor",
	__index = { CurrentlyCleaning = true, [var2] = nil },
}

var4.new = function()
	return (setmetatable({ CurrentlyCleaning = false, [var2] = nil }, var4))
end

var4.Is = function(arg1)
	local bool1 = false
	if type(arg1) == "table" then
		bool1 = getmetatable(arg1) == var4
	end

	return bool1
end

var4.is = var4.Is
local tbl1 = { ["function"] = true, Promise = "cancel", RBXScriptConnection = "Disconnect" }
var4.__index.Add = function(arg1, arg2, arg3, arg4)
	if arg4 then
		arg1:Remove(arg4)
		local var3 = arg1[var2]
		if not var3 then
			var3 = {}
			arg1[var2] = var3
		end

		var3[arg4] = arg2
	end

	local var5 = typeof(arg2)
	if var5 == "table" then
		if string.match(tostring(arg2), "Promise") then
			var5 = "Promise"
		end
	end

	local var6 = arg3
	arg3 = var6 or (tbl1[var5] or "Destroy")
	if type(arg2) ~= "function" and (not arg2[arg3]) then
		local var7 = nil
		local num1 = 2
		local str1 = "Object %s doesn't have method %s, are you sure you want to add it? Traceback: %s"
		local var8 = tostring(arg2)
		local var9 = tostring(arg3)
		warn(string.format(str1, var8, var9, debug.traceback(var7, num1)))
	end

	local tbl2 = { arg3, (debug.traceback("")) }
	arg1[arg2] = tbl2
	return arg2
end

var4.__index.Give = var4.__index.Add
var4.__index.AddPromise = function(arg1, arg2)
	local var3 = if var1:IsRunning() then require(game:GetService("ReplicatedStorage").Framework).modules.Promise else nil
	if var3 then
		if not var3.is(arg2) then
			local str1 = "Invalid argument #1 to 'Janitor:AddPromise' (Promise expected, got %s (%s))"
			local var4 = typeof(arg2)
			local var5 = tostring(arg2)
			error(string.format(str1, var4, var5))
		end

		if arg2:getStatus() == var3.Status.Started then
			local var8 = newproxy(false)
			local var9 = arg1:Add(var3.new(function(arg1, _, arg3)
				if arg3(function()
					arg2:cancel()
				end) then

					return
				end

				arg1(arg2)
			end), "cancel", var8)

			var9:finallyCall(arg1.Remove, arg1, var8)
			return var9
		end

		return arg2
	end

	return arg2
end

var4.__index.GivePromise = var4.__index.AddPromise
var4.__index.AddObject = function(arg1, arg2)
	local var2 = newproxy(false)
	local var5 = if var1:IsRunning() then require(game:GetService("ReplicatedStorage").Framework).modules.Promise else nil
	if var5 then
		if var5.is(arg2) then
			if arg2:getStatus() == var5.Status.Started then
				local var8 = arg1:Add(var5.resolve(arg2), "cancel", var2)
				var8:finallyCall(arg1.Remove, arg1, var2)
				return var8, var2
			end

			return arg2
		end
	end

	return arg1:Add(arg2, false, var2), var2
end

var4.__index.GiveObject = var4.__index.AddObject
var4.__index.Remove = function(arg1, arg2)
	local var6 = arg1[var2]
	if var6 then
		local var10 = var6[arg2]
		if var10 then
			local var11 = arg1[var10]
			local var12 = var11
			var12 = var12 and var11[1]
			if var12 then
				if var12 == true then
					var10()
				else
					local var14 = var10[var12]
					if var14 then
						var14(var10)
					end
				end

				arg1[var10] = nil
			end

			var6[arg2] = nil
		end
	end

	return arg1
end

var4.__index.Get = function(arg1, arg2)
	local var3 = arg1[var2]
	if var3 then
		return var3[arg2]
	end
end

var4.__index.Cleanup = function(arg1)
	if not arg1.CurrentlyCleaning then
		arg1.CurrentlyCleaning = nil
		for k1, v1 in next, arg1 do
			if k1 == var2 then
				continue
			end

			local var3 = type(k1)
			if var3 == "string" or var3 == "number" then
				arg1[k1] = nil
			else
				local var4 = v1[2]
				local var6 = v1[1]
				if var6 == true then
					local success, result = pcall(k1)
					if not success then
						warn("-------- Janitor Error --------" .. [[
]] .. tostring(result) .. [[
]] .. debug.traceback("", 3) .. "" .. var4)

					end
				else
					local var8 = k1[var6]
					if var8 then
						local success, result = pcall(var8, k1)
						local bool1 = false
						if typeof(k1) == "Instance" then
							bool1 = var8 == "Destroy"
						end

						if not success and (not bool1) then
							warn("-------- Janitor Error --------" .. [[
]] .. tostring(result) .. [[
]] .. debug.traceback("", 3) .. "" .. var4)

						end
					end
				end

				arg1[k1] = nil
			end
		end

		local var10 = arg1[var2]
		if var10 then
			for k2 in next, var10 do
				var10[k2] = nil
			end

			arg1[var2] = {}
		end

		arg1.CurrentlyCleaning = false
	end
end

var4.__index.Clean = var4.__index.Cleanup
var4.__index.Destroy = function(arg1)
	arg1:Cleanup()
end

var4.__call = var4.__index.Cleanup
local tbl2 = { Connected = true }
tbl2.__index = tbl2
tbl2.Disconnect = function(arg1)
	if arg1.Connected then
		arg1.Connected = false
		arg1.Connection:Disconnect()
	end
end

tbl2.__tostring = function(arg1)
	return "Disconnect<" .. tostring(arg1.Connected) .. ">"
end

local var5 = var1.Heartbeat
var4.__index.LinkToInstance = function(arg1, arg2, arg3)
	local var1 = setmetatable({}, tbl2)
	local var2 = arg2.Parent == nil
	local var4 = nil
	local var6 = arg3 and newproxy(false) or var3
	var4 = arg2.AncestryChanged:Connect(function(_, arg2)
		if var1.Connected then
			var2 = arg2 == nil
			if var2 then
				coroutine.wrap(function()
					var5:Wait()
					if not var1.Connected then
						return
					end

					if not var4.Connected then
						arg1:Cleanup()
						return
					end

					while var2 and var4.Connected and var1.Connected do
						var5:Wait()
					end

					if var1.Connected and var2 then
						arg1:Cleanup()
					end
				end)()

			end
		end
	end)

	var1.Connection = var4
	if var2 then
		local var7 = nil
		local var8 = arg2.Parent
		if var1.Connected then
			var2 = var8 == nil
			var7 = nil
			if var2 then
				coroutine.wrap(function()
					var5:Wait()
					if not var1.Connected then
						return
					end

					if not var4.Connected then
						arg1:Cleanup()
						return
					end

					while var2 and var4.Connected and var1.Connected do
						var5:Wait()
					end

					if var1.Connected and var2 then
						arg1:Cleanup()
					end
				end)()

			end
		end
	end

	local var9 = var1
	local str1 = "Disconnect"
	local var10 = var6
	return arg1:Add(var9, str1, var10)
end

var4.__index.LinkToInstances = function(arg1, ...)
	local var1 = var4.new()
	for k1, v1 in ipairs({ ... }) do
		var1:Add(arg1:LinkToInstance(v1, true), "Disconnect")
	end

	return var1
end

for k1, v1 in next, var4.__index do
	local var6 = string.sub(string.lower(k1), 1, 1) .. string.sub(k1, 2)
	var4.__index[var6] = v1
end

return var4

--- ReplicatedStorage.TopbarPlus.READ_ME [Script]
-- y u r i

game:GetService("TweenService")
game:GetService("Lighting")
game:GetService("Players")
local var1 = require(script.Parent.Icon)
local var2 = shared.Modules.TweenButtons
var1.new():setLabel(""):setImage(125105418064117, "Deselected"):setImage(125105418064117, "Selected"):oneClick():bindEvent("selected", function()
	if workspace:FindFirstChild("LoadingScreenMenu") then
		return
	end

	var2.OnButtonClick("Settings")
end)

var1.new():setLabel("Update Log"):setImage(87806302466204, "Deselected"):setImage(87806302466204, "Selected"):oneClick():bindEvent("selected", function()
	if workspace:FindFirstChild("LoadingScreenMenu") then
		return
	end

	var2.OnButtonClick("UpdateLog")
end)

--- ReplicatedStorage.ReplicaShared.Maid [ModuleScript]
-- y u r i

local var1 = nil
local function AcquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local function RunEventHandlerInFreeThread(...)
	AcquireRunnerThreadAndCallEventHandler(...)
	while true do
		AcquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

local function Cleanup(arg1, ...)
	local var2 = typeof(arg1)
	if var2 == "function" then
		arg1(...)
		return
	end

	if var2 == "RBXScriptConnection" then
		arg1:Disconnect()
		return
	end

	if var2 == "Instance" then
		arg1:Destroy()
		return
	end

	if var2 == "table" then
		if type(arg1.Destroy) == "function" then
			arg1:Destroy()
			return
		end

		if type(arg1.Disconnect) == "function" then
			arg1:Disconnect()
		end
	end
end

local tbl1 = {}
tbl1.__index = tbl1
tbl1.New = function(arg1, arg2)
	local tbl2 = { maid = arg1, object = arg2 }
	setmetatable(tbl2, tbl1)
	return tbl2
end

tbl1.Destroy = function(arg1)
	arg1.maid.tokens[arg1] = nil
end

local function CleanupInThread(...)
	if not var1 then
		var1 = coroutine.create(RunEventHandlerInFreeThread)
	end

	task.spawn(assert(var1), Cleanup, ...)
end

tbl1.Cleanup = function(arg1, ...)
	if arg1.object == nil then
		return
	end

	arg1.maid.tokens[arg1] = nil
	CleanupInThread(arg1.object, ...)
	arg1.object = nil
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.New = function(arg1)
	local tbl1 = { tokens = {}, is_cleaned = false, key = arg1 }
	setmetatable(tbl1, tbl2)
	return tbl1
end

tbl2.IsActive = function(arg1)
	return not arg1.is_cleaned
end

tbl2.Add = function(arg1, arg2)
	if arg1.is_cleaned == true then
		CleanupInThread(arg2)
	end

	local var2 = typeof(arg2)
	if var2 == "table" then
		if type(arg2.Destroy) ~= "function" and type(arg2.Disconnect) ~= "function" then
			error((("[%*]: Received table as cleanup object, but couldn't detect a :Destroy() or :Disconnect() method"):format(script.Name)))
		end
	elseif var2 ~= "function" and (var2 ~= "RBXScriptConnection" and var2 ~= "Instance") then
		error((("[%*]: Cleanup of type \"%*\" not supported"):format(script.Name, var2)))
	end

	local var3 = tbl1.New(arg1, arg2)
	arg1.tokens[var3] = true
	return var3
end

tbl2.Cleanup = function(arg1, ...)
	local var2
	if arg1.key ~= nil then
		var2 = script.Name
		error((("[%*]: \"Cleanup()\" is locked for this Maid"):format(var2)))
	end

	arg1.is_cleaned = true
	for k1 in pairs(arg1.tokens) do
		k1:Cleanup(...)
	end
end

tbl2.Unlock = function(arg1, arg2)
	if arg1.key ~= nil and arg1.key ~= arg2 then
		error((("[%*]: Invalid lock key"):format(script.Name)))
	end

	arg1.key = nil
end

return tbl2

--- ReplicatedStorage.ReplicaShared.RateLimit [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
tbl1.New = function(arg1, arg2)
	if arg1 <= 0 then
		error("[RateLimit]: Invalid rate")
	end

	local tbl3 = { sources = {}, rate_period = 1 / arg1, is_full_wait = arg2 == true }
	setmetatable(tbl3, tbl1)
	tbl2[tbl3] = true
	return tbl3
end

local tbl3 = {}
tbl1.CheckRate = function(arg1, arg2)
	local var1 = arg1.sources
	local var2 = os.clock()
	if arg2 == nil then
		arg2 = "nil"
	end

	local var4 = var1[arg2]
	if var4 ~= nil then
		if arg1.is_full_wait ~= true then
			var4 = math.max(var2, var4 + arg1.rate_period)
			if var4 - var2 < 1 then
				var1[arg2] = var4
				return true
			end

			return false
		end

		if var4 <= var2 then
			var1[arg2] = var2 + arg1.rate_period
			return true
		end

		return false
	end

	if typeof(arg2) == "Instance" and (arg2:IsA("Player") and tbl3[arg2] == nil) then
		return false
	end

	var1[arg2] = var2 + arg1.rate_period
	return true
end

tbl1.CleanSource = function(arg1, arg2)
	arg1.sources[arg2] = nil
end

tbl1.Cleanup = function(arg1)
	arg1.sources = {}
end

tbl1.Destroy = function(arg1)
	tbl2[arg1] = nil
end

for k1, v1 in ipairs(var1:GetPlayers()) do
	tbl3[v1] = true
end

var1.PlayerAdded:Connect(function(arg1)
	tbl3[arg1] = true
end)

var1.PlayerRemoving:Connect(function(arg1)
	tbl3[arg1] = nil
	for k1 in pairs(tbl2) do
		k1.sources[arg1] = nil
	end
end)

return tbl1

--- ReplicatedStorage.ReplicaShared.Remote [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var5 = var1:IsServer()
local var6 = game:GetService("ReplicatedStorage")
local var7 = var1:IsStudio()
local var8 = nil
local var9 = nil
local tbl1 = {}
if var5 == true then
	var8 = var6:FindFirstChild("RemoteEvents")
	if var8 ~= nil then
		if var7 == true then
			warn((("[%*]: ReplicatedStorage \"RemoteEvents\" container was already defined"):format(script.Name)))
		end
	else
		var8 = Instance.new("Folder")
		var8.Name = "RemoteEvents"
		var8.Parent = var6
	end
else
	var8 = var6:FindFirstChild("RemoteEvents")
	if var8 == nil then
		var9 = Instance.new("BindableEvent")
		task.spawn(function()
			while task.wait() do
				var8 = var6:FindFirstChild("RemoteEvents")
				if var8 == nil then
					continue
				end

				var9:Fire()
				return
			end
		end)

	end
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.New = function(arg1)
	return (setmetatable({ fn = arg1, is_disconnected = false, real_connection = nil }, tbl2))
end

tbl2.Disconnect = function(arg1)
	arg1.is_disconnected = true
	if arg1.real_connection ~= nil then
		arg1.real_connection:Disconnect()
	end
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.New = function(arg1, arg2)
	if type(arg1) ~= "string" then
		error((("[%*]: name must be a string"):format(script.Name)))
	end

	if var5 == true then
		if tbl1[arg1] ~= nil then
			error((("[%*]: RemoteEvent %* was already defined"):format(script.Name, arg1)))
		end

		tbl1[arg1] = true
		local var1 = Instance.new
		var1 = var1(if arg2 == true then "UnreliableRemoteEvent" else "RemoteEvent")
		var1.Name = arg1
		var1.Parent = var8
		return var1
	end

	local var2 = var8
	var2 = var2 and var8:FindFirstChild(arg1)
	if var2 ~= nil then
		return var2
	end

	local tbl4 = {}
	local var3 = setmetatable({
		OnClientEvent = { Connect = function(_, arg2)
			if var2 ~= nil then
				local var3 = arg2
				return var2.OnClientEvent:Connect(var3)
			end

			local var4 = tbl2.New(arg2)
			table.insert(tbl4, var4)
			return var4
		end },
		OnServerEvent = { Connect = function()
			error((("[%*]: Can't connect to \"OnServerEvent\" client-side"):format(script.Name)))
		end },
		RemoteEvent = nil,
	}, tbl3)

	local function on_container_ready()
		local var1 = os.clock()
		while true do
			var2 = var8:FindFirstChild(arg1)
			if var2 ~= nil then
				break
			end

			local var5
			if var1 ~= nil and 20 < os.clock() - var1 then
				var5 = arg1
				warn((("[%*]: RemoteEvent \"%*\" hasn't been defined server-side"):format(script.Name, var5)))
			end

			task.wait()
			continue
		end

		for k1, v1 in ipairs(tbl4) do
			if v1.is_disconnected ~= false then
				continue
			end

			v1.real_connection = var2.OnClientEvent:Connect(v1.fn)
		end

		var3.RemoteEvent = var2
		tbl4 = nil
	end

	if var8 ~= nil then
		task.spawn(on_container_ready)
	else
		local var4 = nil
		var9.Event:Connect(function()
			var4:Disconnect()
			on_container_ready()
		end)

	end

	return var3
end

tbl3.FireServer = function(arg1, ...)
	if arg1.RemoteEvent ~= nil then
		arg1.RemoteEvent:FireServer(...)
	end
end

tbl3.FireClient = function(_)
	error((("[%*]: Can't use \"FireClient\" client-side"):format(script.Name)))
end

tbl3.FireAllClients = function(_)
	error((("[%*]: Can't use \"FireAllClients\" client-side"):format(script.Name)))
end

return tbl3

--- ReplicatedStorage.ReplicaShared.Signal [ModuleScript]
-- y u r i

local var1 = nil
local function AcquireRunnerThreadAndCallEventHandler(arg1, ...)
	local var2 = var1
	var1 = nil
	arg1(...)
	var1 = var2
end

local tbl1 = {}
tbl1.__index = tbl1
local tbl2 = {}
tbl2.__index = tbl2
tbl1.Disconnect = function(arg1)
	if arg1.IsConnected == false then
		return
	end

	arg1.IsConnected = false
	local var1 = arg1.signal
	if var1.head == arg1 then
		var1.head = arg1.next
		return
	end

	local var2 = var1.head
	while var2 ~= nil and var2.next ~= arg1 do
		var2 = var2.next
	end

	if var2 ~= nil then
		var2.next = arg1.next
	end
end

tbl2.New = function()
	local tbl1 = { head = nil }
	setmetatable(tbl1, tbl2)
	return tbl1
end

tbl2.Connect = function(arg1, arg2)
	if type(arg2) ~= "function" then
		error((("[%*]: \"listener\" must be a function; Received %*"):format(script.Name, (typeof(arg2)))))
	end

	local tbl2 = { listener = arg2, signal = arg1, next = arg1.head, IsConnected = true }
	setmetatable(tbl2, tbl1)
	arg1.head = tbl2
	return tbl2
end

local function RunEventHandlerInFreeThread(...)
	AcquireRunnerThreadAndCallEventHandler(...)
	while true do
		AcquireRunnerThreadAndCallEventHandler(coroutine.yield())
	end
end

tbl2.Fire = function(arg1, ...)
	local var2 = arg1.head
	while var2 ~= nil do
		if var2.IsConnected == true then
			if not var1 then
				var1 = coroutine.create(RunEventHandlerInFreeThread)
			end

			task.spawn(var1, var2.listener, ...)
		end

		var2 = var2.next
	end
end

tbl2.Wait = function(arg1)
	local var1 = nil
	local var2 = coroutine.running()
	arg1:Connect(function(...)
		var1:Disconnect()
		task.spawn(var2, ...)
	end)

	return coroutine.yield()
end

tbl2.FireUntil = function(arg1, arg2, ...)
	if type(arg2) ~= "function" then
		error((("[%*]: \"continue_callback\" must be a function; Received %*"):format(script.Name, (typeof(arg2)))))
	end

	local tbl1 = {}
	local var1 = table.pack(...)
	local var2 = arg1.head
	while var2 ~= nil do
		table.insert(tbl1, var2)
		var2 = var2.next
	end

	task.spawn(function()
		for k1, v1 in ipairs(tbl1) do
			if v1.IsConnected ~= true then
				continue
			end

			local var2 = var1
			v1.listener(table.unpack(var2))
			if arg2() == true then
				continue
			end

			return
		end
	end)
end

local tbl3 = { New = tbl2.New }
return table.freeze(tbl3)

--- ReplicatedStorage.ReplicaShared.SmartBone [ModuleScript]
-- y u r i

local var1 = game:GetService("Lighting")
local var2 = game:GetService("CollectionService")
if not game:GetService("RunService"):IsClient() then
	warn("Attempted to initialize SmartBone on Server.")
	return nil
end

local var3 = script:WaitForChild("Dependencies")
local var4 = script:WaitForChild("Components")
local var7 = require(var3.Config).Debug
local var8 = require(var3.UnitConversion)
local var9 = require(var3.DefaultSettings)
local var10 = require(var4.ParticleTree)
local var11 = require(var4.Particle)
local var12 = require(var3.SettingsMath)
local var13 = require(var3.Utilities)
local var14 = Random.new(12098135901304)
local var15 = var2:GetTagged("SmartBone")
local var16 = nil
local var17 = nil
if var7 then
	var16 = Instance.new("Model")
	var16.Name = "SMARTBONE_DEBUGFOLDER"
	var16.Parent = workspace
	var17 = Instance.new("Highlight")
	var17.FillColor = Color3.fromRGB(255, 0, 0)
	var17.OutlineTransparency = 1
	var17.FillTransparency = 0
	var17.Parent = var16
	var17.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	var17.Enabled = true
end

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	local num1 = 10000000
	local tbl2 = {
		ID = var14:NextInteger(1, num1),
		Time = 0,
		WindPreviousPosition = Vector3.new(0, 0, 0),
		Removed = false,
		InRange = false,
	}

	tbl2.RootPart = arg1
	tbl2.ParticleTrees = {}
	tbl2.Connections = {}
	tbl2.RootList = arg2
	local str1 = "Millimeter"
	tbl2.ObjectScale = var8.Convert(math.abs(arg1.Size.X), str1)
	tbl2.RemovedEvent = Instance.new("BindableEvent")
	tbl2.Settings = {}
	tbl2.CollisionRayParams = RaycastParams.new()
	local var1 = setmetatable(tbl2, tbl1)
	for k1, v1 in var9, nil do
		var1.Settings[k1] = arg1:GetAttribute(k1) or v1
	end

	var1.Settings.BlendWeight = 1
	var1.Settings.UpdateRate = math.floor(var1.Settings.UpdateRate + 0.1)
	var1.CollisionRayParams.FilterType = Enum.RaycastFilterType.Exclude
	var1.CollisionRayParams.IgnoreWater = true
	var1:UpdateCollisionFilter()
	var1:Init()
	var1:UpdateParameters(var1.Settings)
	return var1
end

local tbl2 = {}
tbl1.Init = function(arg1)
	tbl2[arg1.ID] = arg1
	local var2 = arg1.RootPart
	arg1.Connections.AttributeChanged = var2.AttributeChanged:ConnectParallel(function(arg1)
		if arg1.Settings[arg1] == nil then
			return
		end

		local var1 = arg1
		arg1:UpdateParameters(arg1, var2:GetAttribute(var1))
	end)

	arg1.Connections.LightingAttributeChanged = var1.AttributeChanged:ConnectParallel(function(arg1)
		if arg1.Settings[arg1] == nil then
			return
		end

		local var2 = arg1
		arg1:UpdateParameters(arg1, var1:GetAttribute(var2))
	end)

	local var3 = nil
	local var4 = nil
	for k1, v1 in var2:GetDescendants() do
		if not v1:IsA("Bone") then
			continue
		end

		if not v1.Parent:IsA("Bone") then
			continue
		end

		if #v1:GetChildren() ~= 0 then
			continue
		end

		var3 = Instance.new("Bone")
		var3.Parent = v1
		var3.Name = v1.Name .. "_Tail"
		var3.WorldCFrame = v1.WorldCFrame + v1.WorldCFrame.UpVector.Unit * (v1.WorldPosition - v1.Parent.WorldPosition).Magnitude
	end

	for k2, v2 in arg1.RootList, nil do
		arg1:AppendParticleTree(v2)
	end

	for k3, v3 in arg1.ParticleTrees, nil do
		arg1:AppendParticles(v3, v3.Root, 0, 0)
	end
end

tbl1.AppendParticleTree = function(arg1, arg2)
	local var1 = arg2
	local var2 = arg1.RootPart
	local var3 = arg1.Settings.Gravity
	table.insert(arg1.ParticleTrees, var10.new(var1, var2, var3))
end

tbl1.AppendParticles = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg1.Settings
	local var2 = var11.new(arg3, arg2.Root, arg1.RootPart, var1)
	var2.Position = arg3.WorldPosition
	var2.LastPosition = arg3.WorldPosition
	var2.ParentIndex = arg4
	var2.BoneLength = arg5
	var2.HeirarchyLength = 0
	if var7 == true then
		var2.DebugPart = Instance.new("Part")
		var2.DebugPart.Size = Vector3.new(0.1, 0.1, 0.1)
		var2.DebugPart.Anchored = true
		var2.DebugPart.CanCollide = false
		var2.DebugPart.CastShadow = false
		var2.DebugPart.CanTouch = false
		var2.DebugPart.CanQuery = false
		var2.DebugPart.Color = Color3.fromRGB(255, 0, 0)
		var2.DebugPart.Parent = var16
	end

	if 1 <= arg4 then
		arg5 = (arg2.Particles[arg4].Bone.WorldPosition - var2.Position).Magnitude
		var2.BoneLength = arg5
		var2.Weight = arg5 * 0.7
		var2.HeirarchyLength = var13.GetHierarchyLength(arg3, arg2.Root)
	end

	if var2.HeirarchyLength <= var1.AnchorDepth then
		var2.Anchored = true
	end

	table.insert(arg2.Particles, var2)
	local var3 = arg3:GetChildren()
	local var4 = #arg2.Particles
	local var5 = nil
	for i1 = 1, #var3 do
		var5 = var3[i1]
		if not var5:IsA("Bone") then
			continue
		end

		arg1:AppendParticles(arg2, var5, var4, arg5)
	end
end

tbl1.UpdateParameters = function(arg1, arg2, arg3)
	if arg1.Settings[arg2] == nil then
		return
	end

	local var1 = arg1.Settings
	local var2 = if var12[arg2] then var12[arg2](arg3) else arg3
	var1[arg2] = var2
end

tbl1.UpdateCollisionFilter = function(arg1)
	local tbl1 = { arg1.RootPart }
	local var1 = arg1.RootPart.Parent
	while not var1 and var1 == workspace and var1:IsA("Model") do
	end

	arg1.CollisionRayParams.FilterDescendantsInstances = tbl1
end

tbl1.ResolveCollision = function(arg1, arg2, arg3, arg4)
	local var1 = arg3 - arg2
	if var1.Magnitude <= 0.0001 then
		return arg3
	end

	local var4 = arg1.CollisionRayParams
	local var5 = nil
	var5 = if workspace.Spherecast and 0 < arg4 then workspace:Spherecast(arg2, arg4, var1, var4) else workspace:Raycast(arg2, var1, var4)
	if not var5 or (not var5.Instance or (not var5.Instance.CanCollide)) then
		return arg3
	end

	return var5.Position + var5.Normal * (arg4 + (arg1.Settings.CollisionOffset or 0.03))
end

tbl1.CollideParticles = function(arg1, arg2)
	local var1 = arg1.Settings
	if var1.CollisionEnabled == false then
		return
	end

	for k1, v1 in arg2.Particles, nil do
		if 1 > v1.ParentIndex then
			continue
		end

		if v1.Anchored ~= false then
			continue
		end

		local var3 = var1.CollisionRadius
		if var3 then
			if var3 <= 0 then
				local var4 = v1.Radius
				var3 = var4 or (var1.Radius or 0.05)
			end
		end

		local var5 = arg1:ResolveCollision(v1.LastPosition, v1.Position, var3)
		v1.Position = var5
	end
end

tbl1.PreUpdate = function(_, arg2)
	local var1 = arg2.RootPart
	arg2.ObjectMove = var1.Position - arg2.ObjectPreviousPosition
	arg2.ObjectPreviousPosition = var1.Position
	local var2 = arg2.Root
	arg2.RestGravity = var2.CFrame:PointToWorldSpace(arg2.LocalGravity)
	for k1, v1 in arg2.Particles, nil do
		v1.LastTransformOffset = v1.TransformOffset
		if v1.Bone == v1.Root then
			v1.TransformOffset = var1.CFrame * v1.RootTransform
		else
			v1.TransformOffset = var2.WorldCFrame * v1.Transform
		end

		v1.LocalTransformOffset = var2.CFrame * v1.LocalTransform
	end
end

tbl1.UpdateParticles = function(arg1, arg2, arg3, arg4)
	local var1 = arg1.Settings
	local var2 = var1.Gravity.Unit
	local var3 = var1.Damping
	local var4 = (var1.Gravity - var2 * math.max(arg2.RestGravity:Dot(var2), 0) + var1.Force) * (arg1.ObjectScale * arg3)
	local var5 = arg4 == 0 and arg2.ObjectMove or Vector3.new(0, 0, 0)
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = nil
	for k1, v1 in arg2.Particles, nil do
		if 1 <= v1.ParentIndex then
			if v1.Anchored == false then
				var6 = Vector3.new(0, 0, 0)
				if 0 < var1.WindInfluence then
					var9 = arg2.WindOffset + (os.clock() - v1.HeirarchyLength / 5) + (v1.TransformOffset.Position - arg2.Root.WorldPosition).Magnitude / 5 * var1.WindInfluence
					var6 = Vector3.new(var1.WindDirection.X + var1.WindDirection.X * math.sin(var9 * var1.WindSpeed), var1.WindDirection.Y + math.sin(var9 * var1.WindSpeed) * 0.05, var1.WindDirection.Z + var1.WindDirection.X * math.sin(var9 * var1.WindSpeed)) / v1.BoneLength * var1.WindInfluence * (var1.WindStrength / 100 * (math.clamp(v1.HeirarchyLength, 1, 10) / 10)) * v1.Weight
					arg1.WindPreviousPosition = var6
				end

				var8 = var5 * var1.Inertia
				var7 = v1.Position - v1.LastPosition
				v1.LastPosition = v1.Position + var8
				local var10 = v1.Position + (var7 * (1 - var3) + var4 + var8 + var6)
				v1.Position = var10
			else
				v1.LastPosition = v1.TransformOffset.Position
				v1.Position = v1.TransformOffset.Position
			end
		else
			v1.LastPosition = v1.TransformOffset.Position
			v1.Position = v1.TransformOffset.Position
		end
	end
end

tbl1.CorrectParticles = function(arg1, arg2, arg3)
	local var1 = arg1.Settings
	local var2 = var1.Stiffness
	local var3 = nil
	local var4 = nil
	local var5 = nil
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = nil
	for k1, v1 in arg2.Particles, nil do
		var3 = arg2.Particles[v1.ParentIndex]
		if not var3 then
			continue
		end

		if 1 > v1.ParentIndex then
			continue
		end

		if v1.Anchored ~= false then
			continue
		end

		var4 = (var3.TransformOffset.Position - v1.TransformOffset.Position).Magnitude
		if 0 < var2 or 0 < var1.Elasticity then
			var8 = (CFrame.new(var3.Position) * var3.TransformOffset.Rotation * CFrame.new(v1.LocalTransformOffset.Position)).Position
			local var10 = v1.Position + (var8 - v1.Position) * (var1.Elasticity * arg3)
			v1.Position = var10
			var5 = var8 - v1.Position
			var9 = var4 * (1 - var2) * 2
			var6 = var5.Magnitude
			if 0 < var2 and var9 < var6 then
				var10 = v1.Position + var5 * ((var6 - var9) / var6)
				v1.Position = var10
			end
		end

		var5 = var3.Position - v1.Position
		var6 = var5.Magnitude
		if 0 >= var6 then
			continue
		end

		local var11 = v1.Position + var5 * ((var6 - var4) / var6)
		v1.Position = var11
	end
end

tbl1.SkipUpdateParticles = function(arg1, arg2)
	local var1 = nil
	local var2 = nil
	local var3 = nil
	local var4 = nil
	local var5 = nil
	local var6 = nil
	local var7 = nil
	for k1, v1 in arg2.Particles, nil do
		if 1 <= v1.ParentIndex and (not v1.Anchored) then
			local var8 = v1.LastPosition + arg2.ObjectMove
			v1.LastPosition = var8
			var8 = v1.Position + arg2.ObjectMove
			v1.Position = var8
			var1 = arg2.Particles[v1.ParentIndex]
			var3 = arg1.Settings.Stiffness
			var5 = var1.Position + CFrame.lookAt(var1.Position, v1.Position).LookVector.Unit * (var1.Position - v1.Position).Magnitude - v1.Position
			var2 = (var1.TransformOffset.Position - v1.TransformOffset.Position).Magnitude
			var7 = var2 * (1 - var3) * 2
			var6 = var5.Magnitude
			if 0 < var3 and var7 < var6 then
				var8 = v1.Position + var5 * ((var6 - var7) / var6)
				v1.Position = var8
			end

			var5 = var1.Position - v1.Position
			var6 = var5.Magnitude
			if var2 >= var6 then
				continue
			end

			var8 = v1.Position + var5 * ((var6 - var2) / var6)
			v1.Position = var8
		else
			v1.LastPosition = v1.TransformOffset.Position
			v1.Position = v1.TransformOffset.Position
		end
	end
end

tbl1.CalculateTransforms = function(arg1, arg2, arg3)
	if arg1.InRange then
		local var1 = nil
		local var2 = nil
		local var3 = nil
		local var4 = nil
		local var5 = nil
		local var6 = nil
		local var7 = nil
		local var8 = nil
		local var9 = nil
		for k1, v1 in arg2.Particles, nil do
			if 1 > v1.ParentIndex then
				continue
			end

			if v1.Anchored ~= false then
				continue
			end

			var1 = arg2.Particles[v1.ParentIndex]
			var2 = var1.Bone
			if not var1 or (not var2) then
				continue
			end

			if not var2:IsA("Bone") then
				continue
			end

			if var2 == arg2.Root then
				continue
			end

			var4 = var1.TransformOffset
			var1.CalculatedWorldCFrame = var2.WorldCFrame:Lerp(CFrame.new(var1.Position) * (var13.GetRotationBetween(var4.UpVector, v1.Position - var1.Position, (var4:PointToObjectSpace(var1.LocalTransformOffset.Position))).Rotation * var4.Rotation), 1 - 1e-05 ^ arg3)
		end
	end
end

tbl1.TransformBones = function(arg1, arg2)
	local var1 = nil
	local var2 = nil
	if arg1.InRange then
		for k1, v1 in arg2.Particles, nil do
			if 1 > v1.ParentIndex then
				continue
			end

			if v1.Anchored ~= false then
				continue
			end

			var1 = arg2.Particles[v1.ParentIndex]
			var2 = var1.Bone
			if not var1 or (not var2) then
				continue
			end

			if not var2:IsA("Bone") then
				continue
			end

			if var2 == arg2.Root then
				continue
			end

			if var1.Anchored and arg1.Settings.AnchorsRotate == false then
				var2.WorldCFrame = var1.TransformOffset
			else
				var2.WorldCFrame = var1.CalculatedWorldCFrame
			end
		end
	end
end

tbl1.DEBUG = function(_, arg2)
	for k1, v1 in arg2.Particles, nil do
		if not v1 then
			continue
		end

		v1.DebugPart.CFrame = CFrame.new(v1.Position)
	end
end

tbl1.RunLoop = function(arg1, arg2, arg3, arg4)
	local bool1 = true
	local var1 = arg3 * 10
	if 0 < arg4 then
		local var2 = arg1.Time + arg3
		arg1.Time = var2
		bool1 = false
		if 1 / arg4 <= arg1.Time then
			arg1.Time = 0
			bool1 = true
		end
	end

	if bool1 then
		arg1:UpdateParticles(arg2, var1, 0)
		arg1:CorrectParticles(arg2, var1)
		arg1:CollideParticles(arg2)
		return
	end

	arg1:SkipUpdateParticles(arg2)
end

tbl1.ResetParticles = function(_, arg2)
	for k1, v1 in arg2.Particles, nil do
		v1.LastPosition = v1.TransformOffset.Position
		v1.Position = v1.TransformOffset.Position
	end
end

tbl1.ResetTransforms = function(_, arg2)
	local var1 = nil
	for k1, v1 in arg2.Particles, nil do
		v1.Bone.WorldCFrame = if v1.Bone == v1.Root then arg2.RootPart.CFrame * v1.RootTransform else arg2.Root.WorldCFrame * v1.Transform
	end
end

tbl1.UpdateBones = function(arg1, arg2, arg3)
	for k1, v1 in arg1.ParticleTrees, nil do
		arg1:PreUpdate(v1, arg2)
		arg1:RunLoop(v1, arg2, arg3)
		arg1:CalculateTransforms(v1, arg2)
	end
end

tbl1.Start = function()
	local var1 = Instance.new("Folder")
	var1.Name = "Actors"
	var1.Parent = game.Players.LocalPlayer:WaitForChild("PlayerScripts")
	local tbl1 = {}
	local tbl3 = {}
	local function registerSmartBoneObject(arg1)
		if arg1:IsA("BasePart") then
			if var13.WaitForChildOfClass(arg1, "Bone", 3) then
				if game.Workspace:IsAncestorOf(arg1) then
					local str5 = "Roots"
					local tbl2 = {}
					if arg1:GetAttribute("Roots") and (arg1:GetAttribute("Roots") ~= nil and typeof(arg1:GetAttribute(str5)) == "string") then
						for k1, v1 in ipairs((string.split(arg1:GetAttribute("Roots"), ","))) do
							local var2 = arg1:FindFirstChild(v1, true)
							if not var2 then
								continue
							end

							if not var2:IsA("Bone") then
								continue
							end

							table.insert(tbl2, var2)
						end
					end

					if 0 < (#tbl2) then
						local var3 = Instance.new("Actor")
						local var4 = Instance.new("BindableFunction")
						var4.Name = "Event"
						var4.Parent = var3
						local var5 = script.Dependencies.ActorScript:Clone()
						var5.Name = "Runtime"
						var5.Parent = var3
						var3.Parent = var1
						var5.Enabled = true
						tbl1[arg1] = var3.Event:Invoke(arg1, tbl2)
						var3.Name = arg1.Name .. tbl1[arg1].ID
						tbl1[arg1].RemovedEvent.Event:Once(function()
							var3.Runtime.Enabled = false
							var3:Destroy()
						end)

						table.insert(tbl3, arg1)
						if not var7 then
							return
						end

						warn("Created new SmartBone Object with ID: " .. tbl1[arg1].ID)
						return
					end

					table.insert(tbl3, arg1)
					local var6 = "Failed to create SmartBone Object for " .. arg1:GetFullName() .. "! Make sure you have defined the Root Bone(s) for this object!"
					if var7 then
						warn(var6)
					end
				end
			end
		end
	end

	var2:GetInstanceAddedSignal("SmartBone"):Connect(registerSmartBoneObject)
	var2:GetInstanceRemovedSignal("SmartBone"):Connect(function(arg1)
		if tbl1[arg1] then
			local var1 = "Removing SmartBone Object with ID: " .. tbl1[arg1].ID
			if var7 then
				warn(var1)
			end

			task.spawn(function()
				local var1 = arg1
				for k1, v1 in pairs(tbl1[var1].Connections) do
					v1:Disconnect()
				end

				tbl1[arg1].SimulationConnection:Disconnect()
				task.wait()
				tbl1[arg1].RemovedEvent:Destroy()
				local var2 = arg1
				for k2, v2 in ipairs(tbl1[var2].ParticleTrees) do
					for k3, v3 in v2.Particles, nil do
						for k4, v4 in v3.RecyclingBin, nil do
							v4:Destroy()
						end
					end
				end

				task.wait()
				if tbl2[tbl1[arg1].ID] then
					tbl2[tbl1[arg1].ID] = nil
				end

				tbl1[arg1].Removed = true
				tbl1[arg1].RemovedEvent:Fire()
				tbl1[arg1] = nil
			end)

		end
	end)

	for k1, v1 in pairs(var15) do
		if tbl1[v1] then
			continue
		end

		if table.find(tbl3, v1) then
			continue
		end

		task.spawn(function()
			registerSmartBoneObject(v1)
		end)

	end
end

return tbl1

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.CameraUtil [ModuleScript]
-- y u r i

return { WithinViewport = function(arg1)
	local var5 = workspace.CurrentCamera
	local var6 = nil
	local var7 = nil
	if arg1:IsA("Model") then
		local var8, var9 = arg1:GetBoundingBox()
		var6 = var8
		var7 = var9
	else
		if arg1:IsA("BasePart") then
			var6 = arg1.CFrame
			var7 = arg1.Size
		else
			warn("Object is neither a Model nor a BasePart! Disregarding Camera check!")
			return false
		end
	end

	for i1 = 1, 8 do
		local var10 = CFrame.new
		local var11 = var7.X
		local var12 = var11 * (if i1 % 2 == 0 then 0.5 else -0.5)
		local var13 = var7.Y
		var11 = var13 * (if 1 < i1 % 4 then 0.5 else -0.5)
		local var14 = var7.Z
		if not var5:WorldToViewportPoint((var6 * var10(var12, var11, var14 * (if 3 < i1 % 8 then 0.5 else -0.5))).Position) then
			continue
		end

		return true
	end

	return false
end }

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.Config [ModuleScript]
-- y u r i

return { Debug = false }

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.DefaultSettings [ModuleScript]
-- y u r i

return {
	Damping = 0.1,
	Stiffness = 0.2,
	Inertia = 0,
	Elasticity = 0.5,
	BlendWeight = 1,
	Radius = 0.2,
	AnchorDepth = 0,
	Force = Vector3.new(0, 0.2, 0),
	Gravity = Vector3.new(-0, -1, -0),
	WindDirection = Vector3.new(-1, -0, -0),
	WindSpeed = 8,
	WindStrength = 1,
	WindInfluence = 1,
	AnchorsRotate = false,
	UpdateRate = 60,
	ActivationDistance = 45,
	ThrottleDistance = 15,
	CollisionEnabled = true,
	CollisionRadius = 0,
	CollisionOffset = 0.03,
}

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.SettingsMath [ModuleScript]
-- y u r i

local num1 = 0
local num2 = 1
num1 = 0
num2 = 1
num1 = 0
num2 = 1
num1 = 0
num2 = 1
num1 = 0
num2 = 1
num1 = 0
num2 = 165
num1 = 0
num2 = 10
num1 = Vector3.new(0, -0.01, 0)
return {
	Damping = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	AnchorDepth = function(arg1)
		return (math.floor(arg1))
	end,
	Stiffness = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	Inertia = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	Elasticity = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	BlendWeight = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	UpdateRate = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	WindStrength = function(arg1)
		return (math.clamp(arg1, num1, num2))
	end,
	Gravity = function(arg1)
		return arg1 + num1
	end,
}

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.ActorScript [LocalScript]
-- y u r i

if not script.Parent:IsA("Actor") then
	return
end

local str1 = "PlayerScripts"
local var1 = script.Parent.Event
local var2 = game:GetService("RunService")
local var3 = nil
for k1, v1 in pairs({
	game:GetService("ReplicatedStorage"),
	game:GetService("Players").LocalPlayer:WaitForChild(str1),
}) do

	local var4 = v1:FindFirstChild("SmartBone", true)
	if not var4 then
		continue
	end

	if not var4:IsA("ModuleScript") then
		continue
	end

	var3 = var4
	break
end

if not var3 then
	warn("SmartBone was not found!")
	return
end

local var5 = var3:WaitForChild("Dependencies")
local str2 = "Config"
local str3 = "CameraUtil"
local var6 = require(var5:WaitForChild(str2))
local var7 = os.clock
local var8 = require(var5:WaitForChild(str3))
local tbl1 = {}
local num1 = 60
str3 = var7()
str1 = require(var3)
local function smoothDelta()
	local var1 = var7()
	for i1 = #tbl1, 1, -1 do
		tbl1[i1 + 1] = var1 - 1 <= tbl1[i1] and tbl1[i1] or nil
	end

	tbl1[1] = var1
	num1 = math.floor(1 <= var7() - str3 and (#tbl1) or #tbl1 / (var7() - str3))
	return math.floor((num1 * (1 / num1) ^ 2 + 0.001) * 1000 + 0.5) / 1000
end

str2 = var6.Debug
var1.OnInvoke = function(arg1, arg2)
	local num1 = 0
	local var1 = str1.new(arg1, arg2)
	var1.SimulationConnection = var2.Heartbeat:ConnectParallel(function(arg1)
		arg1 = smoothDelta()
		local var2 = num1 + arg1
		num1 = var2
		local var3 = (workspace.CurrentCamera.CFrame.Position - var1.RootPart.Position).Magnitude
		local var4 = var1.Settings.ActivationDistance
		local var5 = math.floor((math.clamp((1 - math.clamp(math.clamp(var3 - var1.Settings.ThrottleDistance, 0, var4) / var4, 0, 1)) * var1.Settings.UpdateRate, 1, var1.Settings.UpdateRate)))
		local var6 = var8.WithinViewport(var1.RootPart)
		if 1 / var5 <= num1 then
			local var7
			if var3 < var4 and var6 then
				arg1 = num1
				num1 = 0
				debug.profilebegin("SoftBone")
				if var1.InRange == false then
					var1.InRange = true
				end

				var1:UpdateBones(arg1, var5)
				debug.profileend()
				task.synchronize()
				debug.profilebegin("SoftBoneTransform")
				for k1, v1 in var1.ParticleTrees, nil do
					var1:TransformBones(v1, arg1)
					if not str2 then
						continue
					end

					var1:DEBUG(v1, arg1)
				end

				debug.profileend()
				task.desynchronize()
				return
			end

			if var1.InRange == true then
				var1.InRange = false
				for k2, v2 in var1.ParticleTrees, nil do
					var1:ResetParticles(v2)
				end

				task.synchronize()
				for k3, v3 in var1.ParticleTrees, nil do
					var1:ResetTransforms(v3, arg1)
				end

				task.desynchronize()
			end
		end
	end)

	return var1
end

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.UnitConversion [ModuleScript]
-- y u r i

local tbl1 = { Conversions = {
	Kilometer = 280.03360403248388,
	Hektometer = 28.00336040324839,
	Decameter = 2.8003360403248392,
	Meter = 0.2800336040324839,
	Decimeter = 0.028003360403248391,
	Centimeter = 0.002800336040324839,
	Millimeter = 0.00028003360403248392,
	Miles = 4850.9759731167742,
	Yards = 2.7562363483618033,
	Feet = 0.91874544945393444,
	Inches = 0.07656212078782787,
} }

tbl1.Convert = function(arg1, arg2)
	local bool2 = false
	if tbl1.Conversions[arg2] ~= nil then
		bool2 = arg1 * tbl1.Conversions[arg2]
	end

	return bool2
end

tbl1.ConvertInverse = function(arg1, arg2)
	local bool2 = false
	if tbl1.Conversions[arg2] ~= nil then
		bool2 = tbl1.Conversions[arg2] / arg1
	end

	return bool2
end

tbl1.ConvertRounded = function(arg1, arg2)
	local bool1 = false
	if tbl1.Conversions[arg2] ~= nil then
		bool1 = math.floor(arg1 * tbl1.Conversions[arg2])
	end

	return bool1
end

return tbl1

--- ReplicatedStorage.ReplicaShared.SmartBone.Dependencies.Utilities [ModuleScript]
-- y u r i

return {
	ShallowCopy = function(arg1)
		local tbl1 = {}
		for k1, v1 in pairs(arg1) do
			tbl1[k1] = v1
		end

		return tbl1
	end,
	Lerp = function(arg1, arg2, arg3)
		return arg1 + (arg2 - arg1) * arg3
	end,
	GetRotationBetween = function(arg1, arg2, arg3)
		local var3 = arg1:Dot(arg2)
		local var4 = arg1:Cross(arg2)
		if var3 < -0.99999 then
			local var5 = arg3
			local num2 = 3.1415926535897931
			return CFrame.fromAxisAngle(var5, num2)
		end

		local num3 = 0
		local num4 = 0
		local num5 = 0
		local var6 = var4.X
		local var7 = var4.Y
		local var8 = var4.Z
		local var9 = 1 + var3
		return CFrame.new(num3, num4, num5, var6, var7, var8, var9)
	end,
	GetHierarchyLength = function(arg1, arg2)
		if arg1 == arg2 then
			warn("Child and Root are the same Instance!")
			return
		end

		if arg1 == nil then
			warn("Child is nil!")
			return
		end

		local var1 = arg1
		local num1 = 0
		repeat
			var1 = var1.Parent
			num1 = num1 + 1
		until var1 == arg2

		return num1
	end,
	WaitForChildOfClass = function(arg1, arg2, arg3)
		arg3 = arg3 or 10
		local var1 = os.clock()
		repeat
			task.wait()
		until arg1:FindFirstChildOfClass(arg2) or arg3 < os.clock() - var1

		local var2 = arg2
		return arg1:FindFirstChildOfClass(var2)
	end,
}

--- ReplicatedStorage.ReplicaShared.SmartBone.Components.Particle [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3, arg4)
	local tbl2 = {
		Bone = arg1,
		RestLength = 0,
		Weight = 0.7,
		ParentIndex = 0,
		Transform = arg1.WorldCFrame:ToObjectSpace(arg2.WorldCFrame):Inverse(),
		IsColliding = false,
		RestPosition = Vector3.new(0, 0, 0),
		Anchored = false,
	}

	tbl2.LocalTransform = arg1.CFrame:ToObjectSpace(arg2.CFrame):Inverse()
	tbl2.RootTransform = arg2.WorldCFrame:ToObjectSpace(arg3.CFrame):Inverse()
	tbl2.Radius = arg4.Radius
	tbl2.TransformOffset = CFrame.identity
	tbl2.LastTransformOffset = CFrame.identity
	tbl2.LocalTransformOffset = CFrame.identity
	tbl2.BoneTransform = CFrame.identity
	tbl2.CalculatedWorldCFrame = arg1.WorldCFrame
	tbl2.CalculatedWorldPosition = arg1.WorldPosition
	tbl2.Position = arg1.WorldPosition
	tbl2.LastPosition = arg1.WorldPosition
	tbl2.RecyclingBin = {}
	return (setmetatable(tbl2, tbl1))
end

return tbl1

--- ReplicatedStorage.ReplicaShared.SmartBone.Components.ParticleTree [ModuleScript]
-- y u r i

local var1 = Random.new(1029410295159813)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	local tbl2 = {
		WindOffset = var1:NextNumber(0, 1000000),
		BoneTotalLength = 0,
		DistanceFromCamera = 100,
		Force = Vector3.new(0, 0, 0),
		RestGravity = Vector3.new(0, 0, 0),
		ObjectMove = Vector3.new(0, 0, 0),
		ObjectPreviousPosition = Vector3.new(0, 0, 0),
	}

	local var2 = arg1:IsA("Bone") and arg1 or nil
	tbl2.Root = var2
	tbl2.RootPart = arg2
	tbl2.RootWorldToLocal = arg1.WorldCFrame:ToObjectSpace(arg1.CFrame)
	tbl2.Particles = {}
	tbl2.LocalCFrame = arg1.WorldCFrame
	tbl2.LocalGravity = arg1.CFrame:PointToWorldSpace(arg3).Unit * arg3.Magnitude
	return (setmetatable(tbl2, tbl1))
end

return tbl1

--- Workspace.Map.Cameraman.Animation [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.Map.Cameraman.Animation [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.Map.Brown Cameraman.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.MovingParts.Birds.Hawk_FlightPath01.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.hspspjl.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- ReplicatedFirst.SmartBoneRuntime [LocalScript]
-- y u r i

local str1 = "SmartBone"
require(game:GetService("ReplicatedStorage"):WaitForChild("ReplicaShared"):WaitForChild(str1)).Start()

