--- Players.LocalPlayer.PlayerScripts.ClientMain [LocalScript]
-- y u r i

local str1 = "SidebarController"
local tbl1 = {
	"SkyController",
	"AudioController",
	"PortalFXController",
	"CmdrController",
	"AdminPanelController",
	"BoostHUDController",
	"CurrencyHUDController",
	"ChallengeHUDController",
	"LevelBarController",
	"LoopController",
	"UpgradeVisualsController",
	"UpgradeInputController",
	"DeltaClickerController",
	"SkillTreeController",
	"StarLevelController",
	"SupernovaBoardController",
	"SupernovaChallengeController",
	"KeycapController",
	"ShopController",
	"MenuController",
	"SaveSlotsController",
	str1,
	"SettingsController",
	"AchievementsUIController",
	"TeleportUIController",
	"TutorialController",
	"RevealController",
	"WorldDisplayController",
}

local var1 = script.Parent:WaitForChild("Controllers")
local tbl2 = {}
for k1, v1 in ipairs(tbl1) do
	local var3 = var1:FindFirstChild(v1)
	if not var3 then
		error("[ClientMain] missing controller module: " .. v1)
	end

	tbl2[v1] = require(var3)
end

for k2, v2 in ipairs(var1:GetChildren()) do
	if not v2:IsA("ModuleScript") then
		continue
	end

	if tbl2[v2.Name] then
		continue
	end

	warn("[ClientMain] controller '" .. v2.Name .. "' is not in INIT_ORDER and will never start")
end

for k3, v3 in ipairs(tbl1) do
	local var4 = tbl2[v3]
	if not var4.Init then
		continue
	end

	local success, result = pcall(var4.Init, tbl2)
	if success then
		continue
	end

	warn("[ClientMain] " .. v3 .. ".Init failed: " .. tostring(result))
end

for k4, v4 in ipairs(tbl1) do
	local var5 = tbl2[v4]
	if not var5.Start then
		continue
	end

	task.spawn(function()
		local success, result = pcall(var5.Start)
		if not success then
			warn("[ClientMain] " .. v4 .. ".Start failed: " .. tostring(result))
		end
	end)

end

--- Players.LocalPlayer.PlayerScripts.LocalScript [LocalScript]
-- y u r i

local var1 = game:GetService("TextChatService")
local var2 = game:GetService("Players")
local tbl1 = { Tag = "developer", Color = Color3.fromRGB(0, 255, 0) }
local tbl2 = { [1837214769] = tbl1 }
var1.OnIncomingMessage = function(arg1)
	local var1 = Instance.new("TextChatMessageProperties")
	if not arg1.TextSource then
		return var1
	end

	local var4 = var2:GetPlayerByUserId(arg1.TextSource.UserId)
	if not var4 then
		return var1
	end

	local var7 = tbl2[var4.UserId]
	if var7 then
		local var8 = var7.Color
		var1.PrefixText = string.format("<font color=\"rgb(%d,%d,%d)\">[%s]</font> %s", var8.R * 255, var8.G * 255, var8.B * 255, var7.Tag, arg1.PrefixText)
	end

	return var1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local str1 = "CameraModule"
	local var1 = setmetatable({}, tbl1)
	var1.cameras = require(script:WaitForChild(str1))
	str1 = "ControlModule"
	var1.controls = require(script:WaitForChild(str1))
	return var1
end

tbl1.GetCameras = function(arg1)
	return arg1.cameras
end

tbl1.GetControls = function(arg1)
	return arg1.controls
end

tbl1.GetClickToMoveController = function(arg1)
	return arg1.controls:GetClickToMoveController()
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
local var1 = script.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local var3 = require(var1:WaitForChild(str2))
local str4 = "CameraInput"
local var4 = require(script:WaitForChild(str3))
local str5 = "ClassicCamera"
str1 = require(script:WaitForChild(str4))
local str6 = "OrbitalCamera"
str2 = require(script:WaitForChild(str5))
local str7 = "LegacyCamera"
str3 = require(script:WaitForChild(str6))
local str8 = "VehicleCamera"
str4 = require(script:WaitForChild(str7))
local str9 = "VRCamera"
str5 = require(script:WaitForChild(str8))
local str10 = "VRVehicleCamera"
str6 = require(script:WaitForChild(str9))
local str11 = "Invisicam"
str7 = require(script:WaitForChild(str10))
local str12 = "Poppercam"
str8 = require(script:WaitForChild(str11))
local str13 = "TransparencyController"
str9 = require(script:WaitForChild(str12))
local str14 = "MouseLockController"
str10 = require(script:WaitForChild(str13))
local var5 = game:GetService("Players")
str11 = require(script:WaitForChild(str14))
local tbl2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock",
}

local tbl3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode",
}

local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("VRService")
local var9 = UserSettings():GetService("UserGameSettings")
str12 = {}
str13 = {}
if not var5.LocalPlayer then
	return {}
end

assert(var5.LocalPlayer, "Strict typing check")
str14 = var5.LocalPlayer:WaitForChild("PlayerScripts")
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
str14 = var3.getUserFlag("UserPlayerConnectionMemoryLeak")
local var10 = var3.getUserFlag("UserPSFixCameraControllerReset")
tbl1.new = function()
	local tbl4 = { activeTransparencyController = str10.new() }
	local var1 = if str14 then var2.new() else nil
	tbl4.connectionUtil = var1
	local var3 = setmetatable(tbl4, tbl1)
	var3.activeCameraController = nil
	var3.activeOcclusionModule = nil
	var3.activeMouseLockController = nil
	var3.currentComputerCameraMovementMode = nil
	var3.cameraSubjectChangedConn = nil
	var3.cameraTypeChangedConn = nil
	for k1, v1 in pairs(var5:GetPlayers()) do
		var3:OnPlayerAdded(v1)
	end

	var5.PlayerAdded:Connect(function(arg1)
		var3:OnPlayerAdded(arg1)
	end)

	if str14 then
		var5.PlayerRemoving:Connect(function(arg1)
			var3:OnPlayerRemoving(arg1)
		end)

	end

	var3.activeTransparencyController:Enable(true)
	var3.activeMouseLockController = str11.new()
	assert(var3.activeMouseLockController, "Strict typing check")
	tbl4 = var3.activeMouseLockController:GetBindableToggleEvent()
	if tbl4 then
		tbl4:Connect(function()
			var3:OnMouseLockToggled()
		end)

	end

	var3:ActivateCameraController()
	var3:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
	var3:OnCurrentCameraChanged()
	local function fn2(arg1)
		var3:Update(arg1)
	end

	var6:BindToRenderStep("cameraRenderUpdate", Enum.RenderPriority.Camera.Value, fn2)
	for k2, v2 in pairs(tbl2) do
		var5.LocalPlayer:GetPropertyChangedSignal(v2):Connect(function()
			var3:OnLocalPlayerCameraPropertyChanged(v2)
		end)

	end

	for k3, v3 in pairs(tbl3) do
		var9:GetPropertyChangedSignal(v3):Connect(function()
			var3:OnUserGameSettingsPropertyChanged(v3)
		end)

	end

	game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		var3:OnCurrentCameraChanged()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var3:OnPreferredInputChanged()
	end)

	return var3
end

tbl1.GetCameraMovementModeFromSettings = function(_)
	if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		local var2 = Enum.ComputerCameraMovementMode.Classic
		return var4.ConvertCameraModeEnumToStandard(var2)
	end

	local var8 = nil
	local var10 = nil
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevTouchCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.TouchCameraMovementMode)
	else
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevComputerCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.ComputerCameraMovementMode)
	end

	if var8 == Enum.DevComputerCameraMovementMode.UserChoice then
		return var10
	end

	return var8
end

tbl1.ActivateOcclusionModule = function(arg1, arg2)
	local var2 = nil
	if arg2 == Enum.DevCameraOcclusionMode.Zoom then
		var2 = str9
	else
		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			var2 = str8
		else
			warn("CameraScript ActivateOcclusionModule called with unsupported mode")
			return
		end
	end

	arg1.occlusionMode = arg2
	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() == arg2 then
			if not arg1.activeOcclusionModule:GetEnabled() then
				arg1.activeOcclusionModule:Enable(true)
			end

			return
		end
	end

	local var3 = arg1.activeOcclusionModule
	arg1.activeOcclusionModule = str13[var2]
	if not arg1.activeOcclusionModule then
		arg1.activeOcclusionModule = var2.new()
		if arg1.activeOcclusionModule then
			str13[var2] = arg1.activeOcclusionModule
		end
	end

	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() ~= arg2 then
			warn("CameraScript ActivateOcclusionModule mismatch: ", arg1.activeOcclusionModule:GetOcclusionMode(), "~=", arg2)
		end

		if var3 then
			if var3 ~= arg1.activeOcclusionModule then
				var3:Enable(false)
			else
				warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
			end
		end

		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			if var5.LocalPlayer.Character then
				arg1.activeOcclusionModule:CharacterAdded(var5.LocalPlayer.Character, var5.LocalPlayer)
			end
		else
			for k1, v1 in pairs(var5:GetPlayers()) do
				if not v1 then
					continue
				end

				if not v1.Character then
					continue
				end

				arg1.activeOcclusionModule:CharacterAdded(v1.Character, v1)
			end

			arg1.activeOcclusionModule:OnCameraSubjectChanged(game.Workspace.CurrentCamera.CameraSubject)
		end

		arg1.activeOcclusionModule:Enable(true)
	end
end

tbl1.ShouldUseVehicleCamera = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return false
	end

	local var4 = var2.CameraType
	local var5 = var2.CameraSubject
	local bool1 = true
	if var4 ~= Enum.CameraType.Custom then
		bool1 = var4 == Enum.CameraType.Follow
	end

	local var6 = var5 and var5:IsA("VehicleSeat")
	return var6 and (bool1 and arg1.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam)
end

tbl1.ActivateCameraController = function(arg1)
	local var2 = workspace.CurrentCamera.CameraType
	local var3 = arg1:GetCameraMovementModeFromSettings()
	local var4 = nil
	if var2 == Enum.CameraType.Scriptable then
		if arg1.activeCameraController then
			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = nil
		end

		return
	end

	if var2 == Enum.CameraType.Custom then
		var3 = arg1:GetCameraMovementModeFromSettings()
	else
		if var2 == Enum.CameraType.Track then
			var3 = Enum.ComputerCameraMovementMode.Classic
		else
			if var2 == Enum.CameraType.Follow then
				var3 = Enum.ComputerCameraMovementMode.Follow
			else
				if var2 == Enum.CameraType.Orbital then
					var3 = Enum.ComputerCameraMovementMode.Orbital
				else
					if var2 == Enum.CameraType.Attach or (var2 == Enum.CameraType.Watch or var2 == Enum.CameraType.Fixed) then
						var4 = str4
					else
						warn("CameraScript encountered an unhandled Camera.CameraType value: ", var2)
					end
				end
			end
		end
	end

	if not var4 then
		if var8.VREnabled then
			var4 = str6
		else
			if var3 == Enum.ComputerCameraMovementMode.Classic or (var3 == Enum.ComputerCameraMovementMode.Follow or (var3 == Enum.ComputerCameraMovementMode.Default or var3 == Enum.ComputerCameraMovementMode.CameraToggle)) then
				var4 = str2
			else
				if var3 == Enum.ComputerCameraMovementMode.Orbital then
					var4 = str3
				else
					warn("ActivateCameraController did not select a module.")
					return
				end
			end
		end
	end

	if arg1:ShouldUseVehicleCamera() then
		var4 = if var8.VREnabled then str7 else str5
	end

	local var6 = nil
	if not str12[var4] then
		var6 = var4.new()
		str12[var4] = var6
	else
		var6 = str12[var4]
		if var10 then
			if var6.Reset and arg1.activeCameraController ~= var6 then
				var6:Reset()
			end
		else
			if var6.Reset then
				var6:Reset()
			end
		end
	end

	if arg1.activeCameraController then
		if arg1.activeCameraController ~= var6 then
			if var6.HandleSubjectDistance then
				var6:HandleSubjectDistance(arg1.activeCameraController)
			end

			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = var6
			arg1.activeCameraController:Enable(true)
		else
			if not arg1.activeCameraController:GetEnabled() then
				arg1.activeCameraController:Enable(true)
			end
		end
	elseif var6 ~= nil then
		arg1.activeCameraController = var6
		assert(arg1.activeCameraController, "Strict typing check")
		arg1.activeCameraController:Enable(true)
	end

	if arg1.activeCameraController then
		arg1.activeCameraController:SetCameraMovementMode(var3)
		arg1.activeCameraController:SetCameraType(var2)
	end
end

tbl1.OnCameraSubjectChanged = function(arg1)
	local var2 = workspace.CurrentCamera
	local var4 = if var2 then var2.CameraSubject else nil
	if arg1.activeTransparencyController then
		arg1.activeTransparencyController:SetSubject(var4)
	end

	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:OnCameraSubjectChanged(var4)
	end

	arg1:ActivateCameraController()
end

tbl1.OnCameraTypeChanged = function(arg1, arg2)
	if arg2 == Enum.CameraType.Scriptable and var7.MouseBehavior == Enum.MouseBehavior.LockCenter then
		var4.restoreMouseBehavior()
	end

	arg1:ActivateCameraController()
end

tbl1.OnCurrentCameraChanged = function(arg1)
	local var2 = game.Workspace.CurrentCamera
	if not var2 then
		return
	end

	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
	end

	if arg1.cameraTypeChangedConn then
		arg1.cameraTypeChangedConn:Disconnect()
	end

	arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		arg1:OnCameraSubjectChanged()
	end)

	arg1.cameraTypeChangedConn = var2:GetPropertyChangedSignal("CameraType"):Connect(function()
		arg1:OnCameraTypeChanged(var2.CameraType)
	end)

	arg1:OnCameraSubjectChanged()
	arg1:OnCameraTypeChanged(var2.CameraType)
end

tbl1.OnLocalPlayerCameraPropertyChanged = function(arg1, arg2)
	if arg2 == "CameraMode" then
		if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			if not arg1.activeCameraController or arg1.activeCameraController:GetModuleName() ~= "ClassicCamera" then
				arg1:ActivateCameraController()
			end

			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end

		if var5.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
			arg1:ActivateCameraController()
			return
		end

		warn("Unhandled value for property player.CameraMode: ", var5.LocalPlayer.CameraMode)
		return
	end

	if arg2 == "DevComputerCameraMode" or arg2 == "DevTouchCameraMode" then
		arg1:ActivateCameraController()
		return
	end

	if arg2 == "DevCameraOcclusionMode" then
		arg1:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
		return
	end

	if arg2 ~= "CameraMinZoomDistance" then
		if arg2 == "CameraMaxZoomDistance" then
			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end
	end

	if arg2 == "DevTouchMovementMode" then
		return
	end

	if arg2 == "DevComputerMovementMode" then
		return
	end

	if arg2 == "DevEnableMouseLock" then
	end
end

tbl1.OnUserGameSettingsPropertyChanged = function(arg1, arg2)
	if arg2 == "ComputerCameraMovementMode" or arg2 == "TouchCameraMovementMode" then
		arg1:ActivateCameraController()
	end
end

tbl1.OnPreferredInputChanged = function(arg1)
	arg1:ActivateCameraController()
end

tbl1.Update = function(arg1, arg2)
	if arg1.activeCameraController then
		arg1.activeCameraController:UpdateMouseBehavior()
		local var5, var6 = arg1.activeCameraController:Update(arg2)
		if arg1.activeOcclusionModule and (not arg1.activeCameraController.skipOcclusion) then
			local var7, var8 = arg1.activeOcclusionModule:Update(arg2, var5, var6)
			var5 = var7
			var6 = var8
		end

		local var9 = game.Workspace.CurrentCamera
		var9.CFrame = var5
		var9.Focus = var6
		if arg1.activeTransparencyController then
			arg1.activeTransparencyController:Update(arg2)
		end

		if str1.getInputEnabled() then
			str1.resetInputForFrameEnd()
		end
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterAdded(arg2, arg3)
	end
end

tbl1.OnCharacterRemoving = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterRemoving(arg2, arg3)
	end
end

tbl1.OnPlayerAdded = function(arg1, arg2)
	if str14 then
		if not arg1.connectionUtil then
			return
		end

		local function fn6(arg1)
			arg1:OnCharacterAdded(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterAdded"):format(arg2.UserId), arg2.CharacterAdded:Connect(fn6))
		fn6 = function(arg1)
			arg1:OnCharacterRemoving(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterRemoving"):format(arg2.UserId), arg2.CharacterRemoving:Connect(fn6))
		return
	end

	arg2.CharacterAdded:Connect(function(arg1)
		arg1:OnCharacterAdded(arg1, arg2)
	end)

	arg2.CharacterRemoving:Connect(function(arg1)
		arg1:OnCharacterRemoving(arg1, arg2)
	end)
end

tbl1.OnPlayerRemoving = function(arg1, arg2)
	if arg1.connectionUtil then
		arg1.connectionUtil:disconnect((("%*CharacterAdded"):format(arg2.UserId)))
		arg1.connectionUtil:disconnect((("%*CharacterRemoving"):format(arg2.UserId)))
	end
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = arg1.activeMouseLockController:GetIsMouseLocked()
	local var2 = arg1.activeMouseLockController:GetMouseLockOffset()
	if arg1.activeMouseLockController and arg1.activeCameraController then
		arg1.activeCameraController:SetIsMouseLocked(var1)
		arg1.activeCameraController:SetMouseLockOffset(var2)
	end
end

tbl1.new()
return {}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ClassicCamera [ModuleScript]
-- y u r i

Vector2.new(0, 0)
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixCameraFPError")
local str2 = "CameraInput"
local str3 = "CameraUtils"
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = CFrame.fromOrientation(-0.26179938779914941, 0, 0)
local var5 = game:GetService("Players")
str2 = setmetatable({}, var3)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(var3.new(), str2)
	var1.isFollowCamera = false
	var1.isCameraToggle = false
	var1.lastUpdate = tick()
	var1.cameraToggleSpring = var2.Spring.new(5, 0)
	return var1
end

str2.GetCameraToggleOffset = function(arg1, arg2)
	if arg1.isCameraToggle then
		local var4 = arg1.currentSubjectDistance
		if str1.getTogglePan() then
			arg1.cameraToggleSpring.goal = math.clamp(var2.map(var4, 0.5, arg1.FIRST_PERSON_DISTANCE_THRESHOLD, 0, 1), 0, 1)
		else
			arg1.cameraToggleSpring.goal = 0
		end

		return (Vector3.new(0, arg1.cameraToggleSpring:step(arg2) * (math.clamp(var2.map(var4, 0.5, 64, 0, 1), 0, 1) + 1), 0))
	end

	return (Vector3.new())
end

str2.SetCameraMovementMode = function(arg1, arg2)
	var3.SetCameraMovementMode(arg1, arg2)
	arg1.isFollowCamera = arg2 == Enum.ComputerCameraMovementMode.Follow
	arg1.isCameraToggle = arg2 == Enum.ComputerCameraMovementMode.CameraToggle
end

local num1 = 0
str2.Update = function(arg1, arg2)
	local var3 = workspace.CurrentCamera
	local var8 = tick()
	local var9 = var3.CFrame
	local var10 = var3.Focus
	local var11 = nil
	if arg1.resetCameraAngle then
		local var13 = arg1:GetHumanoidRootPart()
		arg1.resetCameraAngle = false
		var11 = if var13 then (var13.CFrame * var4).lookVector else var4.lookVector
	end

	local var14 = var3.CameraSubject
	local var15 = var14
	local var16 = var14
	local var17 = arg1:GetHumanoid()
	local var19 = var17
	local var20 = var5.LocalPlayer
	var15 = var15 and var14:IsA("VehicleSeat")
	var16 = var16 and var14:IsA("SkateboardPlatform")
	if var19 then
		var19 = var17:GetState() == Enum.HumanoidStateType.Climbing
	end

	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:StepZoom()
	local var22 = str1.getRotation(arg2)
	local var23 = arg1:GetCameraHeight()
	if var22 ~= Vector2.new() then
		num1 = 0
		arg1.lastUserPanCamera = tick()
	end

	local var26 = arg1:GetSubjectPosition()
	local var27 = var8 - arg1.lastUserPanCamera < 2
	if var26 then
		if var20 then
			if var3 then
				local var31 = arg1:GetCameraToSubjectDistance()
				if var31 < 0.5 then
					var31 = 0.5
				end

				if arg1:GetIsMouseLocked() then
					if not arg1:IsInFirstPerson() then
						local var32 = arg1:CalculateNewLookCFrameFromArg(var11, var22)
						local var33 = arg1:GetMouseLockOffset()
						if var17 then
							var33 = var33 + var17.CameraOffset
						end

						local var34 = var33.X * var32.RightVector + var33.Y * var32.UpVector + var33.Z * var32.LookVector
						if var2.IsFiniteVector3(var34) then
							var26 = var26 + var34
						end
					else
						if not (var22 ~= Vector2.new()) then
							if arg1.lastCameraTransform then
								local var37 = arg1:IsInFirstPerson()
								if not var15 then
									if var16 or arg1.isFollowCamera and var19 then
										if arg1.lastUpdate then
											if var17 then
												if var17.Torso then
													if var37 then
														if arg1.lastSubjectCFrame then
															if not var15 then
																if var16 then
																	if var14:IsA("BasePart") then
																		local var47 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																		if var2.IsFinite(var47) then
																			var22 = var22 + Vector2.new(var47, 0)
																		end

																		num1 = 0
																	end
																end
															end
														end
													elseif not var27 then
														local var48 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
														num1 = var48
														local var49 = var17.Torso.CFrame.lookVector
														var48 = math.clamp(num1 * arg2, 0, 1)
														if arg1:IsInFirstPerson() then
															var48 = arg1.isFollowCamera and arg1.isClimbing or 1
														end

														local var50 = var2.GetAngleBetweenXZVectors(var49, arg1:GetCameraLookVector())
														if var2.IsFinite(var50) and 0.0001 < math.abs(var50) then
															var22 = var22 + Vector2.new(var50 * var48, 0)
														end
													end
												else
													local var52 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
													if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var52) and (0.0001 < math.abs(var52) and 0.4 * arg2 < math.abs(var52))))) then
														var22 = var22 + Vector2.new(var52, 0)
													end
												end
											else
												local var54 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var54) and (0.0001 < math.abs(var54) and 0.4 * arg2 < math.abs(var54))))) then
													var22 = var22 + Vector2.new(var54, 0)
												end
											end
										else
											local var56 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var56) and (0.0001 < math.abs(var56) and 0.4 * arg2 < math.abs(var56))))) then
												var22 = var22 + Vector2.new(var56, 0)
											end
										end
									else
										local var58 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var58) and (0.0001 < math.abs(var58) and 0.4 * arg2 < math.abs(var58))))) then
											var22 = var22 + Vector2.new(var58, 0)
										end
									end
								end
							end
						end
					end
				else
					if not (var22 ~= Vector2.new()) then
						if arg1.lastCameraTransform then
							local var61 = arg1:IsInFirstPerson()
							if not var15 then
								if var16 or arg1.isFollowCamera and var19 then
									if arg1.lastUpdate then
										if var17 then
											if var17.Torso then
												if var61 then
													if arg1.lastSubjectCFrame then
														if not var15 then
															if var16 then
																if var14:IsA("BasePart") then
																	local var71 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																	if var2.IsFinite(var71) then
																		var22 = var22 + Vector2.new(var71, 0)
																	end

																	num1 = 0
																end
															end
														end
													end
												elseif not var27 then
													local var72 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
													num1 = var72
													local var73 = var17.Torso.CFrame.lookVector
													var72 = math.clamp(num1 * arg2, 0, 1)
													if arg1:IsInFirstPerson() then
														var72 = arg1.isFollowCamera and arg1.isClimbing or 1
													end

													local var74 = var2.GetAngleBetweenXZVectors(var73, arg1:GetCameraLookVector())
													if var2.IsFinite(var74) and 0.0001 < math.abs(var74) then
														var22 = var22 + Vector2.new(var74 * var72, 0)
													end
												end
											else
												local var76 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var76) and (0.0001 < math.abs(var76) and 0.4 * arg2 < math.abs(var76))))) then
													var22 = var22 + Vector2.new(var76, 0)
												end
											end
										else
											local var78 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var78) and (0.0001 < math.abs(var78) and 0.4 * arg2 < math.abs(var78))))) then
												var22 = var22 + Vector2.new(var78, 0)
											end
										end
									else
										local var80 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var80) and (0.0001 < math.abs(var80) and 0.4 * arg2 < math.abs(var80))))) then
											var22 = var22 + Vector2.new(var80, 0)
										end
									end
								else
									local var82 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
									if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var82) and (0.0001 < math.abs(var82) and 0.4 * arg2 < math.abs(var82))))) then
										var22 = var22 + Vector2.new(var82, 0)
									end
								end
							end
						end
					end
				end

				if not arg1.isFollowCamera then
					var10 = CFrame.new(var26)
					local var87 = var10.p
					local var88 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					if var1 then
						var9 = CFrame.lookAlong(var87 - var31 * var88, var88)
					else
						var9 = CFrame.new(var87 - var31 * var88, var87)
					end
				else
					var10 = CFrame.new(var26)
					local var90 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					var9 = if var1 then CFrame.lookAlong(var10.p - var31 * var90, var90) else CFrame.new(var10.p - var31 * var90, var10.p) + Vector3.new(0, var23, 0)
				end

				local var91 = arg1:GetCameraToggleOffset(arg2)
				var9 = var9 + var91
				arg1.lastCameraTransform = var9
				var10 = var10 + var91
				arg1.lastCameraFocus = var10
				if (var15 or var16) and var14:IsA("BasePart") then
					arg1.lastSubjectCFrame = var14.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var8
	return var9, var10
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUtils [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("UserInputService")
local var3 = UserSettings():GetService("UserGameSettings")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	return (setmetatable({ freq = arg1, goal = arg2, pos = arg2, vel = 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = arg1.pos - var1
	local var4 = arg1.vel
	local var5 = math.exp(-var2 * arg2)
	local var6 = (var3 * (var2 * arg2 + 1) + var4 * arg2) * var5 + var1
	arg1.pos = var6
	arg1.vel = (var4 * (1 - var2 * arg2) - var3 * (var2 * var2 * arg2)) * var5
	return var6
end

local tbl2 = {
	Spring = tbl1,
	map = function(arg1, arg2, arg3, arg4, arg5)
		return (arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4
	end,
	mapClamp = function(arg1, arg2, arg3, arg4, arg5)
		return (math.clamp((arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4, math.min(arg4, arg5), (math.max(arg4, arg5))))
	end,
	getLooseBoundingSphere = function(arg1)
		local var1 = table.create(#arg1)
		for k1, v1 in pairs(arg1) do
			var1[k1] = v1.Position
		end

		local var2 = var1[1]
		local var3 = var2
		local num1 = 0
		for k2, v2 in ipairs(var1) do
			local var4 = (v2 - var2).Magnitude
			if num1 >= var4 then
				continue
			end

			var3 = v2
			local var5 = var4
		end

		local var6 = var3
		local num2 = 0
		for k3, v3 in ipairs(var1) do
			local var7 = (v3 - var3).Magnitude
			if num2 >= var7 then
				continue
			end

			var6 = v3
			local var8 = var7
		end

		local var9 = (var3 + var6) * 0.5
		local var10 = (var3 - var6).Magnitude * 0.5
		for k4, v4 in ipairs(var1) do
			local var11 = (v4 - var9).Magnitude
			if var10 >= var11 then
				continue
			end

			var9 = var9 + (var11 - var10) * 0.5 * (v4 - var9).Unit
			var10 = (var11 + var10) * 0.5
		end

		return var9, var10
	end,
	sanitizeAngle = function(arg1)
		return (arg1 + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
	end,
	Round = function(arg1, arg2)
		local var1 = 10 ^ arg2
		return math.floor(arg1 * var1 + 0.5) / var1
	end,
	IsFinite = function(arg1)
		local bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end

		return bool2
	end,
}

tbl2.IsFiniteVector3 = function(arg1)
	local var1 = tbl2.IsFinite(arg1.X)
	return var1 and (tbl2.IsFinite(arg1.Y) and tbl2.IsFinite(arg1.Z))
end

tbl2.GetAngleBetweenXZVectors = function(arg1, arg2)
	return (math.atan2(arg2.X * arg1.Z - arg2.Z * arg1.X, arg2.X * arg1.X + arg2.Z * arg1.Z))
end

tbl2.RotateVectorByAngleAndRound = function(arg1, arg2, arg3)
	if 0 < arg1.Magnitude then
		arg1 = arg1.Unit
		return math.floor((math.atan2(arg1.Z, arg1.X) + arg2) / arg3 + 0.5) * arg3 - math.atan2(arg1.Z, arg1.X)
	end

	return 0
end

tbl2.GamepadLinearToCurve = function(arg1)
	local var2 = arg1.X
	local var3 = Vector2.new
	local num2 = 1
	if var2 < 0 then
		num2 = -1
	end

	local var5 = math.clamp((math.abs((math.abs(var2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	local var6 = math.clamp(((if 0 <= var5 then var5 * 0.35 / (0.35 - var5 + 1) else -(-var5 * 0.8 / (var5 + 0.8 + 1))) / 2 + 0.5) * num2, -1, 1)
	num2 = arg1.Y
	local num4 = 1
	if num2 < 0 then
		num4 = -1
	end

	local var8 = math.clamp((math.abs((math.abs(num2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	var2 = math.clamp(((if 0 <= var8 then var8 * 0.35 / (0.35 - var8 + 1) else -(-var8 * 0.8 / (var8 + 0.8 + 1))) / 2 + 0.5) * num4, -1, 1)
	return var3(var6, var2)
end

tbl2.ConvertCameraModeEnumToStandard = function(arg1)
	if arg1 == Enum.TouchCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.ComputerCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Classic or (arg1 == Enum.DevTouchCameraMovementMode.Classic or (arg1 == Enum.DevComputerCameraMovementMode.Classic or arg1 == Enum.ComputerCameraMovementMode.Classic)) then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Follow or (arg1 == Enum.DevTouchCameraMovementMode.Follow or (arg1 == Enum.DevComputerCameraMovementMode.Follow or arg1 == Enum.ComputerCameraMovementMode.Follow)) then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.TouchCameraMovementMode.Orbital or (arg1 == Enum.DevTouchCameraMovementMode.Orbital or (arg1 == Enum.DevComputerCameraMovementMode.Orbital or arg1 == Enum.ComputerCameraMovementMode.Orbital)) then
		return Enum.ComputerCameraMovementMode.Orbital
	end

	if arg1 == Enum.ComputerCameraMovementMode.CameraToggle or arg1 == Enum.DevComputerCameraMovementMode.CameraToggle then
		return Enum.ComputerCameraMovementMode.CameraToggle
	end

	if arg1 == Enum.DevTouchCameraMovementMode.UserChoice or arg1 == Enum.DevComputerCameraMovementMode.UserChoice then
		return Enum.DevComputerCameraMovementMode.UserChoice
	end

	return Enum.ComputerCameraMovementMode.Classic
end

local var4 = nil
local str1 = ""
tbl2.setMouseIconOverride = function(arg1)
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon ~= var4 then
		str1 = var5.Icon
	end

	var5.Icon = arg1
	var4 = arg1
end

tbl2.restoreMouseIcon = function()
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon == var4 then
		var5.Icon = str1
	end

	var4 = nil
end

local var5 = nil
local var6 = Enum.MouseBehavior.Default
tbl2.setMouseBehaviorOverride = function(arg1)
	if var2.MouseBehavior ~= var5 then
		var6 = var2.MouseBehavior
	end

	var2.MouseBehavior = arg1
	var5 = arg1
end

tbl2.restoreMouseBehavior = function()
	if var2.MouseBehavior == var5 then
		var2.MouseBehavior = var6
	end

	var5 = nil
end

local var7 = nil
local var8 = Enum.RotationType.MovementRelative
tbl2.setRotationTypeOverride = function(arg1)
	if var3.RotationType ~= var7 then
		var8 = var3.RotationType
	end

	var3.RotationType = arg1
	var7 = arg1
end

tbl2.restoreRotationType = function()
	if var3.RotationType == var7 then
		var3.RotationType = var8
	end

	var7 = nil
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController [ModuleScript]
-- y u r i

game:GetService("Players")
game:GetService("UserInputService")
UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
local str2 = "CameraUI"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local var3 = require(script.Parent:WaitForChild(str3))
var2.setCameraModeToastEnabled(false)
str1 = false
str3 = false
str2 = tick()
local bool1 = false
local bool2 = false
return function(arg1)
	local var5 = var1.getTogglePan()
	if arg1 and var5 ~= str1 then
		str3 = true
	end

	if str1 == var5 then
		if 3 < tick() - str2 then
			local var7 = var5
			if var7 then
				var7 = tick() - str2 < 3
			end

			var2.setCameraModeToastOpen(var7)
			if var5 then
				str3 = false
			end

			str2 = tick()
			str1 = var5
		end
	end

	if arg1 ~= bool1 then
		if arg1 then
			bool2 = var1.getTogglePan()
			var1.setTogglePan(true)
		else
			if not str3 then
				var1.setTogglePan(bool2)
			end
		end
	end

	if arg1 then
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		else
			var3.restoreMouseIcon()
			var3.restoreMouseBehavior()
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		end
	else
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
		else
			if var1.getHoldPan() then
				var3.restoreMouseIcon()
				var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
				var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
			else
				var3.restoreMouseIcon()
				var3.restoreMouseBehavior()
				var3.restoreRotationType()
			end
		end
	end

	bool1 = arg1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector [ModuleScript]
-- y u r i

local tbl1 = { JUMP_STUDS = 4, SETTLED_STUDS = 1, DEBOUNCE_SECONDS = 0.25 }
tbl1.shouldRecenter = function(arg1, arg2, arg3, arg4)
	if arg2 <= tbl1.JUMP_STUDS then
		return false
	end

	if arg1 ~= nil and tbl1.SETTLED_STUDS <= arg1 then
		return false
	end

	if arg3 ~= nil and arg4 - arg3 < tbl1.DEBOUNCE_SECONDS then
		return false
	end

	return true
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera [ModuleScript]
-- y u r i

local str1 = "CameraInput"
local str2 = "ZoomController"
local var1 = require(script.Parent:WaitForChild(str2))
local var2 = require(script.Parent:WaitForChild(str1))
local str3 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str3)).getUserFlag("UserVRRemoveLuaEdgeBlur")
local str4 = "BaseCamera"
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = game:GetService("VRService")
local var5 = game:GetService("Players").LocalPlayer
local var6 = game:GetService("Lighting")
local var7 = game:GetService("RunService")
local var8 = UserSettings():GetService("UserGameSettings")
str3 = setmetatable({}, var3)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(var3.new(), str3)
	var1.gamepadZoomLevels = { 0, 7 }
	var1.headScale = 1
	var1:SetCameraToSubjectDistance(7)
	var1.VRFadeResetTimer = 0
	var1.VREdgeBlurTimer = 0
	var1.gamepadResetConnection = nil
	var1.needsReset = true
	var1.recentered = false
	var1:Reset()
	return var1
end

str3.Reset = function(arg1)
	arg1.stepRotateTimeout = 0
end

str3.GetModuleName = function(_)
	return "VRBaseCamera"
end

str3.GamepadZoomPress = function(arg1)
	var3.GamepadZoomPress(arg1)
	arg1:GamepadReset()
	arg1:ResetZoom()
end

str3.GamepadReset = function(arg1)
	arg1.stepRotateTimeout = 0
	arg1.needsReset = true
end

str3.ResetZoom = function(arg1)
	var1.SetZoomParameters(arg1.currentSubjectDistance, 0)
	var1.ReleaseSpring()
end

str3.OnEnabledChanged = function(arg1)
	var3.OnEnabledChanged(arg1)
	if arg1.enabled then
		arg1.gamepadResetConnection = var2.gamepadReset:Connect(function()
			arg1:GamepadReset()
		end)

		arg1.thirdPersonOptionChanged = var4:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function()
			arg1:Reset()
		end)

		arg1.vrRecentered = var4.UserCFrameChanged:Connect(function(arg1, _)
			if arg1 == Enum.UserCFrame.Floor then
				arg1.recentered = true
			end
		end)

		return
	end

	if arg1.inFirstPerson then
		arg1:GamepadZoomPress()
	end

	if arg1.thirdPersonOptionChanged then
		arg1.thirdPersonOptionChanged:Disconnect()
		arg1.thirdPersonOptionChanged = nil
	end

	if arg1.vrRecentered then
		arg1.vrRecentered:Disconnect()
		arg1.vrRecentered = nil
	end

	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	if arg1.gamepadResetConnection then
		arg1.gamepadResetConnection:Disconnect()
		arg1.gamepadResetConnection = nil
	end

	if not str2 then
		arg1.VREdgeBlurTimer = 0
		arg1:UpdateEdgeBlur(var5, 1)
	end

	local var7 = var6:FindFirstChild("VRFade")
	if var7 then
		var7.Brightness = 0
	end
end

str3.OnCurrentCameraChanged = function(arg1)
	var3.OnCurrentCameraChanged(arg1)
	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	local var2 = workspace.CurrentCamera
	if var2 then
		arg1.cameraHeadScaleChangedConn = var2:GetPropertyChangedSignal("HeadScale"):Connect(function()
			arg1:OnHeadScaleChanged()
		end)

		arg1:OnHeadScaleChanged()
	end
end

str3.OnHeadScaleChanged = function(arg1)
	local var1 = workspace.CurrentCamera.HeadScale
	for k1, v1 in arg1.gamepadZoomLevels, nil do
		arg1.gamepadZoomLevels[k1] = v1 * var1 / arg1.headScale
	end

	arg1:SetCameraToSubjectDistance(arg1:GetCameraToSubjectDistance() * var1 / arg1.headScale)
	arg1.headScale = var1
end

str3.GetVRFocus = function(arg1, arg2, arg3)
	local var1 = Vector3.new(arg1.cameraTranslationConstraints.x, math.min(1, arg1.cameraTranslationConstraints.y + arg3), arg1.cameraTranslationConstraints.z)
	arg1.cameraTranslationConstraints = var1
	local var2 = arg2 + Vector3.new(0, arg1:GetCameraHeight(), 0)
	local var3 = arg1.cameraTranslationConstraints.y
	return (CFrame.new(Vector3.new(arg2.x, (arg1.lastCameraFocus or arg2).y, arg2.z):Lerp(var2, var3)))
end

str3.StartFadeFromBlack = function(arg1)
	if var8.VignetteEnabled == false then
		return
	end

	local var2 = var6:FindFirstChild("VRFade")
	if not var2 then
		var2 = Instance.new("ColorCorrectionEffect")
		var2.Name = "VRFade"
		var2.Parent = var6
	end

	var2.Brightness = -1
	arg1.VRFadeResetTimer = 0.1
end

str3.UpdateFadeFromBlack = function(arg1, arg2)
	local var1 = var6:FindFirstChild("VRFade")
	if 0 < arg1.VRFadeResetTimer then
		local var2 = math.max(arg1.VRFadeResetTimer - arg2, 0)
		arg1.VRFadeResetTimer = var2
		var2 = var6:FindFirstChild("VRFade")
		if not (var2 and var2.Brightness < 0) then
			return
		end

		if var2.Brightness >= 0 then
			return
		end

		local var3 = math.min(var2.Brightness + arg2 * 10, 0)
		var2.Brightness = var3
		return
	end

	if var1 then
		var1.Brightness = 0
	end
end

str3.StartVREdgeBlur = function(arg1, arg2, arg3)
	if not arg3 and var8.VignetteEnabled == false then
		return
	end

	local var1 = nil
	var1 = workspace.CurrentCamera:FindFirstChild("VRBlurPart")
	if not var1 then
		var1 = Instance.new("Part")
		var1.Name = "VRBlurPart"
		var1.Parent = workspace.CurrentCamera
		var1.CanTouch = false
		var1.CanCollide = false
		var1.CanQuery = false
		var1.Anchored = true
		var1.Size = Vector3.new(0.44, 0.47, 1)
		var1.Transparency = 1
		var1.CastShadow = false
		var7.RenderStepped:Connect(function(_)
			local var2 = var4:GetUserCFrame(Enum.UserCFrame.Head)
			local var3 = workspace.CurrentCamera.CFrame * (CFrame.new(var2.p * workspace.CurrentCamera.HeadScale) * (var2 - var2.p))
			var1.CFrame = var3 * CFrame.Angles(0, 3.1415926535897931, 0) + var3.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
			var1.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
		end)

	end

	local var2 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var3 = nil
	var3 = var2 and var2:FindFirstChild("VRBlur")
	if not var3 then
		var2 = var2 or Instance.new("ScreenGui")
		var2.Name = "VRBlurScreen"
		var2.Parent = arg2.PlayerGui
		var2.Adornee = var1
		var3 = Instance.new("ImageLabel")
		var3.Name = "VRBlur"
		var3.Parent = var2
		var3.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
		var3.AnchorPoint = Vector2.new(0.5, 0.5)
		var3.Position = UDim2.new(0.5, 0, 0.5, 0)
		var3.Size = UDim2.fromScale(workspace.CurrentCamera.ViewportSize.X * 2.3 / 512, workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512)
		var3.BackgroundTransparency = 1
		var3.Active = true
		var3.ScaleType = Enum.ScaleType.Stretch
	end

	var3.Visible = true
	var3.ImageTransparency = 0
	arg1.VREdgeBlurTimer = 0.14
end

str3.UpdateEdgeBlur = function(arg1, arg2, arg3)
	local var3 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var4 = nil
	if var3 then
		var4 = var3:FindFirstChild("VRBlur")
	end

	if var4 then
		if 0 < arg1.VREdgeBlurTimer then
			local var5 = arg1.VREdgeBlurTimer - arg3
			arg1.VREdgeBlurTimer = var5
			var5 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
			local var6 = var5:FindFirstChild("VRBlur")
			if not (var5 and var6) then
				return
			end

			var6 = var5:FindFirstChild("VRBlur")
			if not var6 then
				return
			end

			var6.ImageTransparency = 1 - math.clamp(arg1.VREdgeBlurTimer, 0.01, 0.14) * 7.1428571428571423
			return
		end

		var4.Visible = false
	end
end

str3.GetCameraHeight = function(arg1)
	if not arg1.inFirstPerson then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

str3.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectCFrame(arg1)
	if not var2 then
		return var4
	end

	if var2:IsA("Humanoid") then
		if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
			var4 = arg1.lastSubjectCFrame
		end
	end

	if var4 then
		arg1.lastSubjectCFrame = var4
	end

	return var4
end

str3.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectPosition(arg1)
	if var2 then
		if var2:IsA("Humanoid") then
			if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
				var4 = arg1.lastSubjectPosition
			end
		else
			if var2:IsA("VehicleSeat") then
				var4 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
			end
		end
	else
		return nil
	end

	arg1.lastSubjectPosition = var4
	return var4
end

str3.getRotation = function(arg1, arg2)
	local var3 = var2.getRotation(arg2)
	local num2 = 0
	if var8.VRSmoothRotationEnabled then
		return var3.X
	end

	if 0.03 < math.abs(var3.X) then
		if 0 < arg1.stepRotateTimeout then
			local var4 = arg1.stepRotateTimeout - arg2
			arg1.stepRotateTimeout = var4
		end

		if arg1.stepRotateTimeout <= 0 then
			num2 = 1
			if var3.X < 0 then
				num2 = -1
			end

			arg1:StartFadeFromBlack()
			arg1.stepRotateTimeout = 0.25
			num2 = num2 * 0.52359877559829882
			return num2
		end
	end

	if math.abs(var3.X) < 0.02 then
		arg1.stepRotateTimeout = 0
	end

	return num2
end

str3.HandleSubjectDistance = function(arg1, arg2)
	if arg2 and (arg2.IsInFirstPerson and arg2:IsInFirstPerson()) then
		arg1:SetCameraToSubjectDistance(0)
	end
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.LegacyCamera [ModuleScript]
-- y u r i

Vector2.new()
local str1 = "CameraUtils"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str2))
local str3 = "BaseCamera"
str1 = require(script.Parent:WaitForChild(str3))
local var2 = game:GetService("Players")
str2 = setmetatable({}, str1)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(str1.new(), str2)
	var1.cameraType = Enum.CameraType.Fixed
	var1.lastUpdate = tick()
	var1.lastDistanceToSubject = nil
	return var1
end

str2.GetModuleName = function(_)
	return "LegacyCamera"
end

str2.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return str1.SetCameraToSubjectDistance(var1, var2)
end

str2.Update = function(arg1, arg2)
	if not arg1.cameraType then
		return nil, nil
	end

	local var3 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4.CFrame
	local var6 = var4.Focus
	local var7 = var2.LocalPlayer
	local var8 = var1.getRotation(arg2)
	if arg1.lastUpdate == nil or 1 < var3 - arg1.lastUpdate then
		arg1.lastDistanceToSubject = nil
	end

	local var10 = arg1:GetSubjectPosition()
	if arg1.cameraType == Enum.CameraType.Fixed then
		if var10 and (var7 and var4) then
			var5 = CFrame.new(var4.CFrame.p, var4.CFrame.p + arg1:GetCameraToSubjectDistance() * arg1:CalculateNewLookVectorFromArg(nil, var8))
			var6 = var4.Focus
		end
	else
		if arg1.cameraType == Enum.CameraType.Attach then
			local var12 = arg1:GetSubjectCFrame()
			local var13, var14 = var12:ToEulerAnglesYXZ()
			var6 = CFrame.new(var12.p) * CFrame.fromEulerAnglesYXZ(math.clamp(var4.CFrame:ToEulerAnglesYXZ() - var8.Y, -1.3962634015954636, 1.3962634015954636), var14, 0)
			var5 = var6 * CFrame.new(0, 0, arg1:StepZoom())
		else
			if arg1.cameraType == Enum.CameraType.Watch then
				if var10 then
					if var7 then
						if var4 then
							local var15 = nil
							if var10 == var4.CFrame.p then
								warn("Camera cannot watch subject in same position as itself")
								return var4.CFrame, var4.Focus
							end

							local var18 = arg1:GetHumanoid()
							if var18 then
								if var18.RootPart then
									local var20 = var10 - var4.CFrame.p
									var15 = var20.unit
									if arg1.lastDistanceToSubject and arg1.lastDistanceToSubject == arg1:GetCameraToSubjectDistance() then
										arg1:SetCameraToSubjectDistance(var20.magnitude)
									end
								end
							end

							local var21 = arg1:GetCameraToSubjectDistance()
							var6 = CFrame.new(var10)
							var5 = CFrame.new(var10 - var21 * arg1:CalculateNewLookVectorFromArg(var15, var8), var10)
							arg1.lastDistanceToSubject = var21
						end
					end
				end
			else
				return var4.CFrame, var4.Focus
			end
		end
	end

	arg1.lastUpdate = var3
	return var5, var6
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.TransparencyController [ModuleScript]
-- y u r i

local str1 = "CameraUtils"
local var1 = game:GetService("VRService")
local var2 = require(script.Parent:WaitForChild(str1))
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.transparencyDirty = false
	var1.enabled = false
	var1.lastTransparency = nil
	var1.descendantAddedConn = nil
	var1.descendantRemovingConn = nil
	var1.toolDescendantAddedConns = {}
	var1.toolDescendantRemovingConns = {}
	var1.cachedParts = {}
	return var1
end

tbl1.HasToolAncestor = function(arg1, arg2)
	if arg2.Parent == nil then
		return false
	end

	assert(arg2.Parent, "")
	local var1 = arg2.Parent:IsA("Tool")
	return var1 or arg1:HasToolAncestor(arg2.Parent)
end

local tbl2 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion",
}

tbl1.IsValidPartToModify = function(arg1, arg2)
	for k1, v1 in tbl2, nil do
		if not arg2:IsA(v1) then
			continue
		end

		return not arg1:HasToolAncestor(arg2)
	end

	return false
end

tbl1.CachePartsRecursive = function(arg1, arg2)
	if arg2 then
		if arg1:IsValidPartToModify(arg2) then
			arg1.cachedParts[arg2] = true
			arg1.transparencyDirty = true
		end

		for k1, v1 in pairs(arg2:GetChildren()) do
			arg1:CachePartsRecursive(v1)
		end
	end
end

tbl1.TeardownTransparency = function(arg1)
	for k1, v1 in pairs(arg1.cachedParts) do
		k1.LocalTransparencyModifier = 0
	end

	arg1.cachedParts = {}
	arg1.transparencyDirty = true
	arg1.lastTransparency = nil
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
		arg1.descendantAddedConn = nil
	end

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
		arg1.descendantRemovingConn = nil
	end

	for k2, v2 in pairs(arg1.toolDescendantAddedConns) do
		v2:Disconnect()
		arg1.toolDescendantAddedConns[k2] = nil
	end

	for k3, v3 in pairs(arg1.toolDescendantRemovingConns) do
		v3:Disconnect()
		arg1.toolDescendantRemovingConns[k3] = nil
	end
end

tbl1.SetupTransparency = function(arg1, arg2)
	arg1:TeardownTransparency()
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
	end

	arg1.descendantAddedConn = arg2.DescendantAdded:Connect(function(arg1)
		if arg1:IsValidPartToModify(arg1) then
			arg1.cachedParts[arg1] = true
			arg1.transparencyDirty = true
			return
		end

		if arg1:IsA("Tool") then
			if arg1.toolDescendantAddedConns[arg1] then
				arg1.toolDescendantAddedConns[arg1]:Disconnect()
			end

			arg1.toolDescendantAddedConns[arg1] = arg1.DescendantAdded:Connect(function(arg1)
				arg1.cachedParts[arg1] = nil
				if arg1:IsA("BasePart") or arg1:IsA("Decal") then
					arg1.LocalTransparencyModifier = 0
				end
			end)

			if arg1.toolDescendantRemovingConns[arg1] then
				arg1.toolDescendantRemovingConns[arg1]:disconnect()
			end

			arg1.toolDescendantRemovingConns[arg1] = arg1.DescendantRemoving:Connect(function(arg1)
				wait()
				if arg2 and (arg1 and (arg1:IsDescendantOf(arg2) and arg1:IsValidPartToModify(arg1))) then
					arg1.cachedParts[arg1] = true
					arg1.transparencyDirty = true
				end
			end)

		end
	end)

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
	end

	arg1.descendantRemovingConn = arg2.DescendantRemoving:connect(function(arg1)
		if arg1.cachedParts[arg1] then
			arg1.cachedParts[arg1] = nil
			arg1.LocalTransparencyModifier = 0
		end
	end)

	arg1:CachePartsRecursive(arg2)
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
	end
end

tbl1.SetSubject = function(arg1, arg2)
	local var1 = nil
	var1 = arg2 and (arg2:IsA("Humanoid") and arg2.Parent)
	if arg2 then
		if arg2:IsA("VehicleSeat") and arg2.Occupant then
			var1 = arg2.Occupant.Parent
		end
	end

	if var1 then
		arg1:SetupTransparency(var1)
		return
	end

	arg1:TeardownTransparency()
end

tbl1.Update = function(arg1, arg2)
	local var6 = workspace.CurrentCamera
	if var6 then
		if arg1.enabled then
			local var9 = (var6.Focus.p - var6.CoordinateFrame.p).magnitude
			local var11 = var9 < 2 and 1 - (var9 - 0.5) / 1.5 or 0
			if var11 < 0.5 then
				var11 = 0
			end

			if arg1.lastTransparency and (var11 < 1 and arg1.lastTransparency < 0.95) then
				local var13 = 2.8 * arg2
				var11 = arg1.lastTransparency + math.clamp(var11 - arg1.lastTransparency, -var13, var13)
			else
				arg1.transparencyDirty = true
			end

			local num3 = 1
			var11 = math.clamp(var2.Round(var11, 2), 0, num3)
			if arg1.transparencyDirty or arg1.lastTransparency ~= var11 then
				for k1, v1 in pairs(arg1.cachedParts) do
					if var1.VREnabled and var1.AvatarGestures then
						if k1.Parent:IsA("Accessory") and ({
							[Enum.AccessoryType.Hat] = true,
							[Enum.AccessoryType.Hair] = true,
							[Enum.AccessoryType.Face] = true,
							[Enum.AccessoryType.Eyebrow] = true,
							[Enum.AccessoryType.Eyelash] = true,
						})[k1.Parent.AccessoryType] or k1.Name == "Head" then

							k1.LocalTransparencyModifier = var11
						else
							k1.LocalTransparencyModifier = 0
							continue
						end
					else
						k1.LocalTransparencyModifier = var11
					end
				end

				arg1.transparencyDirty = false
				arg1.lastTransparency = var11
			end
		end
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController [ModuleScript]
-- y u r i

local str1 = "Popper"
local var1 = require(script:WaitForChild(str1))
local var2 = game:GetService("Players").LocalPlayer
assert(var2)
local var3 = nil
local var4 = nil
local function updateBounds()
	var3 = var2.CameraMinZoomDistance
	var4 = var2.CameraMaxZoomDistance
end

var2:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(updateBounds)
var2:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(updateBounds)
var3 = var2.CameraMinZoomDistance
var4 = var2.CameraMaxZoomDistance
var2 = {}
var2.__index = var2
local var5 = math.clamp
var2.new = function(arg1, arg2, arg3, arg4)
	arg2 = var5(arg2, arg3, arg4)
	return (setmetatable({ freq = arg1, x = arg2, v = 0, minValue = arg3, maxValue = arg4, goal = arg2 }, var2))
end

local var6 = math.exp
var2.Step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = var2 * arg2
	local var4 = arg1.v
	local var5 = var1 - arg1.x
	local var7 = var6(-var3)
	local var11 = var1 + (var4 * arg2 - var5 * (var3 + 1)) * var7
	local var12 = arg1.minValue
	local var13 = arg1.maxValue
	local var14 = ((var5 * var2 - var4) * var3 + var4) * var7
	if var11 < var12 then
		var11 = var12
		var14 = 0
	elseif var13 < var11 then
		var11 = var13
		var14 = 0
	end

	arg1.x = var11
	arg1.v = var14
	return var11
end

updateBounds = var2.new(4.5, 12.5, 0.5, var4)
local num1 = 0
local var7 = math.max
str1 = math.min
return {
	Update = function(arg1, arg2, arg3)
		local num2 = math.huge
		if 1 < updateBounds.goal then
			local var8 = updateBounds.goal
			local var9 = num1
			local var10 = var3
			var8 = var5(var8 + var9 * (var8 * 0.0375 + 1), var10, var4)
			local var11 = updateBounds.x
			if var8 < 1 then
				var8 = var9 <= 0 and var10 or 1
			end

			local var12 = var7(var11, var8)
			num2 = var1(arg2 * CFrame.new(0, 0, 0.5), var12 - 0.5, arg3) + 0.5
		end

		updateBounds.minValue = 0.5
		updateBounds.maxValue = str1(var4, num2)
		local var13 = arg1
		return updateBounds:Step(var13)
	end,
	GetZoomRadius = function()
		return updateBounds.x
	end,
	SetZoomParameters = function(arg1, arg2)
		updateBounds.goal = arg1
		num1 = arg2
	end,
	ReleaseSpring = function()
		updateBounds.x = updateBounds.goal
		updateBounds.v = 0
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper [ModuleScript]
-- y u r i

local var1 = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "FlagUtil"
local str2 = "CameraWrapper"
local str3 = "ConnectionUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
local var4 = require(var1:WaitForChild(str3))
str2 = var2.getUserFlag("UserCurrentCameraUpdate2")
local var5 = game:GetService("Players")
str1 = var2.getUserFlag("UserRaycastUpdateAPI2")
str3 = var2.getUserFlag("UserPlayerConnectionMemoryLeak")
local var6 = if str2 then var3.new() else nil
local var7 = if str2 then nil else game.Workspace.CurrentCamera
if str2 then
	var6:Enable()
end

local var8 = RaycastParams.new()
var8.IgnoreWater = true
var8.FilterType = Enum.RaycastFilterType.Exclude
var8.RespectCanCollide = true
local var9 = RaycastParams.new()
var9.IgnoreWater = true
var9.FilterType = Enum.RaycastFilterType.Include
local var10 = math.min
local var11 = math.tan
local var12 = math.rad
local var13 = Ray.new
local var16 = if str3 then var4.new() else nil
local var17 = nil
local var18 = nil
local var19 = nil
if str2 then
	local function updateProjection()
		local var1 = var6:getCamera()
		local var2 = var1.ViewportSize
		var19 = var11(var12(var1.FieldOfView) / 2) * 2
		var18 = var2.X / var2.Y * var19
	end

	var6:Connect("FieldOfView", updateProjection)
	var6:Connect("ViewportSize", updateProjection)
	local var20 = var6:getCamera()
	local var21 = var20.ViewportSize
	var19 = var11(var12(var20.FieldOfView) / 2) * 2
	var18 = var21.X / var21.Y * var19
	var17 = var6:getCamera().NearPlaneZ
	var6:Connect("NearPlaneZ", function()
		var17 = var6:getCamera().NearPlaneZ
	end)

else
	updateProjection = function()
		local var1 = var7.ViewportSize
		var19 = var11(var12(var7.FieldOfView) / 2) * 2
		var18 = var1.X / var1.Y * var19
	end

	var7:GetPropertyChangedSignal("FieldOfView"):Connect(updateProjection)
	var7:GetPropertyChangedSignal("ViewportSize"):Connect(updateProjection)
	local var22 = var7.ViewportSize
	var19 = var11(var12(var7.FieldOfView) / 2) * 2
	var17 = var7.NearPlaneZ
	var7:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		var17 = var7.NearPlaneZ
	end)

	var18 = var22.X / var22.Y * var19
end

updateProjection = {}
local tbl1 = {}
local function playerAdded(arg1)
	local function characterAdded(arg1)
		tbl1[arg1] = arg1
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	local function characterRemoving()
		tbl1[arg1] = nil
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	if str3 then
		local var2 = characterAdded
		var16:trackConnection(("%*CharacterAdded"):format(arg1.UserId), arg1.CharacterAdded:Connect(var2))
		var2 = characterRemoving
		var16:trackConnection(("%*CharacterRemoving"):format(arg1.UserId), arg1.CharacterRemoving:Connect(var2))
	else
		arg1.CharacterAdded:Connect(characterAdded)
		arg1.CharacterRemoving:Connect(characterRemoving)
	end

	if arg1.Character then
		tbl1[arg1] = arg1.Character
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end
end

var5.PlayerAdded:Connect(playerAdded)
var5.PlayerRemoving:Connect(function(arg1)
	tbl1[arg1] = nil
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end

	if str3 then
		var16:disconnect((("%*CharacterAdded"):format(arg1.UserId)))
		var16:disconnect((("%*CharacterRemoving"):format(arg1.UserId)))
	end
end)

local function refreshIgnoreList()
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end
end

for k1, v1 in ipairs(var5:GetPlayers()) do
	playerAdded(v1)
end

updateProjection = {}
local num1 = 1
for k2, v2 in pairs(tbl1) do
	updateProjection[num1] = v2
	num1 = num1 + 1
end

tbl1 = nil
refreshIgnoreList = nil
if str2 then
	var6:Connect("CameraSubject", function()
		local var2 = var6:getCamera().CameraSubject
		if var2 and var2:IsA("Humanoid") then
			refreshIgnoreList = var2.RootPart
			return
		end

		if var2 and var2:IsA("BasePart") then
			refreshIgnoreList = var2
			return
		end

		refreshIgnoreList = nil
	end)

else
	var7:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		local var1 = var7.CameraSubject
		if var1:IsA("Humanoid") then
			refreshIgnoreList = var1.RootPart
			return
		end

		if var1:IsA("BasePart") then
			refreshIgnoreList = var1
			return
		end

		refreshIgnoreList = nil
	end)

end

local num2 = 0
local num3 = 0.2
local function queryPoint(arg1, arg2, arg3, arg4)
	debug.profilebegin("queryPoint")
	arg3 = arg3 + var17
	local var1 = arg1 + arg2 * arg3
	local num1 = math.huge
	local num2 = math.huge
	local var2 = arg1
	local num3 = 0
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var3 = #updateProjection
		while true do
			local var7 = workspace:Raycast(var2, var1 - var2, var8)
			if var7 then
				local var10 = var7.Position
				num3 = num3 + 1
				local var12 = var7.Instance
				local var14 = (var10 - arg1).Magnitude
				if 64 <= num3 then
					num2 = var14
				else
					local bool2 = false
					if 1 - (1 - var12.Transparency) * (1 - var12.LocalTransparencyModifier) < 0.25 then
						if not str1 then
							bool2 = var12.CanCollide
							if bool2 then
								bool2 = false
								if tbl1 ~= (var12:GetRootPart() or var12) then
									bool2 = not var12:IsA("TrussPart")
								end
							end
						end
					end

					if bool2 then
						var9.FilterDescendantsInstances = { var12 }
						if workspace:Raycast(var1, var10 - var1, var9) then
							local var15
							if arg4 then
								var15 = workspace:Raycast(arg4, var1 - arg4, var9)
								if not var15 then
									var15 = workspace:Raycast(var1, arg4 - var1, var9)
								end
							else
								var15 = false
							end

							if var15 then
								num2 = var14
							elseif arg3 < num1 then
								num1 = var14
							end
						else
							num2 = var14
						end
					end
				end

				var8:AddToFilter(var12)
				var2 = var10 - arg2 * 0.001
				if num2 >= math.huge and var12 then
					continue
				end
			end
		end
	else
		repeat
			local var19, var20 = workspace:FindPartOnRayWithIgnoreList(var13(var2, var1 - var2), updateProjection, false, true)
			num3 = num3 + 1
			if var19 then
				local var21 = 64 <= num3
				local bool4 = false
				if 1 - (1 - var19.Transparency) * (1 - var19.LocalTransparencyModifier) < 0.25 then
					if not str1 then
						bool4 = var19.CanCollide
						if bool4 then
							bool4 = false
							if tbl1 ~= (var19:GetRootPart() or var19) then
								bool4 = not var19:IsA("TrussPart")
							end
						end
					end
				end

				if bool4 or var21 then
					bool4 = { var19 }
					var15 = (var20 - arg1).Magnitude
					if workspace:FindPartOnRayWithWhitelist(var13(var1, var20 - var1), bool4, true) then
						if not var21 then
							local bool5 = false
							if arg4 and workspace:FindPartOnRayWithWhitelist(var13(var1, arg4 - var1), bool4, true) then
								num2 = var15
							elseif arg3 < num1 then
								num1 = var15
							end
						else
							num2 = var15
						end
					else
						num2 = var15
					end
				end

				updateProjection[#updateProjection + 1] = var19
			end

			local var22 = var20 - arg2 * 0.001
		until num2 < math.huge or (not var19)

		local var23 = updateProjection
		for i1 = #var23, var3 + 1, -1 do
			var23[i1] = nil
		end
	end

	debug.profileend()
	return num1 - var17, num2 - var17
end

num1 = function(arg1, arg2)
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var2 = workspace:Raycast(arg1, arg2, var8)
		if var2 then
			return var2.Position, true
		end
	else
		local var3 = #updateProjection
		repeat
			local var7, var9 = workspace:FindPartOnRayWithIgnoreList(var13(arg1, arg2), updateProjection, false, true)
			if var7 then
				if var7.CanCollide then
					local var11 = updateProjection
					for i1 = #var11, var3 + 1, -1 do
						var11[i1] = nil
					end

					return var9, true
				end

				updateProjection[#updateProjection + 1] = var7
			end
		until not var7

		local var12 = updateProjection
		for i2 = #var12, var3 + 1, -1 do
			var12[i2] = nil
		end
	end

	return arg1 + arg2, false
end

local tbl2 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(num2, num3),
}

local function queryViewport(arg1, arg2)
	debug.profilebegin("queryViewport")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	local var5 = if str2 then var6:getCamera() else var7
	var7 = var5
	var5 = var7.ViewportSize
	local num1 = math.huge
	local num2 = math.huge
	for i1 = 0, 1 do
		for i2 = 0, 1 do
			local var8 = var2 * ((i1 - 0.5) * var18)
			local var11, var12 = queryPoint(var1 + var17 * (var8 + var3 * ((i2 - 0.5) * var19)), var4, arg2, var7:ViewportPointToRay(var5.x * i1, var5.y * i2).Origin)
			if var12 < num1 then
				num1 = var12
			end

			if var11 >= num2 then
				continue
			end

			num2 = var11
		end
	end

	debug.profileend()
	return num2, num1
end

local function testPromotion(arg1, arg2, arg3)
	debug.profilebegin("testPromotion")
	debug.profilebegin("extrapolate")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	for i1 = 0, var10(1.25, arg3.rotVelocity.magnitude + (num1(var1, arg3.posVelocity * 1.25) - var1).Magnitude / arg3.posVelocity.magnitude), 0.0625 do
		local var5 = arg3.extrapolate(i1)
		if arg2 > queryPoint(var5.p, -var5.lookVector, arg2) then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profilebegin("testOffsets")
	for k1, v1 in ipairs(tbl2) do
		local var6 = num1(var1, var2 * v1.x + var3 * v1.y)
		if queryPoint(var6, (var1 + var4 * arg2 - var6).Unit, arg2) ~= math.huge then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profileend()
	return true
end

return function(arg1, arg2, arg3)
	debug.profilebegin("popper")
	local var1 = refreshIgnoreList and refreshIgnoreList:GetRootPart() or refreshIgnoreList
	tbl1 = var1
	local var4, var5 = queryViewport(arg1, arg2)
	var1 = arg2
	if var5 < var1 then
		var1 = var5
	end

	if var4 < var1 and testPromotion(arg1, arg2, arg3) then
		var1 = var4
	end

	tbl1 = nil
	debug.profileend()
	return var1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.MouseLockController [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local str2 = "CameraUtils"
local var2 = game:GetService("Players")
str1 = game:GetService("ContextActionService")
local var3 = game:GetService("UserInputService")
local var4 = UserSettings().GameSettings
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = var1.getUserFlag("UserFixStuckShiftLock")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.isMouseLocked = false
	var1.savedMouseCursor = nil
	var1.boundKeys = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift }
	var1.mouseLockToggledEvent = Instance.new("BindableEvent")
	local var6 = script:FindFirstChild("BoundKeys")
	if var6 then
		if not var6:IsA("StringValue") then
			if var6 then
				var6:Destroy()
			end

			var6 = Instance.new("StringValue")
			assert(var6, "")
			var6.Name = "BoundKeys"
			var6.Value = "LeftShift,RightShift"
			var6.Parent = script
		end
	end

	if var6 then
		var6.Changed:Connect(function(arg1)
			var1:OnBoundKeysObjectChanged(arg1)
		end)

		var1:OnBoundKeysObjectChanged(var6.Value)
	end

	var4.Changed:Connect(function(arg1)
		if arg1 == "ControlMode" or arg1 == "ComputerMovementMode" then
			var1:UpdateMouseLockAvailability()
		end
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var3:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var1:UpdateMouseLockAvailability()
	return var1
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.isMouseLocked
end

tbl1.GetBindableToggleEvent = function(arg1)
	return arg1.mouseLockToggledEvent.Event
end

tbl1.GetMouseLockOffset = function(_)
	return Vector3.new(1.75, 0, 0)
end

tbl1.UpdateMouseLockAvailability = function(arg1)
	local var1 = var3.PreferredInput == Enum.PreferredInput.KeyboardAndMouse
	var1 = var1 and (var2.LocalPlayer.DevEnableMouseLock and (var4.ControlMode == Enum.ControlMode.MouseLockSwitch and (not (var4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove) and (not (var2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable)))))
	if var1 ~= arg1.enabled then
		arg1:EnableMouseLock(var1)
	end
end

tbl1.OnBoundKeysObjectChanged = function(arg1, arg2)
	arg1.boundKeys = {}
	for k1 in string.gmatch(arg2, "[^%s,]+") do
		for k2, v1 in pairs(Enum.KeyCode:GetEnumItems()) do
			if k1 ~= v1.Name then
				continue
			end

			arg1.boundKeys[#arg1.boundKeys + 1] = v1
			break
		end
	end

	arg1:UnbindContextActions()
	arg1:BindContextActions()
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = not arg1.isMouseLocked
	arg1.isMouseLocked = var1
	if arg1.isMouseLocked then
		var1 = script:FindFirstChild("CursorImage")
		if var1 and (var1:IsA("StringValue") and var1.Value) then
			var5.setMouseIconOverride(var1.Value)
		elseif var1 then
			var1:Destroy()
		end
	else
		var5.restoreMouseIcon()
	end

	arg1.mouseLockToggledEvent:Fire()
end

tbl1.DoMouseLockSwitch = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1:OnMouseLockToggled()
		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end

local var7 = Enum.ContextActionPriority.Medium.Value
tbl1.BindContextActions = function(arg1)
	local var1 = arg1.boundKeys
	str1:BindActionAtPriority("MouseLockSwitchAction", function(arg1, arg2, arg3)
		local var1 = arg1
		local var2 = arg2
		local var3 = arg3
		return arg1:DoMouseLockSwitch(var1, var2, var3)
	end, false, var7, unpack(var1))
end

tbl1.UnbindContextActions = function(_)
	str1:UnbindAction("MouseLockSwitchAction")
end

tbl1.IsMouseLocked = function(arg1)
	local var1 = arg1.enabled
	return var1 and arg1.isMouseLocked
end

tbl1.EnableMouseLock = function(arg1, arg2)
	if arg2 ~= arg1.enabled then
		arg1.enabled = arg2
		if arg1.enabled then
			arg1:BindContextActions()
			return
		end

		var5.restoreMouseIcon()
		arg1:UnbindContextActions()
		if var6 then
			if not arg1.isMouseLocked then
				return
			end

			arg1.isMouseLocked = false
			arg1.mouseLockToggledEvent:Fire()
			return
		end

		if arg1.isMouseLocked then
			arg1.mouseLockToggledEvent:Fire()
		end

		arg1.isMouseLocked = false
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec [ModuleScript]
-- y u r i

local var1 = require(game:GetService("CorePackages").Packages.Dev.JestGlobals)
local var2 = require(script.Parent.VRCameraTeleportDetector)
local var3 = var1.it
local var4 = var1.expect
local var5 = var2.shouldRecenter
local var6 = var2.JUMP_STUDS
local var7 = var2.SETTLED_STUDS
local var8 = var2.DEBOUNCE_SECONDS
var1.describe("VRCameraTeleportDetector.shouldRecenter", function()
	var3("fires on a discrete jump from rest (no prior step, never recentered)", function()
		local var1 = nil
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("fires on a discrete jump preceded by a near-still frame", function()
		local var1 = var7 - 0.5
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("does not fire for sub-threshold motion", function()
		local num1 = 0
		local var1 = var6 - 0.1
		local var2 = nil
		local num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
		num1 = 0
		var1 = 0
		var2 = nil
		num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
	end)

	var3("does not fire when the previous frame was already moving (continuous motion)", function()
		local var1 = var7 + 0.1
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(false)
	end)

	var3("does not fire within the debounce interval", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 - 0.01
		var4(var5(var1, var2, num1, var3)).toBe(false)
	end)

	var3("fires again once the debounce interval has elapsed", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 + 0.01
		var4(var5(var1, var2, num1, var3)).toBe(true)
	end)

	var3("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function()
		local num1 = 0
		local var1 = nil
		local var2 = nil
		local num2 = 0
		for i1 = 1, 120 do
			local var3 = var6 + 10
			if var5(var1, var3, var2, num1) then
				num2 = num2 + 1
			end

			local var7 = num1
			num1 = num1 + 0.016666666666666666
			local var8 = var3
		end

		var4(num2).toBe(1)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera [ModuleScript]
-- y u r i

local str1 = "VRBaseCamera"
local str2 = "CameraUtils"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str2))
local str4 = "VehicleCameraConfig"
str2 = game:GetService("RunService")
str3 = game:GetService("VRService")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local var6 = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild(str4))
local var7 = RaycastParams.new()
var7.FilterType = Enum.RaycastFilterType.Exclude
var7.IgnoreWater = true
local var8 = OverlapParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local var9 = setmetatable({}, var1)
var9.__index = var9
local num1 = 0.016666666666666666
var9.new = function()
	local var2 = setmetatable(var1.new(), var9)
	var2.skipOcclusion = true
	var2:Reset()
	if var2.thirdPersonOptionChanged then
		var2.thirdPersonOptionChanged:Disconnect()
		var2.thirdPersonOptionChanged = nil
	end

	str2.Stepped:Connect(function(_, arg2)
		num1 = arg2
	end)

	return var2
end

local tbl1 = { 0, 30 }
var9.Reset = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1, "VRVehicleCamera initialization error")
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	arg1.lastOrbitalDir = nil
	arg1.wasInFirstPerson = nil
	local var4 = var2:GetConnectedParts(true)
	table.insert(var4, var2)
	str1 = var2:FindFirstAncestorOfClass("Model")
	local var5, var6 = var3.getLooseBoundingSphere(var4)
	arg1.vehicleModel = str1 or var2.Parent
	arg1.assemblyRadius = math.max(var6, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var5
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.headScale * arg1.assemblyRadius / 10)
	end

	arg1.lastCameraFocus = nil
	if not arg1:IsInFirstPerson() then
		arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
	end

	arg1.needsReset = false
end

var9._getThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * var6.verticalCenterOffset, 0)
end

var9._getFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = var5.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_getThirdPersonLocalOffset()
end

local function findObstructions(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return 0, {}
	end

	local var3 = str3:GetUserCFrame(Enum.UserCFrame.Head)
	local var4 = arg1 * (CFrame.new(var3.Position * var2.HeadScale) * var3.Rotation)
	local var6 = arg2.Position
	local var9 = var4.Position - var6
	local var11 = var9.Magnitude
	if var11 < 0.5 then
		return 0, {}
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var12 = var5
	var12 = var12 and var5.Character
	if var12 then
		table.insert(tbl1, var12)
	end

	var7.FilterDescendantsInstances = tbl1
	local var15 = workspace:Raycast(var6, var9, var7)
	local var16 = (var15.Position - var6).Magnitude
	if var15 and var16 < var11 then
		local var17 = var15.Position
		local var18 = var4.Position
		local var19 = math.max(math.clamp((1 - -var9.Unit:Dot(var4.LookVector)) / 0.13397459621556129, 0, 1), 1 - var16 / arg3, 0.15)
		local var20 = Vector3.new(2, 2, (var18 - var17).Magnitude)
		local var21 = CFrame.lookAt((var17 + var18) / 2, var18)
		var8.FilterDescendantsInstances = tbl1
		return var19, (workspace:GetPartBoundsInBox(var21, var20, var8))
	end

	return 0, {}
end

var9._vrOccludeVignette = function(arg1, arg2, arg3, arg4)
	local var1 = CFrame.new(arg2.Position + arg3 * arg4) * CFrame.Angles(0, math.atan2(arg3.X, arg3.Z), 0)
	local var3 = var4:FindFirstChild("VRFade")
	local var6, var7 = findObstructions(var1, arg2, arg4, arg1.vehicleModel)
	if not var3 then
		var3 = Instance.new("ColorCorrectionEffect")
		var3.Name = "VRFade"
		var3.Parent = var4
	end

	var3.Brightness = -var6
	local var8
	if arg1.lastOccludedParts then
		for k1, v1 in arg1.lastOccludedParts, nil do
			v1.LocalTransparencyModifier = 0
		end
	end

	if 0 < (#var7) then
		for k2, v2 in var7, nil do
			v2.LocalTransparencyModifier = 1
		end

		arg1:StartVREdgeBlur(var5, true)
	end

	arg1.lastOccludedParts = var7
	return var1
end

var9.Update = function(arg1)
	local var1 = num1
	num1 = 0
	arg1:UpdateFadeFromBlack(var1)
	arg1:UpdateEdgeBlur(var5, var1)
	local var2, var3 = arg1:_updateStepRotation(var1)
	return var2, var3
end

local var10 = var3.mapClamp
local function vrOccludeDisplace(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	local var3 = CFrame.new(arg1.Position + arg2 * arg3) * CFrame.Angles(0, math.atan2(arg2.X, arg2.Z), 0)
	if not var2 then
		return var3
	end

	local var4 = arg1.Position
	local var6 = (var3.Position - var4) * Vector3.new(1, 0, 1)
	local var9 = var6.Magnitude
	if var9 < 0.5 then
		return var3
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var10 = var5
	var10 = var10 and var5.Character
	if var10 then
		table.insert(tbl1, var10)
	end

	var7.FilterDescendantsInstances = tbl1
	local var14 = workspace:Raycast(var4, var6, var7)
	local var15 = var6.Unit
	local var16 = (var14.Position - var4).Magnitude - 0.5
	if var14 and (var14.Normal:Dot(var15) < 0 and var16 < var9) then
		return CFrame.new(arg1.Position + var15 * math.max(var16, 0.5)) * var3.Rotation
	end

	return var3
end

var9._updateStepRotation = function(arg1, arg2)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var3 = arg1:GetSubjectCFrame()
	local var4 = CFrame.new(var3 * arg1:_getThirdPersonLocalOffset():Lerp(arg1:_getFirstPersonLocalOffset(var3), (var10(var1, 0.5, arg1.assemblyRadius, 1, 0))) + Vector3.new(0, arg1:GetCameraHeight(), 0))
	if arg1.needsReset or arg1.recentered then
		arg1.lastOrbitalDir = nil
		arg1.needsReset = false
		arg1.recentered = false
	end

	local var7 = arg1.lastOrbitalDir
	if not var7 then
		arg1:StartFadeFromBlack()
		var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
	end

	local var9 = 2 < (arg1:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude
	if not var9 then
		local var11 = arg1:getRotation(arg2)
		if 0 < math.abs(var11) then
			var7 = (CFrame.Angles(0, -var11, 0) * CFrame.new(var7)).Position.Unit
			arg1.lastRotateTime = os.clock()
		end
	else
		var2.getRotation(arg2)
	end

	local var12 = nil
	if arg1:IsInFirstPerson() then
		if not arg1.wasInFirstPerson or var9 then
			arg1.wasInFirstPerson = true
			var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
		end

		local var14 = math.atan2(-var3.LookVector.X, -var3.LookVector.Z)
		local var15 = (var14 - arg1.lastVehicleYaw + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
		if arg1.lastVehicleYaw and 0.001 < math.abs(var15) then
			var7 = (CFrame.Angles(0, var15, 0) * CFrame.new(var7)).Position.Unit
		end

		arg1.lastVehicleYaw = var14
		var12 = CFrame.new(var4.Position + var7 * var1) * CFrame.Angles(0, math.atan2(var7.X, var7.Z), 0)
	else
		arg1.wasInFirstPerson = false
		arg1.lastVehicleYaw = nil
		local var17 = arg1.lastRotateTime
		if var17 then
			var17 = os.clock() - arg1.lastRotateTime < var6.autocorrectDelay
		end

		if var9 and (not var17) then
			local var19 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
			var7 = var7:Lerp(var19, (math.min(0.01 + math.acos((math.clamp(var7:Dot(var19), -1, 1))) / 3.1415926535897931 * 0.05 + math.abs((var3.YVector:Dot((arg1:GetSubjectRotVelocity())))) * 0.02, 0.15)))
		end

		var12 = vrOccludeDisplace(var4, var7, var1, arg1.vehicleModel)
	end

	arg1.lastOrbitalDir = var7
	return var12, var12 * CFrame.new(0, 0, -var1)
end

return var9

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCamera [ModuleScript]
-- y u r i

UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraUtils"
require(script.Parent:WaitForChild(str2))
local str3 = "VRCameraTeleportDetector"
local var1 = require(script.Parent:WaitForChild(str3))
local str4 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str4))
local str5 = "VRBaseCamera"
str4 = require(script.Parent:WaitForChild(str5))
local var2 = game:GetService("Players")
local var3 = game:GetService("VRService")
str3 = str2.getUserFlag("UserVRRemoveLuaEdgeBlur")
local var4 = str2.getUserFlag("UserVRRecenterOnExternalTeleport")
local var5 = setmetatable({}, str4)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str4.new(), var5)
	var1.lastUpdate = tick()
	var1.focusOffset = CFrame.new()
	var1:Reset()
	local str1 = "ControlModule"
	var1.controlModule = require(var2.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild(str1))
	var1.savedAutoRotate = true
	return var1
end

var5.Reset = function(arg1)
	arg1.needsReset = true
	arg1.needsBlackout = true
	arg1.motionDetTime = 0
	arg1.blackOutTimer = 0
	arg1.lastCameraResetPosition = nil
	str4.Reset(arg1)
end

var5.Update = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	arg1:GetHumanoid()
	local var4 = var1.CFrame
	local var5 = var1.Focus
	local var6 = var2.LocalPlayer
	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:UpdateFadeFromBlack(arg2)
	if not str3 then
		arg1:UpdateEdgeBlur(var6, arg2)
	end

	local var7 = arg1.lastSubjectPosition
	local var8 = arg1:GetSubjectPosition()
	if arg1.needsBlackout then
		arg1:StartFadeFromBlack()
		local var9 = arg1.blackOutTimer + math.clamp(arg2, 0.0001, 0.1)
		arg1.blackOutTimer = var9
		if 0.1 < arg1.blackOutTimer and game:IsLoaded() then
			arg1.needsBlackout = false
			arg1.needsReset = true
		end
	end

	if var8 then
		if var6 then
			if var1 then
				var5 = arg1:GetVRFocus(var8, arg2)
				if arg1:IsInFirstPerson() then
					if var3.AvatarGestures then
						local var20, var21 = arg1:UpdateImmersionCamera(arg2, var4, var5, var7, var8)
						var4 = var20
						var5 = var21
					else
						local var22, var23 = arg1:UpdateFirstPersonTransform(arg2, var4, var5, var7, var8)
						var4 = var22
						var5 = var23
					end
				else
					if var3.ThirdPersonFollowCamEnabled then
						local var26, var27 = arg1:UpdateThirdPersonFollowTransform(arg2, var4, var5, var7, var8)
						var4 = var26
						var5 = var27
					else
						local var28, var29 = arg1:UpdateThirdPersonComfortTransform(arg2, var4, var5, var7, var8)
						var4 = var28
						var5 = var29
					end
				end

				arg1.lastCameraTransform = var4
				arg1.lastCameraFocus = var5
			end
		end
	end

	arg1.lastUpdate = tick()
	return var4, var5
end

var5.GetAvatarFeetWorldYValue = function(_)
	local var2 = workspace.CurrentCamera.CameraSubject
	if not var2 then
		return nil
	end

	if var2:IsA("Humanoid") and var2.RootPart then
		local var4 = var2.RootPart
		return var4.Position.Y - var4.Size.Y / 2 - var2.HipHeight
	end

	return nil
end

var5.UpdateFirstPersonTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	if arg1.needsReset then
		arg1:StartFadeFromBlack()
		arg1.needsReset = false
	end

	local var1 = var2.LocalPlayer
	if not str3 and 0.01 < (arg5 - arg6).magnitude then
		arg1:StartVREdgeBlur(var1)
	end

	local var3 = arg1:GetCameraLookVector()
	local var4 = arg1:getRotation(arg2)
	local num1 = 0
	local var5 = arg1:CalculateNewLookVectorFromArg(Vector3.new(var3.X, 0, var3.Z).Unit, Vector2.new(var4, num1))
	local var6 = arg4.p
	return CFrame.new(var6 - 0.5 * var5, var6), arg4
end

var5.UpdateImmersionCamera = function(arg1, arg2, arg3, _, arg5, arg6)
	local var7 = arg1:GetHumanoid()
	local var8 = arg1:GetSubjectCFrame()
	local var9 = workspace.CurrentCamera
	local var10 = var2.LocalPlayer.Character
	if not var7 then
		return var9.CFrame, var9.Focus
	end

	local var12 = var10:FindFirstChild("HumanoidRootPart")
	if not var12 then
		return var9.CFrame, var9.Focus
	end

	local var13 = nil
	if var4 then
		var13 = if arg5 then Vector3.new(arg6.X - arg5.X, 0, arg6.Z - arg5.Z).Magnitude else 0
	end

	arg1.characterOrientation = var12:FindFirstChild("CharacterAlignOrientation")
	if not arg1.characterOrientation then
		local var15 = var12:FindFirstChild("RootAttachment")
		if not var15 then
			return
		end

		arg1.characterOrientation = Instance.new("AlignOrientation")
		arg1.characterOrientation.Name = "CharacterAlignOrientation"
		arg1.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		arg1.characterOrientation.Attachment0 = var15
		arg1.characterOrientation.RigidityEnabled = true
		arg1.characterOrientation.Parent = var12
	end

	if arg1.characterOrientation.Enabled == false then
		arg1.characterOrientation.Enabled = true
	end

	if arg1.needsReset then
		arg1.needsReset = false
		arg1.savedAutoRotate = var7.AutoRotate
		var7.AutoRotate = false
		if var4 then
			var3:RecenterUserHeadCFrame()
			arg1.lastTeleportRecenter = tick()
		end

		arg1:StartFadeFromBlack()
		arg3 = var8
	else
		if var7.Sit then
			arg3 = var8
			if not str3 and 0.01 < (arg3.Position - var9.CFrame.Position).Magnitude then
				arg1:StartVREdgeBlur(var2.LocalPlayer)
			end
		else
			arg1.characterOrientation.CFrame = var9.CFrame * arg1.controlModule:GetEstimatedVRTorsoFrame()
			if 0 < arg1.controlModule.inputMoveVector.Magnitude then
				arg1.motionDetTime = 0.1
			end

			if 0 < arg1.controlModule.inputMoveVector.Magnitude or 0 < arg1.motionDetTime then
				local var16 = arg1.motionDetTime - arg2
				arg1.motionDetTime = var16
				if not str3 then
					arg1:StartVREdgeBlur(var2.LocalPlayer)
				end

				var16 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				local var17 = var10.HumanoidRootPart
				local var18 = var17.CFrame.LookVector
				local var19 = arg6 - (var9.CFrame * (var16.Rotation + var16.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var17.Size.Y / 2, 0) - Vector3.new(var18.X, 0, var18.Z).Unit * var17.Size.Y * 0.125).Position + var9.CFrame.Position
				arg3 = var9.CFrame.Rotation + Vector3.new(var19.X, arg6.Y, var19.Z)
			else
				if var4 and var1.shouldRecenter(arg1.prevSubjStep, var13, arg1.lastTeleportRecenter, tick()) then
					local var23 = var3:GetUserCFrame(Enum.UserCFrame.Head)
					local var24 = var10.HumanoidRootPart
					local var25 = var24.CFrame.LookVector
					local var26 = arg6 - (var9.CFrame * (var23.Rotation + var23.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var24.Size.Y / 2, 0) - Vector3.new(var25.X, 0, var25.Z).Unit * var24.Size.Y * 0.125).Position + var9.CFrame.Position
					var3:RecenterUserHeadCFrame()
					arg1:StartFadeFromBlack()
					arg3 = var9.CFrame.Rotation + Vector3.new(var26.X, arg6.Y, var26.Z)
					arg1.lastTeleportRecenter = tick()
				else
					arg3 = var9.CFrame.Rotation + Vector3.new(var9.CFrame.Position.X, arg6.Y, var9.CFrame.Position.Z)
				end
			end

			local var27 = arg1:getRotation(arg2)
			if 0 < math.abs(var27) then
				local var30 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				var30 = var30.Rotation + var30.Position * var9.HeadScale
				local var31 = arg3 * var30
				arg3 = CFrame.new(var31.Position) * CFrame.Angles(0, -math.rad(var27 * 90), 0) * var31.Rotation * var30:Inverse()
			end
		end
	end

	if var4 then
		arg1.prevSubjStep = var13
	end

	return arg3, arg3 * CFrame.new(0, 0, -0.5)
end

var5.UpdateThirdPersonComfortTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var4 = arg1:GetCameraToSubjectDistance()
	if var4 < 0.5 then
		var4 = 0.5
	end

	if arg5 ~= nil then
		if arg1.lastCameraFocus ~= nil then
			local var5 = arg1.controlModule:GetMoveVector()
			local bool1 = true
			if 0.01 >= (arg5 - arg6).magnitude then
				bool1 = 0.01 < var5.magnitude
			end

			if bool1 then
				arg1.motionDetTime = 0.1
			end

			local var6 = arg1.motionDetTime - arg2
			arg1.motionDetTime = var6
			if 0 < arg1.motionDetTime then
				bool1 = true
			end

			if bool1 and (not arg1.needsReset) then
				arg1.VRCameraFocusFrozen = true
				arg4 = arg1.lastCameraFocus
				return arg3, arg4
			end

			var6 = true
			if arg1.lastCameraResetPosition ~= nil then
				var6 = 1 < (arg6 - arg1.lastCameraResetPosition).Magnitude
			end

			local var7 = arg1:getRotation(arg2)
			if 0 < math.abs(var7) then
				arg3 = arg4 * CFrame.Angles(0, -var7, 0) * arg4:ToObjectSpace(arg3)
			end

			if arg1.VRCameraFocusFrozen and var6 or arg1.needsReset then
				var3:RecenterUserHeadCFrame()
				arg1.VRCameraFocusFrozen = false
				arg1.needsReset = false
				arg1.lastCameraResetPosition = arg6
				arg1:ResetZoom()
				arg1:StartFadeFromBlack()
				local var8 = arg1:GetHumanoid()
				local var9 = var8.Torso and var8.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
				local var10 = arg4.Position - Vector3.new(var9.X, 0, var9.Z) * var4
				arg3 = CFrame.new(var10, (Vector3.new(arg4.Position.X, var10.Y, arg4.Position.Z)))
			end
		end
	end

	return arg3, arg4
end

var5.UpdateThirdPersonFollowTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = workspace.CurrentCamera
	local var4 = arg1:GetCameraToSubjectDistance()
	local var5 = arg1:GetVRFocus(arg6, arg2)
	if arg1.needsReset then
		arg1.needsReset = false
		var3:RecenterUserHeadCFrame()
		arg1:ResetZoom()
		arg1:StartFadeFromBlack()
	end

	if arg1.recentered then
		local var7 = arg1:GetSubjectCFrame()
		if not var7 then
			return var1.CFrame, var1.Focus
		end

		arg3 = var5 * var7.Rotation * CFrame.new(0, 0, var4)
		arg1.focusOffset = var5:ToObjectSpace(arg3)
		arg1.recentered = false
		return arg3, var5
	end

	local var8 = arg1.controlModule
	local var12 = var5:ToWorldSpace(arg1.focusOffset)
	if 0.01 < (arg5 - arg6).magnitude or 0 < var8:GetMoveVector().magnitude then
		local var13 = var8:GetEstimatedVRTorsoFrame()
		local var14 = var1.CFrame * (var13.Rotation + var13.Position * var1.HeadScale)
		local var15 = var14.LookVector
		arg3 = var12:Lerp(CFrame.new(var1.CFrame.Position + (var5.Position - Vector3.new(var15.X, 0, var15.Z).Unit * var4) - var14.Position) * var12.Rotation, 0.01)
	else
		arg3 = var12
	end

	local var16 = arg1:getRotation(arg2)
	if 0 < math.abs(var16) then
		arg3 = var5 * CFrame.Angles(0, -var16, 0) * var5:ToObjectSpace(arg3)
	end

	arg1.focusOffset = var5:ToObjectSpace(arg3)
	arg4 = arg3 * CFrame.new(0, 0, -var4)
	if not str3 and 0.01 < (arg4.Position - var1.Focus.Position).Magnitude then
		arg1:StartVREdgeBlur(var2.LocalPlayer)
	end

	return arg3, arg4
end

var5.LeaveFirstPerson = function(arg1)
	str4.LeaveFirstPerson(arg1)
	arg1.needsReset = true
	if arg1.VRBlur then
		arg1.VRBlur.Visible = false
	end

	if arg1.characterOrientation then
		arg1.characterOrientation.Enabled = false
	end

	local var2 = arg1:GetHumanoid()
	if var2 then
		var2.AutoRotate = arg1.savedAutoRotate
	end
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseCamera [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
require(var1:WaitForChild(str2))
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local str4 = "ZoomController"
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "CameraToggleStateController"
str1 = require(script.Parent:WaitForChild(str4))
local str6 = "CameraInput"
str2 = require(script.Parent:WaitForChild(str5))
local str7 = "CameraUI"
str3 = require(script.Parent:WaitForChild(str6))
str4 = require(script.Parent:WaitForChild(str7))
Vector2.new(0, 0)
local var4 = game:GetService("VRService")
local var5 = UserSettings():GetService("UserGameSettings")
str5 = game:GetService("Players").LocalPlayer
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = var2.new()
	var1.gamepadZoomLevels = { 0, 10, 20 }
	var1.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	var1.cameraType = nil
	var1.cameraMovementMode = nil
	var1.lastCameraTransform = nil
	var1.lastUserPanCamera = tick()
	var1.humanoidRootPart = nil
	var1.humanoidCache = {}
	var1.lastSubject = nil
	var1.lastSubjectPosition = Vector3.new(0, 5, 0)
	var1.lastSubjectCFrame = CFrame.new(var1.lastSubjectPosition)
	var1.currentSubjectDistance = math.clamp(12.5, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
	var1.inFirstPerson = false
	var1.inMouseLockedMode = false
	var1.resetCameraAngle = true
	var1.enabled = false
	var1.cameraChangedConn = nil
	var1.shouldUseVRRotation = false
	var1.VRRotationIntensityAvailable = false
	var1.lastVRRotationIntensityCheckTime = 0
	var1.lastVRRotationTime = 0
	var1.vrRotateKeyCooldown = {}
	var1.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	var1.humanoidJumpOrigin = nil
	var1.trackingHumanoid = nil
	var1.cameraFrozen = false
	var1.subjectStateChangedConn = nil
	var1.gamepadZoomPressConnection = nil
	var1.mouseLockOffset = Vector3.new(0, 0, 0)
	var5:SetCameraYInvertVisible()
	var5:SetGamepadCameraSensitivityVisible()
	return var1
end

tbl1.GetModuleName = function(_)
	return "BaseCamera"
end

tbl1._setUpConfigurations = function(arg1)
	local function fn2(arg1)
		arg1:OnCharacterAdded(arg1)
	end

	arg1._connections:trackConnection("CHARACTER_ADDED", str5.CharacterAdded:Connect(fn2))
	arg1.humanoidRootPart = nil
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MODE_CHANGED", str5:GetPropertyChangedSignal("CameraMode"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(fn2))
	arg1:OnPlayerCameraPropertyChange()
end

tbl1.OnCharacterAdded = function(arg1, _)
	local var1 = arg1.resetCameraAngle
	var1 = var1 or arg1:GetEnabled()
	arg1.resetCameraAngle = var1
	arg1.humanoidRootPart = nil
end

tbl1.GetHumanoidRootPart = function(arg1)
	local var2 = str5.Character:FindFirstChildOfClass("Humanoid")
	if not arg1.humanoidRootPart and (str5.Character and var2) then
		arg1.humanoidRootPart = var2.RootPart
	end

	return arg1.humanoidRootPart
end

tbl1.GetBodyPartToFollow = function(_, arg2, _)
	if arg2:GetState() == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			if var3:IsA("Model") then
				local var4 = var3:FindFirstChild("Head")
				return var4 or arg2.RootPart
			end
		end
	end

	return arg2.RootPart
end

tbl1.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectCFrame
	if not var2 then
		return var3
	end

	if var2:IsA("Humanoid") then
		local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
		local var5 = var2.CameraOffset
		if arg1:GetIsMouseLocked() then
			var5 = Vector3.new()
		end

		local var6 = var2.RootPart
		var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
		if var6 then
			if var6:IsA("BasePart") then
				local var13 = nil
				if var2.RigType == Enum.HumanoidRigType.R15 then
					if var2.AutomaticScalingEnabled then
						local var16 = var2.RootPart
						var13 = Vector3.new(0, 1.5, 0)
						if var6 == var16 then
							var13 = var13 + Vector3.new(0, (var16.Size.Y - 2) / 2, 0)
						end
					else
						var13 = Vector3.new(0, 2, 0)
					end
				else
					var13 = Vector3.new(0, 1.5, 0)
				end

				if var4 then
					var13 = Vector3.new(0, 0, 0)
				end

				var3 = var6.CFrame * CFrame.new(var13 + var5)
			end
		end
	else
		if var2:IsA("BasePart") then
			var3 = var2.CFrame
		else
			if var2:IsA("Model") then
				var3 = if var2.PrimaryPart then var2:GetPrimaryPartCFrame() else CFrame.new()
			end
		end
	end

	if var3 then
		arg1.lastSubjectCFrame = var3
	end

	return var3
end

tbl1.GetSubjectVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.Velocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.Velocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.Velocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetSubjectRotVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.RotVelocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.RotVelocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.RotVelocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.StepZoom = function(arg1)
	local var1 = str3.getZoomDelta()
	local var4 = arg1.currentSubjectDistance
	if 0 < math.abs(var1) then
		local var6 = nil
		var6 = if 0 < var1 then math.max(var4 + var1 * (var4 * 0.5 + 1), arg1.FIRST_PERSON_DISTANCE_THRESHOLD) else math.max((var4 + var1) / (1 - var1 * 0.5), 0.5)
		if var6 < arg1.FIRST_PERSON_DISTANCE_THRESHOLD then
			var6 = 0.5
		end

		arg1:SetCameraToSubjectDistance(var6)
	end

	return str1.GetZoomRadius()
end

tbl1.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectPosition
	if var2 then
		if var2:IsA("Humanoid") then
			local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
			local var5 = var2.CameraOffset
			if arg1:GetIsMouseLocked() then
				var5 = Vector3.new()
			end

			local var6 = var2.RootPart
			var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
			if var6 then
				if var6:IsA("BasePart") then
					local var10 = nil
					if var2.RigType == Enum.HumanoidRigType.R15 then
						if var2.AutomaticScalingEnabled then
							var10 = Vector3.new(0, 1.5, 0)
							if var6 == var2.RootPart then
								var10 = var10 + Vector3.new(0, var2.RootPart.Size.Y / 2 - 1, 0)
							end
						else
							var10 = Vector3.new(0, 2, 0)
						end
					else
						var10 = Vector3.new(0, 1.5, 0)
					end

					if var4 then
						var10 = Vector3.new(0, 0, 0)
					end

					var3 = var6.CFrame.p + var6.CFrame:vectorToWorldSpace(var10 + var5)
				end
			end
		else
			if var2:IsA("VehicleSeat") then
				var3 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
			else
				if var2:IsA("SkateboardPlatform") then
					var3 = var2.CFrame.p + Vector3.new(0, 5, 0)
				else
					if var2:IsA("BasePart") then
						var3 = var2.CFrame.p
					else
						if var2:IsA("Model") then
							if var2.PrimaryPart then
								var3 = var2:GetPrimaryPartCFrame().p
							else
								var3 = var2:GetModelCFrame().p
							end
						end
					end
				end
			end
		end
	else
		return nil
	end

	arg1.lastSubject = var2
	arg1.lastSubjectPosition = var3
	return var3
end

tbl1.OnCurrentCameraChanged = function(arg1)
	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
		arg1.cameraSubjectChangedConn = nil
	end

	local var2 = game.Workspace.CurrentCamera
	if var2 then
		arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			arg1:OnNewCameraSubject()
		end)

		arg1:OnNewCameraSubject()
	end
end

tbl1.OnPlayerCameraPropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.InputTranslationToCameraAngleChange = function(_, arg2, arg3)
	return arg2 * arg3
end

tbl1.GamepadZoomPress = function(arg1)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var2 = str5.CameraMaxZoomDistance
	for i1 = #arg1.gamepadZoomLevels, 1, -1 do
		local var3 = arg1.gamepadZoomLevels[i1]
		if var2 < var3 then
			continue
		end

		if var3 < str5.CameraMinZoomDistance then
			var3 = str5.CameraMinZoomDistance
			if var2 == var3 then
				break
			end
		end

		if var3 + (var2 - var3) / 2 < var1 then
			arg1:SetCameraToSubjectDistance(var3)
			return
		end

		local var4 = var3
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
		arg1:OnEnabledChanged()
	end
end

tbl1.OnEnabledChanged = function(arg1)
	if arg1.enabled then
		arg1:_setUpConfigurations()
		str3.setInputEnabled(true)
		arg1.gamepadZoomPressConnection = str3.gamepadZoomPress:Connect(function()
			arg1:GamepadZoomPress()
		end)

		if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		end

		if arg1.cameraChangedConn then
			arg1.cameraChangedConn:Disconnect()
			arg1.cameraChangedConn = nil
		end

		arg1.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			arg1:OnCurrentCameraChanged()
		end)

		arg1:OnCurrentCameraChanged()
		return
	end

	arg1._connections:disconnectAll()
	str3.setInputEnabled(false)
	if arg1.gamepadZoomPressConnection then
		arg1.gamepadZoomPressConnection:Disconnect()
		arg1.gamepadZoomPressConnection = nil
	end

	arg1:Cleanup()
end

tbl1.GetEnabled = function(arg1)
	return arg1.enabled
end

tbl1.Cleanup = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end

	if arg1.cameraChangedConn then
		arg1.cameraChangedConn:Disconnect()
		arg1.cameraChangedConn = nil
	end

	arg1.lastCameraTransform = nil
	arg1.lastSubjectCFrame = nil
	var3.restoreMouseBehavior()
end

tbl1.UpdateMouseBehavior = function(arg1)
	if arg1.isCameraToggle and var5.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove == false then
		str4.setCameraModeToastEnabled(true)
		str3.enableCameraToggleInput()
		str2(arg1.inFirstPerson)
		return
	end

	str4.setCameraModeToastEnabled(false)
	str3.disableCameraToggleInput()
	if arg1.inFirstPerson or arg1.inMouseLockedMode then
		var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
		return
	end

	var3.restoreRotationType()
	if str3.getRotationActivated() then
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
		return
	end

	var3.restoreMouseBehavior()
end

tbl1.UpdateForDistancePropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1.currentSubjectDistance
	if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
		arg1.currentSubjectDistance = 0.5
		if not arg1.inFirstPerson then
			arg1:EnterFirstPerson()
		end
	else
		local var3 = math.clamp(arg2, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
		if var3 < 1 then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		else
			arg1.currentSubjectDistance = var3
			if arg1.inFirstPerson then
				arg1:LeaveFirstPerson()
			end
		end
	end

	str1.SetZoomParameters(arg1.currentSubjectDistance, (math.sign(arg2 - var1)))
	return arg1.currentSubjectDistance
end

tbl1.SetCameraType = function(arg1, arg2)
	arg1.cameraType = arg2
end

tbl1.GetCameraType = function(arg1)
	return arg1.cameraType
end

tbl1.SetCameraMovementMode = function(arg1, arg2)
	arg1.cameraMovementMode = arg2
end

tbl1.GetCameraMovementMode = function(arg1)
	return arg1.cameraMovementMode
end

tbl1.SetIsMouseLocked = function(arg1, arg2)
	arg1.inMouseLockedMode = arg2
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.inMouseLockedMode
end

tbl1.SetMouseLockOffset = function(arg1, arg2)
	arg1.mouseLockOffset = arg2
end

tbl1.GetMouseLockOffset = function(arg1)
	return arg1.mouseLockOffset
end

tbl1.InFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.EnterFirstPerson = function(arg1)
	arg1.inFirstPerson = true
	arg1:UpdateMouseBehavior()
end

tbl1.LeaveFirstPerson = function(arg1)
	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
end

tbl1.GetCameraToSubjectDistance = function(arg1)
	return arg1.currentSubjectDistance
end

tbl1.GetMeasuredDistanceToFocus = function(_)
	local var2 = game.Workspace.CurrentCamera
	if var2 then
		return (var2.CoordinateFrame.p - var2.Focus.p).magnitude
	end

	return nil
end

tbl1.GetCameraLookVector = function(_)
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end

tbl1.CalculateNewLookCFrameFromArg = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 + -1.3962634015954636, var2 + 1.3962634015954636)))
	return CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)
end

tbl1.CalculateNewLookVectorFromArg = function(arg1, arg2, arg3)
	return arg1:CalculateNewLookCFrameFromArg(arg2, arg3).LookVector
end

tbl1.CalculateNewLookVectorVRFromArg = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, 0)
	return ((CFrame.Angles(0, -var1.X, 0) * CFrame.new(Vector3.new(0, 0, 0), ((arg1:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit) * CFrame.Angles(-var1.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end

tbl1.GetHumanoid = function(arg1)
	local var1 = str5
	var1 = var1 and str5.Character
	if var1 then
		local var4 = arg1.humanoidCache[str5]
		if var4 and var4.Parent == var1 then
			return var4
		end

		arg1.humanoidCache[str5] = nil
		local var6 = var1:FindFirstChildOfClass("Humanoid")
		if var6 then
			arg1.humanoidCache[str5] = var6
		end

		return var6
	end

	return nil
end

tbl1.GetHumanoidPartToFollow = function(_, arg2, arg3)
	if arg3 == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			local var4 = var3:FindFirstChild("Head")
			return var4 or arg2.Torso
		end

		return arg2.Torso
	end

	return arg2.Torso
end

tbl1.OnNewCameraSubject = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end
end

tbl1.IsInFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.Update = function(_, _)
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end

tbl1.GetCameraHeight = function(arg1)
	if var4.VREnabled and (not arg1.inFirstPerson) then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Invisicam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("Players")
local var3 = RaycastParams.new()
var3.FilterType = Enum.RaycastFilterType.Exclude
local var4 = RaycastParams.new()
var4.FilterType = Enum.RaycastFilterType.Include
local str2 = "BaseOcclusion"
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = setmetatable({}, var5)
var6.__index = var6
local tbl1 = {
	LIMBS = 2,
	MOVEMENT = 3,
	CORNERS = 4,
	CIRCLE1 = 5,
	CIRCLE2 = 6,
	LIMBMOVE = 7,
	SMART_CIRCLE = 8,
	CHAR_OUTLINE = 9,
}

var6.new = function()
	local var1 = setmetatable(var5.new(), var6)
	var1.char = nil
	var1.humanoidRootPart = nil
	var1.torsoPart = nil
	var1.headPart = nil
	var1.childAddedConn = nil
	var1.childRemovedConn = nil
	var1.behaviors = {}
	var1.behaviors[tbl1.LIMBS] = var1.LimbBehavior
	var1.behaviors[tbl1.MOVEMENT] = var1.MoveBehavior
	var1.behaviors[tbl1.CORNERS] = var1.CornerBehavior
	var1.behaviors[tbl1.CIRCLE1] = var1.CircleBehavior
	var1.behaviors[tbl1.CIRCLE2] = var1.CircleBehavior
	var1.behaviors[tbl1.LIMBMOVE] = var1.LimbMoveBehavior
	var1.behaviors[tbl1.SMART_CIRCLE] = var1.SmartCircleBehavior
	var1.behaviors[tbl1.CHAR_OUTLINE] = var1.CharacterOutlineBehavior
	var1.mode = tbl1.SMART_CIRCLE
	var1.behaviorFunction = var1.SmartCircleBehavior
	var1.savedHits = {}
	var1.trackedLimbs = {}
	var1.camera = game.Workspace.CurrentCamera
	var1.enabled = false
	return var1
end

var6.Enable = function(arg1, arg2)
	arg1.enabled = arg2
	if not arg2 then
		arg1:Cleanup()
	end
end

var6.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Invisicam
end

var6.LimbBehavior = function(arg1, arg2)
	for k1, v1 in pairs(arg1.trackedLimbs) do
		arg2[#arg2 + 1] = k1.Position
	end
end

var6.MoveBehavior = function(arg1, arg2)
	for i1 = 1, 3 do
		local var1 = arg1.humanoidRootPart.Velocity
		arg2[#arg2 + 1] = arg1.humanoidRootPart.Position + (i1 - 1) * arg1.humanoidRootPart.CFrame.lookVector * (Vector3.new(var1.X, 0, var1.Z).Magnitude / 2)
	end
end

local tbl2 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1),
}

var6.CornerBehavior = function(arg1, arg2)
	local var1 = arg1.humanoidRootPart.CFrame
	local var2 = var1.Position
	local var3 = arg1.char:GetExtentsSize() / 2
	arg2[#arg2 + 1] = var2
	for i1 = 1, #tbl2 do
		local var4 = var1 - var2
		arg2[#arg2 + 1] = var2 + var4 * (var3 * tbl2[i1])
	end
end

var6.CircleBehavior = function(arg1, arg2)
	local var2 = nil
	if arg1.mode == tbl1.CIRCLE1 then
		var2 = arg1.humanoidRootPart.CFrame
	else
		local var3 = arg1.camera.CoordinateFrame
		var2 = var3 - var3.Position + arg1.humanoidRootPart.Position
	end

	arg2[#arg2 + 1] = var2.Position
	for i1 = 0, 9 do
		local var4 = 0.62831853071795862 * i1
		arg2[#arg2 + 1] = var2 * (Vector3.new(math.cos(var4), math.sin(var4), 0) * 3)
	end
end

var6.LimbMoveBehavior = function(arg1, arg2)
	arg1:LimbBehavior(arg2)
	arg1:MoveBehavior(arg2)
end

var6.CharacterOutlineBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var3 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var3
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var3
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = CFrame.new(Vector3.new(0, 0, 0), (Vector3.new(arg1.camera.CoordinateFrame.lookVector.X, 0, arg1.camera.CoordinateFrame.lookVector.Z)))
	local var6 = arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position
	local tbl2 = { arg1.torsoPart }
	if arg1.headPart then
		tbl2[#tbl2 + 1] = arg1.headPart
	end

	for i1 = 1, 24 do
		local var7 = 6.2831853071795862 * i1 / 24
		local var8 = var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 3)
		var8 = Vector3.new(var8.X, math.max(var8.Y, -2.25), var8.Z)
		if var1 then
			var4.FilterDescendantsInstances = tbl2
			local var9 = game.Workspace:Raycast(var6 + var8, -3 * var8, var4)
			if not var9 then
				continue
			end

			local var10 = var9.Position
			arg2[#arg2 + 1] = var10 + 0.2 * (var6 - var10).unit
		else
			local var11, var12 = game.Workspace:FindPartOnRayWithWhitelist(Ray.new(var6 + var8, -3 * var8), tbl2, false)
			if not var11 then
				continue
			end

			arg2[#arg2 + 1] = var12 + 0.2 * (var6 - var12).unit
		end
	end
end

local function RayIntersection(arg1, arg2, arg3, arg4)
	local var1 = arg2:Cross(arg4)
	local var2 = -arg4.Y
	local var3 = var1.Z
	local var4 = var1.Y
	local var5 = -arg4.Z
	local var6 = arg2.Y
	local var7 = arg2.Z
	local var9 = arg2.X * (var2 * var3 - var4 * var5) - -arg4.X * (var6 * var3 - var4 * var7) + var1.X * (var6 * var5 - var2 * var7)
	local var10 = arg3.X - arg1.X
	local var11 = arg3.Y - arg1.Y
	local var12 = arg3.Z - arg1.Z
	if var9 == 0 then
		return Vector3.new(0, 0, 0)
	end

	var2 = -arg4.Y
	var5 = var1.Z
	var4 = var1.Y
	var7 = -arg4.Z
	local var13 = (var10 * (var2 * var5 - var4 * var7) - -arg4.X * (var11 * var5 - var4 * var12) + var1.X * (var11 * var7 - var2 * var12)) / var9
	var3 = var1.Z
	var7 = var1.Y
	var4 = arg2.Y
	var5 = arg2.Z
	var6 = arg3 + (arg2.X * (var11 * var3 - var7 * var12) - var10 * (var4 * var3 - var7 * var5) + var1.X * (var4 * var12 - var11 * var5)) / var9 * arg4
	local var14 = arg1 + var13 * arg2
	var2 = var14 + (var6 - var14) * 0.5
	if (var6 - var14).Magnitude < 0.25 then
		return var2
	end

	return Vector3.new(0, 0, 0)
end

var6.SmartCircleBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var4 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var4
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var4
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = arg1.camera.CFrame - arg1.camera.CFrame.p
	local var6 = Vector3.new(0, 0.5, 0) + (arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position)
	for i1 = 1, 24 do
		local var7 = 0.26179938779914941 * i1 - 1.5707963267948966
		local var8 = var6 + var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 2.5)
		local var9 = var8 - arg1.camera.CFrame.p
		if var1 then
			var3.FilterDescendantsInstances = { arg1.char }
			local var16 = game.Workspace:Raycast(var6, var8 - var6, var3)
			local var17 = var8
			if var16 then
				local var18 = var16.Normal
				local var19 = var16.Position + 0.1 * var18.unit
				local var20 = var19 - var6
				local var21 = var20:Cross(var9).unit:Cross(var18).unit
				if var20.unit:Dot(-var21) < var20.unit:Dot((var19 - arg1.camera.CFrame.p).unit) then
					var17 = RayIntersection(var19, var21, var8, var9)
					if 0 < var17.Magnitude then
						var16 = game.Workspace:Raycast(var19, var17 - var19, var3)
						if var16 then
							var17 = var16.Position + 0.1 * var16.Normal.Unit
						end
					else
						var17 = var19
					end
				else
					var17 = var19
				end

				var16 = game.Workspace:Raycast(var6, var17 - var6, var3)
				if var16 then
					var17 = var16.Position - 0.1 * (var17 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var17
		else
			local var28, var29, var30 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var8 - var6), { arg1.char }, false, false)
			local var31 = var8
			if var28 then
				local var32 = var29 + 0.1 * var30.unit
				local var33 = var32 - var6
				local var34 = var33:Cross(var9).unit:Cross(var30).unit
				if var33.unit:Dot(-var34) < var33.unit:Dot((var32 - arg1.camera.CFrame.p).unit) then
					var31 = RayIntersection(var32, var34, var8, var9)
					if 0 < var31.Magnitude then
						local var37, var38, var39 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var32, var31 - var32), { arg1.char }, false, false)
						if var37 then
							var31 = var38 + 0.1 * var39.unit
						end
					else
						var31 = var32
					end
				else
					var31 = var32
				end

				local var41, var42, var43 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var31 - var6), { arg1.char }, false, false)
				if var41 then
					var31 = var42 - 0.1 * (var31 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var31
		end
	end
end

var6.CheckTorsoReference = function(arg1)
	if arg1.char then
		arg1.torsoPart = arg1.char:FindFirstChild("Torso")
		if not arg1.torsoPart then
			arg1.torsoPart = arg1.char:FindFirstChild("UpperTorso")
			if not arg1.torsoPart then
				arg1.torsoPart = arg1.char:FindFirstChild("HumanoidRootPart")
			end
		end

		arg1.headPart = arg1.char:FindFirstChild("Head")
	end
end

str1 = {
	Head = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	LeftLowerArm = true,
	RightLowerArm = true,
	LeftUpperLeg = true,
	RightUpperLeg = true,
}

var6.CharacterAdded = function(arg1, arg2, arg3)
	if arg3 ~= var2.LocalPlayer then
		return
	end

	if arg1.childAddedConn then
		arg1.childAddedConn:Disconnect()
		arg1.childAddedConn = nil
	end

	if arg1.childRemovedConn then
		arg1.childRemovedConn:Disconnect()
		arg1.childRemovedConn = nil
	end

	arg1.char = arg2
	arg1.trackedLimbs = {}
	arg1.childAddedConn = arg2.ChildAdded:Connect(function(arg1)
		if arg1:IsA("BasePart") then
			if str1[arg1.Name] then
				arg1.trackedLimbs[arg1] = true
			end

			if arg1.Name == "Torso" or arg1.Name == "UpperTorso" then
				arg1.torsoPart = arg1
			end

			if arg1.Name == "Head" then
				arg1.headPart = arg1
			end
		end
	end)

	arg1.childRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		arg1.trackedLimbs[arg1] = nil
		arg1:CheckTorsoReference()
	end)

	for k1, v1 in pairs(arg1.char:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if str1[v1.Name] then
			arg1.trackedLimbs[v1] = true
		end

		if v1.Name == "Torso" or v1.Name == "UpperTorso" then
			arg1.torsoPart = v1
		end

		if v1.Name ~= "Head" then
			continue
		end

		arg1.headPart = v1
	end
end

local function AssertTypes(arg1, ...)
	local tbl1 = {}
	local str1 = ""
	for k1, v1 in pairs({ ... }) do
		tbl1[v1] = true
		local var1 = str1
		str1 = var1 .. (if str1 == "" then "" else " or ") .. v1
	end

	local var2 = type(arg1)
	assert(tbl1[var2], str1 .. " type expected, got: " .. var2)
end

var6.SetMode = function(arg1, arg2)
	AssertTypes(arg2, "number")
	for k1, v1 in pairs(tbl1) do
		if v1 ~= arg2 then
			continue
		end

		arg1.mode = arg2
		arg1.behaviorFunction = arg1.behaviors[arg1.mode]
		return
	end

	error("Invalid mode number")
end

var6.GetObscuredParts = function(arg1)
	return arg1.savedHits
end

var6.Cleanup = function(arg1)
	for k1, v1 in pairs(arg1.savedHits) do
		k1.LocalTransparencyModifier = v1
	end
end

var6.Update = function(arg1, _, arg3, arg4)
	if not arg1.enabled or (not arg1.char) then
		return arg3, arg4
	end

	arg1.camera = game.Workspace.CurrentCamera
	if not arg1.humanoidRootPart then
		local var3 = arg1.char:FindFirstChildOfClass("Humanoid")
		if var3 and var3.RootPart then
			arg1.humanoidRootPart = var3.RootPart
		else
			arg1.humanoidRootPart = arg1.char:FindFirstChild("HumanoidRootPart")
			if not arg1.humanoidRootPart then
				return arg3, arg4
			end
		end

		local var4 = nil
		arg1.humanoidRootPart.AncestryChanged:Connect(function(arg1, arg2)
			if arg1 == arg1.humanoidRootPart and (not arg2) then
				arg1.humanoidRootPart = nil
				if var4 and var4.Connected then
					var4:Disconnect()
					var4 = nil
				end
			end
		end)

	end

	if not arg1.torsoPart then
		arg1:CheckTorsoReference()
		if not arg1.torsoPart then
			return arg3, arg4
		end
	end

	local tbl1 = {}
	arg1.behaviorFunction(arg1, tbl1)
	local tbl2 = {}
	local tbl3 = { arg1.char }
	local var5 = nil
	var5 = arg1.camera:GetPartsObscuringTarget({
		arg1.headPart and arg1.headPart.CFrame.p or tbl1[1],
		arg1.torsoPart and arg1.torsoPart.CFrame.p or tbl1[2],
	}, tbl3)

	local num1 = 0
	local tbl4 = {}
	local num2 = 0.75
	local num3 = 0.75
	for i1 = 1, #var5 do
		local var6 = var5[i1]
		tbl4[var6] = true
		num1 = num1 + 1
		for k1, v1 in pairs(var6:GetChildren()) do
			if v1:IsA("Decal") or v1:IsA("Texture") then
				num1 = num1 + 1
				break
			end
		end
	end

	if 0 < num1 then
		num2 = math.pow(0.375 / num1 + 0.375, 1 / num1)
		num3 = math.pow(0.25 / num1 + 0.25, 1 / num1)
	end

	var5 = arg1.camera:GetPartsObscuringTarget(tbl1, tbl3)
	local tbl5 = {}
	for i2 = 1, #var5 do
		local var7 = var5[i2]
		tbl5[var7] = tbl4[var7] and num2 or num3
		if var7.Transparency < tbl5[var7] then
			tbl2[var7] = true
			if not arg1.savedHits[var7] then
				arg1.savedHits[var7] = var7.LocalTransparencyModifier
			end
		end

		for k2, v2 in pairs(var7:GetChildren()) do
			if (v2:IsA("Decal") or v2:IsA("Texture")) and v2.Transparency < tbl5[var7] then
				local var8 = tbl5[var7]
				tbl5[v2] = var8
				tbl2[v2] = true
				if arg1.savedHits[v2] then
					continue
				end

				arg1.savedHits[v2] = v2.LocalTransparencyModifier
			end
		end
	end

	for k3, v3 in pairs(arg1.savedHits) do
		if tbl2[k3] then
			k3.LocalTransparencyModifier = k3.Transparency < 1 and (tbl5[k3] - k3.Transparency) / (1 - k3.Transparency) or 0
		else
			k3.LocalTransparencyModifier = v3
			arg1.savedHits[k3] = nil
		end
	end

	return arg3, arg4
end

return var6

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
setmetatable(tbl1, { __call = function(_, ...)
	return tbl1.new(...)
end })

tbl1.new = function()
	return (setmetatable({}, tbl1))
end

tbl1.CharacterAdded = function(_, _, _)
end

tbl1.CharacterRemoving = function(_, _, _)
end

tbl1.OnCameraSubjectChanged = function(_, _)
end

tbl1.GetOcclusionMode = function(_)
	warn("BaseOcclusion GetOcclusionMode must be overridden by derived classes")
	return nil
end

tbl1.Enable = function(_, _)
	warn("BaseOcclusion Enable must be overridden by derived classes")
end

tbl1.Update = function(_, _, arg3, arg4)
	warn("BaseOcclusion Update must be overridden by derived classes")
	return arg3, arg4
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixOrbitalCameraAzimuth")
local str2 = "CameraUtils"
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
str2 = require(script.Parent:WaitForChild(str4))
local var3 = game:GetService("Players")
str3 = setmetatable({}, str2)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(str2.new(), str3)
	var1.lastUpdate = tick()
	var1.changedSignalConnections = {}
	var1.refAzimuthRad = nil
	var1.curAzimuthRad = nil
	var1.minAzimuthAbsoluteRad = nil
	var1.maxAzimuthAbsoluteRad = nil
	var1.useAzimuthLimits = nil
	var1.curElevationRad = nil
	var1.minElevationRad = nil
	var1.maxElevationRad = nil
	var1.curDistance = nil
	var1.minDistance = nil
	var1.maxDistance = nil
	var1.gamepadDollySpeedMultiplier = 1
	var1.lastUserPanCamera = tick()
	var1.externalProperties = {}
	var1.externalProperties.InitialDistance = 25
	var1.externalProperties.MinDistance = 10
	var1.externalProperties.MaxDistance = 100
	var1.externalProperties.InitialElevation = 35
	var1.externalProperties.MinElevation = 35
	var1.externalProperties.MaxElevation = 35
	var1.externalProperties.ReferenceAzimuth = -45
	var1.externalProperties.CWAzimuthTravel = 90
	var1.externalProperties.CCWAzimuthTravel = 90
	var1.externalProperties.UseAzimuthLimits = false
	var1:LoadNumberValueParameters()
	return var1
end

str3.LoadOrCreateNumberValueParameter = function(arg1, arg2, arg3, arg4)
	local var2 = script:FindFirstChild(arg2)
	if var2 and var2:IsA(arg3) then
		arg1.externalProperties[arg2] = var2.Value
	else
		if arg1.externalProperties[arg2] ~= nil then
			var2 = Instance.new(arg3)
			var2.Name = arg2
			var2.Parent = script
			var2.Value = arg1.externalProperties[arg2]
		else
			return
		end
	end

	if arg4 then
		if arg1.changedSignalConnections[arg2] then
			arg1.changedSignalConnections[arg2]:Disconnect()
		end

		arg1.changedSignalConnections[arg2] = var2.Changed:Connect(function(arg1)
			arg1.externalProperties[arg2] = arg1
			arg4(arg1)
		end)

	end
end

str3.SetAndBoundsCheckAzimuthValues = function(arg1)
	arg1.minAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) - math.abs((math.rad(arg1.externalProperties.CWAzimuthTravel)))
	arg1.maxAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) + math.abs((math.rad(arg1.externalProperties.CCWAzimuthTravel)))
	arg1.useAzimuthLimits = arg1.externalProperties.UseAzimuthLimits
	if arg1.useAzimuthLimits then
		local var1 = math.max(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
		var1 = math.min(arg1.curAzimuthRad, arg1.maxAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
	end
end

str3.SetAndBoundsCheckElevationValues = function(arg1)
	local var1 = math.max(arg1.externalProperties.MinElevation, -80)
	local var2 = math.min(arg1.externalProperties.MaxElevation, 80)
	arg1.minElevationRad = math.rad((math.min(var1, var2)))
	arg1.maxElevationRad = math.rad((math.max(var1, var2)))
	local var3 = math.max(arg1.curElevationRad, arg1.minElevationRad)
	arg1.curElevationRad = var3
	var3 = math.min(arg1.curElevationRad, arg1.maxElevationRad)
	arg1.curElevationRad = var3
end

str3.SetAndBoundsCheckDistanceValues = function(arg1)
	arg1.minDistance = arg1.externalProperties.MinDistance
	arg1.maxDistance = arg1.externalProperties.MaxDistance
	local var1 = math.max(arg1.curDistance, arg1.minDistance)
	arg1.curDistance = var1
	var1 = math.min(arg1.curDistance, arg1.maxDistance)
	arg1.curDistance = var1
end

str3.LoadNumberValueParameters = function(arg1)
	arg1:LoadOrCreateNumberValueParameter("InitialElevation", "NumberValue", nil)
	arg1:LoadOrCreateNumberValueParameter("InitialDistance", "NumberValue", nil)
	local str1 = "ReferenceAzimuth"
	local str2 = "NumberValue"
	arg1:LoadOrCreateNumberValueParameter(str1, str2, if var1 then arg1.SetAndBoundsCheckAzimuthValues else arg1.SetAndBoundsCheckAzimuthValue)
	arg1:LoadOrCreateNumberValueParameter("CWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("CCWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("MinElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MaxElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MinDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("MaxDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("UseAzimuthLimits", "BoolValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1.curAzimuthRad = math.rad(arg1.externalProperties.ReferenceAzimuth)
	arg1.curElevationRad = math.rad(arg1.externalProperties.InitialElevation)
	arg1.curDistance = arg1.externalProperties.InitialDistance
	arg1:SetAndBoundsCheckAzimuthValues()
	arg1:SetAndBoundsCheckElevationValues()
	arg1:SetAndBoundsCheckDistanceValues()
end

str3.GetModuleName = function(_)
	return "OrbitalCamera"
end

str3.SetInitialOrientation = function(arg1, arg2)
	if not arg2 or (not arg2.RootPart) then
		warn("OrbitalCamera could not set initial orientation due to missing humanoid")
		return
	end

	assert(arg2.RootPart, "")
	local var1 = (arg2.RootPart.CFrame.LookVector - Vector3.new(0, 0.23, 0)).Unit
	local var2 = math.asin(arg1:GetCameraLookVector().Y) - math.asin(var1.Y)
	if not str1.IsFinite((str1.GetAngleBetweenXZVectors(var1, arg1:GetCameraLookVector()))) then
	end

	if not str1.IsFinite(var2) then
	end
end

str3.GetCameraToSubjectDistance = function(arg1)
	return arg1.curDistance
end

str3.SetCameraToSubjectDistance = function(arg1, arg2)
	if var3.LocalPlayer then
		arg1.currentSubjectDistance = math.clamp(arg2, arg1.minDistance, arg1.maxDistance)
		local var1 = math.max(arg1.currentSubjectDistance, arg1.FIRST_PERSON_DISTANCE_THRESHOLD)
		arg1.currentSubjectDistance = var1
	end

	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
	return arg1.currentSubjectDistance
end

str3.CalculateNewLookVector = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 - 1.3962634015954636, var2 - -1.3962634015954636)))
	return (CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)).LookVector
end

str3.Update = function(arg1, arg2)
	local var1 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4
	var5 = var5 and var4.CameraSubject
	local var6 = var5
	local var7 = var5
	local var8 = var2.getRotation(arg2) ~= Vector2.new()
	local var9 = var4.CFrame
	local var10 = var4.Focus
	local var11 = var3.LocalPlayer
	var6 = var6 and var5:IsA("VehicleSeat")
	var7 = var7 and var5:IsA("SkateboardPlatform")
	if arg1.lastUpdate == nil or 1 < var1 - arg1.lastUpdate then
		arg1.lastCameraTransform = nil
	end

	if var8 then
		arg1.lastUserPanCamera = tick()
	end

	local var13 = arg1:GetSubjectPosition()
	if var13 then
		if var11 then
			if var4 then
				if arg1.gamepadDollySpeedMultiplier ~= 1 then
					arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance * arg1.gamepadDollySpeedMultiplier)
				end

				local var14 = var2.getRotation(arg2)
				var10 = CFrame.new(var13)
				local var15 = arg1.curAzimuthRad - var14.X
				arg1.curAzimuthRad = var15
				if arg1.useAzimuthLimits then
					var15 = math.clamp(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad, arg1.maxAzimuthAbsoluteRad)
					arg1.curAzimuthRad = var15
				else
					if arg1.curAzimuthRad ~= 0 then
						var15 = math.sign(arg1.curAzimuthRad) * (math.abs(arg1.curAzimuthRad) % 6.2831853071795862)
						var15 = var15 or 0
					end

					arg1.curAzimuthRad = 0
				end

				var15 = math.clamp(arg1.curElevationRad + var14.Y, arg1.minElevationRad, arg1.maxElevationRad)
				arg1.curElevationRad = var15
				var9 = CFrame.new(var13 + arg1.currentSubjectDistance * (CFrame.fromEulerAnglesYXZ(-arg1.curElevationRad, arg1.curAzimuthRad, 0) * Vector3.new(0, 0, 1)), var13)
				arg1.lastCameraTransform = var9
				arg1.lastCameraFocus = var10
				if (var6 or var7) and var5:IsA("BasePart") then
					arg1.lastSubjectCFrame = var5.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var1
	return var9, var10
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraInput [ModuleScript]
-- y u r i

game:GetService("RunService")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Instance.new("BindableEvent")
local var3 = nil
local var4 = Instance.new("BindableEvent")
local var5 = nil
local var6 = game:GetService("UserInputService")
var6.InputBegan:Connect(function(arg1, arg2)
	if not arg2 and arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var2:Fire()
	end
end)

var6.InputEnded:Connect(function(arg1, _)
	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var4:Fire()
	end
end)

var3 = var2.Event
var2 = nil
var5 = var4.Event
local var7 = game:GetService("Players").LocalPlayer
local num1 = 0
local var8 = game:GetService("ContextActionService")
local var9 = UserSettings():GetService("UserGameSettings")
local var10 = game:GetService("VRService")
local var11 = game:GetService("GuiService")
local var12 = var1.getUserFlag("UserPSSinkUnknownTouchEvents")
local var13 = var1.getUserFlag("UserPSTextboxResetCameraInput")
str1 = var1.getUserFlag("UserFixVRCameraGamepadReset")
local var14 = var1.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local var15 = Vector2.new(1, 0.77) * 0.069813170079773182 * 60
local var16 = Vector2.new(1, 0.77) * 0.0087266462599716477
local var17 = Vector2.new(1, 0.77) * 0.12217304763960307
local var18 = Vector2.new(1, 0.66) * 0.017453292519943295
local tbl1 = { Thumbstick2 = Vector2.new(), ButtonLeft = 0, ButtonRight = 0 }
local tbl2 = { Movement = Vector2.new(), Wheel = 0, Pinch = 0 }
tbl2.Pan = Vector2.new()
local var19 = Instance.new("BindableEvent")
local tbl3 = { Move = Vector2.new(), Pinch = 0 }
local var21 = Enum.ContextActionPriority.Medium.Value
var2 = function(arg1)
	return math.sign(arg1) * math.clamp((math.exp((math.abs(arg1) - 0.1) / 0.9 * 2) - 1) / 6.3890560989306504, 0, 1)
end

var4 = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return arg1
	end

	local var3 = var2.CFrame:ToEulerAnglesYXZ()
	if 0 <= arg1.Y * var3 then
		return arg1
	end

	return Vector2.new(1, (1 - (math.abs(var3) * 2 / 3.1415926535897931) ^ 0.75) * 0.75 + 0.25) * arg1
end

local function isInDynamicThumbstickArea(arg1)
	local var1 = var7:FindFirstChildOfClass("PlayerGui")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TouchGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("TouchControlFrame")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("DynamicThumbstickFrame")
	if not var4 then
		return false
	end

	if not var2.Enabled then
		return false
	end

	local var5 = var4.AbsolutePosition
	local var8 = var5 + var4.AbsoluteSize
	local bool2 = false
	if var5.X <= arg1.X then
		bool2 = false
		if var5.Y <= arg1.Y then
			bool2 = false
			if arg1.X <= var8.X then
				bool2 = arg1.Y <= var8.Y
			end
		end
	end

	return bool2
end

local function incPanInputCount()
	local var1 = math.max(0, num1 + 1)
	num1 = var1
end

local function decPanInputCount()
	local var1 = math.max(0, num1 - 1)
	num1 = var1
end

local function resetPanInputCount()
	num1 = 0
end

local var22 = nil
local tbl4 = { gamepadZoomPress = var19.Event }
local tbl5 = {}
local tbl6 = { Left = 0, Right = 0, I = 0, O = 0 }
if str1 then
	var22 = Instance.new("BindableEvent")
	tbl4.gamepadReset = var22.Event
else
	var22 = var10.VREnabled and Instance.new("BindableEvent") or nil
	if var10.VREnabled then
		tbl4.gamepadReset = var22.Event
	end
end

tbl4.getRotationActivated = function()
	if var14 then
		local bool3 = true
		if 0 >= num1 then
			bool3 = true
			if 0 >= tbl1.Thumbstick2.Magnitude then
				bool3 = tbl1.ButtonRight - tbl1.ButtonLeft ~= 0
			end
		end

		return bool3
	end

	local bool4 = true
	if 0 >= num1 then
		bool4 = 0 < tbl1.Thumbstick2.Magnitude
	end

	return bool4
end

tbl4.getRotation = function(arg1, arg2)
	local var2 = Vector2.new(1, var9:GetCameraYInvertValue())
	local var3 = Vector2.new(tbl6.Right - tbl6.Left, 0) * arg1
	local var5 = nil
	var5 = if var14 then (tbl1.Thumbstick2 + Vector2.new(tbl1.ButtonRight - tbl1.ButtonLeft, 0)) * var9.GamepadCameraSensitivity * arg1 else tbl1.Thumbstick2 * var9.GamepadCameraSensitivity * arg1
	local var6 = tbl2.Movement
	local var7 = tbl2.Pan
	local var8 = var4(tbl3.Move)
	if arg2 then
		var3 = Vector2.new()
	end

	return (var3 * 2.0943951023931953 + var5 * var15 + var6 * var16 + var7 * var17 + var8 * var18) * var2
end

tbl4.getZoomDelta = function()
	return (tbl6.O - tbl6.I) * 0.1 + (-tbl2.Wheel + tbl2.Pinch) * 1 + -tbl3.Pinch * 0.04
end

local var23 = nil
local tbl7 = {}
local var24 = nil
local var25 = nil
local var26 = nil
local var27 = nil
local var28 = nil
var24 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Begin)
	if var23 == nil and (isInDynamicThumbstickArea(arg1.Position) and (not arg2)) then
		var23 = arg1
		return
	end

	if not arg2 then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end

	tbl7[arg1] = arg2
end

var27 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Change)
	if arg1 == var23 then
		return
	end

	if tbl7[arg1] == nil then
		if var12 then
			tbl7[arg1] = true
		else
			tbl7[arg1] = arg2
		end
	end

	local tbl1 = {}
	for k1, v1 in pairs(tbl7) do
		if v1 then
			continue
		end

		table.insert(tbl1, k1)
	end

	if #tbl1 == 1 and tbl7[arg1] == false then
		local var3 = tbl3
		local var4 = arg1.Delta
		local var5 = var3.Move + Vector2.new(var4.X, var4.Y)
		var3.Move = var5
	end

	if #tbl1 == 2 then
		local var10 = (tbl1[1].Position - tbl1[2].Position).Magnitude
		if var25 then
			local var11 = tbl3
			local var13 = var11.Pinch + (var10 - var25)
			var11.Pinch = var13
		end

		var25 = var10
		return
	end

	var25 = nil
end

var26 = function(arg1, _)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.End)
	if arg1 == var23 then
		var23 = nil
	end

	if tbl7[arg1] == false then
		var25 = nil
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end

	tbl7[arg1] = nil
end

local bool1 = false
local function resetInputDevices()
	local var1 = tbl6
	for k1, v1 in pairs({ tbl1, var1, tbl2, tbl3 }) do
		for k2, v2 in pairs(v1) do
			if type(v2) == "boolean" then
				v1[k2] = false
			else
				local var2 = v1[k2] * 0
				v1[k2] = var2
			end
		end
	end

	num1 = 0
end

var28 = function()
	tbl7 = {}
	var23 = nil
	var25 = nil
	num1 = 0
end

local function thumbstick(_, _, arg3)
	local var1 = arg3.Position
	tbl1[arg3.KeyCode.Name] = Vector2.new(var2(var1.X), -var2(var1.Y))
	return Enum.ContextActionResult.Pass
end

local function directionalButtons(_, arg2, arg3)
	if arg2 == Enum.UserInputState.Cancel then
		tbl1[arg3.KeyCode.Name] = 0
	else
		tbl1[arg3.KeyCode.Name] = var2(arg3.Position.Z)
	end

	return Enum.ContextActionResult.Pass
end

local function keypress(_, arg2, arg3)
	local var1 = tbl6
	local var2 = arg3.KeyCode.Name
	var1[var2] = if arg2 == Enum.UserInputState.Begin then 1 else 0
end

local function gamepadReset(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var22:Fire()
	end
end

local function gamepadZoomPress(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var19:Fire()
	end
end

var23 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var24(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 and (not arg2) then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end
end

var25 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var27(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement then
		local var2 = arg1.Delta
		tbl2.Movement = Vector2.new(var2.X, var2.Y)
	end
end

local function inputEnded(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var26(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end
end

tbl7 = function(arg1, arg2, arg3, arg4)
	if not arg4 then
		tbl2.Wheel = arg1
		tbl2.Pan = arg2
		tbl2.Pinch = -arg3
	end
end

tbl4.setInputEnabled = function(arg1)
	if bool1 == arg1 then
		return
	end

	bool1 = arg1
	resetInputDevices()
	var28()
	local var1
	if bool1 then
		var8:BindActionAtPriority("RbxCameraThumbstick", thumbstick, false, var21, Enum.KeyCode.Thumbstick2)
		if var14 then
			var8:BindActionAtPriority("RbxCameraDirectionalButtons", directionalButtons, false, var21, Enum.KeyCode.ButtonLeft, Enum.KeyCode.ButtonRight)
		end

		var8:BindActionAtPriority("RbxCameraKeypress", keypress, false, var21, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.I, Enum.KeyCode.O)
		if var10.VREnabled then
			var8:BindAction("RbxCameraGamepadReset", gamepadReset, false, Enum.KeyCode.ButtonL3)
		end

		var8:BindAction("RbxCameraGamepadZoom", gamepadZoomPress, false, Enum.KeyCode.ButtonR3)
		var1 = var23
		table.insert(tbl5, var6.InputBegan:Connect(var1))
		var1 = var25
		table.insert(tbl5, var6.InputChanged:Connect(var1))
		var1 = inputEnded
		table.insert(tbl5, var6.InputEnded:Connect(var1))
		var1 = tbl7
		table.insert(tbl5, var6.PointerAction:Connect(var1))
		var1 = var28
		table.insert(tbl5, var11.MenuOpened:connect(var1))
		return
	end

	var8:UnbindAction("RbxCameraThumbstick")
	if var14 then
		var8:UnbindAction("RbxCameraDirectionalButtons")
	end

	var8:UnbindAction("RbxCameraMouseMove")
	var8:UnbindAction("RbxCameraMouseWheel")
	var8:UnbindAction("RbxCameraKeypress")
	var8:UnbindAction("RbxCameraGamepadZoom")
	if var10.VREnabled then
		var8:UnbindAction("RbxCameraGamepadReset")
	end

	for k1, v1 in pairs(tbl5) do
		v1:Disconnect()
	end

	tbl5 = {}
end

tbl4.getInputEnabled = function()
	return bool1
end

tbl4.resetInputForFrameEnd = function()
	tbl2.Movement = Vector2.new()
	tbl3.Move = Vector2.new()
	tbl3.Pinch = 0
	tbl2.Wheel = 0
	tbl2.Pan = Vector2.new()
	tbl2.Pinch = 0
end

var6.WindowFocused:Connect(resetInputDevices)
var6.WindowFocusReleased:Connect(resetInputDevices)
if var13 then
	var6.TextBoxFocusReleased:Connect(resetInputDevices)
end

tbl5 = false
tbl4.getHoldPan = function()
	return tbl5
end

num1 = false
tbl4.getTogglePan = function()
	return num1
end

tbl4.getPanning = function()
	local var1 = num1
	return var1 or tbl5
end

tbl4.setTogglePan = function(arg1)
	num1 = arg1
end

decPanInputCount = false
resetPanInputCount = nil
tbl1 = nil
incPanInputCount = 0
tbl4.enableCameraToggleInput = function()
	if decPanInputCount then
		return
	end

	decPanInputCount = true
	tbl5 = false
	num1 = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
	end

	if tbl1 then
		tbl1:Disconnect()
	end

	resetPanInputCount = var3:Connect(function()
		tbl5 = true
		incPanInputCount = tick()
	end)

	tbl1 = var5:Connect(function()
		tbl5 = false
		if tick() - incPanInputCount < 0.3 and (num1 or var6:GetMouseDelta().Magnitude < 2) then
			local var1 = not num1
			num1 = var1
		end
	end)
end

tbl4.disableCameraToggleInput = function()
	if not decPanInputCount then
		return
	end

	decPanInputCount = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
		resetPanInputCount = nil
	end

	if tbl1 then
		tbl1:Disconnect()
		tbl1 = nil
	end
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Poppercam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local str2 = "ZoomController"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag
local var2 = require(script.Parent:WaitForChild(str2))
var1 = var1("UserFixCameraFPError")
str1 = {}
str1.__index = str1
str2 = CFrame.new()
str1.new = function()
	return (setmetatable({ lastCFrame = nil }, str1))
end

str1.Step = function(arg1, arg2, arg3)
	local var1 = arg1.lastCFrame or arg3
	arg1.lastCFrame = arg3
	local var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13 = arg3:GetComponents()
	local var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25 = var1:GetComponents()
	local var26 = arg3.Position
	local var27 = CFrame.new(0, 0, 0, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	local var28, var29 = (var27 * CFrame.new(0, 0, 0, var17, var18, var19, var20, var21, var22, var23, var24, var25):inverse()):ToAxisAngle()
	var14 = (var26 - var1.p) / arg2
	var15 = var28 * var29 / arg2
	return {
		extrapolate = function(arg1)
			local var1 = var15 * arg1
			local var3 = var1.Magnitude
			local var4 = var14 * arg1 + var26
			return (if 1e-05 < var3 then CFrame.fromAxisAngle(var1, var3) else str2) * var27 + var4
		end,
		posVelocity = var14,
		rotVelocity = var15,
	}
end

str1.Reset = function(arg1)
	arg1.lastCFrame = nil
end

local function cframeToAxis(arg1)
	local var1, var2 = arg1:ToAxisAngle()
	return var1 * var2
end

local function extractRotation(arg1)
	local var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12 = arg1:GetComponents()
	local num1 = 0
	local num2 = 0
	local num3 = 0
	local var13 = var4
	local var14 = var5
	local var15 = var6
	local var16 = var7
	local var17 = var8
	local var18 = var9
	local var19 = var10
	local var20 = var11
	local var21 = var12
	return CFrame.new(num1, num2, num3, var13, var14, var15, var16, var17, var18, var19, var20, var21)
end

extractRotation = "BaseOcclusion"
local function axisToCFrame(arg1)
	local var4 = arg1.Magnitude
	if 1e-05 < var4 then
		local var5 = arg1
		local var6 = var4
		return CFrame.fromAxisAngle(var5, var6)
	end

	return str2
end

str2 = require(script.Parent:WaitForChild(extractRotation))
cframeToAxis = setmetatable({}, str2)
cframeToAxis.__index = cframeToAxis
cframeToAxis.new = function()
	local var1 = setmetatable(str2.new(), cframeToAxis)
	var1.focusExtrapolator = str1.new()
	return var1
end

cframeToAxis.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Zoom
end

cframeToAxis.Enable = function(arg1, _)
	arg1.focusExtrapolator:Reset()
end

cframeToAxis.Update = function(arg1, arg2, arg3, arg4, _)
	local var4 = nil
	var4 = if var1 then CFrame.lookAlong(arg4.p, -arg3.LookVector) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1) else CFrame.new(arg4.p, arg3.p) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	return var4 * CFrame.new(0, 0, (var2.Update(arg2, var4, (arg1.focusExtrapolator:Step(arg2, var4))))), arg4
end

cframeToAxis.CharacterAdded = function(_, _, _)
end

cframeToAxis.CharacterRemoving = function(_, _, _)
end

cframeToAxis.OnCameraSubjectChanged = function(_, _)
end

return cframeToAxis

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera [ModuleScript]
-- y u r i

local str1 = "BaseCamera"
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local str4 = "ZoomController"
require(script.Parent:WaitForChild(str4))
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "VehicleCameraCore"
local str6 = "VehicleCameraConfig"
str2 = require(script:WaitForChild(str5))
str3 = require(script:WaitForChild(str6))
local num1 = 0.016666666666666666
game:GetService("RunService").Stepped:Connect(function(_, arg2)
	num1 = arg2
end)

str4 = game:GetService("Players").LocalPlayer
local var4 = setmetatable({}, var1)
var4.__index = var4
var4.new = function()
	local var2 = setmetatable(var1.new(), var4)
	var2:Reset()
	return var2
end

str6 = var3.Spring
local tbl1 = { 0, 15, 30 }
var4.Reset = function(arg1)
	local var1 = str2.new(arg1:GetSubjectCFrame())
	arg1.vehicleCameraCore = var1
	arg1.pitchSpring = str6.new(0, -math.rad(str3.pitchBaseAngle))
	arg1.yawSpring = str6.new(0, 0)
	arg1.lastPanTick = 0
	var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var4, var5 = var3.getLooseBoundingSphere((var2:GetConnectedParts(true)))
	arg1.assemblyRadius = math.max(var5, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var4
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.assemblyRadius / 10)
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

local var5 = var3.sanitizeAngle
local var6 = var3.mapClamp
var4._StepRotation = function(arg1, arg2, arg3)
	local var1 = var2.getRotation(arg2, true)
	local var3 = arg1.yawSpring
	local var4 = var5(var3.pos + -var1.X)
	var3.pos = var4
	local var7 = arg1.pitchSpring
	var4 = var5((math.clamp(var7.pos + -var1.Y, -1.3962634015954636, 1.3962634015954636)))
	var7.pos = var4
	if var2.getRotationActivated() then
		arg1.lastPanTick = os.clock()
	end

	var4 = -math.rad(str3.pitchBaseAngle)
	local var8 = math.rad(str3.pitchDeadzoneAngle)
	if str3.autocorrectDelay < os.clock() - arg1.lastPanTick then
		local var9 = var6(arg3, str3.autocorrectMinCarSpeed, str3.autocorrectMaxCarSpeed, 0, str3.autocorrectResponse)
		var3.freq = var9
		var7.freq = var9
		if var3.freq < 0.001 then
			var3.vel = 0
		end

		if var7.freq < 0.001 then
			var7.vel = 0
		end

		if math.abs((var5(var4 - var7.pos))) <= var8 then
			var7.goal = var7.pos
		else
			var7.goal = var4
		end
	else
		var3.freq = 0
		var3.vel = 0
		var7.freq = 0
		var7.vel = 0
		var7.goal = var4
	end

	local var10 = var7:step(arg2)
	local var11 = var3:step(arg2)
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var10, var11, num1)
end

var4._GetThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * str3.verticalCenterOffset, 0)
end

var4._GetFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = str4.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_GetThirdPersonLocalOffset()
end

var4.Update = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var3 = num1
	num1 = 0
	local var4 = arg1:GetSubjectCFrame()
	str1 = arg1:GetSubjectRotVelocity()
	local var5 = arg1:StepZoom()
	local var7 = var6(var5, 0.5, arg1.assemblyRadius, 1, 0)
	local var8 = arg1.vehicleCameraCore
	var8:setTransform(var4)
	local var9 = CFrame.new(var4 * arg1:_GetThirdPersonLocalOffset():Lerp(arg1:_GetFirstPersonLocalOffset(var4), var7)) * var8:step(var3, math.abs((var4.XVector:Dot(str1))), math.abs((var4.YVector:Dot(str1))), var7) * arg1:_StepRotation(var3, (math.abs((arg1:GetSubjectVelocity():Dot(var4.ZVector)))))
	return var9 * CFrame.new(0, 0, var5), var9
end

var4.ApplyVRTransform = function(_)
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig [ModuleScript]
-- y u r i

return {
	pitchStiffness = 0.5,
	yawStiffness = 2.5,
	autocorrectDelay = 1,
	autocorrectMinCarSpeed = 16,
	autocorrectMaxCarSpeed = 32,
	autocorrectResponse = 0.5,
	cutoffMinAngularVelYaw = 60,
	cutoffMaxAngularVelYaw = 180,
	cutoffMinAngularVelPitch = 15,
	cutoffMaxAngularVelPitch = 60,
	pitchBaseAngle = 18,
	pitchDeadzoneAngle = 12,
	firstPersonResponseMul = 10,
	yawReponseDampingRising = 1,
	yawResponseDampingFalling = 3,
	pitchReponseDampingRising = 1,
	pitchResponseDampingFalling = 3,
	verticalCenterOffset = 0.33,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.CameraUtils)
local var2 = var1.sanitizeAngle
local var3 = require(script.Parent.VehicleCameraConfig)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	return (setmetatable({ fRising = arg1, fFalling = arg2, g = arg3, p = arg3, v = arg3 * 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.v
	local var2 = arg1.g
	local var3 = 6.2831853071795862 * (0 < var1 and arg1.fRising or arg1.fFalling)
	local var4 = arg1.p - var2
	local var5 = math.exp(-var3 * arg2)
	local var6 = (var4 * (1 + var3 * arg2) + var1 * arg2) * var5 + var2
	arg1.p = var6
	arg1.v = (var1 * (1 - var3 * arg2) - var4 * (var3 * var3 * arg2)) * var5
	return var6
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function(arg1)
	assert(typeof(arg1) == "CFrame")
	local var1, var4 = arg1:toEulerAnglesYXZ()
	local var5, var6 = arg1:toEulerAnglesYXZ()
	local tbl3 = { yawG = var2(var4), yawV = 0, pitchV = 0 }
	tbl3.yawP = var2(var6)
	tbl3.pitchG = var2((arg1:toEulerAnglesYXZ()))
	tbl3.pitchP = var2((arg1:toEulerAnglesYXZ()))
	tbl3.fSpringYaw = tbl1.new(var3.yawReponseDampingRising, var3.yawResponseDampingFalling, 0)
	tbl3.fSpringPitch = tbl1.new(var3.pitchReponseDampingRising, var3.pitchResponseDampingFalling, 0)
	return (setmetatable(tbl3, tbl2))
end

tbl2.setGoal = function(arg1, arg2)
	assert(typeof(arg2) == "CFrame")
	local var1, var3 = arg2:toEulerAnglesYXZ()
	arg1.yawG = var2(var3)
	arg1.pitchG = var2((arg2:toEulerAnglesYXZ()))
end

tbl2.getCFrame = function(arg1)
	local var1 = arg1.pitchP
	local var2 = arg1.yawP
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var1, var2, num1)
end

local var4 = var1.mapClamp
local var5 = var1.map
tbl2.step = function(arg1, arg2, arg3, arg4, arg5)
	assert(typeof(arg2) == "number")
	assert(typeof(arg4) == "number")
	assert(typeof(arg3) == "number")
	assert(typeof(arg5) == "number")
	local var1 = arg1.fSpringYaw
	var1.g = var4(var5(arg5, 0, 1, arg4, 0), math.rad(var3.cutoffMinAngularVelYaw), math.rad(var3.cutoffMaxAngularVelYaw), 1, 0)
	local var6 = arg1.fSpringPitch
	var6.g = var4(var5(arg5, 0, 1, arg3, 0), math.rad(var3.cutoffMinAngularVelPitch), math.rad(var3.cutoffMaxAngularVelPitch), 1, 0)
	local var7 = arg1.yawG
	local var8 = 6.2831853071795862 * var3.yawStiffness * var1:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var9 = var2(arg1.yawP - var7)
	local var10 = arg1.yawV
	local var11 = math.exp(-var8 * arg2)
	local var12 = 6.2831853071795862 * var3.pitchStiffness * var6:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var13 = var2((var9 * (1 + var8 * arg2) + var10 * arg2) * var11 + var7)
	arg1.yawP = var13
	arg1.yawV = (var10 * (1 - var8 * arg2) - var9 * (var8 * var8 * arg2)) * var11
	var7 = arg1.pitchG
	var9 = var2(arg1.pitchP - var7)
	var10 = arg1.pitchV
	var11 = math.exp(-var12 * arg2)
	var13 = var2((var9 * (1 + var12 * arg2) + var10 * arg2) * var11 + var7)
	arg1.pitchP = var13
	arg1.pitchV = (var10 * (1 - var12 * arg2) - var9 * (var12 * var12 * arg2)) * var11
	return arg1:getCFrame()
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.new = function(arg1)
	return (setmetatable({ vrs = tbl2.new(arg1) }, tbl3))
end

tbl3.step = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg2
	local var2 = arg3
	local var3 = arg4
	local var4 = arg5
	return arg1.vrs:step(var1, var2, var3, var4)
end

tbl3.setTransform = function(arg1, arg2)
	arg1.vrs:setGoal(arg2)
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUI [ModuleScript]
-- y u r i

local bool1 = false
local tbl1 = {}
local var1 = game:GetService("StarterGui")
tbl1.setCameraModeToastEnabled = function(arg1)
	if not arg1 and (not bool1) then
		return
	end

	if not bool1 then
		bool1 = true
	end

	if not arg1 then
		tbl1.setCameraModeToastOpen(false)
	end
end

tbl1.setCameraModeToastOpen = function(arg1)
	assert(bool1)
	if arg1 then
		var1:SetCore("SendNotification", { Title = "Camera Control Enabled", Text = "Right click to toggle", Duration = 3 })
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
script.Parent:WaitForChild("CommonUtils")
local str1 = "Keyboard"
local str2 = "Gamepad"
local var1 = require(script:WaitForChild(str1))
local str3 = "DynamicThumbstick"
local var2 = require(script:WaitForChild(str2))
local var3 = require(script:WaitForChild(str3))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local str4 = "TouchThumbstick"
local str5 = "ClickToMoveController"
success = require(script:WaitForChild(str4))
local str6 = "TouchJump"
result = require(script:WaitForChild(str5))
local str7 = "VehicleController"
local var4 = require(script:WaitForChild(str6))
str4 = require(script:WaitForChild(str7))
local success, result = pcall(function()
	local str1 = "UserPlayerScriptsSupportMicroGamepad"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str5 = nil
str5 = success and result
local var5 = game:GetService("Players")
local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("GuiService")
local var9 = game:GetService("Workspace")
local var10 = UserSettings():GetService("UserGameSettings")
local var11 = game:GetService("VRService")
success = Enum.ContextActionPriority.Medium.Value
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.controllers = {}
	var1.activeControlModule = nil
	var1.activeController = nil
	var1.touchJumpController = nil
	var1.moveFunction = var5.LocalPlayer.Move
	var1.humanoid = nil
	var1.controlsEnabled = true
	var1.humanoidSeatedConn = nil
	var1.vehicleController = nil
	var1.touchControlFrame = nil
	var1.currentTorsoAngle = 0
	var1.inputMoveVector = Vector3.new(0, 0, 0)
	var1.vehicleController = str4.new(success)
	var5.LocalPlayer.CharacterAdded:Connect(function(arg1)
		var1:OnCharacterAdded(arg1)
	end)

	var5.LocalPlayer.CharacterRemoving:Connect(function(arg1)
		var1:OnCharacterRemoving(arg1)
	end)

	if var5.LocalPlayer.Character then
		var1:OnCharacterAdded(var5.LocalPlayer.Character)
	end

	var6:BindToRenderStep("ControlScriptRenderstep", Enum.RenderPriority.Input.Value, function(arg1)
		var1:OnRenderStepped(arg1)
	end)

	var10:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var10:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = nil
	var1.touchGui = nil
	var1.playerGuiAddedConn = nil
	var8:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		var1:UpdateMovementMode()
		var1:UpdateActiveControlModuleEnabled()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = var5.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not var1.playerGui then
		var1.playerGuiAddedConn = var5.LocalPlayer.ChildAdded:Connect(function(arg1)
			if arg1:IsA("PlayerGui") then
				var1.playerGui = arg1
				var1.playerGuiAddedConn:Disconnect()
				var1.playerGuiAddedConn = nil
				var1:UpdateMovementMode()
			end
		end)

	end

	var1:UpdateMovementMode()
	return var1
end

tbl1.GetMoveVector = function(arg1)
	if arg1.activeController then
		return arg1.activeController:GetMoveVector()
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetEstimatedVRTorsoFrame = function(arg1)
	local var1 = var11:GetUserCFrame(Enum.UserCFrame.Head)
	local var2, var3, var4 = var1:ToEulerAnglesYXZ()
	var3 = -var3
	if not var11:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) or (not var11:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)) then
		arg1.currentTorsoAngle = var3
	else
		local var5 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.LeftHand).Position
		local var6 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.RightHand).Position
		local var7 = -math.atan2(var5.X, var5.Z)
		local var9 = (-math.atan2(var6.X, var6.Z) - var7 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var12 = (var7 + var9 / 2 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var12 then
			var12 = var12 - 6.2831853071795862
		end

		var9 = (var3 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var14 = (var12 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var14 then
			var14 = var14 - 6.2831853071795862
		end

		local bool1 = false
		if -1.5707963267948966 < var14 then
			bool1 = var14 < 1.5707963267948966
		end

		if not bool1 then
			var14 = var9
		end

		local var16 = math.min(var14, var9)
		local var17 = math.max(var14, var9)
		local num2 = 0
		if 0 < var16 then
			num2 = var16
		else
			if var17 < 0 then
				num2 = var17
			end
		end

		local var18 = num2 + arg1.currentTorsoAngle
		arg1.currentTorsoAngle = var18
	end

	return CFrame.new(var1.Position) * CFrame.fromEulerAnglesYXZ(0, -arg1.currentTorsoAngle, 0)
end

tbl1.GetActiveController = function(arg1)
	return arg1.activeController
end

tbl1.UpdateActiveControlModuleEnabled = function(arg1)
	local function fn2()
		if arg1.touchControlFrame then
			if var7.PreferredInput == Enum.PreferredInput.Touch then
				if arg1.activeControlModule ~= result then
					if arg1.activeControlModule == success or arg1.activeControlModule == var3 then
						if not arg1.controllers[var4] then
							arg1.controllers[var4] = var4.new()
						end

						arg1.touchJumpController = arg1.controllers[var4]
						arg1.touchJumpController:Enable(true, arg1.touchControlFrame)
					else
						if arg1.touchJumpController then
							arg1.touchJumpController:Enable(false)
						end
					end
				end
			else
				if arg1.touchJumpController then
					arg1.touchJumpController:Enable(false)
				end
			end
		else
			if arg1.touchJumpController then
				arg1.touchJumpController:Enable(false)
			end
		end

		if arg1.activeControlModule == result then
			arg1.activeController:Enable(true, var5.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, arg1.touchJumpController)
			return
		end

		if arg1.touchControlFrame then
			arg1.activeController:Enable(true, arg1.touchControlFrame)
			return
		end

		arg1.activeController:Enable(true)
	end

	if not arg1.activeController then
		return
	end

	if not arg1.controlsEnabled then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	if not var8.TouchControlsEnabled and (var7.PreferredInput == Enum.PreferredInput.Touch and (arg1.activeControlModule == result or (arg1.activeControlModule == success or arg1.activeControlModule == var3))) then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	fn2()
end

tbl1.Enable = function(arg1, arg2)
	arg2 = arg2 == nil and true
	if arg1.controlsEnabled == arg2 then
		return
	end

	arg1.controlsEnabled = arg2
	if not arg1.activeController then
		return
	end

	arg1:UpdateActiveControlModuleEnabled()
end

tbl1.Disable = function(arg1)
	arg1:Enable(false)
end

result = {
	[Enum.TouchMovementMode.DPad] = var3,
	[Enum.DevTouchMovementMode.DPad] = var3,
	[Enum.TouchMovementMode.Thumbpad] = var3,
	[Enum.DevTouchMovementMode.Thumbpad] = var3,
	[Enum.TouchMovementMode.Thumbstick] = success,
	[Enum.DevTouchMovementMode.Thumbstick] = success,
	[Enum.TouchMovementMode.DynamicThumbstick] = var3,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = var3,
	[Enum.TouchMovementMode.ClickToMove] = result,
	[Enum.DevTouchMovementMode.ClickToMove] = result,
	[Enum.TouchMovementMode.Default] = var3,
	[Enum.ComputerMovementMode.Default] = var1,
	[Enum.ComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = result,
	[Enum.DevComputerMovementMode.ClickToMove] = result,
}

tbl1.SelectComputerMovementModule = function(_)
	if not var7.KeyboardEnabled and (not var7.GamepadEnabled) then
		return nil, false
	end

	local var4 = var5.LocalPlayer.DevComputerMovementMode
	local var6 = nil
	if var4 == Enum.DevComputerMovementMode.UserChoice then
		local bool3 = false
		if str5 then
			pcall(function()
				bool3 = var7.PreferredInput == Enum.PreferredInput.MicroGamepad
			end)

		end

		if var7.PreferredInput == Enum.PreferredInput.Gamepad or bool3 then
			var6 = var2
		else
			if var7.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				var6 = var1
			end
		end

		if var10.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove and var6 == var1 then
			var6 = result
		end
	else
		var6 = result[var4]
		if not var6 and var4 ~= Enum.DevComputerMovementMode.Scriptable then
			warn("No character control module is associated with DevComputerMovementMode ", var4)
		end
	end

	if var6 then
		return var6, true
	end

	if var4 == Enum.DevComputerMovementMode.Scriptable then
		return nil, true
	end

	return nil, false
end

tbl1.SelectTouchModule = function(_)
	local var3 = var5.LocalPlayer.DevTouchMovementMode
	local var4 = nil
	if var3 == Enum.DevTouchMovementMode.UserChoice then
		var4 = result[var10.TouchMovementMode]
	else
		if var3 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end

		var4 = result[var3]
	end

	return var4, true
end

local function getGamepadRightThumbstickPosition()
	for k1, v1 in pairs((var7:GetGamepadState(Enum.UserInputType.Gamepad1))) do
		if v1.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end

		return v1.Position
	end

	return Vector3.new(0, 0, 0)
end

tbl1.calculateRawMoveVector = function(arg1, arg2, arg3)
	local var2 = var9.CurrentCamera
	if not var2 then
		return arg3
	end

	local var5 = var2.CFrame
	if var11.VREnabled then
		if arg2.RootPart then
			var11:GetUserCFrame(Enum.UserCFrame.Head)
			local var8 = arg1:GetEstimatedVRTorsoFrame()
			var5 = if (var2.Focus.Position - var5.Position).Magnitude < 3 then var5 * var8 else var2.CFrame * (var8.Rotation + var8.Position * var2.HeadScale)
		end
	end

	if arg2:GetState() == Enum.HumanoidStateType.Swimming then
		if var11.VREnabled then
			arg3 = Vector3.new(arg3.X, 0, arg3.Z)
			if arg3.Magnitude < 0.01 then
				return Vector3.new(0, 0, 0)
			end

			local var10, var12, var13 = var5:ToEulerAnglesYXZ()
			return CFrame.fromEulerAnglesYXZ(-getGamepadRightThumbstickPosition().Y * 1.3962634015954636, math.atan2(-arg3.X, -arg3.Z) + var12, 0).LookVector
		end

		local var14 = arg3
		return var5:VectorToWorldSpace(var14)
	end

	local var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40 = var5:GetComponents()
	local var41 = nil
	local var42 = nil
	if var37 < 1 and -1 < var37 then
		var41 = var40
		var42 = var34
	else
		var41 = var32
		var42 = -var33 * math.sign(var37)
	end

	local var43 = math.sqrt(var41 * var41 + var42 * var42)
	return (Vector3.new((var41 * arg3.X + var42 * arg3.Z) / var43, 0, (var41 * arg3.Z - var42 * arg3.X) / var43))
end

tbl1.OnRenderStepped = function(arg1, arg2)
	if arg1.activeController then
		if arg1.activeController.enabled then
			if arg1.humanoid then
				local var7 = arg1:GetClickToMoveController()
				local var8 = arg1.activeController:GetMoveVector()
				local var9 = arg1.activeController:IsMoveVectorCameraRelative()
				if arg1.activeController == var7 then
					var7:OnRenderStepped(arg2)
				else
					if 0 < var8.magnitude then
						var7:CleanupPath()
					else
						var7:OnRenderStepped(arg2)
						var8 = var7:GetMoveVector()
						var9 = var7:IsMoveVectorCameraRelative()
					end
				end

				if arg1.vehicleController then
					local var10, var12 = arg1.vehicleController:Update(var8, var9, arg1.activeControlModule == var2)
					var8 = var10
				end

				if var9 then
					var8 = arg1:calculateRawMoveVector(arg1.humanoid, var8)
				end

				arg1.inputMoveVector = var8
				if var11.VREnabled then
					var8 = arg1:updateVRMoveVector(var8)
				end

				arg1.moveFunction(var5.LocalPlayer, var8, false)
				local var13 = arg1.activeController:GetIsJumping()
				var13 = var13 or arg1.touchJumpController and arg1.touchJumpController:GetIsJumping()
				arg1.humanoid.Jump = var13
			end
		end
	end
end

tbl1.updateVRMoveVector = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	local bool2 = false
	if (var1.Focus.Position - var1.CFrame.Position).Magnitude < 5 then
		bool2 = true
	end

	if arg2.Magnitude == 0 and (bool2 and (var11.AvatarGestures and (arg1.humanoid and (not arg1.humanoid.Sit)))) then
		local var4 = var11:GetUserCFrame(Enum.UserCFrame.Head)
		local var5 = (var1.CFrame * (var4.Rotation + var4.Position * var1.HeadScale) * CFrame.new(0, -0.7 * arg1.humanoid.RootPart.Size.Y / 2, 0)).Position - arg1.humanoid.RootPart.CFrame.Position
		return (Vector3.new(var5.x, 0, var5.z))
	end

	return arg2
end

tbl1.OnHumanoidSeated = function(arg1, arg2, arg3)
	if arg2 then
		if not arg3 then
			return
		end

		if not arg3:IsA("VehicleSeat") then
			return
		end

		if not arg1.vehicleController then
			local var1 = arg1.vehicleController.new(success)
			arg1.vehicleController = var1
		end

		arg1.vehicleController:Enable(true, arg3)
		return
	end

	if arg1.vehicleController then
		arg1.vehicleController:Enable(false, arg3)
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2)
	arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	while not arg1.humanoid do
		arg2.ChildAdded:wait()
		arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	end

	if arg1.humanoidSeatedConn then
		arg1.humanoidSeatedConn:Disconnect()
		arg1.humanoidSeatedConn = nil
	end

	arg1.humanoidSeatedConn = arg1.humanoid.Seated:Connect(function(arg1, arg2)
		arg1:OnHumanoidSeated(arg1, arg2)
	end)

	arg1:UpdateMovementMode()
end

tbl1.OnCharacterRemoving = function(arg1, _)
	arg1.humanoid = nil
	arg1:UpdateMovementMode()
end

tbl1.UpdateTouchGuiVisibility = function(arg1)
	local var2 = arg1.humanoid
	if var2 then
		var2 = var8.TouchControlsEnabled
		if var2 then
			var2 = var7.PreferredInput == Enum.PreferredInput.Touch
		end
	end

	if var2 and (not arg1.touchGui) then
		arg1:CreateTouchGuiContainer()
	end

	if arg1.touchGui then
		arg1.touchGui.Enabled = not not var2
	end
end

tbl1.SwitchToController = function(arg1, arg2)
	if not arg2 then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = nil
		arg1.activeControlModule = nil
		return
	end

	if not arg1.controllers[arg2] then
		arg1.controllers[arg2] = arg2.new(success)
	end

	if arg1.activeController ~= arg1.controllers[arg2] then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = arg1.controllers[arg2]
		arg1.activeControlModule = arg2
		arg1:UpdateActiveControlModuleEnabled()
	end
end

tbl1.UpdateMovementMode = function(arg1)
	arg1:UpdateTouchGuiVisibility()
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		local var1, var2 = arg1:SelectTouchModule()
		if not (var2 and arg1.touchControlFrame) then
			return
		end

		if not arg1.touchControlFrame then
			return
		end

		arg1:SwitchToController(var1)
		return
	end

	arg1:SwitchToController((arg1:SelectComputerMovementModule()))
end

tbl1.CreateTouchGuiContainer = function(arg1)
	if not arg1.playerGui then
		return
	end

	if arg1.touchGui then
		arg1.touchGui:Destroy()
	end

	arg1.touchGui = Instance.new("ScreenGui")
	arg1.touchGui.Name = "TouchGui"
	arg1.touchGui.ResetOnSpawn = false
	arg1.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	if str1 then
		arg1.touchGui.ClipToDeviceSafeArea = false
	end

	arg1.touchControlFrame = Instance.new("Frame")
	arg1.touchControlFrame.Name = "TouchControlFrame"
	arg1.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
	arg1.touchControlFrame.BackgroundTransparency = 1
	arg1.touchControlFrame.Parent = arg1.touchGui
	arg1.touchGui.Parent = arg1.playerGui
end

tbl1.GetClickToMoveController = function(arg1)
	if not arg1.controllers[result] then
		arg1.controllers[result] = result.new(success)
	end

	return arg1.controllers[result]
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick [ModuleScript]
-- y u r i

local tbl1 = { 0.10999999999999999, 0.30000000000000004, 0.4, 0.5, 0.6, 0.7, 0.75 }
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local var2 = var1.getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
success = nil
local var3 = game:GetService("Players")
result = var3.LocalPlayer
local var4 = Enum.ContextActionPriority.High.Value
local var5 = #tbl1
local var6 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local var7 = game:GetService("GuiService")
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("ContextActionService")
local var10 = game:GetService("RunService")
local var11 = game:GetService("TweenService")
local var12 = var1.getUserFlag("UserAllowAbilityControlsBonus")
success = var2 and require(script.Parent:WaitForChild(str2))
if not result then
	var3:GetPropertyChangedSignal("LocalPlayer"):Wait()
	result = var3.LocalPlayer
end

local str3 = "BaseCharacterController"
local var13 = require(script.Parent:WaitForChild(str3))
local var14 = setmetatable({}, var13)
var14.__index = var14
var14.new = function()
	local var1 = setmetatable(var13.new(), var14)
	var1.moveTouchObject = nil
	var1.moveTouchLockedIn = false
	var1.moveTouchFirstChanged = false
	var1.moveTouchStartPosition = nil
	var1.startImage = nil
	var1.endImage = nil
	var1.middleImages = {}
	var1.startImageFadeTween = nil
	var1.endImageFadeTween = nil
	var1.middleImageFadeTweens = {}
	var1.isFirstTouch = true
	var1.thumbstickFrame = nil
	var1.onRenderSteppedConn = nil
	var1.fadeInAndOutBalance = 0.5
	var1.fadeInAndOutHalfDuration = 0.3
	var1.hasFadedBackgroundInPortrait = false
	var1.hasFadedBackgroundInLandscape = false
	var1.tweenInAlphaStart = nil
	var1.tweenOutAlphaStart = nil
	return var1
end

var14.GetIsJumping = function(arg1)
	local var1 = arg1.isJumping
	arg1.isJumping = false
	return var1
end

var14.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1:BindContextActions()
	else
		arg1:UnbindContextActions()
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
	arg1.thumbstickFrame.Visible = arg2
	return nil
end

var14.OnInputEnded = function(arg1)
	arg1.moveTouchObject = nil
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1:FadeThumbstick(false)
end

var14.FadeThumbstick = function(arg1, arg2)
	if not arg2 and arg1.moveTouchObject then
		return
	end

	if arg1.isFirstTouch then
		return
	end

	if arg1.startImageFadeTween then
		arg1.startImageFadeTween:Cancel()
	end

	if arg1.endImageFadeTween then
		arg1.endImageFadeTween:Cancel()
	end

	for i1 = 1, #arg1.middleImages do
		if not arg1.middleImageFadeTweens[i1] then
			continue
		end

		arg1.middleImageFadeTweens[i1]:Cancel()
	end

	if arg2 then
		arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 0 })
		arg1.startImageFadeTween:Play()
		arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 0.2 })
		arg1.endImageFadeTween:Play()
		for i2 = 1, #arg1.middleImages do
			arg1.middleImageFadeTweens[i2] = var11:Create(arg1.middleImages[i2], var6, { ImageTransparency = tbl1[i2] })
			arg1.middleImageFadeTweens[i2]:Play()
		end

		return
	end

	arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 1 })
	arg1.startImageFadeTween:Play()
	arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 1 })
	arg1.endImageFadeTween:Play()
	for i3 = 1, #arg1.middleImages do
		arg1.middleImageFadeTweens[i3] = var11:Create(arg1.middleImages[i3], var6, { ImageTransparency = 1 })
		arg1.middleImageFadeTweens[i3]:Play()
	end
end

var14.FadeThumbstickFrame = function(arg1, arg2, arg3)
	arg1.fadeInAndOutHalfDuration = arg2 * 0.5
	arg1.fadeInAndOutBalance = arg3
	arg1.tweenInAlphaStart = tick()
end

var14.InputInFrame = function(arg1, arg2)
	local var1 = arg1.thumbstickFrame.AbsolutePosition
	local var2 = arg2.Position
	local var4 = var1 + arg1.thumbstickFrame.AbsoluteSize
	if var1.X <= var2.X and (var1.Y <= var2.Y and (var2.X <= var4.X and var2.Y <= var4.Y)) then
		return true
	end

	return false
end

var14.DoFadeInBackground = function(arg1)
	local var2 = result:FindFirstChildOfClass("PlayerGui")
	local bool2 = false
	if var2 then
		if var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft or var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight then
			bool2 = arg1.hasFadedBackgroundInLandscape
			arg1.hasFadedBackgroundInLandscape = true
		else
			if var2.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait then
				bool2 = arg1.hasFadedBackgroundInPortrait
				arg1.hasFadedBackgroundInPortrait = true
			end
		end
	end

	if not bool2 then
		arg1.fadeInAndOutHalfDuration = 0.3
		arg1.fadeInAndOutBalance = 0.5
		arg1.tweenInAlphaStart = tick()
	end
end

var14.DoMove = function(arg1, arg2)
	local var1 = arg2
	if var1.Magnitude < arg1.radiusOfDeadZone then
		var1 = Vector3.new(0, 0, 0)
	else
		var1 = var1.Unit * (1 - math.max(0, (arg1.radiusOfMaxSpeed - var1.Magnitude) / arg1.radiusOfMaxSpeed))
		var1 = Vector3.new(var1.X, 0, var1.Y)
	end

	arg1.moveVector = var1
end

var14.LayoutMiddleImages = function(arg1, arg2, arg3)
	local var1 = arg3 - arg2
	local var4 = var1.Magnitude - arg1.thumbstickRingSize / 2 - arg1.middleSize
	local var6 = arg1.thumbstickSize / 2 + arg1.middleSize
	local var7 = var1.Unit
	local var8 = arg1.middleSpacing
	if arg1.middleSpacing * var5 < var4 then
		var8 = var4 / var5
	end

	for i1 = 1, var5 do
		local var10 = arg1.middleImages[i1]
		if var6 + var8 * (i1 - 2) < var4 then
			local var11 = var6 + var8 * (i1 - 1)
			local var12 = math.clamp(1 - (var11 - var4) / var8, 0, 1)
			var10.Visible = true
			local var13 = arg3 - var7 * var11
			var10.Position = UDim2.new(0, var13.X, 0, var13.Y)
			var10.Size = UDim2.new(0, arg1.middleSize * var12, 0, arg1.middleSize * var12)
		else
			var10.Visible = false
		end
	end
end

var14.MoveStick = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, arg2.Y) - arg1.thumbstickFrame.AbsolutePosition
	local var2 = Vector2.new(arg1.moveTouchStartPosition.X, arg1.moveTouchStartPosition.Y) - arg1.thumbstickFrame.AbsolutePosition
	arg1.endImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
	arg1:LayoutMiddleImages(var2, var1)
end

var14.BindContextActions = function(arg1)
	local function inputBegan(arg1)
		if arg1.moveTouchObject then
			return Enum.ContextActionResult.Pass
		end

		if not arg1:InputInFrame(arg1) then
			return Enum.ContextActionResult.Pass
		end

		if arg1.isFirstTouch then
			arg1.isFirstTouch = false
			local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
			var11:Create(arg1.startImage, var1, { Size = UDim2.new(0, 0, 0, 0) }):Play()
			local tbl1 = { Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize) }
			tbl1.ImageColor3 = Color3.new(0, 0, 0)
			var11:Create(arg1.endImage, var1, tbl1):Play()
		end

		arg1.moveTouchLockedIn = false
		arg1.moveTouchObject = arg1
		arg1.moveTouchStartPosition = arg1.Position
		arg1.moveTouchFirstChanged = true
		arg1:DoFadeInBackground()
		return Enum.ContextActionResult.Pass
	end

	var9:BindActionAtPriority("DynamicThumbstickAction", function(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Begin then
			return (inputBegan(arg3))
		end

		if arg2 == Enum.UserInputState.Change then
			if arg3 == arg1.moveTouchObject then
				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.End then
			if arg3 == arg1.moveTouchObject then
				arg1:OnInputEnded()
				if arg1.moveTouchLockedIn then
					return Enum.ContextActionResult.Sink
				end
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.Cancel then
			arg1:OnInputEnded()
		end
	end, false, var4, Enum.UserInputType.Touch)

	local function inputChanged(arg1)
		if arg1 == arg1.moveTouchObject then
			if arg1.moveTouchFirstChanged then
				arg1.moveTouchFirstChanged = false
				local var1 = Vector2.new(arg1.Position.X - arg1.thumbstickFrame.AbsolutePosition.X, arg1.Position.Y - arg1.thumbstickFrame.AbsolutePosition.Y)
				arg1.startImage.Visible = true
				arg1.startImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
				arg1.endImage.Visible = true
				arg1.endImage.Position = arg1.startImage.Position
				arg1:FadeThumbstick(true)
				arg1:MoveStick(arg1.Position)
			end

			arg1.moveTouchLockedIn = true
			local var2 = Vector2.new(arg1.Position.X - arg1.moveTouchStartPosition.X, arg1.Position.Y - arg1.moveTouchStartPosition.Y)
			if 0 < math.abs(var2.X) or 0 < math.abs(var2.Y) then
				arg1:DoMove(var2)
				arg1:MoveStick(arg1.Position)
			end

			return Enum.ContextActionResult.Sink
		end

		return Enum.ContextActionResult.Pass
	end

	arg1.TouchMovedCon = var8.TouchMoved:Connect(function(arg1, _)
		inputChanged(arg1)
	end)
end

var14.UnbindContextActions = function(arg1)
	var9:UnbindAction("DynamicThumbstickAction")
	if arg1.TouchMovedCon then
		arg1.TouchMovedCon:Disconnect()
	end
end

var14.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onRenderSteppedConn then
			arg1.onRenderSteppedConn:Disconnect()
			arg1.onRenderSteppedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var2 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	local var1 = if str1 then 100 else 0
	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.BorderSizePixel = 0
	arg1.thumbstickFrame.Name = "DynamicThumbstickFrame"
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	arg1.thumbstickFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	arg1.thumbstickFrame.Active = false
	arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
	arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	arg1.startImage = Instance.new("ImageLabel")
	arg1.startImage.Name = "ThumbstickStart"
	arg1.startImage.Visible = true
	arg1.startImage.BackgroundTransparency = 1
	arg1.startImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.startImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.startImage.ImageRectSize = Vector2.new(144, 144)
	arg1.startImage.ImageColor3 = Color3.new(0, 0, 0)
	arg1.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.startImage.ZIndex = 10
	arg1.startImage.Parent = arg1.thumbstickFrame
	arg1.endImage = Instance.new("ImageLabel")
	arg1.endImage.Name = "ThumbstickEnd"
	arg1.endImage.Visible = true
	arg1.endImage.BackgroundTransparency = 1
	arg1.endImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.endImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.endImage.ImageRectSize = Vector2.new(144, 144)
	arg1.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.endImage.ZIndex = 10
	arg1.endImage.Parent = arg1.thumbstickFrame
	local function layoutThumbstickFrame(arg1)
		if arg1 then
			arg1.thumbstickFrame.Size = UDim2.new(1, var1, 0.4, var1)
			arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.6, 0)
			return
		end

		arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
		arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	end

	for i1 = 1, var5 do
		arg1.middleImages[i1] = Instance.new("ImageLabel")
		arg1.middleImages[i1].Name = "ThumbstickMiddle"
		arg1.middleImages[i1].Visible = false
		arg1.middleImages[i1].BackgroundTransparency = 1
		arg1.middleImages[i1].Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.middleImages[i1].ImageRectOffset = Vector2.new(1, 1)
		arg1.middleImages[i1].ImageRectSize = Vector2.new(144, 144)
		arg1.middleImages[i1].ImageTransparency = tbl1[i1]
		arg1.middleImages[i1].AnchorPoint = Vector2.new(0.5, 0.5)
		arg1.middleImages[i1].ZIndex = 9
		arg1.middleImages[i1].Parent = arg1.thumbstickFrame
	end

	local function ResizeThumbstick()
		local var3 = arg2.AbsoluteSize
		local var5 = 500 < math.min(var3.X, var3.Y)
		if var2 then
			local var7 = if var5 then 2 else 1
			if var12 and (success.isEnabled() and var5) then
				var7 = 1.6216216216216217
			end

			arg1.thumbstickSize = 45 * var7
			arg1.thumbstickRingSize = 20 * var7
			arg1.middleSize = 10 * var7
			arg1.middleSpacing = 14 * var7
			arg1.radiusOfDeadZone = 2 * var7
			arg1.radiusOfMaxSpeed = 20 * var7
			local var8 = 74 * var7
			if success.isEnabled() then
				local var9 = if var5 then 100 else 64
				arg1.startImage.Position = UDim2.new(0, var8 * 0.5 + var1 + var9, 1, -var8 * 0.5 - var1 - (if var5 then 112 else 64))
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			else
				arg1.startImage.Position = UDim2.new(0, arg1.thumbstickRingSize * 3.3 + var1, 1, -arg1.thumbstickRingSize * 2.8 - var1)
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			end
		elseif var5 then
			arg1.thumbstickSize = 90
			arg1.thumbstickRingSize = 40
			arg1.middleSize = 20
			arg1.middleSpacing = 28
			arg1.radiusOfDeadZone = 4
			arg1.radiusOfMaxSpeed = 40
		else
			arg1.thumbstickSize = 45
			arg1.thumbstickRingSize = 20
			arg1.middleSize = 10
			arg1.middleSpacing = 14
			arg1.radiusOfDeadZone = 2
			arg1.radiusOfMaxSpeed = 20
		end

		arg1.endImage.Position = arg1.startImage.Position
		arg1.endImage.Size = UDim2.new(0, arg1.thumbstickSize * 0.8, 0, arg1.thumbstickSize * 0.8)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var2 then
		arg1.avatarAbilitiesEnabledChangedConn = success.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	local var3 = nil
	local function onCurrentCameraChanged()
		if var3 then
			var3:Disconnect()
			var3 = nil
		end

		local var2 = workspace.CurrentCamera
		if var2 then
			var3 = var2:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				local var1 = var2.ViewportSize
				layoutThumbstickFrame(var1.X < var1.Y)
			end)

			local var4 = var2.ViewportSize
			layoutThumbstickFrame(var4.X < var4.Y)
		end
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(onCurrentCameraChanged)
	if workspace.CurrentCamera then
		onCurrentCameraChanged()
	end

	arg1.moveTouchStartPosition = nil
	arg1.startImageFadeTween = nil
	arg1.endImageFadeTween = nil
	arg1.middleImageFadeTweens = {}
	arg1.onRenderSteppedConn = var10.RenderStepped:Connect(function()
		if arg1.tweenInAlphaStart ~= nil then
			local var3 = tick() - arg1.tweenInAlphaStart
			local var4 = arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = 1 - math.min(var3 / var4, 1) * 0.35
			if var4 >= var3 then
				return
			end

			arg1.tweenOutAlphaStart = tick()
			arg1.tweenInAlphaStart = nil
			return
		end

		if arg1.tweenOutAlphaStart ~= nil then
			local var7 = tick() - arg1.tweenOutAlphaStart
			local var8 = arg1.fadeInAndOutHalfDuration * 2 - arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = math.min(var7 / var8, 1) * 0.35 + 0.65
			if var8 < var7 then
				arg1.tweenOutAlphaStart = nil
			end
		end
	end)

	arg1.onTouchEndedConn = var8.TouchEnded:connect(function(arg1)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var7.MenuOpened:connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	local var4 = result:FindFirstChildOfClass("PlayerGui")
	while not var4 do
		result.ChildAdded:wait()
		var4 = result:FindFirstChildOfClass("PlayerGui")
	end

	local var6 = nil
	local bool1 = true
	if var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.LandscapeLeft then
		bool1 = var4.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight
	end

	var4:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		if bool1 and var4.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait or not bool1 and var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.Portrait then
			var6:disconnect()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
			if bool1 then
				arg1.hasFadedBackgroundInPortrait = true
				return
			end

			arg1.hasFadedBackgroundInLandscape = true
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
	if game:IsLoaded() then
		arg1.fadeInAndOutHalfDuration = 2.5
		arg1.fadeInAndOutBalance = 0.05
		arg1.tweenInAlphaStart = tick()
	else
		coroutine.wrap(function()
			game.Loaded:Wait()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
		end)()

	end
end

return var14

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController [ModuleScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "UserExcludeNonCollidableForPathfinding"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local success, result = pcall(function()
	local str1 = "UserClickToMoveSupportAgentCanClimb2"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

game:GetService("Debris")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("PathfindingService")
local var4 = game:GetService("Players")
local var5 = game:GetService("StarterGui")
local var6 = game:GetService("Workspace")
local var7 = game:GetService("CollectionService")
local var8 = game:GetService("GuiService")
local str2 = "ClickToMoveDisplay"
local var9 = require(script.Parent:WaitForChild(str2))
local var10 = RaycastParams.new()
var10.FilterType = Enum.RaycastFilterType.Exclude
local var11 = success and result
local var12 = success and result
local bool1 = true
str1 = true
local bool2 = false
local num1 = 1
local num2 = 8
local tbl1 = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true,
}

local var13 = var4.LocalPlayer
local tbl2 = {}
if not var1 then
	str2 = function(arg1)
		if arg1 then
			local var2 = arg1:FindFirstChildOfClass("Humanoid")
			if var2 then
				return arg1, var2
			end

			local var3 = arg1.Parent
			return str2(var3)
		end
	end

	tbl2.FindCharacterAncestor = str2
	local function Raycast(arg1, arg2, arg3)
		local var1 = arg3
		arg3 = var1 or {}
		local var7, var8, var9, var10 = var6:FindPartOnRayWithIgnoreList(arg1, arg3)
		if var7 then
			if arg2 then
				if var7.CanCollide == false then
					local var13
					if var7 then
						local var15 = var7:FindFirstChildOfClass("Humanoid")
						if var15 then
							local var16 = var7
							var13 = var15
						else
							local var17, var18 = str2(var7.Parent)
							local var19 = var17
							var13 = var18
						end
					else
						local var20 = nil
						var13 = nil
					end

					if var13 == nil then
						table.insert(arg3, var7)
						local var21 = arg1
						local var22 = arg2
						local var23 = arg3
						return Raycast(var21, var22, var23)
					end
				end
			end

			return var7, var8, var9, var10
		end

		return nil, nil
	end

	tbl2.Raycast = Raycast
end

str2 = {}
local var14 = nil
local var15 = nil
local var16 = nil
local var17 = nil
local function getCollidableExtentsSize(arg1)
	if arg1 == nil or arg1.PrimaryPart == nil then
		return
	end

	assert(arg1, "")
	assert(arg1.PrimaryPart, "")
	local var1 = arg1.PrimaryPart.CFrame:Inverse()
	local var2 = Vector3.new(inf, inf, inf)
	local var3 = Vector3.new(-inf, -inf, -inf)
	for k1, v1 in pairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if not v1.CanCollide then
			continue
		end

		local var4 = Vector3.new(v1.Size.X / 2, v1.Size.Y / 2, v1.Size.Z / 2)
		local var5 = Vector3.new(-var4.X, var4.Y, var4.Z)
		local var6 = var1 * v1.CFrame
		for k2, v2 in ipairs({
			Vector3.new(var4.X, var4.Y, var4.Z),
			Vector3.new(var4.X, var4.Y, -var4.Z),
			Vector3.new(var4.X, -var4.Y, var4.Z),
			Vector3.new(var4.X, -var4.Y, -var4.Z),
			var5,
			Vector3.new(-var4.X, var4.Y, -var4.Z),
			Vector3.new(-var4.X, -var4.Y, var4.Z),
			(Vector3.new(-var4.X, -var4.Y, -var4.Z)),
		}) do

			local var7 = var2
			local var8 = var6 * v2
			var2 = Vector3.new(math.min(var7.X, var8.X), math.min(var7.Y, var8.Y), (math.min(var7.Z, var8.Z)))
			var7 = var3
			var3 = Vector3.new(math.max(var7.X, var8.X), math.max(var7.Y, var8.Y), (math.max(var7.Z, var8.Z)))
		end
	end

	local var9 = var3 - var2
	if var9.X < 0 or (var9.Y < 0 or var9.Z < 0) then
		return nil
	end

	return var9
end

local var18 = nil
local var19 = nil
local var20 = nil
local function GetEquippedTool(arg1)
	if arg1 ~= nil then
		for k1, v1 in pairs(arg1:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			return v1
		end
	end
end

local function Pather(arg1, arg2, arg3)
	local var5 = nil
	local var7 = nil
	local tbl1 = {}
	if arg3 ~= nil then
		var5 = arg3
		var7 = arg3
	else
		var5 = bool2
		var7 = true
	end

	tbl1.Cancelled = false
	tbl1.Started = false
	tbl1.Finished = Instance.new("BindableEvent")
	tbl1.PathFailed = Instance.new("BindableEvent")
	tbl1.PathComputing = false
	tbl1.PathComputed = false
	tbl1.OriginalTargetPoint = arg1
	tbl1.TargetPoint = arg1
	tbl1.TargetSurfaceNormal = arg2
	tbl1.DiedConn = nil
	tbl1.SeatedConn = nil
	tbl1.BlockedConn = nil
	tbl1.TeleportedConn = nil
	tbl1.CurrentPoint = 0
	tbl1.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPosition = nil
	tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPlaneDistance = 0
	tbl1.CurrentWaypointNeedsJump = false
	tbl1.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	tbl1.CurrentHumanoidVelocity = 0
	tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
	tbl1.NextActionJump = false
	tbl1.Timeout = 0
	local var8 = var13
	local var14 = var8
	var14 = var14 and var8.Character
	local var16
	if var14 then
		local var19 = str2[var8]
		if var19 and var19.Parent == var14 then
			var16 = var19
		else
			str2[var8] = nil
			local var21 = var14:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var8] = var21
			end

			var16 = var21
		end
	else
		var16 = nil
	end

	tbl1.Humanoid = var16
	tbl1.OriginPoint = nil
	tbl1.AgentCanFollowPath = false
	tbl1.DirectPath = false
	tbl1.DirectPathRiseFirst = false
	tbl1.stopTraverseFunc = nil
	tbl1.setPointFunc = nil
	tbl1.pointList = nil
	var16 = tbl1.Humanoid
	var16 = var16 and tbl1.Humanoid.RootPart
	if var16 then
		tbl1.OriginPoint = var16.CFrame.Position
		local var24 = tbl1.Humanoid.SeatPart
		var8 = 2
		var14 = 5
		local bool3 = true
		if var24 then
			if var24:IsA("VehicleSeat") then
				local var27 = var24:FindFirstAncestorOfClass("Model")
				if var27 then
					local var28 = var27.PrimaryPart
					var27.PrimaryPart = var24
					if var7 then
						local var30 = var27:GetExtentsSize()
						var8 = num1 * 0.5 * math.sqrt(var30.X * var30.X + var30.Z * var30.Z)
						tbl1.AgentCanFollowPath = true
						tbl1.DirectPath = var7
						var14 = num1 * var30.Y
						bool3 = false
					end

					var27.PrimaryPart = var28
				end
			else
				local var33 = nil
				if var11 then
					local var34 = var13
					var34 = var34 and var13.Character
					if var34 ~= nil then
						var33 = getCollidableExtentsSize(var34)
					end
				end

				if var33 == nil then
					local var35 = var13
					var33 = (var35 and var13.Character):GetExtentsSize()
				end

				assert(var33, "")
				var8 = num1 * 0.5 * math.sqrt(var33.X * var33.X + var33.Z * var33.Z)
				tbl1.AgentCanFollowPath = true
				tbl1.DirectPath = var5
				tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
				var14 = num1 * var33.Y
				bool3 = 0 < tbl1.Humanoid.JumpPower
			end
		else
			local var38 = nil
			if var11 then
				local var39 = var13
				var39 = var39 and var13.Character
				if var39 ~= nil then
					var38 = getCollidableExtentsSize(var39)
				end
			end

			if var38 == nil then
				local var40 = var13
				var38 = (var40 and var13.Character):GetExtentsSize()
			end

			assert(var38, "")
			var8 = num1 * 0.5 * math.sqrt(var38.X * var38.X + var38.Z * var38.Z)
			tbl1.AgentCanFollowPath = true
			tbl1.DirectPath = var5
			tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
			var14 = num1 * var38.Y
			bool3 = 0 < tbl1.Humanoid.JumpPower
		end

		if var12 then
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3, AgentCanClimb = true })
		else
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3 })
		end
	end

	tbl1.Cleanup = function(_)
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		if tbl1.BlockedConn then
			tbl1.BlockedConn:Disconnect()
			tbl1.BlockedConn = nil
		end

		if tbl1.DiedConn then
			tbl1.DiedConn:Disconnect()
			tbl1.DiedConn = nil
		end

		if tbl1.SeatedConn then
			tbl1.SeatedConn:Disconnect()
			tbl1.SeatedConn = nil
		end

		if tbl1.TeleportedConn then
			tbl1.TeleportedConn:Disconnect()
			tbl1.TeleportedConn = nil
		end

		tbl1.Started = false
	end

	tbl1.Cancel = function(_)
		tbl1.Cancelled = true
		tbl1:Cleanup()
	end

	tbl1.IsActive = function(_)
		local var1 = tbl1.AgentCanFollowPath
		return var1 and (tbl1.Started and (not tbl1.Cancelled))
	end

	tbl1.OnPathInterrupted = function(_)
		tbl1.Cancelled = true
		tbl1:OnPointReached(false)
	end

	tbl1.ComputePath = function(_)
		if tbl1.OriginPoint then
			if tbl1.PathComputed or tbl1.PathComputing then
				return
			end

			tbl1.PathComputing = true
			if tbl1.AgentCanFollowPath then
				if tbl1.DirectPath then
					local var5 = tbl1.TargetPoint
					local var6 = tbl1.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk
					local tbl2 = {
						PathWaypoint.new(tbl1.OriginPoint, Enum.PathWaypointAction.Walk),
						PathWaypoint.new(var5, var6),
					}

					tbl1.pointList = tbl2
					tbl1.PathComputed = true
				else
					tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
					tbl1.pointList = tbl1.pathResult:GetWaypoints()
					tbl1.BlockedConn = tbl1.pathResult.Blocked:Connect(function(arg1)
						tbl1:OnPathBlocked(arg1)
					end)

					tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
				end
			end

			tbl1.PathComputing = false
		end
	end

	tbl1.IsValidPath = function(_)
		tbl1:ComputePath()
		local var1 = tbl1.PathComputed
		return var1 and tbl1.AgentCanFollowPath
	end

	tbl1.Recomputing = false
	tbl1.OnPathBlocked = function(_, arg2)
		if not (tbl1.CurrentPoint <= arg2) or tbl1.Recomputing then
			return
		end

		tbl1.Recomputing = true
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		tbl1.OriginPoint = tbl1.Humanoid.RootPart.CFrame.p
		tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
		tbl1.pointList = tbl1.pathResult:GetWaypoints()
		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = tbl1.pointList[1].Position - tbl1.OriginPoint
		end

		tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
		if bool1 then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if tbl1.PathComputed then
			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
		else
			tbl1.PathFailed:Fire()
			tbl1:Cleanup()
		end

		tbl1.Recomputing = false
	end

	tbl1.OnRenderStepped = function(_, arg2)
		if tbl1.Started and (not tbl1.Cancelled) then
			tbl1.Timeout = tbl1.Timeout + arg2
			if num2 < tbl1.Timeout then
				tbl1:OnPointReached(false)
				return
			end

			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			while tbl1.Started and tbl1:IsCurrentWaypointReached() do
				tbl1:OnPointReached(true)
			end

			if tbl1.Started then
				tbl1.NextActionMoveDirection = tbl1.CurrentWaypointPosition - tbl1.CurrentHumanoidPosition
				if 1e-06 < tbl1.NextActionMoveDirection.Magnitude then
					tbl1.NextActionMoveDirection = tbl1.NextActionMoveDirection.Unit
				else
					tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end

				if tbl1.CurrentWaypointNeedsJump then
					tbl1.NextActionJump = true
					tbl1.CurrentWaypointNeedsJump = false
					return
				end

				tbl1.NextActionJump = false
			end
		end
	end

	tbl1.IsCurrentWaypointReached = function(_)
		local bool1 = false
		if tbl1.CurrentWaypointPlaneNormal ~= Vector3.new(0, 0, 0) then
			bool1 = tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidPosition) - tbl1.CurrentWaypointPlaneDistance < math.max(1, 0.0625 * -tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidVelocity))
		else
			bool1 = true
		end

		if bool1 then
			tbl1.CurrentWaypointPosition = nil
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		return bool1
	end

	tbl1.OnPointReached = function(_, arg2)
		if arg2 then
			if not tbl1.Cancelled then
				if tbl1.setPointFunc then
					tbl1.setPointFunc(tbl1.CurrentPoint)
				end

				local var2 = tbl1.CurrentPoint + 1
				if #tbl1.pointList < var2 then
					if tbl1.stopTraverseFunc then
						tbl1.stopTraverseFunc()
					end

					tbl1.Finished:Fire()
					tbl1:Cleanup()
					return
				end

				local var4 = tbl1.Humanoid:GetState()
				local var5 = tbl1.pointList[tbl1.CurrentPoint]
				local var6 = tbl1.pointList[var2]
				local bool2 = true
				if var4 ~= Enum.HumanoidStateType.FallingDown then
					bool2 = true
					if var4 ~= Enum.HumanoidStateType.Freefall then
						bool2 = var4 == Enum.HumanoidStateType.Jumping
					end
				end

				if bool2 then
					local var10 = var6.Action == Enum.PathWaypointAction.Jump
					if not var10 then
						if 1 < tbl1.CurrentPoint then
							local var13 = var5.Position - tbl1.pointList[tbl1.CurrentPoint - 1].Position
							local var14 = var6.Position - var5.Position
							var10 = Vector2.new(var13.x, var13.z).Unit:Dot(Vector2.new(var14.x, var14.z).Unit) < 0.996
						end
					end

					if var10 then
						tbl1.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end

				tbl1:MoveToNextWayPoint(var5, var6, var2)
				return
			end
		end

		tbl1.PathFailed:Fire()
		tbl1:Cleanup()
	end

	tbl1.MoveToNextWayPoint = function(_, arg2, arg3, arg4)
		tbl1.CurrentWaypointPlaneNormal = arg2.Position - arg3.Position
		if not var12 or arg3.Label ~= "Climb" then
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(tbl1.CurrentWaypointPlaneNormal.X, 0, tbl1.CurrentWaypointPlaneNormal.Z)
		end

		if 1e-06 < tbl1.CurrentWaypointPlaneNormal.Magnitude then
			tbl1.CurrentWaypointPlaneNormal = tbl1.CurrentWaypointPlaneNormal.Unit
			tbl1.CurrentWaypointPlaneDistance = tbl1.CurrentWaypointPlaneNormal:Dot(arg3.Position)
		else
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		tbl1.CurrentWaypointNeedsJump = arg3.Action == Enum.PathWaypointAction.Jump
		tbl1.CurrentWaypointPosition = arg3.Position
		tbl1.CurrentPoint = arg4
		tbl1.Timeout = 0
	end

	tbl1.Start = function(_, arg2)
		if not tbl1.AgentCanFollowPath then
			tbl1.PathFailed:Fire()
			return
		end

		if tbl1.Started then
			return
		end

		tbl1.Started = true
		var9.CancelFailureAnimation()
		if bool1 and (arg2 == nil or arg2) then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList, tbl1.OriginalTargetPoint)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = Vector3.new(0, tbl1.pointList[1].Position.Y - tbl1.OriginPoint.Y, 0)
			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			tbl1.SeatedConn = tbl1.Humanoid.Seated:Connect(function(_, _)
				tbl1:OnPathInterrupted()
			end)

			tbl1.DiedConn = tbl1.Humanoid.Died:Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.TeleportedConn = tbl1.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
			return
		end

		tbl1.PathFailed:Fire()
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
		end
	end

	var8 = tbl1.TargetPoint + tbl1.TargetSurfaceNormal * 1.5
	if var1 then
		var14 = var10
		local var41
		if var17 then
			var41 = var17
		else
			var17 = {}
			assert(var17, "")
			local var42 = var13
			table.insert(var17, var42 and var13.Character)
			var41 = var17
		end

		var14.FilterDescendantsInstances = var41
		var14 = var6:Raycast(var8, Vector3.new(-0, -50, -0), var10)
		if var14 then
			tbl1.TargetPoint = var14.Position
		end
	else
		var41 = var6
		local var43 = Ray.new(var8, Vector3.new(0, -50, 0))
		local var44
		if var17 then
			var44 = var17
		else
			var17 = {}
			assert(var17, "")
			local var45 = var13
			table.insert(var17, var45 and var13.Character)
			var44 = var17
		end

		local var46, var47 = var41:FindPartOnRayWithIgnoreList(var43, var44)
		if var46 then
			tbl1.TargetPoint = var47
		end
	end

	tbl1:ComputePath()
	return tbl1
end

local function HandleMoveTo(arg1, arg2, arg3, arg4, arg5)
	if var18 then
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end

	var18 = arg1
	arg1:Start(arg5)
	var19 = arg1.Finished.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		local var2 = GetEquippedTool(arg4)
		if arg3 and var2 then
			var2:Activate()
		end
	end)

	var20 = arg1.PathFailed.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		if arg5 ~= nil then
			if not arg5 then
				return
			end
		end

		local var1 = str1
		if var1 and (not var18:IsActive()) then
			var9.PlayFailureAnimation()
		end

		var9.DisplayFailureWaypoint(arg2)
	end)
end

function OnTap(arg1, arg2, arg3)
	local var2 = var13
	local var3 = var2
	var3 = var3 and var2.Character
	local var8 = var6.CurrentCamera
	local var11 = var13.Character
	local var12
	if var3 then
		local var15 = str2[var2]
		if var15 and var15.Parent == var3 then
			var12 = var15
		else
			str2[var2] = nil
			local var21 = var3:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var2] = var21
			end

			var12 = var21
		end
	else
		var12 = nil
	end

	local bool1 = false
	if var12 ~= nil then
		bool1 = 0 < var12.Health
	end

	if not bool1 then
		return
	end

	if #arg1 ~= 1 then
		if arg2 then
			if not var8 then
				return
			end

			bool1 = var8:ScreenPointToRay(arg1[1].X, arg1[1].Y)
			if var1 then
				var12 = nil
				var2 = nil
				var3 = nil
				local var22
				if var17 then
					var22 = var17
				else
					var17 = {}
					assert(var17, "")
					local var23 = var13
					table.insert(var17, var23 and var13.Character)
					var22 = var17
				end

				var22 = var22 or {}
				repeat
					var10.FilterDescendantsInstances = var22
					var3 = var6:Raycast(bool1.Origin, bool1.Direction * 1000, var10)
					local bool2 = true
					if var3 then
						local var25 = var3.Instance
						if not var25.CanCollide then
							repeat
								var12 = var25:FindFirstChildOfClass("Humanoid")
								var2 = var25
								var25 = var25.Parent
							until var12 or (not var25)

							if not var12 and var25 then
								table.insert(var22, var25)
								var2 = nil
								bool2 = false
							end
						end
					end
				until bool2

				if arg3 then
					if var12 then
						if var5:GetCore("AvatarContextMenuEnabled") then
							if var4:GetPlayerFromCharacter(var12.Parent) then
								if var18 then
									var18:Cancel()
									var18 = nil
								end

								if var19 then
									var19:Disconnect()
									var19 = nil
								end

								if var20 then
									var20:Disconnect()
									var20 = nil
								end

								return
							end
						end
					end
				end

				if not var3 or (not var11) then
					return
				end

				local var27 = var3.Position
				if arg2 then
					var2 = nil
					var27 = arg2
				end

				if var18 then
					var18:Cancel()
					var18 = nil
				end

				if var19 then
					var19:Disconnect()
					var19 = nil
				end

				if var20 then
					var20:Disconnect()
					var20 = nil
				end

				local var28 = Pather(var27, var3.Normal)
				if var28:IsValidPath() then
					HandleMoveTo(var28, var27, var2, var11)
					return
				end

				var28:Cleanup()
				if var18 and var18:IsActive() then
					var18:Cancel()
				end

				if str1 then
					var9.PlayFailureAnimation()
				end

				var9.DisplayFailureWaypoint(var27)
				return
			end

			var2 = tbl2.Raycast
			var3 = Ray.new(bool1.Origin, bool1.Direction * 1000)
			var22 = true
			local var29
			if var17 then
				var29 = var17
			else
				var17 = {}
				assert(var17, "")
				local var30 = var13
				table.insert(var17, var30 and var13.Character)
				var29 = var17
			end

			local var31, var32, var33 = var2(var3, var22, var29)
			local var34, var35 = tbl2.FindCharacterAncestor(var31)
			if arg3 then
				if var35 then
					if var5:GetCore("AvatarContextMenuEnabled") then
						if var4:GetPlayerFromCharacter(var35.Parent) then
							if var18 then
								var18:Cancel()
								var18 = nil
							end

							if var19 then
								var19:Disconnect()
								var19 = nil
							end

							if var20 then
								var20:Disconnect()
								var20 = nil
							end

							return
						end
					end
				end
			end

			if arg2 then
				var32 = arg2
				var34 = nil
			end

			if not var32 then
				return
			end

			if not var11 then
				return
			end

			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var36 = Pather(var32, var33)
			if var36:IsValidPath() then
				HandleMoveTo(var36, var32, var34, var11)
				return
			end

			var36:Cleanup()
			if var18 and var18:IsActive() then
				var18:Cancel()
			end

			if str1 then
				var9.PlayFailureAnimation()
			end

			var9.DisplayFailureWaypoint(var32)
			return
		end
	end

	bool1 = GetEquippedTool(var11)
	if 2 <= (#arg1) and (var8 and bool1) then
		bool1:Activate()
	end
end

local str3 = "Keyboard"
local var21 = require(script.Parent:WaitForChild(str3))
local var22 = setmetatable({}, var21)
var22.__index = var22
var22.new = function(arg1)
	local var1 = setmetatable(var21.new(arg1), var22)
	var1.fingerTouches = {}
	var1.numUnsunkTouches = 0
	var1.mouse2DownTime = tick()
	var1.mouse2DownPos = Vector2.new()
	var1.mouse2UpTime = tick()
	var1.keyboardMoveVector = Vector3.new(0, 0, 0)
	var1.tapConn = nil
	var1.inputBeganConn = nil
	var1.inputChangedConn = nil
	var1.inputEndedConn = nil
	var1.humanoidDiedConn = nil
	var1.characterChildAddedConn = nil
	var1.onCharacterAddedConn = nil
	var1.characterChildRemovedConn = nil
	var1.renderSteppedConn = nil
	var1.menuOpenedConnection = nil
	var1.preferredInputChangedConnection = nil
	var1.running = false
	var1.wasdEnabled = false
	return var1
end

var22.DisconnectEvents = function(arg1)
	local var2 = arg1.tapConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputBeganConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputChangedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputEndedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.humanoidDiedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.onCharacterAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.renderSteppedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildRemovedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.menuOpenedConnection
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.preferredInputChangedConnection
	if var2 then
		var2:Disconnect()
	end
end

var22.OnTouchBegan = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil and (not arg3) then
		local var1 = arg1.numUnsunkTouches + 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = arg3
end

var22.OnTouchChanged = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil then
		arg1.fingerTouches[arg2] = arg3
		if not arg3 then
			local var1 = arg1.numUnsunkTouches + 1
			arg1.numUnsunkTouches = var1
		end
	end
end

var22.OnTouchEnded = function(arg1, arg2, _)
	if arg1.fingerTouches[arg2] ~= nil and arg1.fingerTouches[arg2] == false then
		local var1 = arg1.numUnsunkTouches - 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = nil
end

var22.OnPreferredInputChanged = function(_)
	local var3 = var13.Character
	if var3 then
		local var4 = var2.PreferredInput == Enum.PreferredInput.Touch
		for k1, v1 in pairs(var3:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			v1.ManualActivationOnly = var4
		end
	end
end

var22.OnCharacterAdded = function(arg1, arg2)
	arg1:DisconnectEvents()
	arg1.inputBeganConn = var2.InputBegan:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchBegan(arg1, arg2)
		end

		if arg1.wasdEnabled then
			if arg2 == false then
				if arg1.UserInputType == Enum.UserInputType.Keyboard then
					if tbl1[arg1.KeyCode] then
						if var18 then
							var18:Cancel()
							var18 = nil
						end

						if var19 then
							var19:Disconnect()
							var19 = nil
						end

						if var20 then
							var20:Disconnect()
							var20 = nil
						end

						var9.CancelFailureAnimation()
					end
				end
			end
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2DownTime = tick()
			arg1.mouse2DownPos = arg1.Position
		end
	end)

	arg1.inputChangedConn = var2.InputChanged:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchChanged(arg1, arg2)
		end
	end)

	arg1.inputEndedConn = var2.InputEnded:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchEnded(arg1, arg2)
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2UpTime = tick()
			local var2 = var18
			local var3 = arg1.Position
			if not var2 then
				var2 = arg1.keyboardMoveVector.Magnitude <= 0
			end

			if arg1.mouse2UpTime - arg1.mouse2DownTime < 0.25 and ((var3 - arg1.mouse2DownPos).magnitude < 5 and var2) then
				OnTap({ var3 })
			end
		end
	end)

	arg1.tapConn = var2.TouchTap:Connect(function(arg1, arg2)
		if not arg2 then
			OnTap(arg1, nil, true)
		end
	end)

	arg1.menuOpenedConnection = var8.MenuOpened:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end)

	local function OnCharacterChildAdded(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = true
		end

		if arg1:IsA("Humanoid") then
			local var4 = arg1.humanoidDiedConn
			if var4 then
				var4:Disconnect()
			end

			arg1.humanoidDiedConn = arg1.Died:Connect(function()
			end)

		end
	end

	arg1.characterChildAddedConn = arg2.ChildAdded:Connect(function(arg1)
		OnCharacterChildAdded(arg1)
	end)

	arg1.characterChildRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = false
		end
	end)

	for k1, v1 in pairs(arg2:GetChildren()) do
		OnCharacterChildAdded(v1)
	end

	arg1.preferredInputChangedConnection = var2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		arg1:OnPreferredInputChanged()
	end)
end

var22.Start = function(arg1)
	arg1:Enable(true)
end

var22.Stop = function(arg1)
	arg1:Enable(false)
end

var22.CleanupPath = function(_)
	if var18 then
		var18:Cancel()
		var18 = nil
	end

	if var19 then
		var19:Disconnect()
		var19 = nil
	end

	if var20 then
		var20:Disconnect()
		var20 = nil
	end
end

var22.Enable = function(arg1, arg2, arg3, arg4)
	if arg2 then
		if not arg1.running then
			if var13.Character then
				arg1:OnCharacterAdded(var13.Character)
			end

			arg1.onCharacterAddedConn = var13.CharacterAdded:Connect(function(arg1)
				arg1:OnCharacterAdded(arg1)
			end)

			arg1.running = true
		end

		arg1.touchJumpController = arg4
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(arg1.jumpEnabled)
		end
	else
		if arg1.running then
			arg1:DisconnectEvents()
			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var3 = var13.Character
			if var2.PreferredInput == Enum.PreferredInput.Touch and var3 then
				for k1, v1 in pairs(var3:GetChildren()) do
					if not v1:IsA("Tool") then
						continue
					end

					v1.ManualActivationOnly = false
				end
			end

			arg1.running = false
		end

		if arg1.touchJumpController and (not arg1.jumpEnabled) then
			arg1.touchJumpController:Enable(true)
		end

		arg1.touchJumpController = nil
	end

	var21.Enable(arg1, arg2)
	arg1.wasdEnabled = arg2 and arg3
	arg1.enabled = arg2
end

var22.OnRenderStepped = function(arg1, arg2)
	arg1.isJumping = false
	if var18 then
		var18:OnRenderStepped(arg2)
		if var18 then
			arg1.moveVector = var18.NextActionMoveDirection
			arg1.moveVectorIsCameraRelative = false
			if var18.NextActionJump then
				arg1.isJumping = true
			end
		else
			arg1.moveVector = arg1.keyboardMoveVector
			arg1.moveVectorIsCameraRelative = true
		end
	else
		arg1.moveVector = arg1.keyboardMoveVector
		arg1.moveVectorIsCameraRelative = true
	end

	if arg1.jumpRequested then
		arg1.isJumping = true
	end
end

var22.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.keyboardMoveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg1.wasdEnabled then
		arg1.keyboardMoveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
	end
end

var22.UpdateJump = function(_)
end

var22.SetShowPath = function(_, arg2)
	bool1 = arg2
end

var22.GetShowPath = function(_)
	return bool1
end

var22.SetWaypointTexture = function(_, arg2)
	var9.SetWaypointTexture(arg2)
end

var22.GetWaypointTexture = function(_)
	return var9.GetWaypointTexture()
end

var22.SetWaypointRadius = function(_, arg2)
	var9.SetWaypointRadius(arg2)
end

var22.GetWaypointRadius = function(_)
	return var9.GetWaypointRadius()
end

var22.SetEndWaypointTexture = function(_, arg2)
	var9.SetEndWaypointTexture(arg2)
end

var22.GetEndWaypointTexture = function(_)
	return var9.GetEndWaypointTexture()
end

var22.SetWaypointsAlwaysOnTop = function(_, arg2)
	var9.SetWaypointsAlwaysOnTop(arg2)
end

var22.GetWaypointsAlwaysOnTop = function(_)
	return var9.GetWaypointsAlwaysOnTop()
end

var22.SetFailureAnimationEnabled = function(_, arg2)
	str1 = arg2
end

var22.GetFailureAnimationEnabled = function(_)
	return str1
end

local function UpdateIgnoreTag(arg1)
	if arg1 == var14 then
		return
	end

	if var15 then
		var15:Disconnect()
		var15 = nil
	end

	if var16 then
		var16:Disconnect()
		var16 = nil
	end

	var14 = arg1
	local var1 = var13
	var17 = { var1 and var13.Character }
	if var14 ~= nil then
		for k1, v1 in ipairs((var7:GetTagged(var14))) do
			table.insert(var17, v1)
		end

		var15 = var7:GetInstanceAddedSignal(var14):Connect(function(arg1)
			table.insert(var17, arg1)
		end)

		var16 = var7:GetInstanceRemovedSignal(var14):Connect(function(arg1)
			for i1 = 1, #var17 do
				if var17[i1] ~= arg1 then
					continue
				end

				var17[i1] = var17[#var17]
				table.remove(var17)
				return
			end
		end)

	end
end

var22.SetIgnoredPartsTag = function(_, arg2)
	UpdateIgnoreTag(arg2)
end

var22.GetIgnoredPartsTag = function(_)
	return var14
end

var22.SetUseDirectPath = function(_, arg2)
	bool2 = arg2
end

var22.GetUseDirectPath = function(_)
	return bool2
end

var22.SetAgentSizeIncreaseFactor = function(_, arg2)
	num1 = arg2 / 100 + 1
end

var22.GetAgentSizeIncreaseFactor = function(_)
	return (num1 - 1) * 100
end

var22.SetUnreachableWaypointTimeout = function(_, arg2)
	num2 = arg2
end

var22.GetUnreachableWaypointTimeout = function(_)
	return num2
end

var22.SetUserJumpEnabled = function(arg1, arg2)
	arg1.jumpEnabled = arg2
	if arg1.touchJumpController then
		arg1.touchJumpController:Enable(arg2)
	end
end

var22.GetUserJumpEnabled = function(arg1)
	return arg1.jumpEnabled
end

var22.MoveTo = function(_, arg2, arg3, arg4)
	local var2 = var13.Character
	if var2 == nil then
		return false
	end

	local var4 = Pather(arg2, Vector3.new(0, 1, 0), arg4)
	if var4 and var4:IsValidPath() then
		HandleMoveTo(var4, arg2, nil, var2, arg3)
		return true
	end

	return false
end

return var22

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.PathDisplay [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = RaycastParams.new()
var2.FilterType = Enum.RaycastFilterType.Exclude
str1 = {
	spacing = 8,
	image = "rbxasset://textures/Cursors/Gamepad/Pointer.png",
	imageSize = Vector2.new(2, 2),
}

local var3 = Instance.new("Model")
var3.Name = "PathDisplayPoints"
local var4 = Instance.new("Part")
var4.Anchored = true
var4.CanCollide = false
var4.Transparency = 1
var4.Name = "PathDisplayAdornee"
var4.CFrame = CFrame.new(0, 0, 0)
var4.Parent = var3
local num1 = 30
local tbl1 = {}
local tbl2 = {}
local tbl3 = {}
for i1 = 1, num1 do
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Archivable = false
	var5.Adornee = var4
	var5.Image = str1.image
	var5.Size = str1.imageSize
	tbl3[i1] = var5
end

str1.setCurrentPoints = function(arg1)
	if typeof(arg1) == "table" then
		tbl1 = arg1
		return
	end

	tbl1 = {}
end

str1.clearRenderedPath = function()
	for k1, v1 in ipairs(tbl2) do
		v1.Parent = nil
		local var1 = num1 + 1
		num1 = var1
		tbl3[num1] = v1
	end

	tbl2 = {}
	var3.Parent = nil
end

local function renderPoint(arg1, _)
	if num1 == 0 then
		return nil
	end

	local var5 = tbl3[1]
	local var6
	if not var5 then
		var6 = nil
	else
		tbl3[1] = tbl3[num1]
		tbl3[num1] = nil
		local var7 = num1 - 1
		num1 = var7
		var6 = var5
	end

	if var1 then
		var2.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
		var5 = workspace:Raycast(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), var2)
		if not var5 then
			return nil
		end

		var6.CFrame = CFrame.lookAlong(var5.Position, var5.Normal)
		var6.Parent = var3
		return var6
	end

	local var8, var9, var10 = workspace:FindPartOnRayWithIgnoreList(Ray.new(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0)), { game.Players.LocalPlayer.Character, workspace.CurrentCamera })
	if not var8 then
		return nil
	end

	var6.CFrame = CFrame.new(var9, var9 + var10)
	var6.Parent = var3
	return var6
end

str1.renderPath = function()
	str1.clearRenderedPath()
	if not tbl1 or #tbl1 == 0 then
		return
	end

	local var1 = #tbl1
	tbl2[1] = renderPoint(tbl1[var1], true)
	local num1 = 0
	if not tbl2[1] then
		return
	end

	while true do
		local var2 = tbl1[var1]
		local var4 = tbl1[var1 - 1]
		if var1 < 2 then
			break
		end

		local var5 = var4 - var2
		local var7 = var5.magnitude
		if var7 < num1 then
			num1 = num1 - var7
		else
			local var9 = renderPoint(var2 + var5.unit * num1, false)
			if var9 then
				tbl2[#tbl2 + 1] = var9
			end
		end

		var1 = var1 - 1
		num1 = num1 + str1.spacing
	end

	var3.Parent = workspace.CurrentCamera
end

return str1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchJump [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "CharacterUtil"
local str3 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
str1 = require(var1:WaitForChild(str3)).getUserFlag("UserAllowAbilityControls")
local str4 = "AvatarAbilitiesInterface"
str2 = nil
str2 = str1 and require(script.Parent:WaitForChild(str4))
local str5 = "BaseCharacterController"
local var4 = require(script.Parent:WaitForChild(str5))
local var5 = game:GetService("GuiService")
str4 = setmetatable({}, var4)
str4.__index = str4
str4.new = function()
	local var1 = setmetatable(var4.new(), str4)
	var1.parentUIFrame = nil
	var1.jumpButton = nil
	var1.externallyEnabled = false
	var1.isJumping = false
	var1._active = false
	var1._connectionUtil = var2.new()
	return var1
end

str3 = {
	"rbxasset://textures/ui/Input/JumpButtonRegular.png",
	"rbxasset://textures/ui/Input/JumpButtonPressed.png",
}

str4._reset = function(arg1)
	arg1.isJumping = false
	arg1.touchObject = nil
	if arg1.jumpButton then
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[1]
			return
		end

		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end

str4.EnableButton = function(arg1, arg2)
	if arg2 == arg1._active then
		return
	end

	if arg2 then
		if not arg1.jumpButton then
			arg1:Create()
		end

		arg1.jumpButton.Visible = true
		local function fn2(arg1)
			if arg1 == arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("JUMP_INPUT_ENDED", arg1.jumpButton.InputEnded:Connect(fn2))
		fn2 = function()
			if arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("MENU_OPENED", var5.MenuOpened:Connect(fn2))
	else
		if arg1.jumpButton then
			arg1.jumpButton.Visible = false
		end

		arg1._connectionUtil:disconnect("JUMP_INPUT_ENDED")
		arg1._connectionUtil:disconnect("MENU_OPENED")
	end

	arg1:_reset()
	arg1._active = arg2
end

str4.UpdateEnabled = function(arg1)
	local var2 = var3.getChild("Humanoid", "Humanoid")
	if var2 and (arg1.externallyEnabled and (var2.UseJumpPower and 0 < var2.JumpPower or not var2.UseJumpPower and (0 < var2.JumpHeight and var2:GetStateEnabled(Enum.HumanoidStateType.Jumping)))) then
		arg1:EnableButton(true)
		return
	end

	arg1:EnableButton(false)
end

str4._setupConfigurations = function(arg1)
	local function update()
		arg1:UpdateEnabled()
	end

	arg1._connectionUtil:trackConnection("HUMANOID", (var3.onChild("Humanoid", "Humanoid", function(arg1)
		arg1:UpdateEnabled()
		arg1:_reset()
		local var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", arg1:GetPropertyChangedSignal("JumpPower"):Connect(var1))
		var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", arg1:GetPropertyChangedSignal("JumpHeight"):Connect(var1))
		var1 = function(arg1, arg2)
			if arg1 == Enum.HumanoidStateType.Jumping and arg2 ~= arg1._active then
				arg1:UpdateEnabled()
			end
		end

		arg1._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", arg1.StateEnabledChanged:Connect(var1))
	end)))
end

str4.Enable = function(arg1, arg2, arg3)
	if arg3 then
		arg1.parentUIFrame = arg3
	end

	if arg1.externallyEnabled == arg2 then
		return
	end

	arg1.externallyEnabled = arg2
	arg1:UpdateEnabled()
	if arg2 then
		arg1:_setupConfigurations()
		return
	end

	arg1._connectionUtil:disconnectAll()
end

str4.Create = function(arg1)
	if not arg1.parentUIFrame then
		return
	end

	if arg1.jumpButton then
		arg1.jumpButton:Destroy()
		arg1.jumpButton = nil
	end

	if arg1.absoluteSizeChangedConn then
		arg1.absoluteSizeChangedConn:Disconnect()
		arg1.absoluteSizeChangedConn = nil
	end

	if str1 and arg1.avatarAbilitiesEnabledChangedConn then
		arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
		arg1.avatarAbilitiesEnabledChangedConn = nil
	end

	arg1.jumpButton = Instance.new("ImageButton")
	arg1.jumpButton.Name = "JumpButton"
	arg1.jumpButton.Visible = false
	arg1.jumpButton.BackgroundTransparency = 1
	if str1 and str2.isEnabled() then
		arg1.jumpButton.Image = str3[1]
	else
		arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
		arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
	end

	local function ResizeJumpButton()
		local var2 = math.min(arg1.parentUIFrame.AbsoluteSize.x, arg1.parentUIFrame.AbsoluteSize.y) <= 500
		if str1 then
			if str2.isEnabled() then
				local var3 = if var2 then 72 else 120
				local var4 = if var2 then 64 else 100
				arg1.jumpButton.Image = str3[1]
				arg1.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				arg1.jumpButton.ImageRectSize = Vector2.new(0, 0)
				arg1.jumpButton.Size = UDim2.new(0, var3, 0, var3)
				arg1.jumpButton.Position = UDim2.new(1, -var3 - var4, 1, -var3 - (if var2 then 64 else 112))
				return
			end
		end

		local var5 = if var2 then 70 else 120
		if str1 then
			arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
		end

		arg1.jumpButton.Size = UDim2.new(0, var5, 0, var5)
		local var6 = var2 and UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 - 20) or UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 * 1.75)
		arg1.jumpButton.Position = var6
	end

	ResizeJumpButton()
	arg1.absoluteSizeChangedConn = arg1.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeJumpButton)
	if str1 then
		arg1.avatarAbilitiesEnabledChangedConn = str2.GetEnabledChangedSignal():Connect(ResizeJumpButton)
	end

	arg1.touchObject = nil
	arg1.jumpButton.InputBegan:connect(function(arg1)
		if arg1.touchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.touchObject = arg1
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[2]
		else
			arg1.jumpButton.ImageRectOffset = Vector2.new(146, 146)
		end

		arg1.isJumping = true
	end)

	arg1.jumpButton.Parent = arg1.parentUIFrame
end

return str4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick [ModuleScript]
-- y u r i

game:GetService("Players")
UserSettings():GetService("UserGameSettings")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
local var2 = nil
var2 = var1 and require(script.Parent:WaitForChild(str2))
str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var3 = game:GetService("GuiService")
local var4 = game:GetService("UserInputService")
local var5 = setmetatable({}, str1)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str1.new(), var5)
	var1.isFollowStick = false
	var1.thumbstickFrame = nil
	var1.moveTouchObject = nil
	var1.onTouchMovedConn = nil
	var1.onTouchEndedConn = nil
	var1.screenPos = nil
	var1.stickImage = nil
	var1.thumbstickSize = nil
	return var1
end

var5.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1.thumbstickFrame.Visible = true
	else
		arg1.thumbstickFrame.Visible = false
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
end

var5.OnInputEnded = function(arg1)
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickFrame.Size.X.Offset / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickFrame.Size.Y.Offset / 2 - arg1.thumbstickSize / 4)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.moveTouchObject = nil
end

var5.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onTouchMovedConn then
			arg1.onTouchMovedConn:Disconnect()
			arg1.onTouchMovedConn = nil
		end

		if arg1.onTouchEndedConn then
			arg1.onTouchEndedConn:Disconnect()
			arg1.onTouchEndedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var1 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.Name = "ThumbstickFrame"
	arg1.thumbstickFrame.Active = true
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	local var5 = Instance.new("ImageLabel")
	var5.Name = "OuterImage"
	var5.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	var5.ImageRectOffset = Vector2.new()
	var5.ImageRectSize = Vector2.new(220, 220)
	var5.BackgroundTransparency = 1
	var5.Position = UDim2.new(0, 0, 0, 0)
	arg1.stickImage = Instance.new("ImageLabel")
	arg1.stickImage.Name = "StickImage"
	arg1.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	arg1.stickImage.ImageRectOffset = Vector2.new(220, 0)
	arg1.stickImage.ImageRectSize = Vector2.new(111, 111)
	arg1.stickImage.BackgroundTransparency = 1
	arg1.stickImage.ZIndex = 2
	local function ResizeThumbstick()
		local var4 = math.min(arg2.AbsoluteSize.X, arg2.AbsoluteSize.Y) <= 500
		if var1 then
			if var2.isEnabled() then
				local var6 = if var4 then 64 else 100
				local var7 = if var4 then 64 else 112
				local var8 = arg1
				var8.thumbstickSize = if var4 then 72 else 120
				arg1.screenPos = UDim2.new(0, var6, 1, -arg1.thumbstickSize - var7)
			else
				local var9 = arg1
				var9.thumbstickSize = if var4 then 70 else 120
				local var10 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
				arg1.screenPos = var10
			end
		else
			local var11 = arg1
			var11.thumbstickSize = if var4 then 70 else 120
			local var12 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
			arg1.screenPos = var12
		end

		arg1.thumbstickFrame.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.thumbstickFrame.Position = arg1.screenPos
		var5.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.stickImage.Size = UDim2.new(0, arg1.thumbstickSize / 2, 0, arg1.thumbstickSize / 2)
		arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var1 then
		arg1.avatarAbilitiesEnabledChangedConn = var2.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	var5.Parent = arg1.thumbstickFrame
	arg1.stickImage.Parent = arg1.thumbstickFrame
	local var6 = nil
	arg1.thumbstickFrame.InputBegan:Connect(function(arg1)
		if arg1.moveTouchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.moveTouchObject = arg1
		arg1.thumbstickFrame.Position = UDim2.new(0, arg1.Position.X - arg1.thumbstickFrame.Size.X.Offset / 2, 0, arg1.Position.Y - arg1.thumbstickFrame.Size.Y.Offset / 2)
		var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
		Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y)
	end)

	local function MoveStick(arg1)
		local var1 = Vector2.new(arg1.X - var6.X, arg1.Y - var6.Y)
		local var5 = arg1.thumbstickFrame.AbsoluteSize.X / 2
		local var7 = var1.magnitude
		if arg1.isFollowStick and var5 < var7 then
			local var8 = var1.unit * var5
			arg1.thumbstickFrame.Position = UDim2.new(0, arg1.X - arg1.thumbstickFrame.AbsoluteSize.X / 2 - var8.X, 0, arg1.Y - arg1.thumbstickFrame.AbsoluteSize.Y / 2 - var8.Y)
		else
			var1 = var1.unit * math.min(var7, var5)
		end

		arg1.stickImage.Position = UDim2.new(0, var1.X + arg1.stickImage.AbsoluteSize.X / 2, 0, var1.Y + arg1.stickImage.AbsoluteSize.Y / 2)
	end

	arg1.onTouchMovedConn = var4.TouchMoved:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
			local var1 = Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y) / (arg1.thumbstickSize / 2)
			local var3 = var1.magnitude
			if var3 < 0.05 then
				var1 = Vector3.new()
			else
				var1 = var1.unit * math.min(1, (var3 - 0.05) / 0.95)
				var1 = Vector3.new(var1.X, 0, var1.Y)
			end

			arg1.moveVector = var1
			MoveStick(arg1.Position)
		end
	end)

	arg1.onTouchEndedConn = var4.TouchEnded:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var3.MenuOpened:Connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Keyboard [ModuleScript]
-- y u r i

script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "BaseCharacterController"
local var1 = require(script.Parent:WaitForChild(str1))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = Vector3.new()
local var5 = setmetatable({}, var1)
var5.__index = var5
var5.new = function(arg1)
	local var2 = setmetatable(var1.new(), var5)
	var2.CONTROL_ACTION_PRIORITY = arg1
	var2.forwardValue = 0
	var2.backwardValue = 0
	var2.leftValue = 0
	var2.rightValue = 0
	var2.jumpEnabled = true
	return var2
end

var5.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.moveVector = var4
	arg1.jumpRequested = false
	arg1:UpdateJump()
	if arg2 then
		arg1:BindContextActions()
		arg1:ConnectFocusEventListeners()
	else
		arg1._connectionUtil:disconnectAll()
	end

	arg1.enabled = arg2
	return true
end

var5.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.moveVector = var4
		return
	end

	arg1.moveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
end

var5.UpdateJump = function(arg1)
	arg1.isJumping = arg1.jumpRequested
end

var5.BindContextActions = function(arg1)
	var3:BindActionAtPriority("moveForwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.forwardValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterForward)

	var3:BindActionAtPriority("moveBackwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.backwardValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterBackward)

	var3:BindActionAtPriority("moveLeftAction", function(_, arg2, _)
		local var1 = arg1
		var1.leftValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterLeft)

	var3:BindActionAtPriority("moveRightAction", function(_, arg2, _)
		local var1 = arg1
		var1.rightValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterRight)

	var3:BindActionAtPriority("jumpAction", function(_, arg2, _)
		local var2 = arg1.jumpEnabled
		local var3 = arg1
		if var2 then
			var2 = arg2 == Enum.UserInputState.Begin
		end

		var3.jumpRequested = var2
		arg1:UpdateJump()
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterJump)

	arg1._connectionUtil:trackBoundFunction("moveForwardAction", function()
		var3:UnbindAction("moveForwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveBackwardAction", function()
		var3:UnbindAction("moveBackwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveLeftAction", function()
		var3:UnbindAction("moveLeftAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveRightAction", function()
		var3:UnbindAction("moveRightAction")
	end)

	arg1._connectionUtil:trackBoundFunction("jumpAction", function()
		var3:UnbindAction("jumpAction")
	end)
end

var5.ConnectFocusEventListeners = function(arg1)
	local function onFocusReleased()
		arg1.moveVector = var4
		arg1.forwardValue = 0
		arg1.backwardValue = 0
		arg1.leftValue = 0
		arg1.rightValue = 0
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	local var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("textBoxFocusReleased", var2.TextBoxFocusReleased:Connect(var1))
	var1 = function(_)
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	arg1._connectionUtil:trackConnection("textBoxFocused", var2.TextBoxFocused:Connect(var1))
	var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("windowFocusReleased", var2.WindowFocused:Connect(var1))
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay [ModuleScript]
-- y u r i

local var1 = UDim2.new(0, 42, 0, 50)
local var2 = Vector2.new(0, 0.5)
local var3 = Vector2.new(0, 1)
local var4 = Vector2.new(0, 0.5)
local var5 = Vector2.new(0.1, 0.5)
local var6 = Vector2.new(-0.1, 0.5)
local var7 = Vector2.new(1.5, 1.5)
local var8 = RaycastParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local str1 = "FlagUtil"
local bool1 = false
local str2 = "rbxasset://textures/ui/traildot.png"
local str3 = "rbxasset://textures/ui/waypoint.png"
local var9 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
str1 = function()
	local var3 = Instance.new("Part")
	var3.Size = Vector3.new(1, 1, 1)
	var3.Anchored = true
	var3.CanCollide = false
	var3.Name = "TrailDot"
	var3.Transparency = 1
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Name = "TrailDotImage"
	var5.Size = var7
	var5.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var5.AlwaysOnTop = bool1
	var5.Image = str2
	var5.Adornee = var3
	var5.Parent = var3
	local var6 = Instance.new("Part")
	var6.Size = Vector3.new(2, 2, 2)
	var6.Anchored = true
	var6.CanCollide = false
	var6.Name = "EndWaypoint"
	var6.Transparency = 1
	local var8 = Instance.new("ImageHandleAdornment")
	var8.Name = "TrailDotImage"
	var8.Size = var7
	var8.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var8.AlwaysOnTop = bool1
	var8.Image = str2
	var8.Adornee = var6
	var8.Parent = var6
	local var9 = Instance.new("BillboardGui")
	var9.Name = "EndWaypointBillboard"
	var9.Size = var1
	var9.LightInfluence = 0
	var9.SizeOffset = var2
	var9.AlwaysOnTop = true
	var9.Adornee = var6
	var9.Parent = var6
	local var10 = Instance.new("ImageLabel")
	var10.Image = str3
	var10.BackgroundTransparency = 1
	var10.Size = UDim2.new(1, 0, 1, 0)
	var10.Parent = var9
	local var11 = Instance.new("Part")
	var11.Size = Vector3.new(2, 2, 2)
	var11.Anchored = true
	var11.CanCollide = false
	var11.Name = "FailureWaypoint"
	var11.Transparency = 1
	local var12 = Instance.new("ImageHandleAdornment")
	var12.Name = "TrailDotImage"
	var12.Size = var7
	var12.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var12.AlwaysOnTop = bool1
	var12.Image = str2
	var12.Adornee = var11
	var12.Parent = var11
	local var13 = Instance.new("BillboardGui")
	var13.Name = "FailureWaypointBillboard"
	var13.Size = var1
	var13.LightInfluence = 0
	var13.SizeOffset = var4
	var13.AlwaysOnTop = true
	var13.Adornee = var11
	var13.Parent = var11
	local var14 = Instance.new("Frame")
	var14.BackgroundTransparency = 1
	var14.Size = UDim2.new(0, 0, 0, 0)
	var14.Position = UDim2.new(0.5, 0, 1, 0)
	var14.Parent = var13
	local var15 = Instance.new("ImageLabel")
	var15.Image = str3
	var15.BackgroundTransparency = 1
	var15.Position = UDim2.new(0, -var1.X.Offset / 2, 0, -var1.Y.Offset)
	var15.Size = var1
	var15.Parent = var14
	return var3, var6, var11
end

local var10 = game:GetService("Workspace")
local var11 = game:GetService("Players").LocalPlayer
local var12 = game:GetService("TweenService")
local var13 = game:GetService("RunService")
local var14, var15, var16 = str1()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

local function placePathWaypoint(arg1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var2 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if not var2 then
			return
		end

		arg1.CFrame = CFrame.lookAlong(var2.Position, var2.Normal)
		local var3 = var10.CurrentCamera
		local var5 = var3:FindFirstChild("ClickToMoveDisplay")
		if not var5 then
			var5 = Instance.new("Model")
			var5.Name = "ClickToMoveDisplay"
			var5.Parent = var3
		end

		arg1.Parent = var5
		return
	end

	local var12, var13, var14 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var12 then
		arg1.CFrame = CFrame.new(var13, var13 + var14)
		local var15 = var10.CurrentCamera
		local var17 = var15:FindFirstChild("ClickToMoveDisplay")
		if not var17 then
			var17 = Instance.new("Model")
			var17.Name = "ClickToMoveDisplay"
			var17.Parent = var15
		end

		arg1.Parent = var17
	end
end

tbl1.NewDisplayModel = function(_, arg2)
	local var1 = var14:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.ClosestWayPoint = arg2
	return var1
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.Destroy = function(arg1)
	arg1.Destroyed = true
	arg1.Tween:Cancel()
	arg1.DisplayModel:Destroy()
end

tbl2.NewDisplayModel = function(_, arg2)
	local var1 = var15:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl2.CreateTween = function(arg1)
	local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, -1, true)
	local var2 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, var1, { SizeOffset = var3 })
	var2:Play()
	return var2
end

tbl2.TweenInFrom = function(arg1, arg2)
	arg1.DisplayModel.EndWaypointBillboard.StudsOffset = Vector3.new(0, (arg2 - arg1.DisplayModel.Position).Y, 0)
	local var1 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), { StudsOffset = Vector3.new(0, 0, 0) })
	var1:Play()
	return var1
end

tbl2.new = function(arg1, arg2, arg3)
	local var1 = setmetatable({}, tbl2)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.Destroyed = false
	if arg3 and 5 < (arg3 - arg1).Magnitude then
		var2 = var1:TweenInFrom(arg3)
		var1.Tween = var2
		coroutine.wrap(function()
			var1.Tween.Completed:Wait()
			if not var1.Destroyed then
				var1.Tween = var1:CreateTween()
			end
		end)()

	else
		var2 = var1:CreateTween()
		var1.Tween = var2
	end

	var1.ClosestWayPoint = arg2
	return var1
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.Hide = function(arg1)
	arg1.DisplayModel.Parent = nil
end

tbl3.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

tbl3.NewDisplayModel = function(_, arg2)
	local var1 = var16:Clone()
	placePathWaypoint(var1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var3 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if var3 then
			var1.CFrame = CFrame.lookAlong(var3.Position, var3.Normal)
			local var4 = var10.CurrentCamera
			local var6 = var4:FindFirstChild("ClickToMoveDisplay")
			if not var6 then
				var6 = Instance.new("Model")
				var6.Name = "ClickToMoveDisplay"
				var6.Parent = var4
			end

			var1.Parent = var6
			return var1
		end
	end

	local var13, var14, var15 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var13 then
		var1.CFrame = CFrame.new(var14, var14 + var15)
		local var17 = var10.CurrentCamera
		local var19 = var17:FindFirstChild("ClickToMoveDisplay")
		if not var19 then
			var19 = Instance.new("Model")
			var19.Name = "ClickToMoveDisplay"
			var19.Parent = var17
		end

		var1.Parent = var19
	end

	return var1
end

tbl3.RunFailureTween = function(arg1)
	wait(0.125)
	local var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local var2 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var5 })
	var2:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 10 }):Play()
	var2.Completed:wait()
	local var3 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	local var7 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var3, { SizeOffset = var6 })
	var7:Play()
	var1 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame.ImageLabel, var1, { ImageColor3 = Color3.new(0.75, 0.75, 0.75) }):Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = -10 }):Play()
	var7.Completed:wait()
	var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	var3 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var4 })
	var3:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 0 }):Play()
	var3.Completed:wait()
	wait(0.125)
end

tbl3.new = function(arg1)
	local var1 = setmetatable({}, tbl3)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	return var1
end

local var17 = Instance.new("Animation")
var17.AnimationId = "rbxassetid://2874840706"
local var18 = nil
local num1 = 0
local function createTrailDots(arg1, arg2)
	local tbl3 = {}
	local num1 = 1
	for i1 = 1, #arg1 - 1 do
		local var1 = (arg1[i1].Position - arg1[#arg1].Position).Magnitude < 3
		local bool2 = false
		if i1 % 2 == 0 then
			bool2 = not var1
		end

		if not bool2 then
			continue
		end

		tbl3[num1] = tbl1.new(arg1[i1].Position, i1)
		num1 = num1 + 1
	end

	table.insert(tbl3, (tbl2.new(arg1[#arg1].Position, #arg1, arg2)))
	num1 = 1
	local tbl4 = {}
	for i2 = #tbl3, 1, -1 do
		tbl4[num1] = tbl3[i2]
		num1 = num1 + 1
	end

	return tbl4
end

local var19 = nil
return {
	CreatePathDisplay = function(arg1, arg2)
		local var1 = num1 + 1
		num1 = var1
		var1 = createTrailDots(arg1, arg2)
		local var2 = "ClickToMoveResizeTrail" .. num1
		var13:BindToRenderStep(var2, Enum.RenderPriority.Camera.Value - 1, function()
			if #var1 == 0 then
				var13:UnbindFromRenderStep(var2)
				return
			end

			local var3 = var10.CurrentCamera.CFrame.p
			for i1 = 1, #var1 do
				local var4 = var1[i1].DisplayModel:FindFirstChild("TrailDotImage")
				if not var4 then
					continue
				end

				var4.Size = var7 * (math.clamp((var1[i1].DisplayModel.Position - var3).Magnitude - 10, 0, 90) / 90 * 1.5 + 1)
			end
		end)

		local function removePathBeforePoint(arg1)
			for i1 = #var1, 1, -1 do
				local var2 = var1[i1]
				if var2.ClosestWayPoint > arg1 then
					break
				end

				var2:Destroy()
				var1[i1] = nil
				continue
			end
		end

		return function()
			removePathBeforePoint(#arg1)
		end, removePathBeforePoint
	end,
	DisplayFailureWaypoint = function(arg1)
		if var19 then
			var19:Hide()
		end

		local var1 = tbl3.new(arg1)
		var19 = var1
		coroutine.wrap(function()
			var1:RunFailureTween()
			var1:Destroy()
			var1 = nil
		end)()
	end,
	CreateEndWaypoint = function(arg1)
		local var1 = arg1
		return tbl2.new(var1)
	end,
	PlayFailureAnimation = function()
		local var2 = var11.Character
		local var4 = if var2 then var2:FindFirstChildOfClass("Humanoid") else nil
		if var4 then
			if var4 == nil then
				var2 = var18
			else
				var18 = var4:LoadAnimation(var17)
				assert(var18, "")
				var18.Priority = Enum.AnimationPriority.Action
				var18.Looped = false
				var2 = var18
			end

			var2:Play()
		end
	end,
	CancelFailureAnimation = function()
		if var18 ~= nil and var18.IsPlaying then
			var18:Stop()
		end
	end,
	SetWaypointTexture = function(arg1)
		str2 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointTexture = function()
		return str2
	end,
	SetWaypointRadius = function(arg1)
		var7 = Vector2.new(arg1, arg1)
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointRadius = function()
		return var7.X
	end,
	SetEndWaypointTexture = function(arg1)
		str3 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetEndWaypointTexture = function()
		return str3
	end,
	SetWaypointsAlwaysOnTop = function(arg1)
		bool1 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointsAlwaysOnTop = function()
		return bool1
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VehicleController [ModuleScript]
-- y u r i

local var1 = game:GetService("ContextActionService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var1 = setmetatable({}, tbl1)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.enabled = false
	var1.vehicleSeat = nil
	var1.throttle = 0
	var1.steer = 0
	var1.acceleration = 0
	var1.decceleration = 0
	var1.turningRight = 0
	var1.turningLeft = 0
	var1.vehicleMoveVector = Vector3.new(0, 0, 0)
	var1.autoPilot = {}
	var1.autoPilot.MaxSpeed = 0
	var1.autoPilot.MaxSteeringAngle = 0
	return var1
end

tbl1.BindContextActions = function(arg1)
	var1:BindActionAtPriority("throttleAccel", function(arg1, arg2, arg3)
		arg1:OnThrottleAccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonR2)

	var1:BindActionAtPriority("throttleDeccel", function(arg1, arg2, arg3)
		arg1:OnThrottleDeccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonL2)

	var1:BindActionAtPriority("arrowSteerRight", function(arg1, arg2, arg3)
		arg1:OnSteerRight(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Right)

	var1:BindActionAtPriority("arrowSteerLeft", function(arg1, arg2, arg3)
		arg1:OnSteerLeft(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Left)
end

tbl1.Enable = function(arg1, arg2, arg3)
	if arg2 == arg1.enabled and arg3 == arg1.vehicleSeat then
		return
	end

	arg1.enabled = arg2
	arg1.vehicleMoveVector = Vector3.new(0, 0, 0)
	if arg2 then
		if not arg3 then
			return
		end

		arg1.vehicleSeat = arg3
		arg1:SetupAutoPilot()
		arg1:BindContextActions()
		return
	end

	var1:UnbindAction("throttleAccel")
	var1:UnbindAction("throttleDeccel")
	var1:UnbindAction("arrowSteerRight")
	var1:UnbindAction("arrowSteerLeft")
	arg1.vehicleSeat = nil
end

tbl1.OnThrottleAccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.acceleration = 0
	else
		arg1.acceleration = -1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnThrottleDeccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.decceleration = 0
	else
		arg1.decceleration = 1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnSteerRight = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningRight = 0
	else
		arg1.turningRight = 1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.OnSteerLeft = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningLeft = 0
	else
		arg1.turningLeft = -1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.Update = function(arg1, arg2, arg3, arg4)
	if arg1.vehicleSeat then
		if arg3 then
			arg2 = arg2 + Vector3.new(arg1.steer, 0, arg1.throttle)
	if not arg4 then
				arg1.vehicleSeat.ThrottleFloat = -arg2.Z
			end

			arg1.vehicleSeat.SteerFloat = arg2.X
			return arg2, true
		end

		local var1 = arg1.vehicleSeat.Occupant.RootPart.CFrame:VectorToObjectSpace(arg2)
		arg1.vehicleSeat.ThrottleFloat = arg1:ComputeThrottle(var1)
		arg1.vehicleSeat.SteerFloat = arg1:ComputeSteer(var1)
		return Vector3.new(0, 0, 0), true
	end

	return arg2, false
end

tbl1.ComputeThrottle = function(_, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -arg2.Z
	end

	return 0
end

tbl1.ComputeSteer = function(arg1, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -math.atan2(-arg2.x, -arg2.z) * 57.295779513082323 / arg1.autoPilot.MaxSteeringAngle
	end

	return 0
end

tbl1.SetupAutoPilot = function(arg1)
	arg1.autoPilot.MaxSpeed = arg1.vehicleSeat.MaxSpeed
	arg1.autoPilot.MaxSteeringAngle = 35
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Vector3.new()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var3 = setmetatable({}, tbl1)
	var3.enabled = false
	var3.moveVector = var2
	var3.moveVectorIsCameraRelative = true
	var3.isJumping = false
	var3._connectionUtil = var1.new()
	return var3
end

tbl1.GetMoveVector = function(arg1)
	return arg1.moveVector
end

tbl1.IsMoveVectorCameraRelative = function(arg1)
	return arg1.moveVectorIsCameraRelative
end

tbl1.GetIsJumping = function(arg1)
	return arg1.isJumping
end

tbl1.Enable = function(_, _)
	error("BaseCharacterController:Enable must be overridden in derived classes and should not be called.")
	return false
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Gamepad [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = setmetatable({}, str1)
var4.__index = var4
local var5 = Enum.UserInputType.None
var4.new = function(arg1)
	local var1 = setmetatable(str1.new(), var4)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.forwardValue = 0
	var1.backwardValue = 0
	var1.leftValue = 0
	var1.rightValue = 0
	var1.thumbstickVector = Vector3.new(0, 0, 0)
	var1.activeGamepad = var5
	var1.gamepadConnectedConn = nil
	var1.gamepadDisconnectedConn = nil
	return var1
end

var4.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.thumbstickVector = Vector3.new(0, 0, 0)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		local var1 = arg1:GetHighestPriorityGamepad()
		arg1.activeGamepad = var1
		if arg1.activeGamepad ~= var5 then
			arg1:BindContextActions()
			arg1:ConnectGamepadConnectionListeners()
		else
			return false
		end
	else
		arg1:UnbindContextActions()
		arg1:DisconnectGamepadConnectionListeners()
		arg1.activeGamepad = var5
	end

	arg1.enabled = arg2
	return true
end

var4.GetHighestPriorityGamepad = function(_)
	local var1 = var5
	for k1, v1 in pairs((var2:GetConnectedGamepads())) do
		if v1.Value >= var1.Value then
			continue
		end

		var1 = v1
	end

	return var1
end

var4.UpdateMovement = function(arg1)
	arg1.moveVector = arg1.thumbstickVector + Vector3.new(0, 0, arg1.forwardValue + arg1.backwardValue)
end

var4.BindContextActions = function(arg1)
	if arg1.activeGamepad == var5 then
		return false
	end

	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	local function fn4(_, arg2, _)
		arg1.isJumping = arg2 == Enum.UserInputState.Begin
		return Enum.ContextActionResult.Sink
	end

	local function fn6(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			if var1 then
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
				arg1:UpdateMovement()
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end

			return Enum.ContextActionResult.Sink
		end

		if arg1.activeGamepad ~= arg3.UserInputType then
			return Enum.ContextActionResult.Pass
		end

		if arg3.KeyCode ~= Enum.KeyCode.Thumbstick1 then
			return
		end

		if var1 then
			if 0.2 < arg3.Position.magnitude then
				arg1.thumbstickVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
			end

			arg1:UpdateMovement()
		else
			if 0.2 < arg3.Position.magnitude then
				arg1.moveVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end
		end

		return Enum.ContextActionResult.Sink
	end

	local function fn8(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			arg1.forwardValue = 0
			arg1.backwardValue = 0
			arg1:UpdateMovement()
			return Enum.ContextActionResult.Sink
		end

		local num2 = 0
		if 0.2 < arg3.Position.magnitude then
			num2 = arg3.Position.Z
		end

		if arg3.KeyCode == Enum.KeyCode.ButtonUp then
			arg1.forwardValue = -num2
		else
			if arg3.KeyCode == Enum.KeyCode.ButtonDown then
				arg1.backwardValue = num2
			end
		end

		arg1:UpdateMovement()
		return Enum.ContextActionResult.Sink
	end

	if var1 then
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonCenter)
		var3:BindActionAtPriority("moveDirectionalButton", fn8, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonUp, Enum.KeyCode.ButtonDown)
	else
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
	end

	var3:BindActionAtPriority("moveThumbstick", fn6, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
	return true
end

var4.UnbindContextActions = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	if var1 then
		var3:UnbindAction("moveDirectionalButton")
	end

	var3:UnbindAction("moveThumbstick")
	var3:UnbindAction("jumpAction")
end

var4.OnNewGamepadConnected = function(arg1)
	local var2 = arg1:GetHighestPriorityGamepad()
	if var2 == arg1.activeGamepad then
		return
	end

	if var2 == var5 then
		warn("Gamepad:OnNewGamepadConnected found no connected gamepads")
		arg1:UnbindContextActions()
		return
	end

	if arg1.activeGamepad ~= var5 then
		arg1:UnbindContextActions()
	end

	arg1.activeGamepad = var2
	arg1:BindContextActions()
end

var4.OnCurrentGamepadDisconnected = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	local var2 = arg1:GetHighestPriorityGamepad()
	if arg1.activeGamepad ~= var5 and var2 == arg1.activeGamepad then
		warn("Gamepad:OnCurrentGamepadDisconnected found the supposedly disconnected gamepad in connectedGamepads.")
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	if var2 == var5 then
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	arg1.activeGamepad = var2
	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
end

var4.ConnectGamepadConnectionListeners = function(arg1)
	arg1.gamepadConnectedConn = var2.GamepadConnected:Connect(function(_)
		arg1:OnNewGamepadConnected()
	end)

	arg1.gamepadDisconnectedConn = var2.GamepadDisconnected:Connect(function(arg1)
		if arg1.activeGamepad == arg1 then
			arg1:OnCurrentGamepadDisconnected()
		end
	end)
end

var4.DisconnectGamepadConnectionListeners = function(arg1)
	if arg1.gamepadConnectedConn then
		arg1.gamepadConnectedConn:Disconnect()
		arg1.gamepadConnectedConn = nil
	end

	if arg1.gamepadDisconnectedConn then
		arg1.gamepadDisconnectedConn:Disconnect()
		arg1.gamepadDisconnectedConn = nil
	end
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VRNavigation [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = game:GetService("VRService")
local var3 = game:GetService("UserInputService")
local var4 = game:GetService("RunService")
local var5 = game:GetService("PathfindingService")
local var6 = game:GetService("ContextActionService")
local var7 = game:GetService("StarterGui")
local var8 = game:GetService("Players").LocalPlayer
str1 = RaycastParams.new()
str1.FilterType = Enum.RaycastFilterType.Exclude
local var9 = var1.getUserFlag("UserRaycastUpdateAPI2")
local var10 = Instance.new("BindableEvent")
var10.Name = "MovementUpdate"
var10.Parent = script
local var11 = nil
coroutine.wrap(function()
	local var2 = script.Parent:WaitForChild("PathDisplay")
	if var2 then
		var11 = require(var2)
	end
end)()

local str2 = "BaseCharacterController"
local var12 = require(script.Parent:WaitForChild(str2))
local var13 = setmetatable({}, var12)
var13.__index = var13
var13.new = function(arg1)
	local var1 = setmetatable(var12.new(), var13)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.navigationRequestedConn = nil
	var1.heartbeatConn = nil
	var1.currentDestination = nil
	var1.currentPath = nil
	var1.currentPoints = nil
	var1.currentPointIdx = 0
	var1.expectedTimeToNextPoint = 0
	var1.timeReachedLastPoint = tick()
	var1.moving = false
	var1.isJumpBound = false
	var1.moveLatch = false
	var1.userCFrameEnabledConn = nil
	return var1
end

var13.SetLaserPointerMode = function(_, arg2)
	pcall(function()
		var7:SetCore("VRLaserPointerMode", arg2)
	end)
end

var13.GetLocalHumanoid = function(_)
	local var2 = var8.Character
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2:GetChildren()) do
		if not v1:IsA("Humanoid") then
			continue
		end

		return v1
	end

	return nil
end

var13.HasBothHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 and var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.HasAnyHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 or var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.IsMobileVR = function(_)
	return var3.TouchEnabled
end

var13.HasGamepad = function(_)
	return var3.GamepadEnabled
end

var13.ShouldUseNavigationLaser = function(arg1)
	if arg1:IsMobileVR() then
		return true
	end

	if arg1:HasBothHandControllers() then
		return false
	end

	if not arg1:HasAnyHandControllers() then
		return not arg1:HasGamepad()
	end

	return true
end

var13.StartFollowingPath = function(arg1, arg2)
	currentPath = arg2
	currentPoints = currentPath:GetPointCoordinates()
	currentPointIdx = 1
	moving = true
	timeReachedLastPoint = tick()
	local var2 = arg1:GetLocalHumanoid()
	if var2 and (var2.Torso and 1 <= (#currentPoints)) then
		expectedTimeToNextPoint = (currentPoints[1] - var2.Torso.Position).magnitude / var2.WalkSpeed
	end

	var10:Fire("targetPoint", arg1.currentDestination)
end

var13.GoToPoint = function(arg1, arg2)
	currentPath = true
	currentPoints = { arg2 }
	currentPointIdx = 1
	moving = true
	local var1 = arg1:GetLocalHumanoid()
	timeReachedLastPoint = tick()
	expectedTimeToNextPoint = (var1.Torso.Position - arg2).magnitude / var1.WalkSpeed
	var10:Fire("targetPoint", arg2)
end

var13.StopFollowingPath = function(arg1)
	currentPath = nil
	currentPoints = nil
	currentPointIdx = 0
	moving = false
	arg1.moveVector = Vector3.new(0, 0, 0)
end

var13.TryComputePath = function(_, arg2, arg3)
	local num1 = 0
	local var1 = nil
	while not var1 do
		if num1 >= 5 then
			break
		end

		var1 = var5:ComputeSmoothPathAsync(arg2, arg3, 200)
		if var1.Status == Enum.PathStatus.ClosestNoPath or var1.Status == Enum.PathStatus.ClosestOutOfRange then
			var1 = nil
			return var1
		end

		if var1 then
			if var1.Status == Enum.PathStatus.FailStartNotEmpty then
				var1 = nil
			end
		end

		if not var1 then
			continue
		end

		if var1.Status ~= Enum.PathStatus.FailFinishNotEmpty then
			continue
		end

		arg2 = arg2 + (arg3 - arg2).Unit
		arg3 = arg3 + Vector3.new(0, 1, 0)
		num1 = num1 + 1
		var1 = nil
	end

	return var1
end

var13.OnNavigationRequest = function(arg1, arg2, _)
	local var1 = arg2.Position
	local var3 = var1.x
	local var4 = arg1.currentDestination
	local bool2 = false
	if var3 == var3 then
		bool2 = false
		if var3 ~= math.huge then
			bool2 = var3 ~= -math.huge
		end
	end

	if bool2 then
		var3 = var1.y
		bool2 = false
		if var3 == var3 then
			bool2 = false
			if var3 ~= math.huge then
				bool2 = var3 ~= -math.huge
			end
		end

		if bool2 then
			var3 = var1.z
			bool2 = false
			if var3 == var3 then
				bool2 = false
				if var3 ~= math.huge then
					bool2 = var3 ~= -math.huge
				end
			end
		end
	end

	if not bool2 then
		return
	end

	arg1.currentDestination = var1
	bool2 = arg1:GetLocalHumanoid()
	if not bool2 or (not bool2.Torso) then
		return
	end

	var3 = bool2.Torso.Position
	if (arg1.currentDestination - var3).magnitude < 12 then
		arg1:GoToPoint(arg1.currentDestination)
		return
	end

	if var4 then
		if 4 < (arg1.currentDestination - var4).magnitude then
			local var8 = arg1:TryComputePath(var3, arg1.currentDestination)
			if var8 then
				arg1:StartFollowingPath(var8)
				if not var11 then
					return
				end

				var11.setCurrentPoints(arg1.currentPoints)
				var11.renderPath()
				return
			end

			arg1:StopFollowingPath()
			if not var11 then
				return
			end

			var11.clearRenderedPath()
			return
		end
	end

	if moving then
		arg1.currentPoints[#currentPoints] = arg1.currentDestination
		return
	end

	arg1:GoToPoint(arg1.currentDestination)
end

var13.OnJumpAction = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1.isJumping = true
	end

	return Enum.ContextActionResult.Sink
end

var13.BindJumpAction = function(arg1, arg2)
	if arg2 then
		if not not arg1.isJumpBound then
			return
		end

		arg1.isJumpBound = true
		var6:BindActionAtPriority("VRJumpAction", function()
			return arg1:OnJumpAction()
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)

		return
	end

	if arg1.isJumpBound then
		arg1.isJumpBound = false
		var6:UnbindAction("VRJumpAction")
	end
end

var13.ControlCharacterGamepad = function(arg1, _, arg3, arg4)
	if arg4.KeyCode ~= Enum.KeyCode.Thumbstick1 then
		return
	end

	if arg3 == Enum.UserInputState.Cancel then
		arg1.moveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg3 ~= Enum.UserInputState.End then
		arg1:StopFollowingPath()
		if var11 then
			var11.clearRenderedPath()
		end

		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(true)
			arg1:SetLaserPointerMode("Hidden")
		end

		if 0.22 < arg4.Position.magnitude then
			arg1.moveVector = Vector3.new(arg4.Position.X, 0, -arg4.Position.Y)
			if 0 < arg1.moveVector.magnitude then
				local var1 = arg1.moveVector.unit * math.min(1, arg4.Position.magnitude)
				arg1.moveVector = var1
			end

			arg1.moveLatch = true
		end
	else
		arg1.moveVector = Vector3.new(0, 0, 0)
		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(false)
			arg1:SetLaserPointerMode("Navigation")
		end

		if arg1.moveLatch then
			arg1.moveLatch = false
			var10:Fire("offtrack")
		end
	end

	return Enum.ContextActionResult.Sink
end

var13.OnHeartbeat = function(arg1, arg2)
	local var2 = arg1:GetLocalHumanoid()
	local var3 = arg1.moveVector
	if not var2 or (not var2.Torso) then
		return
	end

	if arg1.moving then
		if arg1.currentPoints then
			local var13 = var2.Torso.Position
			local var14 = (currentPoints[1] - var13) * Vector3.new(1, 0, 1)
			local var15 = var14.magnitude
			if var15 < 1 then
				local var16 = var14 / var15
				local num1 = 0
				local var17 = currentPoints[1]
				for k1, v1 in pairs(currentPoints) do
					if k1 == 1 then
						continue
					end

					local var18 = (v1 - var17).magnitude
					num1 = num1 + var18 / var2.WalkSpeed
					var17 = v1
				end

				table.remove(currentPoints, 1)
				local var19 = currentPointIdx + 1
				currentPointIdx = var19
				if #currentPoints == 0 then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					return
				end

				if var11 then
					var11.setCurrentPoints(currentPoints)
					var11.renderPath()
				end

				expectedTimeToNextPoint = (currentPoints[1] - var13).magnitude / var2.WalkSpeed
				timeReachedLastPoint = tick()
			else
				if var9 then
					str1.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var22 = workspace:Raycast(var13 - Vector3.new(0, 1, 0), var16 * 3, str1)
					local var23 = workspace:Raycast(var22.Position + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0), str1).Position.Y - var13.Y
					if var22 and (var23 < 6 and -2 < var23) then
						var2.Jump = true
					end
				else
					local tbl1 = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var29, var30, var31 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var13 - Vector3.new(0, 1, 0), var16 * 3), tbl1)
					local var32, var33, var34 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var30 + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0)), tbl1)
					local var35 = var33.Y - var13.Y
					if var29 and (var35 < 6 and -2 < var35) then
						var2.Jump = true
					end
				end

				if expectedTimeToNextPoint + 2 < tick() - timeReachedLastPoint then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					var10:Fire("offtrack")
				end

				var3 = arg1.moveVector:Lerp(var16, arg2 * 10)
			end
		end
	end

	local var37 = var3.x
	local bool2 = false
	if var37 == var37 then
		bool2 = false
		if var37 ~= math.huge then
			bool2 = var37 ~= -math.huge
		end
	end

	if bool2 then
		var37 = var3.y
		bool2 = false
		if var37 == var37 then
			bool2 = false
			if var37 ~= math.huge then
				bool2 = var37 ~= -math.huge
			end
		end

		if bool2 then
			var37 = var3.z
			bool2 = false
			if var37 == var37 then
				bool2 = false
				if var37 ~= math.huge then
					bool2 = var37 ~= -math.huge
				end
			end
		end
	end

	if bool2 then
		arg1.moveVector = var3
	end
end

var13.OnUserCFrameEnabled = function(arg1)
	if arg1:ShouldUseNavigationLaser() then
		arg1:BindJumpAction(false)
		arg1:SetLaserPointerMode("Navigation")
		return
	end

	arg1:BindJumpAction(true)
	arg1:SetLaserPointerMode("Hidden")
end

var13.Enable = function(arg1, arg2)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		arg1.navigationRequestedConn = var2.NavigationRequested:Connect(function(arg1, arg2)
			arg1:OnNavigationRequest(arg1, arg2)
		end)

		arg1.heartbeatConn = var4.Heartbeat:Connect(function(arg1)
			arg1:OnHeartbeat(arg1)
		end)

		var6:BindAction("MoveThumbstick", function(arg1, arg2, arg3)
			local var1 = arg1
			local var2 = arg2
			local var3 = arg3
			return arg1:ControlCharacterGamepad(var1, var2, var3)
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)

		var6:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		arg1.userCFrameEnabledConn = var2.UserCFrameEnabled:Connect(function()
			arg1:OnUserCFrameEnabled()
		end)

		arg1:OnUserCFrameEnabled()
		var2:SetTouchpadMode(Enum.VRTouchpad.Left, Enum.VRTouchpadMode.VirtualThumbstick)
		var2:SetTouchpadMode(Enum.VRTouchpad.Right, Enum.VRTouchpadMode.ABXY)
		arg1.enabled = true
		return
	end

	arg1:StopFollowingPath()
	var6:UnbindAction("MoveThumbstick")
	var6:UnbindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	arg1:BindJumpAction(false)
	arg1:SetLaserPointerMode("Disabled")
	if arg1.navigationRequestedConn then
		arg1.navigationRequestedConn:Disconnect()
		arg1.navigationRequestedConn = nil
	end

	if arg1.heartbeatConn then
		arg1.heartbeatConn:Disconnect()
		arg1.heartbeatConn = nil
	end

	if arg1.userCFrameEnabledConn then
		arg1.userCFrameEnabledConn:Disconnect()
		arg1.userCFrameEnabledConn = nil
	end

	arg1.enabled = false
end

return var13

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
if require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls") then
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = Instance.new("BindableEvent")
	local bool2 = false
	local var10 = game:GetService("Players")
	local function fn3(arg1)
		var6 = nil
		var7 = nil
		if var8 then
			var8:Disconnect()
			var8 = nil
		end

		if arg1 then
			var6 = arg1:FindFirstChild("AbilityManagerActor")
			var7 = arg1:FindFirstChildOfClass("Humanoid")
			while not var7 do
				arg1.ChildAdded:wait()
				var7 = arg1:FindFirstChildOfClass("Humanoid")
			end

			var9:Fire()
			var8 = var7:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				var9:Fire()
			end)

		end
	end

	return {
		isEnabled = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			local bool3 = false
			if var6 ~= nil then
				bool3 = var7
				bool3 = bool3 and (not var7.EvaluateStateMachine)
			end

			return bool3
		end,
		GetEnabledChangedSignal = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			return var9.Event
		end,
	}

end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = {}
	return var1
end

tbl1.trackConnection = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = function()
		arg3:Disconnect()
	end
end

tbl1.trackBoundFunction = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = arg3
end

tbl1.disconnect = function(arg1, arg2)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
		arg1._connections[arg2] = nil
	end
end

tbl1.disconnectAll = function(arg1)
	for k1, v1 in pairs(arg1._connections) do
		v1()
	end

	arg1._connections = {}
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.ConnectionUtil)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.AppCommonLib).Signal
var2.describe("ConnectionUtil", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should track a connection", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		var4.new():trackConnection("Signal", var1:Connect(fn2))
		var1:fire("Testing")
		var5(str1).toBe("Testing")
	end)

	var3("should disconnect from signal", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		var2:disconnect("Signal")
		var1:fire("Testing")
		var5(str1).toBe("")
	end)

	var3("should disconnect from all", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		local str2 = ""
		fn2 = function(arg1)
			str2 = arg1
		end

		var2:trackConnection("Signal1", var6.new():Connect(fn2))
		local str3 = ""
		fn2 = function(arg1)
			str3 = arg1
		end

		var2:trackConnection("Signal2", var6.new():Connect(fn2))
		var2:disconnectAll()
		var1:fire("TestingPrimary")
		var1:fire("TestingSecondary")
		var1:fire("TestingTertiary")
		var5(str1).toBe("")
		var5(str2).toBe("")
		var5(str3).toBe("")
	end)

	var3("should call manual disconnect", function()
		local str1 = ""
		local var1 = var4.new()
		var1:trackBoundFunction("Manual", function()
			str1 = "Disconnected"
		end)

		var1:disconnect("Manual")
		var5(str1).toBe("Disconnected")
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = game:GetService("Players")
local tbl1 = { _connectionUtil = require(script.Parent:WaitForChild(str1)).new() }
tbl1._boundEvents = {}
tbl1.getLocalPlayer = function()
	return var1.LocalPlayer
end

tbl1.onLocalPlayer = function(arg1)
	local var3 = tbl1.getLocalPlayer()
	if var3 then
		arg1(var3)
	end

	local function fn2()
		local var1 = tbl1.getLocalPlayer()
		assert(var1)
		tbl1._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(var1)
	end

	tbl1._connectionUtil:trackConnection("LOCAL_PLAYER", var1:GetPropertyChangedSignal("LocalPlayer"):Connect(fn2))
	local var4 = arg1
	return tbl1._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(var4)
end

tbl1.getCharacter = function()
	local var2 = tbl1.getLocalPlayer()
	if not var2 then
		return nil
	end

	return var2.Character
end

tbl1.onCharacter = function(arg1)
	local function fn2(arg1)
		local var2 = tbl1.getCharacter()
		if var2 then
			arg1(var2)
		end

		local function fn2(arg1)
			assert(arg1)
			tbl1._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(arg1)
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_ADDED", arg1.CharacterAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_LOCAL_PLAYER", tbl1.onLocalPlayer(fn2))
	local var1 = arg1
	return tbl1._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(var1)
end

tbl1.getChild = function(arg1, arg2)
	local var2 = tbl1.getCharacter()
	if not var2 then
		return nil
	end

	local var4 = var2:FindFirstChild(arg1)
	if var4 and var4:IsA(arg2) then
		return var4
	end

	return nil
end

tbl1.onChild = function(arg1, arg2, arg3)
	local function fn2(arg1)
		local var2 = tbl1.getChild(arg1, arg2)
		if var2 then
			arg3(var2)
		end

		local function fn2(arg1)
			if arg1.Name == arg1 and arg1:IsA(arg2) then
				tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2):Fire(arg1)
			end
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", arg1.ChildAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_CHARACTER", tbl1.onCharacter(fn2))
	local var1 = arg3
	return tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2).Event:Connect(var1)
end

tbl1._getOrCreateBoundEvent = function(arg1)
	if not tbl1._boundEvents[arg1] then
		tbl1._boundEvents[arg1] = Instance.new("BindableEvent")
	end

	return tbl1._boundEvents[arg1]
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.CameraWrapper)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.TestUtils).DeferredLuaHelpers.waitForEvents
var2.describe("CameraWrapper", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should return updated camera", function()
		local var1 = var4.new()
		var1:Enable()
		local var2 = Instance.new("Camera")
		var2.Parent = game.Workspace
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).never.toBe(var2)
		game.Workspace.CurrentCamera = var2
		var6()
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).toBe(var2)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.FlagUtil [ModuleScript]
-- y u r i

return { getUserFlag = function(arg1)
	local success, result = pcall(function()
		local var1 = arg1
		return UserSettings():IsUserFeatureEnabled(var1)
	end)

	return success and result
end }

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper [ModuleScript]
-- y u r i

local var1 = require(script.Parent.ConnectionUtil)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	return (setmetatable({
		_camera = game.Workspace.CurrentCamera,
		_callbacks = {},
		_connectionUtil = var1.new(),
		_enabled = false,
	}, tbl1))
end

tbl1._connectCallbacks = function(arg1)
	arg1._camera = game.Workspace.CurrentCamera
	if not arg1._camera then
		return
	end

	for k1, v1 in arg1._callbacks, nil do
		local var1 = v1
		arg1._connectionUtil:trackConnection(k1, arg1._camera:GetPropertyChangedSignal(k1):Connect(var1))
		v1()
	end
end

tbl1.Enable = function(arg1)
	if arg1._enabled then
		return
	end

	arg1._enabled = true
	arg1._cameraChangedConnection = game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		arg1:_connectCallbacks()
	end)

	arg1:_connectCallbacks()
end

tbl1.Disable = function(arg1)
	if not arg1._enabled then
		return
	end

	arg1._enabled = false
	if arg1._cameraChangedConnection then
		arg1._cameraChangedConnection:Disconnect()
		arg1._cameraChangedConnection = nil
	end

	arg1._connectionUtil:disconnectAll()
end

tbl1.Connect = function(arg1, arg2, arg3)
	arg1._callbacks[arg2] = arg3
	if not arg1._camera then
		return
	end

	local var1 = arg3
	arg1._connectionUtil:trackConnection(arg2, arg1._camera:GetPropertyChangedSignal(arg2):Connect(var1))
end

tbl1.Disconnect = function(arg1, arg2)
	arg1._connectionUtil:disconnect(arg2)
	arg1._callbacks[arg2] = nil
end

tbl1.getCamera = function(arg1)
	return arg1._camera
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerScriptsLoader [LocalScript]
-- y u r i

local str1 = "PlayerModule"
require(script.Parent:WaitForChild(str1))

--- Players.LocalPlayer.PlayerScripts.Controllers.SkyController [ModuleScript]
-- y u r i

local var1 = nil
local tbl1 = {
	"SkyboxBk",
	"SkyboxDn",
	"SkyboxFt",
	"SkyboxLf",
	"SkyboxRt",
	"SkyboxUp",
	"SunTextureId",
	"MoonTextureId",
	"SunAngularSize",
	"MoonAngularSize",
	"StarCount",
	"CelestialBodiesShown",
}

local var2 = nil
local var3 = game:GetService("ReplicatedStorage")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local var6 = game:GetService("RunService")
local var7 = nil
local function applySky(arg1)
	local var4 = var1:FindFirstChild(arg1)
	if not var4 or (not var4:IsA("Sky")) then
		return
	end

	for k1, v1 in ipairs(tbl1) do
		var2[v1] = var4[v1]
	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	local var8 = workspace:WaitForChild("Areas")
	var1 = var3:WaitForChild("Sky")
	var2 = var4:FindFirstChildOfClass("Sky")
	if not var2 then
		var2 = Instance.new("Sky")
		var2.Parent = var4
	end

	local var9 = var5.Character
	var9 = var9 or var5.CharacterAdded:Wait()
	local var10 = var9:WaitForChild("HumanoidRootPart")
	var5.CharacterAdded:Connect(function(arg1)
		var9 = arg1
		var10 = arg1:WaitForChild("HumanoidRootPart")
	end)

	var6.RenderStepped:Connect(function()
		if not var10 then
			return
		end

		local var1 = nil
		for k1, v1 in ipairs(var8:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			local var2 = v1.CFrame:PointToObjectSpace(var10.Position)
			local var3 = v1.Size / 2
			local bool2 = false
			if math.abs(var2.X) <= var3.X then
				bool2 = false
				if math.abs(var2.Y) <= var3.Y then
					bool2 = math.abs(var2.Z) <= var3.Z
				end
			end

			if not bool2 then
				continue
			end

			var1 = v1
			break
		end

		if var1 ~= var7 then
			var7 = var1
			if var7 then
				applySky(var7.Name)
			end
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.AudioController [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local function formatTime(arg1)
	arg1 = math.max(0, (math.floor(arg1)))
	local str1 = "%d:%02d"
	local var1 = math.floor(arg1 / 60)
	local var2 = arg1 % 60
	return string.format(str1, var1, var2)
end

local tbl1 = {}
local var2 = nil
local bool1 = false
local function updateBoombox(arg1)
	local var2 = var1:WaitForChild("PlayerGui"):WaitForChild("BoomboxGUI"):WaitForChild("Frame")
	local var3 = var2:WaitForChild("Title")
	local var4 = var2:WaitForChild("Time")
	local var5 = var2:WaitForChild("Position")
	if not arg1 then
		var3.Text = "No song"
		var4.Text = "(0:00-0:00)"
		return
	end

	local var6 = arg1:GetAttribute("Title")
	var3.Text = var6 or arg1.Name
	var6 = arg1.TimeLength
	if 0 < var6 then
		local var7 = math.max(0, (math.floor(arg1.TimePosition)))
		local var8 = string.format("%d:%02d", math.floor(var7 / 60), var7 % 60)
		local var9 = var6
		var4.Text = string.format("(%s-%s)", var8, formatTime(var9))
	else
		var4.Text = "(0:00-0:00)"
	end

	local var10 = UDim2.new(0, 0, var5.Position.Y.Scale, var5.Position.Y.Offset)
	var5.Position = var10
end

local bool2 = true
local var3 = game:GetService("SoundService")
local function getRandomSong()
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1) do
		if v1 == var2 then
			continue
		end

		table.insert(tbl2, v1)
	end

	if #tbl2 == 0 then
		return tbl1[math.random(1, #tbl1)]
	end

	return tbl2[math.random(1, #tbl2)]
end

local function playNextSong()
	local var1 = nil
	if bool2 then
		bool2 = false
		var1 = var3.BGMFolder:FindFirstChild("Classic Easter")
		if not var1 or (not var1:IsA("Sound")) then
			warn("[AudioController] could not find \"Classic Easter\"")
			var1 = getRandomSong()
		end
	else
		var1 = getRandomSong()
	end

	if bool1 then
		return
	end

	bool1 = true
	for k1, v1 in ipairs(tbl1) do
		v1:Stop()
		v1.TimePosition = 0
	end

	var2 = var1
	var1.TimePosition = 0
	var1:Play()
	updateBoombox(var1)
	bool1 = false
end

local var4 = require(game:GetService("ReplicatedStorage").Shared.Remotes)
local var5 = game:GetService("TweenService")
local var6 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var7 = game:GetService("RunService")
local function startPurchaseSounds()
	local var3 = var1:GetAttribute("CameraShake")
	local var7 = workspace.CurrentCamera
	if var3 == nil then
		var3 = true
	end

	var1:GetAttributeChangedSignal("CameraShake"):Connect(function()
		var3 = var1:GetAttribute("CameraShake")
		if var3 == nil then
			var3 = true
		end
	end)

	local num1 = 0
	local num2 = 0
	local var8 = nil
	var4.SoundPlayEvent.OnClientEvent:Connect(function(arg1)
		local var1 = tick()
		if var1 - num1 <= 1 then
			local var2 = num2 + 1
			num2 = var2
		else
			num2 = 0
		end

		num1 = var1
		arg1.PlaybackSpeed = math.min(num2 * 0.05 + 1, 2)
		arg1:Play()
		if not var3 then
			return
		end

		if var8 then
			var8:Cancel()
		end

		var7.FieldOfView = math.min(var7.FieldOfView + 2, 90)
		var8 = var5:Create(var7, var6, { FieldOfView = 70 })
		var8:Play()
	end)
end

local function startMusic()
	table.clear(tbl1)
	for k1, v1 in ipairs(var3:WaitForChild("BGMFolder"):GetChildren()) do
		if not v1:IsA("Sound") then
			continue
		end

		table.insert(tbl1, v1)
	end

	if #tbl1 == 0 then
		warn("[AudioController] no songs found in SoundService.BGMFolder")
		return
	end

	playNextSong()
	for k2, v2 in ipairs(tbl1) do
		v2.Ended:Connect(function()
			if v2 == var2 and (not bool1) then
				playNextSong()
			end
		end)

	end
end

return { Start = function()
	startPurchaseSounds()
	startMusic()
	var7.RenderStepped:Connect(function()
		if not var2 then
			return
		end

		local var4 = var1:FindFirstChild("PlayerGui")
		if not var4 then
			return
		end

		local var6 = var4:FindFirstChild("BoomboxGUI")
		if not var6 then
			return
		end

		local var8 = var6:FindFirstChild("Frame")
		if not var8 then
			return
		end

		local var12 = var8:FindFirstChild("Title")
		local var13 = var8:FindFirstChild("Time")
		local var14 = var8:FindFirstChild("Position")
		if not var12 or (not var13 or (not var8:FindFirstChild("Line") or (not var14))) then
			return
		end

		local var16 = var2.TimeLength
		if var16 <= 0 then
			return
		end

		local var17 = var2:GetAttribute("Title")
		local var18 = math.clamp(var2.TimePosition / var16, 0, 1)
		var12.Text = var17 or var2.Name
		local var19 = math.max(0, (math.floor(var2.TimePosition)))
		local var20 = string.format("%d:%02d", math.floor(var19 / 60), var19 % 60)
		local var21 = var16
		var13.Text = string.format("(%s-%s)", var20, formatTime(var21))
		var17 = UDim2.new(var18, 0, var14.Position.Y.Scale, var14.Position.Y.Offset)
		var14.Position = var17
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.PortalFXController [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = require(game:GetService("ReplicatedStorage").Shared.Remotes)
local var3 = game:GetService("TweenService")
local var4 = TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local var5 = TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
return { Start = function()
	repeat
		task.wait(2)
	until game:IsLoaded()

	local var6 = Instance.new("ScreenGui")
	var6.Name = "TeleportTransition"
	var6.IgnoreGuiInset = true
	var6.ResetOnSpawn = false
	var6.Parent = var1:WaitForChild("PlayerGui")
	local var7 = Instance.new("Frame")
	var7.AnchorPoint = Vector2.new(0.5, 0.5)
	var7.Position = UDim2.fromScale(0.5, 0.5)
	var7.Size = UDim2.fromOffset(0, 0)
	var7.BackgroundColor3 = Color3.new(0, 0, 0)
	var7.BorderSizePixel = 0
	var7.Parent = var6
	local var8 = Instance.new("UICorner")
	var8.CornerRadius = UDim.new(1, 0)
	var8.Parent = var7
	local var9 = math.max(workspace.CurrentCamera.ViewportSize.X, workspace.CurrentCamera.ViewportSize.Y) * 3
	var2.TeleportTransition.OnClientEvent:Connect(function(arg1)
		if arg1 == "Uncover" then
			var3:Create(var7, var4, { Size = UDim2.fromOffset(0, 0) }):Play()
			return
		end

		var7.Size = UDim2.fromOffset(0, 0)
		var3:Create(var7, var5, { Size = UDim2.fromOffset(var9, var9) }):Play()
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.CmdrController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local tbl1 = { [1837214769] = true, [2577214977] = true }
local tbl2 = { Enum.KeyCode.F4 }
return { Start = function()
	if not tbl1[var2.LocalPlayer.UserId] then
		return
	end

	local str1 = "CmdrClient"
	local var3 = require(var1:WaitForChild(str1))
	var3:SetActivationKeys(tbl2)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.AdminPanelController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = Enum.Font.FredokaOne
local var3 = require(var1.Config.GameConfig)
local var4 = game:GetService("Players").LocalPlayer
local tbl1 = {
	{
		key = "target",
		label = "Target (username, blank = All)",
		placeholder = "Target player",
	},
	{ key = "title", label = "Boost Title", placeholder = "e.g. Weekend Boost" },
	{ key = "duration", label = "Duration (seconds)", placeholder = "e.g. 300" },
	{
		key = "stats",
		label = "Stats (comma separated)",
		placeholder = "e.g. Points, SpacePoints, DarkMatter",
	},
	{ key = "mult", label = "Multiplier", placeholder = "e.g. 2" },
}

local function makeLabel(arg1, arg2)
	local var1 = Instance.new("TextLabel")
	var1.Size = UDim2.new(1, 0, 0, 20)
	var1.BackgroundTransparency = 1
	var1.Text = arg2
	var1.TextColor3 = Color3.fromRGB(200, 200, 210)
	var1.Font = var2
	var1.TextSize = 16
	var1.TextXAlignment = Enum.TextXAlignment.Left
	var1.Parent = arg1
	return var1
end

local function makeTextBox(arg1, arg2)
	local var1 = Instance.new("TextBox")
	var1.Size = UDim2.new(1, 0, 0, 34)
	var1.BackgroundColor3 = Color3.fromRGB(40, 40, 48)
	var1.PlaceholderText = arg2
	var1.Text = ""
	var1.TextColor3 = Color3.fromRGB(255, 255, 255)
	var1.PlaceholderColor3 = Color3.fromRGB(140, 140, 150)
	var1.Font = var2
	var1.TextSize = 16
	var1.ClearTextOnFocus = false
	var1.Parent = arg1
	local var3 = Instance.new("UICorner", var1)
	var3.CornerRadius = UDim.new(0, 8)
	return var1
end

local var5 = require(var1.Remotes)
return { Start = function()
	if not var3.AdminUserIds[var4.UserId] then
		return
	end

	local var1 = Instance.new("ScreenGui")
	var1.Name = "AdminBoostPanel"
	var1.ResetOnSpawn = false
	var1.Parent = var4:WaitForChild("PlayerGui")
	local var6 = Instance.new("TextButton")
	var6.Size = UDim2.fromOffset(50, 50)
	var6.Position = UDim2.new(0, 10, 0, 10)
	var6.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
	var6.Text = "\226\154\153"
	var6.TextColor3 = Color3.fromRGB(255, 255, 255)
	var6.TextScaled = true
	var6.Font = var2
	var6.Parent = var1
	local var7 = Instance.new("UICorner", var6)
	var7.CornerRadius = UDim.new(0, 12)
	var7 = Instance.new("Frame")
	var7.Size = UDim2.fromOffset(320, 380)
	var7.Position = UDim2.new(0, 10, 0, 70)
	var7.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
	var7.BackgroundTransparency = 0.1
	var7.Visible = false
	var7.Parent = var1
	local var8 = Instance.new("UICorner", var7)
	var8.CornerRadius = UDim.new(0, 14)
	var8 = Instance.new("UIListLayout")
	var8.Padding = UDim.new(0, 8)
	var8.HorizontalAlignment = Enum.HorizontalAlignment.Center
	var8.Parent = var7
	local var9 = Instance.new("UIPadding")
	var9.PaddingTop = UDim.new(0, 12)
	var9.PaddingLeft = UDim.new(0, 12)
	var9.PaddingRight = UDim.new(0, 12)
	var9.Parent = var7
	local tbl2 = {}
	for k1, v1 in ipairs(tbl1) do
		makeLabel(var7, v1.label)
		tbl2[v1.key] = makeTextBox(var7, v1.placeholder)
	end

	local var10 = Instance.new("TextButton")
	var10.Size = UDim2.new(1, 0, 0, 40)
	var10.BackgroundColor3 = Color3.fromRGB(70, 160, 90)
	var10.Text = "Grant Boost"
	var10.TextColor3 = Color3.fromRGB(255, 255, 255)
	var10.Font = var2
	var10.TextSize = 18
	var10.Parent = var7
	local var11 = Instance.new("UICorner", var10)
	var11.CornerRadius = UDim.new(0, 10)
	var6.MouseButton1Click:Connect(function()
		var7.Visible = not var7.Visible
	end)

	var10.MouseButton1Click:Connect(function()
		var5.AdminGrantBoostEvent:FireServer(tbl2.target.Text, tbl2.title.Text, tonumber(tbl2.duration.Text), tbl2.stats.Text, (tonumber(tbl2.mult.Text)))
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.BoostHUDController [ModuleScript]
-- y u r i

local var1 = Enum.Font.FredokaOne
local function makeTooltipLine(arg1, arg2)
	local var2 = Instance.new("TextLabel")
	var2.Size = UDim2.new(1, 0, 0, 20)
	var2.BackgroundTransparency = 1
	var2.Text = arg2
	var2.TextColor3 = Color3.fromRGB(220, 220, 230)
	var2.Font = var1
	var2.TextSize = 14
	var2.TextXAlignment = Enum.TextXAlignment.Left
	var2.ZIndex = 51
	var2.Parent = arg1
	return var2
end

local function buildTooltip(arg1, arg2)
	local var1 = Instance.new("Frame")
	var1.Name = "BoostTooltip"
	var1.Size = UDim2.fromOffset(230, 0)
	var1.AutomaticSize = Enum.AutomaticSize.Y
	var1.AnchorPoint = Vector2.new(1, 1)
	var1.Position = UDim2.new(0, -8, 0, -4)
	var1.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
	var1.BackgroundTransparency = 0.05
	var1.Visible = false
	var1.ZIndex = 50
	var1.Parent = arg1
	local var2 = Instance.new("UICorner", var1)
	var2.CornerRadius = UDim.new(0, 8)
	var2 = Instance.new("UIPadding")
	var2.PaddingLeft = UDim.new(0, 10)
	var2.PaddingRight = UDim.new(0, 10)
	var2.PaddingTop = UDim.new(0, 8)
	var2.PaddingBottom = UDim.new(0, 8)
	var2.Parent = var1
	local var3 = Instance.new("UIListLayout")
	var3.Padding = UDim.new(0, 2)
	var3.SortOrder = Enum.SortOrder.LayoutOrder
	var3.Parent = var1
	if typeof(arg2.stats) == "table" then
		for k1, v1 in ipairs(arg2.stats) do
			makeTooltipLine(var1, "x" .. tostring(arg2.mult) .. " " .. tostring(v1))
		end

		return var1
	end

	makeTooltipLine(var1, arg2.effectText or "")
	return var1
end

local var2 = game:GetService("RunService")
local function formatRemaining(arg1)
	if 3600 <= arg1 then
		local str1 = "%dh %02dm %02ds left"
		local var1 = math.floor(arg1 / 3600)
		local var2 = math.floor(arg1 % 3600 / 60)
		local var3 = arg1 % 60
		return string.format(str1, var1, var2, var3)
	end

	if 60 <= arg1 then
		local str2 = "%dm %02ds left"
		local var4 = math.floor(arg1 / 60)
		local var5 = arg1 % 60
		return string.format(str2, var4, var5)
	end

	return arg1 .. "s left"
end

local var3 = game:GetService("Players").LocalPlayer
local var4 = require(game:GetService("ReplicatedStorage").Shared.Remotes)
local function addCard(arg1, arg2)
	local var3 = Instance.new("TextButton")
	var3.Name = arg2.id
	var3.Size = UDim2.new(1, 0, 0, 56)
	var3.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
	var3.BackgroundTransparency = 0.15
	var3.Text = ""
	var3.AutoButtonColor = false
	var3.Parent = arg1
	local var4 = Instance.new("UICorner", var3)
	var4.CornerRadius = UDim.new(0, 10)
	var4 = Instance.new("UIPadding")
	var4.PaddingLeft = UDim.new(0, 10)
	var4.PaddingRight = UDim.new(0, 10)
	var4.PaddingTop = UDim.new(0, 6)
	var4.Parent = var3
	local var5 = Instance.new("TextLabel")
	var5.Size = UDim2.new(1, 0, 0, 22)
	var5.BackgroundTransparency = 1
	var5.Text = arg2.title
	var5.TextColor3 = Color3.fromRGB(255, 215, 0)
	var5.Font = var1
	var5.TextSize = 16
	var5.TextXAlignment = Enum.TextXAlignment.Left
	var5.Parent = var3
	local var6 = Instance.new("TextLabel")
	var6.Size = UDim2.new(1, 0, 0, 18)
	var6.Position = UDim2.new(0, 0, 0, 24)
	var6.BackgroundTransparency = 1
	var6.TextColor3 = Color3.fromRGB(150, 150, 160)
	var6.Font = var1
	var6.TextSize = 12
	var6.TextXAlignment = Enum.TextXAlignment.Left
	var6.Parent = var3
	local var7 = buildTooltip(var3, arg2)
	var3.MouseEnter:Connect(function()
		var7.Visible = true
	end)

	var3.MouseLeave:Connect(function()
		var7.Visible = false
	end)

	local var8 = nil
	local var9 = os.clock() + arg2.duration
	var2.Heartbeat:Connect(function()
		if not var3.Parent then
			var8:Disconnect()
			return
		end

		local var2 = var9 - os.clock()
		if var2 <= 0 then
			var8:Disconnect()
			var3:Destroy()
			return
		end

		var6.Text = formatRemaining((math.ceil(var2)))
	end)
end

return { Start = function()
	local var1 = Instance.new("ScreenGui")
	var1.Name = "BoostHUD"
	var1.ResetOnSpawn = false
	var1.Parent = var3:WaitForChild("PlayerGui")
	local var2 = Instance.new("Frame")
	var2.AnchorPoint = Vector2.new(1, 1)
	var2.Position = UDim2.new(1, -10, 1, -10)
	var2.Size = UDim2.fromOffset(260, 0)
	var2.AutomaticSize = Enum.AutomaticSize.Y
	var2.BackgroundTransparency = 1
	var2.Parent = var1
	local var5 = Instance.new("UIListLayout")
	var5.SortOrder = Enum.SortOrder.LayoutOrder
	var5.Padding = UDim.new(0, 6)
	var5.VerticalAlignment = Enum.VerticalAlignment.Bottom
	var5.Parent = var2
	var4.BoostHUDEvent.OnClientEvent:Connect(function(arg1)
		addCard(var2, arg1)
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.CurrencyHUDController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.Libs.EternityNum)
local var3 = require(var1.Formulas)
local var4 = game:GetService("Players").LocalPlayer
local function getGain(arg1, arg2, arg3)
	local var5 = arg3:GetAttribute("TotalBoost") or 0
	if arg1 == "Prestige" then
		local var6 = var5
		local var7 = arg2.Points.Value
		return var3.PrestigeGain(var6, var7)
	end

	if arg1 == "Steel" then
		local var10 = var5
		local var11 = arg2.Power.Value
		return var3.SteelGain(var10, var11)
	end

	if arg1 == "SpacePrestige" then
		local var14 = var5
		local var15 = arg2.StarLevels.Value
		return var3.SpacePrestigeGain(var14, var15)
	end

	return var5
end

local var5 = require(var1.Config.Stats)
local function formatGain(arg1)
	local var3 = tonumber(arg1)
	if var3 and math.abs(var3) < 1 then
		local str1 = "%.1f"
		local var4 = var3
		return string.format(str1, var4)
	end

	local var5 = arg1
	return var2.short(var5)
end

local var6 = game:GetService("RunService")
return { Start = function()
	local var1 = var4:WaitForChild("PlayerGui"):WaitForChild("CurrencyGUI"):WaitForChild("Frame")
	local var3 = var1:WaitForChild("TextLabel")
	local var7 = var4.Character
	var7 = var7 or var4.CharacterAdded:Wait()
	local var8 = var7:WaitForChild("HumanoidRootPart")
	var4.CharacterAdded:Connect(function(arg1)
		var7 = arg1
		var8 = arg1:WaitForChild("HumanoidRootPart")
	end)

	local var9 = workspace:WaitForChild("CurrencyAreas")
	local var10 = var4:WaitForChild("Values")
	local var11 = var1:WaitForChild("UIGradient")
	local var12 = var3:WaitForChild("UIStroke")
	local function getCurrentCurrency()
		for k1, v1 in ipairs(var9:GetChildren()) do
			if not v1:IsA("BasePart") then
				continue
			end

			local var1 = v1.CFrame:PointToObjectSpace(var8.Position)
			local var2 = v1.Size / 2
			local bool2 = false
			if math.abs(var1.X) <= var2.X then
				bool2 = false
				if math.abs(var1.Y) <= var2.Y then
					bool2 = math.abs(var1.Z) <= var2.Z
				end
			end

			if not bool2 then
				continue
			end

			return v1.Name
		end

		return nil
	end

	local var13 = nil
	local function updateCurrencyText(arg1)
		if not arg1 then
			var3.Text = ""
			return
		end

		local var4 = var10:FindFirstChild(arg1)
		if not var4 then
			var3.Text = ""
			return
		end

		local var8 = var2.short(var4.Value)
		local var9 = getGain(arg1, var10, var4)
		local var13 = var5.Symbol[arg1] or arg1
		local var14 = var5.ClickSuffix
		if not var5.AlwaysPerSecond[arg1] then
			if var2.meeq(var9, 0) == false then
				var14 = var5.PerSecondSuffix
			end
		end

		local var17 = var5.CustomHUDFormat[arg1]
		if var17 then
			local var18 = var9
			var3.Text = string.format(var17, var8, formatGain(var18))
		else
			local var20 = tonumber(var9)
			local var21 = var3
			local var22 = string.format
			local str1 = "%s %s (+%s %s%s)"
			local var23 = var8
			local var24 = var13
			var21.Text = var22(str1, var23, var24, if var20 and math.abs(var20) < 1 then string.format("%.1f", var20) else var2.short(var9), var13, var14)
		end

		local var25 = var5.Colors[arg1]
		local var26 = var25 and var25.TextColor or var5.DefaultTextColor
		var3.TextColor3 = var26
		var11.Color = ColorSequence.new(var25 and var25.GradientColor or var26)
		var12.Color = var25 and var25.StrokeColor or var5.DefaultStrokeColor
	end

	local num1 = 0
	var6.RenderStepped:Connect(function(arg1)
		local var2 = getCurrentCurrency()
		if var2 ~= var13 then
			var13 = var2
			updateCurrencyText(var2)
			num1 = 0
			return
		end

		if not var2 then
			var3.Text = ""
			return
		end

		local var4 = num1 + arg1
		num1 = var4
		if 0.25 <= num1 then
			var4 = num1 - 0.25
			num1 = var4
			updateCurrencyText(var2)
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.LevelBarController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = game:GetService("Players").LocalPlayer
local tbl1 = { "LevelsGUI", "LevelsGUIV2" }
local var3 = require(var1.Formulas)
local var4 = require(var1.Libs.EternityNum)
local var5 = game:GetService("TweenService")
local var6 = TweenInfo.new(0.2)
return { Start = function()
	local var1 = var2:WaitForChild("Values")
	local var7 = var1:WaitForChild("Level")
	local var8 = var1:WaitForChild("XP")
	local var9 = var2:WaitForChild("Upgrades"):WaitForChild("#5")
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(tbl1) do
		local var10 = workspace:WaitForChild(v1):WaitForChild("SurfaceGui")
		table.insert(tbl2, (var10:WaitForChild("ProgressBackground"):WaitForChild("ProgressFill")))
		local var11 = var10:FindFirstChild("Frame")
		if not var11 then
			continue
		end

		local tbl4 = { Level = var11:FindFirstChild("Level") }
		tbl4.XP = var11:FindFirstChild("XP")
		tbl4.PBoost = var11:FindFirstChild("PBoost")
		table.insert(tbl3, tbl4)
	end

	local function update()
		local var1 = var3.XPRequirement(var7.Value)
		local var2 = var8.Value
		local var10 = var1
		local var11 = var4.toNumber(var4.div(var2, var10))
		local var12 = math.clamp(var11, 0, 1)
		for k1, v1 in ipairs(tbl2) do
			var5:Create(v1, var6, { Size = UDim2.fromScale(var12, 1) }):Play()
		end

		if (var9:GetAttribute("purchaseCount") or 0) <= 0 then
			return
		end

		local var13 = var7.Value
		var11 = "Level: " .. var4.toNumber(var4.fromString(var13))
		local num1 = 2
		local var14 = var7.Value
		local var15 = " XP: " .. var4.short(var8.Value) .. "/" .. var4.short(var1)
		var2 = var4.short(var4.pow(num1, var14)) .. "x P$"
		for k2, v2 in ipairs(tbl3) do
			if v2.Level then
				v2.Level.Text = var11
			end

			if v2.XP then
				v2.XP.Text = var15
			end

			if not v2.PBoost then
				continue
			end

			v2.PBoost.Text = var2
		end
	end

	var7.Changed:Connect(update)
	var8.Changed:Connect(update)
	var9:GetAttributeChangedSignal("purchaseCount"):Connect(update)
	update()
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.LoopController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.Formulas)
local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Libs.EternityNum)
local var5 = Color3.fromRGB(0, 130, 0)
local var6 = Color3.fromRGB(0, 0, 0)
local var7 = require(var1.Config.GameConfig)
local var8 = require(var1.Remotes)
return { Start = function()
	local var1 = var3:WaitForChild("Values")
	local var9 = workspace:WaitForChild("loopbuttonguiwow"):WaitForChild("MilestoneGUI"):WaitForChild("SurfaceGui"):WaitForChild("Frame")
	local var10 = workspace:WaitForChild("loopmilestones"):WaitForChild("MilestoneGUI"):WaitForChild("SurfaceGui"):WaitForChild("ScrollingFrame")
	local var11 = var1:WaitForChild("Loops")
	local var12 = var9:WaitForChild("CurrentLoops")
	local var13 = var1:WaitForChild("Level")
	local var14 = var3:WaitForChild("Upgrades"):WaitForChild("#3nv")
	local var15 = var9:WaitForChild("TextButton")
	var15.MouseButton1Click:Connect(function()
		if var4.me(var2.LoopsGained(var13.Value, var11.Value, true), 0) then
			var8.LoopEvent:FireServer()
		end
	end)

	local function updateMilestones()
		for k1, v1 in ipairs(var10:GetChildren()) do
			if not v1:IsA("Frame") then
				continue
			end

			local str1 = "^Milestone(%d+)$"
			local var1 = tonumber(v1.Name:match(str1))
			if not var1 then
				continue
			end

			local var2 = v1:FindFirstChild("Title")
			if not var2 then
				continue
			end

			if not var2:IsA("TextLabel") then
				continue
			end

			var2.Text = "Milestone " .. var1 .. " [Loop " .. var1 .. "]"
			local var3 = var4.meeq(var11.Value, var1) and var5 or var6
			var2.TextColor3 = var3
		end
	end

	local function updateButton()
		var12.Text = "Current Loops: " .. var4.short(var11.Value)
		local var1 = var2.LoopsGained(var13.Value, var11.Value, true)
		if var4.me(var1, 0) and 0 < (var14:GetAttribute("purchaseCount") or 0) then
			local var9 = var13.Value
			local var10 = var7.Thresholds.LoopLevelsPerLoop
			local var16 = var4.floor(var4.div(var9, var10))
			local var17 = var16
			var15.Text = "Loop! (+" .. var4.toNumber(var1) .. " Loops, Next: " .. var4.short(var2.LoopRequirement(var17)) .. " Levels)"
			return
		end

		local var18 = var11.Value
		var15.Text = "Loop! (Req: " .. var4.toNumber(var2.LoopRequirement(var18)) .. " Levels)"
	end

	var11.Changed:Connect(function()
		updateMilestones()
		updateButton()
	end)

	var13.Changed:Connect(updateButton)
	var14:GetAttributeChangedSignal("purchaseCount"):Connect(updateButton)
	updateMilestones()
	updateButton()
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.DeltaClickerController [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = game:GetService("TweenService")
local var3 = TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
local tbl1 = {
	{ Upgrade = "#B3\206\148", Seconds = 2 },
	{ Upgrade = "#B7\206\148", Seconds = 1.5 },
	{ Upgrade = "#B8\206\148", Seconds = 1 },
}

local var4 = Color3.fromRGB(76, 76, 76)
local var5 = Color3.fromRGB(85, 0, 0)
local var6 = game:GetService("RunService")
return { Start = function()
	local var7 = var1:WaitForChild("Upgrades")
	local var8 = workspace:WaitForChild("UpgradesFolder"):WaitForChild("#B1\206\148")
	local var9 = var8:WaitForChild("Main")
	local var10 = var8:WaitForChild("ClickDetector")
	local var11 = var7:WaitForChild("#B1\206\148")
	local var12 = var8:WaitForChild("Border")
	local bool1 = false
	local var13 = var11:GetAttribute("purchaseCount") or 0
	local bool2 = false
	local function tweenColors(arg1, arg2)
		var2:Create(var12, var3, { Color = arg1 }):Play()
		var2:Create(var9, var3, { Color = arg2 }):Play()
	end

	local function getCooldownTime()
		local num1 = 5
		for k1, v1 in ipairs(tbl1) do
			local var1 = var7:FindFirstChild(v1.Upgrade)
			if not var1 then
				continue
			end

			if 0 >= (var1:GetAttribute("purchaseCount") or 0) then
				continue
			end

			num1 = num1 - v1.Seconds
		end

		return num1
	end

	local var14 = var9:WaitForChild("SurfaceGui"):WaitForChild("Cooldown")
	local var15 = var10.MaxActivationDistance
	var11:GetAttributeChangedSignal("purchaseCount"):Connect(function()
		local var1 = var11:GetAttribute("purchaseCount") or 0
		if not bool1 then
			var13 = var1
			bool1 = true
			return
		end

		if var1 <= var13 then
			var13 = var1
			return
		end

		var13 = var1
		if bool2 then
			return
		end

		bool2 = true
		var10.MaxActivationDistance = 0
		tweenColors(var4, var5)
		task.wait(0.1)
		local var2 = var12.Color
		local var3 = var9.Color
		local var7 = var6.RenderStepped:Connect(function()
			var12.Color = var4
			var9.Color = var5
		end)

		local var8 = time()
		local var16 = getCooldownTime()
		while time() - var8 < var16 do
			local var17 = var16 - (time() - var8)
			local var18 = math.floor(var17)
			var14.Text = string.format("%d.%02ds", var18, (math.floor(math.floor((var17 - var18) * 1000) / 10)))
			var6.RenderStepped:Wait()
		end

		var7:Disconnect()
		var14.Text = "Free"
		tweenColors(var2, var3)
		var10.MaxActivationDistance = var15
		bool2 = false
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.UpgradeInputController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = require(script.Parent.SettingsController)
local var4 = require(var1.Config.GameConfig)
local var5 = require(var1.Remotes)
local function fireBuy(arg1)
	if var4.NonHoldableUpgrades[arg1.Name] then
		var5.BuyOneEvent:FireServer(arg1)
		return
	end

	if if not var2 or (var2:GetAttribute("purchaseCount") or 0) <= 0 then false else var3.IsBuyMaxAllowed(arg1.Name) then
		var5.BuyMaxEvent:FireServer(arg1)
		return
	end

	var5.BuyOneEvent:FireServer(arg1)
end

local var6 = game:GetService("UserInputService")
local var7 = game:GetService("TweenService")
local var8 = TweenInfo.new(0.15)
local var9 = nil
local function wireButton(arg1, arg2)
	local var1 = nil
	arg1.InputBegan:Connect(function(arg1)
		local bool1 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool1 = arg1.UserInputType == Enum.UserInputType.Touch
		end

		if not bool1 then
			return
		end

		if var1 ~= nil then
			return
		end

		var1 = arg1
	end)

	arg1.InputEnded:Connect(function(arg1)
		if arg1 ~= var1 then
			return
		end

		var1 = nil
		fireBuy(arg2)
	end)

	var6.InputChanged:Connect(function(arg1)
		if arg1 ~= var1 then
			return
		end

		if arg1.UserInputType ~= Enum.UserInputType.Touch and arg1.UserInputType ~= Enum.UserInputType.MouseMovement then
			return
		end

		local var2 = arg1.Position
		local var3 = Vector2.new(var2.X, var2.Y)
		local var4 = arg1.AbsolutePosition
		local bool2 = false
		local var6 = arg1.AbsoluteSize
		if var4.X <= var3.X then
			bool2 = false
			if var3.X <= var4.X + var6.X then
				bool2 = false
				if var4.Y <= var3.Y then
					bool2 = var3.Y <= var4.Y + var6.Y
				end
			end
		end

		if not bool2 then
			var1 = nil
		end
	end)
end

local function setupHoverLighten(arg1)
	local var1 = arg1.BackgroundColor3
	arg1.MouseEnter:Connect(function()
		var1 = arg1.BackgroundColor3
		var7:Create(arg1, var8, { BackgroundColor3 = var1:Lerp(Color3.new(0.05, 0.05, 0.05), 0.75) }):Play()
	end)

	arg1.MouseLeave:Connect(function()
		var7:Create(arg1, var8, { BackgroundColor3 = var1 }):Play()
	end)
end

local var10 = nil
local var11 = game:GetService("Players").LocalPlayer
local function getUpgradeUnderMouse()
	local var1 = var6:GetMouseLocation()
	local var2 = workspace.CurrentCamera:ViewportPointToRay(var1.X, var1.Y)
	local var4 = workspace:Raycast(var2.Origin, var2.Direction * 500, var10)
	if not var4 then
		return nil
	end

	local var7 = var4.Instance:FindFirstAncestorOfClass("Model")
	if not var7 or var7.Parent ~= var9 then
		return nil
	end

	local var12 = var7:FindFirstChildWhichIsA("ClickDetector", true)
	if not var12 then
		return nil
	end

	local var13 = var11.Character
	local var14 = var13
	var14 = var14 and var13:FindFirstChild("HumanoidRootPart")
	if not var14 then
		return nil
	end

	if var12.MaxActivationDistance < (var14.Position - var4.Position).Magnitude then
		return nil
	end

	return var7
end

local var12 = nil
local function onInputBegan(arg1, arg2)
	if not arg2 then
		local bool1 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool1 = arg1.UserInputType == Enum.UserInputType.Touch
		end

		if not bool1 then
			return
		end
	end

	local var2 = getUpgradeUnderMouse()
	if not var2 then
		return
	end

	var12 = var2
end

local function onInputEnded(arg1)
	local bool1 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool1 = arg1.UserInputType == Enum.UserInputType.Touch
	end

	if not bool1 then
		return
	end

	if not var12 then
		return
	end

	if getUpgradeUnderMouse() == var12 then
		fireBuy(var12)
	end

	var12 = nil
end

local tbl1 = { "darkboard", "starlevel" }
local function wireBoard(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(workspace:WaitForChild(arg1):WaitForChild("MainPart"):WaitForChild("SurfaceGui"):WaitForChild("ViewFrame"):WaitForChild("DragFrame"):GetChildren()) do
		local var1 = v1:IsA("Folder")
		var1 = var1 and v1:FindFirstChild("TextButton")
		if not var1 then
			continue
		end

		if not var1:IsA("TextButton") then
			continue
		end

		local var3 = var9:FindFirstChild(v1.Name)
		if var3 then
			wireButton(var1, var3)
		else
			table.insert(tbl1, v1.Name)
		end

		if not string.find(v1.Name, "sl") then
			continue
		end

		setupHoverLighten(var1)
	end

	if 0 < (#tbl1) then
		table.sort(tbl1)
		local var4 = tbl1
		local str1 = ", "
		local var5 = arg1
		print(("[UpgradeInput] %s: no upgrade behind %s \226\128\148 button left inert"):format(var5, table.concat(var4, str1)))
	end
end

return { Start = function()
	var9 = workspace:WaitForChild("UpgradesFolder")
	task.spawn(function()
		var2 = var11:WaitForChild("Upgrades"):WaitForChild("#buymax")
	end)

	var10 = RaycastParams.new()
	var10.FilterType = Enum.RaycastFilterType.Include
	var10.FilterDescendantsInstances = { var9 }
	var6.InputBegan:Connect(onInputBegan)
	var6.InputEnded:Connect(onInputEnded)
	for k1, v1 in ipairs(tbl1) do
		wireBoard(v1)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.UpgradeVisualsController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Shared
local var3 = game:GetService("Debris")
local var4 = game:GetService("TweenService")
local var5 = require(var2.Remotes)
local var6 = require(var2.Libs.EternityNum)
local var7 = require(var2.Config.Upgrades)
local var8 = require(var2.Util)
local var9 = game:GetService("Players").LocalPlayer
local tbl1 = { p = Color3.fromRGB(190, 157, 24) }
tbl1.s = Color3.fromRGB(75, 75, 75)
tbl1.g = Color3.fromRGB(154, 157, 0)
tbl1.sp = Color3.fromRGB(37, 0, 74)
tbl1.spp = Color3.fromRGB(59, 10, 100)
tbl1.dm = Color3.fromRGB(24, 7, 49)
tbl1.gift = Color3.fromRGB(49, 94, 161)
local tbl2 = { { Name = "darkboard", Highlight = false }, { Name = "starlevel", Highlight = true } }
local tbl3 = {}
local function getCategory(arg1)
	if string.find(arg1, "gift") then
		return "gift"
	end

	if string.find(arg1, "spp") then
		return "spp"
	end

	if string.find(arg1, "sp") then
		return "sp"
	end

	if string.find(arg1, "g") then
		return "g"
	end

	if string.find(arg1, "s") then
		return "s"
	end

	if string.find(arg1, "p") then
		return "p"
	end

	return nil
end

local tbl4 = {}
local var10 = Color3.fromRGB(186, 107, 255)
local function SetDragButtonColor(arg1, arg2, arg3)
	local var2 = arg2.dragTextButton
	if not var2 then
		return
	end

	local var3 = var2:GetAttribute("OriginalColor")
	if arg2.dragHighlight then
		local var4 = if (arg1:GetAttribute("purchaseCount") or 0) <= 7 then var10 else var3
		var2.BackgroundColor3 = var4
	end

	if arg3 and var3 then
		local var8, var9, var11 = var3:ToHSV()
		var2.BackgroundColor3 = Color3.fromHSV(var8, var9, var11 * 0.6)
	end
end

local function SetColor(arg1, arg2)
	local var6
	local var1 = arg1:GetAttribute("max") <= arg1:GetAttribute("purchaseCount")
	for k1, v1 in ipairs(arg2.borders) do
		local var2 = v1:GetAttribute("OriginalColor")
		if var1 then
			if arg2.category then
				v1.Color = tbl1[arg2.category]
			else
				local var3, var4, var5 = var2:ToHSV()
				v1.Color = Color3.fromHSV(var3, var4, var5 * 0.3)
				continue
			end
		else
			v1.Color = var2
		end
	end

	SetDragButtonColor(arg1, arg2, var6)
end

local function SetCost(arg1, arg2)
	local var2 = nil
	local var3 = arg2.boardLabels
	local var4 = var3
	var4 = var4 and var3.Cost
	var2 = if arg1:GetAttribute("max") <= arg1:GetAttribute("purchaseCount") then arg1:GetAttribute("MaxedText") or "Maxed!" else arg1:GetAttribute("CostText")
	if var4 then
		var4.Text = var2
	end

	if not arg2.costText then
		warn("[UpgradeVisuals] no Cost label on kiosk " .. arg2.model.Name)
		return
	end

	arg2.costText.Text = var2
end

local function SetLevel(arg1, arg2)
	local var1 = arg2.model.Name .. " [" .. arg1:GetAttribute("purchaseCount") .. "/" .. arg1:GetAttribute("max") .. "]"
	local var2 = arg1:GetAttribute("DescriptionText")
	local var3 = arg1:GetAttribute("TitleText")
	if arg2.levelText then
		arg2.levelText.Text = var1
	end

	if arg2.descText then
		arg2.descText.Text = var2
	end

	if arg2.titleText then
		arg2.titleText.Text = var3
	end

	local var4 = arg2.boardLabels
	local var5 = var4
	var5 = var5 and var4.Level
	if var5 then
		var5.Text = var1
	end

	var4 = arg2.boardLabels
	var5 = var4
	var5 = var5 and var4.Description
	if var5 then
		var5.Text = var2
	end

	var4 = arg2.boardLabels
	var5 = var4
	var5 = var5 and var4.Title
	if var5 then
		var5.Text = var3
	end
end

local function SetVisibility(arg1, arg2)
	local var1 = arg1:GetAttribute("VisibleIf")
	for k1, v1 in ipairs(arg2.parts) do
		v1.Transparency = if var1 then 0 else 1
		v1.CanCollide = var1
	end

	for k2, v2 in ipairs(arg2.guis) do
		v2.Enabled = var1
	end

	if arg2.dragTextButton then
		if not arg2.dragHighlight then
			arg2.dragTextButton.Visible = var1 == true
		end
	end
end

local tbl5 = {}
local var11 = Color3.fromRGB(105, 238, 105)
local var12 = nil
local var13 = nil
local function isUpgradeAffordable(_, arg2)
	for k1, v1 in pairs(arg2) do
		if typeof(k1) ~= "string" or k1 == "CostText" then
			continue
		end

		if not string.match(k1, "Cost$") then
			continue
		end

		local var2 = var12:FindFirstChild((string.sub(k1, 1, -5)))
		if not var2 then
			return nil
		end

		local success, result = pcall(var8.resolve, v1, var9, arg2)
		if not success then
			return nil
		end

		local success, result = pcall(var6.convert, result)
		local success, result = pcall(var6.convert, var2.Value)
		if not success or (not success) then
			return nil
		end

		if var6.meeq(result, result) then
			continue
		end

		return false
	end

	return true
end

local function sweepAffordability()
	local var2 = var9:FindFirstChild("Upgrades")
	if not var2 or (not var13 or (not var12)) then
		return
	end

	for k1, v1 in ipairs(var2:GetChildren()) do
		local var3 = v1.Name
		local var4 = tbl4[var3]
		local var5 = var13[var3]
		if not var4 or (not var5) then
			continue
		end

		var5.purchaseCount = v1:GetAttribute("purchaseCount") or 0
		local var7 = v1:GetAttribute("max") <= v1:GetAttribute("purchaseCount")
		if v1:GetAttribute("VisibleIf") == true then
			if var7 then
				local var10 = tbl5[var3]
				if not var10 then
					continue
				end

				var10:Destroy()
				tbl5[var3] = nil
			else
				local var15 = isUpgradeAffordable(var3, var5)
				if var15 == true then
					if tbl5[var3] then
					else
						local var17 = var4.model:FindFirstChild("Main")
	if not not var17 then
							local var18 = Instance.new("Highlight")
							var18.Name = "AffordableHighlight"
							var18.FillColor = var11
							var18.FillTransparency = 0.8
							var18.OutlineTransparency = 1
							var18.Parent = var17
							tbl5[var3] = var18
							continue
						end
					end
				else
					if var15 ~= false then
						continue
					end

					local var19 = tbl5[var3]
					if not var19 then
						continue
					end

					var19:Destroy()
					tbl5[var3] = nil
				end
			end
		end
	end
end

local var14 = TweenInfo.new(0.5)
local function playBorderPulse(arg1)
	local var1 = arg1.Border:Clone()
	var1.Parent = workspace
	var4:Create(var1, var14, {
		Transparency = 1,
		Size = Vector3.new(arg1.Border.Size.X * 1.25, arg1.Border.Size.Y * 0.99, arg1.Border.Size.Z * 1.25),
	}):Play()

	var3:AddItem(var1, 3)
end

local function playFullBurst(arg1)
	playBorderPulse(arg1)
	for k1, v1 in ipairs(var1.UpgradeParticles:GetChildren()) do
		local var2 = v1:Clone()
		var2.Parent = arg1.Main
		var3:AddItem(var2, 10)
	end

	arg1.Main.ParticleEmitter:Emit(25)
	arg1.Main.ParticleEmitter1:Emit(25)
	arg1.Main.LineParticle:Emit(50)
end

local var15 = nil
local function buildCache(arg1)
	local tbl1 = { model = arg1, borders = {} }
	for k1, v1 in ipairs(arg1:GetChildren()) do
		local var1
		if v1.Name == "Border" or v1.Name == "Wire" then
			v1:SetAttribute("OriginalColor", v1.Color)
			var1 = tbl1.borders
			table.insert(var1, v1)
		end
	end

	local var2 = arg1:FindFirstChild("Main")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("SurfaceGui")
	if var3 then
		tbl1.costText = var3:FindFirstChild("Cost")
		tbl1.levelText = var3:FindFirstChild("Level")
		tbl1.descText = var3:FindFirstChild("Description")
		tbl1.titleText = var3:FindFirstChild("Title")
	end

	for k2, v2 in ipairs(tbl2) do
		local var4 = tbl3[v2.Name]
		local var5 = var4
		var5 = var5 and var4:FindFirstChild(arg1.Name)
		local var6 = var5
		var6 = var6 and var5:FindFirstChild("TextButton")
		if not var6 then
			continue
		end

		if not var6:IsA("TextButton") then
			continue
		end

		if not var6:GetAttribute("OriginalColor") then
			var6:SetAttribute("OriginalColor", var6.BackgroundColor3)
		end

		tbl1.dragTextButton = var6
		tbl1.dragHighlight = v2.Highlight
		local tbl5 = { Cost = var6:FindFirstChild("Cost") }
		tbl5.Level = var6:FindFirstChild("Level")
		tbl5.Description = var6:FindFirstChild("Description")
		tbl5.Title = var6:FindFirstChild("Title")
		tbl1.boardLabels = tbl5
		break
	end

	tbl1.category = getCategory(arg1.Name)
	tbl1.parts = {}
	tbl1.guis = {}
	for k3, v3 in ipairs(arg1:GetDescendants()) do
		if v3:IsA("BasePart") then
			table.insert(tbl1.parts, v3)
		else
			if not v3:IsA("SurfaceGui") then
				continue
			end

			table.insert(tbl1.guis, v3)
		end
	end

	tbl4[arg1.Name] = tbl1
	return tbl1
end

local function hookUpgrade(arg1)
	local var2 = tbl4[arg1.Name]
	if not var2 then
		warn("[UpgradeVisuals] no kiosk model cached for " .. arg1.Name)
		return
	end

	SetColor(arg1, var2)
	SetCost(arg1, var2)
	SetLevel(arg1, var2)
	SetVisibility(arg1, var2)
	arg1:GetAttributeChangedSignal("purchaseCount"):Connect(function()
		local var1 = arg1
		local var3 = var2
		SetColor(var1, var3)
		SetCost(var1, var3)
		SetLevel(var1, var3)
		SetVisibility(var1, var3)
	end)

	arg1:GetAttributeChangedSignal("VisibleIf"):Connect(function()
		SetVisibility(arg1, var2)
	end)
end

local function onUpdateUpgrade(arg1, arg2)
	task.spawn(function()
		if arg2 == "true" then
			local var3 = var9.Upgrades:FindFirstChild(arg1.Name)
			if not (var3 and 0 < var3:GetAttribute("purchaseCount")) then
				return
			end

			if 0 >= var3:GetAttribute("purchaseCount") then
				return
			end

			playFullBurst(arg1)
			return
		end

		if arg2 == "onlyborder" then
			playBorderPulse(arg1)
		end
	end)

	if arg2 == "onlyborder" then
		return
	end

	local var3 = tbl4[arg1.Name]
	local var4 = var9.Upgrades:FindFirstChild(arg1.Name)
	if var3 and var4 then
		SetColor(var4, var3)
		SetCost(var4, var3)
		SetLevel(var4, var3)
		SetVisibility(var4, var3)
	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var15 = workspace:WaitForChild("UpgradesFolder")
	for k1, v1 in ipairs(tbl2) do
		tbl3[v1.Name] = workspace:WaitForChild(v1.Name):WaitForChild("MainPart"):WaitForChild("SurfaceGui"):WaitForChild("ViewFrame"):WaitForChild("DragFrame")
	end

	for k2, v2 in ipairs(var15:GetChildren()) do
		buildCache(v2)
	end

	var15.ChildAdded:Connect(buildCache)
	local var1 = var9:WaitForChild("Upgrades")
	for k3, v3 in ipairs(var1:GetChildren()) do
		hookUpgrade(v3)
	end

	var1.ChildAdded:Connect(hookUpgrade)
	var5.UpdateUpgrade.OnClientEvent:Connect(onUpdateUpgrade)
	task.spawn(function()
		while true do
			if not task.wait(3) then
				break
			end

			local var1 = var9:FindFirstChild("Upgrades")
			if not var1 then
				continue
			end

			for k1, v1 in ipairs(var1:GetChildren()) do
				local var2 = v1:GetAttribute("MaxedText")
				if not var2 or var2 == "Maxed!" then
					continue
				end

				local var3 = tbl4[v1.Name]
				if not var3 then
					continue
				end

				SetCost(v1, var3)
			end
		end
	end)

	var13 = var7.GetPlayerTable(var9)
	var12 = var9:WaitForChild("Values")
	task.spawn(function()
		while task.wait(0.25) do
			sweepAffordability()
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.RevealController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = require(var1.Libs.EternityNum)
local var4 = require(var1.Util)
local var5 = require(var1.Config.Reveals)
local var6 = require(var1.Config.Portals)
local var7 = game:GetService("Players").LocalPlayer
local var8 = nil
local function gateSatisfied(arg1)
	local var1 = arg1
	local var3 = var2
	local var5 = var8
	return var4.gateSatisfied(var1, var3, var5)
end

local function captureOriginal(arg1)
	if arg1:GetAttribute("OrigCaptured") then
		return
	end

	if arg1:IsA("BasePart") then
		arg1:SetAttribute("OrigTransparency", arg1.Transparency)
		arg1:SetAttribute("OrigCanCollide", arg1.CanCollide)
		arg1:SetAttribute("OrigCanTouch", arg1.CanTouch)
		arg1:SetAttribute("OrigCanQuery", arg1.CanQuery)
	else
		if arg1:IsA("Decal") then
			arg1:SetAttribute("OrigTransparency", arg1.Transparency)
		else
			if arg1:IsA("BillboardGui") or arg1:IsA("SurfaceGui") then
				arg1:SetAttribute("OrigEnabled", arg1.Enabled)
			else
				if arg1:IsA("SelectionBox") then
					arg1:SetAttribute("OrigVisible", arg1.Visible)
				end
			end
		end
	end

	arg1:SetAttribute("OrigCaptured", true)
end

local function applyRegionVisibility(arg1, arg2)
	captureOriginal(arg1)
	if arg1:IsA("BasePart") then
		if arg2 then
			local var1 = arg1:GetAttribute("OrigTransparency") or 0
			arg1.Transparency = var1
			var1 = arg1:GetAttribute("OrigCanCollide")
			arg1.CanCollide = if var1 == nil then true else var1
			local var3 = arg1:GetAttribute("OrigCanTouch")
			arg1.CanTouch = if var3 == nil then true else var3
			local var5 = arg1:GetAttribute("OrigCanQuery")
			arg1.CanQuery = if var5 == nil then true else var5
			return
		end

		arg1.Transparency = 1
		arg1.CanCollide = false
		arg1.CanTouch = false
		arg1.CanQuery = false
		return
	end

	if arg1:IsA("Decal") then
		local var6
		if arg2 then
			var6 = arg1:GetAttribute("OrigTransparency")
			if not var6 then
				var6 = 0
			end
		else
			var6 = 1
		end

		arg1.Transparency = var6
		return
	end

	if not arg1:IsA("BillboardGui") then
		if arg1:IsA("SurfaceGui") then
			if arg2 then
				var6 = arg1:GetAttribute("OrigEnabled")
				local bool5 = true
				if var6 ~= nil then
					bool5 = var6
				end

				arg1.Enabled = bool5
				return
			end

			arg1.Enabled = false
			return
		end
	end

	if arg1:IsA("SelectionBox") then
		if arg2 then
			var6 = arg1:GetAttribute("OrigVisible")
			local bool9 = true
			if var6 ~= nil then
				bool9 = var6
			end

			arg1.Visible = bool9
			return
		end

		arg1.Visible = false
	end
end

local tbl1 = {
	hasPurchased = function(arg1)
		local var3 = var2:FindFirstChild(arg1)
		local bool1 = false
		if var3 ~= nil then
			bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
		end

		return bool1
	end,
	currencyAbove0 = function(arg1)
		local var2 = var8:FindFirstChild(arg1)
		if not var2 then
			return false
		end

		local var4 = var3.convert(var2.Value)
		local num1 = 0
		return var3.me(var4, num1)
	end,
}

local function findModels(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(workspace:GetChildren()) do
		if v1.Name ~= arg1 then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end

local tbl2 = {}
local function refreshGroup(arg1, arg2)
	local var1 = arg1.Requirements(tbl1)
	for k1, v1 in ipairs(arg1.Models) do
		local var2 = findModels(v1)
		if #var2 == 0 then
			warn("[RevealController] model not found in workspace: " .. v1)
		end

		for k2, v2 in ipairs(var2) do
			arg2(v2, var1, arg1)
		end
	end
end

local function refreshAll()
	for k1, v1 in ipairs(tbl2) do
		for k2, v2 in ipairs(v1.groups) do
			refreshGroup(v2, v1.apply)
		end
	end
end

local function setRegionVisible(arg1, arg2)
	applyRegionVisibility(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		applyRegionVisibility(v1, arg2)
	end
end

local function toGroup(arg1)
	local tbl1 = {}
	local tbl2 = {}
	var4.collectGateWatches(arg1.Gate, tbl1, tbl2)
	return {
		Name = arg1.Model,
		Models = { arg1.Model },
		Part = arg1.Part,
		ChildrenNamed = arg1.ChildrenNamed,
		ClassIs = arg1.ClassIs,
		TogglePart = arg1.TogglePart,
		AlsoToggleSurfaceGui = arg1.AlsoToggleSurfaceGui,
		Hiding = arg1.Hiding,
		WatchUpgrades = tbl1,
		WatchCurrencies = tbl2,
		Requirements = function()
			local var1 = arg1.Gate
			return gateSatisfied(var1)
		end,
	}
end

local function applyBoardVisibility(arg1, arg2)
	local var1 = if arg2 then 0 else 1
	if arg1:IsA("BasePart") then
		arg1.Transparency = var1
	else
		if arg1:IsA("SurfaceGui") or (arg1:IsA("BillboardGui") or arg1:IsA("ScreenGui")) then
			arg1.Enabled = arg2
		end
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("BasePart") then
			v1.Transparency = var1
		else
			if v1:IsA("Decal") or v1:IsA("Texture") then
				v1.Transparency = var1
			elseif v1:IsA("SurfaceGui") or (v1:IsA("BillboardGui") or v1:IsA("ScreenGui")) then
				v1.Enabled = arg2
			end
		end
	end
end

local function applyKeycapVisibility(arg1, arg2, arg3)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= arg3.ChildrenNamed then
			continue
		end

		if not v1:IsA(arg3.ClassIs) then
			continue
		end

		v1.Transparency = if arg2 then 0 else 1
		v1.CanTouch = arg2
		local var1 = v1:FindFirstChildWhichIsA("SurfaceGui")
		if not var1 then
			continue
		end

		var1.Enabled = arg2
	end
end

local function applyInvertedVisibility(arg1, arg2, arg3)
	if arg3.TogglePart ~= false then
		if arg1:IsA("BasePart") then
			arg1.Transparency = if arg2 then 0 else 1
			arg1.CanCollide = not arg2
			arg1.CanTouch = arg2
			arg1.CanQuery = arg2
		end
	end

	if arg3.AlsoToggleSurfaceGui then
		local var1 = arg1:FindFirstChildWhichIsA("SurfaceGui")
		var1 = var1 or arg1:FindFirstChildWhichIsA("BillboardGui")
		if var1 then
			var1.Enabled = arg2
		end
	end
end

local function applyPortalVisibility(arg1, arg2, arg3)
	local var2 = arg1:FindFirstChild(arg3.Part)
	if not var2 then
		local var3 = arg1.Name
		local var4 = tostring(arg3.Part)
		warn(("[RevealController] portal %s has no part %s"):format(var3, var4))
		return
	end

	var2.Transparency = if arg2 then 0 else 1
	var2.CanCollide = arg2
	var2.CanTouch = arg2
	var2.CanQuery = arg2
	for k1, v1 in ipairs(var2:GetChildren()) do
		if v1:IsA("SurfaceGui") or v1:IsA("BillboardGui") then
			v1.Enabled = arg2
		end
	end
end

local function connectWatches()
	local tbl1 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(tbl2) do
		for k2, v2 in ipairs(v1.groups) do
			local var1 = v2.WatchUpgrades
			for k3, v3 in ipairs(var1 or {}) do
				tbl1[v3] = true
			end

			if v2.WatchCurrency then
				tbl3[v2.WatchCurrency] = true
			end

			var1 = v2.WatchCurrencies
			for k4, v4 in ipairs(var1 or {}) do
				tbl3[v4] = true
			end
		end
	end

	for k5 in pairs(tbl1) do
		local var4 = var2:WaitForChild(k5, 5)
		if var4 then
			var4:GetAttributeChangedSignal("purchaseCount"):Connect(refreshAll)
		else
			warn("[RevealController] watched upgrade never appeared: " .. k5)
		end
	end

	for k6 in pairs(tbl3) do
		local var6 = var8:WaitForChild(k6, 5)
		if var6 then
			var6:GetPropertyChangedSignal("Value"):Connect(refreshAll)
		else
			warn("[RevealController] watched currency never appeared: " .. k6)
		end
	end
end

local function startFailsafe()
	for k1, v1 in ipairs(tbl2) do
		task.spawn(function()
			while task.wait(v1.failsafeInterval) do
				for k1, v2 in ipairs(v1.groups) do
					refreshGroup(v2, v1.apply)
				end
			end
		end)

	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var2 = var7:WaitForChild("Upgrades")
	var8 = var7:WaitForChild("Values")
	table.insert(tbl2, {
		groups = var5.BaseplateGroups,
		apply = setRegionVisible,
		failsafeInterval = var5.RegionFailsafePollInterval,
	})

	local function sectionFrom(arg1, arg2)
		local tbl1 = {}
		for k1, v1 in ipairs(arg1) do
			if v1.Enabled == false then
				continue
			end

			table.insert(tbl1, (toGroup(v1)))
		end

		table.insert(tbl2, {
			groups = tbl1,
			apply = function(arg1, arg2, arg3)
				if arg3.Hiding == false and (not arg2) then
					return
				end

				arg2(arg1, arg2, arg3)
			end,
			failsafeInterval = var5.FailsafePollInterval,
		})
	end

	sectionFrom(var5.Boards, applyBoardVisibility)
	sectionFrom(var5.Keycaps, applyKeycapVisibility)
	sectionFrom(var5.Displays, applyInvertedVisibility)
	if var5.UsePortalConfig then
		local tbl1 = {}
		for k1, v1 in ipairs(var6.List) do
			if not v1.Gate then
				continue
			end

			table.insert(tbl1, { Model = v1.Model, Part = v1.Part, Gate = v1.Gate })
		end

		sectionFrom(tbl1, applyPortalVisibility)
	end

	refreshAll()
	connectWatches()
	startFailsafe()
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.WorldDisplayController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.Libs.EternityNum)
local var3 = require(var1.Formulas)
local var4 = require(var1.Config.GameConfig)
local var5 = game:GetService("Players").LocalPlayer
local str1 = "#6g"
local str2 = "#10g"
local str3 = "#13dm"
local str4 = "#17g"
local var6 = nil
local var7 = nil
local tbl1 = {
	{ Model = "PrestigeDisplay", Stat = "Prestige", Suffix = " PP$" },
	{ Model = "SteelDisplay", Stat = "Steel", Suffix = " Steel" },
	{ Model = "KeycapDisplay", Stat = "Keycap", Suffix = " Keycap" },
	{ Model = "GammaDisplay", Stat = "Gamma", Suffix = " \206\179" },
	{ Model = "SpacePrestigeDisplay", Stat = "SpacePrestige", Suffix = " SPP$" },
}

local tbl2 = {
	{ Model = "PrestigeDisplay", Upgrade = "#12", Stat = "Prestige" },
	{ Model = "GammaDisplay", Upgrade = "#B0", Stat = "Gamma" },
	{ Model = "SteelDisplay", Upgrade = "#8g", Stat = "Steel" },
	{ Model = "SpacePrestigeButton", Upgrade = "#16sp", Stat = "SpacePrestige" },
	{ Model = "SpacePrestigeDisplay", Upgrade = "#16sp", Stat = "SpacePrestige" },
	{ Model = "SteelButton", Upgrade = "#8g", Stat = "Steel" },
	{ Model = "PrestigeButton", Upgrade = "#12", Stat = "Prestige" },
}

local tbl3 = {
	{
		Stat = "Prestige",
		Requirement = function()
			return true
		end,
	},
	{
		Stat = "XP",
		Requirement = function(_, arg2)
			local var2 = arg2:FindFirstChild(str1)
			local bool1 = false
			if var2 ~= nil then
				bool1 = 0 < (var2:GetAttribute("purchaseCount") or 0)
			end

			return bool1
		end,
	},
	{
		Stat = "Steel",
		Requirement = function(_, arg2)
			local var2 = arg2:FindFirstChild(str2)
			local bool1 = false
			if var2 ~= nil then
				bool1 = 0 < (var2:GetAttribute("purchaseCount") or 0)
			end

			return bool1
		end,
	},
	{
		Stat = "DarkMatter",
		Requirement = function(_, arg2)
			local var2 = arg2:FindFirstChild(str3)
			local bool1 = false
			if var2 ~= nil then
				bool1 = 0 < (var2:GetAttribute("purchaseCount") or 0)
			end

			return bool1
		end,
	},
	{
		Stat = "SpacePrestige",
		Requirement = function(arg1)
			local var1 = arg1.Loops.Value
			local num1 = 4
			return var2.meeq(var1, num1)
		end,
	},
	{
		Stat = "Power",
		Requirement = function(_, arg2)
			local var2 = arg2:FindFirstChild(str4)
			local bool1 = false
			if var2 ~= nil then
				bool1 = 0 < (var2:GetAttribute("purchaseCount") or 0)
			end

			return bool1
		end,
	},
}

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var6 = var5:WaitForChild("Values")
	var7 = var5:WaitForChild("Upgrades")
	local str1 = "SpacePoints"
	for k1, v1 in ipairs({
		"Points",
		str1,
		"Prestige",
		"Steel",
		"Keycap",
		"Gamma",
		"SpacePrestige",
		"Power",
		"StarLevels",
		"Loops",
	}) do

		local var1 = v1
		var6:WaitForChild(var1)
	end

	local var8 = workspace:WaitForChild("PointsDisplay"):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("PointsText")
	local var9 = workspace:WaitForChild("SPDisplay"):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("PointsText")
	for k2, v2 in ipairs(tbl1) do
		v2.Label = workspace:WaitForChild(v2.Model):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("PointsText")
	end

	local var10 = workspace:WaitForChild("powerbox"):WaitForChild("powerbox"):WaitForChild("SurfaceGui"):WaitForChild("BG")
	local var11 = var10:WaitForChild("Boosts")
	local var12 = workspace:WaitForChild("PrestigeButton"):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("Cost")
	local var13 = workspace:WaitForChild("SteelButton"):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("ResetThing")
	local var14 = workspace:WaitForChild("SpacePrestigeButton"):WaitForChild("Main"):WaitForChild("SurfaceGui"):WaitForChild("ResetThing")
	local var15 = var10:WaitForChild("Amount")
	local var16 = var10:WaitForChild("Gain")
	local var17 = var11:WaitForChild("Template")
	var17.Visible = false
	local tbl4 = {}
	for k3, v3 in ipairs(tbl2) do
		local var18 = workspace:WaitForChild(v3.Model)
		v3.Parts = {}
		for k4, v4 in ipairs(var18:GetChildren()) do
			if not v4:IsA("BasePart") then
				continue
			end

			table.insert(v3.Parts, v4)
		end

		v3.UpgradeInstance = var7:WaitForChild(v3.Upgrade)
	end

	local var19 = var4.Thresholds
	while task.wait(0.1) do
		var8.Text = var2.short(var6.Points.Value) .. " P$ (" .. var2.short(var6.Points:GetAttribute("TotalBoost") or 0) .. " P$/s)"
		local str2 = " SP$/s)"
		var9.Text = var2.short(var6.SpacePoints.Value) .. " SP$ (" .. var2.short(var6.SpacePoints:GetAttribute("TotalBoost") or 0) .. str2
		for k5, v5 in ipairs(tbl1) do
			v5.Label.Text = var2.short(var6[v5.Stat].Value) .. v5.Suffix
		end

		local var20 = var6.Points.Value
		local var21 = var6.Prestige:GetAttribute("TotalBoost") or 0
		local var22 = var20
		local var23 = var2.meeq(var20, var19.PrestigePoints) and var2.short(var20) .. " P$ -> " .. var2.short(var3.PrestigeGain(var21, var22)) .. " PP$" or "Reach 1Qn P$ first!"
		var12.Text = var23
		var23 = var6.Power.Value
		var22 = var6.Steel:GetAttribute("TotalBoost") or 0
		local var24 = var23
		local var25 = var2.meeq(var23, var19.SteelPower) and var2.short(var23) .. " Power -> " .. var2.short(var3.SteelGain(var22, var24)) .. " Steel" or "Get 1T Power first!"
		var13.Text = var25
		var25 = var6.StarLevels.Value
		var24 = var6.SpacePrestige:GetAttribute("TotalBoost") or 0
		local var26 = var25
		local var27 = var2.meeq(var25, var19.SpacePrestigeStars) and var2.short(var25) .. " Star Levels -> " .. var2.short(var3.SpacePrestigeGain(var24, var26)) .. " SPP$" or "Reach Star Level 30 first!"
		var14.Text = var27
		var21 = var23
		var15.Text = ([[<font size="8" color="#fff">You have</font> %s Power]]):format(var2.short(var21))
		var22 = var6.Power:GetAttribute("TotalBoost")
		var21 = "/sec)"
		var16.Text = "(+" .. var2.short(var22 or 0) .. var21
		for k6, v6 in ipairs(tbl3) do
			var24 = v6.Requirement(var6, var7)
			var26 = tbl4[v6.Stat]
			if var24 and (not var26) then
				var26 = var17:Clone()
				var26.Name = v6.Stat
				var26.Visible = true
				var26.LayoutOrder = k6
				var26.Parent = var11
				tbl4[v6.Stat] = var26
			elseif not var24 and var26 then
				var26:Destroy()
				tbl4[v6.Stat] = nil
			end

			if not var26 then
				continue
			end

			local var29 = v6.Stat
			local var30 = var3.PowerLogBoost(var23, v6.Stat, var5)
			if var29 == "Prestige" then
				var29 = "PP$"
			elseif var29 == "DarkMatter" then
				var29 = "DM$"
			elseif var29 == "SpacePrestige" then
				var29 = "SPP$"
			end

			local str3 = "x"
			var26.Text = str3 .. var2.short(var30) .. " " .. var29
		end

		for k7, v7 in ipairs(tbl2) do
			var24 = true
			if 0 >= (v7.UpgradeInstance:GetAttribute("purchaseCount") or 0) then
				var24 = var2.me(var6[v7.Stat].Value, 0)
			end

			for k8, v8 in ipairs(v7.Parts) do
				v8.Transparency = if var24 then 0 else 1
				v8.CanCollide = var24
				v8.CanTouch = var24
				v8.CanQuery = var24
				local var31 = v8:FindFirstChild("SurfaceGui")
				if not var31 then
					continue
				end

				var31.Enabled = var24
			end
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.SkillTreeController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = nil
local var4 = nil
local var5 = nil
local var6 = require(var1.Libs.EternityNum)
local var7 = nil
local var8 = game:GetService("Players").LocalPlayer
local var9 = nil
local var10 = require(var1.Libs.DraggableObject)
local var11 = TweenInfo.new(0.5)
local function wireNode(arg1)
	local var1 = arg1:FindFirstChild("MainFrame")
	local var4 = var1
	var4 = var4 and var1:FindFirstChild("TextButton")
	if not var4 then
		return nil
	end

	local var6 = var2:FindFirstChild(arg1.Name)
	if not var6 then
		warn("[SkillTree] no upgrade behind node " .. arg1.Name)
		return nil
	end

	var4.MouseButton1Click:Connect(function()
		var3.Value = arg1.Name
	end)

	local var7 = var4:FindFirstChild("TextLabel")
	local function refresh()
		if var7 then
			var7.Text = tostring(var6:GetAttribute("purchaseCount") or 0)
			local var2 = var1:FindFirstChild("DiamondOutline")
			var2.ImageColor3 = Color3.fromHSV(0, 0, 1 - (var6:GetAttribute("purchaseCount") or 1) / (var6:GetAttribute("max") or 1))
		end

		local var3 = var6:GetAttribute("VisibleIf") == true
		var1.Visible = var3
	end

	var6:GetAttributeChangedSignal("purchaseCount"):Connect(refresh)
	var6:GetAttributeChangedSignal("VisibleIf"):Connect(refresh)
	refresh()
	return refresh
end

local function updatePanel()
	local var5 = var2:FindFirstChild(var3.Value)
	if not var5 then
		return
	end

	var4.Level.Text = var5.Name .. " [" .. var5:GetAttribute("purchaseCount") .. "/" .. var5:GetAttribute("max") .. "]"
	var4.Description.Text = var5:GetAttribute("DescriptionText")
	var4.BuyButton.Text = var5:GetAttribute("CostText")
	if var5:GetAttribute("max") <= var5:GetAttribute("purchaseCount") then
		var4.BuyButton.Text = var5:GetAttribute("MaxedText") or "Maxed!"
	end
end

local var12 = require(var1.Remotes)
local function updateNovaAmount()
	var5.Text = "[ " .. var6.short(var7.Nova.Value) .. "/" .. var6.short(var7.MaxNova.Value) .. " NV$ ]"
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var2 = var8:WaitForChild("Upgrades")
	var7 = var8:WaitForChild("Values")
	local var1 = workspace:WaitForChild("supernovaskilltree"):WaitForChild("MainPart"):WaitForChild("SurfaceGui")
	var9 = var1:WaitForChild("ViewFrame"):WaitForChild("DragFrame")
	var4 = var1:WaitForChild("UpgradeFrame"):WaitForChild("SubUpgradeFrame")
	var3 = var4:WaitForChild("CurrentUpgrade")
	local var13 = var1:WaitForChild("BottomRightFrame")
	var5 = var13:WaitForChild("NovaAmount")
	local var14 = var10.new(var9)
	var14:Enable()
	var14:SetTweenInfo(var11)
	local tbl1 = {}
	for k1, v1 in ipairs(var9:GetChildren()) do
		if not v1:IsA("Folder") then
			continue
		end

		local var15 = wireNode(v1)
		if not var15 then
			continue
		end

		table.insert(tbl1, var15)
	end

	var3.Changed:Connect(updatePanel)
	var4.BuyButton.MouseButton1Click:Connect(function()
		local var4 = workspace.UpgradesFolder:FindFirstChild(var3.Value)
		if not var4 or (not var2:FindFirstChild(var3.Value)) then
			return
		end

		var12.BuyOneEvent:FireServer(var4)
		updatePanel()
	end)

	var13.RespecButton.MouseButton1Click:Connect(function()
		var12.SupernovaRespecEvent:FireServer()
		updatePanel()
	end)

	var7.Nova.Changed:Connect(updateNovaAmount)
	var7.MaxNova.Changed:Connect(updateNovaAmount)
	var5.Text = "[ " .. var6.short(var7.Nova.Value) .. "/" .. var6.short(var7.MaxNova.Value) .. " NV$ ]"
	updatePanel()
	task.spawn(function()
		while task.wait(2) do
			updatePanel()
			local str1 = "/"
			var5.Text = "[ " .. var6.short(var7.Nova.Value) .. str1 .. var6.short(var7.MaxNova.Value) .. " NV$ ]"
			for k1, v1 in ipairs(tbl1) do
				v1()
			end
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.StarLevelController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = game:GetService("RunService")
local var4 = game:GetService("TweenService")
local var5 = require(var1.Libs.EternityNum)
local var6 = require(var1.Libs.DraggableObject)
local var7 = require(var1.Formulas)
local var8 = require(var1.Remotes)
local var9 = game:GetService("Players").LocalPlayer
local var10 = require(var1.Config.Upgrades)
local var11 = TweenInfo.new(0.5)
local var12 = TweenInfo.new(0.2)
local var13 = TweenInfo.new(0.15)
local var14 = Color3.fromRGB(95, 72, 165)
local var15 = Color3.fromRGB(145, 111, 255)
local var16 = TweenInfo.new(0.1)
local var17 = Color3.fromRGB(91, 91, 91)
local var18 = Color3.fromRGB(147, 147, 147)
local bool1 = false
local var19 = nil
local tbl1 = {
	Frame = { "BackgroundTransparency" },
	TextButton = { "BackgroundTransparency", "TextTransparency" },
	TextLabel = { "TextTransparency" },
	ImageLabel = { "ImageTransparency" },
	ImageButton = { "ImageTransparency", "BackgroundTransparency" },
	UIStroke = { "Transparency" },
	UIShadow = { "Transparency" },
}

local var20 = nil
local tbl2 = {}
local function captureTransparency(arg1)
	local tbl2 = {}
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		local var1 = tbl1[v1.ClassName]
		if not var1 then
			continue
		end

		for k2, v2 in ipairs(var1) do
			table.insert(tbl2, { instance = v1, prop = v2, base = v1[v2] })
		end
	end

	return tbl2
end

local var21 = nil
local function pulseBar()
	if bool1 then
		return
	end

	bool1 = true
	local var1 = var19.BarHolder.BarHandler.BarHandler
	var4:Create(var1, var16, { BackgroundColor3 = var15 }):Play()
	task.delay(var16.Time, function()
		var4:Create(var1, var16, { BackgroundColor3 = var14 }):Play()
	end)

	task.delay(0.2, function()
		bool1 = false
	end)
end

local function setupHoverLighten(arg1)
	local var1 = arg1.BackgroundColor3
	local var2 = var1:Lerp(Color3.new(0.05, 0.05, 0.05), 0.35)
	arg1.MouseEnter:Connect(function()
		var4:Create(arg1, var13, { BackgroundColor3 = var2 }):Play()
	end)

	arg1.MouseLeave:Connect(function()
		var4:Create(arg1, var13, { BackgroundColor3 = var1 }):Play()
	end)

	task.delay(10, function()
		arg1.BackgroundColor3 = var1
	end)
end

local function setupLevelIconHover(arg1)
	arg1.ImageColor3 = var17
	arg1.MouseEnter:Connect(function()
		var4:Create(arg1, var13, { ImageColor3 = var18 }):Play()
	end)

	arg1.MouseLeave:Connect(function()
		var4:Create(arg1, var13, { ImageColor3 = var17 }):Play()
	end)
end

local function setupStarUpgradeVisibility(arg1)
	var20 = var10.GetPlayerTable(var9)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("Folder") then
			continue
		end

		local var1 = var20[v1.Name]
		if not var1 then
			continue
		end

		table.insert(tbl2, { upgrade = var1, entries = captureTransparency(v1), visible = true })
	end
end

local function startAutoClickers()
	task.spawn(function()
		while true do
			if not task.wait(0.5) then
				break
			end

			local var3 = var2:FindFirstChild("#3spp")
			local bool1 = false
			if var3 ~= nil then
				bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
			end

			if not bool1 then
				continue
			end

			var3 = var2:FindFirstChild("#6spp")
			bool1 = false
			if var3 ~= nil then
				bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
			end

			if bool1 then
				continue
			end

			var8.StarExperienceGain:FireServer()
		end
	end)

	task.spawn(function()
		while true do
			if not task.wait(0.1) then
				break
			end

			local var3 = var2:FindFirstChild("#6spp")
			local bool1 = false
			if var3 ~= nil then
				bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
			end

			if not bool1 then
				continue
			end

			var3 = var2:FindFirstChild("#8spp")
			bool1 = false
			if var3 ~= nil then
				bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
			end

			if bool1 then
				continue
			end

			var8.StarExperienceGain:FireServer()
		end
	end)

	var3.Heartbeat:Connect(function(arg1)
		local var3 = var2:FindFirstChild("#8spp")
		local bool1 = false
		if var3 ~= nil then
			bool1 = 0 < (var3:GetAttribute("purchaseCount") or 0)
		end

		if bool1 then
			var8.StarExperienceGain:FireServer(arg1 * 1000)
		end
	end)
end

local function refreshLabels()
	local var1 = var21.StarLevels.Value
	local var2 = var1
	var19.BarHolder.BarHandler.XPLabel.Text = var5.short(var21.StarXP.Value) .. "/" .. var5.short(var7.StarXPRequirement(var2)) .. " Star XP"
	local var3 = var1
	var19.LevelLabel.Text = math.round((var5.toNumber(var5.convert(var3))))
	var2 = "TotalBoost"
	var19.StarXPButton.TextLabel.Text = "+" .. var5.short(var21.StarXP:GetAttribute(var2)) .. " Star XP"
	local num1 = 3
	var2 = var1
	var19.SpacePointsLabel.Text = "Boosts SP$ by x" .. var5.short(var5.pow(num1, var2))
end

local function updateBar()
	local var1 = var21.StarXP.Value
	local var2 = var7.StarXPRequirement(var21.StarLevels.Value)
	local var3 = var5.toNumber(var5.div(var1, var2))
	local var6 = math.clamp(var3, 0, 1)
	var4:Create(var19.BarHolder.BarHandler.BarHandler, var12, { Size = UDim2.fromScale(var6, 1) }):Play()
end

local function updateStarUpgradeVisibility()
	for k1, v1 in ipairs(tbl2) do
		local var1 = if v1.upgrade.VisibleIf(var20, var9) then true else false
		if var1 == v1.visible then
			continue
		end

		v1.visible = var1
		for k2, v2 in ipairs(v1.entries) do
			v2.instance[v2.prop] = var1 and v2.base or 1
		end
	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var21 = var9:WaitForChild("Values")
	var2 = var9:WaitForChild("Upgrades")
	local var1 = workspace:WaitForChild("starlevel"):WaitForChild("MainPart"):WaitForChild("SurfaceGui")
	var19 = var1:WaitForChild("StarLevelFrame")
	var21.StarLevels:GetPropertyChangedSignal("Value"):Connect(pulseBar)
	setupHoverLighten(var19.StarXPButton)
	setupLevelIconHover(var19.LevelLabel.ImageLabel.ImageLabel)
	setupStarUpgradeVisibility((var1:WaitForChild("ViewFrame"):WaitForChild("DragFrame")))
	local str1 = "DragFrame"
	local var3 = var6.new(var1:WaitForChild("ViewFrame"):WaitForChild(str1))
	var3:Enable()
	var3:SetTweenInfo(var11)
	local bool1 = false
	var19.StarXPButton.MouseButton1Click:Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		var8.StarExperienceGain:FireServer()
		task.delay(0.1, function()
			bool1 = false
		end)
	end)

	startAutoClickers()
	refreshLabels()
	task.spawn(function()
		while task.wait(0.1) do
			refreshLabels()
			updateBar()
			updateStarUpgradeVisibility()
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.SupernovaBoardController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = nil
local var4 = require(var1.Libs.EternityNum)
local var5 = require(var1.Formulas)
local var6 = game:GetService("Players").LocalPlayer
local var7 = nil
local var8 = require(var1.Config.GameConfig)
local var9 = nil
local var10 = game:GetService("TweenService")
local var11 = TweenInfo.new(0.67, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
local var12 = require(var1.Remotes)
local function refreshBonuses()
	local var1 = var2.SupernovaTier.Value
	local var7 = var1
	local var8 = var6
	local var9 = var4.short(var5.SupernovaCurrencyMultiplier(var7, var8))
	local var10 = var1
	var8 = var4.short(var5.SupernovaPowerMultiplier(var10))
	local var11 = var1
	local var12 = var4.short(var5.SupernovaBaseGain(var11))
	local var13 = var1
	local var14 = var4.short(var5.SupernovaGainExponent(var13))
	local var15 = var1
	local var16 = var6
	var3.Text = "" .. "x" .. var9 .. [[ all currencies before Supernova (except Loops)
]] .. "x" .. var8 .. [[ Power
]] .. "+" .. var12 .. [[ P$, SP$, DM$ base gain
]] .. "^" .. var14 .. [[ PP$, Steel, SPP$ gain
]] .. "+" .. var4.short(var5.SupernovaTierToNova(var15, var16)) .. " Nova (NV$)"
end

local function refreshButtonText(arg1)
	if var4.meeq(var2.Loops.Value, var8.Thresholds.SupernovaLoops) then
		arg1.Text = "Supernova! (+" .. var4.short(var2.SupernovaTier:GetAttribute("TotalBoost") or 0) .. " Supernova Tier)"
		return
	end

	arg1.Text = "Supernova! (Req: " .. var4.short(var8.Thresholds.SupernovaLoops) .. " Loops)"
end

local function spinStar()
	var9.Rotation = 0
	var7.Rotation = 0
	var10:Create(var9, var11, { Rotation = 180 }):Play()
	var10:Create(var7, var11, { Rotation = -180 }):Play()
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var2 = var6:WaitForChild("Values")
	local var1 = workspace:WaitForChild("supernovaboard"):WaitForChild("MainPart"):WaitForChild("SurfaceGui"):WaitForChild("Frame")
	var9 = var1:WaitForChild("Star")
	var7 = var9:WaitForChild("Number")
	var3 = var1:WaitForChild("ScrollingFrame"):WaitForChild("Bonuses")
	local var5 = var1:WaitForChild("SupernovaButton")
	local bool1 = false
	var5.MouseButton1Click:Connect(function()
		if bool1 then
			return
		end

		if not var4.meeq(var2.Loops.Value, var8.Thresholds.SupernovaLoops) then
			return
		end

		bool1 = true
		var5.Active = false
		var5.AutoButtonColor = false
		var12.SupernovaEvent:FireServer()
		task.delay(60, function()
			bool1 = false
			var5.Active = true
			var5.AutoButtonColor = true
		end)
	end)

	var2.SupernovaTier.Changed:Connect(function()
		var7.Text = var4.short(var2.SupernovaTier.Value)
		refreshBonuses()
		refreshButtonText(var5)
		spinStar()
	end)

	var2.Loops.Changed:Connect(function()
		refreshButtonText(var5)
	end)

	var7.Text = var4.short(var2.SupernovaTier.Value)
	refreshBonuses()
	refreshButtonText(var5)
	task.spawn(function()
		while task.wait(2) do
			var7.Text = var4.short(var2.SupernovaTier.Value)
			refreshBonuses()
			refreshButtonText(var5)
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.KeycapController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = game:GetService("Players")
local var3 = nil
local var4 = var2.LocalPlayer
local var5 = game:GetService("TweenService")
local var6 = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var7 = Color3.fromRGB(147, 126, 22)
local var8 = require(var1.Remotes)
local function isStillOnKey(arg1)
	local var2 = var4.Character
	if not var2 then
		return false
	end

	local var3 = arg1.Size / 2 + Vector3.new(2, 2, 2)
	for k1, v1 in ipairs(var2:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		local var5 = arg1.CFrame:PointToObjectSpace(v1.Position)
		if math.abs(var5.X) > var3.X then
			continue
		end

		if math.abs(var5.Y) > var3.Y then
			continue
		end

		if math.abs(var5.Z) > var3.Z then
			continue
		end

		return true
	end

	return false
end

local var9 = require(var1.Libs.EternityNum)
local var10 = require(var1.Formulas)
local function wireKeycap(arg1)
	local var1 = arg1.Position
	local var9 = var5:Create(arg1, var6, { Position = var1 - Vector3.new(0, 1.5, 0) })
	local bool1 = false
	local var10 = arg1.Color
	local var11 = arg1.Material
	local bool2 = false
	local var12 = var5:Create(arg1, var6, { Position = var1 })
	arg1.Touched:Connect(function(arg1)
		if var2:GetPlayerFromCharacter(arg1.Parent) ~= var4 then
			return
		end

		if bool2 then
			return
		end

		local var5 = arg1:FindFirstChild("Sound")
		if var5 then
			var5.PlaybackSpeed = math.random(-5, 5) / 50 + 1
			var5:Play()
		end

		if bool1 then
			var8.KeycapPressed:FireServer("Golden")
			bool1 = false
			arg1.Color = var10
			arg1.Material = var11
		else
			var8.KeycapPressed:FireServer("Normal")
		end

		bool2 = true
		var9:Play()
		task.spawn(function()
			repeat
				task.wait(0.05)
			until not isStillOnKey(arg1)

			task.wait(0.15)
			var12:Play()
			var12.Completed:Wait()
			bool2 = false
			if not bool1 then
				local var1 = var3
				var1 = var1 and var3:FindFirstChild("#4key")
				local var4 = math.clamp(if not var1 then 0 else (var1:GetAttribute("purchaseCount") or 0) * 5, 0, 100)
				if 0 < var4 and math.random(100) <= var4 then
					bool1 = true
					var1 = var7
					arg1.Color = var1 or var10
					var1 = Enum.Material.Neon
					arg1.Material = var1 or var11
				end
			end
		end)
	end)
end

local function startMilestoneText()
	local var1 = workspace:WaitForChild("milestonething"):WaitForChild("MilestoneGUI"):WaitForChild("SurfaceGui"):WaitForChild("ScrollingFrame"):WaitForChild("Milestone1"):WaitForChild("Desc")
	local var2 = var4:WaitForChild("Values"):WaitForChild("Keycap")
	local var3 = var2.Value
	var1.Text = "Every x10 keycap (starting from 1) will multiply your Steel by x1.1 (x" .. var9.short(var10.KeycapSteelMultiplier(var3)) .. ")"
	task.spawn(function()
		while task.wait(0.5) do
			local var3 = var2.Value
			var1.Text = "Every x10 keycap (starting from 1) will multiply your Steel by x1.1 (x" .. var9.short(var10.KeycapSteelMultiplier(var3)) .. ")"
		end
	end)
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var3 = var4:WaitForChild("Upgrades")
	for k1, v1 in ipairs(workspace:WaitForChild("Keycaps"):GetChildren()) do
		if not v1:IsA("MeshPart") then
			continue
		end

		wireKeycap(v1)
	end

	startMilestoneText()
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.ShopController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.Config.GameConfig)
local var3 = game:GetService("MarketplaceService")
local var4 = game:GetService("Players").LocalPlayer
local var5 = require(var1.Config.Shop)
local function wireWorldPack(arg1)
	local var6 = var2.GamePasses[arg1.GamePass]
	local var7 = arg1.Model
	if not var6 then
		local var8 = var7
		local var9 = tostring(arg1.GamePass)
		warn(("[Shop] %s names an unknown gamepass '%s'"):format(var8, var9))
	end

	if not var6 then
		return
	end

	var7 = workspace:FindFirstChild(arg1.Model)
	local var11 = var7
	if var11 then
		var11 = var7
		for k1, v1 in ipairs(var5.WorldPackButtonPath) do
			local var12 = var11
			var11 = var12 and var11:FindFirstChild(v1)
		end
	end

	if not var11 or (not var11:IsA("TextButton")) then
		local var14 = arg1.Model
		warn(("[Shop] no button found on %s"):format(var14))
		return
	end

	var11.MouseButton1Click:Connect(function()
		var3:PromptGamePassPurchase(var4, var6)
	end)
end

local function resolveWait(arg1, arg2)
	local var1 = arg1
	for k1, v1 in ipairs(arg2) do
		local var2 = var1
		var1 = var2 and var1:WaitForChild(v1, 10)
	end

	return var1
end

local function wireGuiPack(arg1, arg2)
	local var6 = var2.GamePasses[arg2.GamePass]
	local var7 = arg2.Frame
	if not var6 then
		local var8 = var7
		local var9 = tostring(arg2.GamePass)
		warn(("[Shop] %s names an unknown gamepass '%s'"):format(var8, var9))
	end

	if not var6 then
		return
	end

	var7 = arg1:FindFirstChild(arg2.Frame)
	local bool1 = false
	if var7 then
		for k1, v1 in ipairs(var7:GetDescendants()) do
			if v1.Name ~= var5.GuiPackButton then
				continue
			end

			bool1 = v1
			break
		end
	end

	if not bool1 or (not bool1:IsA("TextButton")) then
		local var12 = var5.GuiPackButton
		local var13 = arg2.Frame
		warn(("[Shop] no %s found on shop row %s"):format(var12, var13))
		return
	end

	bool1.MouseButton1Click:Connect(function()
		var3:PromptGamePassPurchase(var4, var6)
	end)
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	for k1, v1 in ipairs(var5.WorldPacks) do
		wireWorldPack(v1)
	end

	local var2 = resolveWait(var4:WaitForChild("PlayerGui"):WaitForChild("SidebarGUI"), var5.GuiFramePath)
	if not var2 then
		warn("[Shop] sidebar shop list not found")
		return
	end

	for k2, v2 in ipairs(var5.GuiPacks) do
		wireGuiPack(var2, v2)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.SaveSlotsController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = require(var1.Remotes)
local var3 = require(var1.Libs.EternityNum)
local function formatPlaytime(arg1)
	arg1 = math.floor(arg1 or 0)
	local var5 = arg1 // 3600
	local var6 = arg1 % 3600 // 60
	local var7 = arg1 % 60
	if 0 < var5 then
		local str2 = "%dh %dm"
		local var8 = var5
		local var9 = var6
		return string.format(str2, var8, var9)
	end

	if 0 < var6 then
		local str4 = "%dm %ds"
		local var12 = var6
		local var13 = var7
		return string.format(str4, var12, var13)
	end

	local str5 = "%ds"
	local var14 = var7
	return string.format(str5, var14)
end

local var4 = nil
local var5 = game:GetService("TweenService")
local var6 = nil
local function playLoadingScreen()
	local var1 = var4:WaitForChild("LoadingScreen")
	var1.Enabled = true
	task.wait(1)
	local var2 = TweenInfo.new(1)
	for k1, v1 in ipairs(var1:GetDescendants()) do
		if v1:IsA("Frame") then
			var5:Create(v1, var2, { BackgroundTransparency = 1 }):Play()
		else
			if not v1:IsA("TextLabel") then
				continue
			end

			var5:Create(v1, var2, { TextTransparency = 1, BackgroundTransparency = 1 }):Play()
		end
	end

	task.wait(1)
	task.wait(2)
	var1.Enabled = false
end

local function refreshSlot(arg1, arg2)
	local success, result = pcall(function()
		local var1 = arg2
		return var2.GetSlotPreview:InvokeServer(var1)
	end)

	if not success then
		local var1 = arg2
		local var4 = tostring(result)
		warn(("[SaveSlots] preview for slot %d failed: %s"):format(var1, var4))
		return
	end

	if result then
		arg1.Points.Text = var3.short(result.Points) .. " P$"
		arg1.TimePlayed.Text = formatPlaytime(result.Playtime)
		return
	end

	arg1.Points.Text = "Empty Slot"
	arg1.TimePlayed.Text = "--"
end

local var7 = game:GetService("Players").LocalPlayer
local var8 = require(var1.Config.GameConfig)
local function wireSlot(arg1, arg2)
	arg1:WaitForChild("TextButton").MouseButton1Click:Connect(function()
		var2.RequestSlotSwap:FireServer(arg2)
		var6.Enabled = false
		playLoadingScreen()
	end)

	return function()
		refreshSlot(arg1, arg2)
	end
end

return { Start = function()
	var4 = var7:WaitForChild("PlayerGui")
	var6 = var4:WaitForChild("SaveSlots")
	local var1 = var6:WaitForChild("Frame")
	local tbl1 = {}
	for i1 = 1, var8.MaxSlots do
		local var2 = var1:WaitForChild("slot" .. i1)
		var2:WaitForChild("Points")
		var2:WaitForChild("TimePlayed")
		local var3 = tbl1
		table.insert(var3, (wireSlot(var2, i1)))
	end

	var6.Enabled = true
	for k1, v1 in ipairs(tbl1) do
		v1()
	end

	var6:GetPropertyChangedSignal("Enabled"):Connect(function()
		if var6.Enabled then
			for k1, v1 in ipairs(tbl1) do
				v1()
			end
		end
	end)

	while true do
		if not task.wait(1) then
			break
		end

		if not var6.Enabled then
			continue
		end

		for k2, v2 in ipairs(tbl1) do
			v2()
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.MenuController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = CFrame.new(45.7250023, 55.1321945, 90.0078201, 0.943675101, -0.16842638, 0.284797907, -0, 0.860745549, 0.509035528, -0.330873519, -0.480364144, 0.812264144)
local var3 = game:GetService("RunService")
local var4 = game:GetService("UserInputService")
local var5 = game:GetService("TweenService")
local var6 = TweenInfo.new(0.7)
local var7 = game:GetService("Players").LocalPlayer
local function flyToCharacter(arg1, arg2, arg3, arg4)
	var5:Create(arg4, var6, { Position = arg4.Position + UDim2.new(0, 0, 1, 0) }):Play()
	local var1 = var7.Character
	var1 = var1 or var7.CharacterAdded:Wait()
	local var2 = var1:WaitForChild("HumanoidRootPart")
	local var4 = var1:WaitForChild("Humanoid")
	var4.WalkSpeed = 0
	var4.JumpPower = 0
	local var8 = os.clock()
	local var9 = arg1.CFrame
	local var10 = nil
	var3.RenderStepped:Connect(function()
		local var1 = var5:GetValue(math.clamp((os.clock() - var8) / 1, 0, 1), Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
		arg1.CFrame = var9:Lerp(CFrame.lookAt(var2.Position - var2.CFrame.LookVector * 10 + Vector3.new(0, 4, 0), var2.Position + Vector3.new(0, 2, 0)), var1)
		if 1 <= var1 then
			var10:Disconnect()
			arg1.CameraType = Enum.CameraType.Custom
			var4.WalkSpeed = 32
			var4.JumpPower = 50
			arg2:Enable()
			arg3.Enabled = false
		end
	end)
end

local var8 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local var9 = UDim2.fromScale(0.45, 0.55)
local var10 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
return { Start = function()
	local var6 = var7:WaitForChild("PlayerGui"):WaitForChild("JoinGui")
	local var11 = var6:WaitForChild("MainFrame")
	local var12 = var6:WaitForChild("CreditsGUI")
	local var13 = var12:WaitForChild("CreditsFrame")
	local var14 = var13
	local var15 = var13:WaitForChild("CloseButton")
	local str1 = "PlayerModule"
	local var16 = var11:WaitForChild("PlayButton")
	local var17 = var11:WaitForChild("CreditsButton")
	local var18 = require(var7.PlayerScripts:WaitForChild(str1)):GetControls()
	var6.Enabled = true
	var18:Disable()
	var13 = workspace.CurrentCamera
	var13.CameraType = Enum.CameraType.Scriptable
	var13.CFrame = var2
	local var19 = var3.RenderStepped:Connect(function()
		local var1 = var4:GetMouseLocation()
		local var3 = var13.ViewportSize
		var13.CFrame = var13.CFrame:Lerp(var2 + (var2.RightVector * ((var1.X / var3.X - 0.5) * 2 * 6) + var2.UpVector * (-((var1.Y / var3.Y - 0.5) * 2) * 6)), 0.08)
	end)

	var16.MouseButton1Click:Connect(function()
		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		flyToCharacter(var13, var18, var6, var11)
	end)

	var17.MouseButton1Click:Connect(function()
		var1.SFX.ClickSound:Play()
		var12.Enabled = true
		var14.Size = UDim2.fromScale(0, 0)
		var5:Create(var14, var8, { Size = var9 }):Play()
	end)

	var15.MouseButton1Click:Connect(function()
		var1.SFX.ClickSound:Play()
		local var2 = var5:Create(var14, var10, { Size = UDim2.fromScale(0, 0) })
		var2:Play()
		var2.Completed:Wait()
		var12.Enabled = false
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.SidebarController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local var3 = game:GetService("TweenService")
local var4 = game:GetService("UserInputService")
local var5 = game:GetService("Players").LocalPlayer
local var6 = UDim2.fromScale(0.5, 0.5)
local var7 = UDim2.fromScale(0.5, 1.5)
local var8 = TweenInfo.new(0.4)
local var9 = TweenInfo.new(0.5)
local var10 = TweenInfo.new(0.35)
local function applyHover(arg1)
	arg1.MouseEnter:Connect(function()
		var1.SFX.HoverSound:Play()
		var3:Create(arg1.Frame, var9, { Size = UDim2.fromScale(4, 1) }):Play()
		var3:Create(arg1.TextFrame.TextLabel, var9, { Position = UDim2.fromScale(0.2, 0) }):Play()
		var3:Create(arg1, var10, { Size = UDim2.fromScale(0.1098, 0.1098) }):Play()
	end)

	arg1.MouseLeave:Connect(function()
		var3:Create(arg1.Frame, var9, { Size = UDim2.fromScale(0, 1) }):Play()
		var3:Create(arg1.TextFrame.TextLabel, var9, { Position = UDim2.fromScale(-0.5, 0) }):Play()
		var3:Create(arg1, var10, { Size = UDim2.fromScale(0.09, 0.09) }):Play()
	end)
end

local tbl1 = {}
local var11 = nil
local tbl2 = {
	{
		Key = "Achievements",
		FramePath = { "AchievementsGUI", "AchievementsFrame" },
		KeyCode = Enum.KeyCode.Y,
		Buttons = {
			{ Path = { "AchievementsButton" } },
			{ Path = { "AchievementsGUI", "AchievementsFrame", "Clopen" }, SnapClosed = true },
		},
	},
	{
		Key = "Settings",
		FramePath = { "SettingsGUI", "SettingsFrame" },
		KeyCode = Enum.KeyCode.H,
		Buttons = {
			{ Path = { "SettingsButton" } },
			{ Path = { "SettingsGUI", "SettingsFrame", "ExitButton" } },
		},
	},
	{
		Key = "Shop",
		FramePath = { "ShopGUI", "ShopFrame" },
		KeyCode = Enum.KeyCode.G,
		Buttons = { { Path = { "ShopButton" } } },
	},
	{
		Key = "Teleport",
		FramePath = { "TeleportGUI", "TeleportFrame" },
		KeyCode = Enum.KeyCode.T,
		Buttons = { { Path = { "TeleportButton" } } },
	},
}

local function resolve(arg1, arg2)
	local var1 = arg1
	for k1, v1 in ipairs(arg2) do
		local var2 = var1
		var1 = var2 and var1:WaitForChild(v1, 10)
	end

	return var1
end

local function applyHoverToAll(arg1)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:FindFirstChild("Frame") then
			continue
		end

		if not v1:FindFirstChild("TextFrame") then
			continue
		end

		applyHover(v1)
	end
end

return {
	Close = function(arg1, arg2)
		if var11 ~= arg1 then
			return
		end

		var11 = nil
		local var2 = tbl1[arg1]
		if not var2 then
			return
		end

		var3:Create(var2, var8, { Position = var7 }):Play()
		if arg2 then
			var2.Visible = false
			return
		end

		task.delay(var8.Time, function()
			if var11 ~= arg1 then
				var2.Visible = false
			end
		end)
	end,
	Start = function()
		local var9 = var5:WaitForChild("PlayerGui"):WaitForChild("SidebarGUI")
		local var10 = var9:WaitForChild("MenuButton")
		local bool1 = true
		local tbl3 = {}
		local tbl4 = {}
		for k1, v1 in ipairs(tbl2) do
			local var13 = resolve(var9, v1.FramePath)
			if not var13 then
				warn("[Sidebar] menu frame not found: " .. v1.Key)
			else
				tbl1[v1.Key] = var13
				tbl3[v1.KeyCode] = v1.Key
				var13.Position = var7
				var13.Visible = false
			end
		end

		local function toggle(arg1, arg2)
			if not bool1 then
				return
			end

			if not tbl1[arg1] then
				return
			end

			var1.SFX.ClickSound:Play()
			if var11 == arg1 then
				var11 = nil
				local var4 = tbl1[arg1]
				if not var4 then
					return
				end

				var3:Create(var4, var8, { Position = var7 }):Play()
				if arg2 then
					var4.Visible = false
					return
				end

				task.delay(var8.Time, function()
					if var11 ~= arg1 then
						var4.Visible = false
					end
				end)

				return
			end

			if var11 then
				local var9 = var11
				local var12 = tbl1[var9]
			if not not var12 then
					var3:Create(var12, var8, { Position = var7 }):Play()
					task.delay(var8.Time, function()
						if var11 ~= var9 then
							var12.Visible = false
						end
					end)

				end
			end

			var11 = arg1
			tbl1[arg1].Visible = true
			var3:Create(tbl1[arg1], var8, { Position = var6 }):Play()
		end

		for k2, v2 in ipairs(tbl2) do
			for k3, v3 in ipairs(v2.Buttons) do
				local var15 = resolve(var9, v3.Path)
				if var15 then
					table.insert(tbl4, var15)
					var15.MouseButton1Click:Connect(function()
						toggle(v2.Key, v3.SnapClosed)
					end)

				else
					local var16 = v3.Path
					local str1 = "."
					warn(("[Sidebar] button not found: %s"):format(table.concat(var16, str1)))
				end
			end
		end

		local var17 = bool1
		for k4, v4 in ipairs(tbl4) do
			v4.Visible = var17
		end

		var10.MouseButton1Click:Connect(function()
			var1.SFX.ClickSound:Play()
			local var2 = not bool1
			bool1 = var2
			var2 = bool1
			for k1, v1 in ipairs(tbl4) do
				v1.Visible = var2
			end

			if not bool1 and var11 then
				var2 = var11
				var11 = nil
				local var4 = tbl1[var2]
				var3:Create(var4, var8, { Position = var7 }):Play()
				task.delay(var8.Time, function()
					var4.Visible = false
				end)

			end
		end)

		var4.InputBegan:Connect(function(arg1, arg2)
			if arg2 or (not bool1) then
				return
			end

			local var2 = tbl3[arg1.KeyCode]
			if var2 then
				toggle(var2, false)
			end
		end)

		applyHoverToAll(var9)
		var17 = tbl1.Settings
		var17 = var17 and tbl1.Settings:FindFirstChild("BG")
		if var17 then
			local num2 = 0
			local var19 = var17.Position
			var2.RenderStepped:Connect(function(arg1)
				local var1 = num2 + arg1 * 2
				num2 = var1
				var17.Position = UDim2.new(var19.X.Scale + math.sin(num2) * 0.05, var19.X.Offset, var19.Y.Scale + math.cos(num2) * 0.05, var19.Y.Offset)
			end)

		end
	end,
}

--- Players.LocalPlayer.PlayerScripts.Controllers.SettingsController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local function captureOriginalFont(arg1)
	if arg1:GetAttribute("OrigFontWeight") ~= nil then
		return
	end

	local var1 = arg1.FontFace
	arg1:SetAttribute("OrigFontWeight", var1.Weight.Name)
	arg1:SetAttribute("OrigFontStyle", var1.Style.Name)
	arg1:SetAttribute("IsFredokaFont", true)
end

local str1 = "Bold"
local var2 = nil
local bool1 = true
local function applySansSerif(arg1)
	local var1
	if arg1:GetAttribute("IsFredokaFont") ~= nil then
		var1 = arg1:GetAttribute("IsFredokaFont")
	else
		var1 = arg1.FontFace.Family == "rbxasset://fonts/families/FredokaOne.json"
	end

	if not var1 then
		return
	end

	captureOriginalFont(arg1)
	if str1 == "Italic" then
		arg1.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Regular, Enum.FontStyle.Italic)
		return
	end

	arg1.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
end

local function restoreFredoka(arg1)
	if not arg1:GetAttribute("IsFredokaFont") then
		return
	end

	local var1 = Enum.FontWeight[arg1:GetAttribute("OrigFontWeight") or "Regular"]
	local var2 = Enum.FontStyle[arg1:GetAttribute("OrigFontStyle") or "Normal"]
	arg1.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json", var1 or Enum.FontWeight.Regular, var2 or Enum.FontStyle.Normal)
end

local var3 = require(var1.Config.BuyMaxCategories)
local tbl1 = {}
local var4 = require(var1.Remotes)
local var5 = game:GetService("Players").LocalPlayer
local var6 = Color3.fromRGB(0, 255, 0)
local var7 = Color3.fromRGB(3, 140, 3)
local var8 = Color3.fromRGB(255, 0, 0)
local var9 = Color3.fromRGB(140, 3, 3)
local var10 = nil
local function updateAllFonts()
	local var1 = workspace
	for k1, v1 in ipairs({ var2, var1 }) do
		for k2, v2 in ipairs(v1:GetDescendants()) do
			local var3 = v2:IsA("TextLabel")
			if not (var3 or (v2:IsA("TextButton") or v2:IsA("TextBox"))) then
				continue
			end

			if bool1 then
				applySansSerif(v2)
			else
				restoreFredoka(v2)
			end
		end
	end
end

local function resolve(arg1, arg2)
	local var1 = arg1
	for k1, v1 in ipairs(arg2) do
		local var2 = var1
		var1 = var2 and var1:WaitForChild(v1, 10)
	end

	return var1
end

local tbl2 = {
	"SettingsGUI",
	"SettingsFrame",
	"Frame",
	"ScrollingFrame",
	"UnsloppifyMode",
	"UnsloppifyButton",
}

local tbl3 = {
	"SettingsGUI",
	"SettingsFrame",
	"Frame",
	"ScrollingFrame",
	"CameraShake",
	"CameraShakeButton",
}

local tbl4 = { "SettingsGUI", "SettingsFrame", "Frame", "ScrollingFrame" }
local function buildBuyMaxSetting(arg1, arg2)
	local var1 = arg2:Clone()
	var1.Name = "BuyMaxFilter"
	var1.LayoutOrder = 1
	var1.Visible = false
	local var7 = var1:FindFirstChildWhichIsA("TextLabel")
	if var7 then
		var7.Name = "BuyMaxLabel"
		var7.Text = "Buy Max Upgrades"
	end

	local var9 = var1:FindFirstChildWhichIsA("TextButton")
	var9.Name = "BuyMaxButton"
	var9.Text = "Edit"
	var9.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
	var9.BorderColor3 = Color3.fromRGB(21, 62, 140)
	local var11 = Instance.new("Frame")
	var11.Name = "BuyMaxDropdown"
	var11.LayoutOrder = 2
	var11.Size = UDim2.new(1, 0, 0, 130)
	var11.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	var11.BorderColor3 = Color3.fromRGB(0, 0, 0)
	var11.BorderSizePixel = 2
	var11.Visible = false
	local var12 = Instance.new("ScrollingFrame")
	var12.Name = "List"
	var12.Size = UDim2.fromScale(1, 1)
	var12.BackgroundTransparency = 1
	var12.BorderSizePixel = 0
	var12.ScrollBarThickness = 6
	var12.CanvasSize = UDim2.fromOffset(0, #var3.List * 26)
	var12.Parent = var11
	local var13 = Instance.new("UIListLayout")
	var13.SortOrder = Enum.SortOrder.LayoutOrder
	var13.Parent = var12
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(var3.List) do
		local var14 = Instance.new("TextButton")
		var14.Name = v1.key
		var14.LayoutOrder = k1
		var14.Size = UDim2.new(1, 0, 0, 26)
		var14.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
		var14.BorderSizePixel = 0
		var14.Text = ""
		local var15 = Instance.new("TextLabel")
		var15.Name = "CategoryName"
		var15.Size = UDim2.new(0.78, 0, 1, -6)
		var15.Position = UDim2.new(0, 6, 0, 3)
		var15.BackgroundTransparency = 1
		var15.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
		var15.Text = v1.label
		var15.TextColor3 = Color3.fromRGB(255, 255, 255)
		var15.TextScaled = true
		var15.TextXAlignment = Enum.TextXAlignment.Left
		var15.Parent = var14
		local var16 = Instance.new("TextLabel")
		var16.Name = "Check"
		var16.AnchorPoint = Vector2.new(1, 0)
		var16.Size = UDim2.new(0.16, 0, 1, -6)
		var16.Position = UDim2.new(1, -4, 0, 3)
		var16.BackgroundTransparency = 1
		var16.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
		var16.TextScaled = true
		var16.Parent = var14
		local var18 = tbl1[v1.key] == true
		local function paint()
			local var2 = tbl1[v1.key] == true
			local var3 = var16
			var3.Text = if var2 then "\226\156\147" else "\226\156\151"
			var16.TextColor3 = var2 and var6 or var8
		end

		var16.Text = if var18 then "\226\156\147" else "\226\156\151"
		var16.TextColor3 = var18 and var6 or var8
		table.insert(tbl2, paint)
		var14.MouseButton1Click:Connect(function()
			tbl1[v1.key] = not (tbl1[v1.key] == true)
			local var2 = tbl1[v1.key] == true
			local var3 = var16
			var3.Text = if var2 then "\226\156\147" else "\226\156\151"
			var16.TextColor3 = var2 and var6 or var8
			var4.UpdateSetting:FireServer("BuyMaxUpgrades", tbl1)
		end)

		var14.Parent = var12
		tbl3[v1.key] = var14
	end

	var10 = function()
		for k1, v1 in ipairs(tbl2) do
			v1()
		end
	end

	task.spawn(function()
		local tbl1 = {}
		local function updateCanvasSize()
			local num1 = 0
			for k1, v1 in ipairs(var3.List) do
				if not tbl1[v1.key] then
					continue
				end

				num1 = num1 + 1
			end

			var12.CanvasSize = UDim2.fromOffset(0, num1 * 26)
		end

		for k1, v1 in ipairs(var5:WaitForChild("Upgrades"):GetChildren()) do
			local var1 = var3.CategoryOf(v1.Name)
			if not var1 then
				continue
			end

			if not tbl3[var1] then
				continue
			end

			if v1:GetAttribute("VisibleIf") then
				if var1 then
		if not tbl1[var1] then
						tbl1[var1] = true
						local var4 = tbl3[var1]
						if var4 then
							var4.Visible = true
						end

						updateCanvasSize()
					end
				end
			end

			v1:GetAttributeChangedSignal("VisibleIf"):Connect(function()
				if v1:GetAttribute("VisibleIf") then
					local var4 = var1
					if var4 then
						if tbl1[var4] then
							return
						end

						tbl1[var4] = true
						local var6 = tbl3[var4]
						if var6 then
							var6.Visible = true
						end

						updateCanvasSize()
					end
				end
			end)

		end

		for k2, v2 in ipairs(var3.List) do
			if tbl1[v2.key] then
				continue
			end

			local var6 = tbl3[v2.key]
			if not var6 then
				continue
			end

			var6.Visible = false
		end

		updateCanvasSize()
	end)

	var9.MouseButton1Click:Connect(function()
		var11.Visible = not var11.Visible
	end)

	var11.Parent = arg1
	var1.Parent = arg1
	task.spawn(function()
		local var2 = var5:WaitForChild("Upgrades"):WaitForChild("#buymax")
		var2:GetAttributeChangedSignal("purchaseCount"):Connect(function()
			local var3 = 0 < (var2:GetAttribute("purchaseCount") or 0)
			var1.Visible = var3
			if not var3 then
				var11.Visible = false
			end
		end)

		local var3 = 0 < (var2:GetAttribute("purchaseCount") or 0)
		var1.Visible = var3
		if not var3 then
			var11.Visible = false
		end
	end)
end

return {
	IsBuyMaxAllowed = function(arg1)
		local var2 = var3.CategoryOf(arg1)
		if not var2 then
			return true
		end

		return tbl1[var2] == true
	end,
	Start = function()
		var2 = var5:WaitForChild("PlayerGui")
		local bool2 = true
		local bool3 = false
		local bool4 = false
		local var1 = nil
		local var3 = nil
		local var11 = nil
		var4.SettingsLoaded.OnClientEvent:Connect(function(arg1)
			bool1 = arg1.FontToggle or false
			str1 = arg1.FontStyleToggle or "Bold"
			bool2 = arg1.CameraShake
			if bool2 == nil then
				bool2 = true
			end

			var5:SetAttribute("CameraShake", bool2)
			if typeof(arg1.BuyMaxUpgrades) == "table" then
				tbl1 = arg1.BuyMaxUpgrades
			end

			if var10 then
				var10()
			end

			bool3 = arg1.InstantTeleport or false
			bool4 = true
			updateAllFonts()
			if var1 then
				local var4 = bool1
				local var12 = var1
				var12.Text = if var4 then "On" else "Off"
				var12.BackgroundColor3 = var4 and var6 or var8
				var12.BorderColor3 = var4 and var7 or var9
			end

			if var3 then
				local var14 = bool2
				local var15 = var3
				var15.Text = if var14 then "On" else "Off"
				var15.BackgroundColor3 = var14 and var6 or var8
				var15.BorderColor3 = var14 and var7 or var9
			end

			if var11 then
				local var17 = bool3
				local var18 = var11
				var18.Text = if var17 then "On" else "Off"
				var18.BackgroundColor3 = var17 and var6 or var8
				var18.BorderColor3 = var17 and var7 or var9
			end
		end)

		var2.DescendantAdded:Connect(function(arg1)
			local var1 = arg1:IsA("TextLabel")
			if not (var1 or (arg1:IsA("TextButton") or arg1:IsA("TextBox"))) then
				return
			end

			if bool1 then
				applySansSerif(arg1)
				return
			end

			if arg1.FontFace.Family == "rbxasset://fonts/families/FredokaOne.json" then
				arg1:SetAttribute("IsFredokaFont", true)
			end
		end)

		workspace.DescendantAdded:Connect(function(arg1)
			local var1 = arg1:IsA("TextLabel")
			if not (var1 or (arg1:IsA("TextButton") or arg1:IsA("TextBox"))) then
				return
			end

			if bool1 then
				applySansSerif(arg1)
				return
			end

			if arg1.FontFace.Family == "rbxasset://fonts/families/FredokaOne.json" then
				arg1:SetAttribute("IsFredokaFont", true)
			end
		end)

		local var12 = var2:WaitForChild("SidebarGUI")
		var1 = resolve(var12, tbl2)
		var3 = resolve(var12, tbl3)
		if var1 then
			local var14 = bool1
			local var15 = var1
			var15.Text = if var14 then "On" else "Off"
			var15.BackgroundColor3 = var14 and var6 or var8
			var15.BorderColor3 = var14 and var7 or var9
			var1.MouseButton1Click:Connect(function()
				local var2 = not bool1
				bool1 = var2
				updateAllFonts()
				local var5 = bool1
				var2 = var1
				var2.Text = if var5 then "On" else "Off"
				var2.BackgroundColor3 = var5 and var6 or var8
				var2.BorderColor3 = var5 and var7 or var9
				var4.UpdateSetting:FireServer("FontToggle", bool1)
			end)

		else
			warn("[Settings] UnsloppifyButton not found")
		end

		local var18 = resolve(var12, tbl4)
		local var19 = var3 and var3.Parent or var1 and var1.Parent
		if var18 and var19 then
			buildBuyMaxSetting(var18, var19)
			local var20 = var19:Clone()
			var20.Name = "InstantTeleport"
			var20.LayoutOrder = 3
			local var22 = var20:FindFirstChildWhichIsA("TextLabel")
			if var22 then
				var22.Name = "InstantTeleportLabel"
				var22.Text = "Instant Teleport"
			end

			local var23 = var20:FindFirstChildWhichIsA("TextButton")
			var23.Name = "InstantTeleportButton"
			var20.Parent = var18
			var11 = var23
		else
			warn("[Settings] Buy Max filter row not built (settings list not found)")
		end

		if var3 then
			local var25 = bool2
			local var26 = var3
			var26.Text = if var25 then "On" else "Off"
			var26.BackgroundColor3 = var25 and var6 or var8
			var26.BorderColor3 = var25 and var7 or var9
			var3.MouseButton1Click:Connect(function()
				local var1 = not bool2
				bool2 = var1
				var5:SetAttribute("CameraShake", bool2)
				local var10 = bool2
				var1 = var3
				var1.Text = if var10 then "On" else "Off"
				var1.BackgroundColor3 = var10 and var6 or var8
				var1.BorderColor3 = var10 and var7 or var9
				var4.UpdateSetting:FireServer("CameraShake", bool2)
			end)

		else
			warn("[Settings] CameraShakeButton not found")
		end

		if var11 then
			local var28 = bool3
			local var29 = var11
			var29.Text = if var28 then "On" else "Off"
			var29.BackgroundColor3 = var28 and var6 or var8
			var29.BorderColor3 = var28 and var7 or var9
			var11.MouseButton1Click:Connect(function()
				local var1 = not bool3
				bool3 = var1
				local var3 = bool3
				var1 = var11
				var1.Text = if var3 then "On" else "Off"
				var1.BackgroundColor3 = var3 and var6 or var8
				var1.BorderColor3 = var3 and var7 or var9
				var4.UpdateSetting:FireServer("InstantTeleport", bool3)
			end)

		else
			warn("[Settings] InstantTeleportButton not built")
		end

		if bool4 then
			updateAllFonts()
			if var1 then
				local var31 = bool1
				local var32 = var1
				var32.Text = if var31 then "On" else "Off"
				var32.BackgroundColor3 = var31 and var6 or var8
				var32.BorderColor3 = var31 and var7 or var9
			end

			if var3 then
				local var34 = bool2
				local var35 = var3
				var35.Text = if var34 then "On" else "Off"
				var35.BackgroundColor3 = var34 and var6 or var8
				var35.BorderColor3 = var34 and var7 or var9
			end

			if var11 then
				local var37 = bool3
				local var38 = var11
				var38.Text = if var37 then "On" else "Off"
				var38.BackgroundColor3 = var37 and var6 or var8
				var38.BorderColor3 = var37 and var7 or var9
			end

			if var10 then
				var10()
			end
		end
	end,
}

--- Players.LocalPlayer.PlayerScripts.Controllers.AchievementsUIController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local tbl1 = {}
local var3 = Color3.fromRGB(120, 120, 120)
local var4 = require(var1.Config.Achievements)
local str1 = "Main"
local var5 = nil
local var6 = Color3.fromRGB(220, 220, 220)
local var7 = Color3.fromRGB(170, 170, 170)
local var8 = nil
local var9 = game:GetService("TweenService")
local var10 = nil
local var11 = TweenInfo.new(0.35)
local var12 = UDim2.new(0, 0, 0.571, 0)
local var13 = UDim2.new(0, 0, 1.05, 0)
local var14 = nil
local var15 = UDim2.new(1.35, 0, 0.033, 0)
local var16 = TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var17 = UDim2.new(0.984, 0, 0.033, 0)
local var18 = TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local var19 = nil
local var20 = require(var1.Remotes)
local function updateButtons()
	if not var2 then
		return
	end

	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("ImageButton") then
			continue
		end

		local var1 = v1:GetAttribute("AchievementId")
		if not var1 then
			continue
		end

		local var4 = tbl1[var1] and Color3.new(1, 1, 1) or var3
		v1.ImageColor3 = var4
		v1.ImageTransparency = if tbl1[var1] then 0 else 0.7
	end
end

local function showPopup(arg1)
	local var2 = var4[arg1]
	if not var2 or (not var14) then
		return
	end

	local var5 = var14:FindFirstChild("Icon")
	if var5 then
		var5.Image = var2.Icon or ""
	end

	local var7 = var14:FindFirstChild("Title")
	if var7 then
		var7.Text = "Achievement Awarded!"
	end

	local var10 = var14:FindFirstChild("Description")
	if var10 then
		var10.Text = var2.Name or ""
	end

	var14.Position = var15
	var14.Visible = true
	local var11 = var9:Create(var14, var16, { Position = var17 })
	var11:Play()
	var11.Completed:Wait()
	task.wait(3)
	local var12 = var9:Create(var14, var18, { Position = var15 })
	var12:Play()
	var12.Completed:Wait()
	var14.Visible = false
end

local var21 = game:GetService("Players").LocalPlayer
local function updateCategory()
	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("ImageButton") then
			continue
		end

		local var1 = var4[v1:GetAttribute("AchievementId")]
		if not var1 then
			continue
		end

		v1.Visible = var1.Category == str1
	end

	var2.CanvasPosition = Vector2.zero
	var5.BackgroundColor3 = str1 == "Main" and var6 or var7
	var8.BackgroundColor3 = str1 == "Side" and var6 or var7
end

local function wireAchievementButton(arg1)
	local var2 = arg1:GetAttribute("AchievementId")
	if not var2 or (not var4[var2]) then
		local var3 = arg1.Name
		local var5 = tostring(var2)
		warn(("[Achievements] button '%s' has no matching achievement (AchievementId=%s)"):format(var3, var5))
		return
	end

	arg1.Image = var4[var2].Icon or ""
	arg1.MouseButton1Click:Connect(function()
		if var19 == var2 then
			var9:Create(var10, var11, { Position = var13 }):Play()
			var19 = nil
			return
		end

		var19 = var2
		local var5 = var10:FindFirstChild("Image")
		local var6 = var4[var2]
		if var5 then
			var5.Image = var6.Icon or ""
		end

		local var8 = var10:FindFirstChild("Name")
		if var8 then
			var8.Text = var6.Name or ""
		end

		local var15 = var10:FindFirstChild("Description")
		if var15 then
			var15.Text = var6.Description or ""
		end

		local var17 = var10:FindFirstChild("Obtainment")
		if var17 then
			local var18
			if tbl1[var2] then
				var18 = var6.Obtainment
				if not var18 then
					var18 = ""
				end
			else
				var18 = "???"
			end

			var17.Text = var18
		end

		local var20 = var12
		var9:Create(var10, var11, { Position = var20 or var13 }):Play()
	end)
end

return { Start = function()
	var20.SendPlayerAchievements.OnClientEvent:Connect(function(arg1)
		local var1 = arg1
		tbl1 = var1 or {}
		updateButtons()
	end)

	var20.AchievementUnlocked.OnClientEvent:Connect(function(arg1)
		tbl1[arg1] = true
		updateButtons()
		showPopup(arg1)
	end)

	local var1 = var21:WaitForChild("PlayerGui"):WaitForChild("SidebarGUI"):WaitForChild("AchievementsGUI")
	var14 = var1:WaitForChild("AchievementPopup")
	local var3 = var1:WaitForChild("AchievementsFrame")
	var2 = var3:WaitForChild("ScrollingFrame")
	var10 = var3:WaitForChild("InfoFrame")
	local var4 = var3:WaitForChild("PagesSelect")
	var5 = var4:WaitForChild("Main")
	var8 = var4:WaitForChild("Side")
	var14.Visible = false
	var10.Position = var13
	var5.MouseButton1Click:Connect(function()
		str1 = "Main"
		updateCategory()
	end)

	var8.MouseButton1Click:Connect(function()
		str1 = "Side"
		updateCategory()
	end)

	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("ImageButton") then
			continue
		end

		wireAchievementButton(v1)
	end

	local var7 = var10:FindFirstChild("Close")
	if var7 then
		var7.MouseButton1Click:Connect(function()
			var9:Create(var10, var11, { Position = var13 }):Play()
			var19 = nil
		end)

	end

	updateCategory()
	updateButtons()
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.TeleportUIController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local tbl1 = {}
local var2 = require(var1.Util)
local var3 = nil
local var4 = nil
local function refreshRows()
	for k1, v1 in ipairs(tbl1) do
		v1.frame.Visible = var2.gateSatisfied(v1.gate, var3, var4)
	end
end

local var5 = game:GetService("Players").LocalPlayer
local function resolve(arg1, arg2)
	local var1 = arg1
	for k1, v1 in ipairs(arg2) do
		local var2 = var1
		var1 = var2 and var1:WaitForChild(v1, 10)
	end

	return var1
end

local var6 = require(var1.Config.Portals)
local var7 = require(var1.Remotes)
local var8 = require(script.Parent.SidebarController)
local function connectWatches()
	local tbl2 = {}
	local tbl3 = {}
	for k1, v1 in ipairs(tbl1) do
		var2.collectGateWatches(v1.gate, tbl2, tbl3)
	end

	for k2, v2 in ipairs(tbl2) do
		local var5 = var3:WaitForChild(v2, 5)
		if var5 then
			var5:GetAttributeChangedSignal("purchaseCount"):Connect(refreshRows)
		else
			warn("[TeleportUI] watched upgrade never appeared: " .. v2)
		end
	end

	for k3, v3 in ipairs(tbl3) do
		local var7 = var4:WaitForChild(v3, 5)
		if var7 then
			var7:GetPropertyChangedSignal("Value"):Connect(refreshRows)
		else
			warn("[TeleportUI] watched currency never appeared: " .. v3)
		end
	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var3 = var5:WaitForChild("Upgrades")
	var4 = var5:WaitForChild("Values")
	local var2 = resolve(var5:WaitForChild("PlayerGui"):WaitForChild("SidebarGUI"), var6.MenuFramePath)
	if not var2 then
		warn("[TeleportUI] teleport menu not found")
		return
	end

	for k1, v1 in ipairs(var6.MenuRows) do
		local var9 = var2:WaitForChild(v1.Frame, 10)
		local var10 = var9
		local var11 = workspace:FindFirstChild(v1.Destination)
		var10 = var10 and var9:WaitForChild(var6.MenuRowButton, 10)
		if not var9 then
			warn("[TeleportUI] row frame not found: " .. v1.Frame)
		elseif not var10 then
			warn("[TeleportUI] row has no button: " .. v1.Frame)
		elseif not var11 then
			local var12 = v1.Frame
			local var13 = v1.Destination
			warn(("[TeleportUI] %s destination %s is not in workspace"):format(var12, var13))
		else
			var10.MouseButton1Click:Connect(function()
				var7.TeleportEvent:FireServer(var11)
				var8.Close("Teleport")
			end)

			if not v1.Gate then
				continue
			end

			table.insert(tbl1, { frame = var9, gate = v1.Gate })
		end
	end

	refreshRows()
	connectWatches()
	while task.wait(var6.MenuGateFailsafeInterval) do
		refreshRows()
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.TutorialController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local tbl1 = {}
local var2 = require(var1.Remotes)
local var3 = nil
local var4 = nil
local var5 = nil
local var6 = nil
local var7 = nil
local var8 = game:GetService("Players").LocalPlayer
local var9 = nil
local var10 = nil
local var11 = nil
local var12 = nil
local function showBeamTo(arg1)
	if arg1 == var7 then
		return
	end

	if var4 then
		var4:Destroy()
		var4 = nil
	end

	if var5 then
		var5:Destroy()
		var5 = nil
	end

	if var6 then
		var6:Destroy()
		var6 = nil
	end

	var7 = nil
	local var1 = var8.Character
	local var2 = var1
	local var10 = var9:FindFirstChild(arg1)
	var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
	local var11
	if not var10 then
		var11 = nil
	else
		if var10.PrimaryPart then
			var11 = var10.PrimaryPart
		else
			local var13 = var10:FindFirstChild("Main")
			var11 = if var13 and var13:IsA("BasePart") then var13 else var10:FindFirstChildWhichIsA("BasePart", true)
		end
	end

	if not var2 or (not var11) then
		return
	end

	var5 = Instance.new("Attachment")
	var5.Name = "TutorialBeamOrigin"
	var5.Parent = var2
	var6 = Instance.new("Attachment")
	var6.Name = "TutorialBeamTarget"
	var6.Parent = var11
	var4 = Instance.new("Beam")
	var4.Name = "TutorialBeam"
	var4.Attachment0 = var5
	var4.Attachment1 = var6
	var4.FaceCamera = true
	var4.LightEmission = 3
	var4.Texture = "rbxassetid://16686518302"
	var4.TextureLength = 8
	var4.Parent = workspace
	var7 = arg1
end

local function countBought(arg1, arg2)
	local num1 = 0
	for i1 = arg1, arg2 do
		if 0 >= var3["#" .. i1]:GetAttribute("purchaseCount") then
			continue
		end

		num1 = num1 + 1
	end

	return num1
end

local var13 = require(var1.Libs.EternityNum)
local var14 = nil
local var15 = require(var1.Config.GameConfig)
local bool1 = false
local tbl2 = {
	"TutorialStarted",
	"BoughtUpgrade1",
	"BoughtUpgrade2Maxed",
	"BoughtUpgrade3",
	"Reached12Upgrades",
	"ReachedPrestigeThreshold",
	"TutorialCompleted",
	"UnlockedPower",
	"UnlockedSteel",
}

local function clearBeam()
	if var4 then
		var4:Destroy()
		var4 = nil
	end

	if var5 then
		var5:Destroy()
		var5 = nil
	end

	if var6 then
		var6:Destroy()
		var6 = nil
	end

	var7 = nil
end

local function evaluateStage()
	if var3["#1"]:GetAttribute("purchaseCount") == 0 then
		var12.Text = "Tutorial: Buy your first upgrade!"
		showBeamTo("#1")
		return
	end

	if var3["#1"]:GetAttribute("purchaseCount") == 1 then
		if var3["#2"]:GetAttribute("purchaseCount") ~= var3["#2"]:GetAttribute("max") then
	if not tbl1.BoughtUpgrade1 then
				tbl1.BoughtUpgrade1 = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade1")
			end

			var12.Text = "Tutorial: Buy the second upgrade (" .. var3["#2"]:GetAttribute("purchaseCount") .. "/8)"
			showBeamTo("#2")
			return
		end
	end

	if var3["#2"]:GetAttribute("purchaseCount") == 8 then
		if var3["#3"]:GetAttribute("purchaseCount") ~= var3["#3"]:GetAttribute("max") then
	if not tbl1.BoughtUpgrade1 then
				tbl1.BoughtUpgrade1 = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade1")
			end

	if not tbl1.BoughtUpgrade2Maxed then
				tbl1.BoughtUpgrade2Maxed = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade2Maxed")
			end

			var12.Text = "Tutorial: Buy the third upgrade!"
			showBeamTo("#3")
			return
		end
	end

	if var3["#3"]:GetAttribute("purchaseCount") == 1 then
		if countBought(1, 12) < 12 then
	if not tbl1.BoughtUpgrade1 then
				tbl1.BoughtUpgrade1 = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade1")
			end

	if not tbl1.BoughtUpgrade2Maxed then
				tbl1.BoughtUpgrade2Maxed = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade2Maxed")
			end

	if not tbl1.BoughtUpgrade3 then
				tbl1.BoughtUpgrade3 = true
				var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade3")
			end

			var12.Text = "Tutorial: Nice! Now reach the 12th upgrade (" .. countBought(1, 12) .. "/12)"
			if var4 then
				var4:Destroy()
				var4 = nil
			end

			if var5 then
				var5:Destroy()
				var5 = nil
			end

			if var6 then
				var6:Destroy()
				var6 = nil
			end

			var7 = nil
			return
		end
	end

	if countBought(1, 12) == 12 then
	if not tbl1.BoughtUpgrade1 then
			tbl1.BoughtUpgrade1 = true
			var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade1")
		end

	if not tbl1.BoughtUpgrade2Maxed then
			tbl1.BoughtUpgrade2Maxed = true
			var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade2Maxed")
		end

	if not tbl1.BoughtUpgrade3 then
			tbl1.BoughtUpgrade3 = true
			var2.AnalyticsFunnelEvent:FireServer("BoughtUpgrade3")
		end

	if not tbl1.Reached12Upgrades then
			tbl1.Reached12Upgrades = true
			var2.AnalyticsFunnelEvent:FireServer("Reached12Upgrades")
		end

		var12.Text = "Tutorial: Wait for 1Qn Points, then Prestige! (" .. var13.short(var13.meeq(var14.Points.Value, var15.Thresholds.PrestigePoints) and var15.Thresholds.PrestigePoints or var14.Points.Value) .. "/1Qn Points)"
		if var4 then
			var4:Destroy()
			var4 = nil
		end

		if var5 then
			var5:Destroy()
			var5 = nil
		end

		if var6 then
			var6:Destroy()
			var6 = nil
		end

		var7 = nil
	end
end

local function evaluateFunnelOnly()
	if var13.meeq(var14.Points.Value, var15.Thresholds.PrestigePoints) then
	if not tbl1.ReachedPrestigeThreshold then
			tbl1.ReachedPrestigeThreshold = true
			var2.AnalyticsFunnelEvent:FireServer("ReachedPrestigeThreshold")
		end
	end

	if var14.Power then
		if var13.meeq(var14.Power.Value, 1) then
	if not tbl1.UnlockedPower then
				tbl1.UnlockedPower = true
				var2.AnalyticsFunnelEvent:FireServer("UnlockedPower")
			end
		end
	end

	if var14.Steel then
		if var13.meeq(var14.Steel.Value, 1) then
	if not tbl1.UnlockedSteel then
				tbl1.UnlockedSteel = true
				var2.AnalyticsFunnelEvent:FireServer("UnlockedSteel")
			end
		end
	end

	if var13.meeq(var14.Prestige.Value, 1) then
	if not tbl1.TutorialCompleted then
			tbl1.TutorialCompleted = true
			var2.AnalyticsFunnelEvent:FireServer("TutorialCompleted")
		end

		bool1 = true
		if var4 then
			var4:Destroy()
			var4 = nil
		end

		if var5 then
			var5:Destroy()
			var5 = nil
		end

		if var6 then
			var6:Destroy()
			var6 = nil
		end

		var7 = nil
		var2.TutorialCompletedEvent:FireServer()
	end
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	task.wait(2)
	var11 = var8:WaitForChild("PlayerGui")
	var14 = var8:WaitForChild("Values")
	var3 = var8:WaitForChild("Upgrades")
	var9 = workspace:WaitForChild("UpgradesFolder")
	for k1, v1 in ipairs(tbl2) do
		if not var8:GetAttribute("Funnel_" .. v1) then
			continue
		end

		tbl1[v1] = true
	end

	bool1 = var8:GetAttribute("TutorialComplete") or false
	if not bool1 then
	if not tbl1.TutorialStarted then
			tbl1.TutorialStarted = true
			var2.AnalyticsFunnelEvent:FireServer("TutorialStarted")
		end
	end

	var8:GetAttributeChangedSignal("TutorialComplete"):Connect(function()
		bool1 = var8:GetAttribute("TutorialComplete") or false
	end)

	var8.CharacterAdded:Connect(clearBeam)
	while true do
		if not task.wait(0.2) then
			break
		end

		local var1
		if var10 and var10:IsDescendantOf(var11) then
			var1 = true
		else
			var10 = var11:WaitForChild("TutorialGUI", 10)
			if not var10 then
				var12 = nil
				var1 = false
			else
				var12 = var10:WaitForChild("TutorialText", 10)
				var1 = var12 ~= nil
			end
		end

		if not var1 then
			continue
		end

		var10.Enabled = not bool1
		var12.Text = ""
		if bool1 then
			if var4 then
				var4:Destroy()
				var4 = nil
			end

			if var5 then
				var5:Destroy()
				var5 = nil
			end

			if var6 then
				var6:Destroy()
				var6 = nil
			end

			var7 = nil
		else
			evaluateStage()
			evaluateFunnelOnly()
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.SupernovaChallengeController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = nil
local var4 = require(var1.Config.Challenges)
local var5 = nil
local var6 = require(var1.Util)
local var7 = game:GetService("Players").LocalPlayer
local var8 = nil
local var9 = nil
local var10 = nil
local var11 = nil
local var12 = require(var1.Remotes)
local tbl1 = { NotCompleted = Color3.fromRGB(255, 120, 120) }
tbl1.InProgress = Color3.fromRGB(214, 172, 62)
tbl1.Completed = Color3.fromRGB(120, 220, 140)
local tbl2 = {}
local function refreshBoard(arg1)
	local var3 = tbl2[arg1]
	if not var3 then
		return
	end

	local var6 = var4[arg1]
	if not var6 then
		return
	end

	local var7 = var2:FindFirstChild(arg1)
	local var8 = var7 and var7.Value or 0
	var3.LevelText.Text = var8 .. "/" .. var6.MaxLevel
	if var6.MaxLevel <= var8 then
		var3.CompletionText.Text = "Completed"
		var3.CompletionText.TextColor3 = tbl1.Completed
		return
	end

	local var10 = var2.Active.Value
	if (if var10 and var10 ~= "" then var10 else nil) == arg1 then
		var3.CompletionText.Text = "In Progress"
		var3.CompletionText.TextColor3 = tbl1.InProgress
		return
	end

	var3.CompletionText.Text = "Not Completed"
	var3.CompletionText.TextColor3 = tbl1.NotCompleted
end

local function refreshDescription()
	if not var3 then
		return
	end

	local var12 = var4[var3]
	if not var12 then
		return
	end

	local var13 = var2:FindFirstChild(var3)
	local var14 = var13 and var13.Value or 0
	local var16 = var2.Active.Value
	local var17 = var12.MaxLevel <= var14
	var13 = var4.WithState
	local var18 = var12
	local var19 = var14
	var13 = var13(var18, var19, (if var16 and var16 ~= "" then var16 else nil) == var3)
	var5.Text = var6.resolve(var13.TitleText, var7, var13)
	var8.Text = var6.resolve(var13.PenaltyText, var7, var13)
	var9.Text = var4.GetGoalText(var7, var13)
	var10.Text = var6.resolve(var13.RewardText, var7, var13)
	if var13.active then
		var11.Text = "Cancel Challenge"
		return
	end

	if var17 then
		var11.Text = "Maxed Out"
		return
	end

	var11.Text = "Start Challenge"
end

local function showConfirm(arg1, arg2, arg3)
	local var1 = Instance.new("Frame")
	var1.Name = "ChallengeConfirm"
	var1.BackgroundTransparency = 1
	var1.Size = UDim2.fromScale(1, 1)
	var1.ZIndex = 1000
	var1.Parent = arg1
	local var2 = Instance.new("TextButton")
	var2.Text = ""
	var2.AutoButtonColor = false
	var2.Size = UDim2.fromScale(1, 1)
	var2.BackgroundColor3 = Color3.new(0, 0, 0)
	var2.BackgroundTransparency = 0.5
	var2.ZIndex = 1000
	var2.Parent = var1
	local var3 = Instance.new("Frame")
	var3.AnchorPoint = Vector2.new(0.5, 0.5)
	var3.Position = UDim2.fromScale(0.5, 0.5)
	var3.Size = UDim2.fromScale(0.75, 0.6)
	var3.BackgroundColor3 = Color3.fromRGB(30, 30, 36)
	var3.ZIndex = 1001
	var3.Parent = var1
	local var4 = Instance.new("UICorner")
	var4.CornerRadius = UDim.new(0, 10)
	var4.Parent = var3
	local var5 = Instance.new("TextLabel")
	var5.BackgroundTransparency = 1
	var5.RichText = true
	var5.Size = UDim2.new(1, -24, 0.66, 0)
	var5.Position = UDim2.fromOffset(12, 12)
	var5.Font = Enum.Font.FredokaOne
	var5.TextColor3 = Color3.new(1, 1, 1)
	var5.TextWrapped = true
	var5.TextScaled = true
	var5.Text = arg2
	var5.ZIndex = 1001
	var5.Parent = var3
	local var6 = Instance.new("TextButton")
	var6.Size = UDim2.new(0.45, -8, 0.22, 0)
	var6.Position = UDim2.new(0, 8, 0.76, 0)
	var6.BackgroundColor3 = Color3.fromRGB(160, 60, 60)
	var6.Font = Enum.Font.FredokaOne
	var6.TextColor3 = Color3.new(1, 1, 1)
	var6.TextScaled = true
	var6.Text = "Cancel"
	var6.ZIndex = 1001
	var6.Parent = var3
	local var7 = Instance.new("UITextSizeConstraint")
	var7.MaxTextSize = 28
	var7.Parent = var6
	local var8 = Instance.new("UICorner")
	var8.CornerRadius = UDim.new(0, 8)
	var8.Parent = var6
	local var9 = Instance.new("TextButton")
	var9.Size = UDim2.new(0.45, -8, 0.22, 0)
	var9.Position = UDim2.new(0.55, 0, 0.76, 0)
	var9.BackgroundColor3 = Color3.fromRGB(60, 160, 90)
	var9.Font = Enum.Font.FredokaOne
	var9.TextColor3 = Color3.new(1, 1, 1)
	var9.TextScaled = true
	var9.Text = "OK"
	var9.ZIndex = 1001
	var9.Parent = var3
	local var10 = Instance.new("UITextSizeConstraint")
	var10.MaxTextSize = 28
	var10.Parent = var9
	local var11 = Instance.new("UICorner")
	var11.CornerRadius = UDim.new(0, 8)
	var11.Parent = var9
	local bool1 = false
	var9.MouseButton1Click:Connect(function()
		if not bool1 then
			bool1 = true
			var1:Destroy()
		end

		arg3()
	end)

	local function close()
		if bool1 then
			return
		end

		bool1 = true
		var1:Destroy()
	end

	var6.MouseButton1Click:Connect(close)
	var2.MouseButton1Click:Connect(close)
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var2 = var7:WaitForChild("Challenges")
	local var1 = workspace:WaitForChild("supernovachallenges"):WaitForChild("MainPart"):WaitForChild("SurfaceGui"):WaitForChild("Frame")
	local var13 = var1:WaitForChild("ChallengeDescription")
	var5 = var13:WaitForChild("Title")
	var8 = var13:WaitForChild("PenaltyText")
	var9 = var13:WaitForChild("GoalText")
	var10 = var13:WaitForChild("RewardText")
	var11 = var13:WaitForChild("TextButton")
	var5.RichText = true
	local var14 = var1:WaitForChild("ChallengeFrame")
	for k1, v1 in ipairs(var4.Order) do
		local var16 = var14:FindFirstChild(v1)
		if not var16 then
			warn("[SupernovaChallengeController] no board button found for challenge " .. v1)
		else
			local var19 = var16:WaitForChild("LevelText", 5)
			local var20 = var16:WaitForChild("CompletionText", 5)
			if var19 and var20 then
				tbl2[v1] = { LevelText = var19, CompletionText = var20 }
			else
				warn("[SupernovaChallengeController] challenge " .. v1 .. "'s tile is missing LevelText/CompletionText -- its Level/Completion readout won't update, but it's still clickable")
			end

			var16.MouseButton1Click:Connect(function()
				var3 = v1
				refreshDescription()
			end)

		end
	end

	var11.MouseButton1Click:Connect(function()
		if not var3 then
			return
		end

		local var8 = var4[var3]
		if not var8 then
			return
		end

		local var10 = var2.Active.Value
		if (if var10 and var10 ~= "" then var10 else nil) == var3 then
			var12.ChallengeCancelEvent:FireServer()
			return
		end

		local var11 = var2:FindFirstChild(var3)
		if var8.MaxLevel <= (var11 and var11.Value or 0) then
			return
		end

		var10 = var2.Active.Value
		local var14 = if var10 and var10 ~= "" then var10 else nil
		if var14 then
			var10 = var4[var14]
			showConfirm(var1, "Starting this challenge will CANCEL your current challenge (" .. (var10 and var6.resolve(var10.TitleText, var7, var10) or var14) .. ") with no rewards. Continue?", function()
				var12.ChallengeStartEvent:FireServer(var3)
			end)

			return
		end

		showConfirm(var1, "This will force a Supernova Reset for NO rewards, and begin the challenge. Continue?", function()
			var12.ChallengeStartEvent:FireServer(var3)
		end)
	end)

	var2.Active.Changed:Connect(function()
		refreshDescription()
		for k1 in pairs(tbl2) do
			refreshBoard(k1)
		end
	end)

	for k2, v2 in ipairs(var4.Order) do
		local var21 = var2:FindFirstChild(v2)
		if not var21 then
			continue
		end

		var21.Changed:Connect(function()
			refreshDescription()
			refreshBoard(v2)
		end)

	end

	for k3 in pairs(tbl2) do
		refreshBoard(k3)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Controllers.ChallengeHUDController [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Shared
local var2 = nil
local var3 = UDim2.new(1, -16, 0.2, 0)
local var4 = nil
local var5 = UDim2.new(1, 300, 0.2, 0)
local var6 = game:GetService("TweenService")
local var7 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local bool1 = false
local var8 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local num1 = 0
local function playExitTween(arg1)
	bool1 = true
	local var1 = var6:Create(var2, var8, { Position = var5 })
	var1.Completed:Connect(function()
		bool1 = false
		if arg1 ~= num1 then
			return
		end

		var2.Visible = false
		var2.Position = var3
	end)

	var1:Play()
end

local var9 = nil
local var10 = nil
local var11 = nil
local var12 = require(var1.Libs.EternityNum)
local var13 = nil
local var14 = nil
local var15 = nil
local function showComplete()
	if var4 then
		var4:Disconnect()
		var4 = nil
	end

	var2.Parent.Sound:Play()
	var2.Position = var3
	var2.Visible = true
	var9.Text = "Challenge Complete!"
	var10.Text = ""
	var11.Visible = false
	local var1 = num1
	task.delay(3, function()
		if var1 ~= num1 then
			return
		end

		playExitTween(var1)
	end)
end

local var16 = require(var1.Config.Challenges)
local var17 = require(var1.Util)
local var18 = game:GetService("Players").LocalPlayer
local var19 = nil
local function computeProgress(arg1, arg2, arg3)
	if var12.leeq(arg1, 0) then
		return 0
	end

	if arg3 == "log" then
		local var2 = var12.log(arg2, 10)
		local var3 = var12.log(arg1, 10)
		if var12.leeq(var2, 0) then
			return 0
		end

		local var4 = var3
		local var5 = var2
		local var6 = var12.toNumber(var12.div(var4, var5))
		return (math.clamp(var6, 0, 1))
	end

	local var7 = arg1
	local var8 = arg2
	local var9 = var12.toNumber(var12.div(var7, var8))
	return (math.clamp(var9, 0, 1))
end

local var20 = nil
local var21 = nil
local var22 = require(var1.Remotes)
local function refresh()
	if bool1 then
		return
	end

	local var8 = var13.Active.Value
	if not var8 or var8 == "" then
		local var21 = num1 + 1
		num1 = var21
		if var14 then
			var21 = var13:FindFirstChild(var14)
			var14 = nil
			local var22 = var15 < (var21 and var21.Value or 0)
			var15 = nil
			if var22 then
				showComplete()
				return
			end

			if var2.Visible then
				if var4 then
					var4:Disconnect()
					var4 = nil
				end

				playExitTween(num1)
				return
			end
		end

		var2.Visible = false
		var2.Position = var3
		if var4 then
			var4:Disconnect()
			var4 = nil
		end

		return
	end

	local var24 = var16[var8]
	if not var24 then
		var2.Visible = false
		var2.Position = var3
		if var4 then
			var4:Disconnect()
			var4 = nil
		end

		return
	end

	local var25 = var13:FindFirstChild(var8)
	local var26 = var25 and var25.Value or 0
	local var27 = var16.WithState(var24, var26, true)
	local var28 = var16.GoalFor(var27, var27.difficulty)
	local var29 = num1 + 1
	num1 = var29
	var14 = var8
	var15 = var26
	if not var2.Visible then
		var2.Position = var5
		var2.Visible = true
		var6:Create(var2, var7, { Position = var3 }):Play()
	else
		var2.Position = var3
		var2.Visible = true
	end

	var9.Text = var17.resolve(var27.TitleText, var18, var27)
	if var4 then
		var4:Disconnect()
		var4 = nil
	end

	if not var28 or (not var28.Stat or var28.AtLeast == nil) then
		var10.Text = var16.GetGoalText(var18, var27)
		var11.Visible = false
		return
	end

	var11.Visible = true
	local var31 = var19:FindFirstChild(var28.Stat)
	if not var31 then
		var10.Text = var16.GetGoalText(var18, var27)
		var11.Visible = false
		return
	end

	local function updateBar()
		local var1 = var31.Value
		local var2 = computeProgress(var1, var28.AtLeast, var28.Progress)
		var20.Size = UDim2.fromScale(var2, 1)
		var10.Text = var12.short(var1) .. "/" .. var12.short(var28.AtLeast) .. " " .. var28.Stat .. " (" .. math.floor(var2 * 100 + 0.5) .. "%)"
	end

	var4 = var31.Changed:Connect(updateBar)
	updateBar()
end

return { Start = function()
	repeat
		task.wait(0.5)
	until game:IsLoaded()

	var19 = var18:WaitForChild("Values")
	var13 = var18:WaitForChild("Challenges")
	var2 = var18:WaitForChild("PlayerGui"):WaitForChild("ChallengeHUD"):WaitForChild("ActiveChallenge")
	var9 = var2:WaitForChild("NameLabel")
	var10 = var2:WaitForChild("ProgressLabel")
	var11 = var2:WaitForChild("BarBackground")
	var20 = var11:WaitForChild("BarFill")
	var21 = var2:WaitForChild("CancelButton")
	var2.Visible = false
	var2.Position = var3
	var21.MouseButton1Click:Connect(function()
		var22.ChallengeCancelEvent:FireServer()
	end)

	var13.Active.Changed:Connect(refresh)
	for k1, v1 in ipairs(var16.Order) do
		local var1 = var13:FindFirstChild(v1)
		if not var1 then
			continue
		end

		var1.Changed:Connect(refresh)
	end

	refresh()
end }

--- Players.LocalPlayer.PlayerGui.AdminChatLogGUI.LocalScript [LocalScript]
-- y u r i

local var1 = game:GetService("TextChatService")
local var2 = game:GetService("UserInputService")
local var3 = Instance.new("Frame")
var3.Name = "MainFrame"
var3.Size = UDim2.new(0, 360, 0, 260)
var3.Position = UDim2.new(0.05, 0, 0.4, 0)
var3.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
var3.BorderSizePixel = 0
var3.Active = true
var3.Draggable = true
var3.Visible = false
var3.Parent = script.Parent
local var4 = Instance.new("UICorner")
var4.CornerRadius = UDim.new(0, 8)
var4.Parent = var3
local var5 = Instance.new("Frame")
var5.Name = "Header"
var5.Size = UDim2.new(1, 0, 0, 32)
var5.BackgroundColor3 = Color3.fromRGB(45, 45, 50)
var5.BorderSizePixel = 0
var5.Parent = var3
local var6 = Instance.new("UICorner")
var6.CornerRadius = UDim.new(0, 8)
var6.Parent = var5
local var7 = Instance.new("Frame")
var7.Size = UDim2.new(1, 0, 0.5, 0)
var7.Position = UDim2.new(0, 0, 0.5, 0)
var7.BackgroundColor3 = Color3.fromRGB(45, 45, 50)
var7.BorderSizePixel = 0
var7.ZIndex = 0
var7.Parent = var5
local var8 = Instance.new("TextLabel")
var8.Name = "Title"
var8.Size = UDim2.new(1, -50, 1, 0)
var8.Position = UDim2.new(0, 10, 0, 0)
var8.BackgroundTransparency = 1
var8.Text = "ADMIN CHAT LOGS"
var8.TextColor3 = Color3.fromRGB(240, 240, 240)
var8.Font = Enum.Font.SourceSansBold
var8.TextSize = 14
var8.TextXAlignment = Enum.TextXAlignment.Left
var8.Parent = var5
local var9 = Instance.new("TextButton")
var9.Name = "CloseXButton"
var9.Size = UDim2.new(0, 24, 0, 24)
var9.Position = UDim2.new(1, -28, 0, 4)
var9.BackgroundColor3 = Color3.fromRGB(255, 75, 75)
var9.Text = "X"
var9.TextColor3 = Color3.fromRGB(255, 255, 255)
var9.Font = Enum.Font.SourceSansBold
var9.TextSize = 14
var9.Parent = var5
local var10 = Instance.new("UICorner")
var10.CornerRadius = UDim.new(0, 4)
var10.Parent = var9
local var11 = Instance.new("ScrollingFrame")
var11.Name = "LogDisplay"
var11.Size = UDim2.new(1, -16, 1, -44)
var11.Position = UDim2.new(0, 8, 0, 38)
var11.BackgroundTransparency = 1
var11.BorderSizePixel = 0
var11.CanvasSize = UDim2.new(0, 0, 0, 0)
var11.ScrollBarThickness = 6
var11.ScrollBarImageColor3 = Color3.fromRGB(80, 80, 85)
var11.Parent = var3
local var12 = Instance.new("UIListLayout")
var12.SortOrder = Enum.SortOrder.LayoutOrder
var12.Padding = UDim.new(0, 4)
var12.Parent = var11
local var13 = Instance.new("TextLabel")
var13.Size = UDim2.new(1, -10, 0, 18)
var13.BackgroundTransparency = 1
var13.Font = Enum.Font.SourceSans
var13.TextSize = 15
var13.TextColor3 = Color3.fromRGB(220, 220, 220)
var13.TextXAlignment = Enum.TextXAlignment.Left
var13.TextYAlignment = Enum.TextYAlignment.Top
var13.TextWrapped = true
var13.RichText = true
var2.InputBegan:Connect(function(arg1, arg2)
	if arg2 then
		return
	end

	if arg1.KeyCode == Enum.KeyCode.P then
		var3.Visible = not var3.Visible
	end
end)

var9.MouseButton1Click:Connect(function()
	var3.Visible = false
end)

local function addLogToGui(arg1, arg2, arg3)
	local var1 = var13:Clone()
	local str3 = "[SERVER]"
	local str4 = "rgb(85, 255, 127)"
	if string.find(string.lower(arg3), "global") then
		str3 = "[GLOBAL]"
		str4 = "rgb(255, 85, 127)"
	end

	var1.Text = string.format("<font color='%s'><b>%s</b></font> <b>%s:</b> %s", str4, str3, arg1, arg2)
	var1.Parent = var11
	local var2 = var11.AbsoluteSize.X - 10
	local num1 = 10000
	var1.Size = UDim2.new(1, -10, 0, game:GetService("TextService"):GetTextSize(var1.Text, var1.TextSize, var1.Font, Vector2.new(var2, num1)).Y)
	task.wait(0.05)
	var11.CanvasPosition = Vector2.new(0, var11.AbsoluteCanvasSize.Y)
end

var1.MessageReceived:Connect(function(arg1)
	local var3 = arg1.TextSource
	local var4 = arg1.TextChannel
	if var3 and var4 then
		addLogToGui(var3.Name, arg1.Text, var4.Name)
	end
end)

--- ReplicatedStorage.SettingsDataTemplate [ModuleScript]
-- y u r i

return { FontToggle = true, CameraShake = true, BuyMaxUpgrades = {}, InstantTeleport = false }

--- ReplicatedStorage.DataTemplate [ModuleScript]
-- y u r i

return {
	Values = { Points = "0" },
	Upgrades = {},
	Challenges = {},
	ActiveChallenge = "",
	Playtime = 0,
	TutorialComplete = false,
}

--- ReplicatedStorage.CmdrClient [ModuleScript]
-- y u r i

local var1 = script:WaitForChild("Shared")
local str1 = "Util"
local var2 = game:GetService("RunService")
local var3 = game:GetService("StarterGui")
local var4 = game:GetService("Players").LocalPlayer
local var5 = require(var1:WaitForChild(str1))
if var2:IsClient() == false then
	error("Server scripts cannot require the client library. Please require the server library to use Cmdr in your own code.")
end

str1 = {
	ReplicatedRoot = script,
	RemoteFunction = script:WaitForChild("CmdrFunction"),
	Enabled = true,
	MashToEnable = false,
	ActivationUnlocksMouse = false,
	HideOnLostFocus = true,
	PlaceName = "Cmdr",
}

str1.RemoteEvent = script:WaitForChild("CmdrEvent")
str1.ActivationKeys = { [Enum.KeyCode.F2] = true }
str1.Util = var5
str1.Events = {}
local var6 = nil
var6 = setmetatable(str1, { __index = function(arg1, arg2)
	local var2 = arg1.Dispatcher[arg2]
	if var2 and type(var2) == "function" then
		return function(_, ...)
			local var1 = arg1.Dispatcher
			return var2(var1, ...)
		end

	end
end })

local var7 = require(var1.Registry)(var6)
var6.Registry = var7
var7 = require(var1.Dispatcher)(var6)
var6.Dispatcher = var7
if var3:WaitForChild("Cmdr") and (wait() and var4:WaitForChild("PlayerGui"):FindFirstChild("Cmdr") == nil) then
	var7 = var3.Cmdr:Clone()
	var7.Parent = var4.PlayerGui
end

var7 = require(script.CmdrInterface)(var6)
var6.SetActivationKeys = function(arg1, arg2)
	arg1.ActivationKeys = var5.MakeDictionary(arg2)
end

var6.SetPlaceName = function(arg1, arg2)
	arg1.PlaceName = arg2
	var7.Window:UpdateLabel()
end

var6.SetEnabled = function(arg1, arg2)
	arg1.Enabled = arg2
end

var6.SetActivationUnlocksMouse = function(arg1, arg2)
	arg1.ActivationUnlocksMouse = arg2
end

var6.Show = function(arg1)
	if not arg1.Enabled then
		return
	end

	var7.Window:Show()
end

var6.Hide = function(_)
	var7.Window:Hide()
end

var6.Toggle = function(arg1)
	if not arg1.Enabled then
		return arg1:Hide()
	end

	var7.Window:SetVisible(not var7.Window:IsVisible())
end

var6.SetMashToEnable = function(arg1, arg2)
	arg1.MashToEnable = arg2
	if arg2 then
		arg1:SetEnabled(false)
	end
end

var6.SetHideOnLostFocus = function(arg1, arg2)
	arg1.HideOnLostFocus = arg2
end

var6.HandleEvent = function(arg1, arg2, arg3)
	arg1.Events[arg2] = arg3
end

if var2:IsServer() == false then
	local str3 = "Types"
	var6.Registry:RegisterTypesIn(script:WaitForChild(str3))
	str3 = "Commands"
	var6.Registry:RegisterCommandsIn(script:WaitForChild(str3))
end

var6.RemoteEvent.OnClientEvent:Connect(function(arg1, ...)
	if var6.Events[arg1] then
		var6.Events[arg1](...)
	end
end)

require(script.DefaultEventHandlers)(var6)
return var6

--- ReplicatedStorage.CmdrClient.CmdrInterface [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
return function(arg1)
	local str1 = "Window"
	local var2 = require(script:WaitForChild(str1))
	var2.Cmdr = arg1
	local str2 = "AutoComplete"
	local var3 = require(script:WaitForChild(str2))(arg1)
	var2.AutoComplete = var3
	local var4 = arg1.Util
	var2.ProcessEntry = function(arg1)
		arg1 = var4.TrimString(arg1)
		if #arg1 == 0 then
			return
		end

		local num1 = 255
		local num2 = 223
		local num3 = 93
		var2:AddLine(var2:GetLabel() .. " " .. arg1, Color3.fromRGB(num1, num2, num3))
		num1 = arg1
		num2 = var1
		num3 = { IsHuman = true }
		var2:AddLine(arg1.Dispatcher:EvaluateAndRun(num1, num2, num3))
	end

	var2.OnTextChanged = function(arg1)
		local var5 = var4.SplitString(arg1)
		local var8 = arg1.Dispatcher:Evaluate(arg1, var1, true)
		local var9 = table.remove(var5, 1)
		local bool1 = false
		if var8 then
			var5 = var4.MashExcessArguments(var5, #var8.Object.Args)
			bool1 = #var5 == (#var8.Object.Args)
		end

		local var11 = var9
		if var11 then
			var11 = 0 < (#var5)
		end

		if arg1:sub(#arg1, #arg1):match("%s") and (not bool1) then
			var5[#var5 + 1] = ""
			var11 = true
		end

		if var8 and var11 then
			local var15, var16 = var8:Validate()
			local var17 = var16 or ""
			var2:SetIsValidInput(var15, ("Validation errors: %s"):format(var17))
			local var21 = var8:GetArgument(#var5)
			local tbl1 = {}
			if var21 then
				local var22, var23 = var21:GetAutocomplete()
				var17 = var23
				var23 = var17 or {}
				local var24 = var21.RawSegments[#var21.RawSegments]
				for k1, v1 in pairs(var22) do
					tbl1[k1] = { var24, v1 }
				end

				var17 = true
				if 0 < (#var24) then
					local var27, var28 = var21:Validate()
					var16 = var28
					var17 = var27
				end

				local var30 = bool1
				local var31 = var3
				local var32 = tbl1
				local tbl2 = {}
				if var30 then
					local var33 = #arg1 - #var24
					var30 = var33 + (if arg1:sub(#arg1, #arg1):match("%s") then -1 else 0)
				end

				tbl2.at = var30
				tbl2.prefix = #var21.RawSegments == 1 and var21.Prefix or ""
				var30 = false
				if #var8.Arguments == (#var8.ArgumentDefinitions) then
					var30 = 0 < (#var24)
				end

				tbl2.isLast = var30
				tbl2.numArgs = #var5
				tbl2.command = var8
				tbl2.arg = var21
				local var34 = var21.Name
				tbl2.name = var34 .. (if var21.Required then "" else "?")
				tbl2.type = var21.Type.DisplayName
				tbl2.description = var17 == false and var16 or var21.Object.Description
				tbl2.invalid = not var17
				tbl2.isPartial = var23.IsPartial or false
				return var31:Show(var32, tbl2)
			end
		else
			if var9 and #var5 == 0 then
				var2:SetIsValidInput(true)
				local var36 = arg1.Registry:GetCommand(var9)
				local var37 = nil
				if var36 then
					var37 = {
						var36.Name,
						var36.Name,
						options = { name = var36.Name, description = var36.Description },
					}

				end

				local tbl3 = { var37 }
				for k2, v2 in pairs(arg1.Registry:GetCommandsAsStrings()) do
					if var9:lower() ~= v2:lower():sub(1, #var9) then
						continue
					end

					if var37 == nil or var37[1] ~= var9 then
						local var38 = arg1.Registry:GetCommand(v2)
						tbl3[#tbl3 + 1] = { var9, v2, options = { name = var38.Name, description = var38.Description } }
					end
				end

				local var39 = tbl3
				return var3:Show(var39)
			end
		end

		var2:SetIsValidInput(false, "Invalid command. Use the help command to see all available commands.")
		var3:Hide()
	end

	var2:UpdateLabel()
	var2:UpdateWindowHeight()
	return { Window = var2, AutoComplete = var3 }
end

--- ReplicatedStorage.CmdrClient.CmdrInterface.Window [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = var1:WaitForChild("PlayerGui"):WaitForChild("Cmdr"):WaitForChild("Frame")
local var3 = game:GetService("GuiService")
local var4 = game:GetService("UserInputService")
local var5 = game:GetService("TextService")
local var6 = var2:WaitForChild("Line")
local var7 = var2:WaitForChild("Entry")
var6.Parent = nil
local tbl1 = {
	Valid = true,
	AutoComplete = nil,
	ProcessEntry = nil,
	OnTextChanged = nil,
	Cmdr = nil,
	HistoryState = nil,
	UpdateLabel = function(arg1)
		var7.TextLabel.Text = var1.Name .. "@" .. arg1.Cmdr.PlaceName .. "$"
		var7.TextLabel.Size = UDim2.new(0, var7.TextLabel.TextBounds.X, 0, 20)
		var7.TextBox.Position = UDim2.new(0, var7.TextLabel.Size.X.Offset + 7, 0, 0)
	end,
	GetLabel = function(_)
		return var7.TextLabel.Text
	end,
	UpdateWindowHeight = function(_)
		local num1 = 20
		for k1, v1 in pairs(var2:GetChildren()) do
			if not v1:IsA("GuiObject") then
				continue
			end

			num1 = num1 + v1.Size.Y.Offset
		end

		var2.CanvasSize = UDim2.new(var2.CanvasSize.X.Scale, var2.CanvasSize.X.Offset, 0, num1)
		local var1 = var2
		local var3 = UDim2.new
		local var4 = var2.Size.X.Scale
		local var5 = var2.Size.X.Offset
		local num2 = 0
		var1.Size = var3(var4, var5, num2, if 300 < num1 then 300 else num1)
		var2.CanvasPosition = Vector2.new(0, (math.clamp(num1 - 300, 0, math.huge)))
	end,
}

tbl1.AddLine = function(arg1, arg2, arg3)
	if #arg2 == 0 then
		tbl1:UpdateWindowHeight()
		return
	end

	local var1 = var6:Clone()
	local var3 = arg1.Cmdr.Util.EmulateTabstops(arg2 or "nil", 8)
	local var4 = var2.UIListLayout.AbsoluteContentSize.X
	local num1 = math.huge
	local var7 = UDim2.new(var1.Size.X.Scale, var1.Size.X.Offset, 0, var5:GetTextSize(var3, var1.TextSize, var1.Font, Vector2.new(var4, num1)).Y + (20 - var1.TextSize))
	var1.Size = var7
	var1.Text = var3
	var7 = arg3
	var7 = var7 or var1.TextColor3
	var1.TextColor3 = var7
	var1.Parent = var2
end

tbl1.IsVisible = function(_)
	return var2.Visible
end

tbl1.SetVisible = function(arg1, arg2)
	var2.Visible = arg2
	if arg2 then
		var7.TextBox:CaptureFocus()
		arg1:SetEntryText("")
		if not arg1.Cmdr.ActivationUnlocksMouse then
			return
		end

		arg1.PreviousMouseBehavior = var4.MouseBehavior
		var4.MouseBehavior = Enum.MouseBehavior.Default
		return
	end

	var7.TextBox:ReleaseFocus()
	arg1.AutoComplete:Hide()
	if arg1.PreviousMouseBehavior then
		var4.MouseBehavior = arg1.PreviousMouseBehavior
		arg1.PreviousMouseBehavior = nil
	end
end

tbl1.Hide = function(arg1)
	local bool1 = false
	return arg1:SetVisible(bool1)
end

tbl1.Show = function(arg1)
	local bool1 = true
	return arg1:SetVisible(bool1)
end

tbl1.SetEntryText = function(arg1, arg2)
	var7.TextBox.Text = arg2
	if arg1:IsVisible() then
		var7.TextBox:CaptureFocus()
		var7.TextBox.CursorPosition = #arg2 + 1
	end
end

tbl1.GetEntryText = function(_)
	local str1 = "\t"
	local str2 = ""
	return var7.TextBox.Text:gsub(str1, str2)
end

tbl1.SetIsValidInput = function(arg1, arg2, arg3)
	local var1 = arg2 and Color3.fromRGB(255, 255, 255) or Color3.fromRGB(255, 73, 73)
	var7.TextBox.TextColor3 = var1
	arg1.Valid = arg2
	arg1._errorText = arg3
end

tbl1.LoseFocus = function(arg1, arg2)
	arg1:ClearHistoryState()
	local var1 = var7.TextBox.Text
	if var2.Visible and (not var3.MenuIsOpen) then
		var7.TextBox:CaptureFocus()
	else
		if var3.MenuIsOpen and var2.Visible then
			arg1:Hide()
		end
	end

	if arg2 and arg1.Valid then
		wait()
		arg1:SetEntryText("")
		arg1.ProcessEntry(var1)
		return
	end

	if arg2 then
		local num4 = 255
		local num5 = 153
		local num6 = 153
		arg1:AddLine(arg1._errorText, Color3.fromRGB(num4, num5, num6))
	end
end

tbl1.TraverseHistory = function(arg1, arg2)
	local var2 = arg1.Cmdr.Dispatcher:GetHistory()
	if arg1.HistoryState == nil then
		local tbl1 = { Position = #var2 + 1, InitialText = arg1:GetEntryText() }
		arg1.HistoryState = tbl1
	end

	arg1.HistoryState.Position = math.clamp(arg1.HistoryState.Position + arg2, 1, #var2 + 1)
	arg1:SetEntryText(arg1.HistoryState.Position == #var2 + 1 and arg1.HistoryState.InitialText or var2[arg1.HistoryState.Position])
end

tbl1.ClearHistoryState = function(arg1)
	arg1.HistoryState = nil
end

tbl1.SelectVertical = function(arg1, arg2)
	if arg1.AutoComplete:IsVisible() and (not arg1.HistoryState) then
		arg1.AutoComplete:Select(arg2)
		return
	end

	arg1:TraverseHistory(arg2)
end

local num1 = 0
local num2 = 0
local tbl2 = {
	Enum.UserInputType.MouseButton1,
	Enum.UserInputType.MouseButton2,
	Enum.UserInputType.Touch,
}

tbl1.BeginInput = function(arg1, arg2, arg3)
	if var3.MenuIsOpen then
		arg1:Hide()
	end

	if arg3 and arg1:IsVisible() == false then
		return
	end

	if arg1.Cmdr.ActivationKeys[arg2.KeyCode] then
		if arg1.Cmdr.MashToEnable then
			if not arg1.Cmdr.Enabled then
				if tick() - num1 < 1 then
					if 5 <= num2 then
						local bool6 = true
						return arg1.Cmdr:SetEnabled(bool6)
					end

					local var1 = num2 + 1
					num2 = var1
				else
					num2 = 1
				end

				num1 = tick()
				return
			end
		end

		if arg1.Cmdr.Enabled then
			arg1:SetVisible(not arg1:IsVisible())
			wait()
			arg1:SetEntryText("")
			if var3.MenuIsOpen then
				arg1:Hide()
			end
		end

		return
	end

	if arg1.Cmdr.Enabled ~= false then
		if not arg1:IsVisible() then
			if arg1:IsVisible() then
				arg1:Hide()
			end

			return
		end
	end

	if arg1.Cmdr.HideOnLostFocus then
		if table.find(tbl2, arg2.UserInputType) then
			local var10 = arg2.Position
			local var11 = var2.AbsolutePosition
			local var13 = var2.AbsoluteSize
			if not (var10.X < var11.X or (var11.X + var13.X < var10.X or (var10.Y < var11.Y or var11.Y + var13.Y < var10.Y))) then
				return
			end

			if not (var11.X + var13.X < var10.X or (var10.Y < var11.Y or var11.Y + var13.Y < var10.Y)) then
				return
			end

			if not (var10.Y < var11.Y or var11.Y + var13.Y < var10.Y) then
				return
			end

			if var11.Y + var13.Y >= var10.Y then
				return
			end

			arg1:Hide()
			return
		end
	end

	if arg2.KeyCode == Enum.KeyCode.Down then
		arg1:SelectVertical(1)
		return
	end

	if arg2.KeyCode == Enum.KeyCode.Up then
		arg1:SelectVertical(-1)
		return
	end

	if arg2.KeyCode == Enum.KeyCode.Return then
		wait()
		local str1 = "\r"
		local str2 = ""
		arg1:SetEntryText(arg1:GetEntryText():gsub([[
]], ""):gsub(str1, str2))

		return
	end

	if arg2.KeyCode == Enum.KeyCode.Tab then
		local var18 = arg1.AutoComplete:GetSelectedItem()
		local var19 = arg1:GetEntryText()
		if var18 then
			if var19:sub(#var19, #var19):match("%s") then
				if not arg1.AutoComplete.LastItem then
					local var26 = arg1.AutoComplete.Command
					local var27 = var18[2]
					local var28 = nil
					local bool7 = true
					if var26 then
						var28 = var26.Alias
						local var29 = arg1.AutoComplete.Arg
						local bool8 = false
						if arg1.AutoComplete.NumArgs ~= (#var26.ArgumentDefinitions) then
							bool8 = arg1.AutoComplete.IsPartial == false
						end

						bool7 = bool8
						bool8 = var26.Arguments
						for i1 = 1, #bool8 do
							local var30 = bool8[i1]
							local var32 = var30.RawSegments
							if var30 == var29 then
								var32[#var32] = var27
							end

							local var33 = var30.Prefix .. table.concat(var32, ",")
							if var33:find(" ") then
								var33 = ("%q"):format(var33)
							end

							var28 = ("%s %s"):format(var28, var33)
							if var30 ~= var29 then
							end
						end
					else
						var28 = var27
					end

					wait()
					local var34 = var28
					arg1:SetEntryText(var34 .. (if bool7 then " " else ""))
					return
				end
			end
		end

		wait()
		arg1:SetEntryText(arg1:GetEntryText())
		return
	end

	arg1:ClearHistoryState()
end

var7.TextBox.FocusLost:Connect(function(arg1)
	local var1 = arg1
	return tbl1:LoseFocus(var1)
end)

var4.InputBegan:Connect(function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return tbl1:BeginInput(var1, var2)
end)

var7.TextBox:GetPropertyChangedSignal("Text"):Connect(function()
	if var7.TextBox.Text:match("\t") then
		var7.TextBox.Text = var7.TextBox.Text:gsub("\t", "")
		return
	end

	if tbl1.OnTextChanged then
		local var2 = var7.TextBox.Text
		return tbl1.OnTextChanged(var2)
	end
end)

var2.ChildAdded:Connect(tbl1.UpdateWindowHeight)
return tbl1

--- ReplicatedStorage.CmdrClient.CmdrInterface.AutoComplete [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
return function(arg1)
	local var2 = arg1.Util
	local var3 = var1:WaitForChild("PlayerGui"):WaitForChild("Cmdr"):WaitForChild("Autocomplete")
	local var4 = var2.MakeDictionary({ "me", "all", ".", "*", "others" })
	local var5 = var3:WaitForChild("TextButton")
	local var6 = var3:WaitForChild("Title")
	local var7 = var3:WaitForChild("Description")
	local var8 = var3.Parent:WaitForChild("Frame"):WaitForChild("Entry")
	var5.Parent = nil
	local function SetText(arg1, arg2, arg3, arg4)
		arg1.Visible = arg3 ~= nil
		arg2.Text = arg3 or ""
		if arg4 then
			local var1 = UDim2.new(0, var2.GetTextSize(arg3 or "", arg2, Vector2.new(1000, 1000), 1, 0).X, arg1.Size.Y.Scale, arg1.Size.Y.Offset)
			arg2.Size = var1
		end
	end

	local function UpdateInfoDisplay(arg1)
		SetText(var6, var6.Field, arg1.name, true)
		local var1 = arg1.type
		var1 = var1 and ": " .. arg1.type:sub(1, 1):upper() .. arg1.type:sub(2)
		var6.Field.Type.Visible = var1 ~= nil
		var6.Field.Type.Text = var1 or ""
		var1 = arg1.description
		var7.Visible = var1 ~= nil
		var7.Label.Text = var1 or ""
		local var2 = arg1.invalid and Color3.fromRGB(255, 73, 73) or Color3.fromRGB(255, 255, 255)
		var7.Label.TextColor3 = var2
		var2 = math.max(var6.Field.TextBounds.X + var6.Field.Type.TextBounds.X, var3.Size.X.Offset)
		var7.Size = UDim2.new(1, 0, 0, 40)
		repeat
			if var7.Label.TextFits then
				break
			end

			var7.Size = var7.Size + UDim2.new(0, 0, 0, 2)
		until 500 < var7.Size.Y.Offset

		wait()
		var3.UIListLayout:ApplyLayout()
		var3.Size = UDim2.new(0, var2, 0, var3.UIListLayout.AbsoluteContentSize.Y)
	end

	local tbl1 = {
		Items = {},
		ItemOptions = {},
		SelectedItem = 0,
		Show = function(arg1, arg2, arg3)
			local var1 = arg3
			arg3 = var1 or {}
			for k1, v1 in pairs(arg1.Items) do
				local var6 = v1.gui
				if not var6 then
					continue
				end

				v1.gui:Destroy()
			end

			arg1.SelectedItem = 1
			arg1.Items = arg2
			arg1.Prefix = arg3.prefix or ""
			arg1.LastItem = arg3.isLast or false
			arg1.Command = arg3.command
			arg1.Arg = arg3.arg
			arg1.NumArgs = arg3.numArgs
			arg1.IsPartial = arg3.isPartial
			var1 = 200
			for k2, v2 in pairs(arg1.Items) do
				local var7 = v2[1]
				local var10 = v2[2]
				if var4[var7] then
					var7 = var10
				end

				local var11 = var5:Clone()
				var11.Name = var7 .. var10
				var11.BackgroundTransparency = if k2 == arg1.SelectedItem then 0.5 else 1
				var11.Typed.Text = var7
				var11.Suggest.Text = string.rep(" ", #var7) .. var10:sub(#var7 + 1)
				var11.Parent = var3
				var11.LayoutOrder = k2
				local var13 = math.max(var11.Typed.TextBounds.X, var11.Suggest.TextBounds.X) + 20
				if var1 < var13 then
					var1 = var13
				end

				v2.gui = var11
			end

			var3.UIListLayout:ApplyLayout()
			local var14 = var8.TextBox.Text
			local var16 = var2.SplitString(var14)
			if var14:sub(#var14, #var14) == " " and (not arg3.at) then
				var16[#var16 + 1] = "e"
			end

			table.remove(var16, #var16)
			var3.Position = UDim2.new(0, var8.TextBox.AbsolutePosition.X - 10 + (arg3.at and arg3.at or #table.concat(var16, " ") + 1) * 7, 0, var8.TextBox.AbsolutePosition.Y + 30)
			var3.Size = UDim2.new(0, var1, 0, var3.UIListLayout.AbsoluteContentSize.Y)
			var3.Visible = true
			UpdateInfoDisplay(arg1.Items[1] and arg1.Items[1].options or arg3)
		end,
	}

	tbl1.GetSelectedItem = function(_)
		if var3.Visible == false then
			return nil
		end

		return tbl1.Items[tbl1.SelectedItem]
	end

	tbl1.Hide = function(_)
		var3.Visible = false
	end

	tbl1.IsVisible = function(_)
		return var3.Visible
	end

	tbl1.Select = function(arg1, arg2)
		if not var3.Visible then
			return
		end

		local var1 = arg1.SelectedItem + arg2
		arg1.SelectedItem = var1
		if #arg1.Items < arg1.SelectedItem then
			arg1.SelectedItem = 1
		else
			if arg1.SelectedItem < 1 then
				arg1.SelectedItem = #arg1.Items
			end
		end

		for k1, v1 in pairs(arg1.Items) do
			local var2 = v1.gui
			var2.BackgroundTransparency = if k1 == arg1.SelectedItem then 0.5 else 1
		end

		if arg1.Items[arg1.SelectedItem] then
			if arg1.Items[arg1.SelectedItem].options then
				local var4 = arg1.Items[arg1.SelectedItem].options
				UpdateInfoDisplay(var4 or {})
			end
		end
	end

	return tbl1
end

--- ReplicatedStorage.CmdrClient.DefaultEventHandlers [ModuleScript]
-- y u r i

local var1 = game:GetService("StarterGui")
local var2 = require(script.Parent.CmdrInterface.Window)
return function(arg1)
	arg1:HandleEvent("Message", function(arg1)
		local tbl1 = { Text = ("[Announcement] %s"):format(arg1) }
		tbl1.Color = Color3.fromRGB(249, 217, 56)
		var1:SetCore("ChatMakeSystemMessage", tbl1)
	end)

	arg1:HandleEvent("AddLine", function(...)
		var2:AddLine(...)
	end)
end

--- ReplicatedStorage.CmdrClient.Commands.help [ModuleScript]
-- y u r i

return {
	Name = "help",
	Description = "Displays a list of all commands, or inspects one command.",
	Group = "Help",
	Args = { {
		Type = "command",
		Name = "Command",
		Description = "The command to view information on",
		Optional = true,
	} },
	ClientRun = function(arg1, arg2)
		if arg2 then
			local var2 = arg1.Cmdr.Registry:GetCommand(arg2)
			local num4 = 230
			local num5 = 126
			local num6 = 34
			arg1:Reply(("Command: %s"):format(var2.Name), Color3.fromRGB(num4, num5, num6))
			if var2.Aliases and 0 < (#var2.Aliases) then
				num5 = var2.Aliases
				num6 = ", "
				local var4 = ("Aliases: %s"):format(table.concat(num5, num6))
				num4 = 230
				num5 = 230
				num6 = 230
				arg1:Reply(var4, Color3.fromRGB(num4, num5, num6))
			end

			num4 = 230
			num5 = 230
			num6 = 230
			arg1:Reply(var2.Description, Color3.fromRGB(num4, num5, num6))
			for k1, v1 in ipairs(var2.Args) do
				local str1 = "#%d %s%s: %s - %s"
				local var5 = k1
				local var6 = v1.Name
				local var7 = if v1.Optional == true then "?" else ""
				local var8 = v1.Type
				local var9 = v1.Description
				arg1:Reply(str1:format(var5, var6, var7, var8, var9))
			end
		else
			for k2, v2 in pairs((arg1.Cmdr.Registry:GetCommands())) do
				local var10 = v2.Name
				local var11 = v2.Description
				arg1:Reply(("%s - %s"):format(var10, var11))
			end
		end

		return ""
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.thru [ModuleScript]
-- y u r i

return {
	Name = "thru",
	Aliases = { "t", "through" },
	Description = "Teleports you through whatever your mouse is hovering over, placing you equidistantly from the wall.",
	Group = "DefaultDebug",
	Args = { {
		Type = "number",
		Name = "Extra distance",
		Description = "Go through the wall an additional X studs.",
		Default = 0,
	} },
	ClientRun = function(arg1, arg2)
		local var2 = arg1.Executor.Character
		local var3 = arg1.Executor:GetMouse()
		if not var2 or (not var2:FindFirstChild("HumanoidRootPart")) then
			return "You don't have a character."
		end

		local var4 = var2.HumanoidRootPart.Position
		local var5 = var3.Hit.p - var4
		var2:MoveTo(var5 * 2 + var5.unit * arg2 + var4)
		return "Blinked!"
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.blink [ModuleScript]
-- y u r i

return {
	Name = "blink",
	Aliases = { "b" },
	Description = "Teleports you to where your mouse is hovering.",
	Group = "DefaultDebug",
	Args = {},
	ClientRun = function(arg1)
		local var2 = arg1.Executor.Character
		local var3 = arg1.Executor:GetMouse()
		if not var2 then
			return "You don't have a character."
		end

		var2:MoveTo(var3.Hit.p)
		return "Blinked!"
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.position [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
return {
	Name = "position",
	Aliases = { "pos" },
	Description = "Returns Vector3 position of you or other players. Empty string is the player has no character.",
	Group = "DefaultDebug",
	Args = { {
		Type = "player",
		Name = "Player",
		Description = "The player to report the position of. Omit for your own position.",
		Default = var1.LocalPlayer,
	} },
	ClientRun = function(_, arg2)
		local var2 = arg2.Character
		if not var2 or (not var2:FindFirstChild("HumanoidRootPart")) then
			return ""
		end

		local str1 = "%s"
		local str2 = ""
		return tostring(var2.HumanoidRootPart.Position):gsub(str1, str2)
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.version [ModuleScript]
-- y u r i

return {
	Name = "version",
	Args = {},
	Description = "Shows the current version of Cmdr",
	Group = "DefaultDebug",
	ClientRun = function()
		local str1 = "v1.7.1"
		return ("Cmdr Version %s"):format(str1)
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.announce [ModuleScript]
-- y u r i

return {
	Name = "announce",
	Aliases = { "m" },
	Description = "Makes a server-wide announcement.",
	Group = "DefaultAdmin",
	Args = { { Type = "string", Name = "text", Description = "The announcement text." } },
}

--- ReplicatedStorage.CmdrClient.Commands.teleport [ModuleScript]
-- y u r i

return {
	Name = "teleport",
	Aliases = { "tp" },
	Description = "Teleports a player or set of players to one target.",
	Group = "DefaultAdmin",
	AutoExec = {
		"alias \"bring|Brings a player or set of players to you.\" teleport $1{players|players|The players to bring} ${me}",
		"alias \"to|Teleports you to another player or location.\" teleport ${me} $1{player @ vector3|Destination|The player or location to teleport to}",
	},
	Args = {
		{ Type = "players", Name = "From", Description = "The players to teleport" },
		{
			Type = "player @ vector3",
			Name = "Destination",
			Description = "The player to teleport to",
		},
	},
}

--- ReplicatedStorage.CmdrClient.Commands.kill [ModuleScript]
-- y u r i

return {
	Name = "kill",
	Aliases = { "slay" },
	Description = "Kills a player or set of players.",
	Group = "DefaultAdmin",
	Args = { { Type = "players", Name = "victims", Description = "The players to kill." } },
}

--- ReplicatedStorage.CmdrClient.Commands.kick [ModuleScript]
-- y u r i

return {
	Name = "kick",
	Aliases = { "boot" },
	Description = "Kicks a player or set of players.",
	Group = "DefaultAdmin",
	Args = { { Type = "players", Name = "players", Description = "The players to kick." } },
}

--- ReplicatedStorage.CmdrClient.Commands.respawn [ModuleScript]
-- y u r i

return {
	Name = "respawn",
	Description = "Respawns a player or a group of players.",
	Group = "DefaultAdmin",
	Args = { { Type = "players", Name = "targets", Description = "The players to respawn." } },
}

--- ReplicatedStorage.CmdrClient.Commands.SetValue [ModuleScript]
-- y u r i

return {
	Name = "setvalue",
	Aliases = { "sv", "stat" },
	Description = "Sets a player's value.",
	Group = "DefaultAdmin",
	Args = {
		{ Type = "players", Name = "players", Description = "Player" },
		{ Type = "stat", Name = "stat", Description = "The stat to modify" },
		{ Type = "string", Name = "value", Description = "Value (supports Scientific notations)" },
	},
}

--- ReplicatedStorage.CmdrClient.Commands.replace [ModuleScript]
-- y u r i

return {
	Name = "replace",
	Aliases = {},
	Description = "Replaces text A with text B",
	Group = "DefaultUtil",
	Args = {
		{
			Type = "string",
			Name = "Haystack",
			Description = "The source string upon which to perform replacement.",
		},
		{ Type = "string", Name = "Needle", Description = "The string pattern search for." },
		{
			Type = "string",
			Name = "Replacement",
			Description = "The string to replace matches (%1 to insert matches).",
		},
	},
	ClientRun = function(_, arg2, arg3, arg4)
		local var1 = arg3
		local var2 = arg4
		return arg2:gsub(var1, var2)
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.history [ModuleScript]
-- y u r i

return {
	Name = "history",
	Aliases = {},
	AutoExec = {
		"alias \"!|Displays previous command from history.\" run ${history $1{number|Line Number}}",
		"alias \"^|Runs the previous command, replacing all occurrences of A with B.\" run ${run replace ${history -1} $1{string|A} $2{string|B}}",
		"alias \"!!|Reruns the last command.\" ! -1",
	},
	Description = "Displays previous commands from history.",
	Group = "DefaultUtil",
	Args = { {
		Type = "integer",
		Name = "Line Number",
		Description = "Command line number (can be negative to go from end)",
	} },
	ClientRun = function(arg1, arg2)
		local var2 = arg1.Dispatcher:GetHistory()
		if arg2 <= 0 then
			arg2 = #var2 + arg2
		end

		return var2[arg2] or ""
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.alias [ModuleScript]
-- y u r i

return {
	Name = "alias",
	Aliases = {},
	Description = "Creates a new, single command out of a command and given arguments.",
	Group = "DefaultUtil",
	Args = {
		{
			Type = "string",
			Name = "Alias name",
			Description = "The key or input type you'd like to bind the command to.",
		},
		{
			Type = "string",
			Name = "Command string",
			Description = "The command text you want to run. Separate multiple commands with \"&&\". Accept arguments with $1, $2, $3, etc.",
		},
	},
	ClientRun = function(arg1, arg2, arg3)
		arg1.Cmdr.Registry:RegisterCommandObject(arg1.Cmdr.Util.MakeAliasCommand(arg2, arg3), true)
		local var1 = arg2
		return ("Created alias %q"):format(var1)
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.clear [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
return {
	Name = "clear",
	Aliases = {},
	Description = "Clear all lines above the entry line of the Cmdr window.",
	Group = "DefaultUtil",
	Args = {},
	ClientRun = function()
		local var2 = var1.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Cmdr")
		local var4 = var2:WaitForChild("Frame")
		if var2 and var4 then
			for k1, v1 in pairs(var4:GetChildren()) do
				if v1.Name ~= "Line" then
					continue
				end

				if not v1:IsA("TextLabel") then
					continue
				end

				v1:Destroy()
			end
		end

		return ""
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.run [ModuleScript]
-- y u r i

return {
	Name = "run",
	Aliases = {},
	AutoExec = { [[alias discard replace ${run $1} .* \"\"]] },
	Description = "Runs a given command string (replacing embedded commands).",
	Group = "DefaultUtil",
	Args = { { Type = "string", Name = "Command", Description = "The command string to run" } },
	ClientRun = function(arg1, arg2)
		local var1 = arg1.Dispatcher
		local var2 = arg2
		return arg1.Dispatcher:EvaluateAndRun(arg1.Cmdr.Util.RunEmbeddedCommands(var1, var2))
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.hover [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
return {
	Name = "hover",
	Description = "Returns the name of the player you are hovering over.",
	Group = "DefaultUtil",
	Args = {},
	ClientRun = function()
		local var3 = var1.LocalPlayer:GetMouse().Target
		if not var3 then
			return ""
		end

		local str1 = "Model"
		local var4 = var1:GetPlayerFromCharacter(var3:FindFirstAncestorOfClass(str1))
		return var4 and var4.Name or ""
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.bind [ModuleScript]
-- y u r i

local var1 = game:GetService("UserInputService")
return {
	Name = "bind",
	Aliases = {},
	Description = "Binds a command string to a key or mouse input.",
	Group = "DefaultUtil",
	Args = {
		{
			Type = "userInput ! bindableResource @ player",
			Name = "Input",
			Description = "The key or input type you'd like to bind the command to.",
		},
		{
			Type = "command",
			Name = "Command",
			Description = "The command you want to run on this input",
		},
		{
			Type = "string",
			Name = "Arguments",
			Description = "The arguments for the command",
			Default = "",
		},
	},
	ClientRun = function(arg1, arg2, arg3, arg4)
		local var2 = arg1:GetStore("CMDR_Binds")
		arg3 = arg3 .. " " .. arg4
		if var2[arg2] then
			var2[arg2]:Disconnect()
		end

		local var4 = arg1:GetArgument(1).Type.Name
		if var4 == "userInput" then
			var2[arg2] = var1.InputBegan:Connect(function(arg1, arg2)
				if arg2 then
					return
				end

				if arg1.UserInputType == arg2 or arg1.KeyCode == arg2 then
					local var3 = arg1.Dispatcher
					local var4 = arg3
					arg1:Reply(arg1.Dispatcher:EvaluateAndRun(arg1.Cmdr.Util.RunEmbeddedCommands(var3, var4)))
				end
			end)

		elseif var4 == "bindableResource" then
			return "Unimplemented..."
		end

		return "Bound command to input."
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.runif [ModuleScript]
-- y u r i

local tbl1 = { startsWith = function(arg1, arg2)
	if arg1:sub(1, #arg2) == arg2 then
		local var2 = #arg2 + 1
		return arg1:sub(var2)
	end
end }

return {
	Name = "runif",
	Aliases = {},
	Description = "Runs a given command string if a certain condition is met.",
	Group = "DefaultUtil",
	Args = {
		{ Type = "conditionFunction", Name = "Condition", Description = "The condition function" },
		{
			Type = "string",
			Name = "Argument",
			Description = "The argument to the condition function",
		},
		{ Type = "string", Name = "Test against", Description = "The text to test against." },
		{
			Type = "string",
			Name = "Command",
			Description = "The command string to run if requirements are met. If omitted, return value from condition function is used.",
			Optional = true,
		},
	},
	ClientRun = function(arg1, arg2, arg3, arg4, arg5)
		local var3 = tbl1[arg2]
		if not var3 then
			local var4 = arg2
			return ("Condition %q is not valid."):format(var4)
		end

		local var8 = var3(arg4, arg3)
		if var8 then
			local var9 = arg1.Dispatcher
			local var10 = arg5 or var8
			return arg1.Dispatcher:EvaluateAndRun(arg1.Cmdr.Util.RunEmbeddedCommands(var9, var10))
		end

		return ""
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.echo [ModuleScript]
-- y u r i

return {
	Name = "echo",
	Aliases = {},
	Description = "Echoes your text back to you.",
	Group = "DefaultUtil",
	Args = { { Type = "string", Name = "Text", Description = "The text." } },
	ClientRun = function(_, arg2)
		return arg2
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.unbind [ModuleScript]
-- y u r i

return {
	Name = "unbind",
	Aliases = {},
	Description = "Unbinds an input previously bound with Bind",
	Group = "DefaultUtil",
	Args = { {
		Type = "userInput ! bindableResource @ player",
		Name = "Input/Key",
		Description = "The key or input type you'd like to unbind.",
	} },
	ClientRun = function(arg1, arg2)
		local var1 = arg1:GetStore("CMDR_Binds")
		if var1[arg2] then
			var1[arg2]:Disconnect()
			var1[arg2] = nil
			return "Unbound command from input."
		end

		return "That input wasn't bound."
	end,
}

--- ReplicatedStorage.CmdrClient.Commands.me [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
return {
	Name = "me",
	Aliases = {},
	Description = "Displays the current player's name.",
	Group = "DefaultUtil",
	Args = {},
	ClientRun = function()
		return var1.LocalPlayer.Name
	end,
}

--- ReplicatedStorage.CmdrClient.Types.Player [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local function CheckShorthands(arg1, arg2, ...)
	for k1, v1 in pairs({ ... }) do
		local var1 = v1(arg1, arg2)
		if not var1 then
			continue
		end

		return var1
	end
end

local function ShorthandSingle(arg1, arg2)
	if arg1 == "." or arg1 == "me" then
		return { arg2 }
	end

	if arg1 == "?" then
		local var3 = var1:GetPlayers()
		return { var3[math.random(1, #var3)] }
	end
end

local var2 = require(script.Parent.Parent.Shared.Util)
local function ShorthandMultiple(arg1, arg2)
	if arg1 == "*" or arg1 == "all" then
		return var1:GetPlayers()
	end

	if arg1 == "others" then
		local var3 = var1:GetPlayers()
		for i1 = 1, #var3 do
			if var3[i1] ~= arg2 then
				continue
			end

			table.remove(var3, i1)
			return var3
		end

		return var3
	end

	local var5 = arg1:match("%?(%d+)")
	local var6 = tonumber(var5)
	if var5 and (var6 and 0 < var6) then
		local var7 = var1:GetPlayers()
		local tbl1 = {}
		for i2 = 1, math.min(var6, #var7) do
			local num1 = 1
			local var8 = #var7
			local var9 = var7
			table.insert(tbl1, table.remove(var9, math.random(num1, var8)))
		end

		return tbl1
	end
end

local tbl1 = {
	Transform = function(arg1, arg2)
		local var4 = CheckShorthands(arg1, arg2, ShorthandSingle)
		if var4 then
			return var4
		end

		local var5 = arg1
		return var2.MakeFuzzyFinder(var1:GetPlayers())(var5)
	end,
	Validate = function(arg1)
		return 0 < (#arg1), "No player with that name could be found."
	end,
	Autocomplete = function(arg1)
		local var1 = arg1
		return var2.GetNames(var1)
	end,
	Parse = function(arg1)
		return arg1[1]
	end,
}

local tbl2 = {
	Listable = true,
	Prefixes = "% teamPlayers",
	Transform = function(arg1, arg2)
		local var4 = CheckShorthands(arg1, arg2, ShorthandSingle, ShorthandMultiple)
		if var4 then
			return var4, true
		end

		local var5 = arg1
		return var2.MakeFuzzyFinder(var1:GetPlayers())(var5)
	end,
	Validate = function(arg1)
		return 0 < (#arg1), "No players were found matching that query."
	end,
	Autocomplete = function(arg1)
		local var1 = arg1
		return var2.GetNames(var1)
	end,
	Parse = function(arg1, arg2)
		local var3
		if arg2 then
			local var2 = arg1
			if not var2 then
				var2 = { arg1[1] }
			end
		end

		return var3
	end,
}

return function(arg1)
	arg1:RegisterType("player", tbl1)
	arg1:RegisterType("players", tbl2)
end

--- ReplicatedStorage.CmdrClient.Types.Primitives [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local var2 = var1.MakeDictionary({ "true", "t", "yes", "y", "on", "enable", "enabled", "1", "+" })
local var3 = var1.MakeDictionary({ "false", "f", "no", "n", "off", "disable", "disabled", "0", "-" })
local var4 = nil
local tbl1 = {
	Validate = function(arg1)
		return arg1 ~= nil
	end,
	Parse = function(arg1)
		return (tostring(arg1))
	end,
}

local tbl2 = {
	Transform = function(arg1)
		return (tonumber(arg1))
	end,
	Validate = function(arg1)
		return arg1 ~= nil
	end,
	Parse = function(arg1)
		return arg1
	end,
}

local tbl3 = {
	Transform = function(arg1)
		return (tonumber(arg1))
	end,
	Validate = function(arg1)
		local bool1 = false
		if arg1 ~= nil then
			bool1 = arg1 == math.floor(arg1)
		end

		return bool1, "Only whole numbers are valid."
	end,
	Parse = function(arg1)
		return arg1
	end,
}

var4 = {
	Transform = function(arg1)
		return arg1:lower()
	end,
	Validate = function(arg1)
		local bool1 = true
		if var2[arg1] == nil then
			bool1 = var3[arg1] ~= nil
		end

		return bool1, "Please use true/yes/on or false/no/off."
	end,
	Parse = function(arg1)
		if var2[arg1] then
			return true
		end

		if var3[arg1] then
			return false
		end

		error("Unknown boolean value.")
	end,
}

return function(arg1)
	arg1:RegisterType("string", tbl1)
	arg1:RegisterType("number", tbl2)
	arg1:RegisterType("integer", tbl3)
	arg1:RegisterType("boolean", var4)
	local var2 = tbl1
	arg1:RegisterType("strings", var1.MakeListableType(var2))
	var2 = tbl2
	arg1:RegisterType("numbers", var1.MakeListableType(var2))
	var2 = tbl3
	arg1:RegisterType("integers", var1.MakeListableType(var2))
	var2 = var4
	arg1:RegisterType("booleans", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.Team [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local var2 = game:GetService("Teams")
local tbl1 = {
	Transform = function(arg1)
		local var3 = arg1
		return var1.MakeFuzzyFinder(var2:GetTeams())(var3)
	end,
	Validate = function(arg1)
		return 0 < (#arg1), "No team with that name could be found."
	end,
	Autocomplete = function(arg1)
		local var2 = arg1
		return var1.GetNames(var2)
	end,
	Parse = function(arg1)
		return arg1[1]
	end,
}

local tbl2 = {
	Listable = true,
	Transform = tbl1.Transform,
	Validate = tbl1.Validate,
	Autocomplete = tbl1.Autocomplete,
	Parse = function(arg1)
		return arg1[1]:GetPlayers()
	end,
}

local tbl3 = {
	Transform = tbl1.Transform,
	Validate = tbl1.Validate,
	Autocomplete = tbl1.Autocomplete,
	Parse = function(arg1)
		return arg1[1].TeamColor
	end,
}

return function(arg1)
	arg1:RegisterType("team", tbl1)
	local var2 = tbl1
	arg1:RegisterType("teams", var1.MakeListableType(var2))
	arg1:RegisterType("teamPlayers", tbl2)
	arg1:RegisterType("teamColor", tbl3)
	var2 = tbl3
	arg1:RegisterType("teamColors", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.Command [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
return function(arg1)
	local tbl1 = {
		Transform = function(arg1)
			local var2 = arg1
			return var1.MakeFuzzyFinder(arg1:GetCommandsAsStrings())(var2)
		end,
		Validate = function(arg1)
			return 0 < (#arg1), "No command with that name could be found."
		end,
		Autocomplete = function(arg1)
			return arg1
		end,
		Parse = function(arg1)
			return arg1[1]
		end,
	}

	arg1:RegisterType("command", tbl1)
	local var2 = tbl1
	arg1:RegisterType("commands", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.PlayerId [ModuleScript]
-- y u r i

local tbl1 = {}
local var1 = game:GetService("Players")
local var2 = require(script.Parent.Parent.Shared.Util)
local tbl2 = {
	DisplayName = "Full Player Name",
	Prefixes = "# integer",
	Transform = function(arg1)
		local var3 = arg1
		return arg1, var2.MakeFuzzyFinder(var1:GetPlayers())(var3)
	end,
	ValidateOnce = function(arg1)
		local var2
		if tbl1[arg1] then
			var2 = tbl1[arg1]
		else
			if var1:FindFirstChild(arg1) then
				tbl1[arg1] = var1[arg1].UserId
				var2 = var1[arg1].UserId
			else
				local success, result = pcall(var1.GetUserIdFromNameAsync, var1, arg1)
				if not success then
					var2 = nil
				else
					tbl1[arg1] = result
					var2 = result
				end
			end
		end

		local var3 = var2 ~= nil
		return var3, "No player with that name could be found."
	end,
	Autocomplete = function(_, arg2)
		local var1 = arg2
		return var2.GetNames(var1)
	end,
	Parse = function(arg1)
		if tbl1[arg1] then
			return tbl1[arg1]
		end

		if var1:FindFirstChild(arg1) then
			tbl1[arg1] = var1[arg1].UserId
			return var1[arg1].UserId
		end

		local success, result = pcall(var1.GetUserIdFromNameAsync, var1, arg1)
		if not success then
			return nil
		end

		tbl1[arg1] = result
		return result
	end,
}

return function(arg1)
	arg1:RegisterType("playerId", tbl2)
	local var1 = tbl2
	local tbl1 = { Prefixes = "# integers" }
	arg1:RegisterType("playerIds", var2.MakeListableType(var1, tbl1))
end

--- ReplicatedStorage.CmdrClient.Types.UserInput [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local var2 = Enum.UserInputType:GetEnumItems()
for k1, v1 in pairs(Enum.KeyCode:GetEnumItems()) do
	var2[#var2 + 1] = v1
end

local tbl1 = {
	Transform = function(arg1)
		local var3 = arg1
		return var1.MakeFuzzyFinder(var2)(var3)
	end,
	Validate = function(arg1)
		return 0 < (#arg1)
	end,
	Autocomplete = function(arg1)
		local var2 = arg1
		return var1.GetNames(var2)
	end,
	Parse = function(arg1)
		return arg1[1]
	end,
}

return function(arg1)
	arg1:RegisterType("userInput", tbl1)
	local var2 = tbl1
	arg1:RegisterType("userInputs", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.BindableResource [ModuleScript]
-- y u r i

return function(arg1)
	local str1 = "BindableResource"
	local tbl1 = { "Chat" }
	arg1:RegisterType("bindableResource", arg1.Cmdr.Util.MakeEnumType(str1, tbl1))
end

--- ReplicatedStorage.CmdrClient.Types.ConditionFunction [ModuleScript]
-- y u r i

return function(arg1)
	local str1 = "ConditionFunction"
	local tbl1 = { "startsWith" }
	arg1:RegisterType("conditionFunction", arg1.Cmdr.Util.MakeEnumType(str1, tbl1))
end

--- ReplicatedStorage.CmdrClient.Types.Duration [ModuleScript]
-- y u r i

local tbl1 = {
	Years = 31556926,
	Months = 2629744,
	Weeks = 604800,
	Days = 86400,
	Hours = 3600,
	Minutes = 60,
	Seconds = 1,
}

local var1 = require(script.Parent.Parent.Shared.Util)
local tbl2 = {}
for k1, v1 in pairs(tbl1) do
	table.insert(tbl2, k1)
end

local var2 = var1.MakeFuzzyFinder(tbl2)
local function stringToSecondDuration(arg1)
	if arg1 == nil or arg1 == "" then
		return nil
	end

	local var3 = tonumber(arg1)
	if var3 and var3 == 0 then
		return 0, 0, true
	end

	local var5 = arg1:gsub("-?%d+%a+", ""):match("-?%d+")
	if var5 then
		return nil, tonumber(var5), true
	end

	local var6 = nil
	local var7 = nil
	local var8 = nil
	for k1 in arg1:gmatch("-?%d+%a+") do
		local var9, var10 = k1:match("(-?%d+)(%a+)")
		var7 = var9
		var8 = var10
		var9 = var2(var8)
		if #var9 == 0 then
			return nil, (tonumber(var7))
		end

		if var6 == nil then
			var6 = 0
		end

		var6 = var6 + (if var8:lower() == "m" then 60 else tbl1[var9[1]]) * tonumber(var7)
	end

	if var6 == nil then
		return nil
	end

	return var6, (tonumber(var7))
end

local function mapUnits(arg1, arg2, arg3, arg4)
	arg4 = arg4 or 1
	local tbl1 = {}
	for k1, v1 in pairs(arg1) do
		if arg3 == 1 then
			tbl1[k1] = arg2 .. v1:sub(arg4, #v1 - 1)
		else
			tbl1[k1] = arg2 .. v1:sub(arg4)
		end
	end

	return tbl1
end

local tbl3 = {
	Transform = function(arg1)
		local var1 = arg1
		return arg1, stringToSecondDuration(var1)
	end,
	Validate = function(_, arg2)
		return arg2 ~= nil
	end,
	Autocomplete = function(arg1, arg2, arg3, arg4, arg5)
		local tbl2 = {}
		if not arg4 then
			if arg5 then
				local var5 = arg4 == true and var2("") or arg5
				if arg4 == true then
					return (mapUnits(var5, arg1, arg3))
				end

				return (mapUnits(var5, arg1, arg1:match("^.*(%a+)$"):len() + 1))
			end
		end

		if arg2 ~= nil then
			local var7 = arg1:match("^.*-?%d+(%a+)$")
			tbl2 = mapUnits(var2(var7), arg1, arg3, #var7 + 1)
			table.sort(tbl2)
		end

		return tbl2
	end,
	Parse = function(_, arg2)
		return arg2
	end,
}

return function(arg1)
	arg1:RegisterType("duration", tbl3)
	local var2 = tbl3
	arg1:RegisterType("durations", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.BrickColor [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local var2 = var1.MakeFuzzyFinder({
	"White",
	"Grey",
	"Light yellow",
	"Brick yellow",
	"Light green (Mint)",
	"Light reddish violet",
	"Pastel Blue",
	"Light orange brown",
	"Nougat",
	"Bright red",
	"Med. reddish violet",
	"Bright blue",
	"Bright yellow",
	"Earth orange",
	"Black",
	"Dark grey",
	"Dark green",
	"Medium green",
	"Lig. Yellowich orange",
	"Bright green",
	"Dark orange",
	"Light bluish violet",
	"Transparent",
	"Tr. Red",
	"Tr. Lg blue",
	"Tr. Blue",
	"Tr. Yellow",
	"Light blue",
	"Tr. Flu. Reddish orange",
	"Tr. Green",
	"Tr. Flu. Green",
	"Phosph. White",
	"Light red",
	"Medium red",
	"Medium blue",
	"Light grey",
	"Bright violet",
	"Br. yellowish orange",
	"Bright orange",
	"Bright bluish green",
	"Earth yellow",
	"Bright bluish violet",
	"Tr. Brown",
	"Medium bluish violet",
	"Tr. Medi. reddish violet",
	"Med. yellowish green",
	"Med. bluish green",
	"Light bluish green",
	"Br. yellowish green",
	"Lig. yellowish green",
	"Med. yellowish orange",
	"Br. reddish orange",
	"Bright reddish violet",
	"Light orange",
	"Tr. Bright bluish violet",
	"Gold",
	"Dark nougat",
	"Silver",
	"Neon orange",
	"Neon green",
	"Sand blue",
	"Sand violet",
	"Medium orange",
	"Sand yellow",
	"Earth blue",
	"Earth green",
	"Tr. Flu. Blue",
	"Sand blue metallic",
	"Sand violet metallic",
	"Sand yellow metallic",
	"Dark grey metallic",
	"Black metallic",
	"Light grey metallic",
	"Sand green",
	"Sand red",
	"Dark red",
	"Tr. Flu. Yellow",
	"Tr. Flu. Red",
	"Gun metallic",
	"Red flip/flop",
	"Yellow flip/flop",
	"Silver flip/flop",
	"Curry",
	"Fire Yellow",
	"Flame yellowish orange",
	"Reddish brown",
	"Flame reddish orange",
	"Medium stone grey",
	"Royal blue",
	"Dark Royal blue",
	"Bright reddish lilac",
	"Dark stone grey",
	"Lemon metalic",
	"Light stone grey",
	"Dark Curry",
	"Faded green",
	"Turquoise",
	"Light Royal blue",
	"Medium Royal blue",
	"Rust",
	"Brown",
	"Reddish lilac",
	"Lilac",
	"Light lilac",
	"Bright purple",
	"Light purple",
	"Light pink",
	"Light brick yellow",
	"Warm yellowish orange",
	"Cool yellow",
	"Dove blue",
	"Medium lilac",
	"Slime green",
	"Smoky grey",
	"Dark blue",
	"Parsley green",
	"Steel blue",
	"Storm blue",
	"Lapis",
	"Dark indigo",
	"Sea green",
	"Shamrock",
	"Fossil",
	"Mulberry",
	"Forest green",
	"Cadet blue",
	"Electric blue",
	"Eggplant",
	"Moss",
	"Artichoke",
	"Sage green",
	"Ghost grey",
	"Lilac",
	"Plum",
	"Olivine",
	"Laurel green",
	"Quill grey",
	"Crimson",
	"Mint",
	"Baby blue",
	"Carnation pink",
	"Persimmon",
	"Maroon",
	"Gold",
	"Daisy orange",
	"Pearl",
	"Fog",
	"Salmon",
	"Terra Cotta",
	"Cocoa",
	"Wheat",
	"Buttermilk",
	"Mauve",
	"Sunrise",
	"Tawny",
	"Rust",
	"Cashmere",
	"Khaki",
	"Lily white",
	"Seashell",
	"Burgundy",
	"Cork",
	"Burlap",
	"Beige",
	"Oyster",
	"Pine Cone",
	"Fawn brown",
	"Hurricane grey",
	"Cloudy grey",
	"Linen",
	"Copper",
	"Dirt brown",
	"Bronze",
	"Flint",
	"Dark taupe",
	"Burnt Sienna",
	"Institutional white",
	"Mid gray",
	"Really black",
	"Really red",
	"Deep orange",
	"Alder",
	"Dusty Rose",
	"Olive",
	"New Yeller",
	"Really blue",
	"Navy blue",
	"Deep blue",
	"Cyan",
	"CGA brown",
	"Magenta",
	"Pink",
	"Deep orange",
	"Teal",
	"Toothpaste",
	"Lime green",
	"Camo",
	"Grime",
	"Lavender",
	"Pastel light blue",
	"Pastel orange",
	"Pastel violet",
	"Pastel blue-green",
	"Pastel green",
	"Pastel yellow",
	"Pastel brown",
	"Royal purple",
	"Hot pink",
})

local tbl1 = {
	Prefixes = "% teamColor",
	Transform = function(arg1)
		local var1 = arg1
		local tbl1 = {}
		for k1, v1 in pairs(var2(var1)) do
			tbl1[k1] = BrickColor.new(v1)
		end

		return tbl1
	end,
	Validate = function(arg1)
		return 0 < (#arg1), "No valid brick colors with that name could be found."
	end,
	Autocomplete = function(arg1)
		local var2 = arg1
		return var1.GetNames(var2)
	end,
	Parse = function(arg1)
		return arg1[1]
	end,
}

local tbl2 = {
	Transform = tbl1.Transform,
	Validate = tbl1.Validate,
	Autocomplete = tbl1.Autocomplete,
	Parse = function(arg1)
		return arg1[1].Color
	end,
}

return function(arg1)
	arg1:RegisterType("brickColor", tbl1)
	local var2 = tbl1
	local tbl3 = { Prefixes = "% teamColors" }
	arg1:RegisterType("brickColors", var1.MakeListableType(var2, tbl3))
	arg1:RegisterType("brickColor3", tbl2)
	var2 = tbl2
	arg1:RegisterType("brickColor3s", var1.MakeListableType(var2))
end

--- ReplicatedStorage.CmdrClient.Types.Color3 [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local function parseHexDigit(arg1)
	if #arg1 == 1 then
		arg1 = arg1 .. arg1
	end

	return (tonumber(arg1, 16))
end

local var2 = var1.MakeSequenceType({
	Prefixes = "# hexColor3 ! brickColor3",
	ValidateEach = function(arg1, arg2)
		if arg1 == nil then
			local var2 = arg2
			return false, ("Invalid or missing number at position %d in Color3 type."):format(var2)
		end

		if arg1 < 0 or 255 < arg1 then
			local var4 = arg2
			return false, ("Number out of acceptable range 0-255 at position %d in Color3 type."):format(var4)
		end

		if arg1 % 1 ~= 0 then
			local var6 = arg2
			return false, ("Number is not an integer at position %d in Color3 type."):format(var6)
		end

		return true
	end,
	TransformEach = tonumber,
	Constructor = Color3.fromRGB,
	Length = 3,
})

local tbl1 = {
	Transform = function(arg1)
		local var2, var3, var4 = arg1:match("^#?(%x%x?)(%x%x?)(%x%x?)$")
		local var5 = parseHexDigit
		local var6 = var2
		local var7 = var3
		local var8 = var4
		return var1.Each(var5, var6, var7, var8)
	end,
	Validate = function(arg1, arg2, arg3)
		local bool2 = false
		if arg1 ~= nil then
			bool2 = false
			if arg2 ~= nil then
				bool2 = arg3 ~= nil
			end
		end

		return bool2, "Invalid hex color"
	end,
	Parse = function(...)
		return Color3.fromRGB(...)
	end,
}

return function(arg1)
	arg1:RegisterType("color3", var2)
	local var3 = var2
	local tbl2 = { Prefixes = "# hexColor3s ! brickColor3s" }
	arg1:RegisterType("color3s", var1.MakeListableType(var3, tbl2))
	arg1:RegisterType("hexColor3", tbl1)
	var3 = tbl1
	arg1:RegisterType("hexColor3s", var1.MakeListableType(var3))
end

--- ReplicatedStorage.CmdrClient.Types.Vector [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.Shared.Util)
local function validateVector(arg1, arg2)
	if arg1 == nil then
		local var2 = arg2
		return false, ("Invalid or missing number at position %d in Vector type."):format(var2)
	end

	return true
end

local var2 = var1.MakeSequenceType({
	ValidateEach = validateVector,
	TransformEach = tonumber,
	Constructor = Vector3.new,
	Length = 3,
})

local var3 = var1.MakeSequenceType({
	ValidateEach = validateVector,
	TransformEach = tonumber,
	Constructor = Vector2.new,
	Length = 2,
})

return function(arg1)
	arg1:RegisterType("vector3", var2)
	local var4 = var2
	arg1:RegisterType("vector3s", var1.MakeListableType(var4))
	arg1:RegisterType("vector2", var3)
	var4 = var3
	arg1:RegisterType("vector2s", var1.MakeListableType(var4))
end

--- ReplicatedStorage.CmdrClient.Types.Stat [ModuleScript]
-- y u r i

return function(arg1)
	arg1:RegisterType("stat", {
		Transform = function(arg1)
			return arg1
		end,
		Validate = function(arg1)
			local var2 = game.Players:GetPlayers()[1]
			if not var2 then
				return false, "No players in server."
			end

			local var4 = var2:FindFirstChild("Values")
			if not var4 then
				return false, "Values folder not found."
			end

			if var4:FindFirstChild(arg1) then
				return true
			end

			return false, "Unknown stat."
		end,
		Autocomplete = function()
			local var3 = game.Players:GetPlayers()[1]
			local var4 = var3:FindFirstChild("Values")
			local tbl1 = {}
			if var3 and var4 then
				for k1, v1 in ipairs(var4:GetChildren()) do
					if not v1:IsA("StringValue") then
						continue
					end

					table.insert(tbl1, v1.Name)
				end
			end

			table.sort(tbl1)
			return tbl1
		end,
		Parse = function(arg1)
			return arg1
		end,
	})
end

--- ReplicatedStorage.CmdrClient.Types.playersOrGlobal [ModuleScript]
-- y u r i

return function(arg1)
	return {
		Transform = function(arg1)
			if string.lower(arg1) == "global" then
				return "global"
			end

			local var1 = arg1.Util.GetPlayers(arg1)
			if #var1 == 0 then
				return nil, "No players found."
			end

			return var1
		end,
		Validate = function(arg1)
			return arg1 ~= nil
		end,
		Autocomplete = function()
			return { "global", "me", "all" }
		end,
	}
end

--- ReplicatedStorage.CmdrClient.Types.Admins [ModuleScript]
-- y u r i

local tbl1 = { [2577214977] = true, [1837214769] = true }
return function(arg1)
	arg1:RegisterHook("BeforeRun", function(arg1)
		if arg1.Group == "DefaultAdmin" and (not tbl1[arg1.Executor.UserId]) then
			return "You don't have permission to run this command"
		end
	end)
end

--- ReplicatedStorage.CmdrClient.Shared.Util [ModuleScript]
-- y u r i

local var1 = game:GetService("TextService")
local function charCode(arg1)
	local var1 = tonumber(arg1, 16)
	return utf8.char(var1)
end

local tbl1 = {
	MakeDictionary = function(arg1)
		local tbl1 = {}
		for i1 = 1, #arg1 do
			tbl1[arg1[i1]] = true
		end

		return tbl1
	end,
	MakeFuzzyFinder = function(arg1)
		local var1 = nil
		local tbl1 = {}
		if typeof(arg1) == "Enum" then
			arg1 = arg1:GetEnumItems()
		end

		if typeof(arg1) == "Instance" then
			local var3 = arg1:GetChildren()
			local tbl2 = {}
			for i1 = 1, #var3 do
				tbl2[i1] = var3[i1].Name
			end

			var1 = tbl2
			tbl1 = var3
		else
			if typeof(arg1) == "table" then
				if typeof(arg1[1]) == "Instance" or (typeof(arg1[1]) == "EnumItem" or typeof(arg1[1]) == "table" and typeof(arg1[1].Name) == "string") then
					local tbl3 = {}
					for i2 = 1, #arg1 do
						tbl3[i2] = arg1[i2].Name
					end

					var1 = tbl3
					tbl1 = arg1
				else
					if type(arg1[1]) == "string" then
						var1 = arg1
					else
						if arg1[1] ~= nil then
							error("MakeFuzzyFinder only accepts tables of instances or strings.")
						else
							var1 = {}
						end
					end
				end
			else
				error("MakeFuzzyFinder only accepts a table, Enum, or Instance.")
			end
		end

		return function(arg1, arg2)
			local tbl2 = {}
			for k1, v1 in pairs(var1) do
				local var2 = tbl1 and tbl1[k1] or v1
				if v1:lower() == arg1:lower() then
					if arg2 then
						return var2
					end

					table.insert(tbl2, 1, var2)
				else
					if v1:lower():sub(1, #arg1) ~= arg1:lower() then
						continue
					end

					tbl2[#tbl2 + 1] = var2
				end
			end

			if arg2 then
				return tbl2[1]
			end

			return tbl2
		end
	end,
	GetNames = function(arg1)
		local tbl1 = {}
		for i1 = 1, #arg1 do
			local var2 = arg1[i1].Name
			if not var2 then
				var2 = tostring(arg1[i1])
			end

			tbl1[i1] = var2
		end

		return tbl1
	end,
	SplitStringSimple = function(arg1, arg2)
		if arg2 == nil then
			arg2 = "%s"
		end

		local str1 = "([^"
		local tbl1 = {}
		local num1 = 1
		for k1 in string.gmatch(arg1, str1 .. arg2 .. "]+)") do
			tbl1[num1] = k1
			num1 = num1 + 1
		end

		return tbl1
	end,
	ParseEscapeSequences = function(arg1)
		local str1 = "\\x(%x%x)"
		local var1 = charCode
		return arg1:gsub("\\(.)", {
			t = "\t",
			n = [[
]],
		}):gsub("\\u(%x%x%x%x)", charCode):gsub(str1, var1)
	end,
}

tbl1.SplitString = function(arg1, arg2)
	arg2 = arg2 or math.huge
	local tbl2 = {}
	local var1 = nil
	local var2 = nil
	for k1 in arg1:gsub("\\\\", "\17"):gsub("\\\"", "\18"):gsub("\\'", "\19"):gmatch("%S+") do
		k1 = tbl1.ParseEscapeSequences(k1)
		local var5 = k1:match("^(['\"])")
		local var6 = k1:match("(['\"])$")
		local var7 = k1:match("(\\*)['\"]$")
		if var5 and (not var2 and (not var6)) then
			var1 = k1
			var2 = var5
		else
			if var1 and (var6 == var2 and #var7 % 2 == 0) then
				k1 = var1 .. " " .. k1
				var1 = nil
			elseif var1 then
				var1 = var1 .. " " .. k1
			end
		end

		if var1 then
			continue
		end

		local var8 = #tbl2
		local var9 = var8 + (if arg2 < (#tbl2) then 0 else 1)
		tbl2[var9] = k1:gsub("^(['\"])", ""):gsub("(['\"])$", ""):gsub("\17", "\\"):gsub("\18", "\""):gsub("\19", "'")
		local var10 = nil
	end

	if var1 then
		local var11 = #tbl2
		local var12 = var11 + (if arg2 < (#tbl2) then 0 else 1)
		tbl2[var12] = var1:gsub("\17", "\\"):gsub("\18", "\""):gsub("\19", "'")
	end

	return tbl2
end

tbl1.MashExcessArguments = function(arg1, arg2)
	local tbl1 = {}
	for i1 = 1, #arg1 do
		if arg2 < i1 then
			local var1 = ("%s %s"):format(tbl1[arg2] or "", arg1[i1])
			tbl1[arg2] = var1
		else
			tbl1[i1] = arg1[i1]
		end
	end

	return tbl1
end

tbl1.TrimString = function(arg1)
	local str1 = "^%s*(.-)%s*$"
	return arg1:match(str1)
end

tbl1.GetTextSize = function(arg1, arg2, arg3)
	local var2 = arg3
	local var3 = arg1
	local var4 = arg2.TextSize
	local var5 = arg2.Font
	var2 = var2 or Vector2.new(arg2.AbsoluteSize.X, 0)
	return var1:GetTextSize(var3, var4, var5, var2)
end

tbl1.MakeEnumType = function(arg1, arg2)
	local var1 = tbl1.MakeFuzzyFinder(arg2)
	return {
		Validate = function(arg1)
			local var2 = arg1
			local var3 = arg1
			return var1(arg1, true) ~= nil, ("Value %q is not a valid %s."):format(var2, var3)
		end,
		Autocomplete = function(arg1)
			local var2 = var1(arg1)
			if type(var2[1]) ~= "string" then
				local var3 = tbl1.GetNames(var2)
				var3 = var3 or var2
			end

			return var2
		end,
		Parse = function(arg1)
			local var2 = arg1
			local bool1 = true
			return var1(var2, bool1)
		end,
	}
end

tbl1.ParsePrefixedUnionType = function(arg1, arg2)
	local var1 = tbl1.SplitStringSimple(arg1)
	local tbl2 = {}
	for i1 = 1, #var1, 2 do
		tbl2[#tbl2 + 1] = { prefix = var1[i1 - 1] or "", type = var1[i1] }
	end

	table.sort(tbl2, function(arg1, arg2)
		return #arg2.prefix < (#arg1.prefix)
	end)

	for i2 = 1, #tbl2 do
		local var2 = tbl2[i2]
		if arg2:sub(1, #var2.prefix) ~= var2.prefix then
			continue
		end

		return var2.type, arg2:sub(#var2.prefix + 1), var2.prefix
	end
end

tbl1.MakeListableType = function(arg1, arg2)
	local tbl1 = {
		Listable = true,
		Transform = arg1.Transform,
		Validate = arg1.Validate,
		Autocomplete = arg1.Autocomplete,
		Parse = function(...)
			return { arg1.Parse(...) }
		end,
	}

	if arg2 then
		for k1, v1 in pairs(arg2) do
			tbl1[k1] = v1
		end
	end

	return tbl1
end

tbl1.RunEmbeddedCommands = function(arg1, arg2)
	local str1 = "\20"
	arg2 = arg2:gsub("\\%$", str1)
	local tbl1 = {}
	for k1 in arg2:gmatch("$(%b{})") do
		local var1 = k1:sub(2, #k1 - 1)
		local bool2 = true
		if var1:match("^{.+}$") then
			bool2 = false
			var1 = var1:sub(2, #var1 - 1)
		end

		tbl1[k1] = arg1:EvaluateAndRun(var1)
		if not bool2 then
			continue
		end

		if not tbl1[k1]:find("%s") then
			continue
		end

		local var2 = string.format("%q", tbl1[k1])
		tbl1[k1] = var2
	end

	return (arg2:gsub("$(%b{})", tbl1):gsub("\20", "$"))
end

tbl1.SubstituteArgs = function(arg1, arg2)
	arg1 = arg1:gsub("\\%$", "\20")
	if type(arg2) == "table" then
		for i1 = 1, #arg2 do
			local var1 = tostring(i1)
			local var2 = arg2[i1]
			arg2[var1] = var2
			if not arg2[var1]:find("%s") then
				continue
			end

			var2 = string.format("%q", arg2[var1])
			arg2[var1] = var2
		end
	end

	return (arg1:gsub("($%d+)%b{}", "%1"):gsub("$(%w+)", arg2):gsub("\20", "$"))
end

tbl1.MakeAliasCommand = function(arg1, arg2)
	local str1 = "|"
	local var1, var2 = unpack(arg1:split(str1))
	local tbl2 = {}
	for k1 in arg2:gmatch("$(%d+)") do
		local var4 = arg2:match("$" .. k1 .. "{(.*)}")
		local var5 = nil
		local var6 = nil
		local var7 = nil
		if var4 then
			local str3 = "|"
			local var8, var9, var10 = unpack(var4:split(str3))
			var5 = var8
			var6 = var9
			var7 = var10
		end

		local var11 = var6
		local tbl3 = { Type = var5 or "string", Name = var11 or "Argument " .. k1, Description = var7 or "" }
		table.insert(tbl2, tbl3)
	end

	return {
		Name = var1,
		Aliases = {},
		Description = "<Alias> " .. (var2 or arg2),
		Group = "UserAlias",
		Args = tbl2,
		Run = function(arg1)
			local var1 = tbl1.SplitStringSimple(arg2, "&&")
			for k1, v1 in ipairs(var1) do
				local var2 = v1
				local var3 = arg1.RawArguments
				local var4 = arg1.Dispatcher
				local var5 = arg1.Dispatcher:EvaluateAndRun(tbl1.RunEmbeddedCommands(var4, tbl1.SubstituteArgs(var2, var3)))
				if k1 == (#var1) then
					return var5
				end

				arg1:Reply(var5)
			end

			return ""
		end,
	}
end

tbl1.MakeSequenceType = function(arg1)
	local var1 = arg1
	arg1 = var1 or {}
	local bool1 = true
	if arg1.Parse == nil then
		bool1 = arg1.Constructor ~= nil
	end

	assert(bool1, "MakeSequenceType: Must provide one of: Constructor, Parse")
	var1 = arg1.TransformEach
	arg1.TransformEach = var1 or function(...)
		return ...
	end

	var1 = arg1.ValidateEach
	arg1.ValidateEach = var1 or function()
		return true
	end

	bool1 = arg1.Parse
	return {
		Prefixes = arg1.Prefixes,
		Transform = function(arg1)
			local var1 = tbl1.SplitPrioritizedDelimeter(arg1, { ",", "%s" })
			local function fn2(arg1)
				local var1 = arg1
				return arg1.TransformEach(var1)
			end

			return tbl1.Map(var1, fn2)
		end,
		Validate = function(arg1)
			if arg1.Length and arg1.Length < (#arg1) then
				local var2 = arg1.Length
				return false, ("Maximum of %d values allowed in sequence"):format(var2)
			end

			local var3 = arg1.Length
			for i1 = 1, var3 or (#arg1) do
				local var4, var5 = arg1.ValidateEach(arg1[i1], i1)
				if var4 then
					continue
				end

				return false, var5
			end

			return true
		end,
		Parse = bool1 or function(arg1)
			local var1 = arg1
			return arg1.Constructor(unpack(var1))
		end,
	}
end

tbl1.SplitPrioritizedDelimeter = function(arg1, arg2)
	for k1, v1 in ipairs(arg2) do
		if arg1:find(v1) or k1 == (#arg2) then
			local var3 = arg1
			local var4 = v1
			return tbl1.SplitStringSimple(var3, var4)
		end
	end
end

tbl1.Map = function(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1) do
		tbl1[k1] = arg2(v1, k1)
	end

	return tbl1
end

tbl1.Each = function(arg1, ...)
	local var1 = ...
	local tbl1 = {}
	for k1, v1 in ipairs({ var1 }) do
		tbl1[k1] = arg1(v1)
	end

	local var2 = tbl1
	return unpack(var2)
end

tbl1.EmulateTabstops = function(arg1, arg2)
	local str1 = ""
	for i1 = 1, #arg1 do
		local var1 = arg1:sub(i1, i1)
		str1 = str1 .. (var1 == "\t" and string.rep(" ", arg2 - #str1 % arg2) or var1)
	end

	return str1
end

return tbl1

--- ReplicatedStorage.CmdrClient.Shared.Registry [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Util)
local var2 = game:GetService("RunService")
local tbl1 = {
	TypeMethods = var1.MakeDictionary({
		"Transform",
		"Validate",
		"Autocomplete",
		"Parse",
		"DisplayName",
		"Listable",
		"ValidateOnce",
		"Prefixes",
	}),
	Cmdr = nil,
}

tbl1.CommandMethods = var1.MakeDictionary({
	"Name",
	"Aliases",
	"AutoExec",
	"Description",
	"Args",
	"Run",
	"ClientRun",
	"Data",
	"Group",
})

tbl1.CommandArgProps = var1.MakeDictionary({ "Name", "Type", "Description", "Optional", "Default" })
tbl1.Types = {}
tbl1.TypeAliases = {}
tbl1.Commands = {}
tbl1.CommandsArray = {}
tbl1.Hooks = { BeforeRun = {}, AfterRun = {} }
tbl1.Stores = setmetatable({}, { __index = function(arg1, arg2)
	arg1[arg2] = {}
	return arg1[arg2]
end })

tbl1.AutoExecBuffer = {}
tbl1.RegisterType = function(arg1, arg2, arg3)
	if not arg2 or not typeof(arg2) == "string" then
		error("Invalid type name provided: nil")
	end

	local var2
	if not arg2:find("^[%d%l]%w*$") then
		var2 = arg2
		error(("Invalid type name provided: \"%s\", type names must be alphanumeric and start with a lower-case letter or a digit."):format(var2))
	end

	for k1 in pairs(arg3) do
		if arg1.TypeMethods[k1] ~= nil then
			continue
		end

		error("Unknown key/method in type \"" .. arg2 .. "\": " .. k1)
	end

	if arg1.Types[arg2] ~= nil then
		local var4 = arg2
		error(("Type \"%s\" has already been registered."):format(var4))
	end

	arg3.Name = arg2
	local var5 = arg3.DisplayName or arg2
	arg3.DisplayName = var5
	arg1.Types[arg2] = arg3
	if arg3.Prefixes then
		arg1:RegisterTypePrefix(arg2, arg3.Prefixes)
	end
end

tbl1.RegisterTypePrefix = function(arg1, arg2, arg3)
	if not arg1.TypeAliases[arg2] then
		arg1.TypeAliases[arg2] = arg2
	end

	arg1.TypeAliases[arg2] = ("%s %s"):format(arg1.TypeAliases[arg2], arg3)
end

tbl1.RegisterTypeAlias = function(arg1, arg2, arg3)
	local var1 = arg3
	assert(arg1.TypeAliases[arg2] == nil, ("Type alias %s already exists!"):format(var1))
	arg1.TypeAliases[arg2] = arg3
end

tbl1.RegisterTypesIn = function(arg1, arg2)
	for k1, v1 in pairs(arg2:GetChildren()) do
		if v1:IsA("ModuleScript") then
			v1.Parent = arg1.Cmdr.ReplicatedRoot.Types
			require(v1)(arg1)
		else
			arg1:RegisterTypesIn(v1)
		end
	end
end

tbl1.RegisterHooksIn = tbl1.RegisterTypesIn
tbl1.RegisterCommandObject = function(arg1, arg2, arg3)
	for k1 in pairs(arg2) do
		local var1 = arg1.CommandMethods[k1]
		if var1 ~= nil then
			continue
		end

		local var3 = arg2.Name or "unknown command"
		error("Unknown key/method in command " .. var3 .. ": " .. k1)
	end

	local var4
	if arg2.Args then
		for k2, v1 in pairs(arg2.Args) do
			var4 = type(v1)
			if var4 ~= "table" then
				continue
			end

			for k3 in pairs(v1) do
				if arg1.CommandArgProps[k3] ~= nil then
					continue
				end

				local var5 = arg2.Name or "unknown"
				local var6 = k2
				local var7 = k3
				error(("Unknown propery in command \"%s\" argument #%d: %s"):format(var5, var6, var7))
			end
		end
	end

	if not arg3 and (var2:IsClient() and arg2.Run) then
		warn(arg2.Name, "command has `Run` in its command definition; prefer using `ClientRun` for new work.")
	end

	if arg2.AutoExec and var2:IsClient() then
		table.insert(arg1.AutoExecBuffer, arg2.AutoExec)
		arg1:FlushAutoExecBufferDeferred()
	end

	local var9 = arg1.Commands[arg2.Name:lower()]
	if var9 and var9.Aliases then
		for k4, v2 in pairs(var9.Aliases) do
			local var10 = v2:lower()
			arg1.Commands[var10] = nil
		end
	elseif not var9 then
		arg1.CommandsArray[#arg1.CommandsArray + 1] = arg2
	end

	arg1.Commands[arg2.Name:lower()] = arg2
	if arg2.Aliases then
		for k5, v3 in pairs(arg2.Aliases) do
			arg1.Commands[v3:lower()] = arg2
		end
	end
end

tbl1.RegisterCommand = function(arg1, arg2, arg3, arg4)
	local var1 = require(arg2)
	if arg3 then
		var1.Run = require(arg3)
	end

	if arg4 and (not arg4(var1)) then
		return
	end

	arg1:RegisterCommandObject(var1)
	arg2.Parent = arg1.Cmdr.ReplicatedRoot.Commands
end

tbl1.RegisterCommandsIn = function(arg1, arg2, arg3)
	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in pairs(arg2:GetChildren()) do
		if v1:IsA("ModuleScript") then
			if not v1.Name:find("Server") then
				local var2 = arg2:FindFirstChild(v1.Name .. "Server")
				if var2 then
					tbl2[var2] = true
				end

				arg1:RegisterCommand(v1, var2, arg3)
			else
				tbl1[v1] = true
				continue
			end
		else
			arg1:RegisterCommandsIn(v1, arg3)
		end
	end

	for k2 in pairs(tbl1) do
		if tbl2[k2] then
			continue
		end

		warn("Command script " .. k2.Name .. " was skipped because it has 'Server' in its name, and has no equivalent shared script.")
	end
end

tbl1.RegisterDefaultCommands = function(arg1, arg2)
	local var2 = type(arg2) == "table"
	arg2 = var2 and var1.MakeDictionary(arg2)
	arg1:RegisterCommandsIn(arg1.Cmdr.DefaultCommandsFolder, var2 and function(arg1)
		return arg2[arg1.Group] or false
	end or arg2)
end

tbl1.GetCommand = function(arg1, arg2)
	return arg1.Commands[(arg2 or ""):lower()]
end

tbl1.GetCommands = function(arg1)
	return arg1.CommandsArray
end

tbl1.GetCommandsAsStrings = function(arg1)
	local tbl1 = {}
	for k1, v1 in pairs(arg1.CommandsArray) do
		tbl1[#tbl1 + 1] = v1.Name
	end

	return tbl1
end

tbl1.GetType = function(arg1, arg2)
	return arg1.Types[arg2]
end

tbl1.GetTypeName = function(arg1, arg2)
	return arg1.TypeAliases[arg2] or arg2
end

tbl1.RegisterHook = function(arg1, arg2, arg3, arg4)
	if not arg1.Hooks[arg2] then
		error(("Invalid hook name: %q"):format(arg2), 2)
	end

	table.insert(arg1.Hooks[arg2], { callback = arg3, priority = arg4 or 0 })
	table.sort(arg1.Hooks[arg2], function(arg1, arg2)
		return arg1.priority < arg2.priority
	end)
end

tbl1.AddHook = tbl1.RegisterHook
tbl1.GetStore = function(arg1, arg2)
	return arg1.Stores[arg2]
end

tbl1.FlushAutoExecBufferDeferred = function(arg1)
	if arg1.AutoExecFlushConnection then
		return
	end

	arg1.AutoExecFlushConnection = var2.Heartbeat:Connect(function()
		arg1.AutoExecFlushConnection:Disconnect()
		arg1.AutoExecFlushConnection = nil
		arg1:FlushAutoExecBuffer()
	end)
end

tbl1.FlushAutoExecBuffer = function(arg1)
	for k1, v1 in ipairs(arg1.AutoExecBuffer) do
		for k2, v2 in ipairs(v1) do
			arg1.Cmdr.Dispatcher:EvaluateAndRun(v2)
		end
	end

	arg1.AutoExecBuffer = {}
end

return function(arg1)
	tbl1.Cmdr = arg1
	return tbl1
end

--- ReplicatedStorage.CmdrClient.Shared.Dispatcher [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("Players")
local var3 = require(script.Parent.Util)
local var4 = require(script.Parent.Command)
local var5 = game:GetService("TeleportService")
local bool1 = false
local tbl1 = {
	Cmdr = nil,
	Registry = nil,
	Evaluate = function(arg1, arg2, arg3, arg4, arg5)
		if var1:IsClient() == true and arg3 ~= var2.LocalPlayer then
			error("Can't evaluate a command that isn't sent by the local player.")
		end

		local var5 = var3.SplitString(arg2)
		local var6 = table.remove(var5, 1)
		local var8 = arg1.Registry:GetCommand(var6)
		if var8 then
			var5 = var3.MashExcessArguments(var5, #var8.Args)
			local var9 = var4.new({
				Dispatcher = arg1,
				Text = arg2,
				CommandObject = var8,
				Alias = var6,
				Executor = arg3,
				Arguments = var5,
				Data = arg5,
			})

			local var10, var11 = var9:Parse(arg4)
			if var10 then
				return var9
			end

			return false, var11
		end

		local var12 = tostring(var6)
		return false, ("%q is not a valid command name. Use the help command to see all available commands."):format(var12)
	end,
	EvaluateAndRun = function(arg1, arg2, arg3, arg4)
		local var3 = arg3
		arg3 = var3 or var2.LocalPlayer
		var3 = arg4
		arg4 = var3 or {}
		if var1:IsClient() and arg4.IsHuman then
			arg1:PushHistory(arg2)
		end

		local var6, var7 = arg1:Evaluate(arg2, arg3, nil, arg4.Data)
		if not var6 then
			return var7
		end

		local var10, var11 = xpcall(function()
			local var1, var2 = var6:Validate(true)
			if not var1 then
				return var2
			end

			return var6:Run() or "Command executed."
		end, function(arg1)
			local var1 = tostring(arg1)
			return debug.traceback(var1)
		end)

		if not var10 then
			local var12 = arg2
			local var13 = tostring(var11)
			warn(([[Error occurred while evaluating command string %q
%s]]):format(var12, var13))

		end

		return var10 and var11 or "An error occurred while running this command. Check the console for more information."
	end,
	Send = function(arg1, arg2, arg3)
		if var1:IsClient() == false then
			error("Dispatcher:Send can only be called from the client.")
		end

		local var2 = arg2
		local tbl1 = { Data = arg3 }
		return arg1.Cmdr.RemoteFunction:InvokeServer(var2, tbl1)
	end,
	Run = function(arg1, ...)
		if not var2.LocalPlayer then
			error("Dispatcher:Run can only be called from the client.")
		end

		local tbl1 = { ... }
		local var1 = tbl1[1]
		for i1 = 2, #tbl1 do
			var1 = var1 .. " " .. tostring(tbl1[i1])
		end

		local var5, var6 = arg1:Evaluate(var1, var2.LocalPlayer)
		if not var5 then
			error(var6)
		end

		local var8, var9 = var5:Validate(true)
		if not var8 then
			error(var9)
		end

		return var5:Run()
	end,
	RunHooks = function(arg1, arg2, arg3, ...)
		if not arg1.Registry.Hooks[arg2] then
			error(("Invalid hook name: %q"):format(arg2), 2)
		end

		local var2
		if arg2 == "BeforeRun" then
			if #arg1.Registry.Hooks[arg2] == 0 then
				if arg3.Group ~= "DefaultUtil" then
					if arg3.Group ~= "UserAlias" then
						if arg3:HasImplementation() then
							if var1:IsStudio() then
								if bool1 == false then
									var2 = 255
									local num1 = 228
									local num2 = 26
									arg3:Reply((if var1:IsServer() then "<Server>" else "<Client>") .. " Commands will not run in-game if no BeforeRun hook is configured. Learn more: https://eryn.io/Cmdr/guide/Hooks.html", Color3.fromRGB(var2, num1, num2))
									bool1 = true
								end
							else
								return "Command blocked for security as no BeforeRun hook is configured."
							end
						end
					end
				end
			end
		end

		for k1, v1 in ipairs(arg1.Registry.Hooks[arg2]) do
			local var3 = v1.callback(arg3, ...)
			if var3 == nil then
				continue
			end

			return (tostring(var3))
		end
	end,
	PushHistory = function(arg1, arg2)
		assert(var1:IsClient(), "PushHistory may only be used from the client.")
		local var4 = arg1:GetHistory()
		if var3.TrimString(arg2) == "" or arg2 == var4[#var4] then
			return
		end

		var4[#var4 + 1] = arg2
		var5:SetTeleportSetting("CmdrCommandHistory", var4)
	end,
	GetHistory = function(_)
		assert(var1:IsClient(), "GetHistory may only be used from the client.")
		local var2 = var5:GetTeleportSetting("CmdrCommandHistory")
		return var2 or {}
	end,
}

return function(arg1)
	tbl1.Cmdr = arg1
	tbl1.Registry = arg1.Registry
	return tbl1
end

--- ReplicatedStorage.CmdrClient.Shared.Argument [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Util)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	local tbl2 = { Command = arg1, Type = nil, Name = arg2.Name, Object = arg2, Prefix = "" }
	local bool1 = false
	if arg2.Default == nil then
		bool1 = arg2.Optional ~= true
	end

	tbl2.Required = bool1
	tbl2.Executor = arg1.Executor
	tbl2.RawValue = arg3
	tbl2.RawSegments = {}
	tbl2.TransformedValues = {}
	if type(arg2.Type) == "table" then
		tbl2.Type = arg2.Type
	else
		local var2, var3, var4 = var1.ParsePrefixedUnionType(arg1.Cmdr.Registry:GetTypeName(arg2.Type), arg3)
		tbl2.Type = arg1.Dispatcher.Registry:GetType(var2)
		tbl2.RawValue = var3
		tbl2.Prefix = var4
		if tbl2.Type == nil then
			local str2 = "%s has an unregistered type %q"
			local var7 = tbl2.Name or "<none>"
			local var8 = var2 or "<none>"
			error(string.format(str2, var7, var8))
		end
	end

	setmetatable(tbl2, tbl1)
	tbl2:Transform()
	return tbl2
end

tbl1.Transform = function(arg1)
	if #arg1.TransformedValues ~= 0 then
		return
	end

	if arg1.Type.Listable then
		if 0 < (#arg1.RawValue) then
			local var8 = arg1.RawValue
			local var9 = #var8
			local var11 = var1.SplitStringSimple(arg1.RawValue, ",")
			if arg1.RawValue:sub(#arg1.RawValue, var9) == "," then
				var11[#var11 + 1] = ""
			end

			for k1, v1 in ipairs(var11) do
				arg1.RawSegments[k1] = v1
				local var12 = v1
				local tbl1 = { arg1:TransformSegment(var12) }
				arg1.TransformedValues[k1] = tbl1
			end

			return
		end
	end

	arg1.RawSegments[1] = arg1.RawValue
	local var13 = arg1.RawValue
	local tbl2 = { arg1:TransformSegment(var13) }
	arg1.TransformedValues[1] = tbl2
end

tbl1.TransformSegment = function(arg1, arg2)
	if arg1.Type.Transform then
		local var3 = arg2
		local var4 = arg1.Executor
		return arg1.Type.Transform(var3, var4)
	end

	return arg2
end

tbl1.GetTransformedValue = function(arg1, arg2)
	local var1 = arg1.TransformedValues[arg2]
	return unpack(var1)
end

tbl1.Validate = function(arg1, arg2)
	if arg1.RawValue == nil or #arg1.RawValue == 0 and arg1.Required == false then
		return true
	end

	if arg1.Type.Validate or arg1.Type.ValidateOnce then
		for i1 = 1, #arg1.TransformedValues do
			local var4 = i1
			local var5, var6 = arg1.Type.Validate(arg1:GetTransformedValue(var4))
			if arg1.Type.Validate and (not var5) then
				return var5, var6 or "Invalid value"
			end

			if not arg2 then
				continue
			end

			if not arg1.Type.ValidateOnce then
				continue
			end

			var4 = i1
			local var7, var8 = arg1.Type.ValidateOnce(arg1:GetTransformedValue(var4))
			if var7 then
				continue
			end

			return var7, var8
		end

		return true
	end

	return true
end

tbl1.GetAutocomplete = function(arg1)
	if arg1.Type.Autocomplete then
		local var2 = #arg1.TransformedValues
		return arg1.Type.Autocomplete(arg1:GetTransformedValue(var2))
	end

	return {}
end

tbl1.ParseValue = function(arg1, arg2)
	if arg1.Type.Parse then
		local var2 = arg2
		return arg1.Type.Parse(arg1:GetTransformedValue(var2))
	end

	local var3 = arg2
	return arg1:GetTransformedValue(var3)
end

tbl1.GetValue = function(arg1)
	if #arg1.RawValue == 0 and (not arg1.Required and arg1.Object.Default ~= nil) then
		return arg1.Object.Default
	end

	if not arg1.Type.Listable then
		local num2 = 1
		return arg1:ParseValue(num2)
	end

	local tbl1 = {}
	for i1 = 1, #arg1.TransformedValues do
		local var1 = arg1:ParseValue(i1)
		if type(var1) ~= "table" then
			local var3 = arg1.Type.Name
			error(("Listable types must return a table from Parse (%s)"):format(var3))
		end

		for k1, v1 in pairs(var1) do
			tbl1[v1] = true
		end
	end

	local tbl2 = {}
	for k2 in pairs(tbl1) do
		tbl2[#tbl2 + 1] = k2
	end

	return tbl2
end

return tbl1

--- ReplicatedStorage.CmdrClient.Shared.Command [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local var2 = game:GetService("Players")
local var3 = require(script.Parent.Argument)
local var4 = var1:IsServer()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local tbl2 = {
		Dispatcher = arg1.Dispatcher,
		Cmdr = arg1.Dispatcher.Cmdr,
		Name = arg1.CommandObject.Name,
		RawText = arg1.Text,
		Object = arg1.CommandObject,
		Group = arg1.CommandObject.Group,
		State = {},
		Aliases = arg1.CommandObject.Aliases,
		Alias = arg1.Alias,
		Description = arg1.CommandObject.Description,
		Executor = arg1.Executor,
		ArgumentDefinitions = arg1.CommandObject.Args,
		RawArguments = arg1.Arguments,
		Arguments = {},
		Data = arg1.Data,
		Response = nil,
	}

	setmetatable(tbl2, tbl1)
	return tbl2
end

tbl1.Parse = function(arg1, arg2)
	local bool1 = false
	for k1, v1 in ipairs(arg1.ArgumentDefinitions) do
		if type(v1) == "function" then
			v1 = v1(arg1)
			if v1 == nil then
				break
			end
		end

		local bool2 = false
		if v1.Default == nil then
			bool2 = v1.Optional ~= true
		end

		if bool2 and bool1 then
			local var2 = arg1.Name
			error(("Command %q: Required arguments cannot occur after optional arguments."):format(var2))
		elseif not bool2 then
		end

		if arg1.RawArguments[k1] == nil and (bool2 and arg2 ~= true) then
			local var6 = k1
			local var7 = v1.Name
			return false, ("Required argument #%d %s is missing."):format(var6, var7)
		end

		if arg1.RawArguments[k1] or arg2 then
			arg1.Arguments[k1] = var3.new(arg1, v1, arg1.RawArguments[k1] or "")
		end

		local bool3 = true
	end

	return true
end

tbl1.Validate = function(arg1, arg2)
	arg1._Validated = true
	local str1 = ""
	local bool1 = true
	for k1, v1 in pairs(arg1.Arguments) do
		local var1, var2 = v1:Validate(arg2)
		if var1 then
			continue
		end

		str1 = ("%s; #%d %s: %s"):format(str1, k1, v1.Name, var2 or "error")
		bool1 = false
	end

	local num1 = 3
	return bool1, str1:sub(num1)
end

tbl1.GetLastArgument = function(arg1)
	for i1 = #arg1.Arguments, 1, -1 do
		if not arg1.Arguments[i1].RawValue then
			continue
		end

		return arg1.Arguments[i1]
	end
end

tbl1.GatherArgumentValues = function(arg1)
	local tbl1 = {}
	for i1 = 1, #arg1.ArgumentDefinitions do
		local var2 = arg1.Arguments[i1]
		if var2 then
			tbl1[i1] = var2:GetValue()
		else
			if type(arg1.ArgumentDefinitions[i1]) ~= "table" then
				continue
			end

			tbl1[i1] = arg1.ArgumentDefinitions[i1].Default
		end
	end

	return tbl1, #arg1.ArgumentDefinitions
end

tbl1.Run = function(arg1)
	if arg1._Validated == nil then
		error("Must validate a command before running.")
	end

	local var2 = arg1.Dispatcher:RunHooks("BeforeRun", arg1)
	if var2 then
		return var2
	end

	if not var4 and (arg1.Object.Data and arg1.Data == nil) then
		local var3, var5 = arg1:GatherArgumentValues()
		local var6 = var3
		local num1 = 1
		local var7 = var5
		local var8 = arg1.Object.Data(arg1, unpack(var6, num1, var7))
		arg1.Data = var8
	end

	if not var4 and arg1.Object.ClientRun then
		local var9, var10 = arg1:GatherArgumentValues()
		local var11 = var9
		local num2 = 1
		local var12 = var10
		local var13 = arg1.Object.ClientRun(arg1, unpack(var11, num2, var12))
		arg1.Response = var13
	end

	if arg1.Response == nil then
		if arg1.Object.Run then
			local var14, var15 = arg1:GatherArgumentValues()
			local var16 = var14
			local num3 = 1
			local var17 = var15
			local var18 = arg1.Object.Run(arg1, unpack(var16, num3, var17))
			arg1.Response = var18
		else
			if var4 then
				if arg1.Object.ClientRun then
					warn(arg1.Name, "command fell back to the server because ClientRun returned nil, but there is no server implementation! Either return a string from ClientRun, or create a server implementation for this command.")
				else
					warn(arg1.Name, "command has no implementation!")
				end

				arg1.Response = "No implementation."
			else
				arg1.Response = arg1.Dispatcher:Send(arg1.RawText, arg1.Data)
			end
		end
	end

	local var20 = arg1.Dispatcher:RunHooks("AfterRun", arg1)
	if var20 then
		return var20
	end

	return arg1.Response
end

tbl1.GetArgument = function(arg1, arg2)
	return arg1.Arguments[arg2]
end

tbl1.GetData = function(arg1)
	if arg1.Data then
		return arg1.Data
	end

	if arg1.Object.Data and (not var4) then
		local var1 = arg1.Object.Data(arg1)
		arg1.Data = var1
	end

	return arg1.Data
end

tbl1.SendEvent = function(arg1, arg2, arg3, ...)
	assert(typeof(arg2) == "Instance", "Argument #1 must be a Player")
	assert(arg2:IsA("Player"), "Argument #1 must be a Player")
	assert(type(arg3) == "string", "Argument #2 must be a string")
	if var4 then
		arg1.Dispatcher.Cmdr.RemoteEvent:FireClient(arg2, arg3, ...)
		return
	end

	if arg1.Dispatcher.Cmdr.Events[arg3] then
		assert(arg2 == var2.LocalPlayer, "Event messages can only be sent to the local player on the client.")
		arg1.Dispatcher.Cmdr.Events[arg3](...)
	end
end

tbl1.BroadcastEvent = function(arg1, ...)
	if not var4 then
		error("Can't broadcast event messages from the client.", 2)
	end

	arg1.Dispatcher.Cmdr.RemoteEvent:FireAllClients(...)
end

tbl1.Reply = function(arg1, ...)
	local var1 = arg1.Executor
	local str1 = "AddLine"
	return arg1:SendEvent(var1, str1, ...)
end

tbl1.GetStore = function(arg1, ...)
	return arg1.Dispatcher.Cmdr.Registry:GetStore(...)
end

tbl1.HasImplementation = function(arg1)
	if var1:IsClient() and arg1.Object.ClientRun or arg1.Object.Run then
		return true
	end

	return false
end

return tbl1

--- ReplicatedStorage.Shared.Util [ModuleScript]
-- y u r i

local tbl1 = {}
local var1 = require(script.Parent.Libs.EternityNum)
tbl1.deepCopy = function(arg1)
	local tbl2 = {}
	for k1, v1 in pairs(arg1) do
		if typeof(v1) == "table" then
			tbl2[k1] = tbl1.deepCopy(v1)
		else
			tbl2[k1] = v1
		end
	end

	return tbl2
end

tbl1.resolve = function(arg1, arg2, arg3)
	return typeof(arg1) == "function" and arg1(arg2, arg3) or arg1
end

tbl1.pcmore0 = function(arg1, arg2)
	return 0 < arg1[arg2].purchaseCount
end

tbl1.setVisible = function(arg1, arg2, arg3)
	arg3 = arg3 or "none"
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("BasePart") then
			local var3 = v1:GetAttribute("OriginalTransparency")
			if var3 == nil then
				var3 = v1.Transparency
				v1:SetAttribute("OriginalTransparency", var3)
			end

			v1.Transparency = arg2 and var3 or 1
			if arg3 == "follow" then
				v1.CanCollide = arg2
				v1.CanTouch = arg2
			elseif arg3 == "inverted" then
				v1.CanCollide = not arg2
				v1.CanTouch = not arg2
				continue
			end
		else
			if not v1:IsA("Decal") then
				if v1:IsA("Texture") then
					local var7 = v1:GetAttribute("OriginalTransparency")
					if var7 == nil then
						var7 = v1.Transparency
						v1:SetAttribute("OriginalTransparency", var7)
					end

					v1.Transparency = arg2 and var7 or 1
				elseif v1:IsA("GuiObject") then
					v1.Visible = arg2
				end
			end
		end
	end

	if arg1:IsA("BasePart") then
		local var10 = arg1:GetAttribute("OriginalTransparency")
		if var10 == nil then
			var10 = arg1.Transparency
			arg1:SetAttribute("OriginalTransparency", var10)
		end

		arg1.Transparency = arg2 and var10 or 1
		if arg3 == "follow" then
			arg1.CanCollide = arg2
			arg1.CanTouch = arg2
			return
		end

		if arg3 == "inverted" then
			arg1.CanCollide = not arg2
			arg1.CanTouch = not arg2
		end
	end
end

tbl1.gateSatisfied = function(arg1, arg2, arg3)
	if not arg1 then
		return true
	end

	if arg1.AnyOf then
		for k1, v1 in ipairs(arg1.AnyOf) do
			if not tbl1.gateSatisfied(v1, arg2, arg3) then
				continue
			end

			return true
		end

		return false
	end

	if arg1.Upgrade then
		local var4 = arg2:FindFirstChild(arg1.Upgrade)
		local bool1 = false
		if var4 ~= nil then
			bool1 = 0 < (var4:GetAttribute("purchaseCount") or 0)
		end

		return bool1
	end

	if arg1.Stat then
		local var6 = arg3:FindFirstChild(arg1.Stat)
		if not var6 then
			return false
		end

		if arg1.AtLeast ~= nil then
			local var9 = var6.Value
			local var10 = arg1.AtLeast
			return var1.meeq(var9, var10)
		end

		if arg1.GreaterThan ~= nil then
			local var13 = var6.Value
			local var14 = arg1.GreaterThan
			return var1.me(var13, var14)
		end
	end

	warn("[Util] unrecognised gate form; treating as locked")
	return false
end

tbl1.collectGateWatches = function(arg1, arg2, arg3)
	if not arg1 then
		return
	end

	if arg1.AnyOf then
		for k1, v1 in ipairs(arg1.AnyOf) do
			tbl1.collectGateWatches(v1, arg2, arg3)
		end

		return
	end

	if arg1.Upgrade then
		table.insert(arg2, arg1.Upgrade)
	end

	if arg1.Stat then
		table.insert(arg3, arg1.Stat)
	end
end

return tbl1

--- ReplicatedStorage.Shared.Formulas [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.Libs.EternityNum)
local var2 = require(script.Parent.Config.GameConfig)
local tbl1 = {
	XPRequirement = function(arg1)
		local num1 = 3
		local var2 = arg1
		local var3 = var1.mul(5, var1.pow(num1, var2))
		if var1.meeq(arg1, 1000) then
			local var5 = arg1
			local num3 = 999
			var2 = 3.3333
			var3 = var1.mul(var3, var1.pow(var2, var1.sub(var5, num3)))
		end

		return var3
	end,
	StarXPRequirement = function(arg1)
		local num1 = 3
		local var2 = arg1
		local num2 = 5
		return var1.mul(num2, var1.pow(num1, var2))
	end,
	LoopRequirement = function(arg1)
		local var3 = arg1
		local num1 = 1
		local var4 = var2.Thresholds.LoopLevelsPerLoop
		return var1.mul(var4, var1.add(var3, num1))
	end,
	LoopsGained = function(arg1, arg2, arg3)
		if not arg1 then
			local num2 = 0
			return var1.convert(num2)
		end

		local var3 = arg1
		local var4 = var2.Thresholds.LoopLevelsPerLoop
		local var5 = var1.floor(var1.div(var3, var4))
		if var1.le(var5, arg2) then
			var3 = 0
			return var1.convert(var3)
		end

		if arg3 then
			var3 = var5
			var4 = arg2
			return var1.sub(var3, var4)
		end

		return 1
	end,
	PrestigeGain = function(arg1, arg2)
		local var3 = var1.div(arg2, var2.Thresholds.PrestigePoints)
		local num1 = 0.5
		local var4 = arg1
		return var1.mul(var4, var1.pow(var3, num1))
	end,
	SteelGain = function(arg1, arg2)
		local var3 = arg2
		local var4 = var2.Thresholds.SteelPower
		local var5 = arg1
		local num1 = 100
		local var6 = var1.log(var1.add(5, var1.div(var3, var4)), 6)
		return var1.mul(var6, var1.mul(var5, num1))
	end,
	SpacePrestigeGain = function(arg1, arg2)
		local var2 = var1.mul
		local var3 = var1.pow(var1.sub(arg2, 29), 2)
		local var4 = var1.pow
		local num1 = 1.5
		local var5 = if var1.leeq(var1.sub(arg2, 38), 0) then 0 else var1.sub(arg2, 38)
		var2 = var2(var3, var4(num1, var5))
		var4 = var2
		num1 = arg1
		return var1.mul(var4, num1)
	end,
	PassiveNovaMultiplier = function(arg1)
		return 1e-05 * 2 ^ (arg1 - 1)
	end,
	PowerBoostFormulas = {
		Prestige = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log10(arg1), 50000), 5)))
			end

			return var2
		end,
		XP = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log10(arg1), 50000), 3)))
			end

			return var2
		end,
		Steel = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log10(arg1), 50000), 2.5)))
			end

			return var2
		end,
		DarkMatter = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log10(arg1), 50000), 2.75)))
			end

			return var2
		end,
		SpacePrestige = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log10(arg1), 50000), 4)))
			end

			return var2
		end,
		Power = function(arg1, arg2)
			local num3 = 10
			local num4 = 50000
			local var2 = var1.log(var1.add(arg1, 5), 5)
			if var1.meeq(arg2.Values.Loops.Value, 11) and var1.meeq(arg1, var1.pow(num3, num4)) then
				var2 = var1.mul(var2, (var1.pow(var1.sub(var1.log(arg1, 2), 166096.405), 150)))
			end

			return var2
		end,
	},
}

tbl1.PowerLogBoost = function(arg1, arg2, arg3)
	local var2 = arg2
	var2 = var2 and tbl1.PowerBoostFormulas[arg2]
	if var2 then
		local var5 = arg1
		local var6 = arg3
		return var2(var5, var6)
	end

	local var7 = var1.add(arg1, 5)
	local num1 = 5
	return var1.log(var7, num1)
end

tbl1.KeycapSteelMultiplier = function(arg1)
	local var2 = var1.add(arg1, 10)
	local num1 = 10
	local num2 = 1.1
	return var1.pow(num2, var1.floor(var1.log(var2, num1)))
end

tbl1.SupernovaCurrencyMultiplier = function(arg1, arg2)
	local var2 = arg2
	var2 = var2 and arg2:FindFirstChild("Challenges")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("#2")
	local var4 = var1.add(var1.mul(arg1, 2), 1)
	local num2 = 1
	if var3 then
		num2 = 2 ^ var3.Value
	end

	local var5 = var4
	local var6 = num2
	return var1.pow(var5, var6)
end

tbl1.SupernovaPowerMultiplier = function(arg1)
	local num1 = 10000000000
	local var2 = arg1
	return var1.pow(num1, var2)
end

tbl1.SupernovaBaseGain = function(arg1)
	if var1.leeq(arg1, 0) then
		return 0
	end

	local var2 = arg1
	local num1 = 1
	local num2 = 2
	local num3 = 100
	return var1.mul(num3, var1.pow(num2, var1.sub(var2, num1)))
end

tbl1.SupernovaGainExponent = function(arg1)
	local num1 = 0.01
	local var2 = var1.leeq(arg1, 100) and arg1 or var1.convert(100)
	local var3 = var1.add(1, var1.mul(num1, var2))
	local num2 = 0.001
	num1 = var1.meeq(arg1, 100) and var1.sub(arg1, 100) or var1.convert(0)
	return var1.add(var3, var1.mul(num2, num1))
end

tbl1.SupernovaTierToNova = function(arg1, arg2)
	local var2 = arg2
	var2 = var2 and arg2:FindFirstChild("Challenges")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("#2")
	local num2 = 1
	if var3 and 1 <= var3.Value then
		num2 = 10 ^ var3.Value
	end

	local var4 = arg1
	local var5 = num2
	return var1.mul(var4, var5)
end

return tbl1

--- ReplicatedStorage.Shared.Remotes [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
local var4 = var1:FindFirstChild("Remotes")
local var5
if var4 then
	var5 = var4
else
	if var2:IsServer() then
		local var6 = Instance.new("Folder")
		var6.Name = "Remotes"
		var6.Parent = var1
		var5 = var6
	else
		var5 = var1:WaitForChild("Remotes")
	end
end

var4 = {
	BuyOneEvent = "RemoteEvent",
	BuyMaxEvent = "RemoteEvent",
	UpdateUpgrade = "RemoteEvent",
	GetUpgradeInfo = "RemoteFunction",
	GetVisibleInfo = "RemoteFunction",
	SoundPlayEvent = "RemoteEvent",
	RequestSlotSwap = "RemoteEvent",
	GetSlotPreview = "RemoteFunction",
	LoopEvent = "RemoteEvent",
	SupernovaEvent = "RemoteEvent",
	SupernovaRespecEvent = "RemoteEvent",
	StarExperienceGain = "RemoteEvent",
	KeycapPressed = "RemoteEvent",
	ChallengeStartEvent = "RemoteEvent",
	ChallengeCancelEvent = "RemoteEvent",
	TeleportEvent = "RemoteEvent",
	TeleportTransition = "RemoteEvent",
	UpdateSetting = "RemoteEvent",
	SettingsLoaded = "RemoteEvent",
	AchievementUnlocked = "RemoteEvent",
	SendPlayerAchievements = "RemoteEvent",
	TutorialCompletedEvent = "RemoteEvent",
	AnalyticsFunnelEvent = "RemoteEvent",
	AdminGrantBoostEvent = "RemoteEvent",
	BoostHUDEvent = "RemoteEvent",
}

local tbl1 = {}
local function fetch(arg1)
	local var3 = var4[arg1]
	if not var3 then
		error(("Remotes: '%s' is not a known remote. Add it to REMOTE_CLASSES first."):format((tostring(arg1))), 3)
	end

	local var7 = var5:FindFirstChild(arg1)
	if var7 then
		return var7
	end

	if var2:IsServer() then
		local var8 = Instance.new(var3)
		var8.Name = arg1
		var8.Parent = var5
		return var8
	end

	local var9 = arg1
	return var5:WaitForChild(var9)
end

local tbl2 = { __list = function()
	local tbl1 = {}
	for k1 in pairs(var4) do
		table.insert(tbl1, k1)
	end

	table.sort(tbl1)
	return tbl1
end }

setmetatable(tbl2, {
	__index = function(_, arg2)
		local var2 = tbl1[arg2]
		if not var2 then
			var2 = fetch(arg2)
			tbl1[arg2] = var2
		end

		return var2
	end,
	__newindex = function()
		error("Remotes is read-only", 2)
	end,
})

return tbl2

--- ReplicatedStorage.Shared.Libs.EternityNum [ModuleScript]
-- y u r i

local tbl1 = {
	0.99999999999980993,
	676.5203681218851,
	-1259.1392167224028,
	771.32342877765313,
	-176.61502916214059,
	12.507343278686905,
	-0.13857109526572012,
	9.9843695780195716e-06,
	1.5056327351493116e-07,
}

function F_Gamma(arg1)
	if 171.6236 < arg1 then
		return math.huge
	end

	if 0.5 < arg1 then
		arg1 = arg1 - 1
		local var2 = arg1 + 7.5
		return (tbl1[1] + tbl1[2] / (arg1 + 1) + tbl1[3] / (arg1 + 2) + tbl1[4] / (arg1 + 3) + tbl1[5] / (arg1 + 4) + tbl1[6] / (arg1 + 5) + tbl1[7] / (arg1 + 6) + tbl1[8] / (arg1 + 7)) * var2 ^ (arg1 + 0.5 - 36) * math.exp(-var2) * var2 ^ 36 * 2.5066282746310007
	end

	return 3.1415926535897931 / (math.sin(3.1415926535897931 * arg1) * F_Gamma(1 - arg1))
end

function f_Lambertw(arg1)
	local var1 = nil
	local var2 = nil
	if 1.79e+308 < arg1 then
		return arg1
	end

	if arg1 == 0 then
		return arg1
	end

	if arg1 == 1 then
		return 0.56714329040978384
	end

	var1 = if arg1 < 10 then 0 else math.log(arg1) - math.log((math.log(arg1)))
	for i1 = 1, 100 do
		var2 = (arg1 * math.exp(-var1) + var1 * var1) / (var1 + 1)
		if math.abs(var2 - var1) < math.abs(var2) * 1e-10 then
			return var2
		end

		local var3 = var2
	end

	error("Failed to itterate z.... at function: f_lambertw")
end

function Cnew(arg1, arg2, arg3)
	return { Sign = arg1, Layer = arg2, Exp = arg3 }
end

local var1 = Cnew(1, -1, 1)
local var2 = Cnew(0, 0, 0)
local var3 = Cnew(1, 0, 1)
local var4 = Cnew(1, math.huge, 1)
local tbl2 = {
	IsNaN = function(arg1)
		local bool2 = false
		if arg1.Sign == var1.Sign then
			bool2 = false
			if arg1.Layer == var1.Layer then
				bool2 = arg1.Exp == var1.Exp
			end
		end

		return bool2
	end,
	IsInf = function(arg1)
		local bool1 = true
		if arg1.Layer ~= math.huge then
			bool1 = arg1.Exp == math.huge
		end

		return bool1
	end,
	IsZero = function(arg1)
		local bool2 = true
		if arg1.Sign ~= 0 then
			bool2 = false
			if arg1.Exp == 0 then
				bool2 = arg1.Layer == 0
			end
		end

		return bool2
	end,
}

tbl2.correct = function(arg1)
	if tbl2.IsNaN(arg1) then
		return var1
	end

	if tbl2.IsInf(arg1) then
		return var4
	end

	if tbl2.IsZero(arg1) then
		return var2
	end

	local var6 = arg1.Layer
	local var7 = arg1.Sign
	local var8 = arg1.Exp
	if var6 == 0 then
		if var8 < 0 then
			var7 = -var7
			var8 = -var8
		end
	end

	if var6 == 0 and var8 < 1e-10 then
		var6 = var6 + 1
		var8 = math.log10(var8)
		local var9 = var7
		local var10 = var6
		local var11 = var8
		return Cnew(var9, var10, var11)
	end

	local var13 = math.abs(var8)
	local var14 = math.sign(var8)
	if 10000000000 <= var13 then
		var6 = var6 + 1
		var8 = var14 * math.log10(var13)
		local var15 = var7
		local var16 = var6
		local var17 = var8
		return Cnew(var15, var16, var17)
	end

	while true do
		if var13 >= 10 or 0 >= var6 then
			break
		end

		var6 = var6 - 1
		if var6 == 0 then
			var8 = math.pow(10, var8)
		else
			var8 = var14 * math.pow(10, var13)
		end

		local var18 = math.abs(var8)
		local var19 = math.sign(var8)
	end

	if var6 == 0 then
		if var8 < 0 then
			var7 = -var7
			var8 = -var8
		end
	elseif var8 == 0 then
		var7 = 0
	end

	local var20 = var7
	local var21 = var6
	local var22 = var8
	return Cnew(var20, var21, var22)
end

tbl2.new = function(arg1, arg2, arg3)
	local tbl1 = { Sign = arg1, Layer = arg2, Exp = arg3 }
	return tbl2.correct(tbl1)
end

tbl2.fromNumber = function(arg1)
	local tbl1 = { Sign = math.sign(arg1) }
	tbl1.Layer = 0
	tbl1.Exp = math.abs(arg1)
	local var1 = tbl1
	return tbl2.correct(var1)
end

tbl2.fromScientific = function(arg1)
	local var1 = arg1:split("e")
	local var3 = tonumber(var1[1])
	local var6 = math.floor((math.log10(var3)))
	local var7 = tonumber(var1[2])
	local var8 = math.sign(var3)
	if 0 < var6 then
		var3 = var3 / 10 ^ var6
		var7 = var7 + var6
	end

	if var7 == 0 then
		local var9 = math.sign(var3)
		local num1 = 0
		local var10 = var3
		return tbl2.new(var9, num1, var10)
	end

	if var3 == 0 then
		return var2
	end

	if var3 < 0 then
		var3 = -var3
	end

	if var7 < 0 then
		if var7 < -100 then
			return var2
		end

		local var11 = var8
		local num2 = 1
		local var12 = math.log10(var3) + var7
		return tbl2.correct(tbl2.new(var11, num2, var12))
	end

	local var14 = math.log10(var3) + var7
	local num3 = 1
	if 10000000000 < var14 then
		var14 = math.log10(var14)
		num3 = num3 + 1
	end

	local var15 = var8
	local var16 = num3
	local var17 = var14
	return tbl2.correct(tbl2.new(var15, var16, var17))
end

tbl2.fromDefaultStringFormat = function(arg1)
	local var1 = arg1:split(";")
	local var3 = math.sign((tonumber(var1[1])))
	if var3 == 0 then
		var3 = 1
	end

	local var4 = var3
	local var5 = math.abs((tonumber(var1[1])))
	local var6 = tonumber(var1[2])
	return tbl2.correct(tbl2.new(var4, var5, var6))
end

tbl2.fromString = function(arg1)
	if arg1:find("e") and (not arg1:find(";")) then
		local var5 = arg1
		return tbl2.fromScientific(var5)
	end

	if arg1:find(";") then
		local var7 = arg1
		return tbl2.fromDefaultStringFormat(var7)
	end

	if arg1 == "NaN" then
		return var1
	end

	if arg1 == "Inf" then
		return var4
	end

	if arg1 == "" then
		return var2
	end

	local var8 = tonumber(arg1)
	return tbl2.fromNumber(var8)
end

tbl2.toString = function(arg1)
	if tbl2.IsNaN(arg1) then
		return "NaN"
	end

	if tbl2.IsInf(arg1) then
		return "Inf"
	end

	return arg1.Layer .. ";" .. arg1.Exp
end

tbl2.convert = function(arg1)
	if typeof(arg1) == "number" then
		local var3 = arg1
		return tbl2.fromNumber(var3)
	end

	if typeof(arg1) == "string" then
		local var5 = arg1
		return tbl2.fromString(var5)
	end

	if typeof(arg1) == "table" then
		if #arg1 == 2 then
			local var8 = arg1[1] .. "e" .. arg1[2]
			return tbl2.fromScientific(var8)
		end

		if #arg1 == 3 then
			local var12 = arg1[1]
			local var13 = arg1[2]
			local var14 = arg1[3]
			return tbl2.correct(tbl2.new(var12, var13, var14))
		end

		if arg1.Sign then
			local var18 = arg1.Sign
			local var19 = arg1.Layer
			local var20 = arg1.Exp
			return tbl2.correct(tbl2.new(var18, var19, var20))
		end
	end

	warn("Returning DefaultReturn at EN.Convert(): Invalid input!", arg1)
	return var2
end

tbl2.toNumber = function(arg1)
	if 1 < arg1.Layer then
		if math.sign(arg1.Exp) == -1 then
			return arg1.Sign * 0
		end

		return arg1.Sign * math.huge
	end

	if arg1.Layer == 0 then
		return arg1.Sign * arg1.Exp
	end

	if arg1.Layer == 1 then
		return arg1.Sign * 10 ^ arg1.Exp
	end

	return 0/0
end

tbl2.abs = function(arg1)
	arg1 = tbl2.convert(arg1)
	if arg1.Sign == 0 then
		return var2
	end

	local num1 = 1
	local var1 = arg1.Layer
	local var3 = arg1.Exp
	return tbl2.new(num1, var1, var3)
end

tbl2.maxAbs = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = tbl2.convert(arg2)
	if tbl2.cmpAbs(arg1, arg2) < 0 then
		return arg2
	end

	return arg1
end

tbl2.neg = function(arg1)
	arg1 = tbl2.convert(arg1)
	local var1 = -arg1.Sign
	local var2 = arg1.Layer
	local var3 = arg1.Exp
	return tbl2.new(var1, var2, var3)
end

tbl2.cmpAbs = function(arg1, arg2)
	local var2 = nil
	var2 = if 0 < arg1.Exp then arg1.Layer else -arg1.Layer
	local var4 = nil
	var4 = if 0 < arg2.Exp then arg2.Layer else -arg2.Layer
	if var4 < var2 then
		return 1
	end

	if var2 < var4 then
		return -1
	end

	if arg2.Exp < arg1.Exp then
		return 1
	end

	if arg1.Exp < arg2.Exp then
		return -1
	end

	return 0
end

tbl2.cmp = function(arg1, arg2)
	if arg2.Sign < arg1.Sign then
		return 1
	end

	if arg1.Sign < arg2.Sign then
		return -1
	end

	return arg1.Sign * tbl2.cmpAbs(arg1, arg2)
end

tbl2.le = function(arg1, arg2)
	return tbl2.cmp(tbl2.convert(arg1), (tbl2.convert(arg2))) == -1
end

tbl2.me = function(arg1, arg2)
	return tbl2.cmp(tbl2.convert(arg1), (tbl2.convert(arg2))) == 1
end

tbl2.eq = function(arg1, arg2)
	return tbl2.cmp(tbl2.convert(arg1), (tbl2.convert(arg2))) == 0
end

tbl2.leeq = function(arg1, arg2)
	return not (tbl2.cmp(tbl2.convert(arg1), (tbl2.convert(arg2))) == 1)
end

tbl2.meeq = function(arg1, arg2)
	return not (tbl2.cmp(tbl2.convert(arg1), (tbl2.convert(arg2))) == -1)
end

tbl2.recip = function(arg1)
	arg1 = tbl2.convert(arg1)
	if arg1.Exp == 0 then
		return var1
	end

	if arg1.Layer == 0 then
		local var4 = arg1.Sign
		local num2 = 0
		local var5 = 1 / arg1.Exp
		return tbl2.new(var4, num2, var5)
	end

	local var6 = arg1.Sign
	local var7 = arg1.Layer
	local var8 = -arg1.Exp
	return tbl2.new(var6, var7, var8)
end

function baseLog(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = tbl2.convert(arg2)
	if arg1.Sign <= 0 or arg2.Sign <= 0 then
		return var1
	end

	if tbl2.IsNaN(arg2) or tbl2.IsNaN(arg1) then
		return var1
	end

	if arg1.Layer == 0 and arg2.Layer == 0 then
		local var2 = arg1.Sign
		local num1 = 0
		local var3 = math.log(arg1.Exp) / math.log(arg2.Exp)
		return tbl2.new(var2, num1, var3)
	end

	local var4 = arg2
	local var5 = tbl2.log10(arg1)
	return tbl2.div(var5, tbl2.log10(var4))
end

tbl2.log = function(arg1, arg2)
	if arg2 then
		local var4 = arg1
		local var5 = arg2
		return baseLog(var4, var5)
	end

	arg1 = tbl2.convert(arg1)
	if arg1.Sign <= 0 then
		return var1
	end

	if arg1.Layer == 0 then
		local var6 = arg1.Sign
		local num1 = 0
		local var7 = math.log10(arg1.Exp) * 2.3025850929940459
		return tbl2.new(var6, num1, var7)
	end

	if arg1.Layer == 1 then
		local var8 = math.sign(arg1.Exp)
		local num2 = 0
		local var9 = math.abs(arg1.Exp) * 2.3025850929940459
		return tbl2.new(var8, num2, var9)
	end

	if arg1.Layer == 2 then
		local var10 = math.sign(arg1.Exp)
		local num3 = 1
		local var11 = math.abs(arg1.Exp) + 0.36221568869946325
		return tbl2.new(var10, num3, var11)
	end

	local var12 = math.sign(arg1.Exp)
	local var13 = arg1.Layer - 1
	local var14 = math.abs(arg1.Exp)
	return tbl2.new(var12, var13, var14)
end

tbl2.log10 = function(arg1)
	arg1 = tbl2.convert(arg1)
	if arg1.Sign <= 0 then
		return var1
	end

	if 0 < arg1.Layer then
		local var2 = math.sign(arg1.Exp)
		local var3 = arg1.Layer - 1
		local var4 = math.abs(arg1.Exp)
		return tbl2.new(var2, var3, var4)
	end

	local var5 = arg1.Sign
	local num1 = 0
	local var6 = math.log10(arg1.Exp)
	return tbl2.new(var5, num1, var6)
end

tbl2.exp = function(arg1)
	arg1 = tbl2.convert(arg1)
	if arg1.Layer == 0 and arg1.Exp <= 709.7 then
		local var1 = math.exp(arg1.Sign * arg1.Exp)
		return tbl2.fromNumber(var1)
	end

	if arg1.Layer == 0 then
		local num3 = 1
		local num4 = 1
		local var3 = arg1.Sign * 0.43429448190325182 * arg1.Exp
		return tbl2.new(num3, num4, var3)
	end

	if arg1.Layer == 1 then
		local num7 = 1
		local num8 = 2
		local var5 = arg1.Sign * (-0.36221568869946325 + arg1.Exp)
		return tbl2.new(num7, num8, var5)
	end

	local num9 = 1
	local var6 = arg1.Layer + 1
	local var7 = arg1.Sign * arg1.Exp
	return tbl2.new(num9, var6, var7)
end

tbl2.add = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = tbl2.convert(arg2)
	if tbl2.IsInf(arg1) or tbl2.IsInf(arg2) then
		return var4
	end

	if tbl2.IsZero(arg1) then
		return arg2
	end

	if tbl2.IsZero(arg2) then
		return arg1
	end

	if arg1.Sign == (-arg2.Sign) and (arg1.Layer == arg2.Layer and arg1.Exp == arg2.Exp) then
		return var2
	end

	local var5 = nil
	local var6 = nil
	if 2 <= arg1.Layer or 2 <= arg2.Layer then
		local var7 = arg1
		local var8 = arg2
		return tbl2.maxAbs(var7, var8)
	end

	if 0 < tbl2.cmpAbs(arg1, arg2) then
		var5 = arg1
		var6 = arg2
	else
		var5 = arg2
		var6 = arg1
	end

	if var5.Layer == 0 and var6.Layer == 0 then
		local var10 = var5.Sign * var5.Exp + var6.Sign * var6.Exp
		return tbl2.fromNumber(var10)
	end

	local var11 = var5.Layer * math.sign(var5.Exp)
	local var12 = var6.Layer * math.sign(var6.Exp)
	if 2 <= var11 - var12 then
		return var5
	end

	if var11 == 0 then
		if var12 == -1 then
			if 100 < math.abs(var6.Exp - math.log10(var5.Exp)) then
				return var5
			end

			local var13 = var6.Sign + var5.Sign * 10 ^ (math.log10(var5.Exp) - var6.Exp)
			local var14 = math.sign(var13)
			local num1 = 1
			local var15 = var6.Exp + math.log10((math.abs(var13)))
			return tbl2.new(var14, num1, var15)
		end
	end

	if var11 == 1 then
		if var12 == 0 then
			if 100 < math.abs(var5.Exp - math.log10(var6.Exp)) then
				return var5
			end

			local var16 = var6.Sign + var5.Sign * 10 ^ (var5.Exp - math.log10(var6.Exp))
			local var17 = math.sign(var16)
			local num2 = 1
			local var18 = math.log10(var6.Exp) + math.log10((math.abs(var16)))
			return tbl2.new(var17, num2, var18)
		end
	end

	if 100 < math.abs(var5.Exp - var6.Exp) then
		return var5
	end

	local var19 = var6.Sign + var5.Sign * 10 ^ (var5.Exp - var6.Exp)
	local var20 = math.sign(var19)
	local num3 = 1
	local var21 = var6.Exp + math.log10((math.abs(var19)))
	return tbl2.new(var20, num3, var21)
end

tbl2.sub = function(arg1, arg2)
	local var1 = tbl2.convert(arg2)
	local var2 = tbl2.convert(arg1)
	return tbl2.add(var2, tbl2.neg(var1))
end

tbl2.toScientific = function(arg1)
	if 2 < arg1.Layer then
		return "Inf"
	end

	if arg1.Layer == 2 and 308 < arg1.Exp then
		return "Inf"
	end

	if tbl2.IsZero(arg1) then
		return "0e0"
	end

	if arg1.Layer == 0 then
		return math.floor(arg1.Exp / 10 ^ math.floor((math.log10(arg1.Exp))) * arg1.Sign * 100) / 100 .. "e" .. math.floor((math.log10(arg1.Exp)))
	end

	if arg1.Layer == 1 then
		return math.floor(10 ^ (arg1.Exp - math.floor(arg1.Exp)) * arg1.Sign * 100) / 100 .. "e" .. math.floor(arg1.Exp)
	end

	local var1 = 10 ^ arg1.Exp
	return 10 ^ (var1 - math.floor(var1)) * arg1.Sign .. "e" .. math.floor(var1)
end

tbl2.mul = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = tbl2.convert(arg2)
	if tbl2.IsInf(arg1) or tbl2.IsInf(arg2) then
		return var4
	end

	if tbl2.IsZero(arg1) or tbl2.IsZero(arg2) then
		return var2
	end

	if arg1.Layer == arg2.Layer and arg1.Exp == (-arg2.Exp) then
		local var5 = arg1.Sign * arg2.Sign
		local num3 = 0
		local num4 = 1
		return tbl2.new(var5, num3, num4)
	end

	local var6 = nil
	local var7 = nil
	if arg2.Layer < arg1.Layer or arg1.Layer == arg2.Layer and math.abs(arg2.Exp) < math.abs(arg1.Exp) then
		var6 = arg1
		var7 = arg2
	else
		var6 = arg2
		var7 = arg1
	end

	if var6.Layer == 0 and var7.Layer == 0 then
		local var9 = var6.Sign * var7.Sign * var6.Exp * var7.Exp
		return tbl2.fromNumber(var9)
	end

	if 3 <= var6.Layer or 2 <= var6.Layer - var7.Layer then
		local var13 = var6.Sign * var7.Sign
		local var14 = var6.Layer
		local var15 = var6.Exp
		return tbl2.new(var13, var14, var15)
	end

	if var6.Layer == 1 and var7.Layer == 0 then
		local var16 = var6.Sign * var7.Sign
		local num5 = 1
		local var17 = var6.Exp + math.log10(var7.Exp)
		return tbl2.new(var16, num5, var17)
	end

	if var6.Layer == 1 and var7.Layer == 1 then
		local var20 = var6.Sign * var7.Sign
		local num7 = 1
		local var21 = var6.Exp + var7.Exp
		return tbl2.new(var20, num7, var21)
	end

	if var6.Layer == 2 and var7.Layer == 1 or var6.Layer == 2 and var7.Layer == 2 then
		local var22 = tbl2.add(tbl2.new(math.sign(var6.Exp), var6.Layer - 1, (math.abs(var6.Exp))), (tbl2.new(math.sign(var7.Exp), var7.Layer - 1, (math.abs(var7.Exp)))))
		local var23 = var6.Sign * var7.Sign
		local var24 = var22.Layer + 1
		local var25 = var22.Sign * var22.Exp
		return tbl2.new(var23, var24, var25)
	end

	return var1
end

tbl2.div = function(arg1, arg2)
	local var1 = tbl2.convert(arg2)
	local var2 = tbl2.convert(arg1)
	return tbl2.mul(var2, tbl2.recip(var1))
end

tbl2.abslog10 = function(arg1)
	arg1 = tbl2.convert(arg1)
	if tbl2.IsZero(arg1) then
		return var1
	end

	if 0 < arg1.Layer then
		local var2 = math.sign(arg1.Exp)
		local var3 = arg1.Layer - 1
		local var4 = math.abs(arg1.Exp)
		return tbl2.new(var2, var3, var4)
	end

	local num1 = 1
	local num2 = 0
	local var5 = math.log10((math.abs(arg1.Exp)))
	return tbl2.new(num1, num2, var5)
end

tbl2.pow10 = function(arg1)
	arg1 = tbl2.convert(arg1)
	if tbl2.IsInf(arg1) then
		return var4
	end

	if arg1.Layer == 0 then
		local var5 = 10 ^ (arg1.Sign * arg1.Exp)
		if var5 < math.huge and 0.1 < math.abs(var5) then
			local num1 = 1
			local num2 = 0
			local var6 = var5
			return tbl2.new(num1, num2, var6)
		end

		if arg1.Sign == 0 then
			return var3
		end

		arg1 = tbl2.new(arg1.Sign, arg1.Layer + 1, (math.log10(arg1.Exp)))
	end

	if 0 < arg1.Sign and 0 < arg1.Exp then
		local var10 = arg1.Sign
		local var11 = arg1.Layer + 1
		local var12 = arg1.Exp
		return tbl2.new(var10, var11, var12)
	end

	if arg1.Sign < 0 and 0 < arg1.Exp then
		local var16 = -arg1.Sign
		local var17 = arg1.Layer + 1
		local var18 = -arg1.Exp
		return tbl2.new(var16, var17, var18)
	end

	return var3
end

tbl2.pow = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = tbl2.convert(arg2)
	if tbl2.IsZero(arg1) then
		return var2
	end

	if arg1.Sign == 1 and (arg1.Layer == 0 and arg1.Exp == 1) then
		return var3
	end

	if tbl2.IsZero(arg2) then
		return var3
	end

	if arg2.Sign == 1 and (arg2.Layer == 0 and arg2.Exp == 1) then
		return arg1
	end

	local var1 = tbl2.abslog10(arg1)
	local var4 = arg2
	local var6 = tbl2.pow10(tbl2.mul(var1, var4))
	if arg1.Sign == -1 and tbl2.toNumber(arg2) % 2 == 1 then
		var1 = var6
		return tbl2.neg(var1)
	end

	if arg1.Sign == -1 and tbl2.toNumber(arg2) < 1e+20 then
		var4 = var6
		local var7 = tbl2.fromNumber((math.cos(tbl2.toNumber(arg2) * 3.1415926535897931)))
		return tbl2.mul(var4, var7)
	end

	return var6
end

function CutDigits(arg1, arg2)
	if arg2 < 0 then
		return arg1
	end

	return math.floor(arg1 * 10 ^ arg2) / 10 ^ arg2
end

local tbl3 = { "k", "M", "B" }
local tbl4 = { "", "U", "D", "T", "Qd", "Qn", "Sx", "Sp", "Oc", "No" }
local tbl5 = { "", "De", "Vt", "Tg", "qg", "Qg", "sg", "Sg", "Og", "Ng" }
local tbl6 = { "", "Ce", "Du", "Tr", "Qa", "Qi", "Se", "Si", "Ot", "Ni" }
local tbl7 = {
	"",
	"Mi",
	"Mc",
	"Na",
	"Pi",
	"Fm",
	"At",
	"Zp",
	"Yc",
	"Xo",
	"Ve",
	"Me",
	"Due",
	"Tre",
	"Te",
	"Pt",
	"He",
	"Hp",
	"Oct",
	"En",
	"Ic",
	"Mei",
	"Dui",
	"Tri",
	"Teti",
	"Pti",
	"Hei",
	"Hp",
	"Oci",
	"Eni",
	"Tra",
	"TeC",
	"MTc",
	"DTc",
	"TrTc",
	"TeTc",
	"PeTc",
	"HTc",
	"HpT",
	"OcT",
	"EnT",
	"TetC",
	"MTetc",
	"DTetc",
	"TrTetc",
	"TeTetc",
	"PeTetc",
	"HTetc",
	"HpTetc",
	"OcTetc",
	"EnTetc",
	"PcT",
	"MPcT",
	"DPcT",
	"TPCt",
	"TePCt",
	"PePCt",
	"HePCt",
	"HpPct",
	"OcPct",
	"EnPct",
	"HCt",
	"MHcT",
	"DHcT",
	"THCt",
	"TeHCt",
	"PeHCt",
	"HeHCt",
	"HpHct",
	"OcHct",
	"EnHct",
	"HpCt",
	"MHpcT",
	"DHpcT",
	"THpCt",
	"TeHpCt",
	"PeHpCt",
	"HeHpCt",
	"HpHpct",
	"OcHpct",
	"EnHpct",
	"OCt",
	"MOcT",
	"DOcT",
	"TOCt",
	"TeOCt",
	"PeOCt",
	"HeOCt",
	"HpOct",
	"OcOct",
	"EnOct",
	"Ent",
	"MEnT",
	"DEnT",
	"TEnt",
	"TeEnt",
	"PeEnt",
	"HeEnt",
	"HpEnt",
	"OcEnt",
	"EnEnt",
	"Hect",
	"MeHect",
}

tbl2.toSuffix = function(arg1, arg2)
	local var1 = tbl2.toScientific(arg1):split("e")
	local var2 = var1[2]
	local var3 = math.fmod(var2, 3)
	var2 = math.floor(var2 / 3) - 1
	arg2 = arg2 or 2
	local var6 = var1[1]
	if var2 <= -1 then
		local var7 = var1[1] * 10 ^ var1[2]
		local var8 = arg2
		return CutDigits(var7, var8)
	end

	if var2 < 3 then
		return CutDigits(var6 * 10 ^ var3, arg2) .. tbl3[var2 + 1]
	end

	local str1 = ""
	if var2 < 1000 then
		local var10 = var2
		local var11 = math.floor(var10 / 100)
		var10 = math.fmod(var10, 100)
		local var12 = math.floor(var10 / 10)
		str1 = str1 .. tbl4[math.floor(math.fmod(var10, 10) / 1) + 1] .. tbl5[var12 + 1] .. tbl6[var11 + 1]
		return CutDigits(var6 * 10 ^ var3, arg2) .. str1
	end

	for i1 = math.floor(math.log10(var2) / 3), 0, -1 do
		if 10 ^ (i1 * 3) > var2 then
			continue
		end

		local var14 = math.floor(var2 / 10 ^ (i1 * 3)) - 1
		if 0 < var14 then
			var14 = var14 + 1
		end

		if 1000 < var14 then
			var14 = math.fmod(var14, 1000)
		end

		local var15 = var14
		local var16 = math.floor(var15 / 100)
		var15 = math.fmod(var15, 100)
		local var17 = math.floor(var15 / 10)
		var14 = str1 .. tbl4[math.floor(math.fmod(var15, 10) / 1) + 1] .. tbl5[var17 + 1] .. tbl6[var16 + 1]
		str1 = var14 .. tbl7[i1 + 1]
		local var18 = math.fmod(var2, 10 ^ (i1 * 3))
	end

	return CutDigits(var6 * 10 ^ var3, arg2) .. str1
end

tbl2.between = function(arg1, arg2, arg3)
	arg1 = tbl2.convert(arg1)
	local var1 = tbl2.me(arg1, (tbl2.convert(arg2)))
	return var1 and tbl2.le(arg1, (tbl2.convert(arg3)))
end

tbl2.toLayerNotation = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	arg2 = arg2 or 2
	if tbl2.between(arg1, var2, var3) then
		local var5 = var3
		local var6 = arg1
		return "1 / " .. tbl2.short(tbl2.div(var5, var6))
	end

	if arg1.Sign == 1 then
		if arg1.Exp < 0 then
			return "E(" .. arg1.Layer .. "-" .. ")" .. CutDigits(math.abs(arg1.Exp), arg2)
		end

		return "E(" .. arg1.Layer .. ")" .. CutDigits(arg1.Exp, arg2)
	end

	if arg1.Sign == 0 then
		return "E(0)0"
	end

	local var7 = tbl2.abs(arg1)
	local var8 = arg2
	return tbl2.toLayerNotation(var7, var8)
end

tbl2.floor = function(arg1)
	arg1 = tbl2.convert(arg1)
	if tbl2.IsNaN(arg1) or (tbl2.IsInf(arg1) or tbl2.IsZero(arg1)) then
		return arg1
	end

	if arg1.Layer == 0 and arg1.Exp < 1000 then
		local var1 = arg1.Sign
		local num1 = 0
		local var2 = math.floor(arg1.Exp)
		return tbl2.new(var1, num1, var2)
	end

	return arg1
end

tbl2.short = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	if tbl2.le(arg1, "1.79e308") then
		local var3 = arg1
		local var4 = arg2
		return tbl2.toSuffix(var3, var4)
	end

	local var5 = arg1
	local var6 = arg2
	return tbl2.toScientific(var5, var6)
end

tbl2.root = function(arg1, arg2)
	local var1 = tbl2.convert(arg2)
	local var2 = tbl2.convert(arg1)
	return tbl2.pow(var2, tbl2.recip(var1))
end

tbl2.sqrt = function(arg1)
	local var1 = tbl2.convert(arg1)
	local num1 = 2
	return tbl2.root(var1, num1)
end

tbl2.gamma = function(arg1)
	arg1 = tbl2.convert(arg1)
	if tbl2.leeq(arg1, var2) then
		return var1
	end

	if arg1.Exp < 0 then
		local var4 = arg1
		return tbl2.recip(var4)
	end

	if arg1.Layer == 0 then
		if tbl2.le(arg1, { 1, 0, 24 }) then
			local var6 = arg1.Sign * arg1.Exp
			return tbl2.fromNumber(F_Gamma(var6))
		end

		local var7 = arg1.Exp - 1
		local var8 = var7
		local var9 = 0.91893853320467267 + (var7 + 0.5) * math.log(var7) - var7
		local var12 = var9 + 1 / (12 * var8)
		local var13 = var7 * var7
		if var12 == var9 then
			local var14 = var9
			return tbl2.exp(var14)
		end

		var8 = var8 * var13
		var9 = var12
		var12 = var9 - 1 / (360 * var8)
		if var12 == var9 then
			local var16 = var9
			return tbl2.exp(var16)
		end

		var8 = var8 * var13
		var9 = var12 + 1 / (1260 * var8)
		local var17 = var9 - 1 / (1680 * (var8 * var13))
		return tbl2.exp(var17)
	end

	if arg1.Layer == 1 then
		local var20 = tbl2.log(arg1)
		local num2 = 1
		local var21 = arg1
		return tbl2.exp(tbl2.mul(var21, tbl2.sub(var20, num2)))
	end

	local var22 = arg1
	return tbl2.exp(var22)
end

tbl2.fact = function(arg1)
	local var1 = tbl2.convert(arg1)
	local num1 = 1
	return tbl2.gamma(tbl2.add(var1, num1))
end

tbl2.rand = function(arg1, arg2)
	local var1 = tbl2.mul(tbl2.sub(arg2, arg1), (math.random()))
	local var2 = arg1
	return tbl2.add(var1, var2)
end

tbl2.exporand = function(arg1, arg2)
	local var1 = tbl2.convert(arg1)
	local var2 = tbl2.convert(arg2)
	local var3 = var1
	local var4 = tbl2.mul(tbl2.exp(tbl2.abs(var3)), var1.Sign)
	local var5 = var2
	local var6 = tbl2.mul(tbl2.exp(tbl2.abs(var5)), var2.Sign)
	var5 = var4
	local var7 = var6
	return tbl2.exp(tbl2.rand(var5, var7))
end

tbl2.lbencode = function(arg1)
	arg1 = tbl2.convert(arg1)
	if tbl2.eq(arg1, 1) then
		return 1
	end

	local num1 = 0
	if arg1.Sign == -1 and (9999 < arg1.Layer and math.sign(arg1.Exp) == 1) then
		num1 = 0
	else
		if arg1.Sign == -1 and (arg1.Layer < 9999 and math.sign(arg1.Exp) == 1) then
			num1 = 1
		else
			if arg1.Sign == -1 and (9999 < arg1.Layer and math.sign(arg1.Exp) == -1) then
				num1 = 2
			else
				if arg1.Sign == -1 and (arg1.Layer < 9999 and math.sign(arg1.Exp) == -1) then
					num1 = 3
				else
					if arg1.Sign == 0 then
						return 4e+18
					end

					if arg1.Sign == 1 and (arg1.Layer < 9999 and math.sign(arg1.Exp) == -1) then
						num1 = 5
					else
						if arg1.Sign == 1 and (9999 < arg1.Layer and math.sign(arg1.Exp) == -1) then
							num1 = 6
						else
							if arg1.Sign == 1 and (arg1.Layer < 9999 and math.sign(arg1.Exp) == 1) then
								num1 = 7
							else
								if arg1.Sign == 1 and (9999 < arg1.Layer and math.sign(arg1.Exp) == 1) then
									num1 = 8
								end
							end
						end
					end
				end
			end
		end
	end

	local var1 = num1 * 1e+18
	if num1 == 8 then
		var1 = var1 + math.log10(arg1.Layer + math.log10(arg1.Exp) / 10) * 3244067411720800
		return var1
	end

	if num1 == 7 then
		var1 = var1 + arg1.Layer * 100000000000000 + math.log10(arg1.Exp) * 10000000000000
		return var1
	end

	if num1 == 6 then
		var1 = var1 + 1e+18 - math.log10(arg1.Layer + math.log10((math.abs(arg1.Exp))) / 10) * 3244067411720800
		return var1
	end

	if num1 == 5 then
		var1 = var1 + (arg1.Layer * 100000000000000 + 100000000000000) - math.log10((math.abs(arg1.Exp))) * 10000000000000
		return var1
	end

	if num1 == 3 then
		local num2 = 0
		var1 = var1 + (arg1.Layer * 100000000000000 + 100000000000000) - math.log10((math.abs(arg1.Exp))) * 10000000000000 + (1e+18 - num2)
		return var1
	end

	if num1 == 2 then
		local num3 = 0
		var1 = var1 + 1e+18 - math.log10(arg1.Layer + math.log10((math.abs(arg1.Exp))) / 10) * 3244067411720800 + (1e+18 - num3)
		return var1
	end

	if num1 == 1 then
		local num4 = 0
		var1 = var1 + arg1.Layer * 100000000000000 + math.log10(arg1.Exp) * 10000000000000 + (1e+18 - num4)
		return var1
	end

	if num1 == 0 then
		local var2 = math.log10(arg1.Layer + math.log10(arg1.Exp) / 10) * 3244067411720800
		var1 = var1 + (1e+18 - var2)
	end

	return var1
end

tbl2.lbdecode = function(arg1)
	if arg1 == 2e+18 then
		local num4 = -1
		local num5 = 0
		local num6 = 1
		return tbl2.new(num4, num5, num6)
	end

	if arg1 == 3e+18 then
		local num10 = -1
		local num11 = 10000
		local num12 = -1
		return tbl2.new(num10, num11, num12)
	end

	if arg1 == 1e+18 then
		local num16 = -1
		local num17 = 0
		local num18 = -1
		return tbl2.new(num16, num17, num18)
	end

	if arg1 == 6e+18 then
		return var3
	end

	if arg1 == 7e+18 then
		local num22 = 1
		local num23 = 10000
		local num24 = 1
		return tbl2.new(num22, num23, num24)
	end

	if arg1 == 5e+18 then
		local num28 = 1
		local num29 = 10000
		local num30 = -1
		return tbl2.new(num28, num29, num30)
	end

	if arg1 == 1 then
		return var3
	end

	local var5 = math.floor(arg1 / 1e+18)
	if var5 == 4 then
		return var2
	end

	if var5 == 0 then
		local var7 = arg1
		var7 = 10 ^ ((1e+18 - var7) / 3244067411720800)
		local num31 = -1
		local var8 = math.floor(var7)
		local var9 = 10 ^ (math.fmod(var7, 1) * 10)
		return tbl2.new(num31, var8, var9)
	end

	if var5 == 8 then
		local var10 = 10 ^ ((arg1 - 8e+18) / 3244067411720800)
		local num32 = 1
		local var11 = math.floor(var10)
		local var12 = 10 ^ (math.fmod(var10, 1) * 10)
		return tbl2.new(num32, var11, var12)
	end

	if var5 == 1 then
		local var14 = arg1 - 1e+18
		var14 = 1e+18 - var14
		local num33 = -1
		local var15 = math.floor(var14 / 100000000000000)
		local var16 = 10 ^ (math.fmod(var14, 100000000000000) / 10000000000000)
		return tbl2.new(num33, var15, var16)
	end

	if var5 == 7 then
		local var18 = arg1 - 7e+18
		local num34 = 1
		local var19 = math.floor(var18 / 100000000000000)
		local var20 = 10 ^ (math.fmod(var18, 100000000000000) / 10000000000000)
		return tbl2.new(num34, var19, var20)
	end

	if var5 == 2 then
		local var21 = 10 ^ ((arg1 - 2e+18) / 3244067411720800)
		local num35 = -1
		local var22 = math.floor(var21)
		local var23 = -(10 ^ (math.fmod(var21, 1) * 10))
		return tbl2.new(num35, var22, var23)
	end

	if var5 == 6 then
		local var25 = arg1 - 6e+18
		var25 = 10 ^ ((1e+18 - var25) / 3244067411720800)
		local num36 = 1
		local var26 = math.floor(var25)
		local var27 = -(10 ^ (math.fmod(var25, 1) * 10))
		return tbl2.new(num36, var26, var27)
	end

	if var5 == 5 then
		local var29 = arg1 - 5e+18
		local num37 = 1
		local var30 = math.floor(var29 / 100000000000000)
		local var31 = -(10 ^ ((100000000000000 - math.fmod(var29, 100000000000000)) / 10000000000000))
		return tbl2.new(num37, var30, var31)
	end

	if var5 == 3 then
		local var33 = arg1 - 3e+18
		var33 = 1e+18 - var33
		local num38 = -1
		local var34 = math.floor(var33 / 100000000000000)
		local var35 = -(10 ^ ((100000000000000 - math.fmod(var33, 100000000000000)) / 10000000000000))
		return tbl2.new(num38, var34, var35)
	end

	return var1
end

tbl2.shift = function(arg1, arg2)
	arg1 = tbl2.convert(arg1)
	if 1 < arg1.Layer then
		return arg1
	end

	if 20 < arg2 then
		return arg1
	end

	local var1 = 10 ^ (arg1.Exp - math.floor(arg1.Exp))
	local var2 = math.floor(arg1.Exp) + math.log10(math.floor(arg2 * 10 ^ arg2) / 10 ^ arg2)
	arg1.Exp = var2
	return arg1
end

return tbl2

--- ReplicatedStorage.Shared.Libs.DraggableObject [ModuleScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = game:GetService("TweenService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local tbl2 = {
		Object = arg1,
		DragStarted = nil,
		DragEnded = nil,
		Dragged = nil,
		Dragging = false,
		TweenInfo = nil,
		BounceTweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
	}

	tbl2._currentTween = nil
	tbl2.LimitEnabled = false
	tbl2.MinScale = Vector2.new(0, 0)
	tbl2.MaxScale = Vector2.new(1, 1)
	setmetatable(tbl2, tbl1)
	return tbl2
end

tbl1.SetTweenInfo = function(arg1, arg2)
	arg1.TweenInfo = arg2
end

tbl1.SetBounceTweenInfo = function(arg1, arg2)
	arg1.BounceTweenInfo = arg2
end

tbl1.EnableLimit = function(arg1)
	arg1.LimitEnabled = true
	arg1.MinScale = Vector2.new(0, 0)
	local var1 = arg1.Object.Size
	arg1.MaxScale = Vector2.new(1 - var1.X.Scale, 1 - var1.Y.Scale)
end

tbl1.DisableLimit = function(arg1)
	arg1.LimitEnabled = false
end

local var3 = UDim2.new
tbl1._getBoundedPosition = function(arg1)
	local var1 = arg1.Object.Position
	local var2 = math.clamp(var1.X.Scale, arg1.MinScale.X, arg1.MaxScale.X)
	local var4 = var1.X.Offset
	local var5 = math.clamp(var1.Y.Scale, arg1.MinScale.Y, arg1.MaxScale.Y)
	local var6 = var1.Y.Offset
	return var3(var2, var4, var5, var6)
end

tbl1.EnableLimitFromFrame = function(arg1, arg2)
	local var1 = arg1.Object
	local var2 = var1.Parent
	local var3 = arg2.AbsolutePosition
	local var4 = var2.AbsolutePosition
	local var5 = var2.AbsoluteSize
	local var6 = arg2.AbsoluteSize
	local var7 = var1.AbsoluteSize
	arg1.LimitEnabled = true
	arg1.MinScale = Vector2.new((var3.X - var4.X) / var5.X, (var3.Y - var4.Y) / var5.Y)
	arg1.MaxScale = Vector2.new((var3.X - var4.X + var6.X - var7.X) / var5.X, (var3.Y - var4.Y + var6.Y - var7.Y) / var5.Y)
end

tbl1._bounceIfOutOfBounds = function(arg1)
	if not arg1.LimitEnabled then
		return
	end

	local var1 = arg1.Object
	local var4 = arg1:_getBoundedPosition()
	if var4 ~= var1.Position then
		if arg1._currentTween then
			arg1._currentTween:Cancel()
		end

		arg1._currentTween = var2:Create(var1, arg1.BounceTweenInfo, { Position = var4 })
		arg1._currentTween:Play()
	end
end

tbl1.Enable = function(arg1)
	local var4 = nil
	local var5 = nil
	local var6 = arg1.Object
	local bool1 = false
	arg1.InputBegan = var6.InputBegan:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.Touch then
			bool1 = true
			local var1 = nil
			arg1.Changed:Connect(function()
				if arg1.UserInputState == Enum.UserInputState.End and (arg1.Dragging or bool1) then
					arg1.Dragging = false
					var1:Disconnect()
					if arg1.DragEnded and (not bool1) then
						arg1.DragEnded()
					end

					bool1 = false
					arg1:_bounceIfOutOfBounds()
				end
			end)

		end
	end)

	local var7 = nil
	arg1.InputChanged = var6.InputChanged:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseMovement or arg1.UserInputType == Enum.UserInputType.Touch then
			var7 = arg1
		end
	end)

	local function update(arg1)
		local var1 = arg1.Position - var4
		local var7 = var3(var5.X.Scale, var5.X.Offset + var1.X, var5.Y.Scale, var5.Y.Offset + var1.Y)
		if arg1.TweenInfo then
			if arg1._currentTween then
				arg1._currentTween:Cancel()
			end

			arg1._currentTween = var2:Create(var6, arg1.TweenInfo, { Position = var7 })
			arg1._currentTween:Play()
			return var7
		end

		var6.Position = var7
		return var7
	end

	arg1.InputChanged2 = var1.InputChanged:Connect(function(arg1)
		if var6.Parent == nil then
			arg1:Disable()
			return
		end

		if bool1 then
			bool1 = false
			if arg1.DragStarted then
				arg1.DragStarted()
			end

			arg1.Dragging = true
			var4 = arg1.Position
			var5 = var6.Position
		end

		local var1 = update(arg1)
		if arg1 == var7 and (arg1.Dragging and arg1.Dragged) then
			arg1.Dragged(var1)
		end
	end)
end

tbl1.Disable = function(arg1)
	arg1.InputBegan:Disconnect()
	arg1.InputChanged:Disconnect()
	arg1.InputChanged2:Disconnect()
	if arg1._currentTween then
		arg1._currentTween:Cancel()
		arg1._currentTween = nil
	end

	if arg1.Dragging then
		arg1.Dragging = false
		if arg1.DragEnded then
			arg1.DragEnded()
		end
	end
end

return tbl1

--- ReplicatedStorage.Shared.Config.GameConfig [ModuleScript]
-- y u r i

local tbl1 = { GamePasses = {
	Prestige = 1918239622,
	Steel = 1917873620,
	Space = 1918371647,
	DarkMatter = 1942303477,
	Supernova = 1942111508,
	X3ALLSTATS = 1944012772,
	VIP = 1944438685,
	VIPPLUS = 1942028048,
} }

tbl1.FlyToolGamePass = tbl1.GamePasses.VIPPLUS
tbl1.FlyToolName = "Fly"
tbl1.GroupId = 1071522060
tbl1.AdminUserIds = { [2577214977] = true, [1837214769] = true }
tbl1.AdminToolUserIds = { 2577214977, 1837214769 }
tbl1.AdminToolNames = { "BTools", "FlyTool" }
tbl1.SpecialCases = {
	NoGamePassBoostsUserId = 2577214977,
	NovaOverrideUserId = 2577214977,
	NovaOverrideAmount = 0,
}

tbl1.MaxSlots = 5
tbl1.SaveSyncInterval = 5
tbl1.Tick = {
	BoostRecompute = 0.14,
	Accumulate = 0.1,
	Automation = 0.15,
	AttributeSync = 0.1,
	LevelUp = 1,
	StarLevelUp = 0.2,
	AutoBuySoundGap = 0.05,
	ChallengeGoalCheck = 0.5,
}

tbl1.Debounce = { BuyOne = 0.1, BuyMax = 0.1 }
tbl1.Thresholds = {
	PrestigePoints = 1e+18,
	SteelPower = 1000000000000,
	SpacePrestigeStars = 30,
	SupernovaLoops = 10,
	LoopLevelsPerLoop = 100,
}

tbl1.AutomationPauseDuration = 0.1
tbl1.HoldToBuy = { HoldThreshold = 0.18, BurstCount = 14, BurstInterval = 0.05, BuyMaxRepeat = 0.05 }
tbl1.NonHoldableUpgrades = { ["#B1\206\148"] = true }
tbl1.KeycapMilestones = { SteelScaling = 1000000000, FiveCurrency = 10000000000000, TenCurrency = 2.5e+16 }
return tbl1

--- ReplicatedStorage.Shared.Config.Stats [ModuleScript]
-- y u r i

local str1 = "NovaSpent"
local tbl1 = {
	Order = {
		"Points",
		"Gamma",
		"Delta",
		"Omega",
		"XP",
		"Level",
		"Prestige",
		"Power",
		"Steel",
		"Keycap",
		"SpacePoints",
		"StarLevels",
		"StarXP",
		"SpacePrestige",
		"Loops",
		"DarkMatter",
		"SupernovaTier",
		"Nova",
		"MaxNova",
		str1,
	},
	IsStat = {},
}

for k1, v1 in ipairs(tbl1.Order) do
	tbl1.IsStat[v1] = true
end

tbl1.DefaultValue = "0"
tbl1.BoostTemplate = {
	Points = { Base = 0, Mult = 1, Expo = 1 },
	XP = { Base = 0, Mult = 1, Expo = 1 },
	Level = { Base = 0, Mult = 1, Expo = 1 },
	Prestige = { Base = 1, Mult = 1, Expo = 1 },
	Power = { Base = 0, Mult = 1, Expo = 1 },
	Steel = { Base = 1, Mult = 1, Expo = 1 },
	Keycap = { Base = 1, Mult = 1, Expo = 1 },
	SpacePoints = { Base = 0, Mult = 1, Expo = 1 },
	StarXP = { Base = 0, Mult = 1, Expo = 1 },
	StarLevels = { Base = 0, Mult = 1, Expo = 1 },
	SpacePrestige = { Base = 0, Mult = 1, Expo = 1 },
	Loops = { Base = 0, Mult = 1, Expo = 1 },
	DarkMatter = { Base = 0, Mult = 1, Expo = 1 },
	Gamma = { Base = 0, Mult = 1, Expo = 1 },
	Delta = { Base = 0, Mult = 1, Expo = 1 },
	Omega = { Base = 1, Mult = 1, Expo = 1 },
	SupernovaTier = { Base = 1, Mult = 1, Expo = 1 },
	Nova = { Base = 1, Mult = 1, Expo = 1 },
	MaxNova = { Base = 1, Mult = 1, Expo = 1 },
	NovaSpent = { Base = 1, Mult = 1, Expo = 1 },
}

tbl1.TickBaseDefaults = {
	XP = 1,
	Level = 1,
	Keycap = 1,
	Prestige = 1,
	Steel = 1,
	StarXP = 1,
	SpacePrestige = 1,
	Loops = 1,
	Nova = 1,
	MaxNova = 1,
	SupernovaTier = 1,
}

tbl1.Accumulating = { "Points", "SpacePoints", "Power", "Gamma", "DarkMatter" }
tbl1.Symbol = {
	Points = "P$",
	Gamma = "\206\179",
	Delta = "\206\148",
	Keycap = "Keycaps",
	Prestige = "PP$",
	Steel = "Steel",
	Power = "Power",
	SpacePoints = "SP$",
	SpacePrestige = "SPP$",
	Loops = "Loops",
	DarkMatter = "DM$",
	SupernovaTier = "SN$",
	Omega = "\206\169",
}

local tbl2 = { TextColor = Color3.fromRGB(213, 213, 213) }
tbl2.GradientColor = Color3.fromRGB(255, 255, 255)
tbl2.StrokeColor = Color3.new(0, 0, 0)
local tbl3 = { Points = tbl2 }
tbl2 = { TextColor = Color3.fromRGB(235, 120, 120) }
tbl2.StrokeColor = Color3.new(0, 0, 0)
tbl3.Gamma = tbl2
tbl2 = { TextColor = Color3.fromRGB(140, 235, 150) }
tbl2.StrokeColor = Color3.new(0, 0, 0)
tbl3.Delta = tbl2
tbl2 = { TextColor = Color3.fromRGB(90, 90, 90) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.Keycap = tbl2
tbl2 = { TextColor = Color3.fromRGB(255, 205, 60) }
tbl2.StrokeColor = Color3.new(0, 0, 0)
tbl3.Prestige = tbl2
tbl2 = { TextColor = Color3.fromRGB(90, 90, 90) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.Steel = tbl2
tbl2 = { TextColor = Color3.fromRGB(255, 245, 150) }
tbl2.StrokeColor = Color3.new(0, 0, 0)
tbl3.Power = tbl2
tbl2 = { TextColor = Color3.fromRGB(85, 45, 130) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.SpacePoints = tbl2
tbl2 = { TextColor = Color3.fromRGB(150, 90, 220) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.SpacePrestige = tbl2
tbl2 = { TextColor = Color3.fromRGB(150, 150, 150) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.Loops = tbl2
tbl2 = { TextColor = Color3.fromRGB(15, 0, 38) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.DarkMatter = tbl2
tbl2 = { TextColor = Color3.fromRGB(51, 137, 243) }
tbl2.StrokeColor = Color3.new(1, 1, 1)
tbl3.SupernovaTier = tbl2
tbl1.Colors = tbl3
tbl1.DefaultTextColor = Color3.fromRGB(255, 255, 255)
tbl1.DefaultStrokeColor = Color3.new(0, 0, 0)
tbl1.AlwaysPerSecond = { Points = true, Gamma = true, Power = true, SpacePoints = true }
tbl1.PerSecondSuffix = "/s"
tbl1.ClickSuffix = ""
tbl1.CustomHUDFormat = { Loops = "%s Loops", SupernovaTier = "Supernova Tier %s (+%s SNT)" }
return tbl1

--- ReplicatedStorage.Shared.Config.Upgrades [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.Util)
local var2 = require(game:GetService("ReplicatedStorage").Shared.Libs.EternityNum)
local var3 = var1.pcmore0
local tbl1 = {
	TitleText = "You'll need this..",
	DescText = "+1M Base Points gain, good luck. (supernova challenge 2) [PERMANENT]",
	PrestigeCost = var2.pow(10, 719),
	Permanent = true,
	PointsBase = 1000000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1e719 PP$",
}

tbl1.VisibleIf = function(arg1, arg2)
	return 0 < arg1["#8p"].purchaseCount and var2.meeq(arg2.Values.Loops.Value, 11) or var3(arg1, "#15p")
end

local tbl2 = {
	["#1"] = {
		TitleText = "Start of Everything",
		DescText = "Generate 1 Points (P$) every second.",
		PointsCost = 0,
		PointsBase = 1,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: Free!",
		VisibleIf = function(_, _)
			return true
		end,
	},
	["#1Leaderboard"] = {
		TitleText = "Show your glory",
		DescText = "Unlocks Leaderboards",
		PointsCost = 1000,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 1000 P$",
		VisibleIf = function(arg1, _)
			local var1 = arg1
			local str1 = "#1"
			return var3(var1, str1)
		end,
	},
	["#Secret"] = {
		TitleText = "???",
		DescText = "...?",
		purchaseCount = 0,
		max = 1,
		CostText = "Free..?",
		VisibleIf = function(arg1, _)
			local var1 = arg1
			local str1 = "#10dm"
			return var3(var1, str1)
		end,
	},
	["#2"] = {
		TitleText = "First Upgrade Bought",
		DescText = "Gain x1.5 more Points (P$)",
		PointsCost = function(_, arg2)
			local var1 = var2.pow(1.5, arg2.purchaseCount)
			local num1 = 3
			return var2.toString(var2.mul(var1, num1))
		end,
		PointsMult = function(_, arg2)
			return 1.5 ^ arg2.purchaseCount
		end,
		purchaseCount = 0,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
		end,
		max = 8,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#1"].purchaseCount
		end,
	},
	["#3"] = {
		TitleText = "Gain more Points",
		DescText = "Gain x10 more Points (P$)",
		PointsCost = 100,
		PointsMult = 10,
		CostText = "Cost: 100 P$",
		max = 1,
		purchaseCount = 0,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#2"].purchaseCount
		end,
	},
	["#4"] = {
		TitleText = "Gain MORE points",
		DescText = "Gain x3 more Points (P$)",
		PointsCost = function(_, arg2)
			local var1 = var2.pow(5, arg2.purchaseCount)
			local num1 = 1000
			return var2.toString(var2.mul(var1, num1))
		end,
		PointsMult = function(_, arg2)
			return 3 ^ arg2.purchaseCount
		end,
		purchaseCount = 0,
		max = 12,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
		end,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#2"].purchaseCount
		end,
	},
	["#5"] = {
		TitleText = "Unlock Leveling",
		DescText = "Unlock Levels that can boost Points (P$)",
		PointsCost = 50000,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 50k P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#3"].purchaseCount
		end,
	},
	["#6"] = {
		TitleText = "Strong Boost",
		DescText = "x8 Points gain",
		PointsCost = 500000,
		PointsMult = 8,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 500k P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#4"].purchaseCount
		end,
	},
	["#7"] = {
		TitleText = "Experience Multiplier",
		DescText = "x2 XP gain",
		PointsCost = function(_, arg2)
			local var1 = var2.pow(math.max(5, (math.min(10, arg2.purchaseCount * 2.5))), arg2.purchaseCount)
			local num1 = 5000000
			return var2.mul(var1, num1)
		end,
		purchaseCount = 0,
		XPMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		max = 10,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
		end,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#5"].purchaseCount
		end,
	},
	["#8"] = {
		TitleText = "Exponentiation Boost",
		DescText = "^1.1 Points gain",
		PointsCost = 75000000,
		purchaseCount = 0,
		PointsExpo = 1.1,
		max = 1,
		CostText = "Cost: 75M P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#7"].purchaseCount
		end,
	},
	["#9"] = {
		TitleText = "Double Boost",
		DescText = "x4 Points and XP gain",
		PointsCost = 600000000000,
		purchaseCount = 0,
		PointsMult = 4,
		XPMult = 4,
		max = 1,
		CostText = "Cost: 600B P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#8"].purchaseCount
		end,
	},
	["#10"] = {
		TitleText = "Even more Points",
		DescText = "^1.05 Points gain",
		PointsCost = 25000000000000,
		purchaseCount = 0,
		PointsExpo = 1.05,
		max = 1,
		CostText = "Cost: 25T P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#8"].purchaseCount
		end,
	},
	["#11"] = {
		TitleText = "Massive Points",
		DescText = "x25 Points gain",
		PointsCost = 1000000000000000,
		purchaseCount = 0,
		PointsMult = 25,
		max = 1,
		CostText = "Cost: 1Qd P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#10"].purchaseCount
		end,
	},
	["#12"] = {
		TitleText = "PRESTIGE!",
		DescText = "x5 Points gain and unlocks Prestiges",
		PointsCost = 5e+16,
		purchaseCount = 0,
		PointsMult = 5,
		max = 1,
		CostText = "Cost: 50Qd P$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#11"].purchaseCount
		end,
	},
	["#1p"] = {
		TitleText = "Powerful Boosts",
		DescText = "x3 Points and x2 XP gain",
		PrestigeCost = 1,
		purchaseCount = 0,
		PointsMult = 3,
		XPMult = 2,
		max = 1,
		CostText = "Cost: 1 PP$",
		VisibleIf = function(arg1, arg2)
			local bool2 = true
			if 0 >= arg1["#12"].purchaseCount then
				bool2 = var2.me(arg2.Values.Prestige.Value, 0)
			end

			return bool2
		end,
	},
	["#2p"] = {
		TitleText = "Even Stronger Boosts",
		DescText = "x5 Points and x3 XP gain",
		PrestigeCost = 2,
		purchaseCount = 0,
		PointsMult = 5,
		XPMult = 3,
		max = 1,
		CostText = "Cost: 2 PP$",
		VisibleIf = function(arg1, arg2)
			local bool2 = true
			if 0 >= arg1["#12"].purchaseCount then
				bool2 = var2.me(arg2.Values.Prestige.Value, 0)
			end

			return bool2
		end,
	},
	["#3p"] = {
		TitleText = "Prestiged Currencies",
		DescText = "x2 Points and XP gain",
		PrestigeCost = function(_, arg2)
			if 6 <= arg2.purchaseCount then
				local var1 = 10 ^ math.floor(arg2.purchaseCount / 3)
				var1 = var1 or 1
			end

			return 1 * math.min(4, (math.max(2, arg2.purchaseCount))) ^ arg2.purchaseCount
		end,
		purchaseCount = 0,
		XPMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		PointsMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		max = 10,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PrestigeCost(var1, var3)) .. " P$"
		end,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#1p"].purchaseCount
		end,
	},
	["#4p"] = {
		TitleText = "Super Prestige",
		DescText = "x2 Prestiges gain",
		PrestigeCost = function(_, arg2)
			if 5 <= arg2.purchaseCount then
				local var1 = 10 ^ math.floor(arg2.purchaseCount / 2)
				var1 = var1 or 1
			end

			return 1 * 5 ^ arg2.purchaseCount * 2
		end,
		purchaseCount = 0,
		PrestigeMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		max = 8,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PrestigeCost(var1, var3)) .. " PP$"
		end,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#1p"].purchaseCount
		end,
	},
	["#5p"] = {
		TitleText = "More Upgrades",
		DescText = "Unlock more Point Upgrades",
		PrestigeCost = 30,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 30 PP$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#2p"].purchaseCount
		end,
	},
	["#6p"] = {
		TitleText = "Prestige Exponent",
		DescText = "^1.1 PP$ gain",
		PrestigeCost = 144000,
		purchaseCount = 0,
		PrestigeExpo = 1.1,
		max = 1,
		CostText = "Cost: 144k PP$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#5p"].purchaseCount
		end,
	},
	["#7p"] = {
		TitleText = "New baseplate",
		DescText = "Unlock the Power sub-baseplate",
		PrestigeCost = 750000,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 750k PP$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#5p"].purchaseCount
		end,
	},
	["#8p"] = {
		TitleText = "A Lot More Points",
		DescText = "x20 Points",
		PointsMult = 20,
		PrestigeCost = 50000000,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 50M PP$",
		VisibleIf = function(arg1, _)
			local bool1 = false
			if 0 < arg1["#7p"].purchaseCount then
				bool1 = 0 < arg1["#5p"].purchaseCount
			end

			return bool1
		end,
	},
	["#9p"] = {
		TitleText = "Prestige Boosts",
		DescText = "x8 XP, x4 PP$, x3 P$",
		PrestigeCost = 250000000000,
		purchaseCount = 0,
		XPMult = 8,
		PrestigeMult = 4,
		PointsMult = 3,
		max = 1,
		CostText = "Cost: 250B PP$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#8p"].purchaseCount
		end,
	},
	["#10p"] = {
		TitleText = "The Power Push",
		DescText = "x100 Power",
		PrestigeCost = 50000000000000,
		PowerMult = 100,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 50T PP$",
		VisibleIf = function(arg1, _)
			return 0 < arg1["#9p"].purchaseCount
		end,
	},
	["#11p"] = {
		TitleText = "Bonus Boosts",
		DescText = "x2 Power and PP$",
		PrestigeCost = function(_, arg2)
			return 10 ^ arg2.purchaseCount * 10000000000000
		end,
		purchaseCount = 0,
		max = 5,
		PrestigeMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		PowerMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PrestigeCost(var1, var3)) .. " P$"
		end,
		VisibleIf = function(arg1, _)
			return 0 < arg1["#10p"].purchaseCount
		end,
	},
	["#12p"] = {
		TitleText = "Currency Rush",
		DescText = "x100 Points, XP, PP$, Power",
		PrestigeCost = 5e+21,
		PowerMult = 100,
		XPMult = 100,
		PointsMult = 100,
		PrestigeMult = 100,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 5Sx PP$",
		VisibleIf = function(arg1, _)
			local bool2 = false
			if 0 < arg1["#9p"].purchaseCount then
				bool2 = var3(arg1, "#3s")
			end

			return bool2
		end,
	},
	["#13p"] = {
		TitleText = "Steeling",
		DescText = "x2 Steel",
		PrestigeCost = function(_, arg2)
			return 100 ^ arg2.purchaseCount * 1e+27
		end,
		purchaseCount = 0,
		max = 5,
		SteelMult = function(_, arg2)
			return 2 ^ arg2.purchaseCount
		end,
		CostText = function(arg1, arg2)
			local var1 = arg1
			local var3 = arg2
			return "Cost: " .. var2.short(arg2.PrestigeCost(var1, var3)) .. " PP$"
		end,
		VisibleIf = function(arg1, _)
			local bool2 = false
			if 0 < arg1["#10p"].purchaseCount then
				bool2 = var3(arg1, "#3s")
			end

			return bool2
		end,
	},
	["#14p"] = {
		TitleText = "POWER",
		DescText = "x1De Power",
		PrestigeCost = 5e+132,
		PowerMult = 1e+33,
		purchaseCount = 0,
		max = 1,
		CostText = "Cost: 50Tqg PP$",
		VisibleIf = function(arg1, _)
			local bool2 = false
			if 0 < arg1["#6p"].purchaseCount then
				bool2 = var3(arg1, "#10s")
			end

			return bool2
		end,
	},
	["#15p"] = tbl1,
}

tbl2["#1g"] = {
	TitleText = "Powering Prestige",
	DescText = "Start generating Power at a rate of 1/s",
	PrestigeCost = 0,
	PowerBase = 1,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: Free!",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#7p"].purchaseCount
	end,
}

tbl2["#2g"] = {
	TitleText = "Points -> Power",
	DescText = "x3 Power gain",
	PointsCost = function(_, arg2)
		return 100 ^ arg2.purchaseCount * 1e+24
	end,
	PowerMult = function(_, arg2)
		return 3 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1g"].purchaseCount
	end,
}

tbl2["#3g"] = {
	TitleText = "Prestige -> Power",
	DescText = "x10 Power gain",
	PrestigeCost = 2000000,
	PowerMult = 10,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 2M PP$",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2g"].purchaseCount
	end,
}

tbl2["#4g"] = {
	TitleText = "Power -> Power?",
	DescText = "x1.1 Power gain",
	PowerCost = function(_, arg2)
		return 1.25 ^ arg2.purchaseCount * 20
	end,
	PowerMult = function(_, arg2)
		return 1.1 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 100,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PowerCost(var1, var3)) .. " Power"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2g"].purchaseCount
	end,
}

tbl2["#5g"] = {
	TitleText = "Kinda powered",
	DescText = "x5 Power",
	PowerCost = 100000,
	PowerMult = 5,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 100k Power",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4g"].purchaseCount
	end,
}

tbl2["#6g"] = {
	TitleText = "Super Powered",
	DescText = "Power now also boosts XP!",
	PowerCost = 1000000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1M Power",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4g"].purchaseCount
	end,
}

tbl2["#7g"] = {
	TitleText = "Almost There",
	DescText = "x500 Points",
	PowerCost = 15000000000,
	PointsMult = 500,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 15B Power",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#5g"].purchaseCount
	end,
}

tbl2["#8g"] = {
	TitleText = "Steel Reset",
	DescText = "Unlock the Steel reset",
	PowerCost = 1000000000000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1T Power",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#7g"].purchaseCount
	end,
}

tbl2["#9g"] = {
	TitleText = "THE Steel power",
	DescText = "x100k Power",
	PowerCost = 1e+17,
	purchaseCount = 0,
	max = 1,
	PowerMult = 100000,
	CostText = "Cost: 100Qd Power",
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#7g"].purchaseCount then
			bool2 = var3(arg1, "#3s")
		end

		return bool2
	end,
}

tbl2["#10g"] = {
	TitleText = "Steel squared?",
	DescText = "Power now also boosts Steel",
	PowerCost = 1e+32,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 100No Power",
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#7g"].purchaseCount then
			bool2 = var3(arg1, "#3s")
		end

		return bool2
	end,
}

tbl2["#11g"] = {
	TitleText = "Power -> Even More Power",
	DescText = "x10 Power gain",
	PowerCost = function(_, arg2)
		return 15 ^ arg2.purchaseCount * 1e+22
	end,
	PowerMult = function(_, arg2)
		return 10 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 100,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PowerCost(var1, var3)) .. " Power"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#9g"].purchaseCount then
			bool2 = var3(arg1, "#3s")
		end

		return bool2
	end,
}

tbl2["#12g"] = {
	TitleText = "ROUND TWO",
	DescText = "x1000 Power gain",
	PowerCost = function(_, arg2)
		local var1 = var2.pow(4000, arg2.purchaseCount)
		local num1 = 1e+138
		return var2.mul(var1, num1)
	end,
	PowerMult = function(_, arg2)
		local num1 = 1000
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = 200,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PowerCost(var1, var3)) .. " Power"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 0 < arg1["#11g"].purchaseCount then
			bool2 = var3(arg1, "#10s")
			bool2 = bool2 and var2.meeq(arg2.Values.Loops.Value, 5)
		end

		return bool2
	end,
}

tbl2["#13g"] = {
	TitleText = "round 3 [overused joke]",
	DescText = "x10DTg Power gain",
	PowerCost = function(_, arg2)
		local var1 = arg2.purchaseCount
		local num1 = 10
		local num2 = 2500
		local var5 = var2.mul(var2.pow(var2.pow(10, 500), var1), var2.pow(num1, num2))
		if 50 < var1 then
			local var6 = var2.pow(10, 150)
			local var7 = var1 - 50
			var5 = var2.mul(var5, var2.pow(var6, var7))
		end

		return var5
	end,
	PowerMult = function(_, arg2)
		local num1 = 1e+100
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = 300,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PowerCost(var1, var3)) .. " Power"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#12g"].purchaseCount then
			bool2 = var3(arg1, "#8dm")
		end

		return bool2
	end,
}

tbl2["#14g"] = {
	TitleText = "to infinity and beyond",
	DescText = "x100 Power gain",
	PowerMult = function(_, arg2)
		local num1 = 100
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = math.huge,
	PrestigeCost = function(_, arg2)
		local num1 = 10
		local var1 = 189 + arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PrestigeCost(var1, var3)) .. " PP$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#7g"].purchaseCount then
			bool2 = var3(arg1, "#8dm")
		end

		return bool2
	end,
}

tbl1 = {
	TitleText = "boosting itself and xp",
	DescText = "Power boosts itself and XP [Formula: log10(Power+10)^1.5",
	XPMult = function(arg1, _)
		local var1 = arg1.Values.Power.Value
		local num1 = 10
		local var3 = var2.log10(var2.add(var1, num1))
		local num2 = 1.5
		return var2.pow(var3, num2)
	end,
	PowerMult = function(arg1, _)
		local var1 = arg1.Values.Power.Value
		local num1 = 10
		local var3 = var2.log10(var2.add(var1, num1))
		local num2 = 1.5
		return var2.pow(var3, num2)
	end,
	MaxedText = function(arg1, _)
		local var1 = arg1.Values.Power.Value
		local num1 = 10
		local var3 = var2.log10(var2.add(var1, num1))
		local num2 = 1.5
		return "Maxed! (x" .. var2.short(var2.pow(var3, num2)) .. " Power & XP)"
	end,
	PowerCost = var2.pow(10, 10000),
	purchaseCount = 0,
	max = 1,
}

tbl1.CostText = function(_, arg2)
	return "Cost: " .. var2.short(arg2.PowerCost) .. " Power"
end

tbl1.VisibleIf = function(arg1, _)
	local bool2 = false
	if 0 < arg1["#12g"].purchaseCount then
		bool2 = var3(arg1, "#8dm")
	end

	return bool2
end

tbl2["#15g"] = tbl1
tbl2["#16g"] = {
	TitleText = "Nova :D",
	DescText = "+0.5 Nova (protip: #13s, and manually prestige/steel)",
	PowerCost = function(_, arg2)
		local num1 = 10
		local num2 = 18000
		local var1 = var2.pow(var2.pow(10, 10000), arg2.purchaseCount)
		return var2.mul(var1, var2.pow(num1, num2))
	end,
	PowerMult = function(_, arg2)
		local num1 = 1e+100
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PowerCost(var1, var3)) .. " Power"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#14g"].purchaseCount and var3(arg1, "#4nv") or var3(arg1, "#16g")
	end,
	Permanent = true,
}

tbl1 = {
	TitleText = "Powered again",
	DescText = "Power boosts Power (actually this time; btw formula's quite strong!)",
	PowerCost = var2.pow(10, 57000),
	purchaseCount = 0,
	max = 1,
}

tbl1.CostText = function(_, arg2)
	return "Cost: " .. var2.short(arg2.PowerCost) .. " Power"
end

tbl1.VisibleIf = function(arg1, arg2)
	local bool2 = false
	if 0 < arg1["#13g"].purchaseCount then
		bool2 = var2.meeq(arg2.Values.Loops.Value, 11)
	end

	return bool2
end

tbl2["#17g"] = tbl1
tbl2["#13"] = {
	TitleText = "Untitled Upgrade",
	DescText = "x15 XP and Points gain",
	PointsCost = 5e+22,
	purchaseCount = 0,
	XPMult = 15,
	PointsMult = 15,
	max = 1,
	CostText = "Cost: 50Sx P$",
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#5p"].purchaseCount then
			bool1 = 0 < arg1["#7"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#14"] = {
	TitleText = "Very Super Powerful Upgrade",
	DescText = "x1.5 Prestige (PP$) gain",
	PrestigeMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	PointsCost = function(_, arg2)
		return 100 ^ arg2.purchaseCount * 1e+22
	end,
	purchaseCount = 0,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#5p"].purchaseCount then
			bool1 = 0 < arg1["#12"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#15"] = {
	TitleText = "Automation",
	DescText = "Unlock Autobuyer Baseplate [PERMANENT]",
	PointsCost = 1e+25,
	purchaseCount = 0,
	Permanent = true,
	max = 1,
	CostText = "Cost: 10Sp P$",
	VisibleIf = function(arg1, _)
		local bool1 = true
		if 0 >= arg1["#15"].purchaseCount then
			bool1 = 0 < arg1["#13"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#16"] = {
	TitleText = "Powerful Upgrade",
	DescText = "x2 Points gain",
	PointsCost = function(_, arg2)
		return 5 ^ arg2.purchaseCount * 1e+26
	end,
	purchaseCount = 0,
	PointsMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	max = 10,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#13"].purchaseCount
	end,
}

tbl2["#17"] = {
	TitleText = "Steel-Sponsored Points",
	DescText = "x10 Points gain",
	PointsCost = function(_, arg2)
		return 1000 ^ arg2.purchaseCount * 1e+42
	end,
	purchaseCount = 0,
	PointsMult = function(_, arg2)
		return 10 ^ arg2.purchaseCount
	end,
	max = 10,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#3s"].purchaseCount then
			bool1 = 0 < arg1["#10"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#18"] = {
	TitleText = "Steel-Sponsored XP",
	DescText = "^1.1 XP gain",
	PointsCost = function(_, _)
		return 1e+57
	end,
	purchaseCount = 0,
	XPExpo = 1.1,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#3s"].purchaseCount then
			bool1 = 0 < arg1["#7"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#19"] = {
	TitleText = "POWER^2",
	DescText = "^2 Power gain",
	PointsCost = function(_, _)
		return 1e+273
	end,
	purchaseCount = 0,
	PowerExpo = 2,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#10s"].purchaseCount then
			bool1 = 0 < arg1["#17"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#20"] = {
	TitleText = "nice xp gain",
	DescText = "x7.5 XP gain",
	PointsCost = function(_, arg2)
		local num1 = 10
		local var1 = 367 + arg2.purchaseCount + (1 <= arg2.purchaseCount - 14 and arg2.purchaseCount - 14 or 0) + (1 <= arg2.purchaseCount - 43 and arg2.purchaseCount - 20 or 0)
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	XPMult = function(_, arg2)
		return 7.5 ^ arg2.purchaseCount
	end,
	max = 100,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.PointsCost(var1, var3)) .. " P$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#16"].purchaseCount then
			bool1 = 0 < arg1["#8dm"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#1a"] = {
	TitleText = "First Auto-buyer",
	DescText = "Auto-buys #1 to #4",
	PointsCost = 1e+26,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 100Sp P$",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#15"].purchaseCount
	end,
	Auto = { "#1", "#2", "#3", "#4" },
}

tbl2["#buymax"] = {
	TitleText = "Buy Max",
	DescText = "Add a setting to buy max upgrades [TRUE PERMANENT]",
	PointsCost = 1e+30,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1No P$",
	Permanent = true,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1a"].purchaseCount
	end,
}

tbl2["#2a"] = {
	TitleText = "Second Auto-buyer",
	DescText = "Auto-buys #5 to #7",
	PowerCost = 10000000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 10M Power",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1a"].purchaseCount
	end,
	Auto = { "#5", "#6", "#7" },
}

tbl2["#3a"] = {
	TitleText = "Keep XP",
	DescText = "Keep XP/Levels upon Prestige",
	SteelCost = 1,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1 Steel",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2a"].purchaseCount
	end,
}

tbl2["#4a"] = {
	TitleText = "Third Auto-buyer",
	DescText = "Auto-buys #8 to #12",
	SteelCost = 10000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 10k Steel",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3a"].purchaseCount
	end,
	Auto = { "#8", "#9", "#10", "#11", "#12" },
}

tbl2["#5a"] = {
	TitleText = "First prestige keeper",
	DescText = "Keeps #1p to #4p upon refinement",
	PointsCost = 1e+69,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1DVt Points",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4a"].purchaseCount
	end,
}

tbl1 = {
	TitleText = "Almost Full Point Automation",
	DescText = "Auto-buy #13 to #19",
	PointsCost = var2.pow(10, 365),
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1e365 Points",
}

tbl1.Auto = { "#13", "#14", "#15", "#16", "#17", "#18", "#19" }
tbl1.VisibleIf = function(arg1, _)
	return 0 < arg1["#8dm"].purchaseCount
end

tbl2["#6a"] = tbl1
tbl2["#1s"] = {
	TitleText = "Steel powered currencies",
	DescText = "x100 Points, x20 XP, x10 Power, x4 PP$",
	PointsMult = 100,
	XPMult = 20,
	PowerMult = 10,
	PrestigeMult = 4,
	max = 1,
	purchaseCount = 0,
	SteelCost = 100,
	CostText = "Cost: 100 Steel",
	VisibleIf = function(arg1, arg2)
		local var3 = var2.meeq(arg2.Values.Steel.Value, 1)
		if not var3 then
			var3 = 1 <= arg1["#1s"].purchaseCount
		end

		return var3
	end,
}

tbl2["#2s"] = {
	TitleText = "Steel squared",
	DescText = "x2 Steel gain",
	SteelMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	max = 5,
	SteelCost = function(_, arg2)
		return 5 ^ arg2.purchaseCount * 50
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SteelCost(var1, var3)) .. " Steel"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#1s"].purchaseCount
	end,
}

tbl2["#3s"] = {
	TitleText = "Steel Upgrades",
	DescText = "Gives #1s's boost again, and unlock more Upgrades",
	PointsMult = 100,
	XPMult = 20,
	PowerMult = 10,
	PrestigeMult = 4,
	max = 1,
	purchaseCount = 0,
	SteelCost = 150,
	CostText = "Cost: 150 Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#1s"].purchaseCount
	end,
}

tbl2["#4s"] = {
	TitleText = "Powering Steel",
	DescText = "x200 Power",
	PowerMult = 200,
	max = 1,
	purchaseCount = 0,
	SteelCost = 1500,
	CostText = "Cost: 1.5k Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#2s"].purchaseCount
	end,
}

tbl2["#5s"] = {
	TitleText = "STEEL",
	DescText = "^1.2 Points AND Steel",
	PointsExpo = 1.2,
	SteelExpo = 1.2,
	max = 1,
	purchaseCount = 0,
	SteelCost = 250000,
	CostText = "Cost: 250k Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#2s"].purchaseCount
	end,
}

tbl2["#6s"] = {
	TitleText = "The Keyboard",
	DescText = "Unlocks The Keyboard [PERMANENT]",
	Permanent = true,
	max = 1,
	purchaseCount = 0,
	SteelCost = 1000000000,
	CostText = "Cost: 1B Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#4s"].purchaseCount
	end,
}

tbl2["#1key"] = {
	TitleText = "More keycaps",
	DescText = "+1 Keycap gain",
	KeycapBase = function(_, arg2)
		return arg2.purchaseCount
	end,
	max = 10,
	purchaseCount = 0,
	KeycapCost = function(_, arg2)
		return 2 ^ arg2.purchaseCount * 10
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#6s"].purchaseCount
	end,
}

tbl2["#2key"] = {
	TitleText = "Even more keycaps",
	DescText = "x1.5 Keycaps",
	KeycapMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	max = 20,
	purchaseCount = 0,
	KeycapCost = function(_, arg2)
		return 1.6 ^ arg2.purchaseCount * 250
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#1key"].purchaseCount
	end,
}

tbl2["#3key"] = {
	TitleText = "Keycap board",
	DescText = "Expand the keycap area! (2x2 -> 4x4)",
	KeycapBase = function(_, arg2)
		return arg2.purchaseCount
	end,
	max = 1,
	purchaseCount = 0,
	KeycapCost = function(_, _)
		return 1000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#2key"].purchaseCount
	end,
}

tbl2["#4key"] = {
	TitleText = "Golden keycaps",
	DescText = "+5% chance for a golden keycap to spawn in (x10 value)",
	max = 10,
	purchaseCount = 0,
	KeycapCost = function(_, arg2)
		return 4 ^ arg2.purchaseCount * 50000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#2key"].purchaseCount
	end,
}

tbl2["#5key"] = {
	TitleText = "Based keycaps",
	DescText = "+100 Keycap gain",
	KeycapBase = function(_, arg2)
		return arg2.purchaseCount * 100
	end,
	max = 10,
	purchaseCount = 0,
	KeycapCost = function(_, arg2)
		return 4 ^ arg2.purchaseCount * 1000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#4key"].purchaseCount
	end,
}

tbl2["#6key"] = {
	TitleText = "Keycap Milestones",
	DescText = "Unlock Keycap Milestones to aid your progression!",
	max = 1,
	purchaseCount = 0,
	KeycapCost = function(_, _)
		return 1000000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#4key"].purchaseCount
	end,
}

tbl2["#7key"] = {
	TitleText = "Finally!!!",
	DescText = "x5 Keycaps",
	KeycapMult = function(_, _)
		return 5
	end,
	max = 1,
	purchaseCount = 0,
	KeycapCost = function(_, _)
		return 1000000000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 1 <= arg1["#6key"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 1)
		end

		return bool2
	end,
}

tbl2["#8key"] = {
	TitleText = "Even more",
	DescText = "x7.5 Keycaps",
	KeycapMult = function(_, _)
		return 7.5
	end,
	max = 1,
	purchaseCount = 0,
	KeycapCost = function(_, _)
		return 250000000000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.KeycapCost(var1, var3)) .. " Keycaps"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 1 <= arg1["#7key"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 1)
		end

		return bool2
	end,
}

tbl2["#7s"] = {
	TitleText = "Lend me your Power",
	DescText = "x1k Power, the first power upgrade is automatically unlocked",
	PowerMult = 1000,
	max = 1,
	purchaseCount = 0,
	SteelCost = 1000000000,
	CostText = "Cost: 1B Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#5s"].purchaseCount
	end,
}

tbl2["#8s"] = {
	TitleText = "Some steel",
	DescText = "x10000 Steel and Power",
	SteelMult = 10000,
	PowerMult = 10000,
	max = 1,
	purchaseCount = 0,
	SteelCost = 10000000000,
	CostText = "Cost: 10B Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#7s"].purchaseCount
	end,
}

tbl2["#9s"] = {
	TitleText = "The Rocket",
	DescText = "Unlocks the rocket (Space)",
	max = 1,
	purchaseCount = 0,
	SteelCost = 1000000000000000,
	CostText = "Cost: 1Qd Steel",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#8s"].purchaseCount
	end,
}

tbl2["#10s"] = {
	TitleText = "More upgrades!",
	DescText = "Unlock more upgrades around the map",
	max = 1,
	purchaseCount = 0,
	SteelCost = 1e+20,
	CostText = "Cost: 100Qn Steel",
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 1 <= arg1["#9s"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 5)
		end

		return bool2
	end,
}

tbl2["#11s"] = {
	TitleText = "Steel SPP$",
	DescText = "x100 SPP$ and Power",
	max = 1,
	PowerMult = 100,
	SpacePrestigeMult = 100,
	purchaseCount = 0,
	SteelCost = 1e+23,
	CostText = "Cost: 100Sx Steel",
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 1 <= arg1["#10s"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 5)
		end

		return bool2
	end,
}

tbl2["#12s"] = {
	TitleText = "Insane Boosts",
	DescText = "^2 Power and x1De Prestige",
	max = 1,
	PowerExpo = 2,
	PrestigeMult = 1e+33,
	purchaseCount = 0,
	SteelCost = 4e+27,
	CostText = "Cost: 4Oc Steel",
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 1 <= arg1["#11s"].purchaseCount then
			bool1 = 0 < arg1["#8dm"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#13s"] = {
	TitleText = "Steel Prestige/Power",
	DescText = "Steel now boosts PP$ and Power at a rate of x(Steel^2) [Cap: x1.79e308]",
	max = 1,
	purchaseCount = 0,
	SteelCost = 5e+28,
	PrestigeMult = function(arg1, _)
		local num1 = 2
		local num2 = 1024
		return var2.meeq(var2.pow(arg1.Values.Steel.Value, 2), var2.pow(num1, num2)) and var2.pow(2, 1024) or var2.pow(arg1.Values.Steel.Value, 2)
	end,
	PowerMult = function(arg1, _)
		local num1 = 2
		local num2 = 1024
		return var2.meeq(var2.pow(arg1.Values.Steel.Value, 2), var2.pow(num1, num2)) and var2.pow(2, 1024) or var2.pow(arg1.Values.Steel.Value, 2)
	end,
	MaxedText = function(arg1, _)
		local num1 = 2
		local num2 = 1024
		return "Maxed! (x" .. var2.short(var2.meeq(var2.pow(arg1.Values.Steel.Value, 2), var2.pow(num1, num2)) and var2.pow(2, 1024) or var2.pow(arg1.Values.Steel.Value, 2)) .. " PP$ & Power)"
	end,
	CostText = "Cost: 50Oc Steel",
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 1 <= arg1["#11s"].purchaseCount then
			bool1 = 0 < arg1["#8dm"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#1sp"] = {
	TitleText = "Space Tree",
	DescText = "Generate 1 Space Points (SP$) per second",
	max = 1,
	purchaseCount = 0,
	CostText = "Cost: Free!",
	SpacePointsBase = 1,
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#9s"].purchaseCount
	end,
}

tbl2["#2sp"] = {
	TitleText = "Basic things",
	DescText = "2x the SP$ gain",
	max = 1,
	SpacePointsMult = 2,
	purchaseCount = 0,
	CostText = "Cost: 5 SP$",
	VisibleIf = function(arg1, _)
		return 1 <= arg1["#1sp"].purchaseCount
	end,
}

tbl2["#3sp"] = {
	TitleText = "Lots of space out here",
	DescText = "x1.5 SP$ per level",
	SpacePointsCost = function(_, arg2)
		local var1 = var2.pow(2, arg2.purchaseCount)
		local num1 = 10
		return var2.toString(var2.mul(var1, num1))
	end,
	SpacePointsMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 10,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2sp"].purchaseCount
	end,
}

tbl2["#4sp"] = {
	TitleText = "Where does this even come from?",
	DescText = "+3/s base SP$ gain",
	SpacePointsCost = function(_, _)
		return 30
	end,
	SpacePointsBase = 3,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3sp"].purchaseCount
	end,
}

tbl2["#5sp"] = {
	TitleText = "A useful boost??",
	DescText = "x1.1 SP$ per #sp upgrade",
	SpacePointsCost = function(_, _)
		return 50
	end,
	SpacePointsMult = function(arg1, _)
		local num1 = 0
		for k1, v1 in arg1.Upgrades:GetChildren() do
			if not v1.Name:match("^#%d+sp$") then
				continue
			end

			if 0 >= v1:GetAttribute("purchaseCount") then
				continue
			end

			num1 = num1 + 1
		end

		return 1.1 ^ num1
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3sp"].purchaseCount
	end,
}

tbl2["#6sp"] = {
	TitleText = "Is this just coming out of nowhere?",
	DescText = function(_, arg2)
		return "+0.5x SP$ gain (x" .. 1 + 0.5 * arg2.purchaseCount .. ")"
	end,
	SpacePointsCost = function(_, arg2)
		local var1 = var2.pow(2, arg2.purchaseCount)
		local num1 = 500
		return var2.toString(var2.mul(var1, num1))
	end,
	SpacePointsMult = function(_, arg2)
		return 1 + 0.5 * arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 8,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4sp"].purchaseCount
	end,
}

tbl2["#7sp"] = {
	TitleText = "seems useless",
	DescText = function(_, _)
		return "^1.25 SP$ gain"
	end,
	SpacePointsCost = function(_, _)
		return 10000
	end,
	SpacePointsExpo = 1.25,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#5sp"].purchaseCount
	end,
}

tbl2["#8sp"] = {
	TitleText = "boring upgrade",
	DescText = function(_, _)
		return "x2 SP$ gain (ok)"
	end,
	SpacePointsCost = function(_, _)
		return 50000
	end,
	SpacePointsMult = 2,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#7sp"].purchaseCount
	end,
}

tbl2["#9sp"] = {
	TitleText = "lets go rolling!",
	DescText = function(_, _)
		return "roll a 1 sided dice, if it lands on 1 it'll give x3 SP$ (x3 SP$ gain)"
	end,
	SpacePointsCost = function(_, _)
		return 150000
	end,
	SpacePointsMult = 3,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#8sp"].purchaseCount
	end,
}

tbl2["#10sp"] = {
	TitleText = "Starry Nights",
	DescText = function(_, _)
		return "Unlock Star Levels [PERMANENT]"
	end,
	SpacePointsCost = function(_, _)
		return 1000000
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#9sp"].purchaseCount
	end,
	Permanent = true,
}

tbl2["#11sp"] = {
	TitleText = "Space XP",
	DescText = function(_, _)
		return "x1.5 Star XP"
	end,
	SpacePointsCost = function(_, arg2)
		return 10000000000 * 2 ^ arg2.purchaseCount * (15 <= arg2.purchaseCount and 1000000000000 * 5 ^ (arg2.purchaseCount - 15) or 1)
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 30,
	StarXPMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3sl"].purchaseCount
	end,
}

tbl2["#12sp"] = {
	TitleText = "More Space Points",
	DescText = function(_, _)
		return "x10 SP$ gain"
	end,
	SpacePointsCost = function(_, _)
		return 1000000000000
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	SpacePointsMult = 10,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3sl"].purchaseCount
	end,
}

tbl2["#13sp"] = {
	TitleText = "Star Exponent",
	DescText = function(_, _)
		return "^1.125 Star XP"
	end,
	SpacePointsCost = function(_, _)
		return 5e+20
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	StarXPExpo = 1.125,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#12sp"].purchaseCount
	end,
}

tbl2["#14sp"] = {
	TitleText = "Space Inflation",
	DescText = function(_, _)
		return "x100 SP$ gain"
	end,
	SpacePointsCost = function(_, _)
		return 2.5e+26
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	SpacePointsMult = 100,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#13sp"].purchaseCount
	end,
}

tbl2["#15sp"] = {
	TitleText = "Space Deflation",
	DescText = function(_, _)
		return "x20 SP$ gain"
	end,
	SpacePointsCost = function(_, _)
		return 1e+36
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	SpacePointsMult = 20,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#14sp"].purchaseCount
	end,
}

tbl2["#16sp"] = {
	TitleText = "Space Prestige!!!",
	DescText = function(_, _)
		return "Unlock Space Prestige"
	end,
	SpacePointsCost = function(_, _)
		return 5e+42
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#15sp"].purchaseCount
	end,
}

tbl2["#17sp"] = {
	TitleText = "Maybe later..",
	DescText = function(_, _)
		return "+1 Nova"
	end,
	SpacePointsCost = function(_, arg2)
		return 1e+93 * 1e+18 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePointsCost(var1, var3)) .. " SP$"
	end,
	max = 4,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#6sp"].purchaseCount and var3(arg1, "#4nv") or var3(arg1, "#17sp")
	end,
	Permanent = true,
}

tbl2["#1sl"] = {
	TitleText = "Beginner Stars",
	DescText = function(_, _)
		return "x2 Star XP"
	end,
	StarLevelsCost = function(_, arg2)
		return ({ 1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22 })[arg2.purchaseCount + 1]
	end,
	StarXPMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 8,
	VisibleIf = function(_, _)
		return true
	end,
}

tbl2["#2sl"] = {
	TitleText = "Base Stars",
	DescText = function(_, _)
		return "+2 Star Base"
	end,
	StarLevelsCost = function(_, arg2)
		return 4 + arg2.purchaseCount
	end,
	StarXPBase = function(_, arg2)
		return 2 * arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 10,
	VisibleIf = function(_, _)
		return true
	end,
}

tbl2["#3sl"] = {
	TitleText = "SP-Star Upgrades",
	DescText = function(_, _)
		return "Unlock more #sp upgrades"
	end,
	StarLevelsCost = function(_, _)
		return 7
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 1,
	VisibleIf = function(_, _)
		return true
	end,
}

tbl2["#4sl"] = {
	TitleText = "SP Exponent",
	DescText = function(_, _)
		return "^1.2 SP$ gain"
	end,
	StarLevelsCost = function(_, _)
		return 15
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 1,
	SpacePointsExpo = 1.2,
	VisibleIf = function(_, _)
		return true
	end,
}

tbl2["#5sl"] = {
	TitleText = "Double boost",
	DescText = function(_, _)
		return "x5 Star XP and SP$"
	end,
	StarLevelsCost = function(_, arg2)
		return ({ 18, 20, 23, 26, 30, 33 })[arg2.purchaseCount + 1]
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 5,
	SpacePointsMult = function(_, arg2)
		return 5 ^ arg2.purchaseCount
	end,
	StarXPMult = function(_, arg2)
		return 5 ^ arg2.purchaseCount
	end,
	VisibleIf = function(_, _)
		return true
	end,
}

tbl2["#6sl"] = {
	TitleText = "Omega Boost",
	DescText = function(_, _)
		return "x100 Star XP and SP$"
	end,
	StarLevelsCost = function(_, arg2)
		return ({ 70, 80, 90, 100, 120, 140, 160, 180, 200, 220 })[arg2.purchaseCount + 1]
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 8,
	SpacePointsMult = function(_, arg2)
		return 100 ^ arg2.purchaseCount
	end,
	StarXPMult = function(_, arg2)
		return 100 ^ arg2.purchaseCount
	end,
	VisibleIf = function(_, arg2)
		local bool1 = false
		if 0 < arg2.Upgrades["#5nv"]:GetAttribute("purchaseCount") then
			bool1 = 0 < arg2.Upgrades["#2sl"]:GetAttribute("purchaseCount")
		end

		return bool1
	end,
}

tbl2["#7sl"] = {
	TitleText = "Omega Nova",
	DescText = function(_, _)
		return "+1 Nova"
	end,
	StarLevelsCost = function(_, arg2)
		return ({ 75, 85, 95, 105, 115, 125, 135, 145 })[arg2.purchaseCount + 1]
	end,
	purchaseCount = 0,
	Permanent = true,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 5,
	VisibleIf = function(_, arg2)
		local bool1 = false
		if 0 < arg2.Upgrades["#5nv"]:GetAttribute("purchaseCount") then
			bool1 = 0 < arg2.Upgrades["#2sl"]:GetAttribute("purchaseCount")
		end

		return bool1
	end,
}

tbl2["#8sl"] = {
	TitleText = "Omega Boosts V2",
	DescText = function(_, _)
		return "^1.15 Power, x1Qn DM$ & SPP$ (tip: #6nv) [PERMANENT]"
	end,
	StarLevelsCost = function(_, arg2)
		return ({ 125, 6767 })[arg2.purchaseCount + 1]
	end,
	purchaseCount = 0,
	Permanent = true,
	PowerExpo = 1.15,
	SpacePrestigeMult = 1e+18,
	DarkMatterMult = 1e+18,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.StarLevelsCost(var1, var3)) .. " Star Levels"
	end,
	max = 1,
	VisibleIf = function(_, arg2)
		local bool1 = false
		if 0 < arg2.Upgrades["#5nv"]:GetAttribute("purchaseCount") then
			bool1 = 0 < arg2.Upgrades["#3sl"]:GetAttribute("purchaseCount")
		end

		return bool1
	end,
}

tbl2["#1spp"] = {
	TitleText = "Space Powerful Boosts",
	DescText = "x2 SP$, x5 Star XP",
	SpacePrestigeCost = function(_, arg2)
		return ({ 1, 8, 64, 512, 4096, 32768 })[arg2.purchaseCount + 1]
	end,
	purchaseCount = 0,
	SpacePointsMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	StarXPMult = function(_, arg2)
		return 5 ^ arg2.purchaseCount
	end,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = true
		if 0 >= arg1["#16sp"].purchaseCount then
			bool2 = var2.me(arg2.Values.SpacePrestige.Value, 0)
		end

		return bool2
	end,
}

tbl2["#2spp"] = {
	TitleText = "i ran out of title ideas",
	DescText = "x5 SP$ gain",
	SpacePrestigeCost = function(_, _)
		return 10
	end,
	purchaseCount = 0,
	SpacePointsMult = 5,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1spp"].purchaseCount
	end,
}

tbl2["#3spp"] = {
	TitleText = "Star Autoclicker",
	DescText = "Auto click Star XP every 0.5 seconds",
	SpacePrestigeCost = function(_, _)
		return 35
	end,
	purchaseCount = 0,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2spp"].purchaseCount
	end,
}

tbl2["#4spp"] = {
	TitleText = "Star XP Boost",
	DescText = "x2 Star XP gain",
	StarXPMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	SpacePrestigeCost = function(_, arg2)
		return 20 * 2 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 10,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2spp"].purchaseCount
	end,
}

tbl2["#5spp"] = {
	TitleText = "SP$ Boost",
	DescText = "x2 SP$ gain",
	SpacePointsMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	SpacePrestigeCost = function(_, arg2)
		return 20 * 2 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 10,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4spp"].purchaseCount
	end,
}

tbl2["#6spp"] = {
	TitleText = "Star Autoclicker V2",
	DescText = "Auto click Star XP every 0.1 seconds",
	SpacePrestigeCost = function(_, _)
		return 80
	end,
	purchaseCount = 0,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3spp"].purchaseCount
	end,
}

tbl2["#7spp"] = {
	TitleText = "SPP$ Boost",
	DescText = "x1.5 SPP$ gain",
	SpacePrestigeMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	SpacePrestigeCost = function(_, arg2)
		return 50 * 3 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 8,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4spp"].purchaseCount
	end,
}

tbl2["#8spp"] = {
	TitleText = "Star Autoclicker V3",
	DescText = "Auto click Star XP every 0.001 seconds",
	SpacePrestigeCost = function(_, _)
		return 1500
	end,
	purchaseCount = 0,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#6spp"].purchaseCount
	end,
}

tbl2["#9spp"] = {
	TitleText = "Looping!!!",
	DescText = "Unlock Loops [PERMANENT]",
	Permanent = true,
	SpacePrestigeCost = function(_, _)
		return 1000000
	end,
	purchaseCount = 0,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#8spp"].purchaseCount then
			bool2 = var3(arg1, "#5spp")
		end

		return bool2
	end,
}

tbl2["#10spp"] = {
	TitleText = "Normal XP?",
	DescText = "x1000 XP gain",
	SpacePrestigeCost = function(_, arg2)
		return 1000000 * 2 ^ arg2.purchaseCount * (40 <= arg2.purchaseCount and 1.25 ^ (arg2.purchaseCount - 39) or 1)
	end,
	purchaseCount = 0,
	XPMult = function(_, arg2)
		return 1000 ^ arg2.purchaseCount
	end,
	max = 100,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#8spp"].purchaseCount then
			bool2 = var3(arg1, "#7spp")
		end

		return bool2
	end,
}

tbl2["#11spp"] = {
	TitleText = "Loop is soon!",
	DescText = "x100 Star XP gain",
	SpacePrestigeCost = function(_, _)
		return 10000000
	end,
	purchaseCount = 0,
	StarXPMult = function(_, _)
		return 100
	end,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#10spp"].purchaseCount
	end,
}

tbl2["#12spp"] = {
	TitleText = "Again???",
	DescText = "x1.5 SPP$ gain",
	SpacePrestigeCost = function(_, arg2)
		return 100000 * 2 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	SpacePrestigeMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	max = 115,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#10spp"].purchaseCount
	end,
}

tbl2["#13spp"] = {
	TitleText = "Multi-staged boost",
	DescText = "x8 SPP$ and XP",
	SpacePrestigeCost = function(_, arg2)
		return 1e+42 * 20 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	SpacePrestigeMult = function(_, arg2)
		return 8 ^ arg2.purchaseCount
	end,
	XPMult = function(_, arg2)
		return 8 ^ arg2.purchaseCount
	end,
	max = 40,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#12spp"].purchaseCount then
			bool1 = 0 < arg1["#8dm"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#14spp"] = {
	TitleText = "More Nova!!!",
	DescText = "+0.5 Nova",
	SpacePrestigeCost = function(_, arg2)
		return 1e+127 * 1000000000000 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		local var1
		if 0 < arg1["#8spp"].purchaseCount then
			local bool3 = true
			if 0 >= arg1["#4nv"].purchaseCount then
				bool3 = var3(arg1, "#14spp")
			end
		end

		return var1
	end,
	Permanent = true,
}

tbl2["#15spp"] = {
	TitleText = "You'll need this (v2)",
	DescText = "x1Qd P$ and PP$ [PERMANENT]",
	SpacePrestigeCost = function(_, _)
		return 1e+209
	end,
	purchaseCount = 0,
	max = 1,
	PointsMult = 1000000000000000,
	PrestigeMult = 1000000000000000,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, arg2)
		return 0 < arg1["#11spp"].purchaseCount and var2.meeq(arg2.Values.Loops.Value, 11) or var3(arg1, "#15spp")
	end,
	Permanent = true,
}

tbl2["#16spp"] = {
	TitleText = "Finally useful?",
	DescText = "x10B DM$ gain",
	SpacePrestigeCost = function(_, arg2)
		local num1 = 10
		local var1 = 209 + arg2.purchaseCount * 5
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = math.huge,
	DarkMatterMult = function(_, arg2)
		local num1 = 10000000000
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.SpacePrestigeCost(var1, var3)) .. " SPP$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#13spp"].purchaseCount then
			bool2 = var3(arg1, "#7db")
		end

		return bool2
	end,
}

tbl2["#1dm"] = {
	TitleText = "The Void",
	DescText = "Generate 1 Dark Matter (DM$) per second",
	max = 1,
	purchaseCount = 0,
	CostText = "Cost: Free!",
	DarkMatterBase = 1,
	VisibleIf = function(_, arg2)
		local var1 = arg2.Values.Loops.Value
		local num1 = 7
		return var2.meeq(var1, num1)
	end,
}

tbl2["#2dm"] = {
	TitleText = "the void consumes you",
	DescText = function(arg1, _)
		return 0 < arg1.Upgrades["#4dm"]:GetAttribute("purchaseCount") and "x" .. 1.05 + arg1.Upgrades["#2db"]:GetAttribute("purchaseCount") / 100 .. " and +1 DM$ gain" or "+1 DM$ gain"
	end,
	max = 10000,
	purchaseCount = 0,
	DarkMatterCost = function(_, arg2)
		local var3 = var2.mul(var2.pow(1.2, arg2.purchaseCount), 5)
		if 199 <= arg2.purchaseCount then
			local num2 = 1.1
			local var4 = arg2.purchaseCount - 199
			var3 = var2.mul(var3, var2.pow(num2, var4))
		end

		if 299 <= arg2.purchaseCount then
			local num4 = 1.4
			local var6 = arg2.purchaseCount - 299
			var3 = var2.mul(var3, var2.pow(num4, var6))
		end

		if 499 <= arg2.purchaseCount then
			local num6 = 1.5
			local var8 = arg2.purchaseCount - 499
			var3 = var2.mul(var3, var2.pow(num6, var8))
		end

		return var3
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	DarkMatterBase = function(_, arg2)
		return arg2.purchaseCount
	end,
	DarkMatterMult = function(arg1, arg2)
		if arg1.Upgrades["#4dm"]:GetAttribute("purchaseCount") <= 0 then
			return 1
		end

		local var1 = 1.05 + arg1.Upgrades["#2db"]:GetAttribute("purchaseCount") / 100
		local var3 = arg2.purchaseCount
		return var2.pow(var1, var3)
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1dm"].purchaseCount
	end,
}

tbl2["#3dm"] = {
	TitleText = "darkened matter",
	DescText = "x3 DM$ gain",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = 75,
	CostText = "Cost: 75 DM$",
	DarkMatterMult = 3,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2dm"].purchaseCount
	end,
}

tbl2["#4dm"] = {
	TitleText = "Lightened Matter..?",
	DescText = "#2dm now also gives x1.05 DM$ gain each level",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = 500,
	CostText = "Cost: 500 DM$",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#2dm"].purchaseCount
	end,
}

tbl2["#5dm"] = {
	TitleText = "dark exponent",
	DescText = "x2 and +^0.01 DM$ gain",
	max = 15,
	DarkMatterExpo = function(_, arg2)
		return 1 + arg2.purchaseCount * 0.01
	end,
	purchaseCount = 0,
	MaxedText = function(_, arg2)
		return "Maxed! (x" .. 2 ^ arg2.purchaseCount .. ", ^" .. 1 + arg2.purchaseCount * 0.01 .. " DM$)"
	end,
	DarkMatterCost = function(_, arg2)
		return 5 ^ arg2.purchaseCount * 1000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4dm"].purchaseCount
	end,
}

tbl2["#6dm"] = {
	TitleText = "light multiplication",
	DescText = "x100 DM$ gain",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 10000
	end,
	DarkMatterMult = 100,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3dm"].purchaseCount
	end,
}

tbl2["#7dm"] = {
	TitleText = "#2dm but better",
	DescText = "+100 DM$ gain",
	max = 10,
	DarkMatterBase = function(_, arg2)
		return arg2.purchaseCount * 100
	end,
	purchaseCount = 0,
	DarkMatterCost = function(_, arg2)
		return 2 ^ arg2.purchaseCount * 25000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4dm"].purchaseCount
	end,
}

tbl2["#8dm"] = {
	TitleText = "Dark Upgrades",
	DescText = "Unlock Dark Upgrades around the map (including space, check auto-buyer first)",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 750000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#7dm"].purchaseCount
	end,
}

tbl2["#9dm"] = {
	TitleText = "Your average boost",
	DescText = "x5 DM$ gain",
	max = 1,
	DarkMatterMult = 5,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 10000000000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 0 < arg1["#8dm"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 8)
		end

		return bool2
	end,
}

tbl2["#10dm"] = {
	TitleText = "Darkened XP",
	DescText = "DM$ boosts XP at a rate of [x(DM$/1000)^0.25]",
	max = 1,
	purchaseCount = 0,
	XPMult = function(arg1, _)
		local var1 = var2.div(arg1.Values.DarkMatter.Value, 1000)
		local num1 = 0.25
		return var2.pow(var1, num1)
	end,
	DarkMatterCost = function(_, _)
		return 200000000000000
	end,
	MaxedText = function(arg1, _)
		local var1 = var2.div(arg1.Values.DarkMatter.Value, 1000)
		local num1 = 0.25
		return "Maxed! (x" .. var2.short(var2.pow(var1, num1)) .. " XP)"
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 0 < arg1["#8dm"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 8)
		end

		return bool2
	end,
}

tbl2["#11dm"] = {
	TitleText = "Another average boost",
	DescText = "x25 DM$ gain",
	max = 1,
	DarkMatterMult = 25,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 1000000000000000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#9dm"].purchaseCount
	end,
}

tbl2["#12dm"] = {
	TitleText = "The Dark Board",
	DescText = "Unlocks the Dark Board",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 5e+16
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#10dm"].purchaseCount
	end,
}

tbl2["#13dm"] = {
	TitleText = "Powered Matter",
	DescText = "Power now also boosts DM$",
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 1e+28
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 0 < arg1["#12dm"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 9)
		end

		return bool2
	end,
}

tbl2["#14dm"] = {
	TitleText = "Dark Prestige? (not really)",
	DescText = "x1000 DM$, and DM$ now boosts PP$ and Steel at a rate of ((1+DM$)/1e50)^0.5",
	max = 1,
	purchaseCount = 0,
	DarkMatterMult = 1000,
	DarkMatterCost = function(_, _)
		return 1e+51
	end,
	PrestigeMult = function(arg1, _)
		local var1 = var2.div(var2.add(1, arg1.Values.DarkMatter.Value), 1e+50)
		local num1 = 0.5
		return var2.pow(var1, num1)
	end,
	SteelMult = function(arg1, _)
		local var1 = var2.div(var2.add(1, arg1.Values.DarkMatter.Value), 1e+50)
		local num1 = 0.5
		return var2.pow(var1, num1)
	end,
	MaxedText = function(arg1, _)
		local var1 = var2.div(var2.add(1, arg1.Values.DarkMatter.Value), 1e+50)
		local num1 = 0.5
		return "Maxed! (x" .. var2.short(var2.pow(var1, num1)) .. " PP$ & Steel)"
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, arg2)
		local bool2 = false
		if 0 < arg1["#13dm"].purchaseCount then
			bool2 = var2.meeq(arg2.Values.Loops.Value, 9)
		end

		return bool2
	end,
}

tbl2["#15dm"] = {
	TitleText = "Seems like a lot of Nova",
	DescText = function(_, _)
		return "+2 Nova"
	end,
	DarkMatterCost = function(_, arg2)
		return 1e+100 * 1e+30 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " SP$"
	end,
	max = 4,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#14dm"].purchaseCount and var3(arg1, "#4nv") or var3(arg1, "#15dm")
	end,
	Permanent = true,
}

tbl2["#1db"] = {
	TitleText = "Dark Multiplication",
	DescText = "x2 DM$ gain",
	max = 100,
	purchaseCount = 0,
	DarkMatterMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	DarkMatterCost = function(_, arg2)
		return 5 ^ arg2.purchaseCount * 5e+16 * (24 <= arg2.purchaseCount and 10 ^ (arg2.purchaseCount - 24) or 1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#12dm"].purchaseCount
	end,
}

tbl2["#2db"] = {
	TitleText = "Upgrade boosting",
	DescText = "x2 DM$ and +0.01 #2dm's multiplication boost",
	max = 10,
	purchaseCount = 0,
	DarkMatterMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	DarkMatterCost = function(_, arg2)
		return 100000 ^ arg2.purchaseCount * 5e+17 * (4 <= arg2.purchaseCount and 100000 ^ (arg2.purchaseCount - 4) or 1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#12dm"].purchaseCount
	end,
}

tbl2["#3db"] = {
	TitleText = "XP Multiplication",
	DescText = "x5 XP gain",
	max = 100,
	purchaseCount = 0,
	XPMult = function(_, arg2)
		return 5 ^ arg2.purchaseCount
	end,
	DarkMatterCost = function(_, arg2)
		return 10 ^ arg2.purchaseCount * 1e+21 * (9 <= arg2.purchaseCount and 10 ^ (arg2.purchaseCount - 9) or 1) * (19 <= arg2.purchaseCount and 10 ^ (arg2.purchaseCount - 19) or 1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#12dm"].purchaseCount
	end,
}

tbl2["#4db"] = {
	TitleText = "Space Prestige Multiplication",
	DescText = "x100 SPP$ gain",
	max = 50,
	purchaseCount = 0,
	SpacePrestigeMult = function(_, arg2)
		return 100 ^ arg2.purchaseCount
	end,
	DarkMatterCost = function(_, arg2)
		local var1 = 9 <= arg2.purchaseCount and var2.pow("10", arg2.purchaseCount - 9) or "1"
		local var3 = 10 <= arg2.purchaseCount and var2.pow("10", arg2.purchaseCount - 19) or "1"
		local var6 = var2.mul(var2.mul(var2.pow("20", arg2.purchaseCount), "1e22"), var2.mul(var1, var3))
		if 20 <= arg2.purchaseCount then
			var3 = 10
			local var7 = 170 + (arg2.purchaseCount - 20) * 3
			var6 = var2.mul(var6, var2.pow(var3, var7))
		end

		return var6
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#12dm"].purchaseCount
	end,
}

tbl2["#5db"] = {
	TitleText = "exponents : part 2",
	DescText = "+^0.02 DM$ gain (protip: Power)",
	max = 25,
	DarkMatterExpo = function(_, arg2)
		return arg2.purchaseCount * 0.02 + 1
	end,
	purchaseCount = 0,
	DarkMatterCost = function(_, arg2)
		local num1 = 10
		local var1 = 172 + arg2.purchaseCount * 18
		return var2.pow(num1, var1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#12dm"].purchaseCount then
			bool2 = var3(arg1, "#9nv")
		end

		return bool2
	end,
}

tbl2["#6db"] = {
	TitleText = "thats a lot of boosts",
	DescText = function(_, arg2)
		return "x1.5 all currencies before Supernova (Current: x" .. var2.short(1.5 ^ arg2.purchaseCount) .. ")"
	end,
	max = 25,
	PointsMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	XPMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	PrestigeMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	PowerMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	SteelMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	KeycapMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	SpacePointsMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	StarXPMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	SpacePrestigeMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	DarkMatterMult = function(_, arg2)
		return 1.5 ^ arg2.purchaseCount
	end,
	purchaseCount = 0,
	DarkMatterCost = function(_, arg2)
		local num1 = 10
		local var1 = 172 + arg2.purchaseCount * 18
		return var2.pow(num1, var1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#12dm"].purchaseCount then
			bool2 = var3(arg1, "#9nv")
		end

		return bool2
	end,
}

tbl2["#7db"] = {
	TitleText = "space prestige becomes useful",
	DescText = function(_, _)
		return "Unlock a new space prestige upgrade"
	end,
	max = 1,
	purchaseCount = 0,
	DarkMatterCost = function(_, _)
		return 1e+197
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#12dm"].purchaseCount then
			bool2 = var3(arg1, "#9nv")
		end

		return bool2
	end,
}

tbl2["#8db"] = {
	TitleText = "Supernova Basing",
	DescText = "+1 base Supernova Tier gain",
	max = 25,
	purchaseCount = 0,
	SupernovaTierBase = function(_, arg2)
		return arg2.purchaseCount
	end,
	DarkMatterCost = function(_, arg2)
		local num1 = 10
		local var1 = 303 + arg2.purchaseCount * 100
		return var2.pow(num1, var1)
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DarkMatterCost(var1, var3)) .. " DM$"
	end,
	VisibleIf = function(arg1, _)
		local bool2 = false
		if 0 < arg1["#12dm"].purchaseCount then
			bool2 = var3(arg1, "#9nv")
		end

		return bool2
	end,
}

tbl2["#1nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "x5 all currencies before Supernova (except Loops)"
	end,
	PointsMult = 5,
	XPMult = 5,
	PrestigeMult = 5,
	PowerMult = 5,
	SteelMult = 5,
	KeycapMult = 5,
	SpacePointsMult = 5,
	StarXPMult = 5,
	SpacePrestigeMult = 5,
	DarkMatterMult = 5,
	purchaseCount = 0,
	NovaSubtraction = 1,
	CostText = function(_, arg2)
		return "Buy! (" .. var2.short(arg2.NovaSubtraction) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(_, arg2)
		local var1 = arg2.Values.SupernovaTier.Value
		local num1 = 0
		return var2.me(var1, num1)
	end,
}

tbl2["#2nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, arg2)
		return "Gain +0.01% of PP$, Steel & SPP$ gained each reset; per second (x2 each level) [Current: +" .. (0 < arg2.purchaseCount and 0.01 * 2 ^ (arg2.purchaseCount - 1) or 0) .. "%/s]"
	end,
	purchaseCount = 0,
	NovaSubtraction = function(_, _)
		return 1
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 5,
	VisibleIf = function(_, arg2)
		return 0 < arg2.Upgrades["#1nv"]:GetAttribute("purchaseCount")
	end,
}

tbl2["#3nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "Unlocks Bulk Looping (you can skip loops, for example: you're on loop 1 and have 300 levels when looping, you will skip to loop 3)"
	end,
	purchaseCount = 0,
	NovaSubtraction = function(_, _)
		return 1
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(_, arg2)
		return 0 < arg2.Upgrades["#1nv"]:GetAttribute("purchaseCount")
	end,
}

tbl2["#4nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "x1000 XP, x5 Steel & SPP$ & PP$, and Loop 10 now unlocks some permanent supernova upgrades that gives Nova upon purchase!"
	end,
	purchaseCount = 0,
	XPMult = 1000,
	SteelMult = 5,
	PrestigeMult = 5,
	SpacePrestigeMult = 5,
	NovaSubtraction = function(_, _)
		return 1
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#2nv"].purchaseCount then
			bool1 = 0 < arg1["#3nv"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#5nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "Unlocks new Star Level upgrades alongside with x1T P$, SP$, and DM$ (tip: you can buy #nv upgrades whenever in your supernova run)"
	end,
	purchaseCount = 0,
	PointsMult = 1000000000000,
	SpacePointsMult = 1000000000000,
	DarkMatterMult = 1000000000000,
	NovaSubtraction = function(_, _)
		return 2
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 0 < arg1["#2nv"].purchaseCount then
			bool1 = 0 < arg1["#3nv"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#6nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "x100 Star XP (maybe you need this for something.. btw drag up)"
	end,
	purchaseCount = 0,
	StarXPMult = function(_, arg2)
		return 100 ^ arg2.purchaseCount
	end,
	NovaSubtraction = function(_, _)
		return 1
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 10,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#5nv"].purchaseCount
	end,
}

tbl2["#7nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "Unlock Supernova Challenges and x1M Star XP"
	end,
	purchaseCount = 0,
	StarXPMult = function(_, _)
		return 1000000
	end,
	NovaSubtraction = function(_, _)
		return 14
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#4nv"].purchaseCount
	end,
}

tbl2["#8nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "Keep #8spp (tier 3 autoclicker) always bought, x1T SPP$, Star XP, and SP$"
	end,
	purchaseCount = 0,
	StarXPMult = function(_, _)
		return 1000000000000
	end,
	SpacePointsMult = function(_, _)
		return 1000000000000
	end,
	SpacePrestigeMult = function(_, _)
		return 1000000000000
	end,
	NovaSubtraction = function(_, _)
		return 100
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#7nv"].purchaseCount
	end,
}

tbl2["#9nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "x1T DM$, and finally unlocks the last 4 dark board upgrades!"
	end,
	purchaseCount = 0,
	DarkMatterMult = 1000000000000,
	NovaSubtraction = function(_, _)
		return 2000
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 1,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#3nv"].purchaseCount
	end,
}

tbl2["#10nv"] = {
	TitleText = "there is no title text",
	DescText = function(_, _)
		return "x2000 XP gain, is this required for something? (challenges)"
	end,
	purchaseCount = 0,
	XPMult = function(_, arg2)
		local num1 = 2000
		local var1 = arg2.purchaseCount
		return var2.pow(num1, var1)
	end,
	NovaSubtraction = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Buy! (" .. var2.short(arg2.NovaSubtraction(var1, var3)) .. " NV$)"
	end,
	max = 100,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#9nv"].purchaseCount
	end,
}

tbl2["#1gift"] = {
	purchaseCount = 0,
	TitleText = "A special gift...",
	DescText = "Automate #1 to #12, #1sp to #16sp, #1g to #11g, and star level upgrades (#1sl to #5sl)",
	SupernovaTierReq = 1,
	Auto = {
		"#1",
		"#2",
		"#3",
		"#4",
		"#5",
		"#6",
		"#7",
		"#8",
		"#9",
		"#10",
		"#11",
		"#12",
		"#1sp",
		"#2sp",
		"#3sp",
		"#4sp",
		"#5sp",
		"#6sp",
		"#7sp",
		"#8sp",
		"#9sp",
		"#10sp",
		"#11sp",
		"#12sp",
		"#13sp",
		"#14sp",
		"#15sp",
		"#16sp",
		"#1sl",
		"#2sl",
		"#3sl",
		"#4sl",
		"#5sl",
		"#1g",
		"#2g",
		"#3g",
		"#4g",
		"#5g",
		"#6g",
		"#7g",
		"#8g",
		"#9g",
		"#10g",
		"#11g",
	},
	max = 1,
	CostText = "Requirement: SN Tier 1",
	VisibleIf = function(_, arg2)
		local var1 = arg2.Values.SupernovaTier.Value
		local num1 = 1
		return var2.meeq(var1, num1)
	end,
}

tbl2["#2gift"] = {
	purchaseCount = 0,
	TitleText = "Another special gift...",
	DescText = "Automate #1p to #14p and #1s to #13s",
	LoopsReq = 10.99,
	Auto = {
		"#1p",
		"#2p",
		"#3p",
		"#4p",
		"#5p",
		"#6p",
		"#7p",
		"#8p",
		"#9p",
		"#10p",
		"#11p",
		"#12p",
		"#13p",
		"#14p",
		"#1s",
		"#2s",
		"#3s",
		"#4s",
		"#5s",
		"#6s",
		"#7s",
		"#8s",
		"#9s",
		"#10s",
		"#11s",
		"#12s",
		"13s",
	},
	max = 1,
	CostText = "Requirement: Loop 11",
	VisibleIf = function(_, arg2)
		local var1 = arg2.Values.Loops.Value
		local num1 = 11
		return var2.meeq(var1, num1)
	end,
}

tbl2["#B0"] = {
	TitleText = "Green",
	DescText = "Unlock The Bonus Baseplate.",
	PointsCost = 1000,
	purchaseCount = 0,
	max = 1,
	CostText = "Cost: 1000 P$",
	Permanent = true,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#1"].purchaseCount
	end,
}

tbl2["#B1"] = {
	TitleText = "Gamma!",
	DescText = "Start Generating \206\179 every second",
	PointsCost = 0,
	purchaseCount = 0,
	max = 1,
	GammaBase = 1,
	CostText = "Free",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B0"].purchaseCount
	end,
}

tbl2["#B2"] = {
	TitleText = "Gamma Base",
	DescText = "+1 \206\179 Gain",
	GammaCost = function(_, arg2)
		local var1 = var2.pow(2, arg2.purchaseCount)
		local num1 = 5
		return var2.toString(var2.mul(var1, num1))
	end,
	purchaseCount = 0,
	max = 5,
	GammaBase = function(_, arg2)
		return arg2.purchaseCount
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.GammaCost(var1, var3)) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B1"].purchaseCount
	end,
}

tbl2["#B3"] = {
	TitleText = "Gamma Multiplication",
	DescText = "2x \206\179 gain",
	GammaCost = function(_, arg2)
		local var1 = var2.pow(2.5, arg2.purchaseCount)
		local num1 = 25
		return var2.toString(var2.mul(var1, num1))
	end,
	purchaseCount = 0,
	max = 10,
	GammaMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.GammaCost(var1, var3)) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B1"].purchaseCount
	end,
}

tbl2["#B4"] = {
	TitleText = "Advanced Gamma Base",
	DescText = "+5 \206\179 Gain",
	GammaCost = 85,
	purchaseCount = 0,
	max = 1,
	GammaBase = 5,
	CostText = "Cost: 85 \206\179",
	VisibleIf = function(arg1, _)
		return 2 < arg1["#B2"].purchaseCount
	end,
}

tbl2["#B5"] = {
	TitleText = "Advanced Gamma Mult",
	DescText = "5x \206\179 gain",
	GammaCost = 296,
	purchaseCount = 0,
	max = 1,
	GammaMult = 5,
	CostText = "Cost: 296 \206\179",
	VisibleIf = function(arg1, _)
		return 1 < arg1["#B3"].purchaseCount
	end,
}

tbl2["#B6"] = {
	TitleText = "Advanced Gamma Mult",
	DescText = "x1.75 \206\179 gain for every bonus (#B) upgrade",
	GammaCost = 300000,
	purchaseCount = 0,
	max = 1,
	GammaMult = function(arg1, _)
		local num1 = 0
		for k1, v1 in arg1.Upgrades:GetChildren() do
			if not v1.Name:match("^#B%d+$") then
				continue
			end

			if 0 >= v1:GetAttribute("purchaseCount") then
				continue
			end

			num1 = num1 + 1
		end

		return 1.75 ^ num1
	end,
	CostText = "Cost: 300k \206\179",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B5"].purchaseCount
	end,
}

tbl2["#B7"] = {
	TitleText = "Really advanced Gamma Mult",
	DescText = "10x \206\179 gain",
	GammaCost = function(_, arg2)
		local var1 = var2.pow(1000, arg2.purchaseCount)
		local num1 = 300
		return var2.toString(var2.mul(var1, num1))
	end,
	purchaseCount = 0,
	max = math.huge,
	GammaMult = function(_, arg2)
		return 10 ^ arg2.purchaseCount
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.GammaCost(var1, var3)) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B6"].purchaseCount
	end,
}

tbl2["#B8"] = {
	TitleText = "Delta gamer",
	DescText = "Unlocks the Delta sub-baseplate",
	GammaCost = 50000000000,
	purchaseCount = 0,
	DeltaBase = 1,
	max = 1,
	CostText = "Cost: 50B \206\179",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B6"].purchaseCount
	end,
}

tbl2["#B9"] = {
	TitleText = "Exponented Gamma",
	DescText = "^1.15 \206\179 gain",
	GammaCost = 1000000000000,
	purchaseCount = 0,
	max = 1,
	GammaExpo = 1.15,
	CostText = "Cost: 1T \206\179",
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B7"].purchaseCount
	end,
}

tbl2["#B10"] = {
	TitleText = "Delta boosting",
	DescText = "\206\148 boosts \206\179 gain (1 \206\148 = +1 \206\179 multiplier)",
	GammaCost = 1e+16,
	purchaseCount = 0,
	max = 1,
	GammaMult = function(arg1, _)
		local num1 = 1
		local var1 = arg1.Values.Delta.Value
		return var2.add(num1, var1)
	end,
	CostText = function(_, _)
		return "Cost: " .. var2.short(1e+16) .. " \206\179"
	end,
	MaxedText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Maxed! (x" .. var2.short(arg2.GammaMult(var1, var3)) .. " \206\179)"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B9"].purchaseCount
	end,
}

tbl2["#B11"] = {
	TitleText = "okay",
	DescText = "^1.1 \206\148 and \206\179",
	GammaCost = 1e+25,
	purchaseCount = 0,
	max = 1,
	GammaExpo = 1.1,
	DeltaExpo = 1.1,
	CostText = function(_, _)
		return "Cost: " .. var2.short(1e+25) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B10"].purchaseCount
	end,
}

tbl2["#B12"] = {
	TitleText = "inflation simulator",
	DescText = "x5B \206\148 gain",
	GammaCost = 1e+95,
	purchaseCount = 0,
	max = 1,
	DeltaMult = 50000000000,
	CostText = function(_, _)
		return "Cost: " .. var2.short(1e+95) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B11"].purchaseCount
	end,
}

tbl2["#B13"] = {
	TitleText = "inflation simulator 0.5",
	DescText = "x5T y gain",
	GammaCost = 1e+36,
	purchaseCount = 0,
	max = 1,
	GammaMult = 5000000000000,
	CostText = function(_, _)
		return "Cost: " .. var2.short(1e+36) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B11"].purchaseCount
	end,
}

tbl2["#B14"] = {
	TitleText = "inflation simulator 2",
	DescText = "x10000 \206\148 and \206\179 gain",
	GammaCost = function(_, arg2)
		local num1 = 10
		local var1 = ({ 373, 394, 460, 506, 550, 999, 999 })[arg2.purchaseCount + 1]
		return var2.pow(num1, var1)
	end,
	purchaseCount = 0,
	max = 5,
	GammaMult = function(_, arg2)
		return 10000 ^ arg2.purchaseCount
	end,
	DeltaMult = function(_, arg2)
		return 10000 ^ arg2.purchaseCount
	end,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.GammaCost(var1, var3)) .. " \206\179"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B12"].purchaseCount
	end,
}

tbl1 = {
	TitleText = " ",
	DescText = "Unlock ??? [WIP]",
	GammaCost = var2.pow(10, 600),
	OmegaBase = 1,
	purchaseCount = 0,
	max = 1,
	Permanent = true,
}

tbl1.DeltaCost = var2.mul(var2.pow(10, 234), 20)
tbl1.CostText = function(_, arg2)
	return "Cost: " .. var2.short(arg2.GammaCost) .. " \206\179" .. " and " .. var2.short(arg2.DeltaCost) .. " \206\148"
end

tbl1.VisibleIf = function(arg1, _)
	return 0 < arg1["#B14"].purchaseCount
end

tbl2["#B15"] = tbl1
tbl2["#B1\206\148"] = {
	TitleText = "Clicking Simulator",
	DescText = "+1 Delta (\206\148) for each purchase",
	purchaseCount = 0,
	max = math.huge,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B8"].purchaseCount
	end,
}

tbl2["#B2\206\148"] = {
	TitleText = "2^purchaseCount",
	DescText = "x2 \206\148 gain",
	purchaseCount = 0,
	DeltaMult = function(_, arg2)
		return 2 ^ arg2.purchaseCount
	end,
	DeltaCost = function(_, arg2)
		return 3 ^ arg2.purchaseCount
	end,
	max = 5,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B1\206\148"].purchaseCount
	end,
}

tbl2["#B3\206\148"] = {
	TitleText = "Cooldown reducing",
	DescText = "Reduce #B1\206\148's cooldown by 2 seconds",
	purchaseCount = 0,
	DeltaCost = function(_, _)
		return 15
	end,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B2\206\148"].purchaseCount
	end,
}

tbl2["#B4\206\148"] = {
	TitleText = "normal boosts idk",
	DescText = "x4 \206\148 and \206\179",
	purchaseCount = 0,
	DeltaCost = function(_, _)
		return 50
	end,
	max = 1,
	DeltaMult = 4,
	GammaMult = 4,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B2\206\148"].purchaseCount
	end,
}

tbl2["#B5\206\148"] = {
	TitleText = "Delta maxing",
	DescText = "x10 \206\148 gain",
	purchaseCount = 0,
	DeltaMult = function(_, arg2)
		return 10 ^ arg2.purchaseCount
	end,
	DeltaCost = function(_, arg2)
		local var1 = var2.mul(var2.pow(15, arg2.purchaseCount), 500)
		local var3 = 100 <= arg2.purchaseCount and var2.pow(2, arg2.purchaseCount - 99) or 1
		return var2.mul(var1, var3)
	end,
	max = math.huge,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B4\206\148"].purchaseCount
	end,
}

tbl2["#B6\206\148"] = {
	TitleText = "Oh, that's nice",
	DescText = "\206\179 slowly boosts \206\148 gain (1+log10(\206\179+10))",
	purchaseCount = 0,
	DeltaCost = function(_, _)
		return 1000000000
	end,
	max = 1,
	DeltaMult = function(arg1, _)
		local var1 = arg1.Values.Gamma.Value
		local num1 = 10
		local num2 = 1
		return var2.add(num2, var2.log10(var2.add(var1, num1)))
	end,
	CostText = function(_, _)
		return "Cost: " .. var2.short(1000000000) .. " \206\148"
	end,
	MaxedText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Maxed! (x" .. var2.short(arg2.DeltaMult(var1, var3)) .. " \206\148)"
	end,
	VisibleIf = function(arg1, _)
		local bool1 = false
		if 4 <= arg1["#B2\206\148"].purchaseCount then
			bool1 = 1 <= arg1["#B5\206\148"].purchaseCount
		end

		return bool1
	end,
}

tbl2["#B7\206\148"] = {
	TitleText = "Even more cooldown reducing",
	DescText = "Reduce #B1\206\148's cooldown by 1.5 seconds",
	purchaseCount = 0,
	DeltaCost = function(_, _)
		return 1e+21
	end,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B6\206\148"].purchaseCount
	end,
}

tbl2["#B8\206\148"] = {
	TitleText = "and more.. cooldown reducing",
	DescText = "Reduce #B1\206\148's cooldown by another 1 second",
	purchaseCount = 0,
	DeltaCost = function(_, _)
		return 1e+147
	end,
	max = 1,
	CostText = function(arg1, arg2)
		local var1 = arg1
		local var3 = arg2
		return "Cost: " .. var2.short(arg2.DeltaCost(var1, var3)) .. " \206\148"
	end,
	VisibleIf = function(arg1, _)
		return 0 < arg1["#B7\206\148"].purchaseCount
	end,
}

local tbl3 = {}
return {
	GetPlayerTable = function(arg1)
		if not tbl3[arg1] then
			tbl3[arg1] = var1.deepCopy(tbl2)
		end

		return tbl3[arg1]
	end,
	ReleasePlayer = function(arg1)
		tbl3[arg1] = nil
	end,
}

--- ReplicatedStorage.Shared.Config.Achievements [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.Libs.EternityNum)
return {
	JoinedGame = {
		Name = "Welcome!",
		Description = "Joined the game for the first time.",
		Obtainment = "Join the game.",
		Icon = "rbxassetid://93139230442240",
		Category = "Main",
		AchievementRequirement = function(_, _)
			return true
		end,
	},
	Prestige = {
		Name = "Prestige",
		Description = "Prestiging beyond the Points",
		Obtainment = "Prestige once",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Prestige.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://86566703410556",
	},
	Steel = {
		Name = "Steel",
		Description = "You've reached the steel reset",
		Obtainment = "Perform the stud steel once",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Steel.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://116471337126282",
	},
	SpacePrestige = {
		Name = "Space Prestige",
		Description = "Reached beyond the stars.",
		Obtainment = "Space Prestige once",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.SpacePrestige.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://0",
	},
	Alpha = {
		Name = "Gamma",
		Description = "When life gives you gamma, use it",
		Obtainment = "Buy upgrade #B1",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Gamma.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Side",
		Icon = "rbxassetid://103775417948791",
	},
	Delta = {
		Name = "Delta",
		Description = "Clicker Simulator 2.0",
		Obtainment = "Get atleast 1 delta",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Delta.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Side",
		Icon = "rbxassetid://0",
	},
	Omega = {
		Name = "Omega",
		Description = "Resetting the bonuses",
		Obtainment = "Perform an Omega reset",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Omega.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Side",
		Icon = "rbxassetid://0",
	},
	Space = {
		Name = "Space",
		Description = "Venturing beyond the atmosphere.",
		Obtainment = "Get at least 1 Space Point",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.SpacePoints.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://0",
	},
	Loop = {
		Name = "Loop",
		Description = "Come full circle.",
		Obtainment = "Complete a loop reset",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.Loops.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://0",
	},
	DarkMatter = {
		Name = "Dark Matter",
		Description = "You looped to far and reached dark matter",
		Obtainment = "Get atleast 1 Dark Matter",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.DarkMatter.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://0",
	},
	Supernova = {
		Name = "Supernova",
		Description = "The star",
		Obtainment = "Complete a Supernova tier reset",
		AchievementRequirement = function(arg1, _)
			local var2 = arg1.Values.SupernovaTier.Value
			local num1 = 1
			return var1.meeq(var2, num1)
		end,
		Category = "Main",
		Icon = "rbxassetid://0",
	},
}

--- ReplicatedStorage.Shared.Config.Resets [ModuleScript]
-- y u r i

local var1 = require(script.Parent.GameConfig)
local tbl1 = {
	Plain = "^#%d+$",
	Prestige = "^#%d+p$",
	Power = "^#%d+g$",
	Steel = "^#%d+s$",
	Space = "^#%d+sp$",
	StarLevel = "^#%d+sl$",
	SpacePrest = "^#%d+spp$",
	Automation = "^#%d+a$",
	DarkMatter = "^#%d+dm$",
	DarkBoard = "^#%d+db$",
	Keycap = "^#%d+key$",
	Nova = "^#%d+nv$",
}

local tbl2 = {
	"Points",
	"XP",
	"Level",
	"Prestige",
	"Power",
	"Steel",
	"Keycap",
	"SpacePoints",
	"StarLevels",
	"StarXP",
	"SpacePrestige",
	"Loops",
	"DarkMatter",
}

local tbl3 = {
	tbl1.Plain,
	tbl1.Prestige,
	tbl1.Power,
	tbl1.Steel,
	tbl1.Space,
	tbl1.StarLevel,
	tbl1.SpacePrest,
	tbl1.Automation,
	tbl1.DarkMatter,
	tbl1.DarkBoard,
	tbl1.Keycap,
}

local tbl4 = { "#15", "#6s", "#10sp", "#9spp" }
return {
	Patterns = tbl1,
	Prestige = {
		Id = "Prestige",
		TriggerPart = "PrestigeButton",
		Require = { Stat = "Points", Min = var1.Thresholds.PrestigePoints },
		PauseAutomation = true,
		BorderFlashBefore = true,
		Award = {
			Stat = "Prestige",
			Formula = "PrestigeGain",
			From = "Points",
			BoostSource = "GetBoosts",
		},
		WipeStats = { "Points" },
		ConditionalWipe = { { Stats = { "XP", "Level" }, SkipIfOwned = "#3a" } },
		UpgradePatterns = { tbl1.Plain },
		UpdateUpgradeArg = "",
	},
	Steel = {
		Id = "Steel",
		TriggerPart = "SteelButton",
		Require = { Stat = "Power", Min = var1.Thresholds.SteelPower },
		PauseAutomation = true,
		BorderFlashBefore = false,
		Award = { Stat = "Steel", Formula = "SteelGain", From = "Power", BoostSource = "TotalBoost" },
		WipeStats = { "Points", "Level", "XP", "Prestige", "Power" },
		UpgradePatterns = { tbl1.Plain, tbl1.Prestige, tbl1.Power },
		UpgradeExceptions = { { Keys = { "#1p", "#2p", "#3p", "#4p" }, SkipIfOwned = "#5a" } },
	},
	SpacePrestige = {
		Id = "SpacePrestige",
		TriggerPart = "SpacePrestigeButton",
		Require = { Stat = "StarLevels", Min = var1.Thresholds.SpacePrestigeStars },
		PauseAutomation = true,
		BorderFlashBefore = false,
		Award = {
			Stat = "SpacePrestige",
			Formula = "SpacePrestigeGain",
			From = "StarLevels",
			BoostSource = "GetBoosts",
		},
		WipeStats = { "SpacePoints", "StarXP", "StarLevels" },
		UpgradePatterns = { tbl1.Space, tbl1.StarLevel },
	},
	Loop = {
		Id = "Loop",
		TriggerRemote = "LoopEvent",
		PauseAutomation = false,
		BorderFlashBefore = false,
		Award = { Stat = "Loops", Formula = "LoopsGained" },
		SkipWipeWhen = { Stat = "Loops", AtLeast = 5 },
		WipeStats = {
			"Points",
			"XP",
			"Level",
			"Prestige",
			"Power",
			"Steel",
			"Keycap",
			"SpacePoints",
			"StarLevels",
			"StarXP",
			"SpacePrestige",
		},
		UpgradePatterns = {
			tbl1.Plain,
			tbl1.Prestige,
			tbl1.Power,
			tbl1.Steel,
			tbl1.Space,
			tbl1.StarLevel,
			tbl1.SpacePrest,
			tbl1.Automation,
		},
	},
	Supernova = {
		Id = "Supernova",
		TriggerRemote = "SupernovaEvent",
		Require = { Stat = "Loops", Min = var1.Thresholds.SupernovaLoops },
		PauseAutomation = true,
		BorderFlashBefore = false,
		Award = { Stat = "SupernovaTier", Formula = "TotalBoost", BoostSource = "TotalBoost" },
		WipeStats = tbl2,
		UpgradePatterns = tbl3,
		ForceResetKeys = tbl4,
	},
	Respec = {
		Id = "Respec",
		TriggerCondition = "MaxNovaBelowSpent",
		PauseAutomation = true,
		BorderFlashBefore = false,
		Award = nil,
		PreWipeStats = { "Nova", "NovaSpent" },
		PreWipeUpgradePatterns = { tbl1.Nova },
		WipeStats = tbl2,
		UpgradePatterns = tbl3,
		ForceResetKeys = tbl4,
	},
	RespecSentinelExponent = 300,
	Order = { "Prestige", "Steel", "SpacePrestige", "Loop", "Supernova", "Respec" },
}

--- ReplicatedStorage.Shared.Config.Portals [ModuleScript]
-- y u r i

return {
	CoverDuration = 0.7,
	DebounceRelease = 1,
	ArrivalOffset = Vector3.new(0, 5, 0),
	List = {
		{
			Model = "MysteriousPortal",
			Part = "Spawn",
			Destination = "DarkMatterSpawn",
			Gate = { Stat = "Loops", AtLeast = 7 },
		},
		{ Model = "Space Ship", Part = "Space", Destination = "spacetppart", Gate = nil },
		{ Model = "Spawn Ship", Part = "Spawn", Destination = "SpawnLocation", Gate = nil },
		{
			Model = "SupernovaPortal",
			Part = "Spawn",
			Destination = "supernovatppart",
			Gate = { AnyOf = { { Stat = "Loops", AtLeast = 10 }, { Stat = "SupernovaTier", AtLeast = 1 } } },
		},
		{
			Model = "SupernovaPortal+1",
			Part = "Spawn",
			Destination = "supernovatppart",
			Gate = { Stat = "SupernovaTier", AtLeast = 1 },
		},
		{
			Model = "SupernovaSpawnPortal",
			Part = "Spawn",
			Destination = "SpawnLocation",
			Gate = { AnyOf = { { Stat = "Loops", AtLeast = 10 }, { Stat = "SupernovaTier", AtLeast = 1 } } },
		},
		{ Model = "portalbacktospace", Part = "Spawn", Destination = "looptppart", Gate = nil },
	},
	TouchReturns = { {
		Model = "ForestWater",
		Part = nil,
		Destination = "SpawnLocation",
		Offset = Vector3.new(0, 3, 0),
		DebounceRelease = 1,
	} },
	TeleportMenuDestinations = { "spacetppart", "supernovatppart", "SpawnLocation", "DarkMatterSpawn", "looptppart" },
	MenuRows = {
		{ Frame = "Spawn", Destination = "SpawnLocation", Gate = nil },
		{ Frame = "Space", Destination = "spacetppart", Gate = { Upgrade = "#9s" } },
		{ Frame = "DarkMatter", Destination = "DarkMatterSpawn", Gate = { Upgrade = "#1dm" } },
		{
			Frame = "SuperNova",
			Destination = "supernovatppart",
			Gate = { AnyOf = { { Stat = "Loops", AtLeast = 10 }, { Stat = "SupernovaTier", AtLeast = 1 } } },
		},
	},
	MenuRowButton = "TextButton",
	MenuFramePath = { "TeleportGUI", "TeleportFrame", "ScrollingFrame" },
	MenuGateFailsafeInterval = 1,
}

--- ReplicatedStorage.Shared.Config.Reveals [ModuleScript]
-- y u r i

return {
	Style = { Board = "Board", Portal = "Portal", Inverted = "Inverted" },
	Boards = {
		{ Model = "darkboard", Style = "Board", Gate = { Upgrade = "#12dm" } },
		{ Model = "starlevel", Style = "Board", Gate = { Upgrade = "#10sp" } },
		{ Model = "tierThing", Style = "Board", Gate = { Upgrade = "#5" } },
		{ Model = "milestonething", Style = "Board", Gate = { Upgrade = "#6key" } },
		{ Model = "loopmilestones", Style = "Board", Gate = { Upgrade = "#9spp" } },
		{ Model = "loopbuttonguiwow", Style = "Board", Gate = { Upgrade = "#9spp" } },
		{
			Model = "supernovaboard",
			Style = "Board",
			Gate = { AnyOf = { { Stat = "Loops", AtLeast = 10 }, { Stat = "SupernovaTier", AtLeast = 1 } } },
		},
		{
			Model = "supernovaskilltree",
			Style = "Board",
			Gate = { Stat = "SupernovaTier", GreaterThan = 0 },
		},
		{ Model = "supernovachallenges", Style = "Board", Gate = { Upgrade = "#7nv" } },
	},
	UsePortalConfig = true,
	Displays = {
		{
			Model = "LevelsGUI",
			Style = "Inverted",
			Gate = { Upgrade = "#5" },
			AlsoToggleSurfaceGui = true,
		},
		{
			Model = "LevelsGUIV2",
			Style = "Inverted",
			Gate = { Upgrade = "#5" },
			AlsoToggleSurfaceGui = true,
			Hiding = false,
			TogglePart = false,
		},
		{ Model = "BoomBox", Style = "Inverted", Gate = { Upgrade = "#1music" }, Enabled = false },
	},
	Keycaps = {
		{
			Model = "Keycaps",
			ChildrenNamed = "4by4Keycaps",
			ClassIs = "MeshPart",
			Gate = { Upgrade = "#3key" },
		},
		{
			Model = "Keycaps",
			ChildrenNamed = "2by2Keycaps",
			ClassIs = "MeshPart",
			Gate = { Upgrade = "#6s" },
		},
	},
	BaseplateGroups = {
		{
			Name = "Points",
			Models = { "PointsBaseplate" },
			WatchUpgrades = {},
			Requirements = function(_)
				return true
			end,
		},
		{
			Name = "Leaderboard",
			Models = {
				"LeaderboardBaseplate",
				"SupernovaLeaderboard",
				"PointsLeaderboard",
				"DarkMatterLeaderboard",
				"LevelsLeaderboard",
				"KeycapsLeaderboard",
			},
			WatchUpgrades = { "#1Leaderboard" },
			Requirements = function(arg1)
				local str1 = "#1Leaderboard"
				return arg1.hasPurchased(str1)
			end,
		},
		{
			Name = "Prestige",
			Models = { "PrestigeBaseplate", "PrestigePack" },
			WatchUpgrades = { "#12" },
			WatchCurrency = "Prestige",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#12")
				return var1 or (arg1.currencyAbove0("Prestige") or (arg1.currencyAbove0("Steel") or (arg1.currencyAbove0("SpacePoints") or (arg1.currencyAbove0("SpacePrestige") or arg1.currencyAbove0("Loops")))))
			end,
		},
		{
			Name = "Power",
			Models = { "PowerSubBaseplate", "powerbox" },
			WatchUpgrades = { "#7p" },
			WatchCurrency = "Power",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#7p")
				return var1 or arg1.currencyAbove0("Power")
			end,
		},
		{
			Name = "Steel",
			Models = { "SteelBaseplate", "SteelPack" },
			WatchUpgrades = { "#8g" },
			WatchCurrency = "Steel",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#8g")
				return var1 or (arg1.currencyAbove0("Steel") or (arg1.currencyAbove0("SpacePoints") or (arg1.currencyAbove0("SpacePrestige") or arg1.currencyAbove0("Loops"))))
			end,
		},
		{
			Name = "SpaceShip",
			Models = { "Space Ship" },
			WatchUpgrades = { "#9s" },
			WatchCurrency = "SpacePoints",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#9s")
				return var1 or arg1.currencyAbove0("Loops")
			end,
		},
		{
			Name = "AutoBuyer",
			Models = { "AutoBuyerBaseplate" },
			WatchUpgrades = { "#15", "#1a" },
			Requirements = function(arg1)
				local str1 = "#15"
				return arg1.hasPurchased(str1)
			end,
		},
		{
			Name = "Keycap",
			Models = {
				"KeycapBaseplate",
				"KeypadSubBaseplate",
				"selectionboxthingyforkeyboard",
				"KeycapDisplay",
			},
			WatchUpgrades = { "#6s" },
			WatchCurrency = "Keycap",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#6s")
				return var1 or (arg1.currencyAbove0("Keycap") or (arg1.currencyAbove0("Loops") or arg1.currencyAbove0("SupernovaTier")))
			end,
		},
		{
			Name = "Space",
			Models = { "SpaceBaseplate", "Spawn Ship" },
			WatchUpgrades = { "#9s" },
			WatchCurrency = "SpacePoints",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#9s")
				return var1 or arg1.currencyAbove0("SpacePoints")
			end,
		},
		{
			Name = "SpacePrestige",
			Models = { "SpacePrestigeBaseplate" },
			WatchUpgrades = { "#16sp" },
			WatchCurrency = "SpacePrestige",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#16sp")
				return var1 or (arg1.currencyAbove0("SpacePrestige") or (arg1.currencyAbove0("SpacePoints") or arg1.currencyAbove0("Loops")))
			end,
		},
		{
			Name = "Bonus",
			Models = { "BonusBaseplate" },
			WatchUpgrades = { "#B0" },
			WatchCurrency = "Gamma",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#B0")
				return var1 or (arg1.currencyAbove0("Gamma") or arg1.currencyAbove0("Delta"))
			end,
		},
		{
			Name = "Omega",
			Models = { "OmegaBaseplate" },
			WatchUpgrades = { "#B15" },
			WatchCurrency = "Gamma",
			Requirements = function(arg1)
				local str1 = "#B15"
				return arg1.hasPurchased(str1)
			end,
		},
		{
			Name = "Delta",
			Models = { "DeltaSubBaseplate" },
			WatchUpgrades = { "#B8" },
			WatchCurrency = "Delta",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#B8")
				return var1 or arg1.currencyAbove0("Delta")
			end,
		},
		{
			Name = "Loop",
			Models = { "LoopBaseplate", "LevelsGUIV2" },
			WatchUpgrades = { "#9spp" },
			WatchCurrency = "Loops",
			Requirements = function(arg1)
				local var1 = arg1.hasPurchased("#9spp")
				return var1 or arg1.currencyAbove0("Loops")
			end,
		},
	},
	RegionFailsafePollInterval = 2,
	FailsafePollInterval = 0.5,
}

--- ReplicatedStorage.Shared.Config.Shop [ModuleScript]
-- y u r i

return {
	WorldPacks = {
		{ Model = "PrestigePack", GamePass = "Prestige" },
		{ Model = "SteelPack", GamePass = "Steel" },
		{ Model = "SpacePack", GamePass = "Space" },
		{ Model = "DarkMatterPack", GamePass = "DarkMatter" },
		{ Model = "SupernovaPack", GamePass = "Supernova" },
	},
	WorldPackButtonPath = { "SurfaceGui", "TextButton" },
	GuiPacks = {
		{ Frame = "PrestigePack", GamePass = "Prestige" },
		{ Frame = "SteelPack", GamePass = "Steel" },
		{ Frame = "SpacePack", GamePass = "Space" },
		{ Frame = "DarkMatterPack", GamePass = "DarkMatter" },
		{ Frame = "SupernovaPack", GamePass = "Supernova" },
		{ Frame = "VIP", GamePass = "VIP" },
		{ Frame = "VIP+", GamePass = "VIPPLUS" },
		{ Frame = "x3allstats:skull:", GamePass = "X3ALLSTATS" },
	},
	GuiFramePath = { "ShopGUI", "ShopFrame", "ScrollingFrame" },
	GuiPackButton = "BuyButton",
}

--- ReplicatedStorage.Shared.Config.Challenges [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Shared.Libs.EternityNum)
local var2 = require(game:GetService("ReplicatedStorage").Shared.Util)
local var3 = require(game:GetService("ReplicatedStorage").Shared.Config.Resets)
local num1 = 2100
local tbl1 = { Stat = "Power", AtLeast = var1.pow(10, num1), Progress = "log" }
local tbl2 = { tbl1 }
tbl2[2] = { Stat = "Level", AtLeast = 548, Progress = "linear" }
tbl2[3] = { Stat = "Loops", AtLeast = 5, Progress = "linear" }
tbl2[4] = { Stat = "Level", AtLeast = 1000, Progress = "linear" }
tbl2[5] = { Stat = "Level", AtLeast = 1500, Progress = "linear" }
local tbl3 = {
	TitleText = "#1: <font color=\"#F5F9FC\">Rooted Gain</font>",
	MaxLevel = 5,
	Goals = tbl2,
}

tbl3.PenaltyText = function(_, arg2)
	local var1 = 0.81 ^ arg2.difficulty
	return ("- ^%.4g all currencies before Supernova (except Loops)"):format(var1)
end

tbl3.RewardText = function(_, arg2)
	local function multAt(arg1)
		if arg1 <= 0 then
			local num2 = 1
			return var1.convert(num2)
		end

		local num3 = 10
		local var2 = 33 + (arg1 - 1) * 15
		return var1.pow(num3, var2)
	end

	local var2 = arg2.level
	local var3 = var1.short(multAt(var2))
	local var4 = arg2.level + 1
	return "x" .. var3 .. " XP -> x" .. var1.short(multAt(var4)) .. " XP"
end

tbl3.XPMult = function(_, arg2)
	if arg2.level <= 0 then
		return 1
	end

	local num1 = 10
	local var2 = 33 + (arg2.level - 1) * 12
	return var1.pow(num1, var2)
end

local tbl4 = { PenaltyStats = {
	"Points",
	"XP",
	"Prestige",
	"Power",
	"Steel",
	"SpacePoints",
	"StarXP",
	"SpacePrestige",
	"Keycap",
	"DarkMatter",
} }

local tbl5 = {}
local tbl6 = {}
for k1, v1 in ipairs(tbl4.PenaltyStats) do
	tbl3[v1 .. "ExpoInChallenge"] = function(_, arg2)
		return 0.81 ^ arg2.difficulty
	end

end

tbl6["#1"] = tbl3
local tbl7 = { Stat = "Power", AtLeast = var1.pow(10, 12), Progress = "log" }
tbl1 = { { Stat = "Points", AtLeast = 1e+18, Progress = "log" }, tbl7 }
tbl1[3] = { Stat = "StarLevels", AtLeast = 30 }
tbl1[4] = { Stat = "Loops", AtLeast = 1 }
tbl1[5] = { Stat = "Loops", AtLeast = 10 }
local tbl8 = {
	"- /1Qn Points, /100UDe XP, ^0.95 all currencies listed and automation is disabled :3",
	function(arg1, _)
		local var2 = arg1.Values.SupernovaTier.Value
		local var3 = var1.toNumber(var1.convert(var2))
		local var4 = 503 + var3 * 10
		return ("- /10De Points, /1DDe XP, /100Qd Prestige, /3e%d Power, ^0.85 all currencies listed and automation is disabled :3"):format(var4)
	end,
	"- ^0.7 SpacePoints, /10K StarXP gain, automation disabled :3",
	"- Prestige and Steel gain fully blocked, automation disabled :3",
	"- ^0.5 Points, Power and XP gain, automation disabled :3",
}

tbl7 = {
	{ Points = { Mult = 1e-19, Expo = 0.95 }, XP = { Mult = 1e-38, Expo = 0.95 } },
	{
		Points = { Mult = 1e-34, Expo = 0.85 },
		XP = { Mult = 1e-39, Expo = 0.85 },
		Prestige = { Mult = 1e-17, Expo = 0.85 },
		Power = {
			Mult = function(arg1, _)
				local var2 = arg1.Values.SupernovaTier.Value
				local var3 = var1.toNumber(var1.convert(var2))
				local num1 = 10
				local var4 = -(503 + var3 * 10)
				var2 = 3
				return var1.mul(var2, var1.pow(num1, var4))
			end,
			Expo = 0.85,
		},
	},
	{ SpacePoints = { Expo = 0.7 }, StarXP = { Mult = 0.0001 } },
	{ Prestige = { Mult = 0 }, Steel = { Mult = 0 } },
	{ Points = { Expo = 0.5 }, Power = { Expo = 0.5 }, XP = { Expo = 0.5 } },
}

tbl3 = function(arg1)
	return 2 ^ arg1
end

local tbl9 = {
	TitleText = "#2: <font color=\"#F5F9FC\">Back to Basics</font>",
	MaxLevel = 2,
	Goals = tbl1,
	PenaltyText = function(arg1, arg2)
		local var3 = tbl8[arg2.difficulty]
		if not var3 then
			return "- (no penalty authored for this difficulty yet)"
		end

		local var4 = var3
		local var5 = arg1
		local var6 = arg2
		return var2.resolve(var4, var5, var6)
	end,
	DisableAutomationInChallenge = true,
	NovaRateMultiplier = function(arg1)
		return 10 ^ arg1
	end,
	RewardText = function(_, arg2)
		local var2 = 10 ^ (arg2.level + 1)
		local var3 = 2 ^ arg2.level
		local var4 = 2 ^ (arg2.level + 1)
		local var5 = var1.short(10 ^ arg2.level)
		return ("^%d -> ^%d First Supernova Bonus & +%s -> +%s NV$ per Supernova Tier"):format(var3, var4, var5, var1.short(var2))
	end,
}

local tbl10 = {}
for k2, v2 in pairs(tbl7) do
	for k3 in pairs(v2) do
		tbl10[k3] = true
	end
end

for k4 in pairs(tbl10) do
	tbl9[k4 .. "MultInChallenge"] = function(arg1, arg2)
		local var1 = tbl7[arg2.difficulty]
		local var3 = var1
		var1 = var3 and var1[k4]
		local var4 = var1 and var1.Mult or 1
		local var5 = arg1
		local var6 = arg2
		return var2.resolve(var4, var5, var6)
	end

	tbl9[k4 .. "BaseInChallenge"] = function(arg1, arg2)
		local var1 = tbl7[arg2.difficulty]
		local var3 = var1
		var1 = var3 and var1[k4]
		local var4 = var1 and var1.Base or 0
		local var5 = arg1
		local var6 = arg2
		return var2.resolve(var4, var5, var6)
	end

	tbl9[k4 .. "ExpoInChallenge"] = function(arg1, arg2)
		local var1 = tbl7[arg2.difficulty]
		local var3 = var1
		var1 = var3 and var1[k4]
		local var4 = var1 and var1.Expo or 1
		local var5 = arg1
		local var6 = arg2
		return var2.resolve(var4, var5, var6)
	end

end

tbl6["#2"] = tbl9
tbl3 = {
	{
		Patterns = { var3.Patterns.Prestige, var3.Patterns.Power },
		Exceptions = { ["#8g"] = true, ["#1g"] = true },
	},
	{
		Patterns = { var3.Patterns.Prestige, var3.Patterns.Power, var3.Patterns.StarLevel },
		Exceptions = { ["#8g"] = true, ["#3sl"] = true, ["#1g"] = true },
	},
	{
		"",
		Patterns = {
			var3.Patterns.Prestige,
			var3.Patterns.Power,
			var3.Patterns.StarLevel,
			var3.Patterns.SpacePrest,
		},
		Exceptions = { ["#8g"] = true, ["#3sl"] = true, ["#9spp"] = true, ["#1g"] = true, ["#10spp"] = true },
	},
	{
		Patterns = {
			var3.Patterns.Prestige,
			var3.Patterns.Power,
			var3.Patterns.StarLevel,
			var3.Patterns.SpacePrest,
			var3.Patterns.DarkMatter,
			var3.Patterns.DarkBoard,
		},
		Exceptions = { ["#8g"] = true, ["#3sl"] = true, ["#9spp"] = true, ["#1g"] = true, ["#10spp"] = true },
	},
	{
		Patterns = {
			var3.Patterns.Prestige,
			var3.Patterns.Power,
			var3.Patterns.StarLevel,
			var3.Patterns.SpacePrest,
			var3.Patterns.DarkMatter,
			var3.Patterns.DarkBoard,
			var3.Patterns.Plain,
		},
		Exceptions = {
			["#8g"] = true,
			["#3sl"] = true,
			["#9spp"] = true,
			["#5"] = true,
			["#1g"] = true,
			["#10spp"] = true,
		},
	},
}

tbl2 = {
	[var3.Patterns.Prestige] = "Prestige",
	[var3.Patterns.Power] = "Power",
	[var3.Patterns.StarLevel] = "Star Level",
	[var3.Patterns.SpacePrest] = "Space Prestige",
	[var3.Patterns.DarkMatter] = "Dark Matter",
	[var3.Patterns.DarkBoard] = "Dark Board",
	[var3.Patterns.Plain] = "Points",
}

tbl8 = {
	{ Level = 1, Suffix = "spp", From = 1, To = 6 },
	{ Level = 2, Suffix = "spp", From = 7, To = 13 },
	{ Level = 3, Suffix = "dm", From = 1, To = 14 },
	{ Level = 4, Suffix = "db", From = 1, To = 4 },
	{ Level = 5, Suffix = "db", From = 5, To = 8 },
}

tbl9 = {
	TitleText = "#3: <font color=\"#F5F9FC\">Unserviceable Upgrades</font>",
	MaxLevel = 5,
	Goals = {
		{ Stat = "Loops", AtLeast = 10, Progress = "linear" },
		{ Stat = "Loops", AtLeast = 10, Progress = "linear" },
		{ Stat = "Loops", AtLeast = 10, Progress = "linear" },
		{ Stat = "Loops", AtLeast = 10, Progress = "linear" },
		{ Stat = "Loops", AtLeast = 10, Progress = "linear" },
	},
	IsUpgradeDisabledInChallenge = function(_, arg2, arg3)
		local var2 = tbl3[arg2.difficulty]
		if not var2 then
			return false
		end

		if var2.Exceptions[arg3] then
			return false
		end

		for k1, v1 in ipairs(var2.Patterns) do
			if not string.match(arg3, v1) then
				continue
			end

			return true
		end

		return false
	end,
	PenaltyText = function(_, arg2)
		local var2 = tbl3[arg2.difficulty]
		if not var2 then
			return "- (no penalty authored for this difficulty yet)"
		end

		local tbl1 = {}
		for k1, v1 in ipairs(var2.Patterns) do
			table.insert(tbl1, tbl2[v1] or v1)
		end

		local str1 = "- Disables "
		local var3
		local var4
		if #tbl1 == 1 then
			var3 = tbl1[1]
		else
			if #tbl1 == 2 then
				var4 = tbl1[2]
				var3 = tbl1[1] .. " and " .. var4
			else
				var4 = tbl1[#tbl1]
				var3 = table.concat(tbl1, ", ", 1, #tbl1 - 1) .. ", and " .. var4
			end
		end

		local var5 = str1 .. var3 .. " Upgrades"
		str1 = {}
		for k2 in pairs(var2.Exceptions) do
			table.insert(str1, k2)
		end

		table.sort(str1)
		if 0 < (#str1) then
			var5 = var5 .. " (Excluding " .. table.concat(str1, ", ") .. " & upgrade unlockers)"
		end

		return var5
	end,
	AutoUpgradeKeys = function(_, arg2)
		local tbl1 = {}
		for k1, v1 in ipairs(tbl8) do
			if v1.Level > arg2.level then
				continue
			end

			for i1 = v1.From, v1.To do
				table.insert(tbl1, "#" .. i1 .. v1.Suffix)
			end
		end

		return tbl1
	end,
	GrantStatFromLevel = function(_, arg2, arg3)
		if arg2.level < 5 then
			return
		end

		local var2 = arg3.Level.Value
		local num1 = 100
		local var3 = var1.floor(var1.div(var2, num1))
		if var1.me(var3, arg3.Loops.Value) then
			arg3.Loops.Value = var1.toString(var3)
		end
	end,
	RewardText = function(_, arg2)
		local tbl1 = {
			"#1spp-#6spp",
			"#1spp-#13spp",
			"#1spp-#13spp & #1dm-#14dm",
			"#1spp-#13spp & #1dm-#14dm & #1db-#4db",
			"#1spp-#13spp & #1dm-#14dm & #1db-#8db + Auto-Loop",
		}

		return "Auto: " .. (tbl1[arg2.level] or "none") .. " -> " .. (tbl1[arg2.level + 1] or "maxed")
	end,
}

tbl6["#3"] = tbl9
tbl1 = function(arg1)
	if #arg1 == 1 then
		return arg1[1]
	end

	if #arg1 == 2 then
		return arg1[1] .. " and " .. arg1[2]
	end

	return table.concat(arg1, ", ", 1, #arg1 - 1) .. ", and " .. arg1[#arg1]
end

tbl3 = {
	TitleText = "#4: <font color=\"#F5F9FC\">XP Tester</font>",
	MaxLevel = 1,
	Goals = { { Stat = "Level", AtLeast = 1 } },
	PenaltyText = function(_, _)
		return [[- /1e1000 all currencies before Supernova except XP
- /10TTg XP Gain]]
	end,
	RewardText = function(_, _)
		return "- Fully automates the entirety of #1 to #20, #1p to #15p, #1g to #17g, and #1s to #13s"
	end,
	AutoUpgradeKeys = function(_, _)
		local tbl1 = {}
		local function addRange(arg1, arg2, arg3)
			for i1 = arg2, arg3 do
				table.insert(tbl1, "#" .. i1 .. arg1)
			end
		end

		addRange("", 1, 20)
		addRange("p", 1, 15)
		addRange("g", 1, 17)
		addRange("s", 1, 13)
		return tbl1
	end,
}

for k5, v3 in ipairs(tbl4.PenaltyStats) do
	if v3 == "XP" then
		continue
	end

	tbl3[v3 .. "MultInChallenge"] = function(_, _)
		local num1 = 10
		local num2 = -1000
		return var1.pow(num1, num2)
	end

	tbl3.XPMultInChallenge = function(_, _)
		local num1 = 10
		local num2 = -102
		local num3 = 10
		return var1.mul(num3, var1.pow(num1, num2))
	end

end

tbl6["#4"] = tbl3
local tbl11 = { Stat = "Keycap", AtLeast = var1.pow(10, 16), Progress = "log" }
tbl7 = { tbl11 }
tbl11 = { Stat = "Keycap", AtLeast = var1.pow(10, 20), Progress = "log" }
tbl7[2] = tbl11
tbl11 = { Stat = "Keycap", AtLeast = var1.pow(10, 24), Progress = "log" }
tbl7[3] = tbl11
tbl1 = {
	TitleText = "#5: <font color=\"#F5F9FC\">Key Capped</font>",
	MaxLevel = 3,
	Goals = tbl7,
}

tbl1.PenaltyText = function(_, arg2)
	return ({
		"- ^0.9 Keycap gain, /1T Keycap gain",
		"- ^0.7 Keycap gain, /10T Keycap gain",
		"- ^0.5 Keycap gain, /100T Keycap gain",
	})[arg2.difficulty] or "- (no penalty authored for this difficulty yet)"
end

tbl3 = function(arg1)
	if arg1 <= 0 then
		return 1
	end

	local num1 = 10
	local var2 = 18 * arg1
	return var1.pow(num1, var2)
end

tbl1.XPMult = function(_, arg2)
	local var1 = arg2.level
	return tbl3(var1)
end

tbl1.SupernovaTierMult = function(_, arg2)
	local var2 = arg2.level
	if 3 <= var2 then
		return 3
	end

	if 2 <= var2 then
		return 2
	end

	if 1 <= var2 then
		return 1.5
	end

	return 1
end

tbl1.RewardText = function(_, arg2)
	local var3 = arg2.level
	local var4
	if 3 < var3 then
		var4 = "maxed"
	else
		local var5 = var3
		local str1 = "x"
		local var6 = var1.short(tbl3(var5))
		local str2 = " XP & x"
		local var7
		if 3 <= var3 then
			var7 = 3
		else
			if 2 <= var3 then
				var7 = 2
			else
				var7 = if 1 <= var3 then 1.5 else 1
			end
		end

		var5 = tostring(var7)
		var4 = str1 .. var6 .. str2 .. var5 .. " SupernovaTier"
	end

	local var9 = arg2.level + 1
	var3 = " -> "
	local var10
	if 3 < var9 then
		var10 = "maxed"
	else
		local var11 = var9
		local str3 = "x"
		local var12 = var1.short(tbl3(var11))
		var7 = " XP & x"
		local var13
		if 3 <= var9 then
			var13 = 3
		else
			if 2 <= var9 then
				var13 = 2
			elseif 1 <= var9 then
				var13 = 1.5
			else
				var13 = 1
			end
		end

		var11 = tostring(var13)
		var10 = str3 .. var12 .. var7 .. var11 .. " SupernovaTier"
	end

	return var4 .. var3 .. var10
end

local tbl12 = { Mult = var1.pow(10, -12), Expo = 0.9 }
tbl7 = { { Keycap = tbl12 } }
tbl12 = { Mult = var1.pow(10, -13), Expo = 0.7 }
tbl7[2] = { Keycap = tbl12 }
tbl12 = { Mult = var1.pow(10, -14), Expo = 0.5 }
tbl7[3] = { Keycap = tbl12 }
tbl1.KeycapMultInChallenge = function(_, arg2)
	local var2 = tbl7[arg2.difficulty]
	if var2 and var2.Keycap then
		return var2.Keycap.Mult
	end

	return 1
end

tbl1.KeycapExpoInChallenge = function(_, arg2)
	local var2 = tbl7[arg2.difficulty]
	if var2 and var2.Keycap then
		return var2.Keycap.Expo
	end

	return 1
end

tbl6["#5"] = tbl1
tbl12 = "#3"
tbl10 = "#4"
tbl4.Order = { "#1", "#2", tbl12, tbl10, "#5" }
for k6, v4 in pairs(tbl6) do
	tbl4[k6] = v4
end

tbl4.DifficultyFor = function(arg1, arg2)
	return (math.min(arg2 + 1, arg1.MaxLevel))
end

tbl4.GoalFor = function(arg1, arg2)
	for i1 = arg2, 1, -1 do
		if not arg1.Goals[i1] then
			continue
		end

		return arg1.Goals[i1]
	end

	return nil
end

tbl4.GoalTextForGate = function(arg1)
	if arg1.Stat and arg1.AtLeast ~= nil then
		local var4 = var1.short(arg1.AtLeast)
		local var5 = arg1.Stat
		return ("- Reach %s %s"):format(var4, var5)
	end

	if arg1.Stat and arg1.GreaterThan ~= nil then
		local var8 = arg1.GreaterThan
		local var9 = arg1.Stat
		return ("- Get %s above %s"):format(var9, var1.short(var8))
	end

	if arg1.Upgrade then
		return "- Own " .. arg1.Upgrade
	end

	return "- (goal not set)"
end

tbl4.GetGoalText = function(arg1, arg2)
	if arg2.GoalText then
		local var5 = arg2.GoalText
		local var6 = arg1
		local var7 = arg2
		return var2.resolve(var5, var6, var7)
	end

	local var9 = tbl4.GoalFor(arg2, arg2.difficulty)
	if not var9 then
		return "- (no goal authored for this difficulty yet)"
	end

	local var10 = var9
	return tbl4.GoalTextForGate(var10)
end

tbl4.GetPlayerTable = function(arg1)
	if not tbl5[arg1] then
		tbl5[arg1] = var2.deepCopy(tbl6)
	end

	return tbl5[arg1]
end

tbl4.ReleasePlayer = function(arg1)
	tbl5[arg1] = nil
end

tbl4.WithState = function(arg1, arg2, arg3)
	local tbl1 = { level = arg2, difficulty = tbl4.DifficultyFor(arg1, arg2) }
	tbl1.active = arg3 or false
	return (setmetatable(tbl1, { __index = arg1 }))
end

return tbl4

--- ReplicatedStorage.Shared.Config.BuyMaxCategories [ModuleScript]
-- y u r i

local tbl1 = { key = "s", label = "Steel" }
local tbl2 = {
	List = {
		{ key = "points", label = "Points" },
		{ key = "p", label = "Prestige" },
		{ key = "g", label = "Power" },
		tbl1,
		{ key = "a", label = "Auto-buyers" },
		{ key = "key", label = "Keycaps" },
		{ key = "sl", label = "Star Levels" },
		{ key = "sp", label = "Space Points" },
		{ key = "spp", label = "Space Prestige" },
		{ key = "dm", label = "Dark Matter" },
		{ key = "db", label = "Darkboard" },
		{ key = "nv", label = "Nova" },
		{ key = "gift", label = "Gifts" },
		{ key = "music", label = "Music" },
		{ key = "gamma", label = "Gamma Board" },
	},
	ByKey = {},
}

for k1, v1 in ipairs(tbl2.List) do
	tbl2.ByKey[v1.key] = v1
end

tbl2.CategoryOf = function(arg1)
	local var2 = string.match(arg1, "^#%d+(%l*)$")
	if var2 then
		if var2 == "" then
			return "points"
		end

		return var2
	end

	if string.match(arg1, "^#B%d+$") then
		return "gamma"
	end

	return nil
end

return tbl2

--- Workspace.Keycaps.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.PointsLeaderboard.Display.SurfaceGui.ScrollingFrame.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.LevelsLeaderboard.Display.SurfaceGui.ScrollingFrame.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.KeycapsLeaderboard.Display.SurfaceGui.ScrollingFrame.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.DarkMatterLeaderboard.Display.SurfaceGui.ScrollingFrame.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.SupernovaLeaderboard.Display.SurfaceGui.ScrollingFrame.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.lwtwtnp.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

