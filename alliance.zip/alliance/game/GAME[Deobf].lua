--- Players.LocalPlayer.PlayerScripts.TowerAttackAudio [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "TowerAttackConfig"
local var2 = require(var1:WaitForChild("Modules"):WaitForChild(str1))
local tbl1 = { "AttackSoundOrigin", "AttackOrigin", "Muzzle" }
local function getValidClips(arg1)
	local tbl1 = {}
	if type(arg1.Clips) ~= "table" then
		return tbl1
	end

	for k1, v1 in ipairs(arg1.Clips) do
		if type(v1) ~= "table" then
			continue
		end

		local var1 = v1.SoundId
		local var2
		if typeof(var1) ~= "string" then
			var2 = nil
		else
			local var4 = var1:match("^%s*(.-)%s*$")
			if var4 == "" then
				var2 = nil
			else
				if var4:match("^rbxassetid://%d+$") then
					var2 = var4
				else
					var2 = if var4:match("^%d+$") then "rbxassetid://" .. var4 else nil
				end
			end
		end

		if not var2 then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end

local var3 = setmetatable({}, { __mode = "k" })
str1 = Random.new()
local var4 = setmetatable({}, { __mode = "k" })
local function destroyPool(arg1)
	local var2 = var4[arg1]
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2.banks) do
		for k2, v2 in ipairs(v1.voices) do
			if not v2.Parent then
				continue
			end

			v2:Destroy()
		end
	end

	var4[arg1] = nil
end

local function getPool(arg1, arg2)
	local var2 = var4[arg1]
	if var2 and var2.origin ~= arg2 then
		destroyPool(arg1)
		var2 = nil
	end

	if not var2 then
		var2 = { origin = arg2, banks = {} }
		var4[arg1] = var2
	end

	return var2
end

local function configureVoice(arg1, arg2, arg3)
	local var1 = var2.Defaults
	local var3 = arg2.Volume
	local var4 = arg3.Volume
	local var5 = var1.Volume
	local var6 = if typeof(var3) ~= "number" or (var3 ~= var3 or (var3 == math.huge or var3 == -math.huge)) then var5 else var3
	var5 = arg2.PlaybackSpeed
	local var7 = if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then var6 else var4
	var6 = arg3.PlaybackSpeed
	local var8 = var1.PlaybackSpeed
	var3 = if typeof(var5) ~= "number" or (var5 ~= var5 or (var5 == math.huge or var5 == -math.huge)) then var8 else var5
	var8 = arg2.RollOffMinDistance
	var4 = if typeof(var6) ~= "number" or (var6 ~= var6 or (var6 == math.huge or var6 == -math.huge)) then var3 else var6
	var3 = 0
	local var9 = var1.RollOffMinDistance
	var9 = arg2.RollOffMaxDistance
	var6 = math.max(var3, if typeof(var8) ~= "number" or (var8 ~= var8 or (var8 == math.huge or var8 == -math.huge)) then var9 else var8)
	local var10 = var1.RollOffMaxDistance
	var3 = math.max(var6, if typeof(var9) ~= "number" or (var9 ~= var9 or (var9 == math.huge or var9 == -math.huge)) then var10 else var9)
	arg1.Volume = math.clamp(var7, 0, 10)
	arg1.PlaybackSpeed = math.clamp(var4, 0.05, 4)
	arg1.RollOffMode = Enum.RollOffMode.InverseTapered
	arg1.RollOffMinDistance = var6
	arg1.RollOffMaxDistance = var3
end

local function getBank(arg1, arg2, arg3)
	local var1 = getPool(arg1, arg2)
	local var3 = var1.banks[arg3]
	if not var3 then
		var3 = { voices = {}, cursor = 0 }
		var1.banks[arg3] = var3
	end

	return var3
end

local function getSoundSettings(arg1)
	local var1 = arg1:GetAttribute("UnitId")
	local var3 = var2.Units
	local var4 = var3[if typeof(var1) == "string" and var1 ~= "" then var1 else arg1.Name]
	if type(var4) ~= "table" then
		return nil
	end

	var1 = arg1:GetAttribute("Level")
	var3 = var4.Sound
	local var6 = if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then nil else var1
	if var6 then
		var1 = var4.Levels[math.max(1, (math.floor(var6)))]
		if type(var4.Levels) == "table" and (type(var1) == "table" and type(var1.Sound) == "table") then
			var3 = var1.Sound
		end
	end

	if type(var3) ~= "table" then
		return nil
	end

	return var3
end

local function findSoundOrigin(arg1)
	for k1, v1 in ipairs(tbl1) do
		local var1 = arg1:FindFirstChild(v1, true)
		local var2 = var1
		if not (var2 and (var1:IsA("Attachment") or var1:IsA("BasePart"))) then
			continue
		end

		return var1
	end

	local var3 = arg1.PrimaryPart
	local var4 = var3
	if var4 and (var3:IsA("Attachment") or var3:IsA("BasePart")) then
		return arg1.PrimaryPart
	end

	local str1 = "HumanoidPart"
	for k2, v2 in ipairs({ "HumanoidRootPart", str1 }) do
		local var5 = arg1:FindFirstChild(v2, true)
		if not var5 then
			continue
		end

		if not var5:IsA("BasePart") then
			continue
		end

		return var5
	end

	local str2 = "BasePart"
	local bool1 = true
	return arg1:FindFirstChildWhichIsA(str2, bool1)
end

local function selectClips(arg1, arg2)
	local var1 = getValidClips(arg2)
	local var4 = #var1
	if var4 == 0 then
		return {}
	end

	if arg2.Mode == "All" then
		return var1
	end

	if var4 == 1 then
		var3[arg1] = 1
		return { var1[1] }
	end

	local var5 = var3[arg1]
	local var7 = nil
	if typeof(var5) == "number" then
		if 1 <= var5 then
			if var5 <= var4 then
				var7 = str1:NextInteger(1, var4 - 1)
				if var5 <= var7 then
					var7 = var7 + 1
				end
			else
				var7 = str1:NextInteger(1, var4)
			end
		else
			var7 = str1:NextInteger(1, var4)
		end
	else
		var7 = str1:NextInteger(1, var4)
	end

	var3[arg1] = var7
	return { var1[var7] }
end

local function acquireVoice(arg1, arg2, arg3, arg4, arg5)
	local var1 = var2.Defaults.MaxConcurrent
	local var3 = getBank(arg1, arg2, arg5)
	local var4 = arg3.MaxConcurrent
	local var5 = if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then 4 else var1
	local var6 = math.clamp(math.floor(if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then var5 else var4), 1, 16)
	for i1 = #var3.voices, 1, -1 do
		var5 = var3.voices
		if var5[i1].Parent then
			continue
		end

		var5 = var3.voices
		table.remove(var5, i1)
	end

	for k1, v1 in ipairs(var3.voices) do
		if v1.IsPlaying then
			continue
		end

		configureVoice(v1, arg3, arg4)
		return v1
	end

	if #var3.voices < var6 then
		local var7 = Instance.new("Sound")
		var7.Name = "TowerAttackVoice"
		var7.SoundId = arg5
		var7.Looped = false
		configureVoice(var7, arg3, arg4)
		var7.Parent = arg2
		table.insert(var3.voices, var7)
		return var7
	end

	local var8 = var3.cursor % #var3.voices + 1
	var3.cursor = var8
	var8 = var3.voices[var3.cursor]
	configureVoice(var8, arg3, arg4)
	return var8
end

local var5 = game:GetService("ContentProvider")
local function addPreloadSounds(arg1, arg2, arg3)
	if type(arg1) ~= "table" or type(arg1.Clips) ~= "table" then
		return
	end

	for k1, v1 in ipairs(arg1.Clips) do
		if type(v1) == "table" then
			local var1 = v1.SoundId
			local var2
			if typeof(var1) ~= "string" then
				var2 = nil
			else
				local var4 = var1:match("^%s*(.-)%s*$")
				if var4 == "" then
					var2 = nil
				else
					if var4:match("^rbxassetid://%d+$") then
						var2 = var4
					else
						var2 = if var4:match("^%d+$") then "rbxassetid://" .. var4 else nil
					end
				end
			end

			var2 = var2 or nil
		end

		var2 = nil
		if not var2 then
			continue
		end

		if arg2[var2] then
			continue
		end

		arg2[var2] = true
		local var5 = Instance.new("Sound")
		var5.Name = "AttackSoundPreload"
		var5.SoundId = var2
		var5.Volume = 0
		var5.Parent = script
		table.insert(arg3, var5)
	end
end

local function playAttackSound(arg1)
	local var2 = getSoundSettings(arg1)
	if not var2 then
		return
	end

	local var4 = findSoundOrigin(arg1)
	if not var4 then
		return
	end

	local var5 = arg1
	for k1, v1 in ipairs((selectClips(var5, var2))) do
		local var6 = v1.SoundId
		local var7
		if typeof(var6) ~= "string" then
			var7 = nil
		else
			local var9 = var6:match("^%s*(.-)%s*$")
			if var9 == "" then
				var7 = nil
			else
				if var9:match("^rbxassetid://%d+$") then
					var7 = var9
				else
					var7 = if var9:match("^%d+$") then "rbxassetid://" .. var9 else nil
				end
			end
		end

		if not var7 then
			continue
		end

		var6 = acquireVoice(arg1, var4, var2, v1, var7)
		if not var6 then
			continue
		end

		if not var6.Parent then
			continue
		end

		var6.TimePosition = 0
		var6:Play()
	end
end

var1:WaitForChild("RemoteEvents"):WaitForChild("AnimateTower").OnClientEvent:Connect(function(arg1, arg2)
	if (arg2 == "Attack" or arg2 ~= "HandAttack") and (typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or (not arg1:IsDescendantOf(workspace)))) then
		return
	end

	playAttackSound(arg1)
end)

local var6 = workspace:WaitForChild("Towers")
local function warmTower(arg1)
	local var2 = getSoundSettings(arg1)
	if not var2 then
		return
	end

	local var3 = getValidClips(var2)
	if #var3 == 0 then
		return
	end

	task.spawn(function()
		local var1 = nil
		for i1 = 1, 40 do
			if not arg1.Parent then
				return
			end

			var1 = findSoundOrigin(arg1)
			if var1 then
				break
			end

			task.wait(0.1)
		end

		if not var1 or (not arg1.Parent) then
			return
		end

		local tbl1 = {}
		for k1, v1 in ipairs(var3) do
			local var4 = v1.SoundId
			local var6
			if typeof(var4) ~= "string" then
				var6 = nil
			else
				local var8 = var4:match("^%s*(.-)%s*$")
				if var8 == "" then
					var6 = nil
				else
					if var8:match("^rbxassetid://%d+$") then
						var6 = var8
					else
						var6 = if var8:match("^%d+$") then "rbxassetid://" .. var8 else nil
					end
				end
			end

			if not var6 then
				continue
			end

			var4 = getBank(arg1, var1, var6)
			if #var4.voices ~= 0 then
				continue
			end

			local var9 = Instance.new("Sound")
			var9.Name = "TowerAttackVoice"
			var9.SoundId = var6
			var9.Looped = false
			configureVoice(var9, var2, v1)
			var9.Parent = var1
			table.insert(var4.voices, var9)
			table.insert(tbl1, var9)
		end

		if 0 < (#tbl1) then
			pcall(function()
				var5:PreloadAsync(tbl1)
			end)

		end
	end)
end

local function preloadConfiguredSounds()
	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in pairs(var2.Units) do
		if type(v1) ~= "table" then
			continue
		end

		addPreloadSounds(v1.Sound, tbl2, tbl1)
		if type(v1.Levels) ~= "table" then
			continue
		end

		for k2, v2 in pairs(v1.Levels) do
			if type(v2) ~= "table" then
				continue
			end

			addPreloadSounds(v2.Sound, tbl2, tbl1)
		end
	end

	if 0 < (#tbl1) then
		pcall(function()
			var5:PreloadAsync(tbl1)
		end)

	end

	for k3, v3 in ipairs(tbl1) do
		v3:Destroy()
	end
end

for k1, v1 in ipairs(var6:GetChildren()) do
	if not v1:IsA("Model") then
		continue
	end

	warmTower(v1)
end

var6.ChildAdded:Connect(function(arg1)
	if arg1:IsA("Model") then
		warmTower(arg1)
	end
end)

var6.ChildRemoved:Connect(function(arg1)
	destroyPool(arg1)
	var3[arg1] = nil
end)

task.defer(preloadConfiguredSounds)

--- Players.LocalPlayer.PlayerScripts.ModelPreloader [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local function collectAssets(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("MeshPart") or (v1:IsA("SpecialMesh") or (v1:IsA("Decal") or (v1:IsA("Texture") or (v1:IsA("Animation") or (v1:IsA("Sound") or (v1:IsA("ImageLabel") or v1:IsA("ImageButton"))))))) then
			table.insert(arg2, v1)
		end
	end
end

local var2 = game:GetService("ContentProvider")
local var3 = game:GetService("Players").LocalPlayer
task.spawn(function()
	if not game:IsLoaded() then
		game.Loaded:Wait()
	end

	local str1 = "Crates"
	local tbl1 = {}
	for k1, v1 in ipairs({ "Towers", str1, "Visual" }) do
		local var4 = var1:FindFirstChild(v1)
		if not var4 then
			continue
		end

		collectAssets(var4, tbl1)
	end

	local success, result = pcall(function()
		if 0 < (#tbl1) then
			var2:PreloadAsync(tbl1)
		end
	end)

	var3:SetAttribute("ModelsPreloaded", success)
	if not success then
		warn("[ModelPreloader] Could not preload every model asset:", result)
	end
end)

--- Players.LocalPlayer.PlayerScripts.MobHealth [LocalScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var3 = var1:WaitForChild("PlayerGui", 10)
local var4 = game:GetService("ReplicatedStorage")
local var5 = game:GetService("RunService")
local var6 = game:GetService("TweenService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("GuiService")
local var9 = Vector2.new(20, 20)
local var10 = Color3.fromRGB(181, 255, 131)
local var11 = Color3.fromRGB(85, 255, 0)
local var12 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var13 = var1:GetMouse()
local function findDescendantOfClass(arg1, arg2, arg3)
	for k1, v1 in arg1:GetDescendants() do
		if v1.Name ~= arg2 then
			continue
		end

		if not v1:IsA(arg3) then
			continue
		end

		return v1
	end

	return nil
end

local var15 = if var3 == nil or (not var3:IsA("PlayerGui")) then nil else var3
if var15 == nil then
	return
end

local var17 = workspace:WaitForChild("Mobs", 10)
var3 = if var17 == nil or (not var17:IsA("Folder")) then nil else var17
if var3 == nil then
	return
end

local var19 = workspace:WaitForChild("EngineerUnits", 10)
local var21 = if var19 == nil or (not var19:IsA("Folder")) then nil else var19
if var21 == nil then
	return
end

var17 = var4:WaitForChild("UI", 10)
if var17 == nil then
	return
end

local var23 = var17:WaitForChild("ToiletInfo", 10)
var19 = if var23 == nil or (not var23:IsA("ScreenGui")) then nil else var23
if var19 == nil then
	return
end

local var25 = var4:WaitForChild("Visual", 10)
var23 = if var25 == nil or (not var25:IsA("Folder")) then nil else var25
if var23 == nil then
	return
end

local var27 = var23:WaitForChild("HighLights", 10)
var25 = if var27 == nil or (not var27:IsA("Folder")) then nil else var27
if var25 == nil then
	return
end

local var29 = var25:WaitForChild("ForHover", 10)
var27 = if var29 == nil or (not var29:IsA("Highlight")) then nil else var29
if var27 == nil then
	return
end

local var31 = var23:WaitForChild("HealthUI", 10)
var29 = if var31 == nil or (not var31:IsA("BillboardGui")) then nil else var31
if var29 == nil then
	return
end

var31 = var19:Clone()
if var31 == nil or (not var31:IsA("ScreenGui")) then
	return
end

var31.Name = "ToiletInfo"
var31.ResetOnSpawn = false
var31.Enabled = true
var31.Parent = var15
local var33 = var31:FindFirstChild("Hover")
local var35 = if var33 == nil or (not var33:IsA("GuiObject")) then nil else var33
if var35 == nil then
	var31:Destroy()
	return
end

local var37 = var35:FindFirstChild("ToiletHp")
var33 = if var37 == nil or (not var37:IsA("GuiObject")) then nil else var37
if var33 == nil then
	var31:Destroy()
	return
end

local var39 = var35:FindFirstChild("ToiletName")
var37 = if var39 == nil or (not var39:IsA("GuiObject")) then nil else var39
if var37 == nil then
	var31:Destroy()
	return
end

local var41 = var35:FindFirstChild("CanvasGroup")
var39 = if var41 == nil or (not var41:IsA("CanvasGroup")) then nil else var41
if var39 == nil then
	var31:Destroy()
	return
end

local var43 = var33:FindFirstChild("Hp")
var41 = if var43 == nil or (not var43:IsA("TextLabel")) then nil else var43
if var41 == nil then
	var31:Destroy()
	return
end

local var45 = var37:FindFirstChild("ToiletName")
var43 = if var45 == nil or (not var45:IsA("TextLabel")) then nil else var45
if var43 == nil then
	var31:Destroy()
	return
end

local var47 = var39:FindFirstChild("Frame")
var45 = if var47 == nil or (not var47:IsA("Frame")) then nil else var47
if var45 == nil then
	var31:Destroy()
	return
end

var35.AnchorPoint = Vector2.zero
var35.Visible = false
var39.ClipsDescendants = true
var45.AutomaticSize = Enum.AutomaticSize.None
var47 = Vector2.new(0, var45.AnchorPoint.Y)
var45.AnchorPoint = var47
var47 = UDim2.new(0, 0, var45.Position.Y.Scale, var45.Position.Y.Offset)
var45.Position = var47
local var48 = nil
var47 = var45.Size.Y.Scale
local var49 = var45.Size.Y.Offset
local function formatHealth(arg1)
	arg1 = math.max(0, (math.ceil(arg1)))
	if 1000000000 <= arg1 then
		local var2 = ("%.1f"):format(arg1 / 1000000000)
		if var2:sub(-2) == ".0" then
			var2 = var2:sub(1, -3)
		end

		return var2 .. "B"
	end

	if 1000000 <= arg1 then
		local var4 = ("%.1f"):format(arg1 / 1000000)
		if var4:sub(-2) == ".0" then
			var4 = var4:sub(1, -3)
		end

		return var4 .. "M"
	end

	if 1000 <= arg1 then
		local var6 = ("%.1f"):format(arg1 / 1000)
		if var6:sub(-2) == ".0" then
			var6 = var6:sub(1, -3)
		end

		return var6 .. "k"
	end

	return (tostring(arg1))
end

local function getDisplayName(arg1)
	local var1 = arg1:GetAttribute("DisplayName")
	if typeof(var1) == "string" and var1 ~= "" then
		return var1
	end

	local var4 = arg1:FindFirstChild("Config")
	local var5 = var4:FindFirstChild("DisplayName")
	if var4 ~= nil and (var5 ~= nil and (var5:IsA("StringValue") and var5.Value ~= "")) then
		return var5.Value
	end

	return arg1.Name
end

local tbl1 = {}
local function updateWorldHealth(arg1, arg2, arg3)
	local var1 = arg2.humanoid
	local var2 = math.max(var1.MaxHealth, 0)
	local var4 = math.clamp(var1.Health, 0, var2)
	local var5 = UDim2.new(math.clamp(if 0 < var2 then var4 / var2 else 0, 0, 1), 0, arg2.fillHeightScale, arg2.fillHeightOffset)
	arg2.nameLabel.Text = getDisplayName(arg1)
	arg2.hpLabel.Text = ("%s/%s"):format(formatHealth(var4), (formatHealth(var2)))
	local var7 = arg2.tween
	arg2.tween = nil
	if var7 ~= nil then
		var7:Cancel()
	end

	if not arg3 then
		arg2.healthFill.Size = var5
		return
	end

	var7 = var6:Create(arg2.healthFill, var12, { Size = var5 })
	arg2.tween = var7
	var7.Completed:Once(function(_)
		if arg2.tween == var7 then
			arg2.tween = nil
		end
	end)

	var7:Play()
end

local function removeWorldHealthUi(arg1)
	local var2 = tbl1[arg1]
	if var2 == nil then
		return
	end

	tbl1[arg1] = nil
	local var3 = var2.tween
	var2.tween = nil
	if var3 ~= nil then
		var3:Cancel()
	end

	for k1, v1 in var2.connections, nil do
		v1:Disconnect()
	end

	var2.gui:Destroy()
end

local tbl2 = {}
local bool1 = false
local function attachWorldHealthUi(arg1)
	if tbl1[arg1] == nil then
		local bool1 = true
		if arg1.Parent ~= var3 then
			bool1 = arg1.Parent == var21
		end

		if not bool1 then
			return
		end
	end

	local var4 = arg1:FindFirstChildOfClass("Humanoid")
	local var5 = arg1:FindFirstChild("HumanoidRootPart")
	if var4 == nil or (var5 == nil or (not var5:IsA("BasePart"))) then
		return
	end

	local var7 = var29:Clone()
	if var7 == nil or (not var7:IsA("BillboardGui")) then
		return
	end

	local var13 = findDescendantOfClass(var7, "ToiletName", "TextLabel")
	local var14 = findDescendantOfClass(var7, "Hp", "TextLabel")
	local var15 = findDescendantOfClass(var7, "CanvasGroup", "CanvasGroup")
	if var13 == nil or (var14 == nil or var15 == nil) then
		var7:Destroy()
		return
	end

	local var17 = findDescendantOfClass(var15, "Frame", "Frame")
	if var17 == nil then
		var7:Destroy()
		return
	end

	local var19 = arg1:FindFirstChild("Config")
	local var20
	if var19 == nil then
		var20 = nil
	else
		local var23 = var19:FindFirstChild("BillboardOffset")
		var20 = if var23 == nil or (not var23:IsA("NumberValue")) then nil else var23
	end

	var15.ClipsDescendants = true
	var17.AutomaticSize = Enum.AutomaticSize.None
	var19 = Vector2.new(0, var17.AnchorPoint.Y)
	var17.AnchorPoint = var19
	var19 = UDim2.new(0, 0, var17.Position.Y.Scale, var17.Position.Y.Offset)
	var17.Position = var19
	var17.BackgroundColor3 = Color3.new(1, 1, 1)
	var19 = var17:FindFirstChildOfClass("UIGradient")
	local var25 = nil
	if var19 ~= nil then
		var25 = var19
	else
		var25 = Instance.new("UIGradient")
		var25.Name = "HealthGradient"
		var25.Parent = var17
	end

	local num1 = 1
	local var26 = var11
	var25.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, var10), ColorSequenceKeypoint.new(num1, var26) })
	var25.Rotation = 90
	var7.Name = "HealthUI"
	var7.Adornee = var5
	var7.Enabled = true
	if var20 ~= nil then
		local var28 = var7.ExtentsOffsetWorldSpace
		var7.ExtentsOffsetWorldSpace = Vector3.new(var28.X, var20.Value, var28.Z)
	end

	var7.Parent = var5
	local tbl2 = {
		gui = var7,
		humanoid = var4,
		healthFill = var17,
		hpLabel = var14,
		nameLabel = var13,
		fillHeightScale = var17.Size.Y.Scale,
		fillHeightOffset = var17.Size.Y.Offset,
		tween = nil,
		connections = {},
	}

	tbl1[arg1] = tbl2
	local var30 = tbl2.humanoid
	local var31 = math.max(var30.MaxHealth, 0)
	local var33 = math.clamp(var30.Health, 0, var31)
	var26 = UDim2.new(math.clamp(if 0 < var31 then var33 / var31 else 0, 0, 1), 0, tbl2.fillHeightScale, tbl2.fillHeightOffset)
	tbl2.nameLabel.Text = getDisplayName(arg1)
	tbl2.hpLabel.Text = ("%s/%s"):format(formatHealth(var33), (formatHealth(var31)))
	local var34 = tbl2.tween
	tbl2.tween = nil
	if var34 ~= nil then
		var34:Cancel()
	end

	tbl2.healthFill.Size = var26
	local function fn2()
		if tbl1[arg1] == tbl2 then
			tbl2.nameLabel.Text = getDisplayName(arg1)
		end
	end

	var30 = {
		var4.HealthChanged:Connect(function(_)
			if tbl1[arg1] == tbl2 then
				updateWorldHealth(arg1, tbl2, true)
			end
		end),
		var4:GetPropertyChangedSignal("MaxHealth"):Connect(function()
			if tbl1[arg1] == tbl2 then
				updateWorldHealth(arg1, tbl2, true)
			end
		end),
		var4.AncestryChanged:Connect(function()
			if tbl1[arg1] == tbl2 and (not var4:IsDescendantOf(arg1)) then
				removeWorldHealthUi(arg1)
			end
		end),
		arg1:GetAttributeChangedSignal("DisplayName"):Connect(fn2),
	}

	tbl2.connections = var30
	if var20 ~= nil then
		var26 = function()
			if tbl1[arg1] == tbl2 then
				local var3 = tbl2.gui
				local var4 = var3.ExtentsOffsetWorldSpace
				var3.ExtentsOffsetWorldSpace = Vector3.new(var4.X, var20.Value, var4.Z)
			end
		end

		table.insert(tbl2.connections, var20:GetPropertyChangedSignal("Value"):Connect(var26))
	end
end

local var50 = nil
local function disconnectAll(...)
	local var1 = table.pack(...)
	for i1 = 1, var1.n do
		local var2 = var1[i1]
		if var2 == nil then
			continue
		end

		var2:Disconnect()
	end
end

local function updateHealth(arg1, arg2)
	local var1 = math.max(arg1.MaxHealth, 0)
	local var3 = math.clamp(arg1.Health, 0, var1)
	local var4 = UDim2.new(math.clamp(if 0 < var1 then var3 / var1 else 0, 0, 1), 0, var47, var49)
	var41.Text = ("%s/%s"):format(formatHealth(var3), (formatHealth(var1)))
	local var5 = var48
	var48 = nil
	if var5 ~= nil then
		var5:Cancel()
	end

	if not arg2 then
		var45.Size = var4
		return
	end

	var5 = var6:Create(var45, var12, { Size = var4 })
	var48 = var5
	var5.Completed:Once(function(_)
		if var48 == var5 then
			var48 = nil
		end
	end)

	var5:Play()
end

local tbl3 = {}
local function trackFolder(arg1)
	for k1, v1 in arg1:GetChildren() do
		if not v1:IsA("Model") then
			continue
		end

		if tbl1[v1] ~= nil then
			continue
		end

		if tbl2[v1] then
			continue
		end

	if not bool1 then
			tbl2[v1] = true
			task.spawn(function()
				v1:WaitForChild("Humanoid", 10)
				v1:WaitForChild("HumanoidRootPart", 10)
				tbl2[v1] = nil
				if not bool1 then
					local var2 = v1
					local bool2 = true
					if var2.Parent ~= var3 then
						bool2 = var2.Parent == var21
					end

					if bool2 then
						attachWorldHealthUi(v1)
					end
				end
			end)

		end
	end

	local function fn2(arg1)
		if arg1:IsA("Model") then
			if tbl1[arg1] == nil then
				if not tbl2[arg1] then
					if bool1 then
						return
					end

					tbl2[arg1] = true
					task.spawn(function()
						arg1:WaitForChild("Humanoid", 10)
						arg1:WaitForChild("HumanoidRootPart", 10)
						tbl2[arg1] = nil
						if not bool1 then
							local var2 = arg1
							local bool2 = true
							if var2.Parent ~= var3 then
								bool2 = var2.Parent == var21
							end

							if bool2 then
								attachWorldHealthUi(arg1)
							end
						end
					end)

				end
			end
		end
	end

	table.insert(tbl3, arg1.ChildAdded:Connect(fn2))
	fn2 = function(arg1)
		if arg1:IsA("Model") then
			tbl2[arg1] = nil
			removeWorldHealthUi(arg1)
		end
	end

	table.insert(tbl3, arg1.ChildRemoved:Connect(fn2))
end

trackFolder(var3)
trackFolder(var21)
local function getMobFromTarget(arg1)
	local var1 = arg1
	while var1 ~= nil do
		if var1:IsA("Model") then
			local bool1 = true
			if var1.Parent ~= var3 then
				bool1 = var1.Parent == var21
			end

			if bool1 then
				return var1
			end
		end

		if var1 == workspace then
			break
		end

		var1 = var1.Parent
	end

	return nil
end

local function bindMob(arg1)
	local var2 = arg1:FindFirstChildOfClass("Humanoid")
	if var2 == nil then
		return
	end

	local var4 = var27:Clone()
	if var4 == nil or (not var4:IsA("Highlight")) then
		return
	end

	var4.Name = "ForHover"
	var4.Adornee = arg1
	var4.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	var4.Enabled = true
	var4.FillColor = Color3.fromRGB(144, 203, 255)
	var4.FillTransparency = 0.75
	var4.OutlineColor = Color3.fromRGB(208, 251, 255)
	var4.OutlineTransparency = 0
	var4.Parent = arg1
	local tbl1 = {
		model = arg1,
		humanoid = var2,
		highlight = var4,
		healthChanged = nil,
		maxHealthChanged = nil,
		ancestryChanged = nil,
	}

	var50 = tbl1
	var43.Text = getDisplayName(arg1)
	local var5 = math.max(var2.MaxHealth, 0)
	local var7 = math.clamp(var2.Health, 0, var5)
	local var8 = UDim2.new(math.clamp(if 0 < var5 then var7 / var5 else 0, 0, 1), 0, var47, var49)
	var41.Text = ("%s/%s"):format(formatHealth(var7), (formatHealth(var5)))
	local var9 = var48
	var48 = nil
	if var9 ~= nil then
		var9:Cancel()
	end

	var45.Size = var8
	tbl1.healthChanged = var2.HealthChanged:Connect(function(_)
		if var50 == tbl1 then
			updateHealth(var2, true)
		end
	end)

	tbl1.maxHealthChanged = var2:GetPropertyChangedSignal("MaxHealth"):Connect(function()
		if var50 == tbl1 then
			updateHealth(var2, true)
		end
	end)

	tbl1.ancestryChanged = var2.AncestryChanged:Connect(function()
		if var50 ~= tbl1 then
			return
		end

		if not var2:IsDescendantOf(arg1) then
			local var1 = var50
			var50 = nil
			local var3 = var48
			var48 = nil
			if var3 ~= nil then
				var3:Cancel()
			end

			if var1 ~= nil then
				disconnectAll(var1.healthChanged, var1.maxHealthChanged, var1.ancestryChanged)
				var1.highlight:Destroy()
			end

			var35.Visible = false
		end
	end)

	var35.Visible = true
end

local function updateHoverPosition()
	local var1 = var7:GetMouseLocation()
	if not var31.IgnoreGuiInset then
		var1 = var1 - var8:GetGuiInset()
	end

	local var2 = var35.AbsoluteSize
	local var3 = var1.X + var9.X
	local var4 = var31.AbsoluteSize
	local var5 = var1.Y + var9.Y
	if var4.X < var3 + var2.X then
		var3 = var1.X - var2.X - var9.X
	end

	if var4.Y < var5 + var2.Y then
		var5 = var1.Y - var2.Y - var9.Y
	end

	var35.Position = UDim2.fromOffset(math.clamp(var3, 0, (math.max(0, var4.X - var2.X))), (math.clamp(var5, 0, (math.max(0, var4.Y - var2.Y)))))
end

local var51 = var5.RenderStepped:Connect(function(_)
	local var1 = getMobFromTarget(var13.Target)
	if var1 ~= (if var50 ~= nil then var50.model else nil) then
		local var2 = var50
		var50 = nil
		local var3 = var48
		var48 = nil
		if var3 ~= nil then
			var3:Cancel()
		end

		if var2 ~= nil then
			disconnectAll(var2.healthChanged, var2.maxHealthChanged, var2.ancestryChanged)
			var2.highlight:Destroy()
		end

		var35.Visible = false
		if var1 ~= nil then
			bindMob(var1)
		end
	end

	if var35.Visible then
		updateHoverPosition()
	end
end)

script.Destroying:Once(function()
	bool1 = true
	var51:Disconnect()
	for k1, v1 in tbl3, nil do
		v1:Disconnect()
	end

	local var1 = var50
	var50 = nil
	local var2 = var48
	var48 = nil
	if var2 ~= nil then
		var2:Cancel()
	end

	local var3
	if var1 ~= nil then
		var3 = var1.ancestryChanged
		disconnectAll(var1.healthChanged, var1.maxHealthChanged, var3)
		var1.highlight:Destroy()
	end

	var35.Visible = false
	var1 = {}
	for k2 in tbl1, nil do
		table.insert(var1, k2)
	end

	for k3, v2 in var1, nil do
		removeWorldHealthUi(v2)
	end

	var31:Destroy()
end)

--- Players.LocalPlayer.PlayerScripts.TowerHoverInfo [LocalScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = game:GetService("ReplicatedStorage")
local var3 = var2:WaitForChild("Modules")
local var4 = var3:FindFirstChild("TowerConfig")
local str1 = "TowerAmmo"
local var5 = require(var3:WaitForChild(str1))
local var6 = var2:WaitForChild("Visual")
local var7 = game:GetService("RunService")
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("TweenService")
local var10 = var1:WaitForChild("PlayerGui")
local var11 = require(var4 or var3:WaitForChild("TowerUnitConfig"))
local var12 = workspace:WaitForChild("Towers")
str1 = var6:FindFirstChild("AuraColors")
local var13 = var2:WaitForChild("UI")
local var14 = Color3.fromRGB(150, 150, 165)
local var15 = var13:WaitForChild("InfoGui")
local var16 = workspace.CurrentCamera
local tbl1 = { "ForHover", "Cursor", "Hover" }
local tbl2 = { ["Camera Man"] = true }
local tbl3 = { "unitname", "name" }
local tbl4 = { "unitlvl", "unitlevel", "level", "lvl" }
local tbl5 = { "unitrarity", "rarity" }
local tbl6 = { "icon" }
local tbl7 = { "bg", "iconframe", "background" }
local tbl8 = { "hasbullet", "ammo", "bullets" }
local tbl9 = { "amount", "value", "count" }
if not var15:IsA("BillboardGui") then
	error("[TowerHoverInfo] ReplicatedStorage.UI.InfoGui \208\180\208\190\208\187\208\182\208\181\208\189 \208\177\209\139\209\130\209\140 BillboardGui")
end

local function findByNames(arg1, arg2, arg3)
	if not arg1 then
		return nil
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		local var1
		if not arg3 or (not v1:IsDescendantOf(arg3)) then
			local var2 = string.lower(v1.Name)
			for k2, v2 in ipairs(arg2) do
				if var2 ~= v2 then
					continue
				end

				return v1
			end
		end
	end

	return nil
end

local function buildHighlightTemplate()
	local var1 = Instance.new("Highlight")
	var1.Name = "Cursor"
	var1.DepthMode = Enum.HighlightDepthMode.Occluded
	var1.FillColor = Color3.fromRGB(255, 255, 255)
	var1.FillTransparency = 0.8
	var1.OutlineColor = Color3.fromRGB(255, 255, 255)
	var1.OutlineTransparency = 0
	var1.Enabled = true
	return var1
end

local var17 = nil
local var18 = (function()
	local var1 = var6:FindFirstChild("HighLights")
	for k1, v1 in ipairs(tbl1) do
		local var2 = var1 and var1:FindFirstChild(v1) or var6:FindFirstChild(v1)
		if not var2 then
			continue
		end

		if not var2:IsA("Highlight") then
			continue
		end

		return var2
	end

	return (buildHighlightTemplate())
end)()

local var19 = RaycastParams.new()
var19.FilterType = Enum.RaycastFilterType.Include
var19.FilterDescendantsInstances = { var12 }
var19.IgnoreWater = true
var19.RespectCanCollide = false
local function getTowerFromInstance(arg1)
	local var1 = arg1
	while not var1 and var1 == var12 and var1.Parent == var12 and var1:IsA("Model") do
	end

	return nil
end

local function isPointerOverUI(arg1)
	local success, result = pcall(function()
		local var1 = arg1.X
		local var2 = arg1.Y
		return var10:GetGuiObjectsAtPosition(var1, var2)
	end)

	if not success or typeof(result) ~= "table" then
		return false
	end

	for k1, v1 in ipairs(result) do
		if not v1:IsA("GuiButton") then
			continue
		end

		if not v1.Visible then
			continue
		end

		if not v1.Active then
			continue
		end

		return true
	end

	return false
end

local var20 = nil
local function nearestTowerOnScreen(arg1, arg2, arg3)
	local var1 = nil
	local var2 = arg2
	local var3
	if arg3 then
		var3 = { arg3 }
	else
		var3 = var12:GetChildren()
	end

	for k1, v1 in ipairs(var3) do
		if not v1:IsA("Model") then
			continue
		end

		if v1.Parent ~= var12 then
			continue
		end

		local var4
		if not v1 or (not v1:IsA("Model")) then
			var4 = false
		else
			local success, result = pcall(var11.getUnitId, v1)
			if success and (type(result) == "string" and tbl2[result]) then
				var4 = true
			else
				var4 = tbl2[v1.Name] == true
			end
		end

		if not var4 then
			continue
		end

		local var6 = v1:FindFirstChild("HumanoidRootPart")
		if var6 and var6:IsA("BasePart") then
			var4 = var6
		else
			var4 = if v1.PrimaryPart then v1.PrimaryPart else v1:FindFirstChildWhichIsA("BasePart")
		end

		if not var4 then
			continue
		end

		local success, result = pcall(function()
			return v1:GetExtentsSize()
		end)

		local var7 = var4.Position
		if success then
			if typeof(result) == "Vector3" then
				var7 = Vector3.new(var7.X, v1:GetPivot().Position.Y + result.Y * 0.35, var7.Z)
			end
		end

		local var8, var9 = var16:WorldToViewportPoint(var7)
		if not var9 then
			continue
		end

		if 0 >= var8.Z then
			continue
		end

		if var8.Z > 400 then
			continue
		end

		local var10 = (Vector2.new(var8.X, var8.Y) - arg1).Magnitude
		if var10 >= var2 then
			continue
		end

		var1 = v1
		local var13 = var10
	end

	return var1
end

local var21 = nil
local num1 = -1
local var22 = var15.StudsOffsetWorldSpace
local function clearStaleGui(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "InfoGui" then
			continue
		end

		if not v1:IsA("BillboardGui") then
			continue
		end

		v1:Destroy()
	end
end

local function computeOffsetY(arg1, arg2)
	local success, result = pcall(function()
		return arg1:GetExtentsSize()
	end)

	local var1 = nil
	return (math.max((if success and typeof(result) == "Vector3" then arg1:GetPivot().Position.Y + result.Y * 0.5 else arg2.Position.Y + 3) - arg2.Position.Y + 0.6, var22.Y))
end

local function bindGui(arg1)
	local var1 = findByNames(arg1, tbl8)
	local var2 = findByNames(arg1, tbl5)
	local var3 = findByNames(var1, tbl9)
	local var4 = findByNames(arg1, tbl3, var1)
	local var5 = findByNames(arg1, tbl4, var1)
	local var6 = findByNames
	local var7 = var2 or arg1
	local var8 = tbl6
	var6 = var6(var7, var8, if var2 then nil else var1)
	var7 = findByNames
	var8 = var2 or arg1
	local var9 = tbl7
	var7 = var7(var8, var9, if var2 then nil else var1)
	var8 = arg1:FindFirstChildWhichIsA("UIScale", true)
	var9 = if var8 and var8:IsA("UIScale") then var8 else nil
	local var10 = if var4 and var4:IsA("TextLabel") then var4 else nil
	local tbl2 = {
		gui = arg1,
		scale = var9,
		targetScale = if var9 then var9.Scale else 1,
		nameLabel = var10,
	}

	if var5 and var5:IsA("TextLabel") then
		var10 = var5
	else
		var10 = nil
	end

	tbl2.levelLabel = var10
	var10 = if var6 and var6:IsA("ImageLabel") then var6 else nil
	tbl2.icon = var10
	var10 = if var7 and var7:IsA("GuiObject") then var7 else nil
	tbl2.rarityBackground = var10
	var10 = if var1 and var1:IsA("GuiObject") then var1 else nil
	tbl2.ammoFrame = var10
	var10 = if var3 and var3:IsA("TextLabel") then var3 else nil
	tbl2.ammoLabel = var10
	return tbl2
end

local num2 = 0
local function findHoveredTower()
	local var1 = var8:GetMouseLocation()
	local var2 = Vector2.new(var1.X, var1.Y)
	if isPointerOverUI(var2) then
		return nil
	end

	local var3 = var16:ScreenPointToRay(var2.X, var2.Y)
	local var5 = workspace:Raycast(var3.Origin, var3.Direction * 1000, var19)
	var1 = if not var5 then nil else getTowerFromInstance(var5.Instance)
	if var1 then
		if not var1 or (not var1:IsA("Model")) then
			var3 = false
		else
			local success, result = pcall(var11.getUnitId, var1)
			if success and (type(result) == "string" and tbl2[result]) then
				var3 = true
			else
				var3 = tbl2[var1.Name] == true
			end
		end

		if var3 then
			return var1
		end
	end

	var3 = nearestTowerOnScreen(var2, 70, var20)
	if var20 and (var20.Parent == var12 and var3) then
		return var3
	end

	return (nearestTowerOnScreen(var2, 40))
end

local function attachTo(arg1)
	local var2 = arg1:FindFirstChild("HumanoidRootPart")
	local var3
	if var2 and var2:IsA("BasePart") then
		var3 = var2
	else
		var3 = if arg1.PrimaryPart then arg1.PrimaryPart else arg1:FindFirstChildWhichIsA("BasePart")
	end

	if not var3 then
		return false
	end

	if var21 then
		var21.gui:Destroy()
		var21 = nil
	end

	clearStaleGui(var3)
	var2 = var15:Clone()
	var2.Name = "InfoGui"
	var2.Adornee = var3
	var2.Enabled = true
	var2.ResetOnSpawn = false
	var2.StudsOffsetWorldSpace = Vector3.new(var22.X, computeOffsetY(arg1, var3), var22.Z)
	var2.Parent = var3
	local var4 = bindGui(var2)
	var21 = var4
	if var4.scale then
		local var5 = var4.scale
		var5.Scale = var4.targetScale * 0.75
		local var6 = TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		var9:Create(var5, var6, { Scale = var4.targetScale }):Play()
	end

	return true
end

local function refreshStatic(arg1)
	local var2 = var21
	if not var2 then
		return
	end

	local var3 = var11.getUnitId(arg1)
	local var4 = var11.getLevel(arg1)
	local var6 = var11.getMaxLevel(var3)
	num1 = var4
	local var7 = var11.getStats(arg1.Name, arg1)
	if var2.nameLabel then
		var2.nameLabel.Text = var3
	end

	if var2.levelLabel then
		local var8 = var2.levelLabel
		local var9 = if 0 < var6 and var6 <= var4 then string.format("Lv. %d ( MAX )", var4) else string.format("Lv. %d", var4)
		var8.Text = var9
	end

	if var2.icon then
		var2.icon.Image = var7.Icon or ""
	end

	if var2.rarityBackground then
		local var10 = var7.Rarity
		local var12 = var2.rarityBackground
		local var13
		if not str1 or typeof(var10) ~= "string" then
			var13 = var14
		else
			local var16 = str1:FindFirstChild(var10)
			var13 = if var16 and var16:IsA("Color3Value") then var16.Value else var14
		end

		var12.BackgroundColor3 = var13
	end

	if var2.ammoFrame then
		var2.ammoFrame.Visible = var5.isEnabled(arg1)
	end
end

var7.RenderStepped:Connect(function(arg1)
	local var1 = num2 + arg1
	num2 = var1
	if num2 < 0.033333333333333333 then
		return
	end

	num2 = 0
	if var8.TouchEnabled then
		if not var8.MouseEnabled then
			if var20 then
				var20 = nil
				num1 = -1
				if var21 then
					var21.gui:Destroy()
					var21 = nil
				end

				if var17 then
					var17:Destroy()
					var17 = nil
				end
			end

			return
		end
	end

	var1 = findHoveredTower()
	if var1 then
		if var1.Parent ~= var12 then
			if var20 then
				var20 = nil
				num1 = -1
				if var21 then
					var21.gui:Destroy()
					var21 = nil
				end

				if var17 then
					var17:Destroy()
					var17 = nil
				end
			end

			return
		end
	end

	if var1 ~= var20 then
		var20 = var1
		if not attachTo(var1) then
			var20 = nil
			num1 = -1
			if var21 then
				var21.gui:Destroy()
				var21 = nil
			end

			if var17 then
				var17:Destroy()
				var17 = nil
			end

			return
		end

		if var17 then
			var17:Destroy()
			var17 = nil
		end

		local var2 = var18:Clone()
		var2.Name = "Cursor"
		var2.Adornee = var1
		var2.Enabled = true
		var2.Parent = var1
		var17 = var2
		refreshStatic(var1)
	else
		if var21 then
			if not var21.gui.Parent then
				if not attachTo(var1) then
					var20 = nil
					num1 = -1
					if var21 then
						var21.gui:Destroy()
						var21 = nil
					end

					if var17 then
						var17:Destroy()
						var17 = nil
					end

					return
				end

				refreshStatic(var1)
			else
				if var11.getLevel(var1) ~= num1 then
					refreshStatic(var1)
				end
			end
		end
	end

	local var4 = var21
	if var4 then
		if var4.ammoFrame then
			if not var4.ammoFrame.Visible then
				return
			end

			if var4.ammoLabel then
				var4.ammoLabel.Text = var5.format(var1)
			end
		end
	end
end)

var12.ChildRemoved:Connect(function(arg1)
	if arg1 == var20 then
		var20 = nil
		num1 = -1
		if var21 then
			var21.gui:Destroy()
			var21 = nil
		end

		if var17 then
			var17:Destroy()
			var17 = nil
		end
	end
end)

var1.CharacterAdded:Connect(function()
	var20 = nil
	num1 = -1
	if var21 then
		var21.gui:Destroy()
		var21 = nil
	end

	if var17 then
		var17:Destroy()
		var17 = nil
	end
end)

--- Players.LocalPlayer.PlayerScripts.GameSpeedController [LocalScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = var1.LocalPlayer
local var3 = var2:WaitForChild("PlayerGui")
local var4 = var3:WaitForChild("MainGameUI")
local var5 = var4:WaitForChild("DownSide"):WaitForChild("GameSpeed")
local var6 = var5:WaitForChild("VisibleFrame")
local var7 = var6:WaitForChild("LINE")
local var8 = var7:WaitForChild("GrowFrame")
local var9 = game:GetService("ReplicatedStorage")
local var10 = var9:WaitForChild("RemoteEvents")
local var11 = game:GetService("MarketplaceService")
local var12 = game:GetService("TweenService")
local var13 = game:GetService("UserInputService")
local var14 = var8:WaitForChild("GrowFrame")
local var15 = var8:WaitForChild("Trigger")
local var16 = var6:WaitForChild("Amount")
local var17 = var9:WaitForChild("RemoteFunctions"):WaitForChild("GetGameSpeedState")
local var18 = var10:WaitForChild("SetGameSpeed")
local var19 = var10:WaitForChild("GameSpeedChanged")
local var20 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var21 = Color3.fromRGB(255, 60, 60)
local num1 = 0
local function getNotifyFrame()
	local var1 = var3:FindFirstChild("ForNotify")
	var1 = var1 or var3:WaitForChild("ForNotify", 3)
	if not var1 or (not var1:IsA("ScreenGui")) then
		return nil
	end

	local var4 = var1:FindFirstChild("Frame")
	if var4 and var4:IsA("GuiObject") then
		return var4
	end

	return nil
end

local function getNotifyTemplate(arg1)
	local var2 = arg1:FindFirstChild("Template")
	if var2 and var2:IsA("TextLabel") then
		return var2
	end

	local var3 = var4:FindFirstChild("TowerController")
	local var5 = var3
	var2 = var5 and var3:FindFirstChild("Template")
	if var2 and var2:IsA("TextLabel") then
		return var2
	end

	var5 = Instance.new("TextLabel")
	var5.Name = "Template"
	var5.Size = UDim2.new(0.94, 0, 0, 54)
	var5.BackgroundTransparency = 1
	var5.BorderSizePixel = 0
	var5.Font = Enum.Font.FredokaOne
	var5.Text = "Notification"
	var5.TextColor3 = Color3.new(1, 1, 1)
	var5.TextStrokeColor3 = Color3.new(0, 0, 0)
	var5.TextStrokeTransparency = 0
	var5.TextScaled = true
	var5.Visible = false
	var5.ZIndex = 101
	var5.Parent = arg1
	return var5
end

local tbl1 = {
	Speed = 1,
	MaxSpeed = 1,
	InGroup = false,
	HasPass = false,
	GroupId = 0,
	GamePassId = 0,
	Options = { 1, 1.5, 2 },
}

local function render()
	local var1 = tbl1.Options
	local var4 = var1[#var1]
	local var5 = var1[1]
	local var6 = tbl1.Speed
	var1 = var15.AbsoluteSize.X
	local var7 = if var4 <= var5 then 0 else (var6 - var5) / (var4 - var5)
	var6 = if var1 <= 0 then 0 else (0.5 - var7) * var1
	var12:Create(var14, var20, { Size = UDim2.new(var7, var6, var14.Size.Y.Scale, var14.Size.Y.Offset) }):Play()
	var12:Create(var15, var20, { Position = UDim2.new(var7, var6, var15.Position.Y.Scale, var15.Position.Y.Offset) }):Play()
	var4 = tbl1.Speed
	var1 = var16
	local var9 = nil
	var9 = if var4 % 1 == 0 then ("x%d Speed"):format(var4) else ("x%.1f Speed"):format(var4)
	if var13.KeyboardEnabled then
		var9 = var9 .. " [ Z ]"
	end

	var1.Text = var9
end

local function applyState(arg1)
	if type(arg1) ~= "table" then
		return
	end

	local var1 = tonumber(arg1.Speed)
	tbl1.Speed = var1 or tbl1.Speed
	var1 = tonumber(arg1.MaxSpeed)
	tbl1.MaxSpeed = var1 or tbl1.MaxSpeed
	tbl1.InGroup = arg1.InGroup == true
	tbl1.HasPass = arg1.HasPass == true
	var1 = tonumber(arg1.GroupId)
	tbl1.GroupId = var1 or tbl1.GroupId
	var1 = tonumber(arg1.GamePassId)
	tbl1.GamePassId = var1 or tbl1.GamePassId
	if type(arg1.Options) == "table" and 0 < (#arg1.Options) then
		tbl1.Options = arg1.Options
	end

	render()
end

local function notify(arg1, arg2)
	if os.clock() - num1 < 1.5 then
		return
	end

	num1 = os.clock()
	local var2 = getNotifyFrame()
	if not var2 then
		return
	end

	local var3 = getNotifyTemplate(var2):Clone()
	var3.Name = "GameSpeedNotify"
	var3.Text = arg1
	var3.Visible = true
	var3.Parent = var2
	local var4 = var3:FindFirstChild("UIShadow")
	var4 = var4 or var3:FindFirstChildOfClass("UIStroke")
	if var4 then
		pcall(function()
			var4.Color = arg2
		end)

	end

	local var5 = var3.Size.X.Scale
	local var6 = var3.Size.X.Offset
	local var7 = var3.Size.Y.Offset
	local var8 = var3.Size
	var3.Size = UDim2.new(var5, var6, 0, 0)
	local var9 = TweenInfo.new(0.2)
	var12:Create(var3, var9, { Size = var8 }):Play()
	task.delay(3, function()
		if not var3.Parent then
			return
		end

		local var1 = TweenInfo.new(0.25)
		local var2 = var12:Create(var3, var1, { Size = UDim2.new(var5, var6, 0, 0) })
		var2.Completed:Connect(function()
			var3:Destroy()
		end)

		var2:Play()
	end)
end

local function nearestOption(arg1)
	local var1 = tbl1.Options
	local var2 = var1[1]
	local var3 = var2 + math.clamp(arg1, 0, 1) * (var1[#var1] - var2)
	local var4 = var1[1]
	local num1 = math.huge
	for k1, v1 in ipairs(var1) do
		local var5 = math.abs(v1 - var3)
		if var5 >= num1 then
			continue
		end

		var4 = v1
		local var6 = var5
	end

	return var4
end

local function promptUnlock(arg1)
	if 1 < arg1 and (not tbl1.InGroup) then
		notify("Join the group to unlock x1.5 Speed", var21)
		if 0 < tbl1.GroupId then
			pcall(function()
				local var1 = tbl1.GroupId
				game:GetService("GuiService"):OpenBrowserWindow(("https://www.roblox.com/groups/%d"):format(var1))
			end)

		end

		return
	end

	if 1.5 < arg1 and (not tbl1.HasPass and 0 < tbl1.GamePassId) then
		notify("Buy the x2 Speed gamepass", var21)
		pcall(function()
			var11:PromptGamePassPurchase(var2, tbl1.GamePassId)
		end)

	end
end

local var22 = Enum.KeyCode.Z
local function cycleSpeed()
	local var1 = tbl1.Options
	if type(var1) ~= "table" or #var1 == 0 then
		return
	end

	local tbl2 = {}
	local var2 = nil
	for k1, v1 in ipairs(var1) do
		local var4 = tbl1.MaxSpeed + 0.001
		if v1 <= var4 then
			table.insert(tbl2, v1)
		elseif var2 == nil then
			var2 = v1
		end
	end

	if #tbl2 <= 1 then
		if var2 then
			promptUnlock(var2)
		end

		return
	end

	local num1 = 1
	for k2, v2 in ipairs(tbl2) do
		if math.abs(v2 - tbl1.Speed) >= 0.001 then
			continue
		end

		num1 = k2
		break
	end

	local var5 = tbl2[num1 % #tbl2 + 1]
	if math.abs(var5 - tbl1.Speed) < 0.001 then
		return
	end

	tbl1.Speed = var5
	render()
	var18:FireServer(var5)
end

var13.InputBegan:Connect(function(arg1, arg2)
	if arg2 or (not var13.KeyboardEnabled) then
		return
	end

	if arg1.UserInputType ~= Enum.UserInputType.Keyboard or arg1.KeyCode ~= var22 then
		return
	end

	if not var5.Visible or (not var6.Visible) then
		return
	end

	cycleSpeed()
end)

var13.LastInputTypeChanged:Connect(function()
	local var1 = tbl1.Speed
	local var3 = var16
	local var4 = nil
	var4 = if var1 % 1 == 0 then ("x%d Speed"):format(var1) else ("x%.1f Speed"):format(var1)
	if var13.KeyboardEnabled then
		var4 = var4 .. " [ Z ]"
	end

	var3.Text = var4
end)

local var24 = var7:FindFirstChild("TrackButton")
local bool1 = false
local function requestState()
	local success, result = pcall(function()
		return var17:InvokeServer()
	end)

	if success then
		applyState(result)
	end
end

local function updateFromInput(arg1)
	local var1 = var15.AbsoluteSize.X
	local var3 = nearestOption((math.clamp((arg1 - (var7.AbsolutePosition.X + var1 / 2)) / math.max(var7.AbsoluteSize.X - var1, 1), 0, 1)))
	if tbl1.MaxSpeed + 0.001 < var3 then
		promptUnlock(var3)
		render()
		return
	end

	if math.abs(var3 - tbl1.Speed) < 0.001 then
		render()
		return
	end

	tbl1.Speed = var3
	render()
	var18:FireServer(var3)
end

if not var24 then
	local var25 = Instance.new("TextButton")
	var25.Name = "TrackButton"
	var25.Text = ""
	var25.BackgroundTransparency = 1
	var25.AutoButtonColor = false
	var25.AnchorPoint = Vector2.new(0.5, 0.5)
	var25.Position = UDim2.fromScale(0.5, 0.5)
	var25.Size = UDim2.fromScale(1, 2)
	var25.ZIndex = var7.ZIndex + 5
	var25.Parent = var7
	var24 = var25
end

local function beginDrag(arg1)
	local bool2 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool2 = arg1.UserInputType == Enum.UserInputType.Touch
	end

	if not bool2 or (not var6.Visible) then
		return
	end

	bool1 = true
	updateFromInput(arg1.Position.X)
end

var15.InputBegan:Connect(beginDrag)
var24.InputBegan:Connect(beginDrag)
var13.InputChanged:Connect(function(arg1)
	if not bool1 then
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement or arg1.UserInputType == Enum.UserInputType.Touch then
		updateFromInput(arg1.Position.X)
	end
end)

var13.InputEnded:Connect(function(arg1)
	local bool2 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool2 = arg1.UserInputType == Enum.UserInputType.Touch
	end

	if bool2 then
		bool1 = false
	end
end)

var19.OnClientEvent:Connect(applyState)
var11.PromptGamePassPurchaseFinished:Connect(function(arg1, arg2, arg3)
	if arg1 ~= var2 or (arg2 ~= tbl1.GamePassId or (not arg3)) then
		return
	end

	task.delay(1, requestState)
end)

local function refreshVisibility()
	local var2 = 4 <= (#var1:GetPlayers())
	var6.Visible = not var2
	if var2 then
		bool1 = false
	end
end

var1.PlayerAdded:Connect(refreshVisibility)
var1.PlayerRemoving:Connect(function()
	task.defer(refreshVisibility)
end)

var7:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
	if not bool1 then
		render()
	end
end)

var15:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
	if not bool1 then
		render()
	end
end)

local var26 = 4 <= (#var1:GetPlayers())
var6.Visible = not var26
if var26 then
end

render()
task.defer(render)
task.spawn(requestState)

--- Players.LocalPlayer.PlayerScripts.TowerMuzzleEffect [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "TowerMuzzleConfig"
local var2 = require(var1:WaitForChild("Modules"):WaitForChild(str1))
str1 = setmetatable({}, { __mode = "k" })
local var3 = game:GetService("Debris")
local function getEmitCount(arg1, arg2)
	local var1 = arg1:GetAttribute("EmitCount")
	if typeof(var1) == "number" and var1 == var1 then
		return (math.max(0, (math.floor(var1))))
	end

	local var2 = arg2.EmitCounts
	local var3 = var2[arg1.Name]
	if typeof(var2) == "table" and (typeof(var3) == "number" and var3 == var3) then
		return (math.max(0, (math.floor(var3))))
	end

	local var4 = arg1.Rate
	var3 = tonumber(arg2.BurstTime) or 0.2
	local var5 = tonumber(arg2.MinEmit) or 3
	local var6 = tonumber(arg2.MaxEmit) or 40
	if typeof(var4) ~= "number" or (var4 ~= var4 or var4 <= 0) then
		return (math.floor(var5))
	end

	return (math.clamp(math.floor(var4 * var3 + 0.5), math.floor(var5), (math.floor(var6))))
end

local function flashLight(arg1, arg2)
	local var1 = arg2.Light
	if typeof(var1) ~= "table" then
		return
	end

	local var4 = arg1:FindFirstChild("MuzzleFlashLight")
	if var4 then
		var4:Destroy()
	end

	local var5 = Instance.new("PointLight")
	var5.Name = "MuzzleFlashLight"
	local var6 = var1.Color
	var6 = var6 or Color3.fromRGB(255, 214, 138)
	var5.Color = var6
	var5.Brightness = tonumber(var1.Brightness) or 6
	var5.Range = tonumber(var1.Range) or 14
	var5.Shadows = false
	var5.Parent = arg1
	var3:AddItem(var5, (math.max(0.01, tonumber(var1.Duration) or 0.07)))
end

local var4 = setmetatable({}, { __mode = "k" })
local function findAttachments(arg1, arg2)
	local var2 = str1[arg1]
	local var3
	if var2 then
		local var4 = 0 < (#var2)
		for k1, v1 in ipairs(var2) do
			if v1:IsDescendantOf(arg1) then
				continue
			end

			var4 = false
			break
		end

		if var4 then
			return var2
		end
	end

	var4 = {}
	for k2, v2 in ipairs(arg2.Sources) do
		if typeof(v2) ~= "table" then
			continue
		end

		if typeof(v2.PartName) ~= "string" then
			continue
		end

		local var5 = v2.PartName
		local var6 = if typeof(v2.AttachmentName) == "string" and v2.AttachmentName ~= "" then v2.AttachmentName else "Attachment"
		var4[var5] = var6
	end

	local tbl1 = {}
	for k3, v3 in ipairs(arg1:GetDescendants()) do
		if not v3:IsA("BasePart") then
			continue
		end

		local var7 = var4[v3.Name]
		if not var7 then
			continue
		end

		local var8 = v3:FindFirstChild(var7)
		if not var8 then
			continue
		end

		if not var8:IsA("Attachment") then
			continue
		end

		table.insert(tbl1, var8)
	end

	str1[arg1] = tbl1
	return tbl1
end

local function emitFrom(arg1, arg2)
	local var2
	local var1 = arg2.Skip
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		if typeof(var1) == "table" then
			local bool1 = true
			if var1[v1.Name] ~= true then
				bool1 = v1:GetAttribute("MuzzleSkip") == true
			end
		end

		if var2 then
			continue
		end

		local var3 = getEmitCount(v1, arg2)
		if 0 >= var3 then
			continue
		end

		v1:Emit(var3)
	end

	flashLight(arg1, arg2)
end

local function playMuzzle(arg1, arg2)
	if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or (not arg1.Parent)) then
		return
	end

	local var1 = arg1:GetAttribute("UnitId")
	local var3 = var2.get
	var3 = var3(if typeof(var1) == "string" and var1 ~= "" then var1 else arg1.Name)
	if not var3 or (not var2.handlesState(var3, arg2)) then
		return
	end

	local var5 = os.clock()
	if var5 - (var4[arg1] or 0) < (tonumber(var3.Cooldown) or 0.05) then
		return
	end

	var4[arg1] = var5
	local var6 = arg1
	for k1, v1 in ipairs((findAttachments(var6, var3))) do
		emitFrom(v1, var3)
	end
end

var1:WaitForChild("RemoteEvents"):WaitForChild("AnimateTower").OnClientEvent:Connect(function(arg1, arg2)
	pcall(playMuzzle, arg1, arg2)
end)

--- Players.LocalPlayer.PlayerScripts.TowerAimState [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules")
local str1 = "TowerAnimator"
local str2 = "TowerAnimationConfig"
local var2 = require(var1:WaitForChild(str2))
local var3 = require(var1:WaitForChild(str1))
str1 = setmetatable({}, { __mode = "k" })
local function apply(arg1)
	if arg1.Parent then
		local var1 = arg1:GetAttribute("UnitId")
		local var4 = var2.isHold
		if not var4(if typeof(var1) == "string" and var1 ~= "" then var1 else arg1.Name, "Charge") then
			return
		end
	end

	if arg1:GetAttribute("Aiming") == true then
		var3.play(arg1, "Charge")
		return
	end

	local var5 = arg1:GetAttribute("UnitId")
	local var6 = var2.hasState
	if var6(if typeof(var5) == "string" and var5 ~= "" then var5 else arg1.Name, "Lower") then
		return
	end

	var3.play(arg1, "Idle")
end

local var4 = workspace:WaitForChild("Towers")
local function untrack(arg1)
	local var2 = str1[arg1]
	if var2 then
		var2:Disconnect()
		str1[arg1] = nil
	end
end

local function track(arg1)
	if not arg1:IsA("Model") or str1[arg1] then
		return
	end

	str1[arg1] = arg1:GetAttributeChangedSignal("Aiming"):Connect(function()
		apply(arg1)
	end)

	if arg1:GetAttribute("Aiming") == true then
		apply(arg1)
	end
end

for k1, v1 in ipairs(var4:GetChildren()) do
	track(v1)
end

var4.ChildAdded:Connect(track)
var4.ChildRemoved:Connect(untrack)
task.spawn(function()
	while true do
		task.wait(0.25)
		for k1, v1 in ipairs(var4:GetChildren()) do
			if not v1:IsA("Model") then
				continue
			end

			if v1:GetAttribute("Aiming") ~= true then
				continue
			end

			apply(v1)
		end
	end
end)

--- Players.LocalPlayer.PlayerScripts.PresentGiftEffects [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "PresentGiftConfig"
local var2 = require(var1:WaitForChild("Modules"):WaitForChild(str1))
local var3 = game:GetService("TweenService")
local var4 = game:GetService("Debris")
local var5 = var1:WaitForChild("Things")
str1 = function(arg1, arg2, arg3)
	local var1 = Instance.new("Part")
	var1.Name = "PresentGiftPulse"
	var1.Shape = Enum.PartType.Ball
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanTouch = false
	var1.CanQuery = false
	var1.Material = Enum.Material.Neon
	var1.Color = arg3
	var1.Transparency = 0.6
	var1.Size = Vector3.new(1, 1, 1)
	var1.CFrame = CFrame.new(arg1.Position)
	var1.Parent = workspace
	local var2 = TweenInfo.new(0.45)
	var3:Create(var1, var2, { Size = Vector3.new(1, 1, 1) * arg2 * 2, Transparency = 1 }):Play()
	var4:AddItem(var1, 0.6)
end

local var6 = game:GetService("RunService")
var1:WaitForChild("RemoteEvents"):WaitForChild("PresentGiftEffect").OnClientEvent:Connect(function(arg1, arg2, arg3)
	if typeof(arg2) ~= "CFrame" or (type(arg3) ~= "number" or (not var2.Models[arg1])) then
		return
	end

	local var3 = var5:FindFirstChild(var2.Models[arg1])
	if not var3 then
		return
	end

	local var7 = var3:Clone()
	var7.Name = "Gift"
	var7:SetAttribute("DisplayName", "Gift")
	var7:ScaleTo(var3:GetScale() * math.clamp(tonumber(var2.GiftScale) or 0.4, 0.05, 1))
	local tbl1 = {}
	local var8 = var2.EffectSeconds
	for k1, v1 in ipairs(var7:GetDescendants()) do
		if v1:IsA("BasePart") then
			v1.Anchored = true
			v1.CanCollide = false
			v1.CanTouch = false
			v1.CanQuery = false
			v1.Transparency = 1
		else
			if v1:IsA("Decal") or v1:IsA("Texture") then
				v1.Transparency = 1
			else
				if v1:IsA("ParticleEmitter") then
					v1.Enabled = false
					table.insert(tbl1, v1)
					local str2 = "EmitDelay"
					local var9 = math.clamp(tonumber(v1:GetAttribute(str2)) or 0, 0, 5)
					var8 = math.max(var8, v1.Lifetime.Max + var9 + 1)
				else
					if v1:IsA("Script") or v1:IsA("LocalScript") then
						v1:Destroy()
					end
				end
			end
		end
	end

	var7:PivotTo(arg2)
	var7.Parent = workspace
	var4:AddItem(var7, var8)
	local var10
	if arg1 == "Confusion" then
		var10 = 165
		local num4 = 80
		local num5 = 255
		str1(arg2, arg3, Color3.fromRGB(var10, num4, num5))
	end

	if arg1 == "Poison" then
		str1(arg2, arg3, var2.PoisonColor)
	end

	var6.Heartbeat:Wait()
	for k2, v2 in ipairs(tbl1) do
		local str3 = "EmitDelay"
		local str4 = "EmitCount"
		local var11 = tonumber(v2:GetAttribute(str4))
		local var12 = math.floor(var11 or var2.DefaultEmitCount)
		local var13 = math.clamp(var12, 0, 200)
		task.delay(math.clamp(tonumber(v2:GetAttribute(str3)) or 0, 0, 5), function()
			if v2.Parent then
				v2:Emit(var13)
			end
		end)

	end
end)

--- Players.LocalPlayer.PlayerScripts.UpgradeTitanEffects [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("RemoteEvents")
local str1 = "TitanCannonConfig"
local var3 = require(var1:WaitForChild("Modules"):WaitForChild(str1))
local var4 = game:GetService("TweenService")
local var5 = game:GetService("Debris")
local var6 = var2:WaitForChild("UpgradedTitanEffect")
local var7 = var2:WaitForChild("TitanCannonEffect")
local tbl1 = {
	PartName = "Object_11.002",
	BurstTime = 0.08,
	MinEmit = 1,
	MaxEmit = 16,
	LightColor = Color3.fromRGB(80, 190, 255),
	LightRange = 12,
}

local tbl2 = { Shot = tbl1 }
tbl1 = {
	PartName = "Cylinder.027",
	BurstTime = 0.15,
	MinEmit = 1,
	MaxEmit = 30,
	LightColor = Color3.fromRGB(100, 200, 255),
	LightRange = 18,
}

tbl2.Hammer = tbl1
str1 = function(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if v1.Name ~= arg2 then
			continue
		end

		return v1
	end

	return nil
end

local function emitCount(arg1, arg2)
	local var1 = arg1:GetAttribute("EmitCount")
	if typeof(var1) == "number" and var1 == var1 then
		return (math.clamp(math.floor(var1), 0, 200))
	end

	local var2 = string.lower(arg1.Name)
	if string.find(var2, "shock", 1, true) or (string.match(var2, "^sw%d") or (var2 == "sphere" or (var2 == "impact" or var2 == "flash"))) then
		return 1
	end

	return (math.clamp(math.floor(arg1.Rate * arg2.BurstTime + 0.5), arg2.MinEmit, arg2.MaxEmit))
end

local function createProjectile(arg1, arg2, arg3)
	local var3 = var1:FindFirstChild("WaveState")
	local var6 = math.max(0.2, tonumber(arg3.Size) or 0.9)
	local var7 = math.clamp((arg2 - arg1).Magnitude / math.max(1, tonumber(arg3.Speed) or 130), 0.08, 1.5)
	if var3 then
		local str2 = "GameSpeed"
		local var8 = tonumber(var3:GetAttribute(str2))
		var8 = var8 or 1
	end

	local var9 = var7 / math.clamp(1 or 1, 0.1, 10)
	var7 = Instance.new("Part")
	var7.Name = "TitanCannonBall"
	var7.Shape = Enum.PartType.Ball
	var7.Size = Vector3.new(1, 1, 1) * var6
	var7.Material = Enum.Material.Neon
	var7.Color = arg3.Color
	var7.Anchored = true
	var7.CanCollide = false
	var7.CanTouch = false
	var7.CanQuery = false
	var7.CastShadow = false
	var7.CFrame = CFrame.new(arg1)
	local var10 = Instance.new("Attachment")
	var10.Position = Vector3.new(0, 0, var6 * 0.35)
	var10.Parent = var7
	var3 = Instance.new("Attachment")
	var3.Position = Vector3.new(0, 0, -var6 * 0.35)
	var3.Parent = var7
	local var11 = Instance.new("Trail")
	var11.Attachment0 = var10
	var11.Attachment1 = var3
	var11.Color = ColorSequence.new(arg3.Color)
	var11.LightEmission = 1
	var11.Lifetime = 0.1
	var11.MinLength = 0.05
	var11.Parent = var7
	local var12 = Instance.new("PointLight")
	var12.Color = arg3.Color
	var12.Brightness = 2
	var12.Range = var6 * 5
	var12.Shadows = false
	var12.Parent = var7
	var7.Parent = workspace
	local var13 = TweenInfo.new(var9, Enum.EasingStyle.Linear)
	local var14 = var4:Create(var7, var13, { Position = arg2, Size = Vector3.new(1, 1, 1) * var6 * 0.7 })
	var14.Completed:Once(function()
		var7:Destroy()
	end)

	var5:AddItem(var7, var9 + 0.5)
	var14:Play()
end

local function setCoreEffects(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("ParticleEmitter") then
			v1.Enabled = arg2
			if not arg2 then
				continue
			end

			v1:Emit((math.max(3, (math.floor(v1.Rate * 0.15 + 0.5)))))
		else
			if not v1:IsA("Beam") then
				continue
			end

			v1.Enabled = false
		end
	end
end

var6.OnClientEvent:Connect(function(arg1, arg2, arg3)
	local var2 = tbl2[arg2]
	if var2 then
		if typeof(arg1) == "Instance" then
			if arg1:IsA("Model") then
				if arg1:IsDescendantOf(workspace) then
					local var3 = arg1:GetAttribute("UnitId")
					if (if typeof(var3) == "string" and var3 ~= "" then var3 else arg1.Name) ~= "Upgraded Titan Camera Man" then
						return
					end
				end
			end
		end
	end

	local var6 = str1(arg1, var2.PartName)
	local var7
	if not var6 then
		var7 = nil
	else
		local var8 = var6:FindFirstChild("Attachment")
		var8 = var8 or var6:FindFirstChildWhichIsA("Attachment", true)
		var7 = if var8 and var8:IsA("Attachment") then var8 else nil
	end

	if not var7 then
		return
	end

	if arg2 == "Hammer" and typeof(arg3) ~= "Vector3" then
		return
	end

	local var9 = var7:Clone()
	var6 = Instance.new("Part")
	var6.Name = "UpgradedTitanEffect"
	var6.Size = Vector3.new(0.1, 0.1, 0.1)
	var6.Transparency = 1
	var6.Anchored = true
	var6.CanCollide = false
	var6.CanTouch = false
	var6.CanQuery = false
	var6.CastShadow = false
	local var10 = if arg2 == "Hammer" then CFrame.new(arg3) else var7.WorldCFrame
	var6.CFrame = var10
	var9.CFrame = CFrame.identity
	var10 = {}
	local num1 = 0.2
	for k1, v1 in ipairs(var9:GetDescendants()) do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		v1.Enabled = false
		if v1:GetAttribute("MuzzleSkip") == true then
			continue
		end

		table.insert(var10, v1)
		num1 = math.max(num1, v1.Lifetime.Max / math.max(v1.TimeScale, 0.01))
	end

	var9.Parent = var6
	var6.Parent = workspace
	var5:AddItem(var6, num1 + 0.25)
	for k2, v2 in ipairs(var10) do
		v2:Emit((emitCount(v2, var2)))
	end

	local var11 = Instance.new("PointLight")
	var11.Color = var2.LightColor
	var11.Range = var2.LightRange
	var11.Brightness = 3
	var11.Shadows = false
	var11.Parent = var9
	var5:AddItem(var11, 0.08)
end)

var7.OnClientEvent:Connect(function(arg1, arg2, arg3)
	if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or (not arg1:IsDescendantOf(workspace) or typeof(arg3) ~= "Vector3")) then
		return
	end

	local var2 = arg1:GetAttribute("UnitId")
	local var4 = var2
	local var5 = var3
	local var7 = var5[if typeof(var4) == "string" and var2 ~= "" then var2 else arg1.Name]
	if not var7 then
		return
	end

	if arg2 == "Guns" then
		local var8 = var7.Guns
		for k1, v1 in ipairs(var8 or {}) do
			local var9 = str1(arg1, v1)
			if not var9 then
				continue
			end

			local var11 = var9:FindFirstChild("Muzzle", true)
			local var12 = createProjectile
			local var13
			if var11 and var11:IsA("Attachment") then
				var13 = var11.WorldPosition
			else
				local var15 = var9:FindFirstChildWhichIsA("Attachment", true)
				var13 = if var15 then var15.WorldPosition else var9.Position
			end

			var12(var13, arg3, var7)
		end

		return
	end

	if arg2 ~= "CoreStart" then
		if not (arg2 == "CoreStop" or arg2 == "Core") then
			return
		end

		if arg2 ~= "Core" then
			return
		end
	end

	if var7.Core then
		var5 = str1(arg1, var7.Core)
		if var5 then
			setCoreEffects(var5, arg2 ~= "CoreStop")
			if arg2 == "Core" then
				local var17 = var1:FindFirstChild("WaveState")
				var2 = math.max(0.05, tonumber(var7.CoreDuration) or 0.16)
				if var17 then
					local str3 = "GameSpeed"
					local var18 = tonumber(var17:GetAttribute(str3))
					var18 = var18 or 1
				end

				local var19 = var2 / math.clamp(1 or 1, 0.1, 10)
				task.delay(var19, function()
					if var5.Parent then
						setCoreEffects(var5, false)
					end
				end)

			end
		end
	end
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local str1 = "CameraModule"
	local var1 = setmetatable({}, tbl1)
	var1.cameras = require(script:WaitForChild(str1))
	str1 = "ControlModule"
	var1.controls = require(script:WaitForChild(str1))
	return var1
end

tbl1.GetCameras = function(arg1)
	return arg1.cameras
end

tbl1.GetControls = function(arg1)
	return arg1.controls
end

tbl1.GetClickToMoveController = function(arg1)
	return arg1.controls:GetClickToMoveController()
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
local var1 = script.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local var3 = require(var1:WaitForChild(str2))
local str4 = "CameraInput"
local var4 = require(script:WaitForChild(str3))
local str5 = "ClassicCamera"
str1 = require(script:WaitForChild(str4))
local str6 = "OrbitalCamera"
str2 = require(script:WaitForChild(str5))
local str7 = "LegacyCamera"
str3 = require(script:WaitForChild(str6))
local str8 = "VehicleCamera"
str4 = require(script:WaitForChild(str7))
local str9 = "VRCamera"
str5 = require(script:WaitForChild(str8))
local str10 = "VRVehicleCamera"
str6 = require(script:WaitForChild(str9))
local str11 = "Invisicam"
str7 = require(script:WaitForChild(str10))
local str12 = "Poppercam"
str8 = require(script:WaitForChild(str11))
local str13 = "TransparencyController"
str9 = require(script:WaitForChild(str12))
local str14 = "MouseLockController"
str10 = require(script:WaitForChild(str13))
local var5 = game:GetService("Players")
str11 = require(script:WaitForChild(str14))
local tbl2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock",
}

local tbl3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode",
}

local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("VRService")
local var9 = UserSettings():GetService("UserGameSettings")
str12 = {}
str13 = {}
if not var5.LocalPlayer then
	return {}
end

assert(var5.LocalPlayer, "Strict typing check")
str14 = var5.LocalPlayer:WaitForChild("PlayerScripts")
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
str14 = var3.getUserFlag("UserPlayerConnectionMemoryLeak")
local var10 = var3.getUserFlag("UserPSFixCameraControllerReset")
tbl1.new = function()
	local tbl4 = { activeTransparencyController = str10.new() }
	local var1 = if str14 then var2.new() else nil
	tbl4.connectionUtil = var1
	local var3 = setmetatable(tbl4, tbl1)
	var3.activeCameraController = nil
	var3.activeOcclusionModule = nil
	var3.activeMouseLockController = nil
	var3.currentComputerCameraMovementMode = nil
	var3.cameraSubjectChangedConn = nil
	var3.cameraTypeChangedConn = nil
	for k1, v1 in pairs(var5:GetPlayers()) do
		var3:OnPlayerAdded(v1)
	end

	var5.PlayerAdded:Connect(function(arg1)
		var3:OnPlayerAdded(arg1)
	end)

	if str14 then
		var5.PlayerRemoving:Connect(function(arg1)
			var3:OnPlayerRemoving(arg1)
		end)

	end

	var3.activeTransparencyController:Enable(true)
	var3.activeMouseLockController = str11.new()
	assert(var3.activeMouseLockController, "Strict typing check")
	tbl4 = var3.activeMouseLockController:GetBindableToggleEvent()
	if tbl4 then
		tbl4:Connect(function()
			var3:OnMouseLockToggled()
		end)

	end

	var3:ActivateCameraController()
	var3:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
	var3:OnCurrentCameraChanged()
	local function fn2(arg1)
		var3:Update(arg1)
	end

	var6:BindToRenderStep("cameraRenderUpdate", Enum.RenderPriority.Camera.Value, fn2)
	for k2, v2 in pairs(tbl2) do
		var5.LocalPlayer:GetPropertyChangedSignal(v2):Connect(function()
			var3:OnLocalPlayerCameraPropertyChanged(v2)
		end)

	end

	for k3, v3 in pairs(tbl3) do
		var9:GetPropertyChangedSignal(v3):Connect(function()
			var3:OnUserGameSettingsPropertyChanged(v3)
		end)

	end

	game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		var3:OnCurrentCameraChanged()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var3:OnPreferredInputChanged()
	end)

	return var3
end

tbl1.GetCameraMovementModeFromSettings = function(_)
	if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		local var2 = Enum.ComputerCameraMovementMode.Classic
		return var4.ConvertCameraModeEnumToStandard(var2)
	end

	local var8 = nil
	local var10 = nil
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevTouchCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.TouchCameraMovementMode)
	else
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevComputerCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.ComputerCameraMovementMode)
	end

	if var8 == Enum.DevComputerCameraMovementMode.UserChoice then
		return var10
	end

	return var8
end

tbl1.ActivateOcclusionModule = function(arg1, arg2)
	local var2 = nil
	if arg2 == Enum.DevCameraOcclusionMode.Zoom then
		var2 = str9
	else
		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			var2 = str8
		else
			warn("CameraScript ActivateOcclusionModule called with unsupported mode")
			return
		end
	end

	arg1.occlusionMode = arg2
	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() == arg2 then
			if not arg1.activeOcclusionModule:GetEnabled() then
				arg1.activeOcclusionModule:Enable(true)
			end

			return
		end
	end

	local var3 = arg1.activeOcclusionModule
	arg1.activeOcclusionModule = str13[var2]
	if not arg1.activeOcclusionModule then
		arg1.activeOcclusionModule = var2.new()
		if arg1.activeOcclusionModule then
			str13[var2] = arg1.activeOcclusionModule
		end
	end

	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() ~= arg2 then
			warn("CameraScript ActivateOcclusionModule mismatch: ", arg1.activeOcclusionModule:GetOcclusionMode(), "~=", arg2)
		end

		if var3 then
			if var3 ~= arg1.activeOcclusionModule then
				var3:Enable(false)
			else
				warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
			end
		end

		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			if var5.LocalPlayer.Character then
				arg1.activeOcclusionModule:CharacterAdded(var5.LocalPlayer.Character, var5.LocalPlayer)
			end
		else
			for k1, v1 in pairs(var5:GetPlayers()) do
				if not v1 then
					continue
				end

				if not v1.Character then
					continue
				end

				arg1.activeOcclusionModule:CharacterAdded(v1.Character, v1)
			end

			arg1.activeOcclusionModule:OnCameraSubjectChanged(game.Workspace.CurrentCamera.CameraSubject)
		end

		arg1.activeOcclusionModule:Enable(true)
	end
end

tbl1.ShouldUseVehicleCamera = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return false
	end

	local var4 = var2.CameraType
	local var5 = var2.CameraSubject
	local bool1 = true
	if var4 ~= Enum.CameraType.Custom then
		bool1 = var4 == Enum.CameraType.Follow
	end

	local var6 = var5 and var5:IsA("VehicleSeat")
	return var6 and (bool1 and arg1.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam)
end

tbl1.ActivateCameraController = function(arg1)
	local var2 = workspace.CurrentCamera.CameraType
	local var3 = arg1:GetCameraMovementModeFromSettings()
	local var4 = nil
	if var2 == Enum.CameraType.Scriptable then
		if arg1.activeCameraController then
			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = nil
		end

		return
	end

	if var2 == Enum.CameraType.Custom then
		var3 = arg1:GetCameraMovementModeFromSettings()
	else
		if var2 == Enum.CameraType.Track then
			var3 = Enum.ComputerCameraMovementMode.Classic
		else
			if var2 == Enum.CameraType.Follow then
				var3 = Enum.ComputerCameraMovementMode.Follow
			else
				if var2 == Enum.CameraType.Orbital then
					var3 = Enum.ComputerCameraMovementMode.Orbital
				else
					if var2 == Enum.CameraType.Attach or (var2 == Enum.CameraType.Watch or var2 == Enum.CameraType.Fixed) then
						var4 = str4
					else
						warn("CameraScript encountered an unhandled Camera.CameraType value: ", var2)
					end
				end
			end
		end
	end

	if not var4 then
		if var8.VREnabled then
			var4 = str6
		else
			if var3 == Enum.ComputerCameraMovementMode.Classic or (var3 == Enum.ComputerCameraMovementMode.Follow or (var3 == Enum.ComputerCameraMovementMode.Default or var3 == Enum.ComputerCameraMovementMode.CameraToggle)) then
				var4 = str2
			else
				if var3 == Enum.ComputerCameraMovementMode.Orbital then
					var4 = str3
				else
					warn("ActivateCameraController did not select a module.")
					return
				end
			end
		end
	end

	if arg1:ShouldUseVehicleCamera() then
		var4 = if var8.VREnabled then str7 else str5
	end

	local var6 = nil
	if not str12[var4] then
		var6 = var4.new()
		str12[var4] = var6
	else
		var6 = str12[var4]
		if var10 then
			if var6.Reset and arg1.activeCameraController ~= var6 then
				var6:Reset()
			end
		else
			if var6.Reset then
				var6:Reset()
			end
		end
	end

	if arg1.activeCameraController then
		if arg1.activeCameraController ~= var6 then
			if var6.HandleSubjectDistance then
				var6:HandleSubjectDistance(arg1.activeCameraController)
			end

			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = var6
			arg1.activeCameraController:Enable(true)
		else
			if not arg1.activeCameraController:GetEnabled() then
				arg1.activeCameraController:Enable(true)
			end
		end
	elseif var6 ~= nil then
		arg1.activeCameraController = var6
		assert(arg1.activeCameraController, "Strict typing check")
		arg1.activeCameraController:Enable(true)
	end

	if arg1.activeCameraController then
		arg1.activeCameraController:SetCameraMovementMode(var3)
		arg1.activeCameraController:SetCameraType(var2)
	end
end

tbl1.OnCameraSubjectChanged = function(arg1)
	local var2 = workspace.CurrentCamera
	local var4 = if var2 then var2.CameraSubject else nil
	if arg1.activeTransparencyController then
		arg1.activeTransparencyController:SetSubject(var4)
	end

	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:OnCameraSubjectChanged(var4)
	end

	arg1:ActivateCameraController()
end

tbl1.OnCameraTypeChanged = function(arg1, arg2)
	if arg2 == Enum.CameraType.Scriptable and var7.MouseBehavior == Enum.MouseBehavior.LockCenter then
		var4.restoreMouseBehavior()
	end

	arg1:ActivateCameraController()
end

tbl1.OnCurrentCameraChanged = function(arg1)
	local var2 = game.Workspace.CurrentCamera
	if not var2 then
		return
	end

	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
	end

	if arg1.cameraTypeChangedConn then
		arg1.cameraTypeChangedConn:Disconnect()
	end

	arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		arg1:OnCameraSubjectChanged()
	end)

	arg1.cameraTypeChangedConn = var2:GetPropertyChangedSignal("CameraType"):Connect(function()
		arg1:OnCameraTypeChanged(var2.CameraType)
	end)

	arg1:OnCameraSubjectChanged()
	arg1:OnCameraTypeChanged(var2.CameraType)
end

tbl1.OnLocalPlayerCameraPropertyChanged = function(arg1, arg2)
	if arg2 == "CameraMode" then
		if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			if not arg1.activeCameraController or arg1.activeCameraController:GetModuleName() ~= "ClassicCamera" then
				arg1:ActivateCameraController()
			end

			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end

		if var5.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
			arg1:ActivateCameraController()
			return
		end

		warn("Unhandled value for property player.CameraMode: ", var5.LocalPlayer.CameraMode)
		return
	end

	if arg2 == "DevComputerCameraMode" or arg2 == "DevTouchCameraMode" then
		arg1:ActivateCameraController()
		return
	end

	if arg2 == "DevCameraOcclusionMode" then
		arg1:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
		return
	end

	if arg2 ~= "CameraMinZoomDistance" then
		if arg2 == "CameraMaxZoomDistance" then
			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end
	end

	if arg2 == "DevTouchMovementMode" then
		return
	end

	if arg2 == "DevComputerMovementMode" then
		return
	end

	if arg2 == "DevEnableMouseLock" then
	end
end

tbl1.OnUserGameSettingsPropertyChanged = function(arg1, arg2)
	if arg2 == "ComputerCameraMovementMode" or arg2 == "TouchCameraMovementMode" then
		arg1:ActivateCameraController()
	end
end

tbl1.OnPreferredInputChanged = function(arg1)
	arg1:ActivateCameraController()
end

tbl1.Update = function(arg1, arg2)
	if arg1.activeCameraController then
		arg1.activeCameraController:UpdateMouseBehavior()
		local var5, var6 = arg1.activeCameraController:Update(arg2)
		if arg1.activeOcclusionModule and (not arg1.activeCameraController.skipOcclusion) then
			local var7, var8 = arg1.activeOcclusionModule:Update(arg2, var5, var6)
			var5 = var7
			var6 = var8
		end

		local var9 = game.Workspace.CurrentCamera
		var9.CFrame = var5
		var9.Focus = var6
		if arg1.activeTransparencyController then
			arg1.activeTransparencyController:Update(arg2)
		end

		if str1.getInputEnabled() then
			str1.resetInputForFrameEnd()
		end
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterAdded(arg2, arg3)
	end
end

tbl1.OnCharacterRemoving = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterRemoving(arg2, arg3)
	end
end

tbl1.OnPlayerAdded = function(arg1, arg2)
	if str14 then
		if not arg1.connectionUtil then
			return
		end

		local function fn6(arg1)
			arg1:OnCharacterAdded(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterAdded"):format(arg2.UserId), arg2.CharacterAdded:Connect(fn6))
		fn6 = function(arg1)
			arg1:OnCharacterRemoving(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterRemoving"):format(arg2.UserId), arg2.CharacterRemoving:Connect(fn6))
		return
	end

	arg2.CharacterAdded:Connect(function(arg1)
		arg1:OnCharacterAdded(arg1, arg2)
	end)

	arg2.CharacterRemoving:Connect(function(arg1)
		arg1:OnCharacterRemoving(arg1, arg2)
	end)
end

tbl1.OnPlayerRemoving = function(arg1, arg2)
	if arg1.connectionUtil then
		arg1.connectionUtil:disconnect((("%*CharacterAdded"):format(arg2.UserId)))
		arg1.connectionUtil:disconnect((("%*CharacterRemoving"):format(arg2.UserId)))
	end
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = arg1.activeMouseLockController:GetIsMouseLocked()
	local var2 = arg1.activeMouseLockController:GetMouseLockOffset()
	if arg1.activeMouseLockController and arg1.activeCameraController then
		arg1.activeCameraController:SetIsMouseLocked(var1)
		arg1.activeCameraController:SetMouseLockOffset(var2)
	end
end

tbl1.new()
return {}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ClassicCamera [ModuleScript]
-- y u r i

Vector2.new(0, 0)
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixCameraFPError")
local str2 = "CameraInput"
local str3 = "CameraUtils"
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = CFrame.fromOrientation(-0.26179938779914941, 0, 0)
local var5 = game:GetService("Players")
str2 = setmetatable({}, var3)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(var3.new(), str2)
	var1.isFollowCamera = false
	var1.isCameraToggle = false
	var1.lastUpdate = tick()
	var1.cameraToggleSpring = var2.Spring.new(5, 0)
	return var1
end

str2.GetCameraToggleOffset = function(arg1, arg2)
	if arg1.isCameraToggle then
		local var4 = arg1.currentSubjectDistance
		if str1.getTogglePan() then
			arg1.cameraToggleSpring.goal = math.clamp(var2.map(var4, 0.5, arg1.FIRST_PERSON_DISTANCE_THRESHOLD, 0, 1), 0, 1)
		else
			arg1.cameraToggleSpring.goal = 0
		end

		return (Vector3.new(0, arg1.cameraToggleSpring:step(arg2) * (math.clamp(var2.map(var4, 0.5, 64, 0, 1), 0, 1) + 1), 0))
	end

	return (Vector3.new())
end

str2.SetCameraMovementMode = function(arg1, arg2)
	var3.SetCameraMovementMode(arg1, arg2)
	arg1.isFollowCamera = arg2 == Enum.ComputerCameraMovementMode.Follow
	arg1.isCameraToggle = arg2 == Enum.ComputerCameraMovementMode.CameraToggle
end

local num1 = 0
str2.Update = function(arg1, arg2)
	local var3 = workspace.CurrentCamera
	local var8 = tick()
	local var9 = var3.CFrame
	local var10 = var3.Focus
	local var11 = nil
	if arg1.resetCameraAngle then
		local var13 = arg1:GetHumanoidRootPart()
		arg1.resetCameraAngle = false
		var11 = if var13 then (var13.CFrame * var4).lookVector else var4.lookVector
	end

	local var14 = var3.CameraSubject
	local var15 = var14
	local var16 = var14
	local var17 = arg1:GetHumanoid()
	local var19 = var17
	local var20 = var5.LocalPlayer
	var15 = var15 and var14:IsA("VehicleSeat")
	var16 = var16 and var14:IsA("SkateboardPlatform")
	if var19 then
		var19 = var17:GetState() == Enum.HumanoidStateType.Climbing
	end

	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:StepZoom()
	local var22 = str1.getRotation(arg2)
	local var23 = arg1:GetCameraHeight()
	if var22 ~= Vector2.new() then
		num1 = 0
		arg1.lastUserPanCamera = tick()
	end

	local var26 = arg1:GetSubjectPosition()
	local var27 = var8 - arg1.lastUserPanCamera < 2
	if var26 then
		if var20 then
			if var3 then
				local var31 = arg1:GetCameraToSubjectDistance()
				if var31 < 0.5 then
					var31 = 0.5
				end

				if arg1:GetIsMouseLocked() then
					if not arg1:IsInFirstPerson() then
						local var32 = arg1:CalculateNewLookCFrameFromArg(var11, var22)
						local var33 = arg1:GetMouseLockOffset()
						if var17 then
							var33 = var33 + var17.CameraOffset
						end

						local var34 = var33.X * var32.RightVector + var33.Y * var32.UpVector + var33.Z * var32.LookVector
						if var2.IsFiniteVector3(var34) then
							var26 = var26 + var34
						end
					else
						if not (var22 ~= Vector2.new()) then
							if arg1.lastCameraTransform then
								local var37 = arg1:IsInFirstPerson()
								if not var15 then
									if var16 or arg1.isFollowCamera and var19 then
										if arg1.lastUpdate then
											if var17 then
												if var17.Torso then
													if var37 then
														if arg1.lastSubjectCFrame then
															if not var15 then
																if var16 then
																	if var14:IsA("BasePart") then
																		local var47 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																		if var2.IsFinite(var47) then
																			var22 = var22 + Vector2.new(var47, 0)
																		end

																		num1 = 0
																	end
																end
															end
														end
													elseif not var27 then
														local var48 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
														num1 = var48
														local var49 = var17.Torso.CFrame.lookVector
														var48 = math.clamp(num1 * arg2, 0, 1)
														if arg1:IsInFirstPerson() then
															var48 = arg1.isFollowCamera and arg1.isClimbing or 1
														end

														local var50 = var2.GetAngleBetweenXZVectors(var49, arg1:GetCameraLookVector())
														if var2.IsFinite(var50) and 0.0001 < math.abs(var50) then
															var22 = var22 + Vector2.new(var50 * var48, 0)
														end
													end
												else
													local var52 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
													if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var52) and (0.0001 < math.abs(var52) and 0.4 * arg2 < math.abs(var52))))) then
														var22 = var22 + Vector2.new(var52, 0)
													end
												end
											else
												local var54 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var54) and (0.0001 < math.abs(var54) and 0.4 * arg2 < math.abs(var54))))) then
													var22 = var22 + Vector2.new(var54, 0)
												end
											end
										else
											local var56 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var56) and (0.0001 < math.abs(var56) and 0.4 * arg2 < math.abs(var56))))) then
												var22 = var22 + Vector2.new(var56, 0)
											end
										end
									else
										local var58 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var58) and (0.0001 < math.abs(var58) and 0.4 * arg2 < math.abs(var58))))) then
											var22 = var22 + Vector2.new(var58, 0)
										end
									end
								end
							end
						end
					end
				else
					if not (var22 ~= Vector2.new()) then
						if arg1.lastCameraTransform then
							local var61 = arg1:IsInFirstPerson()
							if not var15 then
								if var16 or arg1.isFollowCamera and var19 then
									if arg1.lastUpdate then
										if var17 then
											if var17.Torso then
												if var61 then
													if arg1.lastSubjectCFrame then
														if not var15 then
															if var16 then
																if var14:IsA("BasePart") then
																	local var71 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																	if var2.IsFinite(var71) then
																		var22 = var22 + Vector2.new(var71, 0)
																	end

																	num1 = 0
																end
															end
														end
													end
												elseif not var27 then
													local var72 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
													num1 = var72
													local var73 = var17.Torso.CFrame.lookVector
													var72 = math.clamp(num1 * arg2, 0, 1)
													if arg1:IsInFirstPerson() then
														var72 = arg1.isFollowCamera and arg1.isClimbing or 1
													end

													local var74 = var2.GetAngleBetweenXZVectors(var73, arg1:GetCameraLookVector())
													if var2.IsFinite(var74) and 0.0001 < math.abs(var74) then
														var22 = var22 + Vector2.new(var74 * var72, 0)
													end
												end
											else
												local var76 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var76) and (0.0001 < math.abs(var76) and 0.4 * arg2 < math.abs(var76))))) then
													var22 = var22 + Vector2.new(var76, 0)
												end
											end
										else
											local var78 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var78) and (0.0001 < math.abs(var78) and 0.4 * arg2 < math.abs(var78))))) then
												var22 = var22 + Vector2.new(var78, 0)
											end
										end
									else
										local var80 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var80) and (0.0001 < math.abs(var80) and 0.4 * arg2 < math.abs(var80))))) then
											var22 = var22 + Vector2.new(var80, 0)
										end
									end
								else
									local var82 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
									if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var82) and (0.0001 < math.abs(var82) and 0.4 * arg2 < math.abs(var82))))) then
										var22 = var22 + Vector2.new(var82, 0)
									end
								end
							end
						end
					end
				end

				if not arg1.isFollowCamera then
					var10 = CFrame.new(var26)
					local var87 = var10.p
					local var88 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					if var1 then
						var9 = CFrame.lookAlong(var87 - var31 * var88, var88)
					else
						var9 = CFrame.new(var87 - var31 * var88, var87)
					end
				else
					var10 = CFrame.new(var26)
					local var90 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					var9 = if var1 then CFrame.lookAlong(var10.p - var31 * var90, var90) else CFrame.new(var10.p - var31 * var90, var10.p) + Vector3.new(0, var23, 0)
				end

				local var91 = arg1:GetCameraToggleOffset(arg2)
				var9 = var9 + var91
				arg1.lastCameraTransform = var9
				var10 = var10 + var91
				arg1.lastCameraFocus = var10
				if (var15 or var16) and var14:IsA("BasePart") then
					arg1.lastSubjectCFrame = var14.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var8
	return var9, var10
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUtils [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("UserInputService")
local var3 = UserSettings():GetService("UserGameSettings")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	return (setmetatable({ freq = arg1, goal = arg2, pos = arg2, vel = 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = arg1.pos - var1
	local var4 = arg1.vel
	local var5 = math.exp(-var2 * arg2)
	local var6 = (var3 * (var2 * arg2 + 1) + var4 * arg2) * var5 + var1
	arg1.pos = var6
	arg1.vel = (var4 * (1 - var2 * arg2) - var3 * (var2 * var2 * arg2)) * var5
	return var6
end

local tbl2 = {
	Spring = tbl1,
	map = function(arg1, arg2, arg3, arg4, arg5)
		return (arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4
	end,
	mapClamp = function(arg1, arg2, arg3, arg4, arg5)
		return (math.clamp((arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4, math.min(arg4, arg5), (math.max(arg4, arg5))))
	end,
	getLooseBoundingSphere = function(arg1)
		local var1 = table.create(#arg1)
		for k1, v1 in pairs(arg1) do
			var1[k1] = v1.Position
		end

		local var2 = var1[1]
		local var3 = var2
		local num1 = 0
		for k2, v2 in ipairs(var1) do
			local var4 = (v2 - var2).Magnitude
			if num1 >= var4 then
				continue
			end

			var3 = v2
			local var5 = var4
		end

		local var6 = var3
		local num2 = 0
		for k3, v3 in ipairs(var1) do
			local var7 = (v3 - var3).Magnitude
			if num2 >= var7 then
				continue
			end

			var6 = v3
			local var8 = var7
		end

		local var9 = (var3 + var6) * 0.5
		local var10 = (var3 - var6).Magnitude * 0.5
		for k4, v4 in ipairs(var1) do
			local var11 = (v4 - var9).Magnitude
			if var10 >= var11 then
				continue
			end

			var9 = var9 + (var11 - var10) * 0.5 * (v4 - var9).Unit
			var10 = (var11 + var10) * 0.5
		end

		return var9, var10
	end,
	sanitizeAngle = function(arg1)
		return (arg1 + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
	end,
	Round = function(arg1, arg2)
		local var1 = 10 ^ arg2
		return math.floor(arg1 * var1 + 0.5) / var1
	end,
	IsFinite = function(arg1)
		local bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end

		return bool2
	end,
}

tbl2.IsFiniteVector3 = function(arg1)
	local var1 = tbl2.IsFinite(arg1.X)
	return var1 and (tbl2.IsFinite(arg1.Y) and tbl2.IsFinite(arg1.Z))
end

tbl2.GetAngleBetweenXZVectors = function(arg1, arg2)
	return (math.atan2(arg2.X * arg1.Z - arg2.Z * arg1.X, arg2.X * arg1.X + arg2.Z * arg1.Z))
end

tbl2.RotateVectorByAngleAndRound = function(arg1, arg2, arg3)
	if 0 < arg1.Magnitude then
		arg1 = arg1.Unit
		return math.floor((math.atan2(arg1.Z, arg1.X) + arg2) / arg3 + 0.5) * arg3 - math.atan2(arg1.Z, arg1.X)
	end

	return 0
end

tbl2.GamepadLinearToCurve = function(arg1)
	local var2 = arg1.X
	local var3 = Vector2.new
	local num2 = 1
	if var2 < 0 then
		num2 = -1
	end

	local var5 = math.clamp((math.abs((math.abs(var2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	local var6 = math.clamp(((if 0 <= var5 then var5 * 0.35 / (0.35 - var5 + 1) else -(-var5 * 0.8 / (var5 + 0.8 + 1))) / 2 + 0.5) * num2, -1, 1)
	num2 = arg1.Y
	local num4 = 1
	if num2 < 0 then
		num4 = -1
	end

	local var8 = math.clamp((math.abs((math.abs(num2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	var2 = math.clamp(((if 0 <= var8 then var8 * 0.35 / (0.35 - var8 + 1) else -(-var8 * 0.8 / (var8 + 0.8 + 1))) / 2 + 0.5) * num4, -1, 1)
	return var3(var6, var2)
end

tbl2.ConvertCameraModeEnumToStandard = function(arg1)
	if arg1 == Enum.TouchCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.ComputerCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Classic or (arg1 == Enum.DevTouchCameraMovementMode.Classic or (arg1 == Enum.DevComputerCameraMovementMode.Classic or arg1 == Enum.ComputerCameraMovementMode.Classic)) then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Follow or (arg1 == Enum.DevTouchCameraMovementMode.Follow or (arg1 == Enum.DevComputerCameraMovementMode.Follow or arg1 == Enum.ComputerCameraMovementMode.Follow)) then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.TouchCameraMovementMode.Orbital or (arg1 == Enum.DevTouchCameraMovementMode.Orbital or (arg1 == Enum.DevComputerCameraMovementMode.Orbital or arg1 == Enum.ComputerCameraMovementMode.Orbital)) then
		return Enum.ComputerCameraMovementMode.Orbital
	end

	if arg1 == Enum.ComputerCameraMovementMode.CameraToggle or arg1 == Enum.DevComputerCameraMovementMode.CameraToggle then
		return Enum.ComputerCameraMovementMode.CameraToggle
	end

	if arg1 == Enum.DevTouchCameraMovementMode.UserChoice or arg1 == Enum.DevComputerCameraMovementMode.UserChoice then
		return Enum.DevComputerCameraMovementMode.UserChoice
	end

	return Enum.ComputerCameraMovementMode.Classic
end

local var4 = nil
local str1 = ""
tbl2.setMouseIconOverride = function(arg1)
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon ~= var4 then
		str1 = var5.Icon
	end

	var5.Icon = arg1
	var4 = arg1
end

tbl2.restoreMouseIcon = function()
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon == var4 then
		var5.Icon = str1
	end

	var4 = nil
end

local var5 = nil
local var6 = Enum.MouseBehavior.Default
tbl2.setMouseBehaviorOverride = function(arg1)
	if var2.MouseBehavior ~= var5 then
		var6 = var2.MouseBehavior
	end

	var2.MouseBehavior = arg1
	var5 = arg1
end

tbl2.restoreMouseBehavior = function()
	if var2.MouseBehavior == var5 then
		var2.MouseBehavior = var6
	end

	var5 = nil
end

local var7 = nil
local var8 = Enum.RotationType.MovementRelative
tbl2.setRotationTypeOverride = function(arg1)
	if var3.RotationType ~= var7 then
		var8 = var3.RotationType
	end

	var3.RotationType = arg1
	var7 = arg1
end

tbl2.restoreRotationType = function()
	if var3.RotationType == var7 then
		var3.RotationType = var8
	end

	var7 = nil
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController [ModuleScript]
-- y u r i

game:GetService("Players")
game:GetService("UserInputService")
UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
local str2 = "CameraUI"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local var3 = require(script.Parent:WaitForChild(str3))
var2.setCameraModeToastEnabled(false)
str1 = false
str3 = false
str2 = tick()
local bool1 = false
local bool2 = false
return function(arg1)
	local var5 = var1.getTogglePan()
	if arg1 and var5 ~= str1 then
		str3 = true
	end

	if str1 == var5 then
		if 3 < tick() - str2 then
			local var7 = var5
			if var7 then
				var7 = tick() - str2 < 3
			end

			var2.setCameraModeToastOpen(var7)
			if var5 then
				str3 = false
			end

			str2 = tick()
			str1 = var5
		end
	end

	if arg1 ~= bool1 then
		if arg1 then
			bool2 = var1.getTogglePan()
			var1.setTogglePan(true)
		else
			if not str3 then
				var1.setTogglePan(bool2)
			end
		end
	end

	if arg1 then
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		else
			var3.restoreMouseIcon()
			var3.restoreMouseBehavior()
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		end
	else
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
		else
			if var1.getHoldPan() then
				var3.restoreMouseIcon()
				var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
				var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
			else
				var3.restoreMouseIcon()
				var3.restoreMouseBehavior()
				var3.restoreRotationType()
			end
		end
	end

	bool1 = arg1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector [ModuleScript]
-- y u r i

local tbl1 = { JUMP_STUDS = 4, SETTLED_STUDS = 1, DEBOUNCE_SECONDS = 0.25 }
tbl1.shouldRecenter = function(arg1, arg2, arg3, arg4)
	if arg2 <= tbl1.JUMP_STUDS then
		return false
	end

	if arg1 ~= nil and tbl1.SETTLED_STUDS <= arg1 then
		return false
	end

	if arg3 ~= nil and arg4 - arg3 < tbl1.DEBOUNCE_SECONDS then
		return false
	end

	return true
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera [ModuleScript]
-- y u r i

local str1 = "CameraInput"
local str2 = "ZoomController"
local var1 = require(script.Parent:WaitForChild(str2))
local var2 = require(script.Parent:WaitForChild(str1))
local str3 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str3)).getUserFlag("UserVRRemoveLuaEdgeBlur")
local str4 = "BaseCamera"
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = game:GetService("VRService")
local var5 = game:GetService("Players").LocalPlayer
local var6 = game:GetService("Lighting")
local var7 = game:GetService("RunService")
local var8 = UserSettings():GetService("UserGameSettings")
str3 = setmetatable({}, var3)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(var3.new(), str3)
	var1.gamepadZoomLevels = { 0, 7 }
	var1.headScale = 1
	var1:SetCameraToSubjectDistance(7)
	var1.VRFadeResetTimer = 0
	var1.VREdgeBlurTimer = 0
	var1.gamepadResetConnection = nil
	var1.needsReset = true
	var1.recentered = false
	var1:Reset()
	return var1
end

str3.Reset = function(arg1)
	arg1.stepRotateTimeout = 0
end

str3.GetModuleName = function(_)
	return "VRBaseCamera"
end

str3.GamepadZoomPress = function(arg1)
	var3.GamepadZoomPress(arg1)
	arg1:GamepadReset()
	arg1:ResetZoom()
end

str3.GamepadReset = function(arg1)
	arg1.stepRotateTimeout = 0
	arg1.needsReset = true
end

str3.ResetZoom = function(arg1)
	var1.SetZoomParameters(arg1.currentSubjectDistance, 0)
	var1.ReleaseSpring()
end

str3.OnEnabledChanged = function(arg1)
	var3.OnEnabledChanged(arg1)
	if arg1.enabled then
		arg1.gamepadResetConnection = var2.gamepadReset:Connect(function()
			arg1:GamepadReset()
		end)

		arg1.thirdPersonOptionChanged = var4:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function()
			arg1:Reset()
		end)

		arg1.vrRecentered = var4.UserCFrameChanged:Connect(function(arg1, _)
			if arg1 == Enum.UserCFrame.Floor then
				arg1.recentered = true
			end
		end)

		return
	end

	if arg1.inFirstPerson then
		arg1:GamepadZoomPress()
	end

	if arg1.thirdPersonOptionChanged then
		arg1.thirdPersonOptionChanged:Disconnect()
		arg1.thirdPersonOptionChanged = nil
	end

	if arg1.vrRecentered then
		arg1.vrRecentered:Disconnect()
		arg1.vrRecentered = nil
	end

	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	if arg1.gamepadResetConnection then
		arg1.gamepadResetConnection:Disconnect()
		arg1.gamepadResetConnection = nil
	end

	if not str2 then
		arg1.VREdgeBlurTimer = 0
		arg1:UpdateEdgeBlur(var5, 1)
	end

	local var7 = var6:FindFirstChild("VRFade")
	if var7 then
		var7.Brightness = 0
	end
end

str3.OnCurrentCameraChanged = function(arg1)
	var3.OnCurrentCameraChanged(arg1)
	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	local var2 = workspace.CurrentCamera
	if var2 then
		arg1.cameraHeadScaleChangedConn = var2:GetPropertyChangedSignal("HeadScale"):Connect(function()
			arg1:OnHeadScaleChanged()
		end)

		arg1:OnHeadScaleChanged()
	end
end

str3.OnHeadScaleChanged = function(arg1)
	local var1 = workspace.CurrentCamera.HeadScale
	for k1, v1 in arg1.gamepadZoomLevels, nil do
		arg1.gamepadZoomLevels[k1] = v1 * var1 / arg1.headScale
	end

	arg1:SetCameraToSubjectDistance(arg1:GetCameraToSubjectDistance() * var1 / arg1.headScale)
	arg1.headScale = var1
end

str3.GetVRFocus = function(arg1, arg2, arg3)
	local var1 = Vector3.new(arg1.cameraTranslationConstraints.x, math.min(1, arg1.cameraTranslationConstraints.y + arg3), arg1.cameraTranslationConstraints.z)
	arg1.cameraTranslationConstraints = var1
	local var2 = arg2 + Vector3.new(0, arg1:GetCameraHeight(), 0)
	local var3 = arg1.cameraTranslationConstraints.y
	return (CFrame.new(Vector3.new(arg2.x, (arg1.lastCameraFocus or arg2).y, arg2.z):Lerp(var2, var3)))
end

str3.StartFadeFromBlack = function(arg1)
	if var8.VignetteEnabled == false then
		return
	end

	local var2 = var6:FindFirstChild("VRFade")
	if not var2 then
		var2 = Instance.new("ColorCorrectionEffect")
		var2.Name = "VRFade"
		var2.Parent = var6
	end

	var2.Brightness = -1
	arg1.VRFadeResetTimer = 0.1
end

str3.UpdateFadeFromBlack = function(arg1, arg2)
	local var1 = var6:FindFirstChild("VRFade")
	if 0 < arg1.VRFadeResetTimer then
		local var2 = math.max(arg1.VRFadeResetTimer - arg2, 0)
		arg1.VRFadeResetTimer = var2
		var2 = var6:FindFirstChild("VRFade")
		if not (var2 and var2.Brightness < 0) then
			return
		end

		if var2.Brightness >= 0 then
			return
		end

		local var3 = math.min(var2.Brightness + arg2 * 10, 0)
		var2.Brightness = var3
		return
	end

	if var1 then
		var1.Brightness = 0
	end
end

str3.StartVREdgeBlur = function(arg1, arg2, arg3)
	if not arg3 and var8.VignetteEnabled == false then
		return
	end

	local var1 = nil
	var1 = workspace.CurrentCamera:FindFirstChild("VRBlurPart")
	if not var1 then
		var1 = Instance.new("Part")
		var1.Name = "VRBlurPart"
		var1.Parent = workspace.CurrentCamera
		var1.CanTouch = false
		var1.CanCollide = false
		var1.CanQuery = false
		var1.Anchored = true
		var1.Size = Vector3.new(0.44, 0.47, 1)
		var1.Transparency = 1
		var1.CastShadow = false
		var7.RenderStepped:Connect(function(_)
			local var2 = var4:GetUserCFrame(Enum.UserCFrame.Head)
			local var3 = workspace.CurrentCamera.CFrame * (CFrame.new(var2.p * workspace.CurrentCamera.HeadScale) * (var2 - var2.p))
			var1.CFrame = var3 * CFrame.Angles(0, 3.1415926535897931, 0) + var3.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
			var1.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
		end)

	end

	local var2 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var3 = nil
	var3 = var2 and var2:FindFirstChild("VRBlur")
	if not var3 then
		var2 = var2 or Instance.new("ScreenGui")
		var2.Name = "VRBlurScreen"
		var2.Parent = arg2.PlayerGui
		var2.Adornee = var1
		var3 = Instance.new("ImageLabel")
		var3.Name = "VRBlur"
		var3.Parent = var2
		var3.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
		var3.AnchorPoint = Vector2.new(0.5, 0.5)
		var3.Position = UDim2.new(0.5, 0, 0.5, 0)
		var3.Size = UDim2.fromScale(workspace.CurrentCamera.ViewportSize.X * 2.3 / 512, workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512)
		var3.BackgroundTransparency = 1
		var3.Active = true
		var3.ScaleType = Enum.ScaleType.Stretch
	end

	var3.Visible = true
	var3.ImageTransparency = 0
	arg1.VREdgeBlurTimer = 0.14
end

str3.UpdateEdgeBlur = function(arg1, arg2, arg3)
	local var3 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var4 = nil
	if var3 then
		var4 = var3:FindFirstChild("VRBlur")
	end

	if var4 then
		if 0 < arg1.VREdgeBlurTimer then
			local var5 = arg1.VREdgeBlurTimer - arg3
			arg1.VREdgeBlurTimer = var5
			var5 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
			local var6 = var5:FindFirstChild("VRBlur")
			if not (var5 and var6) then
				return
			end

			var6 = var5:FindFirstChild("VRBlur")
			if not var6 then
				return
			end

			var6.ImageTransparency = 1 - math.clamp(arg1.VREdgeBlurTimer, 0.01, 0.14) * 7.1428571428571423
			return
		end

		var4.Visible = false
	end
end

str3.GetCameraHeight = function(arg1)
	if not arg1.inFirstPerson then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

str3.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectCFrame(arg1)
	if not var2 then
		return var4
	end

	if var2:IsA("Humanoid") then
		if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
			var4 = arg1.lastSubjectCFrame
		end
	end

	if var4 then
		arg1.lastSubjectCFrame = var4
	end

	return var4
end

str3.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectPosition(arg1)
	if var2 then
		if var2:IsA("Humanoid") then
			if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
				var4 = arg1.lastSubjectPosition
			end
		else
			if var2:IsA("VehicleSeat") then
				var4 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
			end
		end
	else
		return nil
	end

	arg1.lastSubjectPosition = var4
	return var4
end

str3.getRotation = function(arg1, arg2)
	local var3 = var2.getRotation(arg2)
	local num2 = 0
	if var8.VRSmoothRotationEnabled then
		return var3.X
	end

	if 0.03 < math.abs(var3.X) then
		if 0 < arg1.stepRotateTimeout then
			local var4 = arg1.stepRotateTimeout - arg2
			arg1.stepRotateTimeout = var4
		end

		if arg1.stepRotateTimeout <= 0 then
			num2 = 1
			if var3.X < 0 then
				num2 = -1
			end

			arg1:StartFadeFromBlack()
			arg1.stepRotateTimeout = 0.25
			num2 = num2 * 0.52359877559829882
			return num2
		end
	end

	if math.abs(var3.X) < 0.02 then
		arg1.stepRotateTimeout = 0
	end

	return num2
end

str3.HandleSubjectDistance = function(arg1, arg2)
	if arg2 and (arg2.IsInFirstPerson and arg2:IsInFirstPerson()) then
		arg1:SetCameraToSubjectDistance(0)
	end
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.LegacyCamera [ModuleScript]
-- y u r i

Vector2.new()
local str1 = "CameraUtils"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str2))
local str3 = "BaseCamera"
str1 = require(script.Parent:WaitForChild(str3))
local var2 = game:GetService("Players")
str2 = setmetatable({}, str1)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(str1.new(), str2)
	var1.cameraType = Enum.CameraType.Fixed
	var1.lastUpdate = tick()
	var1.lastDistanceToSubject = nil
	return var1
end

str2.GetModuleName = function(_)
	return "LegacyCamera"
end

str2.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return str1.SetCameraToSubjectDistance(var1, var2)
end

str2.Update = function(arg1, arg2)
	if not arg1.cameraType then
		return nil, nil
	end

	local var3 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4.CFrame
	local var6 = var4.Focus
	local var7 = var2.LocalPlayer
	local var8 = var1.getRotation(arg2)
	if arg1.lastUpdate == nil or 1 < var3 - arg1.lastUpdate then
		arg1.lastDistanceToSubject = nil
	end

	local var10 = arg1:GetSubjectPosition()
	if arg1.cameraType == Enum.CameraType.Fixed then
		if var10 and (var7 and var4) then
			var5 = CFrame.new(var4.CFrame.p, var4.CFrame.p + arg1:GetCameraToSubjectDistance() * arg1:CalculateNewLookVectorFromArg(nil, var8))
			var6 = var4.Focus
		end
	else
		if arg1.cameraType == Enum.CameraType.Attach then
			local var12 = arg1:GetSubjectCFrame()
			local var13, var14 = var12:ToEulerAnglesYXZ()
			var6 = CFrame.new(var12.p) * CFrame.fromEulerAnglesYXZ(math.clamp(var4.CFrame:ToEulerAnglesYXZ() - var8.Y, -1.3962634015954636, 1.3962634015954636), var14, 0)
			var5 = var6 * CFrame.new(0, 0, arg1:StepZoom())
		else
			if arg1.cameraType == Enum.CameraType.Watch then
				if var10 then
					if var7 then
						if var4 then
							local var15 = nil
							if var10 == var4.CFrame.p then
								warn("Camera cannot watch subject in same position as itself")
								return var4.CFrame, var4.Focus
							end

							local var18 = arg1:GetHumanoid()
							if var18 then
								if var18.RootPart then
									local var20 = var10 - var4.CFrame.p
									var15 = var20.unit
									if arg1.lastDistanceToSubject and arg1.lastDistanceToSubject == arg1:GetCameraToSubjectDistance() then
										arg1:SetCameraToSubjectDistance(var20.magnitude)
									end
								end
							end

							local var21 = arg1:GetCameraToSubjectDistance()
							var6 = CFrame.new(var10)
							var5 = CFrame.new(var10 - var21 * arg1:CalculateNewLookVectorFromArg(var15, var8), var10)
							arg1.lastDistanceToSubject = var21
						end
					end
				end
			else
				return var4.CFrame, var4.Focus
			end
		end
	end

	arg1.lastUpdate = var3
	return var5, var6
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.TransparencyController [ModuleScript]
-- y u r i

local str1 = "CameraUtils"
local var1 = game:GetService("VRService")
local var2 = require(script.Parent:WaitForChild(str1))
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.transparencyDirty = false
	var1.enabled = false
	var1.lastTransparency = nil
	var1.descendantAddedConn = nil
	var1.descendantRemovingConn = nil
	var1.toolDescendantAddedConns = {}
	var1.toolDescendantRemovingConns = {}
	var1.cachedParts = {}
	return var1
end

tbl1.HasToolAncestor = function(arg1, arg2)
	if arg2.Parent == nil then
		return false
	end

	assert(arg2.Parent, "")
	local var1 = arg2.Parent:IsA("Tool")
	return var1 or arg1:HasToolAncestor(arg2.Parent)
end

local tbl2 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion",
}

tbl1.IsValidPartToModify = function(arg1, arg2)
	for k1, v1 in tbl2, nil do
		if not arg2:IsA(v1) then
			continue
		end

		return not arg1:HasToolAncestor(arg2)
	end

	return false
end

tbl1.CachePartsRecursive = function(arg1, arg2)
	if arg2 then
		if arg1:IsValidPartToModify(arg2) then
			arg1.cachedParts[arg2] = true
			arg1.transparencyDirty = true
		end

		for k1, v1 in pairs(arg2:GetChildren()) do
			arg1:CachePartsRecursive(v1)
		end
	end
end

tbl1.TeardownTransparency = function(arg1)
	for k1, v1 in pairs(arg1.cachedParts) do
		k1.LocalTransparencyModifier = 0
	end

	arg1.cachedParts = {}
	arg1.transparencyDirty = true
	arg1.lastTransparency = nil
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
		arg1.descendantAddedConn = nil
	end

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
		arg1.descendantRemovingConn = nil
	end

	for k2, v2 in pairs(arg1.toolDescendantAddedConns) do
		v2:Disconnect()
		arg1.toolDescendantAddedConns[k2] = nil
	end

	for k3, v3 in pairs(arg1.toolDescendantRemovingConns) do
		v3:Disconnect()
		arg1.toolDescendantRemovingConns[k3] = nil
	end
end

tbl1.SetupTransparency = function(arg1, arg2)
	arg1:TeardownTransparency()
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
	end

	arg1.descendantAddedConn = arg2.DescendantAdded:Connect(function(arg1)
		if arg1:IsValidPartToModify(arg1) then
			arg1.cachedParts[arg1] = true
			arg1.transparencyDirty = true
			return
		end

		if arg1:IsA("Tool") then
			if arg1.toolDescendantAddedConns[arg1] then
				arg1.toolDescendantAddedConns[arg1]:Disconnect()
			end

			arg1.toolDescendantAddedConns[arg1] = arg1.DescendantAdded:Connect(function(arg1)
				arg1.cachedParts[arg1] = nil
				if arg1:IsA("BasePart") or arg1:IsA("Decal") then
					arg1.LocalTransparencyModifier = 0
				end
			end)

			if arg1.toolDescendantRemovingConns[arg1] then
				arg1.toolDescendantRemovingConns[arg1]:disconnect()
			end

			arg1.toolDescendantRemovingConns[arg1] = arg1.DescendantRemoving:Connect(function(arg1)
				wait()
				if arg2 and (arg1 and (arg1:IsDescendantOf(arg2) and arg1:IsValidPartToModify(arg1))) then
					arg1.cachedParts[arg1] = true
					arg1.transparencyDirty = true
				end
			end)

		end
	end)

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
	end

	arg1.descendantRemovingConn = arg2.DescendantRemoving:connect(function(arg1)
		if arg1.cachedParts[arg1] then
			arg1.cachedParts[arg1] = nil
			arg1.LocalTransparencyModifier = 0
		end
	end)

	arg1:CachePartsRecursive(arg2)
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
	end
end

tbl1.SetSubject = function(arg1, arg2)
	local var1 = nil
	var1 = arg2 and (arg2:IsA("Humanoid") and arg2.Parent)
	if arg2 then
		if arg2:IsA("VehicleSeat") and arg2.Occupant then
			var1 = arg2.Occupant.Parent
		end
	end

	if var1 then
		arg1:SetupTransparency(var1)
		return
	end

	arg1:TeardownTransparency()
end

tbl1.Update = function(arg1, arg2)
	local var6 = workspace.CurrentCamera
	if var6 then
		if arg1.enabled then
			local var9 = (var6.Focus.p - var6.CoordinateFrame.p).magnitude
			local var11 = var9 < 2 and 1 - (var9 - 0.5) / 1.5 or 0
			if var11 < 0.5 then
				var11 = 0
			end

			if arg1.lastTransparency and (var11 < 1 and arg1.lastTransparency < 0.95) then
				local var13 = 2.8 * arg2
				var11 = arg1.lastTransparency + math.clamp(var11 - arg1.lastTransparency, -var13, var13)
			else
				arg1.transparencyDirty = true
			end

			local num3 = 1
			var11 = math.clamp(var2.Round(var11, 2), 0, num3)
			if arg1.transparencyDirty or arg1.lastTransparency ~= var11 then
				for k1, v1 in pairs(arg1.cachedParts) do
					if var1.VREnabled and var1.AvatarGestures then
						if k1.Parent:IsA("Accessory") and ({
							[Enum.AccessoryType.Hat] = true,
							[Enum.AccessoryType.Hair] = true,
							[Enum.AccessoryType.Face] = true,
							[Enum.AccessoryType.Eyebrow] = true,
							[Enum.AccessoryType.Eyelash] = true,
						})[k1.Parent.AccessoryType] or k1.Name == "Head" then

							k1.LocalTransparencyModifier = var11
						else
							k1.LocalTransparencyModifier = 0
							continue
						end
					else
						k1.LocalTransparencyModifier = var11
					end
				end

				arg1.transparencyDirty = false
				arg1.lastTransparency = var11
			end
		end
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController [ModuleScript]
-- y u r i

local str1 = "Popper"
local var1 = require(script:WaitForChild(str1))
local var2 = game:GetService("Players").LocalPlayer
assert(var2)
local var3 = nil
local var4 = nil
local function updateBounds()
	var3 = var2.CameraMinZoomDistance
	var4 = var2.CameraMaxZoomDistance
end

var2:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(updateBounds)
var2:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(updateBounds)
var3 = var2.CameraMinZoomDistance
var4 = var2.CameraMaxZoomDistance
var2 = {}
var2.__index = var2
local var5 = math.clamp
var2.new = function(arg1, arg2, arg3, arg4)
	arg2 = var5(arg2, arg3, arg4)
	return (setmetatable({ freq = arg1, x = arg2, v = 0, minValue = arg3, maxValue = arg4, goal = arg2 }, var2))
end

local var6 = math.exp
var2.Step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = var2 * arg2
	local var4 = arg1.v
	local var5 = var1 - arg1.x
	local var7 = var6(-var3)
	local var11 = var1 + (var4 * arg2 - var5 * (var3 + 1)) * var7
	local var12 = arg1.minValue
	local var13 = arg1.maxValue
	local var14 = ((var5 * var2 - var4) * var3 + var4) * var7
	if var11 < var12 then
		var11 = var12
		var14 = 0
	elseif var13 < var11 then
		var11 = var13
		var14 = 0
	end

	arg1.x = var11
	arg1.v = var14
	return var11
end

updateBounds = var2.new(4.5, 12.5, 0.5, var4)
local num1 = 0
local var7 = math.max
str1 = math.min
return {
	Update = function(arg1, arg2, arg3)
		local num2 = math.huge
		if 1 < updateBounds.goal then
			local var8 = updateBounds.goal
			local var9 = num1
			local var10 = var3
			var8 = var5(var8 + var9 * (var8 * 0.0375 + 1), var10, var4)
			local var11 = updateBounds.x
			if var8 < 1 then
				var8 = var9 <= 0 and var10 or 1
			end

			local var12 = var7(var11, var8)
			num2 = var1(arg2 * CFrame.new(0, 0, 0.5), var12 - 0.5, arg3) + 0.5
		end

		updateBounds.minValue = 0.5
		updateBounds.maxValue = str1(var4, num2)
		local var13 = arg1
		return updateBounds:Step(var13)
	end,
	GetZoomRadius = function()
		return updateBounds.x
	end,
	SetZoomParameters = function(arg1, arg2)
		updateBounds.goal = arg1
		num1 = arg2
	end,
	ReleaseSpring = function()
		updateBounds.x = updateBounds.goal
		updateBounds.v = 0
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper [ModuleScript]
-- y u r i

local var1 = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "FlagUtil"
local str2 = "CameraWrapper"
local str3 = "ConnectionUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
local var4 = require(var1:WaitForChild(str3))
str2 = var2.getUserFlag("UserCurrentCameraUpdate2")
local var5 = game:GetService("Players")
str1 = var2.getUserFlag("UserRaycastUpdateAPI2")
str3 = var2.getUserFlag("UserPlayerConnectionMemoryLeak")
local var6 = if str2 then var3.new() else nil
local var7 = if str2 then nil else game.Workspace.CurrentCamera
if str2 then
	var6:Enable()
end

local var8 = RaycastParams.new()
var8.IgnoreWater = true
var8.FilterType = Enum.RaycastFilterType.Exclude
var8.RespectCanCollide = true
local var9 = RaycastParams.new()
var9.IgnoreWater = true
var9.FilterType = Enum.RaycastFilterType.Include
local var10 = math.min
local var11 = math.tan
local var12 = math.rad
local var13 = Ray.new
local var16 = if str3 then var4.new() else nil
local var17 = nil
local var18 = nil
local var19 = nil
if str2 then
	local function updateProjection()
		local var1 = var6:getCamera()
		local var2 = var1.ViewportSize
		var19 = var11(var12(var1.FieldOfView) / 2) * 2
		var18 = var2.X / var2.Y * var19
	end

	var6:Connect("FieldOfView", updateProjection)
	var6:Connect("ViewportSize", updateProjection)
	local var20 = var6:getCamera()
	local var21 = var20.ViewportSize
	var19 = var11(var12(var20.FieldOfView) / 2) * 2
	var18 = var21.X / var21.Y * var19
	var17 = var6:getCamera().NearPlaneZ
	var6:Connect("NearPlaneZ", function()
		var17 = var6:getCamera().NearPlaneZ
	end)

else
	updateProjection = function()
		local var1 = var7.ViewportSize
		var19 = var11(var12(var7.FieldOfView) / 2) * 2
		var18 = var1.X / var1.Y * var19
	end

	var7:GetPropertyChangedSignal("FieldOfView"):Connect(updateProjection)
	var7:GetPropertyChangedSignal("ViewportSize"):Connect(updateProjection)
	local var22 = var7.ViewportSize
	var19 = var11(var12(var7.FieldOfView) / 2) * 2
	var17 = var7.NearPlaneZ
	var7:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		var17 = var7.NearPlaneZ
	end)

	var18 = var22.X / var22.Y * var19
end

updateProjection = {}
local tbl1 = {}
local function playerAdded(arg1)
	local function characterAdded(arg1)
		tbl1[arg1] = arg1
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	local function characterRemoving()
		tbl1[arg1] = nil
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	if str3 then
		local var2 = characterAdded
		var16:trackConnection(("%*CharacterAdded"):format(arg1.UserId), arg1.CharacterAdded:Connect(var2))
		var2 = characterRemoving
		var16:trackConnection(("%*CharacterRemoving"):format(arg1.UserId), arg1.CharacterRemoving:Connect(var2))
	else
		arg1.CharacterAdded:Connect(characterAdded)
		arg1.CharacterRemoving:Connect(characterRemoving)
	end

	if arg1.Character then
		tbl1[arg1] = arg1.Character
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end
end

var5.PlayerAdded:Connect(playerAdded)
var5.PlayerRemoving:Connect(function(arg1)
	tbl1[arg1] = nil
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end

	if str3 then
		var16:disconnect((("%*CharacterAdded"):format(arg1.UserId)))
		var16:disconnect((("%*CharacterRemoving"):format(arg1.UserId)))
	end
end)

local function refreshIgnoreList()
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end
end

for k1, v1 in ipairs(var5:GetPlayers()) do
	playerAdded(v1)
end

updateProjection = {}
local num1 = 1
for k2, v2 in pairs(tbl1) do
	updateProjection[num1] = v2
	num1 = num1 + 1
end

tbl1 = nil
refreshIgnoreList = nil
if str2 then
	var6:Connect("CameraSubject", function()
		local var2 = var6:getCamera().CameraSubject
		if var2 and var2:IsA("Humanoid") then
			refreshIgnoreList = var2.RootPart
			return
		end

		if var2 and var2:IsA("BasePart") then
			refreshIgnoreList = var2
			return
		end

		refreshIgnoreList = nil
	end)

else
	var7:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		local var1 = var7.CameraSubject
		if var1:IsA("Humanoid") then
			refreshIgnoreList = var1.RootPart
			return
		end

		if var1:IsA("BasePart") then
			refreshIgnoreList = var1
			return
		end

		refreshIgnoreList = nil
	end)

end

local num2 = 0
local num3 = 0.2
local function queryPoint(arg1, arg2, arg3, arg4)
	debug.profilebegin("queryPoint")
	arg3 = arg3 + var17
	local var1 = arg1 + arg2 * arg3
	local num1 = math.huge
	local num2 = math.huge
	local var2 = arg1
	local num3 = 0
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var3 = #updateProjection
		while true do
			local var7 = workspace:Raycast(var2, var1 - var2, var8)
			if var7 then
				local var10 = var7.Position
				num3 = num3 + 1
				local var12 = var7.Instance
				local var14 = (var10 - arg1).Magnitude
				if 64 <= num3 then
					num2 = var14
				else
					local bool2 = false
					if 1 - (1 - var12.Transparency) * (1 - var12.LocalTransparencyModifier) < 0.25 then
						if not str1 then
							bool2 = var12.CanCollide
							if bool2 then
								bool2 = false
								if tbl1 ~= (var12:GetRootPart() or var12) then
									bool2 = not var12:IsA("TrussPart")
								end
							end
						end
					end

					if bool2 then
						var9.FilterDescendantsInstances = { var12 }
						if workspace:Raycast(var1, var10 - var1, var9) then
							local var15
							if arg4 then
								var15 = workspace:Raycast(arg4, var1 - arg4, var9)
								if not var15 then
									var15 = workspace:Raycast(var1, arg4 - var1, var9)
								end
							else
								var15 = false
							end

							if var15 then
								num2 = var14
							elseif arg3 < num1 then
								num1 = var14
							end
						else
							num2 = var14
						end
					end
				end

				var8:AddToFilter(var12)
				var2 = var10 - arg2 * 0.001
				if num2 >= math.huge and var12 then
					continue
				end
			end
		end
	else
		repeat
			local var19, var20 = workspace:FindPartOnRayWithIgnoreList(var13(var2, var1 - var2), updateProjection, false, true)
			num3 = num3 + 1
			if var19 then
				local var21 = 64 <= num3
				local bool4 = false
				if 1 - (1 - var19.Transparency) * (1 - var19.LocalTransparencyModifier) < 0.25 then
					if not str1 then
						bool4 = var19.CanCollide
						if bool4 then
							bool4 = false
							if tbl1 ~= (var19:GetRootPart() or var19) then
								bool4 = not var19:IsA("TrussPart")
							end
						end
					end
				end

				if bool4 or var21 then
					bool4 = { var19 }
					var15 = (var20 - arg1).Magnitude
					if workspace:FindPartOnRayWithWhitelist(var13(var1, var20 - var1), bool4, true) then
						if not var21 then
							local bool5 = false
							if arg4 and workspace:FindPartOnRayWithWhitelist(var13(var1, arg4 - var1), bool4, true) then
								num2 = var15
							elseif arg3 < num1 then
								num1 = var15
							end
						else
							num2 = var15
						end
					else
						num2 = var15
					end
				end

				updateProjection[#updateProjection + 1] = var19
			end

			local var22 = var20 - arg2 * 0.001
		until num2 < math.huge or (not var19)

		local var23 = updateProjection
		for i1 = #var23, var3 + 1, -1 do
			var23[i1] = nil
		end
	end

	debug.profileend()
	return num1 - var17, num2 - var17
end

num1 = function(arg1, arg2)
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var2 = workspace:Raycast(arg1, arg2, var8)
		if var2 then
			return var2.Position, true
		end
	else
		local var3 = #updateProjection
		repeat
			local var7, var9 = workspace:FindPartOnRayWithIgnoreList(var13(arg1, arg2), updateProjection, false, true)
			if var7 then
				if var7.CanCollide then
					local var11 = updateProjection
					for i1 = #var11, var3 + 1, -1 do
						var11[i1] = nil
					end

					return var9, true
				end

				updateProjection[#updateProjection + 1] = var7
			end
		until not var7

		local var12 = updateProjection
		for i2 = #var12, var3 + 1, -1 do
			var12[i2] = nil
		end
	end

	return arg1 + arg2, false
end

local tbl2 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(num2, num3),
}

local function queryViewport(arg1, arg2)
	debug.profilebegin("queryViewport")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	local var5 = if str2 then var6:getCamera() else var7
	var7 = var5
	var5 = var7.ViewportSize
	local num1 = math.huge
	local num2 = math.huge
	for i1 = 0, 1 do
		for i2 = 0, 1 do
			local var8 = var2 * ((i1 - 0.5) * var18)
			local var11, var12 = queryPoint(var1 + var17 * (var8 + var3 * ((i2 - 0.5) * var19)), var4, arg2, var7:ViewportPointToRay(var5.x * i1, var5.y * i2).Origin)
			if var12 < num1 then
				num1 = var12
			end

			if var11 >= num2 then
				continue
			end

			num2 = var11
		end
	end

	debug.profileend()
	return num2, num1
end

local function testPromotion(arg1, arg2, arg3)
	debug.profilebegin("testPromotion")
	debug.profilebegin("extrapolate")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	for i1 = 0, var10(1.25, arg3.rotVelocity.magnitude + (num1(var1, arg3.posVelocity * 1.25) - var1).Magnitude / arg3.posVelocity.magnitude), 0.0625 do
		local var5 = arg3.extrapolate(i1)
		if arg2 > queryPoint(var5.p, -var5.lookVector, arg2) then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profilebegin("testOffsets")
	for k1, v1 in ipairs(tbl2) do
		local var6 = num1(var1, var2 * v1.x + var3 * v1.y)
		if queryPoint(var6, (var1 + var4 * arg2 - var6).Unit, arg2) ~= math.huge then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profileend()
	return true
end

return function(arg1, arg2, arg3)
	debug.profilebegin("popper")
	local var1 = refreshIgnoreList and refreshIgnoreList:GetRootPart() or refreshIgnoreList
	tbl1 = var1
	local var4, var5 = queryViewport(arg1, arg2)
	var1 = arg2
	if var5 < var1 then
		var1 = var5
	end

	if var4 < var1 and testPromotion(arg1, arg2, arg3) then
		var1 = var4
	end

	tbl1 = nil
	debug.profileend()
	return var1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.MouseLockController [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local str2 = "CameraUtils"
local var2 = game:GetService("Players")
str1 = game:GetService("ContextActionService")
local var3 = game:GetService("UserInputService")
local var4 = UserSettings().GameSettings
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = var1.getUserFlag("UserFixStuckShiftLock")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.isMouseLocked = false
	var1.savedMouseCursor = nil
	var1.boundKeys = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift }
	var1.mouseLockToggledEvent = Instance.new("BindableEvent")
	local var6 = script:FindFirstChild("BoundKeys")
	if var6 then
		if not var6:IsA("StringValue") then
			if var6 then
				var6:Destroy()
			end

			var6 = Instance.new("StringValue")
			assert(var6, "")
			var6.Name = "BoundKeys"
			var6.Value = "LeftShift,RightShift"
			var6.Parent = script
		end
	end

	if var6 then
		var6.Changed:Connect(function(arg1)
			var1:OnBoundKeysObjectChanged(arg1)
		end)

		var1:OnBoundKeysObjectChanged(var6.Value)
	end

	var4.Changed:Connect(function(arg1)
		if arg1 == "ControlMode" or arg1 == "ComputerMovementMode" then
			var1:UpdateMouseLockAvailability()
		end
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var3:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var1:UpdateMouseLockAvailability()
	return var1
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.isMouseLocked
end

tbl1.GetBindableToggleEvent = function(arg1)
	return arg1.mouseLockToggledEvent.Event
end

tbl1.GetMouseLockOffset = function(_)
	return Vector3.new(1.75, 0, 0)
end

tbl1.UpdateMouseLockAvailability = function(arg1)
	local var1 = var3.PreferredInput == Enum.PreferredInput.KeyboardAndMouse
	var1 = var1 and (var2.LocalPlayer.DevEnableMouseLock and (var4.ControlMode == Enum.ControlMode.MouseLockSwitch and (not (var4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove) and (not (var2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable)))))
	if var1 ~= arg1.enabled then
		arg1:EnableMouseLock(var1)
	end
end

tbl1.OnBoundKeysObjectChanged = function(arg1, arg2)
	arg1.boundKeys = {}
	for k1 in string.gmatch(arg2, "[^%s,]+") do
		for k2, v1 in pairs(Enum.KeyCode:GetEnumItems()) do
			if k1 ~= v1.Name then
				continue
			end

			arg1.boundKeys[#arg1.boundKeys + 1] = v1
			break
		end
	end

	arg1:UnbindContextActions()
	arg1:BindContextActions()
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = not arg1.isMouseLocked
	arg1.isMouseLocked = var1
	if arg1.isMouseLocked then
		var1 = script:FindFirstChild("CursorImage")
		if var1 and (var1:IsA("StringValue") and var1.Value) then
			var5.setMouseIconOverride(var1.Value)
		elseif var1 then
			var1:Destroy()
		end
	else
		var5.restoreMouseIcon()
	end

	arg1.mouseLockToggledEvent:Fire()
end

tbl1.DoMouseLockSwitch = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1:OnMouseLockToggled()
		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end

local var7 = Enum.ContextActionPriority.Medium.Value
tbl1.BindContextActions = function(arg1)
	local var1 = arg1.boundKeys
	str1:BindActionAtPriority("MouseLockSwitchAction", function(arg1, arg2, arg3)
		local var1 = arg1
		local var2 = arg2
		local var3 = arg3
		return arg1:DoMouseLockSwitch(var1, var2, var3)
	end, false, var7, unpack(var1))
end

tbl1.UnbindContextActions = function(_)
	str1:UnbindAction("MouseLockSwitchAction")
end

tbl1.IsMouseLocked = function(arg1)
	local var1 = arg1.enabled
	return var1 and arg1.isMouseLocked
end

tbl1.EnableMouseLock = function(arg1, arg2)
	if arg2 ~= arg1.enabled then
		arg1.enabled = arg2
		if arg1.enabled then
			arg1:BindContextActions()
			return
		end

		var5.restoreMouseIcon()
		arg1:UnbindContextActions()
		if var6 then
			if not arg1.isMouseLocked then
				return
			end

			arg1.isMouseLocked = false
			arg1.mouseLockToggledEvent:Fire()
			return
		end

		if arg1.isMouseLocked then
			arg1.mouseLockToggledEvent:Fire()
		end

		arg1.isMouseLocked = false
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec [ModuleScript]
-- y u r i

local var1 = require(game:GetService("CorePackages").Packages.Dev.JestGlobals)
local var2 = require(script.Parent.VRCameraTeleportDetector)
local var3 = var1.it
local var4 = var1.expect
local var5 = var2.shouldRecenter
local var6 = var2.JUMP_STUDS
local var7 = var2.SETTLED_STUDS
local var8 = var2.DEBOUNCE_SECONDS
var1.describe("VRCameraTeleportDetector.shouldRecenter", function()
	var3("fires on a discrete jump from rest (no prior step, never recentered)", function()
		local var1 = nil
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("fires on a discrete jump preceded by a near-still frame", function()
		local var1 = var7 - 0.5
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("does not fire for sub-threshold motion", function()
		local num1 = 0
		local var1 = var6 - 0.1
		local var2 = nil
		local num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
		num1 = 0
		var1 = 0
		var2 = nil
		num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
	end)

	var3("does not fire when the previous frame was already moving (continuous motion)", function()
		local var1 = var7 + 0.1
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(false)
	end)

	var3("does not fire within the debounce interval", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 - 0.01
		var4(var5(var1, var2, num1, var3)).toBe(false)
	end)

	var3("fires again once the debounce interval has elapsed", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 + 0.01
		var4(var5(var1, var2, num1, var3)).toBe(true)
	end)

	var3("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function()
		local num1 = 0
		local var1 = nil
		local var2 = nil
		local num2 = 0
		for i1 = 1, 120 do
			local var3 = var6 + 10
			if var5(var1, var3, var2, num1) then
				num2 = num2 + 1
			end

			local var7 = num1
			num1 = num1 + 0.016666666666666666
			local var8 = var3
		end

		var4(num2).toBe(1)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera [ModuleScript]
-- y u r i

local str1 = "VRBaseCamera"
local str2 = "CameraUtils"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str2))
local str4 = "VehicleCameraConfig"
str2 = game:GetService("RunService")
str3 = game:GetService("VRService")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local var6 = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild(str4))
local var7 = RaycastParams.new()
var7.FilterType = Enum.RaycastFilterType.Exclude
var7.IgnoreWater = true
local var8 = OverlapParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local var9 = setmetatable({}, var1)
var9.__index = var9
local num1 = 0.016666666666666666
var9.new = function()
	local var2 = setmetatable(var1.new(), var9)
	var2.skipOcclusion = true
	var2:Reset()
	if var2.thirdPersonOptionChanged then
		var2.thirdPersonOptionChanged:Disconnect()
		var2.thirdPersonOptionChanged = nil
	end

	str2.Stepped:Connect(function(_, arg2)
		num1 = arg2
	end)

	return var2
end

local tbl1 = { 0, 30 }
var9.Reset = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1, "VRVehicleCamera initialization error")
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	arg1.lastOrbitalDir = nil
	arg1.wasInFirstPerson = nil
	local var4 = var2:GetConnectedParts(true)
	table.insert(var4, var2)
	str1 = var2:FindFirstAncestorOfClass("Model")
	local var5, var6 = var3.getLooseBoundingSphere(var4)
	arg1.vehicleModel = str1 or var2.Parent
	arg1.assemblyRadius = math.max(var6, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var5
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.headScale * arg1.assemblyRadius / 10)
	end

	arg1.lastCameraFocus = nil
	if not arg1:IsInFirstPerson() then
		arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
	end

	arg1.needsReset = false
end

var9._getThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * var6.verticalCenterOffset, 0)
end

var9._getFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = var5.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_getThirdPersonLocalOffset()
end

local function findObstructions(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return 0, {}
	end

	local var3 = str3:GetUserCFrame(Enum.UserCFrame.Head)
	local var4 = arg1 * (CFrame.new(var3.Position * var2.HeadScale) * var3.Rotation)
	local var6 = arg2.Position
	local var9 = var4.Position - var6
	local var11 = var9.Magnitude
	if var11 < 0.5 then
		return 0, {}
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var12 = var5
	var12 = var12 and var5.Character
	if var12 then
		table.insert(tbl1, var12)
	end

	var7.FilterDescendantsInstances = tbl1
	local var15 = workspace:Raycast(var6, var9, var7)
	local var16 = (var15.Position - var6).Magnitude
	if var15 and var16 < var11 then
		local var17 = var15.Position
		local var18 = var4.Position
		local var19 = math.max(math.clamp((1 - -var9.Unit:Dot(var4.LookVector)) / 0.13397459621556129, 0, 1), 1 - var16 / arg3, 0.15)
		local var20 = Vector3.new(2, 2, (var18 - var17).Magnitude)
		local var21 = CFrame.lookAt((var17 + var18) / 2, var18)
		var8.FilterDescendantsInstances = tbl1
		return var19, (workspace:GetPartBoundsInBox(var21, var20, var8))
	end

	return 0, {}
end

var9._vrOccludeVignette = function(arg1, arg2, arg3, arg4)
	local var1 = CFrame.new(arg2.Position + arg3 * arg4) * CFrame.Angles(0, math.atan2(arg3.X, arg3.Z), 0)
	local var3 = var4:FindFirstChild("VRFade")
	local var6, var7 = findObstructions(var1, arg2, arg4, arg1.vehicleModel)
	if not var3 then
		var3 = Instance.new("ColorCorrectionEffect")
		var3.Name = "VRFade"
		var3.Parent = var4
	end

	var3.Brightness = -var6
	local var8
	if arg1.lastOccludedParts then
		for k1, v1 in arg1.lastOccludedParts, nil do
			v1.LocalTransparencyModifier = 0
		end
	end

	if 0 < (#var7) then
		for k2, v2 in var7, nil do
			v2.LocalTransparencyModifier = 1
		end

		arg1:StartVREdgeBlur(var5, true)
	end

	arg1.lastOccludedParts = var7
	return var1
end

var9.Update = function(arg1)
	local var1 = num1
	num1 = 0
	arg1:UpdateFadeFromBlack(var1)
	arg1:UpdateEdgeBlur(var5, var1)
	local var2, var3 = arg1:_updateStepRotation(var1)
	return var2, var3
end

local var10 = var3.mapClamp
local function vrOccludeDisplace(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	local var3 = CFrame.new(arg1.Position + arg2 * arg3) * CFrame.Angles(0, math.atan2(arg2.X, arg2.Z), 0)
	if not var2 then
		return var3
	end

	local var4 = arg1.Position
	local var6 = (var3.Position - var4) * Vector3.new(1, 0, 1)
	local var9 = var6.Magnitude
	if var9 < 0.5 then
		return var3
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var10 = var5
	var10 = var10 and var5.Character
	if var10 then
		table.insert(tbl1, var10)
	end

	var7.FilterDescendantsInstances = tbl1
	local var14 = workspace:Raycast(var4, var6, var7)
	local var15 = var6.Unit
	local var16 = (var14.Position - var4).Magnitude - 0.5
	if var14 and (var14.Normal:Dot(var15) < 0 and var16 < var9) then
		return CFrame.new(arg1.Position + var15 * math.max(var16, 0.5)) * var3.Rotation
	end

	return var3
end

var9._updateStepRotation = function(arg1, arg2)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var3 = arg1:GetSubjectCFrame()
	local var4 = CFrame.new(var3 * arg1:_getThirdPersonLocalOffset():Lerp(arg1:_getFirstPersonLocalOffset(var3), (var10(var1, 0.5, arg1.assemblyRadius, 1, 0))) + Vector3.new(0, arg1:GetCameraHeight(), 0))
	if arg1.needsReset or arg1.recentered then
		arg1.lastOrbitalDir = nil
		arg1.needsReset = false
		arg1.recentered = false
	end

	local var7 = arg1.lastOrbitalDir
	if not var7 then
		arg1:StartFadeFromBlack()
		var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
	end

	local var9 = 2 < (arg1:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude
	if not var9 then
		local var11 = arg1:getRotation(arg2)
		if 0 < math.abs(var11) then
			var7 = (CFrame.Angles(0, -var11, 0) * CFrame.new(var7)).Position.Unit
			arg1.lastRotateTime = os.clock()
		end
	else
		var2.getRotation(arg2)
	end

	local var12 = nil
	if arg1:IsInFirstPerson() then
		if not arg1.wasInFirstPerson or var9 then
			arg1.wasInFirstPerson = true
			var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
		end

		local var14 = math.atan2(-var3.LookVector.X, -var3.LookVector.Z)
		local var15 = (var14 - arg1.lastVehicleYaw + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
		if arg1.lastVehicleYaw and 0.001 < math.abs(var15) then
			var7 = (CFrame.Angles(0, var15, 0) * CFrame.new(var7)).Position.Unit
		end

		arg1.lastVehicleYaw = var14
		var12 = CFrame.new(var4.Position + var7 * var1) * CFrame.Angles(0, math.atan2(var7.X, var7.Z), 0)
	else
		arg1.wasInFirstPerson = false
		arg1.lastVehicleYaw = nil
		local var17 = arg1.lastRotateTime
		if var17 then
			var17 = os.clock() - arg1.lastRotateTime < var6.autocorrectDelay
		end

		if var9 and (not var17) then
			local var19 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
			var7 = var7:Lerp(var19, (math.min(0.01 + math.acos((math.clamp(var7:Dot(var19), -1, 1))) / 3.1415926535897931 * 0.05 + math.abs((var3.YVector:Dot((arg1:GetSubjectRotVelocity())))) * 0.02, 0.15)))
		end

		var12 = vrOccludeDisplace(var4, var7, var1, arg1.vehicleModel)
	end

	arg1.lastOrbitalDir = var7
	return var12, var12 * CFrame.new(0, 0, -var1)
end

return var9

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCamera [ModuleScript]
-- y u r i

UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraUtils"
require(script.Parent:WaitForChild(str2))
local str3 = "VRCameraTeleportDetector"
local var1 = require(script.Parent:WaitForChild(str3))
local str4 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str4))
local str5 = "VRBaseCamera"
str4 = require(script.Parent:WaitForChild(str5))
local var2 = game:GetService("Players")
local var3 = game:GetService("VRService")
str3 = str2.getUserFlag("UserVRRemoveLuaEdgeBlur")
local var4 = str2.getUserFlag("UserVRRecenterOnExternalTeleport")
local var5 = setmetatable({}, str4)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str4.new(), var5)
	var1.lastUpdate = tick()
	var1.focusOffset = CFrame.new()
	var1:Reset()
	local str1 = "ControlModule"
	var1.controlModule = require(var2.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild(str1))
	var1.savedAutoRotate = true
	return var1
end

var5.Reset = function(arg1)
	arg1.needsReset = true
	arg1.needsBlackout = true
	arg1.motionDetTime = 0
	arg1.blackOutTimer = 0
	arg1.lastCameraResetPosition = nil
	str4.Reset(arg1)
end

var5.Update = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	arg1:GetHumanoid()
	local var4 = var1.CFrame
	local var5 = var1.Focus
	local var6 = var2.LocalPlayer
	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:UpdateFadeFromBlack(arg2)
	if not str3 then
		arg1:UpdateEdgeBlur(var6, arg2)
	end

	local var7 = arg1.lastSubjectPosition
	local var8 = arg1:GetSubjectPosition()
	if arg1.needsBlackout then
		arg1:StartFadeFromBlack()
		local var9 = arg1.blackOutTimer + math.clamp(arg2, 0.0001, 0.1)
		arg1.blackOutTimer = var9
		if 0.1 < arg1.blackOutTimer and game:IsLoaded() then
			arg1.needsBlackout = false
			arg1.needsReset = true
		end
	end

	if var8 then
		if var6 then
			if var1 then
				var5 = arg1:GetVRFocus(var8, arg2)
				if arg1:IsInFirstPerson() then
					if var3.AvatarGestures then
						local var20, var21 = arg1:UpdateImmersionCamera(arg2, var4, var5, var7, var8)
						var4 = var20
						var5 = var21
					else
						local var22, var23 = arg1:UpdateFirstPersonTransform(arg2, var4, var5, var7, var8)
						var4 = var22
						var5 = var23
					end
				else
					if var3.ThirdPersonFollowCamEnabled then
						local var26, var27 = arg1:UpdateThirdPersonFollowTransform(arg2, var4, var5, var7, var8)
						var4 = var26
						var5 = var27
					else
						local var28, var29 = arg1:UpdateThirdPersonComfortTransform(arg2, var4, var5, var7, var8)
						var4 = var28
						var5 = var29
					end
				end

				arg1.lastCameraTransform = var4
				arg1.lastCameraFocus = var5
			end
		end
	end

	arg1.lastUpdate = tick()
	return var4, var5
end

var5.GetAvatarFeetWorldYValue = function(_)
	local var2 = workspace.CurrentCamera.CameraSubject
	if not var2 then
		return nil
	end

	if var2:IsA("Humanoid") and var2.RootPart then
		local var4 = var2.RootPart
		return var4.Position.Y - var4.Size.Y / 2 - var2.HipHeight
	end

	return nil
end

var5.UpdateFirstPersonTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	if arg1.needsReset then
		arg1:StartFadeFromBlack()
		arg1.needsReset = false
	end

	local var1 = var2.LocalPlayer
	if not str3 and 0.01 < (arg5 - arg6).magnitude then
		arg1:StartVREdgeBlur(var1)
	end

	local var3 = arg1:GetCameraLookVector()
	local var4 = arg1:getRotation(arg2)
	local num1 = 0
	local var5 = arg1:CalculateNewLookVectorFromArg(Vector3.new(var3.X, 0, var3.Z).Unit, Vector2.new(var4, num1))
	local var6 = arg4.p
	return CFrame.new(var6 - 0.5 * var5, var6), arg4
end

var5.UpdateImmersionCamera = function(arg1, arg2, arg3, _, arg5, arg6)
	local var7 = arg1:GetHumanoid()
	local var8 = arg1:GetSubjectCFrame()
	local var9 = workspace.CurrentCamera
	local var10 = var2.LocalPlayer.Character
	if not var7 then
		return var9.CFrame, var9.Focus
	end

	local var12 = var10:FindFirstChild("HumanoidRootPart")
	if not var12 then
		return var9.CFrame, var9.Focus
	end

	local var13 = nil
	if var4 then
		var13 = if arg5 then Vector3.new(arg6.X - arg5.X, 0, arg6.Z - arg5.Z).Magnitude else 0
	end

	arg1.characterOrientation = var12:FindFirstChild("CharacterAlignOrientation")
	if not arg1.characterOrientation then
		local var15 = var12:FindFirstChild("RootAttachment")
		if not var15 then
			return
		end

		arg1.characterOrientation = Instance.new("AlignOrientation")
		arg1.characterOrientation.Name = "CharacterAlignOrientation"
		arg1.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		arg1.characterOrientation.Attachment0 = var15
		arg1.characterOrientation.RigidityEnabled = true
		arg1.characterOrientation.Parent = var12
	end

	if arg1.characterOrientation.Enabled == false then
		arg1.characterOrientation.Enabled = true
	end

	if arg1.needsReset then
		arg1.needsReset = false
		arg1.savedAutoRotate = var7.AutoRotate
		var7.AutoRotate = false
		if var4 then
			var3:RecenterUserHeadCFrame()
			arg1.lastTeleportRecenter = tick()
		end

		arg1:StartFadeFromBlack()
		arg3 = var8
	else
		if var7.Sit then
			arg3 = var8
			if not str3 and 0.01 < (arg3.Position - var9.CFrame.Position).Magnitude then
				arg1:StartVREdgeBlur(var2.LocalPlayer)
			end
		else
			arg1.characterOrientation.CFrame = var9.CFrame * arg1.controlModule:GetEstimatedVRTorsoFrame()
			if 0 < arg1.controlModule.inputMoveVector.Magnitude then
				arg1.motionDetTime = 0.1
			end

			if 0 < arg1.controlModule.inputMoveVector.Magnitude or 0 < arg1.motionDetTime then
				local var16 = arg1.motionDetTime - arg2
				arg1.motionDetTime = var16
				if not str3 then
					arg1:StartVREdgeBlur(var2.LocalPlayer)
				end

				var16 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				local var17 = var10.HumanoidRootPart
				local var18 = var17.CFrame.LookVector
				local var19 = arg6 - (var9.CFrame * (var16.Rotation + var16.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var17.Size.Y / 2, 0) - Vector3.new(var18.X, 0, var18.Z).Unit * var17.Size.Y * 0.125).Position + var9.CFrame.Position
				arg3 = var9.CFrame.Rotation + Vector3.new(var19.X, arg6.Y, var19.Z)
			else
				if var4 and var1.shouldRecenter(arg1.prevSubjStep, var13, arg1.lastTeleportRecenter, tick()) then
					local var23 = var3:GetUserCFrame(Enum.UserCFrame.Head)
					local var24 = var10.HumanoidRootPart
					local var25 = var24.CFrame.LookVector
					local var26 = arg6 - (var9.CFrame * (var23.Rotation + var23.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var24.Size.Y / 2, 0) - Vector3.new(var25.X, 0, var25.Z).Unit * var24.Size.Y * 0.125).Position + var9.CFrame.Position
					var3:RecenterUserHeadCFrame()
					arg1:StartFadeFromBlack()
					arg3 = var9.CFrame.Rotation + Vector3.new(var26.X, arg6.Y, var26.Z)
					arg1.lastTeleportRecenter = tick()
				else
					arg3 = var9.CFrame.Rotation + Vector3.new(var9.CFrame.Position.X, arg6.Y, var9.CFrame.Position.Z)
				end
			end

			local var27 = arg1:getRotation(arg2)
			if 0 < math.abs(var27) then
				local var30 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				var30 = var30.Rotation + var30.Position * var9.HeadScale
				local var31 = arg3 * var30
				arg3 = CFrame.new(var31.Position) * CFrame.Angles(0, -math.rad(var27 * 90), 0) * var31.Rotation * var30:Inverse()
			end
		end
	end

	if var4 then
		arg1.prevSubjStep = var13
	end

	return arg3, arg3 * CFrame.new(0, 0, -0.5)
end

var5.UpdateThirdPersonComfortTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var4 = arg1:GetCameraToSubjectDistance()
	if var4 < 0.5 then
		var4 = 0.5
	end

	if arg5 ~= nil then
		if arg1.lastCameraFocus ~= nil then
			local var5 = arg1.controlModule:GetMoveVector()
			local bool1 = true
			if 0.01 >= (arg5 - arg6).magnitude then
				bool1 = 0.01 < var5.magnitude
			end

			if bool1 then
				arg1.motionDetTime = 0.1
			end

			local var6 = arg1.motionDetTime - arg2
			arg1.motionDetTime = var6
			if 0 < arg1.motionDetTime then
				bool1 = true
			end

			if bool1 and (not arg1.needsReset) then
				arg1.VRCameraFocusFrozen = true
				arg4 = arg1.lastCameraFocus
				return arg3, arg4
			end

			var6 = true
			if arg1.lastCameraResetPosition ~= nil then
				var6 = 1 < (arg6 - arg1.lastCameraResetPosition).Magnitude
			end

			local var7 = arg1:getRotation(arg2)
			if 0 < math.abs(var7) then
				arg3 = arg4 * CFrame.Angles(0, -var7, 0) * arg4:ToObjectSpace(arg3)
			end

			if arg1.VRCameraFocusFrozen and var6 or arg1.needsReset then
				var3:RecenterUserHeadCFrame()
				arg1.VRCameraFocusFrozen = false
				arg1.needsReset = false
				arg1.lastCameraResetPosition = arg6
				arg1:ResetZoom()
				arg1:StartFadeFromBlack()
				local var8 = arg1:GetHumanoid()
				local var9 = var8.Torso and var8.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
				local var10 = arg4.Position - Vector3.new(var9.X, 0, var9.Z) * var4
				arg3 = CFrame.new(var10, (Vector3.new(arg4.Position.X, var10.Y, arg4.Position.Z)))
			end
		end
	end

	return arg3, arg4
end

var5.UpdateThirdPersonFollowTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = workspace.CurrentCamera
	local var4 = arg1:GetCameraToSubjectDistance()
	local var5 = arg1:GetVRFocus(arg6, arg2)
	if arg1.needsReset then
		arg1.needsReset = false
		var3:RecenterUserHeadCFrame()
		arg1:ResetZoom()
		arg1:StartFadeFromBlack()
	end

	if arg1.recentered then
		local var7 = arg1:GetSubjectCFrame()
		if not var7 then
			return var1.CFrame, var1.Focus
		end

		arg3 = var5 * var7.Rotation * CFrame.new(0, 0, var4)
		arg1.focusOffset = var5:ToObjectSpace(arg3)
		arg1.recentered = false
		return arg3, var5
	end

	local var8 = arg1.controlModule
	local var12 = var5:ToWorldSpace(arg1.focusOffset)
	if 0.01 < (arg5 - arg6).magnitude or 0 < var8:GetMoveVector().magnitude then
		local var13 = var8:GetEstimatedVRTorsoFrame()
		local var14 = var1.CFrame * (var13.Rotation + var13.Position * var1.HeadScale)
		local var15 = var14.LookVector
		arg3 = var12:Lerp(CFrame.new(var1.CFrame.Position + (var5.Position - Vector3.new(var15.X, 0, var15.Z).Unit * var4) - var14.Position) * var12.Rotation, 0.01)
	else
		arg3 = var12
	end

	local var16 = arg1:getRotation(arg2)
	if 0 < math.abs(var16) then
		arg3 = var5 * CFrame.Angles(0, -var16, 0) * var5:ToObjectSpace(arg3)
	end

	arg1.focusOffset = var5:ToObjectSpace(arg3)
	arg4 = arg3 * CFrame.new(0, 0, -var4)
	if not str3 and 0.01 < (arg4.Position - var1.Focus.Position).Magnitude then
		arg1:StartVREdgeBlur(var2.LocalPlayer)
	end

	return arg3, arg4
end

var5.LeaveFirstPerson = function(arg1)
	str4.LeaveFirstPerson(arg1)
	arg1.needsReset = true
	if arg1.VRBlur then
		arg1.VRBlur.Visible = false
	end

	if arg1.characterOrientation then
		arg1.characterOrientation.Enabled = false
	end

	local var2 = arg1:GetHumanoid()
	if var2 then
		var2.AutoRotate = arg1.savedAutoRotate
	end
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseCamera [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
require(var1:WaitForChild(str2))
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local str4 = "ZoomController"
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "CameraToggleStateController"
str1 = require(script.Parent:WaitForChild(str4))
local str6 = "CameraInput"
str2 = require(script.Parent:WaitForChild(str5))
local str7 = "CameraUI"
str3 = require(script.Parent:WaitForChild(str6))
str4 = require(script.Parent:WaitForChild(str7))
Vector2.new(0, 0)
local var4 = game:GetService("VRService")
local var5 = UserSettings():GetService("UserGameSettings")
str5 = game:GetService("Players").LocalPlayer
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = var2.new()
	var1.gamepadZoomLevels = { 0, 10, 20 }
	var1.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	var1.cameraType = nil
	var1.cameraMovementMode = nil
	var1.lastCameraTransform = nil
	var1.lastUserPanCamera = tick()
	var1.humanoidRootPart = nil
	var1.humanoidCache = {}
	var1.lastSubject = nil
	var1.lastSubjectPosition = Vector3.new(0, 5, 0)
	var1.lastSubjectCFrame = CFrame.new(var1.lastSubjectPosition)
	var1.currentSubjectDistance = math.clamp(12.5, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
	var1.inFirstPerson = false
	var1.inMouseLockedMode = false
	var1.resetCameraAngle = true
	var1.enabled = false
	var1.cameraChangedConn = nil
	var1.shouldUseVRRotation = false
	var1.VRRotationIntensityAvailable = false
	var1.lastVRRotationIntensityCheckTime = 0
	var1.lastVRRotationTime = 0
	var1.vrRotateKeyCooldown = {}
	var1.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	var1.humanoidJumpOrigin = nil
	var1.trackingHumanoid = nil
	var1.cameraFrozen = false
	var1.subjectStateChangedConn = nil
	var1.gamepadZoomPressConnection = nil
	var1.mouseLockOffset = Vector3.new(0, 0, 0)
	var5:SetCameraYInvertVisible()
	var5:SetGamepadCameraSensitivityVisible()
	return var1
end

tbl1.GetModuleName = function(_)
	return "BaseCamera"
end

tbl1._setUpConfigurations = function(arg1)
	local function fn2(arg1)
		arg1:OnCharacterAdded(arg1)
	end

	arg1._connections:trackConnection("CHARACTER_ADDED", str5.CharacterAdded:Connect(fn2))
	arg1.humanoidRootPart = nil
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MODE_CHANGED", str5:GetPropertyChangedSignal("CameraMode"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(fn2))
	arg1:OnPlayerCameraPropertyChange()
end

tbl1.OnCharacterAdded = function(arg1, _)
	local var1 = arg1.resetCameraAngle
	var1 = var1 or arg1:GetEnabled()
	arg1.resetCameraAngle = var1
	arg1.humanoidRootPart = nil
end

tbl1.GetHumanoidRootPart = function(arg1)
	local var2 = str5.Character:FindFirstChildOfClass("Humanoid")
	if not arg1.humanoidRootPart and (str5.Character and var2) then
		arg1.humanoidRootPart = var2.RootPart
	end

	return arg1.humanoidRootPart
end

tbl1.GetBodyPartToFollow = function(_, arg2, _)
	if arg2:GetState() == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			if var3:IsA("Model") then
				local var4 = var3:FindFirstChild("Head")
				return var4 or arg2.RootPart
			end
		end
	end

	return arg2.RootPart
end

tbl1.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectCFrame
	if not var2 then
		return var3
	end

	if var2:IsA("Humanoid") then
		local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
		local var5 = var2.CameraOffset
		if arg1:GetIsMouseLocked() then
			var5 = Vector3.new()
		end

		local var6 = var2.RootPart
		var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
		if var6 then
			if var6:IsA("BasePart") then
				local var13 = nil
				if var2.RigType == Enum.HumanoidRigType.R15 then
					if var2.AutomaticScalingEnabled then
						local var16 = var2.RootPart
						var13 = Vector3.new(0, 1.5, 0)
						if var6 == var16 then
							var13 = var13 + Vector3.new(0, (var16.Size.Y - 2) / 2, 0)
						end
					else
						var13 = Vector3.new(0, 2, 0)
					end
				else
					var13 = Vector3.new(0, 1.5, 0)
				end

				if var4 then
					var13 = Vector3.new(0, 0, 0)
				end

				var3 = var6.CFrame * CFrame.new(var13 + var5)
			end
		end
	else
		if var2:IsA("BasePart") then
			var3 = var2.CFrame
		else
			if var2:IsA("Model") then
				var3 = if var2.PrimaryPart then var2:GetPrimaryPartCFrame() else CFrame.new()
			end
		end
	end

	if var3 then
		arg1.lastSubjectCFrame = var3
	end

	return var3
end

tbl1.GetSubjectVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.Velocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.Velocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.Velocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetSubjectRotVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.RotVelocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.RotVelocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.RotVelocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.StepZoom = function(arg1)
	local var1 = str3.getZoomDelta()
	local var4 = arg1.currentSubjectDistance
	if 0 < math.abs(var1) then
		local var6 = nil
		var6 = if 0 < var1 then math.max(var4 + var1 * (var4 * 0.5 + 1), arg1.FIRST_PERSON_DISTANCE_THRESHOLD) else math.max((var4 + var1) / (1 - var1 * 0.5), 0.5)
		if var6 < arg1.FIRST_PERSON_DISTANCE_THRESHOLD then
			var6 = 0.5
		end

		arg1:SetCameraToSubjectDistance(var6)
	end

	return str1.GetZoomRadius()
end

tbl1.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectPosition
	if var2 then
		if var2:IsA("Humanoid") then
			local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
			local var5 = var2.CameraOffset
			if arg1:GetIsMouseLocked() then
				var5 = Vector3.new()
			end

			local var6 = var2.RootPart
			var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
			if var6 then
				if var6:IsA("BasePart") then
					local var10 = nil
					if var2.RigType == Enum.HumanoidRigType.R15 then
						if var2.AutomaticScalingEnabled then
							var10 = Vector3.new(0, 1.5, 0)
							if var6 == var2.RootPart then
								var10 = var10 + Vector3.new(0, var2.RootPart.Size.Y / 2 - 1, 0)
							end
						else
							var10 = Vector3.new(0, 2, 0)
						end
					else
						var10 = Vector3.new(0, 1.5, 0)
					end

					if var4 then
						var10 = Vector3.new(0, 0, 0)
					end

					var3 = var6.CFrame.p + var6.CFrame:vectorToWorldSpace(var10 + var5)
				end
			end
		else
			if var2:IsA("VehicleSeat") then
				var3 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
			else
				if var2:IsA("SkateboardPlatform") then
					var3 = var2.CFrame.p + Vector3.new(0, 5, 0)
				else
					if var2:IsA("BasePart") then
						var3 = var2.CFrame.p
					else
						if var2:IsA("Model") then
							if var2.PrimaryPart then
								var3 = var2:GetPrimaryPartCFrame().p
							else
								var3 = var2:GetModelCFrame().p
							end
						end
					end
				end
			end
		end
	else
		return nil
	end

	arg1.lastSubject = var2
	arg1.lastSubjectPosition = var3
	return var3
end

tbl1.OnCurrentCameraChanged = function(arg1)
	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
		arg1.cameraSubjectChangedConn = nil
	end

	local var2 = game.Workspace.CurrentCamera
	if var2 then
		arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			arg1:OnNewCameraSubject()
		end)

		arg1:OnNewCameraSubject()
	end
end

tbl1.OnPlayerCameraPropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.InputTranslationToCameraAngleChange = function(_, arg2, arg3)
	return arg2 * arg3
end

tbl1.GamepadZoomPress = function(arg1)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var2 = str5.CameraMaxZoomDistance
	for i1 = #arg1.gamepadZoomLevels, 1, -1 do
		local var3 = arg1.gamepadZoomLevels[i1]
		if var2 < var3 then
			continue
		end

		if var3 < str5.CameraMinZoomDistance then
			var3 = str5.CameraMinZoomDistance
			if var2 == var3 then
				break
			end
		end

		if var3 + (var2 - var3) / 2 < var1 then
			arg1:SetCameraToSubjectDistance(var3)
			return
		end

		local var4 = var3
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
		arg1:OnEnabledChanged()
	end
end

tbl1.OnEnabledChanged = function(arg1)
	if arg1.enabled then
		arg1:_setUpConfigurations()
		str3.setInputEnabled(true)
		arg1.gamepadZoomPressConnection = str3.gamepadZoomPress:Connect(function()
			arg1:GamepadZoomPress()
		end)

		if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		end

		if arg1.cameraChangedConn then
			arg1.cameraChangedConn:Disconnect()
			arg1.cameraChangedConn = nil
		end

		arg1.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			arg1:OnCurrentCameraChanged()
		end)

		arg1:OnCurrentCameraChanged()
		return
	end

	arg1._connections:disconnectAll()
	str3.setInputEnabled(false)
	if arg1.gamepadZoomPressConnection then
		arg1.gamepadZoomPressConnection:Disconnect()
		arg1.gamepadZoomPressConnection = nil
	end

	arg1:Cleanup()
end

tbl1.GetEnabled = function(arg1)
	return arg1.enabled
end

tbl1.Cleanup = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end

	if arg1.cameraChangedConn then
		arg1.cameraChangedConn:Disconnect()
		arg1.cameraChangedConn = nil
	end

	arg1.lastCameraTransform = nil
	arg1.lastSubjectCFrame = nil
	var3.restoreMouseBehavior()
end

tbl1.UpdateMouseBehavior = function(arg1)
	if arg1.isCameraToggle and var5.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove == false then
		str4.setCameraModeToastEnabled(true)
		str3.enableCameraToggleInput()
		str2(arg1.inFirstPerson)
		return
	end

	str4.setCameraModeToastEnabled(false)
	str3.disableCameraToggleInput()
	if arg1.inFirstPerson or arg1.inMouseLockedMode then
		var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
		return
	end

	var3.restoreRotationType()
	if str3.getRotationActivated() then
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
		return
	end

	var3.restoreMouseBehavior()
end

tbl1.UpdateForDistancePropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1.currentSubjectDistance
	if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
		arg1.currentSubjectDistance = 0.5
		if not arg1.inFirstPerson then
			arg1:EnterFirstPerson()
		end
	else
		local var3 = math.clamp(arg2, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
		if var3 < 1 then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		else
			arg1.currentSubjectDistance = var3
			if arg1.inFirstPerson then
				arg1:LeaveFirstPerson()
			end
		end
	end

	str1.SetZoomParameters(arg1.currentSubjectDistance, (math.sign(arg2 - var1)))
	return arg1.currentSubjectDistance
end

tbl1.SetCameraType = function(arg1, arg2)
	arg1.cameraType = arg2
end

tbl1.GetCameraType = function(arg1)
	return arg1.cameraType
end

tbl1.SetCameraMovementMode = function(arg1, arg2)
	arg1.cameraMovementMode = arg2
end

tbl1.GetCameraMovementMode = function(arg1)
	return arg1.cameraMovementMode
end

tbl1.SetIsMouseLocked = function(arg1, arg2)
	arg1.inMouseLockedMode = arg2
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.inMouseLockedMode
end

tbl1.SetMouseLockOffset = function(arg1, arg2)
	arg1.mouseLockOffset = arg2
end

tbl1.GetMouseLockOffset = function(arg1)
	return arg1.mouseLockOffset
end

tbl1.InFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.EnterFirstPerson = function(arg1)
	arg1.inFirstPerson = true
	arg1:UpdateMouseBehavior()
end

tbl1.LeaveFirstPerson = function(arg1)
	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
end

tbl1.GetCameraToSubjectDistance = function(arg1)
	return arg1.currentSubjectDistance
end

tbl1.GetMeasuredDistanceToFocus = function(_)
	local var2 = game.Workspace.CurrentCamera
	if var2 then
		return (var2.CoordinateFrame.p - var2.Focus.p).magnitude
	end

	return nil
end

tbl1.GetCameraLookVector = function(_)
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end

tbl1.CalculateNewLookCFrameFromArg = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 + -1.3962634015954636, var2 + 1.3962634015954636)))
	return CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)
end

tbl1.CalculateNewLookVectorFromArg = function(arg1, arg2, arg3)
	return arg1:CalculateNewLookCFrameFromArg(arg2, arg3).LookVector
end

tbl1.CalculateNewLookVectorVRFromArg = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, 0)
	return ((CFrame.Angles(0, -var1.X, 0) * CFrame.new(Vector3.new(0, 0, 0), ((arg1:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit) * CFrame.Angles(-var1.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end

tbl1.GetHumanoid = function(arg1)
	local var1 = str5
	var1 = var1 and str5.Character
	if var1 then
		local var4 = arg1.humanoidCache[str5]
		if var4 and var4.Parent == var1 then
			return var4
		end

		arg1.humanoidCache[str5] = nil
		local var6 = var1:FindFirstChildOfClass("Humanoid")
		if var6 then
			arg1.humanoidCache[str5] = var6
		end

		return var6
	end

	return nil
end

tbl1.GetHumanoidPartToFollow = function(_, arg2, arg3)
	if arg3 == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			local var4 = var3:FindFirstChild("Head")
			return var4 or arg2.Torso
		end

		return arg2.Torso
	end

	return arg2.Torso
end

tbl1.OnNewCameraSubject = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end
end

tbl1.IsInFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.Update = function(_, _)
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end

tbl1.GetCameraHeight = function(arg1)
	if var4.VREnabled and (not arg1.inFirstPerson) then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Invisicam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("Players")
local var3 = RaycastParams.new()
var3.FilterType = Enum.RaycastFilterType.Exclude
local var4 = RaycastParams.new()
var4.FilterType = Enum.RaycastFilterType.Include
local str2 = "BaseOcclusion"
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = setmetatable({}, var5)
var6.__index = var6
local tbl1 = {
	LIMBS = 2,
	MOVEMENT = 3,
	CORNERS = 4,
	CIRCLE1 = 5,
	CIRCLE2 = 6,
	LIMBMOVE = 7,
	SMART_CIRCLE = 8,
	CHAR_OUTLINE = 9,
}

var6.new = function()
	local var1 = setmetatable(var5.new(), var6)
	var1.char = nil
	var1.humanoidRootPart = nil
	var1.torsoPart = nil
	var1.headPart = nil
	var1.childAddedConn = nil
	var1.childRemovedConn = nil
	var1.behaviors = {}
	var1.behaviors[tbl1.LIMBS] = var1.LimbBehavior
	var1.behaviors[tbl1.MOVEMENT] = var1.MoveBehavior
	var1.behaviors[tbl1.CORNERS] = var1.CornerBehavior
	var1.behaviors[tbl1.CIRCLE1] = var1.CircleBehavior
	var1.behaviors[tbl1.CIRCLE2] = var1.CircleBehavior
	var1.behaviors[tbl1.LIMBMOVE] = var1.LimbMoveBehavior
	var1.behaviors[tbl1.SMART_CIRCLE] = var1.SmartCircleBehavior
	var1.behaviors[tbl1.CHAR_OUTLINE] = var1.CharacterOutlineBehavior
	var1.mode = tbl1.SMART_CIRCLE
	var1.behaviorFunction = var1.SmartCircleBehavior
	var1.savedHits = {}
	var1.trackedLimbs = {}
	var1.camera = game.Workspace.CurrentCamera
	var1.enabled = false
	return var1
end

var6.Enable = function(arg1, arg2)
	arg1.enabled = arg2
	if not arg2 then
		arg1:Cleanup()
	end
end

var6.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Invisicam
end

var6.LimbBehavior = function(arg1, arg2)
	for k1, v1 in pairs(arg1.trackedLimbs) do
		arg2[#arg2 + 1] = k1.Position
	end
end

var6.MoveBehavior = function(arg1, arg2)
	for i1 = 1, 3 do
		local var1 = arg1.humanoidRootPart.Velocity
		arg2[#arg2 + 1] = arg1.humanoidRootPart.Position + (i1 - 1) * arg1.humanoidRootPart.CFrame.lookVector * (Vector3.new(var1.X, 0, var1.Z).Magnitude / 2)
	end
end

local tbl2 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1),
}

var6.CornerBehavior = function(arg1, arg2)
	local var1 = arg1.humanoidRootPart.CFrame
	local var2 = var1.Position
	local var3 = arg1.char:GetExtentsSize() / 2
	arg2[#arg2 + 1] = var2
	for i1 = 1, #tbl2 do
		local var4 = var1 - var2
		arg2[#arg2 + 1] = var2 + var4 * (var3 * tbl2[i1])
	end
end

var6.CircleBehavior = function(arg1, arg2)
	local var2 = nil
	if arg1.mode == tbl1.CIRCLE1 then
		var2 = arg1.humanoidRootPart.CFrame
	else
		local var3 = arg1.camera.CoordinateFrame
		var2 = var3 - var3.Position + arg1.humanoidRootPart.Position
	end

	arg2[#arg2 + 1] = var2.Position
	for i1 = 0, 9 do
		local var4 = 0.62831853071795862 * i1
		arg2[#arg2 + 1] = var2 * (Vector3.new(math.cos(var4), math.sin(var4), 0) * 3)
	end
end

var6.LimbMoveBehavior = function(arg1, arg2)
	arg1:LimbBehavior(arg2)
	arg1:MoveBehavior(arg2)
end

var6.CharacterOutlineBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var3 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var3
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var3
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = CFrame.new(Vector3.new(0, 0, 0), (Vector3.new(arg1.camera.CoordinateFrame.lookVector.X, 0, arg1.camera.CoordinateFrame.lookVector.Z)))
	local var6 = arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position
	local tbl2 = { arg1.torsoPart }
	if arg1.headPart then
		tbl2[#tbl2 + 1] = arg1.headPart
	end

	for i1 = 1, 24 do
		local var7 = 6.2831853071795862 * i1 / 24
		local var8 = var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 3)
		var8 = Vector3.new(var8.X, math.max(var8.Y, -2.25), var8.Z)
		if var1 then
			var4.FilterDescendantsInstances = tbl2
			local var9 = game.Workspace:Raycast(var6 + var8, -3 * var8, var4)
			if not var9 then
				continue
			end

			local var10 = var9.Position
			arg2[#arg2 + 1] = var10 + 0.2 * (var6 - var10).unit
		else
			local var11, var12 = game.Workspace:FindPartOnRayWithWhitelist(Ray.new(var6 + var8, -3 * var8), tbl2, false)
			if not var11 then
				continue
			end

			arg2[#arg2 + 1] = var12 + 0.2 * (var6 - var12).unit
		end
	end
end

local function RayIntersection(arg1, arg2, arg3, arg4)
	local var1 = arg2:Cross(arg4)
	local var2 = -arg4.Y
	local var3 = var1.Z
	local var4 = var1.Y
	local var5 = -arg4.Z
	local var6 = arg2.Y
	local var7 = arg2.Z
	local var9 = arg2.X * (var2 * var3 - var4 * var5) - -arg4.X * (var6 * var3 - var4 * var7) + var1.X * (var6 * var5 - var2 * var7)
	local var10 = arg3.X - arg1.X
	local var11 = arg3.Y - arg1.Y
	local var12 = arg3.Z - arg1.Z
	if var9 == 0 then
		return Vector3.new(0, 0, 0)
	end

	var2 = -arg4.Y
	var5 = var1.Z
	var4 = var1.Y
	var7 = -arg4.Z
	local var13 = (var10 * (var2 * var5 - var4 * var7) - -arg4.X * (var11 * var5 - var4 * var12) + var1.X * (var11 * var7 - var2 * var12)) / var9
	var3 = var1.Z
	var7 = var1.Y
	var4 = arg2.Y
	var5 = arg2.Z
	var6 = arg3 + (arg2.X * (var11 * var3 - var7 * var12) - var10 * (var4 * var3 - var7 * var5) + var1.X * (var4 * var12 - var11 * var5)) / var9 * arg4
	local var14 = arg1 + var13 * arg2
	var2 = var14 + (var6 - var14) * 0.5
	if (var6 - var14).Magnitude < 0.25 then
		return var2
	end

	return Vector3.new(0, 0, 0)
end

var6.SmartCircleBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var4 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var4
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var4
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = arg1.camera.CFrame - arg1.camera.CFrame.p
	local var6 = Vector3.new(0, 0.5, 0) + (arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position)
	for i1 = 1, 24 do
		local var7 = 0.26179938779914941 * i1 - 1.5707963267948966
		local var8 = var6 + var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 2.5)
		local var9 = var8 - arg1.camera.CFrame.p
		if var1 then
			var3.FilterDescendantsInstances = { arg1.char }
			local var16 = game.Workspace:Raycast(var6, var8 - var6, var3)
			local var17 = var8
			if var16 then
				local var18 = var16.Normal
				local var19 = var16.Position + 0.1 * var18.unit
				local var20 = var19 - var6
				local var21 = var20:Cross(var9).unit:Cross(var18).unit
				if var20.unit:Dot(-var21) < var20.unit:Dot((var19 - arg1.camera.CFrame.p).unit) then
					var17 = RayIntersection(var19, var21, var8, var9)
					if 0 < var17.Magnitude then
						var16 = game.Workspace:Raycast(var19, var17 - var19, var3)
						if var16 then
							var17 = var16.Position + 0.1 * var16.Normal.Unit
						end
					else
						var17 = var19
					end
				else
					var17 = var19
				end

				var16 = game.Workspace:Raycast(var6, var17 - var6, var3)
				if var16 then
					var17 = var16.Position - 0.1 * (var17 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var17
		else
			local var28, var29, var30 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var8 - var6), { arg1.char }, false, false)
			local var31 = var8
			if var28 then
				local var32 = var29 + 0.1 * var30.unit
				local var33 = var32 - var6
				local var34 = var33:Cross(var9).unit:Cross(var30).unit
				if var33.unit:Dot(-var34) < var33.unit:Dot((var32 - arg1.camera.CFrame.p).unit) then
					var31 = RayIntersection(var32, var34, var8, var9)
					if 0 < var31.Magnitude then
						local var37, var38, var39 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var32, var31 - var32), { arg1.char }, false, false)
						if var37 then
							var31 = var38 + 0.1 * var39.unit
						end
					else
						var31 = var32
					end
				else
					var31 = var32
				end

				local var41, var42, var43 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var31 - var6), { arg1.char }, false, false)
				if var41 then
					var31 = var42 - 0.1 * (var31 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var31
		end
	end
end

var6.CheckTorsoReference = function(arg1)
	if arg1.char then
		arg1.torsoPart = arg1.char:FindFirstChild("Torso")
		if not arg1.torsoPart then
			arg1.torsoPart = arg1.char:FindFirstChild("UpperTorso")
			if not arg1.torsoPart then
				arg1.torsoPart = arg1.char:FindFirstChild("HumanoidRootPart")
			end
		end

		arg1.headPart = arg1.char:FindFirstChild("Head")
	end
end

str1 = {
	Head = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	LeftLowerArm = true,
	RightLowerArm = true,
	LeftUpperLeg = true,
	RightUpperLeg = true,
}

var6.CharacterAdded = function(arg1, arg2, arg3)
	if arg3 ~= var2.LocalPlayer then
		return
	end

	if arg1.childAddedConn then
		arg1.childAddedConn:Disconnect()
		arg1.childAddedConn = nil
	end

	if arg1.childRemovedConn then
		arg1.childRemovedConn:Disconnect()
		arg1.childRemovedConn = nil
	end

	arg1.char = arg2
	arg1.trackedLimbs = {}
	arg1.childAddedConn = arg2.ChildAdded:Connect(function(arg1)
		if arg1:IsA("BasePart") then
			if str1[arg1.Name] then
				arg1.trackedLimbs[arg1] = true
			end

			if arg1.Name == "Torso" or arg1.Name == "UpperTorso" then
				arg1.torsoPart = arg1
			end

			if arg1.Name == "Head" then
				arg1.headPart = arg1
			end
		end
	end)

	arg1.childRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		arg1.trackedLimbs[arg1] = nil
		arg1:CheckTorsoReference()
	end)

	for k1, v1 in pairs(arg1.char:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if str1[v1.Name] then
			arg1.trackedLimbs[v1] = true
		end

		if v1.Name == "Torso" or v1.Name == "UpperTorso" then
			arg1.torsoPart = v1
		end

		if v1.Name ~= "Head" then
			continue
		end

		arg1.headPart = v1
	end
end

local function AssertTypes(arg1, ...)
	local tbl1 = {}
	local str1 = ""
	for k1, v1 in pairs({ ... }) do
		tbl1[v1] = true
		local var1 = str1
		str1 = var1 .. (if str1 == "" then "" else " or ") .. v1
	end

	local var2 = type(arg1)
	assert(tbl1[var2], str1 .. " type expected, got: " .. var2)
end

var6.SetMode = function(arg1, arg2)
	AssertTypes(arg2, "number")
	for k1, v1 in pairs(tbl1) do
		if v1 ~= arg2 then
			continue
		end

		arg1.mode = arg2
		arg1.behaviorFunction = arg1.behaviors[arg1.mode]
		return
	end

	error("Invalid mode number")
end

var6.GetObscuredParts = function(arg1)
	return arg1.savedHits
end

var6.Cleanup = function(arg1)
	for k1, v1 in pairs(arg1.savedHits) do
		k1.LocalTransparencyModifier = v1
	end
end

var6.Update = function(arg1, _, arg3, arg4)
	if not arg1.enabled or (not arg1.char) then
		return arg3, arg4
	end

	arg1.camera = game.Workspace.CurrentCamera
	if not arg1.humanoidRootPart then
		local var3 = arg1.char:FindFirstChildOfClass("Humanoid")
		if var3 and var3.RootPart then
			arg1.humanoidRootPart = var3.RootPart
		else
			arg1.humanoidRootPart = arg1.char:FindFirstChild("HumanoidRootPart")
			if not arg1.humanoidRootPart then
				return arg3, arg4
			end
		end

		local var4 = nil
		arg1.humanoidRootPart.AncestryChanged:Connect(function(arg1, arg2)
			if arg1 == arg1.humanoidRootPart and (not arg2) then
				arg1.humanoidRootPart = nil
				if var4 and var4.Connected then
					var4:Disconnect()
					var4 = nil
				end
			end
		end)

	end

	if not arg1.torsoPart then
		arg1:CheckTorsoReference()
		if not arg1.torsoPart then
			return arg3, arg4
		end
	end

	local tbl1 = {}
	arg1.behaviorFunction(arg1, tbl1)
	local tbl2 = {}
	local tbl3 = { arg1.char }
	local var5 = nil
	var5 = arg1.camera:GetPartsObscuringTarget({
		arg1.headPart and arg1.headPart.CFrame.p or tbl1[1],
		arg1.torsoPart and arg1.torsoPart.CFrame.p or tbl1[2],
	}, tbl3)

	local num1 = 0
	local tbl4 = {}
	local num2 = 0.75
	local num3 = 0.75
	for i1 = 1, #var5 do
		local var6 = var5[i1]
		tbl4[var6] = true
		num1 = num1 + 1
		for k1, v1 in pairs(var6:GetChildren()) do
			if v1:IsA("Decal") or v1:IsA("Texture") then
				num1 = num1 + 1
				break
			end
		end
	end

	if 0 < num1 then
		num2 = math.pow(0.375 / num1 + 0.375, 1 / num1)
		num3 = math.pow(0.25 / num1 + 0.25, 1 / num1)
	end

	var5 = arg1.camera:GetPartsObscuringTarget(tbl1, tbl3)
	local tbl5 = {}
	for i2 = 1, #var5 do
		local var7 = var5[i2]
		tbl5[var7] = tbl4[var7] and num2 or num3
		if var7.Transparency < tbl5[var7] then
			tbl2[var7] = true
			if not arg1.savedHits[var7] then
				arg1.savedHits[var7] = var7.LocalTransparencyModifier
			end
		end

		for k2, v2 in pairs(var7:GetChildren()) do
			if (v2:IsA("Decal") or v2:IsA("Texture")) and v2.Transparency < tbl5[var7] then
				local var8 = tbl5[var7]
				tbl5[v2] = var8
				tbl2[v2] = true
				if arg1.savedHits[v2] then
					continue
				end

				arg1.savedHits[v2] = v2.LocalTransparencyModifier
			end
		end
	end

	for k3, v3 in pairs(arg1.savedHits) do
		if tbl2[k3] then
			k3.LocalTransparencyModifier = k3.Transparency < 1 and (tbl5[k3] - k3.Transparency) / (1 - k3.Transparency) or 0
		else
			k3.LocalTransparencyModifier = v3
			arg1.savedHits[k3] = nil
		end
	end

	return arg3, arg4
end

return var6

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
setmetatable(tbl1, { __call = function(_, ...)
	return tbl1.new(...)
end })

tbl1.new = function()
	return (setmetatable({}, tbl1))
end

tbl1.CharacterAdded = function(_, _, _)
end

tbl1.CharacterRemoving = function(_, _, _)
end

tbl1.OnCameraSubjectChanged = function(_, _)
end

tbl1.GetOcclusionMode = function(_)
	warn("BaseOcclusion GetOcclusionMode must be overridden by derived classes")
	return nil
end

tbl1.Enable = function(_, _)
	warn("BaseOcclusion Enable must be overridden by derived classes")
end

tbl1.Update = function(_, _, arg3, arg4)
	warn("BaseOcclusion Update must be overridden by derived classes")
	return arg3, arg4
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixOrbitalCameraAzimuth")
local str2 = "CameraUtils"
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
str2 = require(script.Parent:WaitForChild(str4))
local var3 = game:GetService("Players")
str3 = setmetatable({}, str2)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(str2.new(), str3)
	var1.lastUpdate = tick()
	var1.changedSignalConnections = {}
	var1.refAzimuthRad = nil
	var1.curAzimuthRad = nil
	var1.minAzimuthAbsoluteRad = nil
	var1.maxAzimuthAbsoluteRad = nil
	var1.useAzimuthLimits = nil
	var1.curElevationRad = nil
	var1.minElevationRad = nil
	var1.maxElevationRad = nil
	var1.curDistance = nil
	var1.minDistance = nil
	var1.maxDistance = nil
	var1.gamepadDollySpeedMultiplier = 1
	var1.lastUserPanCamera = tick()
	var1.externalProperties = {}
	var1.externalProperties.InitialDistance = 25
	var1.externalProperties.MinDistance = 10
	var1.externalProperties.MaxDistance = 100
	var1.externalProperties.InitialElevation = 35
	var1.externalProperties.MinElevation = 35
	var1.externalProperties.MaxElevation = 35
	var1.externalProperties.ReferenceAzimuth = -45
	var1.externalProperties.CWAzimuthTravel = 90
	var1.externalProperties.CCWAzimuthTravel = 90
	var1.externalProperties.UseAzimuthLimits = false
	var1:LoadNumberValueParameters()
	return var1
end

str3.LoadOrCreateNumberValueParameter = function(arg1, arg2, arg3, arg4)
	local var2 = script:FindFirstChild(arg2)
	if var2 and var2:IsA(arg3) then
		arg1.externalProperties[arg2] = var2.Value
	else
		if arg1.externalProperties[arg2] ~= nil then
			var2 = Instance.new(arg3)
			var2.Name = arg2
			var2.Parent = script
			var2.Value = arg1.externalProperties[arg2]
		else
			return
		end
	end

	if arg4 then
		if arg1.changedSignalConnections[arg2] then
			arg1.changedSignalConnections[arg2]:Disconnect()
		end

		arg1.changedSignalConnections[arg2] = var2.Changed:Connect(function(arg1)
			arg1.externalProperties[arg2] = arg1
			arg4(arg1)
		end)

	end
end

str3.SetAndBoundsCheckAzimuthValues = function(arg1)
	arg1.minAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) - math.abs((math.rad(arg1.externalProperties.CWAzimuthTravel)))
	arg1.maxAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) + math.abs((math.rad(arg1.externalProperties.CCWAzimuthTravel)))
	arg1.useAzimuthLimits = arg1.externalProperties.UseAzimuthLimits
	if arg1.useAzimuthLimits then
		local var1 = math.max(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
		var1 = math.min(arg1.curAzimuthRad, arg1.maxAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
	end
end

str3.SetAndBoundsCheckElevationValues = function(arg1)
	local var1 = math.max(arg1.externalProperties.MinElevation, -80)
	local var2 = math.min(arg1.externalProperties.MaxElevation, 80)
	arg1.minElevationRad = math.rad((math.min(var1, var2)))
	arg1.maxElevationRad = math.rad((math.max(var1, var2)))
	local var3 = math.max(arg1.curElevationRad, arg1.minElevationRad)
	arg1.curElevationRad = var3
	var3 = math.min(arg1.curElevationRad, arg1.maxElevationRad)
	arg1.curElevationRad = var3
end

str3.SetAndBoundsCheckDistanceValues = function(arg1)
	arg1.minDistance = arg1.externalProperties.MinDistance
	arg1.maxDistance = arg1.externalProperties.MaxDistance
	local var1 = math.max(arg1.curDistance, arg1.minDistance)
	arg1.curDistance = var1
	var1 = math.min(arg1.curDistance, arg1.maxDistance)
	arg1.curDistance = var1
end

str3.LoadNumberValueParameters = function(arg1)
	arg1:LoadOrCreateNumberValueParameter("InitialElevation", "NumberValue", nil)
	arg1:LoadOrCreateNumberValueParameter("InitialDistance", "NumberValue", nil)
	local str1 = "ReferenceAzimuth"
	local str2 = "NumberValue"
	arg1:LoadOrCreateNumberValueParameter(str1, str2, if var1 then arg1.SetAndBoundsCheckAzimuthValues else arg1.SetAndBoundsCheckAzimuthValue)
	arg1:LoadOrCreateNumberValueParameter("CWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("CCWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("MinElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MaxElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MinDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("MaxDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("UseAzimuthLimits", "BoolValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1.curAzimuthRad = math.rad(arg1.externalProperties.ReferenceAzimuth)
	arg1.curElevationRad = math.rad(arg1.externalProperties.InitialElevation)
	arg1.curDistance = arg1.externalProperties.InitialDistance
	arg1:SetAndBoundsCheckAzimuthValues()
	arg1:SetAndBoundsCheckElevationValues()
	arg1:SetAndBoundsCheckDistanceValues()
end

str3.GetModuleName = function(_)
	return "OrbitalCamera"
end

str3.SetInitialOrientation = function(arg1, arg2)
	if not arg2 or (not arg2.RootPart) then
		warn("OrbitalCamera could not set initial orientation due to missing humanoid")
		return
	end

	assert(arg2.RootPart, "")
	local var1 = (arg2.RootPart.CFrame.LookVector - Vector3.new(0, 0.23, 0)).Unit
	local var2 = math.asin(arg1:GetCameraLookVector().Y) - math.asin(var1.Y)
	if not str1.IsFinite((str1.GetAngleBetweenXZVectors(var1, arg1:GetCameraLookVector()))) then
	end

	if not str1.IsFinite(var2) then
	end
end

str3.GetCameraToSubjectDistance = function(arg1)
	return arg1.curDistance
end

str3.SetCameraToSubjectDistance = function(arg1, arg2)
	if var3.LocalPlayer then
		arg1.currentSubjectDistance = math.clamp(arg2, arg1.minDistance, arg1.maxDistance)
		local var1 = math.max(arg1.currentSubjectDistance, arg1.FIRST_PERSON_DISTANCE_THRESHOLD)
		arg1.currentSubjectDistance = var1
	end

	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
	return arg1.currentSubjectDistance
end

str3.CalculateNewLookVector = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 - 1.3962634015954636, var2 - -1.3962634015954636)))
	return (CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)).LookVector
end

str3.Update = function(arg1, arg2)
	local var1 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4
	var5 = var5 and var4.CameraSubject
	local var6 = var5
	local var7 = var5
	local var8 = var2.getRotation(arg2) ~= Vector2.new()
	local var9 = var4.CFrame
	local var10 = var4.Focus
	local var11 = var3.LocalPlayer
	var6 = var6 and var5:IsA("VehicleSeat")
	var7 = var7 and var5:IsA("SkateboardPlatform")
	if arg1.lastUpdate == nil or 1 < var1 - arg1.lastUpdate then
		arg1.lastCameraTransform = nil
	end

	if var8 then
		arg1.lastUserPanCamera = tick()
	end

	local var13 = arg1:GetSubjectPosition()
	if var13 then
		if var11 then
			if var4 then
				if arg1.gamepadDollySpeedMultiplier ~= 1 then
					arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance * arg1.gamepadDollySpeedMultiplier)
				end

				local var14 = var2.getRotation(arg2)
				var10 = CFrame.new(var13)
				local var15 = arg1.curAzimuthRad - var14.X
				arg1.curAzimuthRad = var15
				if arg1.useAzimuthLimits then
					var15 = math.clamp(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad, arg1.maxAzimuthAbsoluteRad)
					arg1.curAzimuthRad = var15
				else
					if arg1.curAzimuthRad ~= 0 then
						var15 = math.sign(arg1.curAzimuthRad) * (math.abs(arg1.curAzimuthRad) % 6.2831853071795862)
						var15 = var15 or 0
					end

					arg1.curAzimuthRad = 0
				end

				var15 = math.clamp(arg1.curElevationRad + var14.Y, arg1.minElevationRad, arg1.maxElevationRad)
				arg1.curElevationRad = var15
				var9 = CFrame.new(var13 + arg1.currentSubjectDistance * (CFrame.fromEulerAnglesYXZ(-arg1.curElevationRad, arg1.curAzimuthRad, 0) * Vector3.new(0, 0, 1)), var13)
				arg1.lastCameraTransform = var9
				arg1.lastCameraFocus = var10
				if (var6 or var7) and var5:IsA("BasePart") then
					arg1.lastSubjectCFrame = var5.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var1
	return var9, var10
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraInput [ModuleScript]
-- y u r i

game:GetService("RunService")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Instance.new("BindableEvent")
local var3 = nil
local var4 = Instance.new("BindableEvent")
local var5 = nil
local var6 = game:GetService("UserInputService")
var6.InputBegan:Connect(function(arg1, arg2)
	if not arg2 and arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var2:Fire()
	end
end)

var6.InputEnded:Connect(function(arg1, _)
	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var4:Fire()
	end
end)

var3 = var2.Event
var2 = nil
var5 = var4.Event
local var7 = game:GetService("Players").LocalPlayer
local num1 = 0
local var8 = game:GetService("ContextActionService")
local var9 = UserSettings():GetService("UserGameSettings")
local var10 = game:GetService("VRService")
local var11 = game:GetService("GuiService")
local var12 = var1.getUserFlag("UserPSSinkUnknownTouchEvents")
local var13 = var1.getUserFlag("UserPSTextboxResetCameraInput")
str1 = var1.getUserFlag("UserFixVRCameraGamepadReset")
local var14 = var1.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local var15 = Vector2.new(1, 0.77) * 0.069813170079773182 * 60
local var16 = Vector2.new(1, 0.77) * 0.0087266462599716477
local var17 = Vector2.new(1, 0.77) * 0.12217304763960307
local var18 = Vector2.new(1, 0.66) * 0.017453292519943295
local tbl1 = { Thumbstick2 = Vector2.new(), ButtonLeft = 0, ButtonRight = 0 }
local tbl2 = { Movement = Vector2.new(), Wheel = 0, Pinch = 0 }
tbl2.Pan = Vector2.new()
local var19 = Instance.new("BindableEvent")
local tbl3 = { Move = Vector2.new(), Pinch = 0 }
local var21 = Enum.ContextActionPriority.Medium.Value
var2 = function(arg1)
	return math.sign(arg1) * math.clamp((math.exp((math.abs(arg1) - 0.1) / 0.9 * 2) - 1) / 6.3890560989306504, 0, 1)
end

var4 = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return arg1
	end

	local var3 = var2.CFrame:ToEulerAnglesYXZ()
	if 0 <= arg1.Y * var3 then
		return arg1
	end

	return Vector2.new(1, (1 - (math.abs(var3) * 2 / 3.1415926535897931) ^ 0.75) * 0.75 + 0.25) * arg1
end

local function isInDynamicThumbstickArea(arg1)
	local var1 = var7:FindFirstChildOfClass("PlayerGui")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TouchGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("TouchControlFrame")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("DynamicThumbstickFrame")
	if not var4 then
		return false
	end

	if not var2.Enabled then
		return false
	end

	local var5 = var4.AbsolutePosition
	local var8 = var5 + var4.AbsoluteSize
	local bool2 = false
	if var5.X <= arg1.X then
		bool2 = false
		if var5.Y <= arg1.Y then
			bool2 = false
			if arg1.X <= var8.X then
				bool2 = arg1.Y <= var8.Y
			end
		end
	end

	return bool2
end

local function incPanInputCount()
	local var1 = math.max(0, num1 + 1)
	num1 = var1
end

local function decPanInputCount()
	local var1 = math.max(0, num1 - 1)
	num1 = var1
end

local function resetPanInputCount()
	num1 = 0
end

local var22 = nil
local tbl4 = { gamepadZoomPress = var19.Event }
local tbl5 = {}
local tbl6 = { Left = 0, Right = 0, I = 0, O = 0 }
if str1 then
	var22 = Instance.new("BindableEvent")
	tbl4.gamepadReset = var22.Event
else
	var22 = var10.VREnabled and Instance.new("BindableEvent") or nil
	if var10.VREnabled then
		tbl4.gamepadReset = var22.Event
	end
end

tbl4.getRotationActivated = function()
	if var14 then
		local bool3 = true
		if 0 >= num1 then
			bool3 = true
			if 0 >= tbl1.Thumbstick2.Magnitude then
				bool3 = tbl1.ButtonRight - tbl1.ButtonLeft ~= 0
			end
		end

		return bool3
	end

	local bool4 = true
	if 0 >= num1 then
		bool4 = 0 < tbl1.Thumbstick2.Magnitude
	end

	return bool4
end

tbl4.getRotation = function(arg1, arg2)
	local var2 = Vector2.new(1, var9:GetCameraYInvertValue())
	local var3 = Vector2.new(tbl6.Right - tbl6.Left, 0) * arg1
	local var5 = nil
	var5 = if var14 then (tbl1.Thumbstick2 + Vector2.new(tbl1.ButtonRight - tbl1.ButtonLeft, 0)) * var9.GamepadCameraSensitivity * arg1 else tbl1.Thumbstick2 * var9.GamepadCameraSensitivity * arg1
	local var6 = tbl2.Movement
	local var7 = tbl2.Pan
	local var8 = var4(tbl3.Move)
	if arg2 then
		var3 = Vector2.new()
	end

	return (var3 * 2.0943951023931953 + var5 * var15 + var6 * var16 + var7 * var17 + var8 * var18) * var2
end

tbl4.getZoomDelta = function()
	return (tbl6.O - tbl6.I) * 0.1 + (-tbl2.Wheel + tbl2.Pinch) * 1 + -tbl3.Pinch * 0.04
end

local var23 = nil
local tbl7 = {}
local var24 = nil
local var25 = nil
local var26 = nil
local var27 = nil
local var28 = nil
var24 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Begin)
	if var23 == nil and (isInDynamicThumbstickArea(arg1.Position) and (not arg2)) then
		var23 = arg1
		return
	end

	if not arg2 then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end

	tbl7[arg1] = arg2
end

var27 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Change)
	if arg1 == var23 then
		return
	end

	if tbl7[arg1] == nil then
		if var12 then
			tbl7[arg1] = true
		else
			tbl7[arg1] = arg2
		end
	end

	local tbl1 = {}
	for k1, v1 in pairs(tbl7) do
		if v1 then
			continue
		end

		table.insert(tbl1, k1)
	end

	if #tbl1 == 1 and tbl7[arg1] == false then
		local var3 = tbl3
		local var4 = arg1.Delta
		local var5 = var3.Move + Vector2.new(var4.X, var4.Y)
		var3.Move = var5
	end

	if #tbl1 == 2 then
		local var10 = (tbl1[1].Position - tbl1[2].Position).Magnitude
		if var25 then
			local var11 = tbl3
			local var13 = var11.Pinch + (var10 - var25)
			var11.Pinch = var13
		end

		var25 = var10
		return
	end

	var25 = nil
end

var26 = function(arg1, _)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.End)
	if arg1 == var23 then
		var23 = nil
	end

	if tbl7[arg1] == false then
		var25 = nil
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end

	tbl7[arg1] = nil
end

local bool1 = false
local function resetInputDevices()
	local var1 = tbl6
	for k1, v1 in pairs({ tbl1, var1, tbl2, tbl3 }) do
		for k2, v2 in pairs(v1) do
			if type(v2) == "boolean" then
				v1[k2] = false
			else
				local var2 = v1[k2] * 0
				v1[k2] = var2
			end
		end
	end

	num1 = 0
end

var28 = function()
	tbl7 = {}
	var23 = nil
	var25 = nil
	num1 = 0
end

local function thumbstick(_, _, arg3)
	local var1 = arg3.Position
	tbl1[arg3.KeyCode.Name] = Vector2.new(var2(var1.X), -var2(var1.Y))
	return Enum.ContextActionResult.Pass
end

local function directionalButtons(_, arg2, arg3)
	if arg2 == Enum.UserInputState.Cancel then
		tbl1[arg3.KeyCode.Name] = 0
	else
		tbl1[arg3.KeyCode.Name] = var2(arg3.Position.Z)
	end

	return Enum.ContextActionResult.Pass
end

local function keypress(_, arg2, arg3)
	local var1 = tbl6
	local var2 = arg3.KeyCode.Name
	var1[var2] = if arg2 == Enum.UserInputState.Begin then 1 else 0
end

local function gamepadReset(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var22:Fire()
	end
end

local function gamepadZoomPress(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var19:Fire()
	end
end

var23 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var24(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 and (not arg2) then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end
end

var25 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var27(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement then
		local var2 = arg1.Delta
		tbl2.Movement = Vector2.new(var2.X, var2.Y)
	end
end

local function inputEnded(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var26(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end
end

tbl7 = function(arg1, arg2, arg3, arg4)
	if not arg4 then
		tbl2.Wheel = arg1
		tbl2.Pan = arg2
		tbl2.Pinch = -arg3
	end
end

tbl4.setInputEnabled = function(arg1)
	if bool1 == arg1 then
		return
	end

	bool1 = arg1
	resetInputDevices()
	var28()
	local var1
	if bool1 then
		var8:BindActionAtPriority("RbxCameraThumbstick", thumbstick, false, var21, Enum.KeyCode.Thumbstick2)
		if var14 then
			var8:BindActionAtPriority("RbxCameraDirectionalButtons", directionalButtons, false, var21, Enum.KeyCode.ButtonLeft, Enum.KeyCode.ButtonRight)
		end

		var8:BindActionAtPriority("RbxCameraKeypress", keypress, false, var21, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.I, Enum.KeyCode.O)
		if var10.VREnabled then
			var8:BindAction("RbxCameraGamepadReset", gamepadReset, false, Enum.KeyCode.ButtonL3)
		end

		var8:BindAction("RbxCameraGamepadZoom", gamepadZoomPress, false, Enum.KeyCode.ButtonR3)
		var1 = var23
		table.insert(tbl5, var6.InputBegan:Connect(var1))
		var1 = var25
		table.insert(tbl5, var6.InputChanged:Connect(var1))
		var1 = inputEnded
		table.insert(tbl5, var6.InputEnded:Connect(var1))
		var1 = tbl7
		table.insert(tbl5, var6.PointerAction:Connect(var1))
		var1 = var28
		table.insert(tbl5, var11.MenuOpened:connect(var1))
		return
	end

	var8:UnbindAction("RbxCameraThumbstick")
	if var14 then
		var8:UnbindAction("RbxCameraDirectionalButtons")
	end

	var8:UnbindAction("RbxCameraMouseMove")
	var8:UnbindAction("RbxCameraMouseWheel")
	var8:UnbindAction("RbxCameraKeypress")
	var8:UnbindAction("RbxCameraGamepadZoom")
	if var10.VREnabled then
		var8:UnbindAction("RbxCameraGamepadReset")
	end

	for k1, v1 in pairs(tbl5) do
		v1:Disconnect()
	end

	tbl5 = {}
end

tbl4.getInputEnabled = function()
	return bool1
end

tbl4.resetInputForFrameEnd = function()
	tbl2.Movement = Vector2.new()
	tbl3.Move = Vector2.new()
	tbl3.Pinch = 0
	tbl2.Wheel = 0
	tbl2.Pan = Vector2.new()
	tbl2.Pinch = 0
end

var6.WindowFocused:Connect(resetInputDevices)
var6.WindowFocusReleased:Connect(resetInputDevices)
if var13 then
	var6.TextBoxFocusReleased:Connect(resetInputDevices)
end

tbl5 = false
tbl4.getHoldPan = function()
	return tbl5
end

num1 = false
tbl4.getTogglePan = function()
	return num1
end

tbl4.getPanning = function()
	local var1 = num1
	return var1 or tbl5
end

tbl4.setTogglePan = function(arg1)
	num1 = arg1
end

decPanInputCount = false
resetPanInputCount = nil
tbl1 = nil
incPanInputCount = 0
tbl4.enableCameraToggleInput = function()
	if decPanInputCount then
		return
	end

	decPanInputCount = true
	tbl5 = false
	num1 = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
	end

	if tbl1 then
		tbl1:Disconnect()
	end

	resetPanInputCount = var3:Connect(function()
		tbl5 = true
		incPanInputCount = tick()
	end)

	tbl1 = var5:Connect(function()
		tbl5 = false
		if tick() - incPanInputCount < 0.3 and (num1 or var6:GetMouseDelta().Magnitude < 2) then
			local var1 = not num1
			num1 = var1
		end
	end)
end

tbl4.disableCameraToggleInput = function()
	if not decPanInputCount then
		return
	end

	decPanInputCount = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
		resetPanInputCount = nil
	end

	if tbl1 then
		tbl1:Disconnect()
		tbl1 = nil
	end
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Poppercam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local str2 = "ZoomController"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag
local var2 = require(script.Parent:WaitForChild(str2))
var1 = var1("UserFixCameraFPError")
str1 = {}
str1.__index = str1
str2 = CFrame.new()
str1.new = function()
	return (setmetatable({ lastCFrame = nil }, str1))
end

str1.Step = function(arg1, arg2, arg3)
	local var1 = arg1.lastCFrame or arg3
	arg1.lastCFrame = arg3
	local var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13 = arg3:GetComponents()
	local var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25 = var1:GetComponents()
	local var26 = arg3.Position
	local var27 = CFrame.new(0, 0, 0, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	local var28, var29 = (var27 * CFrame.new(0, 0, 0, var17, var18, var19, var20, var21, var22, var23, var24, var25):inverse()):ToAxisAngle()
	var14 = (var26 - var1.p) / arg2
	var15 = var28 * var29 / arg2
	return {
		extrapolate = function(arg1)
			local var1 = var15 * arg1
			local var3 = var1.Magnitude
			local var4 = var14 * arg1 + var26
			return (if 1e-05 < var3 then CFrame.fromAxisAngle(var1, var3) else str2) * var27 + var4
		end,
		posVelocity = var14,
		rotVelocity = var15,
	}
end

str1.Reset = function(arg1)
	arg1.lastCFrame = nil
end

local function cframeToAxis(arg1)
	local var1, var2 = arg1:ToAxisAngle()
	return var1 * var2
end

local function extractRotation(arg1)
	local var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12 = arg1:GetComponents()
	local num1 = 0
	local num2 = 0
	local num3 = 0
	local var13 = var4
	local var14 = var5
	local var15 = var6
	local var16 = var7
	local var17 = var8
	local var18 = var9
	local var19 = var10
	local var20 = var11
	local var21 = var12
	return CFrame.new(num1, num2, num3, var13, var14, var15, var16, var17, var18, var19, var20, var21)
end

extractRotation = "BaseOcclusion"
local function axisToCFrame(arg1)
	local var4 = arg1.Magnitude
	if 1e-05 < var4 then
		local var5 = arg1
		local var6 = var4
		return CFrame.fromAxisAngle(var5, var6)
	end

	return str2
end

str2 = require(script.Parent:WaitForChild(extractRotation))
cframeToAxis = setmetatable({}, str2)
cframeToAxis.__index = cframeToAxis
cframeToAxis.new = function()
	local var1 = setmetatable(str2.new(), cframeToAxis)
	var1.focusExtrapolator = str1.new()
	return var1
end

cframeToAxis.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Zoom
end

cframeToAxis.Enable = function(arg1, _)
	arg1.focusExtrapolator:Reset()
end

cframeToAxis.Update = function(arg1, arg2, arg3, arg4, _)
	local var4 = nil
	var4 = if var1 then CFrame.lookAlong(arg4.p, -arg3.LookVector) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1) else CFrame.new(arg4.p, arg3.p) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	return var4 * CFrame.new(0, 0, (var2.Update(arg2, var4, (arg1.focusExtrapolator:Step(arg2, var4))))), arg4
end

cframeToAxis.CharacterAdded = function(_, _, _)
end

cframeToAxis.CharacterRemoving = function(_, _, _)
end

cframeToAxis.OnCameraSubjectChanged = function(_, _)
end

return cframeToAxis

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera [ModuleScript]
-- y u r i

local str1 = "BaseCamera"
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local str4 = "ZoomController"
require(script.Parent:WaitForChild(str4))
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "VehicleCameraCore"
local str6 = "VehicleCameraConfig"
str2 = require(script:WaitForChild(str5))
str3 = require(script:WaitForChild(str6))
local num1 = 0.016666666666666666
game:GetService("RunService").Stepped:Connect(function(_, arg2)
	num1 = arg2
end)

str4 = game:GetService("Players").LocalPlayer
local var4 = setmetatable({}, var1)
var4.__index = var4
var4.new = function()
	local var2 = setmetatable(var1.new(), var4)
	var2:Reset()
	return var2
end

str6 = var3.Spring
local tbl1 = { 0, 15, 30 }
var4.Reset = function(arg1)
	local var1 = str2.new(arg1:GetSubjectCFrame())
	arg1.vehicleCameraCore = var1
	arg1.pitchSpring = str6.new(0, -math.rad(str3.pitchBaseAngle))
	arg1.yawSpring = str6.new(0, 0)
	arg1.lastPanTick = 0
	var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var4, var5 = var3.getLooseBoundingSphere((var2:GetConnectedParts(true)))
	arg1.assemblyRadius = math.max(var5, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var4
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.assemblyRadius / 10)
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

local var5 = var3.sanitizeAngle
local var6 = var3.mapClamp
var4._StepRotation = function(arg1, arg2, arg3)
	local var1 = var2.getRotation(arg2, true)
	local var3 = arg1.yawSpring
	local var4 = var5(var3.pos + -var1.X)
	var3.pos = var4
	local var7 = arg1.pitchSpring
	var4 = var5((math.clamp(var7.pos + -var1.Y, -1.3962634015954636, 1.3962634015954636)))
	var7.pos = var4
	if var2.getRotationActivated() then
		arg1.lastPanTick = os.clock()
	end

	var4 = -math.rad(str3.pitchBaseAngle)
	local var8 = math.rad(str3.pitchDeadzoneAngle)
	if str3.autocorrectDelay < os.clock() - arg1.lastPanTick then
		local var9 = var6(arg3, str3.autocorrectMinCarSpeed, str3.autocorrectMaxCarSpeed, 0, str3.autocorrectResponse)
		var3.freq = var9
		var7.freq = var9
		if var3.freq < 0.001 then
			var3.vel = 0
		end

		if var7.freq < 0.001 then
			var7.vel = 0
		end

		if math.abs((var5(var4 - var7.pos))) <= var8 then
			var7.goal = var7.pos
		else
			var7.goal = var4
		end
	else
		var3.freq = 0
		var3.vel = 0
		var7.freq = 0
		var7.vel = 0
		var7.goal = var4
	end

	local var10 = var7:step(arg2)
	local var11 = var3:step(arg2)
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var10, var11, num1)
end

var4._GetThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * str3.verticalCenterOffset, 0)
end

var4._GetFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = str4.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_GetThirdPersonLocalOffset()
end

var4.Update = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var3 = num1
	num1 = 0
	local var4 = arg1:GetSubjectCFrame()
	str1 = arg1:GetSubjectRotVelocity()
	local var5 = arg1:StepZoom()
	local var7 = var6(var5, 0.5, arg1.assemblyRadius, 1, 0)
	local var8 = arg1.vehicleCameraCore
	var8:setTransform(var4)
	local var9 = CFrame.new(var4 * arg1:_GetThirdPersonLocalOffset():Lerp(arg1:_GetFirstPersonLocalOffset(var4), var7)) * var8:step(var3, math.abs((var4.XVector:Dot(str1))), math.abs((var4.YVector:Dot(str1))), var7) * arg1:_StepRotation(var3, (math.abs((arg1:GetSubjectVelocity():Dot(var4.ZVector)))))
	return var9 * CFrame.new(0, 0, var5), var9
end

var4.ApplyVRTransform = function(_)
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig [ModuleScript]
-- y u r i

return {
	pitchStiffness = 0.5,
	yawStiffness = 2.5,
	autocorrectDelay = 1,
	autocorrectMinCarSpeed = 16,
	autocorrectMaxCarSpeed = 32,
	autocorrectResponse = 0.5,
	cutoffMinAngularVelYaw = 60,
	cutoffMaxAngularVelYaw = 180,
	cutoffMinAngularVelPitch = 15,
	cutoffMaxAngularVelPitch = 60,
	pitchBaseAngle = 18,
	pitchDeadzoneAngle = 12,
	firstPersonResponseMul = 10,
	yawReponseDampingRising = 1,
	yawResponseDampingFalling = 3,
	pitchReponseDampingRising = 1,
	pitchResponseDampingFalling = 3,
	verticalCenterOffset = 0.33,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.CameraUtils)
local var2 = var1.sanitizeAngle
local var3 = require(script.Parent.VehicleCameraConfig)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	return (setmetatable({ fRising = arg1, fFalling = arg2, g = arg3, p = arg3, v = arg3 * 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.v
	local var2 = arg1.g
	local var3 = 6.2831853071795862 * (0 < var1 and arg1.fRising or arg1.fFalling)
	local var4 = arg1.p - var2
	local var5 = math.exp(-var3 * arg2)
	local var6 = (var4 * (1 + var3 * arg2) + var1 * arg2) * var5 + var2
	arg1.p = var6
	arg1.v = (var1 * (1 - var3 * arg2) - var4 * (var3 * var3 * arg2)) * var5
	return var6
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function(arg1)
	assert(typeof(arg1) == "CFrame")
	local var1, var4 = arg1:toEulerAnglesYXZ()
	local var5, var6 = arg1:toEulerAnglesYXZ()
	local tbl3 = { yawG = var2(var4), yawV = 0, pitchV = 0 }
	tbl3.yawP = var2(var6)
	tbl3.pitchG = var2((arg1:toEulerAnglesYXZ()))
	tbl3.pitchP = var2((arg1:toEulerAnglesYXZ()))
	tbl3.fSpringYaw = tbl1.new(var3.yawReponseDampingRising, var3.yawResponseDampingFalling, 0)
	tbl3.fSpringPitch = tbl1.new(var3.pitchReponseDampingRising, var3.pitchResponseDampingFalling, 0)
	return (setmetatable(tbl3, tbl2))
end

tbl2.setGoal = function(arg1, arg2)
	assert(typeof(arg2) == "CFrame")
	local var1, var3 = arg2:toEulerAnglesYXZ()
	arg1.yawG = var2(var3)
	arg1.pitchG = var2((arg2:toEulerAnglesYXZ()))
end

tbl2.getCFrame = function(arg1)
	local var1 = arg1.pitchP
	local var2 = arg1.yawP
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var1, var2, num1)
end

local var4 = var1.mapClamp
local var5 = var1.map
tbl2.step = function(arg1, arg2, arg3, arg4, arg5)
	assert(typeof(arg2) == "number")
	assert(typeof(arg4) == "number")
	assert(typeof(arg3) == "number")
	assert(typeof(arg5) == "number")
	local var1 = arg1.fSpringYaw
	var1.g = var4(var5(arg5, 0, 1, arg4, 0), math.rad(var3.cutoffMinAngularVelYaw), math.rad(var3.cutoffMaxAngularVelYaw), 1, 0)
	local var6 = arg1.fSpringPitch
	var6.g = var4(var5(arg5, 0, 1, arg3, 0), math.rad(var3.cutoffMinAngularVelPitch), math.rad(var3.cutoffMaxAngularVelPitch), 1, 0)
	local var7 = arg1.yawG
	local var8 = 6.2831853071795862 * var3.yawStiffness * var1:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var9 = var2(arg1.yawP - var7)
	local var10 = arg1.yawV
	local var11 = math.exp(-var8 * arg2)
	local var12 = 6.2831853071795862 * var3.pitchStiffness * var6:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var13 = var2((var9 * (1 + var8 * arg2) + var10 * arg2) * var11 + var7)
	arg1.yawP = var13
	arg1.yawV = (var10 * (1 - var8 * arg2) - var9 * (var8 * var8 * arg2)) * var11
	var7 = arg1.pitchG
	var9 = var2(arg1.pitchP - var7)
	var10 = arg1.pitchV
	var11 = math.exp(-var12 * arg2)
	var13 = var2((var9 * (1 + var12 * arg2) + var10 * arg2) * var11 + var7)
	arg1.pitchP = var13
	arg1.pitchV = (var10 * (1 - var12 * arg2) - var9 * (var12 * var12 * arg2)) * var11
	return arg1:getCFrame()
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.new = function(arg1)
	return (setmetatable({ vrs = tbl2.new(arg1) }, tbl3))
end

tbl3.step = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg2
	local var2 = arg3
	local var3 = arg4
	local var4 = arg5
	return arg1.vrs:step(var1, var2, var3, var4)
end

tbl3.setTransform = function(arg1, arg2)
	arg1.vrs:setGoal(arg2)
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUI [ModuleScript]
-- y u r i

local bool1 = false
local tbl1 = {}
local var1 = game:GetService("StarterGui")
tbl1.setCameraModeToastEnabled = function(arg1)
	if not arg1 and (not bool1) then
		return
	end

	if not bool1 then
		bool1 = true
	end

	if not arg1 then
		tbl1.setCameraModeToastOpen(false)
	end
end

tbl1.setCameraModeToastOpen = function(arg1)
	assert(bool1)
	if arg1 then
		var1:SetCore("SendNotification", { Title = "Camera Control Enabled", Text = "Right click to toggle", Duration = 3 })
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
script.Parent:WaitForChild("CommonUtils")
local str1 = "Keyboard"
local str2 = "Gamepad"
local var1 = require(script:WaitForChild(str1))
local str3 = "DynamicThumbstick"
local var2 = require(script:WaitForChild(str2))
local var3 = require(script:WaitForChild(str3))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local str4 = "TouchThumbstick"
local str5 = "ClickToMoveController"
success = require(script:WaitForChild(str4))
local str6 = "TouchJump"
result = require(script:WaitForChild(str5))
local str7 = "VehicleController"
local var4 = require(script:WaitForChild(str6))
str4 = require(script:WaitForChild(str7))
local success, result = pcall(function()
	local str1 = "UserPlayerScriptsSupportMicroGamepad"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str5 = nil
str5 = success and result
local var5 = game:GetService("Players")
local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("GuiService")
local var9 = game:GetService("Workspace")
local var10 = UserSettings():GetService("UserGameSettings")
local var11 = game:GetService("VRService")
success = Enum.ContextActionPriority.Medium.Value
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.controllers = {}
	var1.activeControlModule = nil
	var1.activeController = nil
	var1.touchJumpController = nil
	var1.moveFunction = var5.LocalPlayer.Move
	var1.humanoid = nil
	var1.controlsEnabled = true
	var1.humanoidSeatedConn = nil
	var1.vehicleController = nil
	var1.touchControlFrame = nil
	var1.currentTorsoAngle = 0
	var1.inputMoveVector = Vector3.new(0, 0, 0)
	var1.vehicleController = str4.new(success)
	var5.LocalPlayer.CharacterAdded:Connect(function(arg1)
		var1:OnCharacterAdded(arg1)
	end)

	var5.LocalPlayer.CharacterRemoving:Connect(function(arg1)
		var1:OnCharacterRemoving(arg1)
	end)

	if var5.LocalPlayer.Character then
		var1:OnCharacterAdded(var5.LocalPlayer.Character)
	end

	var6:BindToRenderStep("ControlScriptRenderstep", Enum.RenderPriority.Input.Value, function(arg1)
		var1:OnRenderStepped(arg1)
	end)

	var10:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var10:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = nil
	var1.touchGui = nil
	var1.playerGuiAddedConn = nil
	var8:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		var1:UpdateMovementMode()
		var1:UpdateActiveControlModuleEnabled()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = var5.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not var1.playerGui then
		var1.playerGuiAddedConn = var5.LocalPlayer.ChildAdded:Connect(function(arg1)
			if arg1:IsA("PlayerGui") then
				var1.playerGui = arg1
				var1.playerGuiAddedConn:Disconnect()
				var1.playerGuiAddedConn = nil
				var1:UpdateMovementMode()
			end
		end)

	end

	var1:UpdateMovementMode()
	return var1
end

tbl1.GetMoveVector = function(arg1)
	if arg1.activeController then
		return arg1.activeController:GetMoveVector()
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetEstimatedVRTorsoFrame = function(arg1)
	local var1 = var11:GetUserCFrame(Enum.UserCFrame.Head)
	local var2, var3, var4 = var1:ToEulerAnglesYXZ()
	var3 = -var3
	if not var11:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) or (not var11:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)) then
		arg1.currentTorsoAngle = var3
	else
		local var5 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.LeftHand).Position
		local var6 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.RightHand).Position
		local var7 = -math.atan2(var5.X, var5.Z)
		local var9 = (-math.atan2(var6.X, var6.Z) - var7 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var12 = (var7 + var9 / 2 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var12 then
			var12 = var12 - 6.2831853071795862
		end

		var9 = (var3 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var14 = (var12 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var14 then
			var14 = var14 - 6.2831853071795862
		end

		local bool1 = false
		if -1.5707963267948966 < var14 then
			bool1 = var14 < 1.5707963267948966
		end

		if not bool1 then
			var14 = var9
		end

		local var16 = math.min(var14, var9)
		local var17 = math.max(var14, var9)
		local num2 = 0
		if 0 < var16 then
			num2 = var16
		else
			if var17 < 0 then
				num2 = var17
			end
		end

		local var18 = num2 + arg1.currentTorsoAngle
		arg1.currentTorsoAngle = var18
	end

	return CFrame.new(var1.Position) * CFrame.fromEulerAnglesYXZ(0, -arg1.currentTorsoAngle, 0)
end

tbl1.GetActiveController = function(arg1)
	return arg1.activeController
end

tbl1.UpdateActiveControlModuleEnabled = function(arg1)
	local function fn2()
		if arg1.touchControlFrame then
			if var7.PreferredInput == Enum.PreferredInput.Touch then
				if arg1.activeControlModule ~= result then
					if arg1.activeControlModule == success or arg1.activeControlModule == var3 then
						if not arg1.controllers[var4] then
							arg1.controllers[var4] = var4.new()
						end

						arg1.touchJumpController = arg1.controllers[var4]
						arg1.touchJumpController:Enable(true, arg1.touchControlFrame)
					else
						if arg1.touchJumpController then
							arg1.touchJumpController:Enable(false)
						end
					end
				end
			else
				if arg1.touchJumpController then
					arg1.touchJumpController:Enable(false)
				end
			end
		else
			if arg1.touchJumpController then
				arg1.touchJumpController:Enable(false)
			end
		end

		if arg1.activeControlModule == result then
			arg1.activeController:Enable(true, var5.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, arg1.touchJumpController)
			return
		end

		if arg1.touchControlFrame then
			arg1.activeController:Enable(true, arg1.touchControlFrame)
			return
		end

		arg1.activeController:Enable(true)
	end

	if not arg1.activeController then
		return
	end

	if not arg1.controlsEnabled then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	if not var8.TouchControlsEnabled and (var7.PreferredInput == Enum.PreferredInput.Touch and (arg1.activeControlModule == result or (arg1.activeControlModule == success or arg1.activeControlModule == var3))) then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	fn2()
end

tbl1.Enable = function(arg1, arg2)
	arg2 = arg2 == nil and true
	if arg1.controlsEnabled == arg2 then
		return
	end

	arg1.controlsEnabled = arg2
	if not arg1.activeController then
		return
	end

	arg1:UpdateActiveControlModuleEnabled()
end

tbl1.Disable = function(arg1)
	arg1:Enable(false)
end

result = {
	[Enum.TouchMovementMode.DPad] = var3,
	[Enum.DevTouchMovementMode.DPad] = var3,
	[Enum.TouchMovementMode.Thumbpad] = var3,
	[Enum.DevTouchMovementMode.Thumbpad] = var3,
	[Enum.TouchMovementMode.Thumbstick] = success,
	[Enum.DevTouchMovementMode.Thumbstick] = success,
	[Enum.TouchMovementMode.DynamicThumbstick] = var3,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = var3,
	[Enum.TouchMovementMode.ClickToMove] = result,
	[Enum.DevTouchMovementMode.ClickToMove] = result,
	[Enum.TouchMovementMode.Default] = var3,
	[Enum.ComputerMovementMode.Default] = var1,
	[Enum.ComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = result,
	[Enum.DevComputerMovementMode.ClickToMove] = result,
}

tbl1.SelectComputerMovementModule = function(_)
	if not var7.KeyboardEnabled and (not var7.GamepadEnabled) then
		return nil, false
	end

	local var4 = var5.LocalPlayer.DevComputerMovementMode
	local var6 = nil
	if var4 == Enum.DevComputerMovementMode.UserChoice then
		local bool3 = false
		if str5 then
			pcall(function()
				bool3 = var7.PreferredInput == Enum.PreferredInput.MicroGamepad
			end)

		end

		if var7.PreferredInput == Enum.PreferredInput.Gamepad or bool3 then
			var6 = var2
		else
			if var7.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				var6 = var1
			end
		end

		if var10.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove and var6 == var1 then
			var6 = result
		end
	else
		var6 = result[var4]
		if not var6 and var4 ~= Enum.DevComputerMovementMode.Scriptable then
			warn("No character control module is associated with DevComputerMovementMode ", var4)
		end
	end

	if var6 then
		return var6, true
	end

	if var4 == Enum.DevComputerMovementMode.Scriptable then
		return nil, true
	end

	return nil, false
end

tbl1.SelectTouchModule = function(_)
	local var3 = var5.LocalPlayer.DevTouchMovementMode
	local var4 = nil
	if var3 == Enum.DevTouchMovementMode.UserChoice then
		var4 = result[var10.TouchMovementMode]
	else
		if var3 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end

		var4 = result[var3]
	end

	return var4, true
end

local function getGamepadRightThumbstickPosition()
	for k1, v1 in pairs((var7:GetGamepadState(Enum.UserInputType.Gamepad1))) do
		if v1.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end

		return v1.Position
	end

	return Vector3.new(0, 0, 0)
end

tbl1.calculateRawMoveVector = function(arg1, arg2, arg3)
	local var2 = var9.CurrentCamera
	if not var2 then
		return arg3
	end

	local var5 = var2.CFrame
	if var11.VREnabled then
		if arg2.RootPart then
			var11:GetUserCFrame(Enum.UserCFrame.Head)
			local var8 = arg1:GetEstimatedVRTorsoFrame()
			var5 = if (var2.Focus.Position - var5.Position).Magnitude < 3 then var5 * var8 else var2.CFrame * (var8.Rotation + var8.Position * var2.HeadScale)
		end
	end

	if arg2:GetState() == Enum.HumanoidStateType.Swimming then
		if var11.VREnabled then
			arg3 = Vector3.new(arg3.X, 0, arg3.Z)
			if arg3.Magnitude < 0.01 then
				return Vector3.new(0, 0, 0)
			end

			local var10, var12, var13 = var5:ToEulerAnglesYXZ()
			return CFrame.fromEulerAnglesYXZ(-getGamepadRightThumbstickPosition().Y * 1.3962634015954636, math.atan2(-arg3.X, -arg3.Z) + var12, 0).LookVector
		end

		local var14 = arg3
		return var5:VectorToWorldSpace(var14)
	end

	local var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40 = var5:GetComponents()
	local var41 = nil
	local var42 = nil
	if var37 < 1 and -1 < var37 then
		var41 = var40
		var42 = var34
	else
		var41 = var32
		var42 = -var33 * math.sign(var37)
	end

	local var43 = math.sqrt(var41 * var41 + var42 * var42)
	return (Vector3.new((var41 * arg3.X + var42 * arg3.Z) / var43, 0, (var41 * arg3.Z - var42 * arg3.X) / var43))
end

tbl1.OnRenderStepped = function(arg1, arg2)
	if arg1.activeController then
		if arg1.activeController.enabled then
			if arg1.humanoid then
				local var7 = arg1:GetClickToMoveController()
				local var8 = arg1.activeController:GetMoveVector()
				local var9 = arg1.activeController:IsMoveVectorCameraRelative()
				if arg1.activeController == var7 then
					var7:OnRenderStepped(arg2)
				else
					if 0 < var8.magnitude then
						var7:CleanupPath()
					else
						var7:OnRenderStepped(arg2)
						var8 = var7:GetMoveVector()
						var9 = var7:IsMoveVectorCameraRelative()
					end
				end

				if arg1.vehicleController then
					local var10, var12 = arg1.vehicleController:Update(var8, var9, arg1.activeControlModule == var2)
					var8 = var10
				end

				if var9 then
					var8 = arg1:calculateRawMoveVector(arg1.humanoid, var8)
				end

				arg1.inputMoveVector = var8
				if var11.VREnabled then
					var8 = arg1:updateVRMoveVector(var8)
				end

				arg1.moveFunction(var5.LocalPlayer, var8, false)
				local var13 = arg1.activeController:GetIsJumping()
				var13 = var13 or arg1.touchJumpController and arg1.touchJumpController:GetIsJumping()
				arg1.humanoid.Jump = var13
			end
		end
	end
end

tbl1.updateVRMoveVector = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	local bool2 = false
	if (var1.Focus.Position - var1.CFrame.Position).Magnitude < 5 then
		bool2 = true
	end

	if arg2.Magnitude == 0 and (bool2 and (var11.AvatarGestures and (arg1.humanoid and (not arg1.humanoid.Sit)))) then
		local var4 = var11:GetUserCFrame(Enum.UserCFrame.Head)
		local var5 = (var1.CFrame * (var4.Rotation + var4.Position * var1.HeadScale) * CFrame.new(0, -0.7 * arg1.humanoid.RootPart.Size.Y / 2, 0)).Position - arg1.humanoid.RootPart.CFrame.Position
		return (Vector3.new(var5.x, 0, var5.z))
	end

	return arg2
end

tbl1.OnHumanoidSeated = function(arg1, arg2, arg3)
	if arg2 then
		if not arg3 then
			return
		end

		if not arg3:IsA("VehicleSeat") then
			return
		end

		if not arg1.vehicleController then
			local var1 = arg1.vehicleController.new(success)
			arg1.vehicleController = var1
		end

		arg1.vehicleController:Enable(true, arg3)
		return
	end

	if arg1.vehicleController then
		arg1.vehicleController:Enable(false, arg3)
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2)
	arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	while not arg1.humanoid do
		arg2.ChildAdded:wait()
		arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	end

	if arg1.humanoidSeatedConn then
		arg1.humanoidSeatedConn:Disconnect()
		arg1.humanoidSeatedConn = nil
	end

	arg1.humanoidSeatedConn = arg1.humanoid.Seated:Connect(function(arg1, arg2)
		arg1:OnHumanoidSeated(arg1, arg2)
	end)

	arg1:UpdateMovementMode()
end

tbl1.OnCharacterRemoving = function(arg1, _)
	arg1.humanoid = nil
	arg1:UpdateMovementMode()
end

tbl1.UpdateTouchGuiVisibility = function(arg1)
	local var2 = arg1.humanoid
	if var2 then
		var2 = var8.TouchControlsEnabled
		if var2 then
			var2 = var7.PreferredInput == Enum.PreferredInput.Touch
		end
	end

	if var2 and (not arg1.touchGui) then
		arg1:CreateTouchGuiContainer()
	end

	if arg1.touchGui then
		arg1.touchGui.Enabled = not not var2
	end
end

tbl1.SwitchToController = function(arg1, arg2)
	if not arg2 then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = nil
		arg1.activeControlModule = nil
		return
	end

	if not arg1.controllers[arg2] then
		arg1.controllers[arg2] = arg2.new(success)
	end

	if arg1.activeController ~= arg1.controllers[arg2] then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = arg1.controllers[arg2]
		arg1.activeControlModule = arg2
		arg1:UpdateActiveControlModuleEnabled()
	end
end

tbl1.UpdateMovementMode = function(arg1)
	arg1:UpdateTouchGuiVisibility()
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		local var1, var2 = arg1:SelectTouchModule()
		if not (var2 and arg1.touchControlFrame) then
			return
		end

		if not arg1.touchControlFrame then
			return
		end

		arg1:SwitchToController(var1)
		return
	end

	arg1:SwitchToController((arg1:SelectComputerMovementModule()))
end

tbl1.CreateTouchGuiContainer = function(arg1)
	if not arg1.playerGui then
		return
	end

	if arg1.touchGui then
		arg1.touchGui:Destroy()
	end

	arg1.touchGui = Instance.new("ScreenGui")
	arg1.touchGui.Name = "TouchGui"
	arg1.touchGui.ResetOnSpawn = false
	arg1.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	if str1 then
		arg1.touchGui.ClipToDeviceSafeArea = false
	end

	arg1.touchControlFrame = Instance.new("Frame")
	arg1.touchControlFrame.Name = "TouchControlFrame"
	arg1.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
	arg1.touchControlFrame.BackgroundTransparency = 1
	arg1.touchControlFrame.Parent = arg1.touchGui
	arg1.touchGui.Parent = arg1.playerGui
end

tbl1.GetClickToMoveController = function(arg1)
	if not arg1.controllers[result] then
		arg1.controllers[result] = result.new(success)
	end

	return arg1.controllers[result]
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick [ModuleScript]
-- y u r i

local tbl1 = { 0.10999999999999999, 0.30000000000000004, 0.4, 0.5, 0.6, 0.7, 0.75 }
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local var2 = var1.getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
success = nil
local var3 = game:GetService("Players")
result = var3.LocalPlayer
local var4 = Enum.ContextActionPriority.High.Value
local var5 = #tbl1
local var6 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local var7 = game:GetService("GuiService")
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("ContextActionService")
local var10 = game:GetService("RunService")
local var11 = game:GetService("TweenService")
local var12 = var1.getUserFlag("UserAllowAbilityControlsBonus")
success = var2 and require(script.Parent:WaitForChild(str2))
if not result then
	var3:GetPropertyChangedSignal("LocalPlayer"):Wait()
	result = var3.LocalPlayer
end

local str3 = "BaseCharacterController"
local var13 = require(script.Parent:WaitForChild(str3))
local var14 = setmetatable({}, var13)
var14.__index = var14
var14.new = function()
	local var1 = setmetatable(var13.new(), var14)
	var1.moveTouchObject = nil
	var1.moveTouchLockedIn = false
	var1.moveTouchFirstChanged = false
	var1.moveTouchStartPosition = nil
	var1.startImage = nil
	var1.endImage = nil
	var1.middleImages = {}
	var1.startImageFadeTween = nil
	var1.endImageFadeTween = nil
	var1.middleImageFadeTweens = {}
	var1.isFirstTouch = true
	var1.thumbstickFrame = nil
	var1.onRenderSteppedConn = nil
	var1.fadeInAndOutBalance = 0.5
	var1.fadeInAndOutHalfDuration = 0.3
	var1.hasFadedBackgroundInPortrait = false
	var1.hasFadedBackgroundInLandscape = false
	var1.tweenInAlphaStart = nil
	var1.tweenOutAlphaStart = nil
	return var1
end

var14.GetIsJumping = function(arg1)
	local var1 = arg1.isJumping
	arg1.isJumping = false
	return var1
end

var14.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1:BindContextActions()
	else
		arg1:UnbindContextActions()
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
	arg1.thumbstickFrame.Visible = arg2
	return nil
end

var14.OnInputEnded = function(arg1)
	arg1.moveTouchObject = nil
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1:FadeThumbstick(false)
end

var14.FadeThumbstick = function(arg1, arg2)
	if not arg2 and arg1.moveTouchObject then
		return
	end

	if arg1.isFirstTouch then
		return
	end

	if arg1.startImageFadeTween then
		arg1.startImageFadeTween:Cancel()
	end

	if arg1.endImageFadeTween then
		arg1.endImageFadeTween:Cancel()
	end

	for i1 = 1, #arg1.middleImages do
		if not arg1.middleImageFadeTweens[i1] then
			continue
		end

		arg1.middleImageFadeTweens[i1]:Cancel()
	end

	if arg2 then
		arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 0 })
		arg1.startImageFadeTween:Play()
		arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 0.2 })
		arg1.endImageFadeTween:Play()
		for i2 = 1, #arg1.middleImages do
			arg1.middleImageFadeTweens[i2] = var11:Create(arg1.middleImages[i2], var6, { ImageTransparency = tbl1[i2] })
			arg1.middleImageFadeTweens[i2]:Play()
		end

		return
	end

	arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 1 })
	arg1.startImageFadeTween:Play()
	arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 1 })
	arg1.endImageFadeTween:Play()
	for i3 = 1, #arg1.middleImages do
		arg1.middleImageFadeTweens[i3] = var11:Create(arg1.middleImages[i3], var6, { ImageTransparency = 1 })
		arg1.middleImageFadeTweens[i3]:Play()
	end
end

var14.FadeThumbstickFrame = function(arg1, arg2, arg3)
	arg1.fadeInAndOutHalfDuration = arg2 * 0.5
	arg1.fadeInAndOutBalance = arg3
	arg1.tweenInAlphaStart = tick()
end

var14.InputInFrame = function(arg1, arg2)
	local var1 = arg1.thumbstickFrame.AbsolutePosition
	local var2 = arg2.Position
	local var4 = var1 + arg1.thumbstickFrame.AbsoluteSize
	if var1.X <= var2.X and (var1.Y <= var2.Y and (var2.X <= var4.X and var2.Y <= var4.Y)) then
		return true
	end

	return false
end

var14.DoFadeInBackground = function(arg1)
	local var2 = result:FindFirstChildOfClass("PlayerGui")
	local bool2 = false
	if var2 then
		if var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft or var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight then
			bool2 = arg1.hasFadedBackgroundInLandscape
			arg1.hasFadedBackgroundInLandscape = true
		else
			if var2.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait then
				bool2 = arg1.hasFadedBackgroundInPortrait
				arg1.hasFadedBackgroundInPortrait = true
			end
		end
	end

	if not bool2 then
		arg1.fadeInAndOutHalfDuration = 0.3
		arg1.fadeInAndOutBalance = 0.5
		arg1.tweenInAlphaStart = tick()
	end
end

var14.DoMove = function(arg1, arg2)
	local var1 = arg2
	if var1.Magnitude < arg1.radiusOfDeadZone then
		var1 = Vector3.new(0, 0, 0)
	else
		var1 = var1.Unit * (1 - math.max(0, (arg1.radiusOfMaxSpeed - var1.Magnitude) / arg1.radiusOfMaxSpeed))
		var1 = Vector3.new(var1.X, 0, var1.Y)
	end

	arg1.moveVector = var1
end

var14.LayoutMiddleImages = function(arg1, arg2, arg3)
	local var1 = arg3 - arg2
	local var4 = var1.Magnitude - arg1.thumbstickRingSize / 2 - arg1.middleSize
	local var6 = arg1.thumbstickSize / 2 + arg1.middleSize
	local var7 = var1.Unit
	local var8 = arg1.middleSpacing
	if arg1.middleSpacing * var5 < var4 then
		var8 = var4 / var5
	end

	for i1 = 1, var5 do
		local var10 = arg1.middleImages[i1]
		if var6 + var8 * (i1 - 2) < var4 then
			local var11 = var6 + var8 * (i1 - 1)
			local var12 = math.clamp(1 - (var11 - var4) / var8, 0, 1)
			var10.Visible = true
			local var13 = arg3 - var7 * var11
			var10.Position = UDim2.new(0, var13.X, 0, var13.Y)
			var10.Size = UDim2.new(0, arg1.middleSize * var12, 0, arg1.middleSize * var12)
		else
			var10.Visible = false
		end
	end
end

var14.MoveStick = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, arg2.Y) - arg1.thumbstickFrame.AbsolutePosition
	local var2 = Vector2.new(arg1.moveTouchStartPosition.X, arg1.moveTouchStartPosition.Y) - arg1.thumbstickFrame.AbsolutePosition
	arg1.endImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
	arg1:LayoutMiddleImages(var2, var1)
end

var14.BindContextActions = function(arg1)
	local function inputBegan(arg1)
		if arg1.moveTouchObject then
			return Enum.ContextActionResult.Pass
		end

		if not arg1:InputInFrame(arg1) then
			return Enum.ContextActionResult.Pass
		end

		if arg1.isFirstTouch then
			arg1.isFirstTouch = false
			local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
			var11:Create(arg1.startImage, var1, { Size = UDim2.new(0, 0, 0, 0) }):Play()
			local tbl1 = { Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize) }
			tbl1.ImageColor3 = Color3.new(0, 0, 0)
			var11:Create(arg1.endImage, var1, tbl1):Play()
		end

		arg1.moveTouchLockedIn = false
		arg1.moveTouchObject = arg1
		arg1.moveTouchStartPosition = arg1.Position
		arg1.moveTouchFirstChanged = true
		arg1:DoFadeInBackground()
		return Enum.ContextActionResult.Pass
	end

	var9:BindActionAtPriority("DynamicThumbstickAction", function(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Begin then
			return (inputBegan(arg3))
		end

		if arg2 == Enum.UserInputState.Change then
			if arg3 == arg1.moveTouchObject then
				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.End then
			if arg3 == arg1.moveTouchObject then
				arg1:OnInputEnded()
				if arg1.moveTouchLockedIn then
					return Enum.ContextActionResult.Sink
				end
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.Cancel then
			arg1:OnInputEnded()
		end
	end, false, var4, Enum.UserInputType.Touch)

	local function inputChanged(arg1)
		if arg1 == arg1.moveTouchObject then
			if arg1.moveTouchFirstChanged then
				arg1.moveTouchFirstChanged = false
				local var1 = Vector2.new(arg1.Position.X - arg1.thumbstickFrame.AbsolutePosition.X, arg1.Position.Y - arg1.thumbstickFrame.AbsolutePosition.Y)
				arg1.startImage.Visible = true
				arg1.startImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
				arg1.endImage.Visible = true
				arg1.endImage.Position = arg1.startImage.Position
				arg1:FadeThumbstick(true)
				arg1:MoveStick(arg1.Position)
			end

			arg1.moveTouchLockedIn = true
			local var2 = Vector2.new(arg1.Position.X - arg1.moveTouchStartPosition.X, arg1.Position.Y - arg1.moveTouchStartPosition.Y)
			if 0 < math.abs(var2.X) or 0 < math.abs(var2.Y) then
				arg1:DoMove(var2)
				arg1:MoveStick(arg1.Position)
			end

			return Enum.ContextActionResult.Sink
		end

		return Enum.ContextActionResult.Pass
	end

	arg1.TouchMovedCon = var8.TouchMoved:Connect(function(arg1, _)
		inputChanged(arg1)
	end)
end

var14.UnbindContextActions = function(arg1)
	var9:UnbindAction("DynamicThumbstickAction")
	if arg1.TouchMovedCon then
		arg1.TouchMovedCon:Disconnect()
	end
end

var14.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onRenderSteppedConn then
			arg1.onRenderSteppedConn:Disconnect()
			arg1.onRenderSteppedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var2 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	local var1 = if str1 then 100 else 0
	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.BorderSizePixel = 0
	arg1.thumbstickFrame.Name = "DynamicThumbstickFrame"
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	arg1.thumbstickFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	arg1.thumbstickFrame.Active = false
	arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
	arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	arg1.startImage = Instance.new("ImageLabel")
	arg1.startImage.Name = "ThumbstickStart"
	arg1.startImage.Visible = true
	arg1.startImage.BackgroundTransparency = 1
	arg1.startImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.startImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.startImage.ImageRectSize = Vector2.new(144, 144)
	arg1.startImage.ImageColor3 = Color3.new(0, 0, 0)
	arg1.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.startImage.ZIndex = 10
	arg1.startImage.Parent = arg1.thumbstickFrame
	arg1.endImage = Instance.new("ImageLabel")
	arg1.endImage.Name = "ThumbstickEnd"
	arg1.endImage.Visible = true
	arg1.endImage.BackgroundTransparency = 1
	arg1.endImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.endImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.endImage.ImageRectSize = Vector2.new(144, 144)
	arg1.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.endImage.ZIndex = 10
	arg1.endImage.Parent = arg1.thumbstickFrame
	local function layoutThumbstickFrame(arg1)
		if arg1 then
			arg1.thumbstickFrame.Size = UDim2.new(1, var1, 0.4, var1)
			arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.6, 0)
			return
		end

		arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
		arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	end

	for i1 = 1, var5 do
		arg1.middleImages[i1] = Instance.new("ImageLabel")
		arg1.middleImages[i1].Name = "ThumbstickMiddle"
		arg1.middleImages[i1].Visible = false
		arg1.middleImages[i1].BackgroundTransparency = 1
		arg1.middleImages[i1].Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.middleImages[i1].ImageRectOffset = Vector2.new(1, 1)
		arg1.middleImages[i1].ImageRectSize = Vector2.new(144, 144)
		arg1.middleImages[i1].ImageTransparency = tbl1[i1]
		arg1.middleImages[i1].AnchorPoint = Vector2.new(0.5, 0.5)
		arg1.middleImages[i1].ZIndex = 9
		arg1.middleImages[i1].Parent = arg1.thumbstickFrame
	end

	local function ResizeThumbstick()
		local var3 = arg2.AbsoluteSize
		local var5 = 500 < math.min(var3.X, var3.Y)
		if var2 then
			local var7 = if var5 then 2 else 1
			if var12 and (success.isEnabled() and var5) then
				var7 = 1.6216216216216217
			end

			arg1.thumbstickSize = 45 * var7
			arg1.thumbstickRingSize = 20 * var7
			arg1.middleSize = 10 * var7
			arg1.middleSpacing = 14 * var7
			arg1.radiusOfDeadZone = 2 * var7
			arg1.radiusOfMaxSpeed = 20 * var7
			local var8 = 74 * var7
			if success.isEnabled() then
				local var9 = if var5 then 100 else 64
				arg1.startImage.Position = UDim2.new(0, var8 * 0.5 + var1 + var9, 1, -var8 * 0.5 - var1 - (if var5 then 112 else 64))
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			else
				arg1.startImage.Position = UDim2.new(0, arg1.thumbstickRingSize * 3.3 + var1, 1, -arg1.thumbstickRingSize * 2.8 - var1)
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			end
		elseif var5 then
			arg1.thumbstickSize = 90
			arg1.thumbstickRingSize = 40
			arg1.middleSize = 20
			arg1.middleSpacing = 28
			arg1.radiusOfDeadZone = 4
			arg1.radiusOfMaxSpeed = 40
		else
			arg1.thumbstickSize = 45
			arg1.thumbstickRingSize = 20
			arg1.middleSize = 10
			arg1.middleSpacing = 14
			arg1.radiusOfDeadZone = 2
			arg1.radiusOfMaxSpeed = 20
		end

		arg1.endImage.Position = arg1.startImage.Position
		arg1.endImage.Size = UDim2.new(0, arg1.thumbstickSize * 0.8, 0, arg1.thumbstickSize * 0.8)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var2 then
		arg1.avatarAbilitiesEnabledChangedConn = success.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	local var3 = nil
	local function onCurrentCameraChanged()
		if var3 then
			var3:Disconnect()
			var3 = nil
		end

		local var2 = workspace.CurrentCamera
		if var2 then
			var3 = var2:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				local var1 = var2.ViewportSize
				layoutThumbstickFrame(var1.X < var1.Y)
			end)

			local var4 = var2.ViewportSize
			layoutThumbstickFrame(var4.X < var4.Y)
		end
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(onCurrentCameraChanged)
	if workspace.CurrentCamera then
		onCurrentCameraChanged()
	end

	arg1.moveTouchStartPosition = nil
	arg1.startImageFadeTween = nil
	arg1.endImageFadeTween = nil
	arg1.middleImageFadeTweens = {}
	arg1.onRenderSteppedConn = var10.RenderStepped:Connect(function()
		if arg1.tweenInAlphaStart ~= nil then
			local var3 = tick() - arg1.tweenInAlphaStart
			local var4 = arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = 1 - math.min(var3 / var4, 1) * 0.35
			if var4 >= var3 then
				return
			end

			arg1.tweenOutAlphaStart = tick()
			arg1.tweenInAlphaStart = nil
			return
		end

		if arg1.tweenOutAlphaStart ~= nil then
			local var7 = tick() - arg1.tweenOutAlphaStart
			local var8 = arg1.fadeInAndOutHalfDuration * 2 - arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = math.min(var7 / var8, 1) * 0.35 + 0.65
			if var8 < var7 then
				arg1.tweenOutAlphaStart = nil
			end
		end
	end)

	arg1.onTouchEndedConn = var8.TouchEnded:connect(function(arg1)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var7.MenuOpened:connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	local var4 = result:FindFirstChildOfClass("PlayerGui")
	while not var4 do
		result.ChildAdded:wait()
		var4 = result:FindFirstChildOfClass("PlayerGui")
	end

	local var6 = nil
	local bool1 = true
	if var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.LandscapeLeft then
		bool1 = var4.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight
	end

	var4:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		if bool1 and var4.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait or not bool1 and var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.Portrait then
			var6:disconnect()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
			if bool1 then
				arg1.hasFadedBackgroundInPortrait = true
				return
			end

			arg1.hasFadedBackgroundInLandscape = true
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
	if game:IsLoaded() then
		arg1.fadeInAndOutHalfDuration = 2.5
		arg1.fadeInAndOutBalance = 0.05
		arg1.tweenInAlphaStart = tick()
	else
		coroutine.wrap(function()
			game.Loaded:Wait()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
		end)()

	end
end

return var14

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController [ModuleScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "UserExcludeNonCollidableForPathfinding"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local success, result = pcall(function()
	local str1 = "UserClickToMoveSupportAgentCanClimb2"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

game:GetService("Debris")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("PathfindingService")
local var4 = game:GetService("Players")
local var5 = game:GetService("StarterGui")
local var6 = game:GetService("Workspace")
local var7 = game:GetService("CollectionService")
local var8 = game:GetService("GuiService")
local str2 = "ClickToMoveDisplay"
local var9 = require(script.Parent:WaitForChild(str2))
local var10 = RaycastParams.new()
var10.FilterType = Enum.RaycastFilterType.Exclude
local var11 = success and result
local var12 = success and result
local bool1 = true
str1 = true
local bool2 = false
local num1 = 1
local num2 = 8
local tbl1 = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true,
}

local var13 = var4.LocalPlayer
local tbl2 = {}
if not var1 then
	str2 = function(arg1)
		if arg1 then
			local var2 = arg1:FindFirstChildOfClass("Humanoid")
			if var2 then
				return arg1, var2
			end

			local var3 = arg1.Parent
			return str2(var3)
		end
	end

	tbl2.FindCharacterAncestor = str2
	local function Raycast(arg1, arg2, arg3)
		local var1 = arg3
		arg3 = var1 or {}
		local var7, var8, var9, var10 = var6:FindPartOnRayWithIgnoreList(arg1, arg3)
		if var7 then
			if arg2 then
				if var7.CanCollide == false then
					local var13
					if var7 then
						local var15 = var7:FindFirstChildOfClass("Humanoid")
						if var15 then
							local var16 = var7
							var13 = var15
						else
							local var17, var18 = str2(var7.Parent)
							local var19 = var17
							var13 = var18
						end
					else
						local var20 = nil
						var13 = nil
					end

					if var13 == nil then
						table.insert(arg3, var7)
						local var21 = arg1
						local var22 = arg2
						local var23 = arg3
						return Raycast(var21, var22, var23)
					end
				end
			end

			return var7, var8, var9, var10
		end

		return nil, nil
	end

	tbl2.Raycast = Raycast
end

str2 = {}
local var14 = nil
local var15 = nil
local var16 = nil
local var17 = nil
local function getCollidableExtentsSize(arg1)
	if arg1 == nil or arg1.PrimaryPart == nil then
		return
	end

	assert(arg1, "")
	assert(arg1.PrimaryPart, "")
	local var1 = arg1.PrimaryPart.CFrame:Inverse()
	local var2 = Vector3.new(inf, inf, inf)
	local var3 = Vector3.new(-inf, -inf, -inf)
	for k1, v1 in pairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if not v1.CanCollide then
			continue
		end

		local var4 = Vector3.new(v1.Size.X / 2, v1.Size.Y / 2, v1.Size.Z / 2)
		local var5 = Vector3.new(-var4.X, var4.Y, var4.Z)
		local var6 = var1 * v1.CFrame
		for k2, v2 in ipairs({
			Vector3.new(var4.X, var4.Y, var4.Z),
			Vector3.new(var4.X, var4.Y, -var4.Z),
			Vector3.new(var4.X, -var4.Y, var4.Z),
			Vector3.new(var4.X, -var4.Y, -var4.Z),
			var5,
			Vector3.new(-var4.X, var4.Y, -var4.Z),
			Vector3.new(-var4.X, -var4.Y, var4.Z),
			(Vector3.new(-var4.X, -var4.Y, -var4.Z)),
		}) do

			local var7 = var2
			local var8 = var6 * v2
			var2 = Vector3.new(math.min(var7.X, var8.X), math.min(var7.Y, var8.Y), (math.min(var7.Z, var8.Z)))
			var7 = var3
			var3 = Vector3.new(math.max(var7.X, var8.X), math.max(var7.Y, var8.Y), (math.max(var7.Z, var8.Z)))
		end
	end

	local var9 = var3 - var2
	if var9.X < 0 or (var9.Y < 0 or var9.Z < 0) then
		return nil
	end

	return var9
end

local var18 = nil
local var19 = nil
local var20 = nil
local function GetEquippedTool(arg1)
	if arg1 ~= nil then
		for k1, v1 in pairs(arg1:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			return v1
		end
	end
end

local function Pather(arg1, arg2, arg3)
	local var5 = nil
	local var7 = nil
	local tbl1 = {}
	if arg3 ~= nil then
		var5 = arg3
		var7 = arg3
	else
		var5 = bool2
		var7 = true
	end

	tbl1.Cancelled = false
	tbl1.Started = false
	tbl1.Finished = Instance.new("BindableEvent")
	tbl1.PathFailed = Instance.new("BindableEvent")
	tbl1.PathComputing = false
	tbl1.PathComputed = false
	tbl1.OriginalTargetPoint = arg1
	tbl1.TargetPoint = arg1
	tbl1.TargetSurfaceNormal = arg2
	tbl1.DiedConn = nil
	tbl1.SeatedConn = nil
	tbl1.BlockedConn = nil
	tbl1.TeleportedConn = nil
	tbl1.CurrentPoint = 0
	tbl1.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPosition = nil
	tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPlaneDistance = 0
	tbl1.CurrentWaypointNeedsJump = false
	tbl1.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	tbl1.CurrentHumanoidVelocity = 0
	tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
	tbl1.NextActionJump = false
	tbl1.Timeout = 0
	local var8 = var13
	local var14 = var8
	var14 = var14 and var8.Character
	local var16
	if var14 then
		local var19 = str2[var8]
		if var19 and var19.Parent == var14 then
			var16 = var19
		else
			str2[var8] = nil
			local var21 = var14:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var8] = var21
			end

			var16 = var21
		end
	else
		var16 = nil
	end

	tbl1.Humanoid = var16
	tbl1.OriginPoint = nil
	tbl1.AgentCanFollowPath = false
	tbl1.DirectPath = false
	tbl1.DirectPathRiseFirst = false
	tbl1.stopTraverseFunc = nil
	tbl1.setPointFunc = nil
	tbl1.pointList = nil
	var16 = tbl1.Humanoid
	var16 = var16 and tbl1.Humanoid.RootPart
	if var16 then
		tbl1.OriginPoint = var16.CFrame.Position
		local var24 = tbl1.Humanoid.SeatPart
		var8 = 2
		var14 = 5
		local bool3 = true
		if var24 then
			if var24:IsA("VehicleSeat") then
				local var27 = var24:FindFirstAncestorOfClass("Model")
				if var27 then
					local var28 = var27.PrimaryPart
					var27.PrimaryPart = var24
					if var7 then
						local var30 = var27:GetExtentsSize()
						var8 = num1 * 0.5 * math.sqrt(var30.X * var30.X + var30.Z * var30.Z)
						tbl1.AgentCanFollowPath = true
						tbl1.DirectPath = var7
						var14 = num1 * var30.Y
						bool3 = false
					end

					var27.PrimaryPart = var28
				end
			else
				local var33 = nil
				if var11 then
					local var34 = var13
					var34 = var34 and var13.Character
					if var34 ~= nil then
						var33 = getCollidableExtentsSize(var34)
					end
				end

				if var33 == nil then
					local var35 = var13
					var33 = (var35 and var13.Character):GetExtentsSize()
				end

				assert(var33, "")
				var8 = num1 * 0.5 * math.sqrt(var33.X * var33.X + var33.Z * var33.Z)
				tbl1.AgentCanFollowPath = true
				tbl1.DirectPath = var5
				tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
				var14 = num1 * var33.Y
				bool3 = 0 < tbl1.Humanoid.JumpPower
			end
		else
			local var38 = nil
			if var11 then
				local var39 = var13
				var39 = var39 and var13.Character
				if var39 ~= nil then
					var38 = getCollidableExtentsSize(var39)
				end
			end

			if var38 == nil then
				local var40 = var13
				var38 = (var40 and var13.Character):GetExtentsSize()
			end

			assert(var38, "")
			var8 = num1 * 0.5 * math.sqrt(var38.X * var38.X + var38.Z * var38.Z)
			tbl1.AgentCanFollowPath = true
			tbl1.DirectPath = var5
			tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
			var14 = num1 * var38.Y
			bool3 = 0 < tbl1.Humanoid.JumpPower
		end

		if var12 then
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3, AgentCanClimb = true })
		else
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3 })
		end
	end

	tbl1.Cleanup = function(_)
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		if tbl1.BlockedConn then
			tbl1.BlockedConn:Disconnect()
			tbl1.BlockedConn = nil
		end

		if tbl1.DiedConn then
			tbl1.DiedConn:Disconnect()
			tbl1.DiedConn = nil
		end

		if tbl1.SeatedConn then
			tbl1.SeatedConn:Disconnect()
			tbl1.SeatedConn = nil
		end

		if tbl1.TeleportedConn then
			tbl1.TeleportedConn:Disconnect()
			tbl1.TeleportedConn = nil
		end

		tbl1.Started = false
	end

	tbl1.Cancel = function(_)
		tbl1.Cancelled = true
		tbl1:Cleanup()
	end

	tbl1.IsActive = function(_)
		local var1 = tbl1.AgentCanFollowPath
		return var1 and (tbl1.Started and (not tbl1.Cancelled))
	end

	tbl1.OnPathInterrupted = function(_)
		tbl1.Cancelled = true
		tbl1:OnPointReached(false)
	end

	tbl1.ComputePath = function(_)
		if tbl1.OriginPoint then
			if tbl1.PathComputed or tbl1.PathComputing then
				return
			end

			tbl1.PathComputing = true
			if tbl1.AgentCanFollowPath then
				if tbl1.DirectPath then
					local var5 = tbl1.TargetPoint
					local var6 = tbl1.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk
					local tbl2 = {
						PathWaypoint.new(tbl1.OriginPoint, Enum.PathWaypointAction.Walk),
						PathWaypoint.new(var5, var6),
					}

					tbl1.pointList = tbl2
					tbl1.PathComputed = true
				else
					tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
					tbl1.pointList = tbl1.pathResult:GetWaypoints()
					tbl1.BlockedConn = tbl1.pathResult.Blocked:Connect(function(arg1)
						tbl1:OnPathBlocked(arg1)
					end)

					tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
				end
			end

			tbl1.PathComputing = false
		end
	end

	tbl1.IsValidPath = function(_)
		tbl1:ComputePath()
		local var1 = tbl1.PathComputed
		return var1 and tbl1.AgentCanFollowPath
	end

	tbl1.Recomputing = false
	tbl1.OnPathBlocked = function(_, arg2)
		if not (tbl1.CurrentPoint <= arg2) or tbl1.Recomputing then
			return
		end

		tbl1.Recomputing = true
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		tbl1.OriginPoint = tbl1.Humanoid.RootPart.CFrame.p
		tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
		tbl1.pointList = tbl1.pathResult:GetWaypoints()
		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = tbl1.pointList[1].Position - tbl1.OriginPoint
		end

		tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
		if bool1 then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if tbl1.PathComputed then
			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
		else
			tbl1.PathFailed:Fire()
			tbl1:Cleanup()
		end

		tbl1.Recomputing = false
	end

	tbl1.OnRenderStepped = function(_, arg2)
		if tbl1.Started and (not tbl1.Cancelled) then
			tbl1.Timeout = tbl1.Timeout + arg2
			if num2 < tbl1.Timeout then
				tbl1:OnPointReached(false)
				return
			end

			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			while tbl1.Started and tbl1:IsCurrentWaypointReached() do
				tbl1:OnPointReached(true)
			end

			if tbl1.Started then
				tbl1.NextActionMoveDirection = tbl1.CurrentWaypointPosition - tbl1.CurrentHumanoidPosition
				if 1e-06 < tbl1.NextActionMoveDirection.Magnitude then
					tbl1.NextActionMoveDirection = tbl1.NextActionMoveDirection.Unit
				else
					tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end

				if tbl1.CurrentWaypointNeedsJump then
					tbl1.NextActionJump = true
					tbl1.CurrentWaypointNeedsJump = false
					return
				end

				tbl1.NextActionJump = false
			end
		end
	end

	tbl1.IsCurrentWaypointReached = function(_)
		local bool1 = false
		if tbl1.CurrentWaypointPlaneNormal ~= Vector3.new(0, 0, 0) then
			bool1 = tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidPosition) - tbl1.CurrentWaypointPlaneDistance < math.max(1, 0.0625 * -tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidVelocity))
		else
			bool1 = true
		end

		if bool1 then
			tbl1.CurrentWaypointPosition = nil
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		return bool1
	end

	tbl1.OnPointReached = function(_, arg2)
		if arg2 then
			if not tbl1.Cancelled then
				if tbl1.setPointFunc then
					tbl1.setPointFunc(tbl1.CurrentPoint)
				end

				local var2 = tbl1.CurrentPoint + 1
				if #tbl1.pointList < var2 then
					if tbl1.stopTraverseFunc then
						tbl1.stopTraverseFunc()
					end

					tbl1.Finished:Fire()
					tbl1:Cleanup()
					return
				end

				local var4 = tbl1.Humanoid:GetState()
				local var5 = tbl1.pointList[tbl1.CurrentPoint]
				local var6 = tbl1.pointList[var2]
				local bool2 = true
				if var4 ~= Enum.HumanoidStateType.FallingDown then
					bool2 = true
					if var4 ~= Enum.HumanoidStateType.Freefall then
						bool2 = var4 == Enum.HumanoidStateType.Jumping
					end
				end

				if bool2 then
					local var10 = var6.Action == Enum.PathWaypointAction.Jump
					if not var10 then
						if 1 < tbl1.CurrentPoint then
							local var13 = var5.Position - tbl1.pointList[tbl1.CurrentPoint - 1].Position
							local var14 = var6.Position - var5.Position
							var10 = Vector2.new(var13.x, var13.z).Unit:Dot(Vector2.new(var14.x, var14.z).Unit) < 0.996
						end
					end

					if var10 then
						tbl1.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end

				tbl1:MoveToNextWayPoint(var5, var6, var2)
				return
			end
		end

		tbl1.PathFailed:Fire()
		tbl1:Cleanup()
	end

	tbl1.MoveToNextWayPoint = function(_, arg2, arg3, arg4)
		tbl1.CurrentWaypointPlaneNormal = arg2.Position - arg3.Position
		if not var12 or arg3.Label ~= "Climb" then
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(tbl1.CurrentWaypointPlaneNormal.X, 0, tbl1.CurrentWaypointPlaneNormal.Z)
		end

		if 1e-06 < tbl1.CurrentWaypointPlaneNormal.Magnitude then
			tbl1.CurrentWaypointPlaneNormal = tbl1.CurrentWaypointPlaneNormal.Unit
			tbl1.CurrentWaypointPlaneDistance = tbl1.CurrentWaypointPlaneNormal:Dot(arg3.Position)
		else
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		tbl1.CurrentWaypointNeedsJump = arg3.Action == Enum.PathWaypointAction.Jump
		tbl1.CurrentWaypointPosition = arg3.Position
		tbl1.CurrentPoint = arg4
		tbl1.Timeout = 0
	end

	tbl1.Start = function(_, arg2)
		if not tbl1.AgentCanFollowPath then
			tbl1.PathFailed:Fire()
			return
		end

		if tbl1.Started then
			return
		end

		tbl1.Started = true
		var9.CancelFailureAnimation()
		if bool1 and (arg2 == nil or arg2) then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList, tbl1.OriginalTargetPoint)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = Vector3.new(0, tbl1.pointList[1].Position.Y - tbl1.OriginPoint.Y, 0)
			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			tbl1.SeatedConn = tbl1.Humanoid.Seated:Connect(function(_, _)
				tbl1:OnPathInterrupted()
			end)

			tbl1.DiedConn = tbl1.Humanoid.Died:Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.TeleportedConn = tbl1.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
			return
		end

		tbl1.PathFailed:Fire()
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
		end
	end

	var8 = tbl1.TargetPoint + tbl1.TargetSurfaceNormal * 1.5
	if var1 then
		var14 = var10
		local var41
		if var17 then
			var41 = var17
		else
			var17 = {}
			assert(var17, "")
			local var42 = var13
			table.insert(var17, var42 and var13.Character)
			var41 = var17
		end

		var14.FilterDescendantsInstances = var41
		var14 = var6:Raycast(var8, Vector3.new(-0, -50, -0), var10)
		if var14 then
			tbl1.TargetPoint = var14.Position
		end
	else
		var41 = var6
		local var43 = Ray.new(var8, Vector3.new(0, -50, 0))
		local var44
		if var17 then
			var44 = var17
		else
			var17 = {}
			assert(var17, "")
			local var45 = var13
			table.insert(var17, var45 and var13.Character)
			var44 = var17
		end

		local var46, var47 = var41:FindPartOnRayWithIgnoreList(var43, var44)
		if var46 then
			tbl1.TargetPoint = var47
		end
	end

	tbl1:ComputePath()
	return tbl1
end

local function HandleMoveTo(arg1, arg2, arg3, arg4, arg5)
	if var18 then
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end

	var18 = arg1
	arg1:Start(arg5)
	var19 = arg1.Finished.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		local var2 = GetEquippedTool(arg4)
		if arg3 and var2 then
			var2:Activate()
		end
	end)

	var20 = arg1.PathFailed.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		if arg5 ~= nil then
			if not arg5 then
				return
			end
		end

		local var1 = str1
		if var1 and (not var18:IsActive()) then
			var9.PlayFailureAnimation()
		end

		var9.DisplayFailureWaypoint(arg2)
	end)
end

function OnTap(arg1, arg2, arg3)
	local var2 = var13
	local var3 = var2
	var3 = var3 and var2.Character
	local var8 = var6.CurrentCamera
	local var11 = var13.Character
	local var12
	if var3 then
		local var15 = str2[var2]
		if var15 and var15.Parent == var3 then
			var12 = var15
		else
			str2[var2] = nil
			local var21 = var3:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var2] = var21
			end

			var12 = var21
		end
	else
		var12 = nil
	end

	local bool1 = false
	if var12 ~= nil then
		bool1 = 0 < var12.Health
	end

	if not bool1 then
		return
	end

	if #arg1 ~= 1 then
		if arg2 then
			if not var8 then
				return
			end

			bool1 = var8:ScreenPointToRay(arg1[1].X, arg1[1].Y)
			if var1 then
				var12 = nil
				var2 = nil
				var3 = nil
				local var22
				if var17 then
					var22 = var17
				else
					var17 = {}
					assert(var17, "")
					local var23 = var13
					table.insert(var17, var23 and var13.Character)
					var22 = var17
				end

				var22 = var22 or {}
				repeat
					var10.FilterDescendantsInstances = var22
					var3 = var6:Raycast(bool1.Origin, bool1.Direction * 1000, var10)
					local bool2 = true
					if var3 then
						local var25 = var3.Instance
						if not var25.CanCollide then
							repeat
								var12 = var25:FindFirstChildOfClass("Humanoid")
								var2 = var25
								var25 = var25.Parent
							until var12 or (not var25)

							if not var12 and var25 then
								table.insert(var22, var25)
								var2 = nil
								bool2 = false
							end
						end
					end
				until bool2

				if arg3 then
					if var12 then
						if var5:GetCore("AvatarContextMenuEnabled") then
							if var4:GetPlayerFromCharacter(var12.Parent) then
								if var18 then
									var18:Cancel()
									var18 = nil
								end

								if var19 then
									var19:Disconnect()
									var19 = nil
								end

								if var20 then
									var20:Disconnect()
									var20 = nil
								end

								return
							end
						end
					end
				end

				if not var3 or (not var11) then
					return
				end

				local var27 = var3.Position
				if arg2 then
					var2 = nil
					var27 = arg2
				end

				if var18 then
					var18:Cancel()
					var18 = nil
				end

				if var19 then
					var19:Disconnect()
					var19 = nil
				end

				if var20 then
					var20:Disconnect()
					var20 = nil
				end

				local var28 = Pather(var27, var3.Normal)
				if var28:IsValidPath() then
					HandleMoveTo(var28, var27, var2, var11)
					return
				end

				var28:Cleanup()
				if var18 and var18:IsActive() then
					var18:Cancel()
				end

				if str1 then
					var9.PlayFailureAnimation()
				end

				var9.DisplayFailureWaypoint(var27)
				return
			end

			var2 = tbl2.Raycast
			var3 = Ray.new(bool1.Origin, bool1.Direction * 1000)
			var22 = true
			local var29
			if var17 then
				var29 = var17
			else
				var17 = {}
				assert(var17, "")
				local var30 = var13
				table.insert(var17, var30 and var13.Character)
				var29 = var17
			end

			local var31, var32, var33 = var2(var3, var22, var29)
			local var34, var35 = tbl2.FindCharacterAncestor(var31)
			if arg3 then
				if var35 then
					if var5:GetCore("AvatarContextMenuEnabled") then
						if var4:GetPlayerFromCharacter(var35.Parent) then
							if var18 then
								var18:Cancel()
								var18 = nil
							end

							if var19 then
								var19:Disconnect()
								var19 = nil
							end

							if var20 then
								var20:Disconnect()
								var20 = nil
							end

							return
						end
					end
				end
			end

			if arg2 then
				var32 = arg2
				var34 = nil
			end

			if not var32 then
				return
			end

			if not var11 then
				return
			end

			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var36 = Pather(var32, var33)
			if var36:IsValidPath() then
				HandleMoveTo(var36, var32, var34, var11)
				return
			end

			var36:Cleanup()
			if var18 and var18:IsActive() then
				var18:Cancel()
			end

			if str1 then
				var9.PlayFailureAnimation()
			end

			var9.DisplayFailureWaypoint(var32)
			return
		end
	end

	bool1 = GetEquippedTool(var11)
	if 2 <= (#arg1) and (var8 and bool1) then
		bool1:Activate()
	end
end

local str3 = "Keyboard"
local var21 = require(script.Parent:WaitForChild(str3))
local var22 = setmetatable({}, var21)
var22.__index = var22
var22.new = function(arg1)
	local var1 = setmetatable(var21.new(arg1), var22)
	var1.fingerTouches = {}
	var1.numUnsunkTouches = 0
	var1.mouse2DownTime = tick()
	var1.mouse2DownPos = Vector2.new()
	var1.mouse2UpTime = tick()
	var1.keyboardMoveVector = Vector3.new(0, 0, 0)
	var1.tapConn = nil
	var1.inputBeganConn = nil
	var1.inputChangedConn = nil
	var1.inputEndedConn = nil
	var1.humanoidDiedConn = nil
	var1.characterChildAddedConn = nil
	var1.onCharacterAddedConn = nil
	var1.characterChildRemovedConn = nil
	var1.renderSteppedConn = nil
	var1.menuOpenedConnection = nil
	var1.preferredInputChangedConnection = nil
	var1.running = false
	var1.wasdEnabled = false
	return var1
end

var22.DisconnectEvents = function(arg1)
	local var2 = arg1.tapConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputBeganConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputChangedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputEndedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.humanoidDiedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.onCharacterAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.renderSteppedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildRemovedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.menuOpenedConnection
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.preferredInputChangedConnection
	if var2 then
		var2:Disconnect()
	end
end

var22.OnTouchBegan = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil and (not arg3) then
		local var1 = arg1.numUnsunkTouches + 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = arg3
end

var22.OnTouchChanged = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil then
		arg1.fingerTouches[arg2] = arg3
		if not arg3 then
			local var1 = arg1.numUnsunkTouches + 1
			arg1.numUnsunkTouches = var1
		end
	end
end

var22.OnTouchEnded = function(arg1, arg2, _)
	if arg1.fingerTouches[arg2] ~= nil and arg1.fingerTouches[arg2] == false then
		local var1 = arg1.numUnsunkTouches - 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = nil
end

var22.OnPreferredInputChanged = function(_)
	local var3 = var13.Character
	if var3 then
		local var4 = var2.PreferredInput == Enum.PreferredInput.Touch
		for k1, v1 in pairs(var3:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			v1.ManualActivationOnly = var4
		end
	end
end

var22.OnCharacterAdded = function(arg1, arg2)
	arg1:DisconnectEvents()
	arg1.inputBeganConn = var2.InputBegan:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchBegan(arg1, arg2)
		end

		if arg1.wasdEnabled then
			if arg2 == false then
				if arg1.UserInputType == Enum.UserInputType.Keyboard then
					if tbl1[arg1.KeyCode] then
						if var18 then
							var18:Cancel()
							var18 = nil
						end

						if var19 then
							var19:Disconnect()
							var19 = nil
						end

						if var20 then
							var20:Disconnect()
							var20 = nil
						end

						var9.CancelFailureAnimation()
					end
				end
			end
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2DownTime = tick()
			arg1.mouse2DownPos = arg1.Position
		end
	end)

	arg1.inputChangedConn = var2.InputChanged:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchChanged(arg1, arg2)
		end
	end)

	arg1.inputEndedConn = var2.InputEnded:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchEnded(arg1, arg2)
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2UpTime = tick()
			local var2 = var18
			local var3 = arg1.Position
			if not var2 then
				var2 = arg1.keyboardMoveVector.Magnitude <= 0
			end

			if arg1.mouse2UpTime - arg1.mouse2DownTime < 0.25 and ((var3 - arg1.mouse2DownPos).magnitude < 5 and var2) then
				OnTap({ var3 })
			end
		end
	end)

	arg1.tapConn = var2.TouchTap:Connect(function(arg1, arg2)
		if not arg2 then
			OnTap(arg1, nil, true)
		end
	end)

	arg1.menuOpenedConnection = var8.MenuOpened:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end)

	local function OnCharacterChildAdded(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = true
		end

		if arg1:IsA("Humanoid") then
			local var4 = arg1.humanoidDiedConn
			if var4 then
				var4:Disconnect()
			end

			arg1.humanoidDiedConn = arg1.Died:Connect(function()
			end)

		end
	end

	arg1.characterChildAddedConn = arg2.ChildAdded:Connect(function(arg1)
		OnCharacterChildAdded(arg1)
	end)

	arg1.characterChildRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = false
		end
	end)

	for k1, v1 in pairs(arg2:GetChildren()) do
		OnCharacterChildAdded(v1)
	end

	arg1.preferredInputChangedConnection = var2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		arg1:OnPreferredInputChanged()
	end)
end

var22.Start = function(arg1)
	arg1:Enable(true)
end

var22.Stop = function(arg1)
	arg1:Enable(false)
end

var22.CleanupPath = function(_)
	if var18 then
		var18:Cancel()
		var18 = nil
	end

	if var19 then
		var19:Disconnect()
		var19 = nil
	end

	if var20 then
		var20:Disconnect()
		var20 = nil
	end
end

var22.Enable = function(arg1, arg2, arg3, arg4)
	if arg2 then
		if not arg1.running then
			if var13.Character then
				arg1:OnCharacterAdded(var13.Character)
			end

			arg1.onCharacterAddedConn = var13.CharacterAdded:Connect(function(arg1)
				arg1:OnCharacterAdded(arg1)
			end)

			arg1.running = true
		end

		arg1.touchJumpController = arg4
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(arg1.jumpEnabled)
		end
	else
		if arg1.running then
			arg1:DisconnectEvents()
			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var3 = var13.Character
			if var2.PreferredInput == Enum.PreferredInput.Touch and var3 then
				for k1, v1 in pairs(var3:GetChildren()) do
					if not v1:IsA("Tool") then
						continue
					end

					v1.ManualActivationOnly = false
				end
			end

			arg1.running = false
		end

		if arg1.touchJumpController and (not arg1.jumpEnabled) then
			arg1.touchJumpController:Enable(true)
		end

		arg1.touchJumpController = nil
	end

	var21.Enable(arg1, arg2)
	arg1.wasdEnabled = arg2 and arg3
	arg1.enabled = arg2
end

var22.OnRenderStepped = function(arg1, arg2)
	arg1.isJumping = false
	if var18 then
		var18:OnRenderStepped(arg2)
		if var18 then
			arg1.moveVector = var18.NextActionMoveDirection
			arg1.moveVectorIsCameraRelative = false
			if var18.NextActionJump then
				arg1.isJumping = true
			end
		else
			arg1.moveVector = arg1.keyboardMoveVector
			arg1.moveVectorIsCameraRelative = true
		end
	else
		arg1.moveVector = arg1.keyboardMoveVector
		arg1.moveVectorIsCameraRelative = true
	end

	if arg1.jumpRequested then
		arg1.isJumping = true
	end
end

var22.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.keyboardMoveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg1.wasdEnabled then
		arg1.keyboardMoveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
	end
end

var22.UpdateJump = function(_)
end

var22.SetShowPath = function(_, arg2)
	bool1 = arg2
end

var22.GetShowPath = function(_)
	return bool1
end

var22.SetWaypointTexture = function(_, arg2)
	var9.SetWaypointTexture(arg2)
end

var22.GetWaypointTexture = function(_)
	return var9.GetWaypointTexture()
end

var22.SetWaypointRadius = function(_, arg2)
	var9.SetWaypointRadius(arg2)
end

var22.GetWaypointRadius = function(_)
	return var9.GetWaypointRadius()
end

var22.SetEndWaypointTexture = function(_, arg2)
	var9.SetEndWaypointTexture(arg2)
end

var22.GetEndWaypointTexture = function(_)
	return var9.GetEndWaypointTexture()
end

var22.SetWaypointsAlwaysOnTop = function(_, arg2)
	var9.SetWaypointsAlwaysOnTop(arg2)
end

var22.GetWaypointsAlwaysOnTop = function(_)
	return var9.GetWaypointsAlwaysOnTop()
end

var22.SetFailureAnimationEnabled = function(_, arg2)
	str1 = arg2
end

var22.GetFailureAnimationEnabled = function(_)
	return str1
end

local function UpdateIgnoreTag(arg1)
	if arg1 == var14 then
		return
	end

	if var15 then
		var15:Disconnect()
		var15 = nil
	end

	if var16 then
		var16:Disconnect()
		var16 = nil
	end

	var14 = arg1
	local var1 = var13
	var17 = { var1 and var13.Character }
	if var14 ~= nil then
		for k1, v1 in ipairs((var7:GetTagged(var14))) do
			table.insert(var17, v1)
		end

		var15 = var7:GetInstanceAddedSignal(var14):Connect(function(arg1)
			table.insert(var17, arg1)
		end)

		var16 = var7:GetInstanceRemovedSignal(var14):Connect(function(arg1)
			for i1 = 1, #var17 do
				if var17[i1] ~= arg1 then
					continue
				end

				var17[i1] = var17[#var17]
				table.remove(var17)
				return
			end
		end)

	end
end

var22.SetIgnoredPartsTag = function(_, arg2)
	UpdateIgnoreTag(arg2)
end

var22.GetIgnoredPartsTag = function(_)
	return var14
end

var22.SetUseDirectPath = function(_, arg2)
	bool2 = arg2
end

var22.GetUseDirectPath = function(_)
	return bool2
end

var22.SetAgentSizeIncreaseFactor = function(_, arg2)
	num1 = arg2 / 100 + 1
end

var22.GetAgentSizeIncreaseFactor = function(_)
	return (num1 - 1) * 100
end

var22.SetUnreachableWaypointTimeout = function(_, arg2)
	num2 = arg2
end

var22.GetUnreachableWaypointTimeout = function(_)
	return num2
end

var22.SetUserJumpEnabled = function(arg1, arg2)
	arg1.jumpEnabled = arg2
	if arg1.touchJumpController then
		arg1.touchJumpController:Enable(arg2)
	end
end

var22.GetUserJumpEnabled = function(arg1)
	return arg1.jumpEnabled
end

var22.MoveTo = function(_, arg2, arg3, arg4)
	local var2 = var13.Character
	if var2 == nil then
		return false
	end

	local var4 = Pather(arg2, Vector3.new(0, 1, 0), arg4)
	if var4 and var4:IsValidPath() then
		HandleMoveTo(var4, arg2, nil, var2, arg3)
		return true
	end

	return false
end

return var22

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.PathDisplay [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = RaycastParams.new()
var2.FilterType = Enum.RaycastFilterType.Exclude
str1 = {
	spacing = 8,
	image = "rbxasset://textures/Cursors/Gamepad/Pointer.png",
	imageSize = Vector2.new(2, 2),
}

local var3 = Instance.new("Model")
var3.Name = "PathDisplayPoints"
local var4 = Instance.new("Part")
var4.Anchored = true
var4.CanCollide = false
var4.Transparency = 1
var4.Name = "PathDisplayAdornee"
var4.CFrame = CFrame.new(0, 0, 0)
var4.Parent = var3
local num1 = 30
local tbl1 = {}
local tbl2 = {}
local tbl3 = {}
for i1 = 1, num1 do
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Archivable = false
	var5.Adornee = var4
	var5.Image = str1.image
	var5.Size = str1.imageSize
	tbl3[i1] = var5
end

str1.setCurrentPoints = function(arg1)
	if typeof(arg1) == "table" then
		tbl1 = arg1
		return
	end

	tbl1 = {}
end

str1.clearRenderedPath = function()
	for k1, v1 in ipairs(tbl2) do
		v1.Parent = nil
		local var1 = num1 + 1
		num1 = var1
		tbl3[num1] = v1
	end

	tbl2 = {}
	var3.Parent = nil
end

local function renderPoint(arg1, _)
	if num1 == 0 then
		return nil
	end

	local var5 = tbl3[1]
	local var6
	if not var5 then
		var6 = nil
	else
		tbl3[1] = tbl3[num1]
		tbl3[num1] = nil
		local var7 = num1 - 1
		num1 = var7
		var6 = var5
	end

	if var1 then
		var2.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
		var5 = workspace:Raycast(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), var2)
		if not var5 then
			return nil
		end

		var6.CFrame = CFrame.lookAlong(var5.Position, var5.Normal)
		var6.Parent = var3
		return var6
	end

	local var8, var9, var10 = workspace:FindPartOnRayWithIgnoreList(Ray.new(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0)), { game.Players.LocalPlayer.Character, workspace.CurrentCamera })
	if not var8 then
		return nil
	end

	var6.CFrame = CFrame.new(var9, var9 + var10)
	var6.Parent = var3
	return var6
end

str1.renderPath = function()
	str1.clearRenderedPath()
	if not tbl1 or #tbl1 == 0 then
		return
	end

	local var1 = #tbl1
	tbl2[1] = renderPoint(tbl1[var1], true)
	local num1 = 0
	if not tbl2[1] then
		return
	end

	while true do
		local var2 = tbl1[var1]
		local var4 = tbl1[var1 - 1]
		if var1 < 2 then
			break
		end

		local var5 = var4 - var2
		local var7 = var5.magnitude
		if var7 < num1 then
			num1 = num1 - var7
		else
			local var9 = renderPoint(var2 + var5.unit * num1, false)
			if var9 then
				tbl2[#tbl2 + 1] = var9
			end
		end

		var1 = var1 - 1
		num1 = num1 + str1.spacing
	end

	var3.Parent = workspace.CurrentCamera
end

return str1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchJump [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "CharacterUtil"
local str3 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
str1 = require(var1:WaitForChild(str3)).getUserFlag("UserAllowAbilityControls")
local str4 = "AvatarAbilitiesInterface"
str2 = nil
str2 = str1 and require(script.Parent:WaitForChild(str4))
local str5 = "BaseCharacterController"
local var4 = require(script.Parent:WaitForChild(str5))
local var5 = game:GetService("GuiService")
str4 = setmetatable({}, var4)
str4.__index = str4
str4.new = function()
	local var1 = setmetatable(var4.new(), str4)
	var1.parentUIFrame = nil
	var1.jumpButton = nil
	var1.externallyEnabled = false
	var1.isJumping = false
	var1._active = false
	var1._connectionUtil = var2.new()
	return var1
end

str3 = {
	"rbxasset://textures/ui/Input/JumpButtonRegular.png",
	"rbxasset://textures/ui/Input/JumpButtonPressed.png",
}

str4._reset = function(arg1)
	arg1.isJumping = false
	arg1.touchObject = nil
	if arg1.jumpButton then
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[1]
			return
		end

		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end

str4.EnableButton = function(arg1, arg2)
	if arg2 == arg1._active then
		return
	end

	if arg2 then
		if not arg1.jumpButton then
			arg1:Create()
		end

		arg1.jumpButton.Visible = true
		local function fn2(arg1)
			if arg1 == arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("JUMP_INPUT_ENDED", arg1.jumpButton.InputEnded:Connect(fn2))
		fn2 = function()
			if arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("MENU_OPENED", var5.MenuOpened:Connect(fn2))
	else
		if arg1.jumpButton then
			arg1.jumpButton.Visible = false
		end

		arg1._connectionUtil:disconnect("JUMP_INPUT_ENDED")
		arg1._connectionUtil:disconnect("MENU_OPENED")
	end

	arg1:_reset()
	arg1._active = arg2
end

str4.UpdateEnabled = function(arg1)
	local var2 = var3.getChild("Humanoid", "Humanoid")
	if var2 and (arg1.externallyEnabled and (var2.UseJumpPower and 0 < var2.JumpPower or not var2.UseJumpPower and (0 < var2.JumpHeight and var2:GetStateEnabled(Enum.HumanoidStateType.Jumping)))) then
		arg1:EnableButton(true)
		return
	end

	arg1:EnableButton(false)
end

str4._setupConfigurations = function(arg1)
	local function update()
		arg1:UpdateEnabled()
	end

	arg1._connectionUtil:trackConnection("HUMANOID", (var3.onChild("Humanoid", "Humanoid", function(arg1)
		arg1:UpdateEnabled()
		arg1:_reset()
		local var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", arg1:GetPropertyChangedSignal("JumpPower"):Connect(var1))
		var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", arg1:GetPropertyChangedSignal("JumpHeight"):Connect(var1))
		var1 = function(arg1, arg2)
			if arg1 == Enum.HumanoidStateType.Jumping and arg2 ~= arg1._active then
				arg1:UpdateEnabled()
			end
		end

		arg1._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", arg1.StateEnabledChanged:Connect(var1))
	end)))
end

str4.Enable = function(arg1, arg2, arg3)
	if arg3 then
		arg1.parentUIFrame = arg3
	end

	if arg1.externallyEnabled == arg2 then
		return
	end

	arg1.externallyEnabled = arg2
	arg1:UpdateEnabled()
	if arg2 then
		arg1:_setupConfigurations()
		return
	end

	arg1._connectionUtil:disconnectAll()
end

str4.Create = function(arg1)
	if not arg1.parentUIFrame then
		return
	end

	if arg1.jumpButton then
		arg1.jumpButton:Destroy()
		arg1.jumpButton = nil
	end

	if arg1.absoluteSizeChangedConn then
		arg1.absoluteSizeChangedConn:Disconnect()
		arg1.absoluteSizeChangedConn = nil
	end

	if str1 and arg1.avatarAbilitiesEnabledChangedConn then
		arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
		arg1.avatarAbilitiesEnabledChangedConn = nil
	end

	arg1.jumpButton = Instance.new("ImageButton")
	arg1.jumpButton.Name = "JumpButton"
	arg1.jumpButton.Visible = false
	arg1.jumpButton.BackgroundTransparency = 1
	if str1 and str2.isEnabled() then
		arg1.jumpButton.Image = str3[1]
	else
		arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
		arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
	end

	local function ResizeJumpButton()
		local var2 = math.min(arg1.parentUIFrame.AbsoluteSize.x, arg1.parentUIFrame.AbsoluteSize.y) <= 500
		if str1 then
			if str2.isEnabled() then
				local var3 = if var2 then 72 else 120
				local var4 = if var2 then 64 else 100
				arg1.jumpButton.Image = str3[1]
				arg1.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				arg1.jumpButton.ImageRectSize = Vector2.new(0, 0)
				arg1.jumpButton.Size = UDim2.new(0, var3, 0, var3)
				arg1.jumpButton.Position = UDim2.new(1, -var3 - var4, 1, -var3 - (if var2 then 64 else 112))
				return
			end
		end

		local var5 = if var2 then 70 else 120
		if str1 then
			arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
		end

		arg1.jumpButton.Size = UDim2.new(0, var5, 0, var5)
		local var6 = var2 and UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 - 20) or UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 * 1.75)
		arg1.jumpButton.Position = var6
	end

	ResizeJumpButton()
	arg1.absoluteSizeChangedConn = arg1.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeJumpButton)
	if str1 then
		arg1.avatarAbilitiesEnabledChangedConn = str2.GetEnabledChangedSignal():Connect(ResizeJumpButton)
	end

	arg1.touchObject = nil
	arg1.jumpButton.InputBegan:connect(function(arg1)
		if arg1.touchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.touchObject = arg1
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[2]
		else
			arg1.jumpButton.ImageRectOffset = Vector2.new(146, 146)
		end

		arg1.isJumping = true
	end)

	arg1.jumpButton.Parent = arg1.parentUIFrame
end

return str4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick [ModuleScript]
-- y u r i

game:GetService("Players")
UserSettings():GetService("UserGameSettings")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
local var2 = nil
var2 = var1 and require(script.Parent:WaitForChild(str2))
str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var3 = game:GetService("GuiService")
local var4 = game:GetService("UserInputService")
local var5 = setmetatable({}, str1)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str1.new(), var5)
	var1.isFollowStick = false
	var1.thumbstickFrame = nil
	var1.moveTouchObject = nil
	var1.onTouchMovedConn = nil
	var1.onTouchEndedConn = nil
	var1.screenPos = nil
	var1.stickImage = nil
	var1.thumbstickSize = nil
	return var1
end

var5.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1.thumbstickFrame.Visible = true
	else
		arg1.thumbstickFrame.Visible = false
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
end

var5.OnInputEnded = function(arg1)
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickFrame.Size.X.Offset / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickFrame.Size.Y.Offset / 2 - arg1.thumbstickSize / 4)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.moveTouchObject = nil
end

var5.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onTouchMovedConn then
			arg1.onTouchMovedConn:Disconnect()
			arg1.onTouchMovedConn = nil
		end

		if arg1.onTouchEndedConn then
			arg1.onTouchEndedConn:Disconnect()
			arg1.onTouchEndedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var1 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.Name = "ThumbstickFrame"
	arg1.thumbstickFrame.Active = true
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	local var5 = Instance.new("ImageLabel")
	var5.Name = "OuterImage"
	var5.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	var5.ImageRectOffset = Vector2.new()
	var5.ImageRectSize = Vector2.new(220, 220)
	var5.BackgroundTransparency = 1
	var5.Position = UDim2.new(0, 0, 0, 0)
	arg1.stickImage = Instance.new("ImageLabel")
	arg1.stickImage.Name = "StickImage"
	arg1.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	arg1.stickImage.ImageRectOffset = Vector2.new(220, 0)
	arg1.stickImage.ImageRectSize = Vector2.new(111, 111)
	arg1.stickImage.BackgroundTransparency = 1
	arg1.stickImage.ZIndex = 2
	local function ResizeThumbstick()
		local var4 = math.min(arg2.AbsoluteSize.X, arg2.AbsoluteSize.Y) <= 500
		if var1 then
			if var2.isEnabled() then
				local var6 = if var4 then 64 else 100
				local var7 = if var4 then 64 else 112
				local var8 = arg1
				var8.thumbstickSize = if var4 then 72 else 120
				arg1.screenPos = UDim2.new(0, var6, 1, -arg1.thumbstickSize - var7)
			else
				local var9 = arg1
				var9.thumbstickSize = if var4 then 70 else 120
				local var10 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
				arg1.screenPos = var10
			end
		else
			local var11 = arg1
			var11.thumbstickSize = if var4 then 70 else 120
			local var12 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
			arg1.screenPos = var12
		end

		arg1.thumbstickFrame.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.thumbstickFrame.Position = arg1.screenPos
		var5.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.stickImage.Size = UDim2.new(0, arg1.thumbstickSize / 2, 0, arg1.thumbstickSize / 2)
		arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var1 then
		arg1.avatarAbilitiesEnabledChangedConn = var2.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	var5.Parent = arg1.thumbstickFrame
	arg1.stickImage.Parent = arg1.thumbstickFrame
	local var6 = nil
	arg1.thumbstickFrame.InputBegan:Connect(function(arg1)
		if arg1.moveTouchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.moveTouchObject = arg1
		arg1.thumbstickFrame.Position = UDim2.new(0, arg1.Position.X - arg1.thumbstickFrame.Size.X.Offset / 2, 0, arg1.Position.Y - arg1.thumbstickFrame.Size.Y.Offset / 2)
		var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
		Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y)
	end)

	local function MoveStick(arg1)
		local var1 = Vector2.new(arg1.X - var6.X, arg1.Y - var6.Y)
		local var5 = arg1.thumbstickFrame.AbsoluteSize.X / 2
		local var7 = var1.magnitude
		if arg1.isFollowStick and var5 < var7 then
			local var8 = var1.unit * var5
			arg1.thumbstickFrame.Position = UDim2.new(0, arg1.X - arg1.thumbstickFrame.AbsoluteSize.X / 2 - var8.X, 0, arg1.Y - arg1.thumbstickFrame.AbsoluteSize.Y / 2 - var8.Y)
		else
			var1 = var1.unit * math.min(var7, var5)
		end

		arg1.stickImage.Position = UDim2.new(0, var1.X + arg1.stickImage.AbsoluteSize.X / 2, 0, var1.Y + arg1.stickImage.AbsoluteSize.Y / 2)
	end

	arg1.onTouchMovedConn = var4.TouchMoved:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
			local var1 = Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y) / (arg1.thumbstickSize / 2)
			local var3 = var1.magnitude
			if var3 < 0.05 then
				var1 = Vector3.new()
			else
				var1 = var1.unit * math.min(1, (var3 - 0.05) / 0.95)
				var1 = Vector3.new(var1.X, 0, var1.Y)
			end

			arg1.moveVector = var1
			MoveStick(arg1.Position)
		end
	end)

	arg1.onTouchEndedConn = var4.TouchEnded:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var3.MenuOpened:Connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Keyboard [ModuleScript]
-- y u r i

script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "BaseCharacterController"
local var1 = require(script.Parent:WaitForChild(str1))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = Vector3.new()
local var5 = setmetatable({}, var1)
var5.__index = var5
var5.new = function(arg1)
	local var2 = setmetatable(var1.new(), var5)
	var2.CONTROL_ACTION_PRIORITY = arg1
	var2.forwardValue = 0
	var2.backwardValue = 0
	var2.leftValue = 0
	var2.rightValue = 0
	var2.jumpEnabled = true
	return var2
end

var5.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.moveVector = var4
	arg1.jumpRequested = false
	arg1:UpdateJump()
	if arg2 then
		arg1:BindContextActions()
		arg1:ConnectFocusEventListeners()
	else
		arg1._connectionUtil:disconnectAll()
	end

	arg1.enabled = arg2
	return true
end

var5.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.moveVector = var4
		return
	end

	arg1.moveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
end

var5.UpdateJump = function(arg1)
	arg1.isJumping = arg1.jumpRequested
end

var5.BindContextActions = function(arg1)
	var3:BindActionAtPriority("moveForwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.forwardValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterForward)

	var3:BindActionAtPriority("moveBackwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.backwardValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterBackward)

	var3:BindActionAtPriority("moveLeftAction", function(_, arg2, _)
		local var1 = arg1
		var1.leftValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterLeft)

	var3:BindActionAtPriority("moveRightAction", function(_, arg2, _)
		local var1 = arg1
		var1.rightValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterRight)

	var3:BindActionAtPriority("jumpAction", function(_, arg2, _)
		local var2 = arg1.jumpEnabled
		local var3 = arg1
		if var2 then
			var2 = arg2 == Enum.UserInputState.Begin
		end

		var3.jumpRequested = var2
		arg1:UpdateJump()
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterJump)

	arg1._connectionUtil:trackBoundFunction("moveForwardAction", function()
		var3:UnbindAction("moveForwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveBackwardAction", function()
		var3:UnbindAction("moveBackwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveLeftAction", function()
		var3:UnbindAction("moveLeftAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveRightAction", function()
		var3:UnbindAction("moveRightAction")
	end)

	arg1._connectionUtil:trackBoundFunction("jumpAction", function()
		var3:UnbindAction("jumpAction")
	end)
end

var5.ConnectFocusEventListeners = function(arg1)
	local function onFocusReleased()
		arg1.moveVector = var4
		arg1.forwardValue = 0
		arg1.backwardValue = 0
		arg1.leftValue = 0
		arg1.rightValue = 0
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	local var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("textBoxFocusReleased", var2.TextBoxFocusReleased:Connect(var1))
	var1 = function(_)
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	arg1._connectionUtil:trackConnection("textBoxFocused", var2.TextBoxFocused:Connect(var1))
	var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("windowFocusReleased", var2.WindowFocused:Connect(var1))
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay [ModuleScript]
-- y u r i

local var1 = UDim2.new(0, 42, 0, 50)
local var2 = Vector2.new(0, 0.5)
local var3 = Vector2.new(0, 1)
local var4 = Vector2.new(0, 0.5)
local var5 = Vector2.new(0.1, 0.5)
local var6 = Vector2.new(-0.1, 0.5)
local var7 = Vector2.new(1.5, 1.5)
local var8 = RaycastParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local str1 = "FlagUtil"
local bool1 = false
local str2 = "rbxasset://textures/ui/traildot.png"
local str3 = "rbxasset://textures/ui/waypoint.png"
local var9 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
str1 = function()
	local var3 = Instance.new("Part")
	var3.Size = Vector3.new(1, 1, 1)
	var3.Anchored = true
	var3.CanCollide = false
	var3.Name = "TrailDot"
	var3.Transparency = 1
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Name = "TrailDotImage"
	var5.Size = var7
	var5.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var5.AlwaysOnTop = bool1
	var5.Image = str2
	var5.Adornee = var3
	var5.Parent = var3
	local var6 = Instance.new("Part")
	var6.Size = Vector3.new(2, 2, 2)
	var6.Anchored = true
	var6.CanCollide = false
	var6.Name = "EndWaypoint"
	var6.Transparency = 1
	local var8 = Instance.new("ImageHandleAdornment")
	var8.Name = "TrailDotImage"
	var8.Size = var7
	var8.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var8.AlwaysOnTop = bool1
	var8.Image = str2
	var8.Adornee = var6
	var8.Parent = var6
	local var9 = Instance.new("BillboardGui")
	var9.Name = "EndWaypointBillboard"
	var9.Size = var1
	var9.LightInfluence = 0
	var9.SizeOffset = var2
	var9.AlwaysOnTop = true
	var9.Adornee = var6
	var9.Parent = var6
	local var10 = Instance.new("ImageLabel")
	var10.Image = str3
	var10.BackgroundTransparency = 1
	var10.Size = UDim2.new(1, 0, 1, 0)
	var10.Parent = var9
	local var11 = Instance.new("Part")
	var11.Size = Vector3.new(2, 2, 2)
	var11.Anchored = true
	var11.CanCollide = false
	var11.Name = "FailureWaypoint"
	var11.Transparency = 1
	local var12 = Instance.new("ImageHandleAdornment")
	var12.Name = "TrailDotImage"
	var12.Size = var7
	var12.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var12.AlwaysOnTop = bool1
	var12.Image = str2
	var12.Adornee = var11
	var12.Parent = var11
	local var13 = Instance.new("BillboardGui")
	var13.Name = "FailureWaypointBillboard"
	var13.Size = var1
	var13.LightInfluence = 0
	var13.SizeOffset = var4
	var13.AlwaysOnTop = true
	var13.Adornee = var11
	var13.Parent = var11
	local var14 = Instance.new("Frame")
	var14.BackgroundTransparency = 1
	var14.Size = UDim2.new(0, 0, 0, 0)
	var14.Position = UDim2.new(0.5, 0, 1, 0)
	var14.Parent = var13
	local var15 = Instance.new("ImageLabel")
	var15.Image = str3
	var15.BackgroundTransparency = 1
	var15.Position = UDim2.new(0, -var1.X.Offset / 2, 0, -var1.Y.Offset)
	var15.Size = var1
	var15.Parent = var14
	return var3, var6, var11
end

local var10 = game:GetService("Workspace")
local var11 = game:GetService("Players").LocalPlayer
local var12 = game:GetService("TweenService")
local var13 = game:GetService("RunService")
local var14, var15, var16 = str1()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

local function placePathWaypoint(arg1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var2 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if not var2 then
			return
		end

		arg1.CFrame = CFrame.lookAlong(var2.Position, var2.Normal)
		local var3 = var10.CurrentCamera
		local var5 = var3:FindFirstChild("ClickToMoveDisplay")
		if not var5 then
			var5 = Instance.new("Model")
			var5.Name = "ClickToMoveDisplay"
			var5.Parent = var3
		end

		arg1.Parent = var5
		return
	end

	local var12, var13, var14 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var12 then
		arg1.CFrame = CFrame.new(var13, var13 + var14)
		local var15 = var10.CurrentCamera
		local var17 = var15:FindFirstChild("ClickToMoveDisplay")
		if not var17 then
			var17 = Instance.new("Model")
			var17.Name = "ClickToMoveDisplay"
			var17.Parent = var15
		end

		arg1.Parent = var17
	end
end

tbl1.NewDisplayModel = function(_, arg2)
	local var1 = var14:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.ClosestWayPoint = arg2
	return var1
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.Destroy = function(arg1)
	arg1.Destroyed = true
	arg1.Tween:Cancel()
	arg1.DisplayModel:Destroy()
end

tbl2.NewDisplayModel = function(_, arg2)
	local var1 = var15:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl2.CreateTween = function(arg1)
	local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, -1, true)
	local var2 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, var1, { SizeOffset = var3 })
	var2:Play()
	return var2
end

tbl2.TweenInFrom = function(arg1, arg2)
	arg1.DisplayModel.EndWaypointBillboard.StudsOffset = Vector3.new(0, (arg2 - arg1.DisplayModel.Position).Y, 0)
	local var1 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), { StudsOffset = Vector3.new(0, 0, 0) })
	var1:Play()
	return var1
end

tbl2.new = function(arg1, arg2, arg3)
	local var1 = setmetatable({}, tbl2)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.Destroyed = false
	if arg3 and 5 < (arg3 - arg1).Magnitude then
		var2 = var1:TweenInFrom(arg3)
		var1.Tween = var2
		coroutine.wrap(function()
			var1.Tween.Completed:Wait()
			if not var1.Destroyed then
				var1.Tween = var1:CreateTween()
			end
		end)()

	else
		var2 = var1:CreateTween()
		var1.Tween = var2
	end

	var1.ClosestWayPoint = arg2
	return var1
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.Hide = function(arg1)
	arg1.DisplayModel.Parent = nil
end

tbl3.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

tbl3.NewDisplayModel = function(_, arg2)
	local var1 = var16:Clone()
	placePathWaypoint(var1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var3 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if var3 then
			var1.CFrame = CFrame.lookAlong(var3.Position, var3.Normal)
			local var4 = var10.CurrentCamera
			local var6 = var4:FindFirstChild("ClickToMoveDisplay")
			if not var6 then
				var6 = Instance.new("Model")
				var6.Name = "ClickToMoveDisplay"
				var6.Parent = var4
			end

			var1.Parent = var6
			return var1
		end
	end

	local var13, var14, var15 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var13 then
		var1.CFrame = CFrame.new(var14, var14 + var15)
		local var17 = var10.CurrentCamera
		local var19 = var17:FindFirstChild("ClickToMoveDisplay")
		if not var19 then
			var19 = Instance.new("Model")
			var19.Name = "ClickToMoveDisplay"
			var19.Parent = var17
		end

		var1.Parent = var19
	end

	return var1
end

tbl3.RunFailureTween = function(arg1)
	wait(0.125)
	local var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local var2 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var5 })
	var2:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 10 }):Play()
	var2.Completed:wait()
	local var3 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	local var7 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var3, { SizeOffset = var6 })
	var7:Play()
	var1 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame.ImageLabel, var1, { ImageColor3 = Color3.new(0.75, 0.75, 0.75) }):Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = -10 }):Play()
	var7.Completed:wait()
	var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	var3 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var4 })
	var3:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 0 }):Play()
	var3.Completed:wait()
	wait(0.125)
end

tbl3.new = function(arg1)
	local var1 = setmetatable({}, tbl3)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	return var1
end

local var17 = Instance.new("Animation")
var17.AnimationId = "rbxassetid://2874840706"
local var18 = nil
local num1 = 0
local function createTrailDots(arg1, arg2)
	local tbl3 = {}
	local num1 = 1
	for i1 = 1, #arg1 - 1 do
		local var1 = (arg1[i1].Position - arg1[#arg1].Position).Magnitude < 3
		local bool2 = false
		if i1 % 2 == 0 then
			bool2 = not var1
		end

		if not bool2 then
			continue
		end

		tbl3[num1] = tbl1.new(arg1[i1].Position, i1)
		num1 = num1 + 1
	end

	table.insert(tbl3, (tbl2.new(arg1[#arg1].Position, #arg1, arg2)))
	num1 = 1
	local tbl4 = {}
	for i2 = #tbl3, 1, -1 do
		tbl4[num1] = tbl3[i2]
		num1 = num1 + 1
	end

	return tbl4
end

local var19 = nil
return {
	CreatePathDisplay = function(arg1, arg2)
		local var1 = num1 + 1
		num1 = var1
		var1 = createTrailDots(arg1, arg2)
		local var2 = "ClickToMoveResizeTrail" .. num1
		var13:BindToRenderStep(var2, Enum.RenderPriority.Camera.Value - 1, function()
			if #var1 == 0 then
				var13:UnbindFromRenderStep(var2)
				return
			end

			local var3 = var10.CurrentCamera.CFrame.p
			for i1 = 1, #var1 do
				local var4 = var1[i1].DisplayModel:FindFirstChild("TrailDotImage")
				if not var4 then
					continue
				end

				var4.Size = var7 * (math.clamp((var1[i1].DisplayModel.Position - var3).Magnitude - 10, 0, 90) / 90 * 1.5 + 1)
			end
		end)

		local function removePathBeforePoint(arg1)
			for i1 = #var1, 1, -1 do
				local var2 = var1[i1]
				if var2.ClosestWayPoint > arg1 then
					break
				end

				var2:Destroy()
				var1[i1] = nil
				continue
			end
		end

		return function()
			removePathBeforePoint(#arg1)
		end, removePathBeforePoint
	end,
	DisplayFailureWaypoint = function(arg1)
		if var19 then
			var19:Hide()
		end

		local var1 = tbl3.new(arg1)
		var19 = var1
		coroutine.wrap(function()
			var1:RunFailureTween()
			var1:Destroy()
			var1 = nil
		end)()
	end,
	CreateEndWaypoint = function(arg1)
		local var1 = arg1
		return tbl2.new(var1)
	end,
	PlayFailureAnimation = function()
		local var2 = var11.Character
		local var4 = if var2 then var2:FindFirstChildOfClass("Humanoid") else nil
		if var4 then
			if var4 == nil then
				var2 = var18
			else
				var18 = var4:LoadAnimation(var17)
				assert(var18, "")
				var18.Priority = Enum.AnimationPriority.Action
				var18.Looped = false
				var2 = var18
			end

			var2:Play()
		end
	end,
	CancelFailureAnimation = function()
		if var18 ~= nil and var18.IsPlaying then
			var18:Stop()
		end
	end,
	SetWaypointTexture = function(arg1)
		str2 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointTexture = function()
		return str2
	end,
	SetWaypointRadius = function(arg1)
		var7 = Vector2.new(arg1, arg1)
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointRadius = function()
		return var7.X
	end,
	SetEndWaypointTexture = function(arg1)
		str3 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetEndWaypointTexture = function()
		return str3
	end,
	SetWaypointsAlwaysOnTop = function(arg1)
		bool1 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointsAlwaysOnTop = function()
		return bool1
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VehicleController [ModuleScript]
-- y u r i

local var1 = game:GetService("ContextActionService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var1 = setmetatable({}, tbl1)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.enabled = false
	var1.vehicleSeat = nil
	var1.throttle = 0
	var1.steer = 0
	var1.acceleration = 0
	var1.decceleration = 0
	var1.turningRight = 0
	var1.turningLeft = 0
	var1.vehicleMoveVector = Vector3.new(0, 0, 0)
	var1.autoPilot = {}
	var1.autoPilot.MaxSpeed = 0
	var1.autoPilot.MaxSteeringAngle = 0
	return var1
end

tbl1.BindContextActions = function(arg1)
	var1:BindActionAtPriority("throttleAccel", function(arg1, arg2, arg3)
		arg1:OnThrottleAccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonR2)

	var1:BindActionAtPriority("throttleDeccel", function(arg1, arg2, arg3)
		arg1:OnThrottleDeccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonL2)

	var1:BindActionAtPriority("arrowSteerRight", function(arg1, arg2, arg3)
		arg1:OnSteerRight(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Right)

	var1:BindActionAtPriority("arrowSteerLeft", function(arg1, arg2, arg3)
		arg1:OnSteerLeft(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Left)
end

tbl1.Enable = function(arg1, arg2, arg3)
	if arg2 == arg1.enabled and arg3 == arg1.vehicleSeat then
		return
	end

	arg1.enabled = arg2
	arg1.vehicleMoveVector = Vector3.new(0, 0, 0)
	if arg2 then
		if not arg3 then
			return
		end

		arg1.vehicleSeat = arg3
		arg1:SetupAutoPilot()
		arg1:BindContextActions()
		return
	end

	var1:UnbindAction("throttleAccel")
	var1:UnbindAction("throttleDeccel")
	var1:UnbindAction("arrowSteerRight")
	var1:UnbindAction("arrowSteerLeft")
	arg1.vehicleSeat = nil
end

tbl1.OnThrottleAccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.acceleration = 0
	else
		arg1.acceleration = -1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnThrottleDeccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.decceleration = 0
	else
		arg1.decceleration = 1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnSteerRight = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningRight = 0
	else
		arg1.turningRight = 1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.OnSteerLeft = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningLeft = 0
	else
		arg1.turningLeft = -1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.Update = function(arg1, arg2, arg3, arg4)
	if arg1.vehicleSeat then
		if arg3 then
			arg2 = arg2 + Vector3.new(arg1.steer, 0, arg1.throttle)
	if not arg4 then
				arg1.vehicleSeat.ThrottleFloat = -arg2.Z
			end

			arg1.vehicleSeat.SteerFloat = arg2.X
			return arg2, true
		end

		local var1 = arg1.vehicleSeat.Occupant.RootPart.CFrame:VectorToObjectSpace(arg2)
		arg1.vehicleSeat.ThrottleFloat = arg1:ComputeThrottle(var1)
		arg1.vehicleSeat.SteerFloat = arg1:ComputeSteer(var1)
		return Vector3.new(0, 0, 0), true
	end

	return arg2, false
end

tbl1.ComputeThrottle = function(_, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -arg2.Z
	end

	return 0
end

tbl1.ComputeSteer = function(arg1, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -math.atan2(-arg2.x, -arg2.z) * 57.295779513082323 / arg1.autoPilot.MaxSteeringAngle
	end

	return 0
end

tbl1.SetupAutoPilot = function(arg1)
	arg1.autoPilot.MaxSpeed = arg1.vehicleSeat.MaxSpeed
	arg1.autoPilot.MaxSteeringAngle = 35
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Vector3.new()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var3 = setmetatable({}, tbl1)
	var3.enabled = false
	var3.moveVector = var2
	var3.moveVectorIsCameraRelative = true
	var3.isJumping = false
	var3._connectionUtil = var1.new()
	return var3
end

tbl1.GetMoveVector = function(arg1)
	return arg1.moveVector
end

tbl1.IsMoveVectorCameraRelative = function(arg1)
	return arg1.moveVectorIsCameraRelative
end

tbl1.GetIsJumping = function(arg1)
	return arg1.isJumping
end

tbl1.Enable = function(_, _)
	error("BaseCharacterController:Enable must be overridden in derived classes and should not be called.")
	return false
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Gamepad [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = setmetatable({}, str1)
var4.__index = var4
local var5 = Enum.UserInputType.None
var4.new = function(arg1)
	local var1 = setmetatable(str1.new(), var4)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.forwardValue = 0
	var1.backwardValue = 0
	var1.leftValue = 0
	var1.rightValue = 0
	var1.thumbstickVector = Vector3.new(0, 0, 0)
	var1.activeGamepad = var5
	var1.gamepadConnectedConn = nil
	var1.gamepadDisconnectedConn = nil
	return var1
end

var4.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.thumbstickVector = Vector3.new(0, 0, 0)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		local var1 = arg1:GetHighestPriorityGamepad()
		arg1.activeGamepad = var1
		if arg1.activeGamepad ~= var5 then
			arg1:BindContextActions()
			arg1:ConnectGamepadConnectionListeners()
		else
			return false
		end
	else
		arg1:UnbindContextActions()
		arg1:DisconnectGamepadConnectionListeners()
		arg1.activeGamepad = var5
	end

	arg1.enabled = arg2
	return true
end

var4.GetHighestPriorityGamepad = function(_)
	local var1 = var5
	for k1, v1 in pairs((var2:GetConnectedGamepads())) do
		if v1.Value >= var1.Value then
			continue
		end

		var1 = v1
	end

	return var1
end

var4.UpdateMovement = function(arg1)
	arg1.moveVector = arg1.thumbstickVector + Vector3.new(0, 0, arg1.forwardValue + arg1.backwardValue)
end

var4.BindContextActions = function(arg1)
	if arg1.activeGamepad == var5 then
		return false
	end

	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	local function fn4(_, arg2, _)
		arg1.isJumping = arg2 == Enum.UserInputState.Begin
		return Enum.ContextActionResult.Sink
	end

	local function fn6(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			if var1 then
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
				arg1:UpdateMovement()
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end

			return Enum.ContextActionResult.Sink
		end

		if arg1.activeGamepad ~= arg3.UserInputType then
			return Enum.ContextActionResult.Pass
		end

		if arg3.KeyCode ~= Enum.KeyCode.Thumbstick1 then
			return
		end

		if var1 then
			if 0.2 < arg3.Position.magnitude then
				arg1.thumbstickVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
			end

			arg1:UpdateMovement()
		else
			if 0.2 < arg3.Position.magnitude then
				arg1.moveVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end
		end

		return Enum.ContextActionResult.Sink
	end

	local function fn8(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			arg1.forwardValue = 0
			arg1.backwardValue = 0
			arg1:UpdateMovement()
			return Enum.ContextActionResult.Sink
		end

		local num2 = 0
		if 0.2 < arg3.Position.magnitude then
			num2 = arg3.Position.Z
		end

		if arg3.KeyCode == Enum.KeyCode.ButtonUp then
			arg1.forwardValue = -num2
		else
			if arg3.KeyCode == Enum.KeyCode.ButtonDown then
				arg1.backwardValue = num2
			end
		end

		arg1:UpdateMovement()
		return Enum.ContextActionResult.Sink
	end

	if var1 then
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonCenter)
		var3:BindActionAtPriority("moveDirectionalButton", fn8, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonUp, Enum.KeyCode.ButtonDown)
	else
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
	end

	var3:BindActionAtPriority("moveThumbstick", fn6, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
	return true
end

var4.UnbindContextActions = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	if var1 then
		var3:UnbindAction("moveDirectionalButton")
	end

	var3:UnbindAction("moveThumbstick")
	var3:UnbindAction("jumpAction")
end

var4.OnNewGamepadConnected = function(arg1)
	local var2 = arg1:GetHighestPriorityGamepad()
	if var2 == arg1.activeGamepad then
		return
	end

	if var2 == var5 then
		warn("Gamepad:OnNewGamepadConnected found no connected gamepads")
		arg1:UnbindContextActions()
		return
	end

	if arg1.activeGamepad ~= var5 then
		arg1:UnbindContextActions()
	end

	arg1.activeGamepad = var2
	arg1:BindContextActions()
end

var4.OnCurrentGamepadDisconnected = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	local var2 = arg1:GetHighestPriorityGamepad()
	if arg1.activeGamepad ~= var5 and var2 == arg1.activeGamepad then
		warn("Gamepad:OnCurrentGamepadDisconnected found the supposedly disconnected gamepad in connectedGamepads.")
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	if var2 == var5 then
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	arg1.activeGamepad = var2
	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
end

var4.ConnectGamepadConnectionListeners = function(arg1)
	arg1.gamepadConnectedConn = var2.GamepadConnected:Connect(function(_)
		arg1:OnNewGamepadConnected()
	end)

	arg1.gamepadDisconnectedConn = var2.GamepadDisconnected:Connect(function(arg1)
		if arg1.activeGamepad == arg1 then
			arg1:OnCurrentGamepadDisconnected()
		end
	end)
end

var4.DisconnectGamepadConnectionListeners = function(arg1)
	if arg1.gamepadConnectedConn then
		arg1.gamepadConnectedConn:Disconnect()
		arg1.gamepadConnectedConn = nil
	end

	if arg1.gamepadDisconnectedConn then
		arg1.gamepadDisconnectedConn:Disconnect()
		arg1.gamepadDisconnectedConn = nil
	end
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VRNavigation [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = game:GetService("VRService")
local var3 = game:GetService("UserInputService")
local var4 = game:GetService("RunService")
local var5 = game:GetService("PathfindingService")
local var6 = game:GetService("ContextActionService")
local var7 = game:GetService("StarterGui")
local var8 = game:GetService("Players").LocalPlayer
str1 = RaycastParams.new()
str1.FilterType = Enum.RaycastFilterType.Exclude
local var9 = var1.getUserFlag("UserRaycastUpdateAPI2")
local var10 = Instance.new("BindableEvent")
var10.Name = "MovementUpdate"
var10.Parent = script
local var11 = nil
coroutine.wrap(function()
	local var2 = script.Parent:WaitForChild("PathDisplay")
	if var2 then
		var11 = require(var2)
	end
end)()

local str2 = "BaseCharacterController"
local var12 = require(script.Parent:WaitForChild(str2))
local var13 = setmetatable({}, var12)
var13.__index = var13
var13.new = function(arg1)
	local var1 = setmetatable(var12.new(), var13)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.navigationRequestedConn = nil
	var1.heartbeatConn = nil
	var1.currentDestination = nil
	var1.currentPath = nil
	var1.currentPoints = nil
	var1.currentPointIdx = 0
	var1.expectedTimeToNextPoint = 0
	var1.timeReachedLastPoint = tick()
	var1.moving = false
	var1.isJumpBound = false
	var1.moveLatch = false
	var1.userCFrameEnabledConn = nil
	return var1
end

var13.SetLaserPointerMode = function(_, arg2)
	pcall(function()
		var7:SetCore("VRLaserPointerMode", arg2)
	end)
end

var13.GetLocalHumanoid = function(_)
	local var2 = var8.Character
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2:GetChildren()) do
		if not v1:IsA("Humanoid") then
			continue
		end

		return v1
	end

	return nil
end

var13.HasBothHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 and var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.HasAnyHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 or var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.IsMobileVR = function(_)
	return var3.TouchEnabled
end

var13.HasGamepad = function(_)
	return var3.GamepadEnabled
end

var13.ShouldUseNavigationLaser = function(arg1)
	if arg1:IsMobileVR() then
		return true
	end

	if arg1:HasBothHandControllers() then
		return false
	end

	if not arg1:HasAnyHandControllers() then
		return not arg1:HasGamepad()
	end

	return true
end

var13.StartFollowingPath = function(arg1, arg2)
	currentPath = arg2
	currentPoints = currentPath:GetPointCoordinates()
	currentPointIdx = 1
	moving = true
	timeReachedLastPoint = tick()
	local var2 = arg1:GetLocalHumanoid()
	if var2 and (var2.Torso and 1 <= (#currentPoints)) then
		expectedTimeToNextPoint = (currentPoints[1] - var2.Torso.Position).magnitude / var2.WalkSpeed
	end

	var10:Fire("targetPoint", arg1.currentDestination)
end

var13.GoToPoint = function(arg1, arg2)
	currentPath = true
	currentPoints = { arg2 }
	currentPointIdx = 1
	moving = true
	local var1 = arg1:GetLocalHumanoid()
	timeReachedLastPoint = tick()
	expectedTimeToNextPoint = (var1.Torso.Position - arg2).magnitude / var1.WalkSpeed
	var10:Fire("targetPoint", arg2)
end

var13.StopFollowingPath = function(arg1)
	currentPath = nil
	currentPoints = nil
	currentPointIdx = 0
	moving = false
	arg1.moveVector = Vector3.new(0, 0, 0)
end

var13.TryComputePath = function(_, arg2, arg3)
	local num1 = 0
	local var1 = nil
	while not var1 do
		if num1 >= 5 then
			break
		end

		var1 = var5:ComputeSmoothPathAsync(arg2, arg3, 200)
		if var1.Status == Enum.PathStatus.ClosestNoPath or var1.Status == Enum.PathStatus.ClosestOutOfRange then
			var1 = nil
			return var1
		end

		if var1 then
			if var1.Status == Enum.PathStatus.FailStartNotEmpty then
				var1 = nil
			end
		end

		if not var1 then
			continue
		end

		if var1.Status ~= Enum.PathStatus.FailFinishNotEmpty then
			continue
		end

		arg2 = arg2 + (arg3 - arg2).Unit
		arg3 = arg3 + Vector3.new(0, 1, 0)
		num1 = num1 + 1
		var1 = nil
	end

	return var1
end

var13.OnNavigationRequest = function(arg1, arg2, _)
	local var1 = arg2.Position
	local var3 = var1.x
	local var4 = arg1.currentDestination
	local bool2 = false
	if var3 == var3 then
		bool2 = false
		if var3 ~= math.huge then
			bool2 = var3 ~= -math.huge
		end
	end

	if bool2 then
		var3 = var1.y
		bool2 = false
		if var3 == var3 then
			bool2 = false
			if var3 ~= math.huge then
				bool2 = var3 ~= -math.huge
			end
		end

		if bool2 then
			var3 = var1.z
			bool2 = false
			if var3 == var3 then
				bool2 = false
				if var3 ~= math.huge then
					bool2 = var3 ~= -math.huge
				end
			end
		end
	end

	if not bool2 then
		return
	end

	arg1.currentDestination = var1
	bool2 = arg1:GetLocalHumanoid()
	if not bool2 or (not bool2.Torso) then
		return
	end

	var3 = bool2.Torso.Position
	if (arg1.currentDestination - var3).magnitude < 12 then
		arg1:GoToPoint(arg1.currentDestination)
		return
	end

	if var4 then
		if 4 < (arg1.currentDestination - var4).magnitude then
			local var8 = arg1:TryComputePath(var3, arg1.currentDestination)
			if var8 then
				arg1:StartFollowingPath(var8)
				if not var11 then
					return
				end

				var11.setCurrentPoints(arg1.currentPoints)
				var11.renderPath()
				return
			end

			arg1:StopFollowingPath()
			if not var11 then
				return
			end

			var11.clearRenderedPath()
			return
		end
	end

	if moving then
		arg1.currentPoints[#currentPoints] = arg1.currentDestination
		return
	end

	arg1:GoToPoint(arg1.currentDestination)
end

var13.OnJumpAction = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1.isJumping = true
	end

	return Enum.ContextActionResult.Sink
end

var13.BindJumpAction = function(arg1, arg2)
	if arg2 then
		if not not arg1.isJumpBound then
			return
		end

		arg1.isJumpBound = true
		var6:BindActionAtPriority("VRJumpAction", function()
			return arg1:OnJumpAction()
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)

		return
	end

	if arg1.isJumpBound then
		arg1.isJumpBound = false
		var6:UnbindAction("VRJumpAction")
	end
end

var13.ControlCharacterGamepad = function(arg1, _, arg3, arg4)
	if arg4.KeyCode ~= Enum.KeyCode.Thumbstick1 then
		return
	end

	if arg3 == Enum.UserInputState.Cancel then
		arg1.moveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg3 ~= Enum.UserInputState.End then
		arg1:StopFollowingPath()
		if var11 then
			var11.clearRenderedPath()
		end

		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(true)
			arg1:SetLaserPointerMode("Hidden")
		end

		if 0.22 < arg4.Position.magnitude then
			arg1.moveVector = Vector3.new(arg4.Position.X, 0, -arg4.Position.Y)
			if 0 < arg1.moveVector.magnitude then
				local var1 = arg1.moveVector.unit * math.min(1, arg4.Position.magnitude)
				arg1.moveVector = var1
			end

			arg1.moveLatch = true
		end
	else
		arg1.moveVector = Vector3.new(0, 0, 0)
		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(false)
			arg1:SetLaserPointerMode("Navigation")
		end

		if arg1.moveLatch then
			arg1.moveLatch = false
			var10:Fire("offtrack")
		end
	end

	return Enum.ContextActionResult.Sink
end

var13.OnHeartbeat = function(arg1, arg2)
	local var2 = arg1:GetLocalHumanoid()
	local var3 = arg1.moveVector
	if not var2 or (not var2.Torso) then
		return
	end

	if arg1.moving then
		if arg1.currentPoints then
			local var13 = var2.Torso.Position
			local var14 = (currentPoints[1] - var13) * Vector3.new(1, 0, 1)
			local var15 = var14.magnitude
			if var15 < 1 then
				local var16 = var14 / var15
				local num1 = 0
				local var17 = currentPoints[1]
				for k1, v1 in pairs(currentPoints) do
					if k1 == 1 then
						continue
					end

					local var18 = (v1 - var17).magnitude
					num1 = num1 + var18 / var2.WalkSpeed
					var17 = v1
				end

				table.remove(currentPoints, 1)
				local var19 = currentPointIdx + 1
				currentPointIdx = var19
				if #currentPoints == 0 then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					return
				end

				if var11 then
					var11.setCurrentPoints(currentPoints)
					var11.renderPath()
				end

				expectedTimeToNextPoint = (currentPoints[1] - var13).magnitude / var2.WalkSpeed
				timeReachedLastPoint = tick()
			else
				if var9 then
					str1.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var22 = workspace:Raycast(var13 - Vector3.new(0, 1, 0), var16 * 3, str1)
					local var23 = workspace:Raycast(var22.Position + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0), str1).Position.Y - var13.Y
					if var22 and (var23 < 6 and -2 < var23) then
						var2.Jump = true
					end
				else
					local tbl1 = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var29, var30, var31 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var13 - Vector3.new(0, 1, 0), var16 * 3), tbl1)
					local var32, var33, var34 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var30 + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0)), tbl1)
					local var35 = var33.Y - var13.Y
					if var29 and (var35 < 6 and -2 < var35) then
						var2.Jump = true
					end
				end

				if expectedTimeToNextPoint + 2 < tick() - timeReachedLastPoint then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					var10:Fire("offtrack")
				end

				var3 = arg1.moveVector:Lerp(var16, arg2 * 10)
			end
		end
	end

	local var37 = var3.x
	local bool2 = false
	if var37 == var37 then
		bool2 = false
		if var37 ~= math.huge then
			bool2 = var37 ~= -math.huge
		end
	end

	if bool2 then
		var37 = var3.y
		bool2 = false
		if var37 == var37 then
			bool2 = false
			if var37 ~= math.huge then
				bool2 = var37 ~= -math.huge
			end
		end

		if bool2 then
			var37 = var3.z
			bool2 = false
			if var37 == var37 then
				bool2 = false
				if var37 ~= math.huge then
					bool2 = var37 ~= -math.huge
				end
			end
		end
	end

	if bool2 then
		arg1.moveVector = var3
	end
end

var13.OnUserCFrameEnabled = function(arg1)
	if arg1:ShouldUseNavigationLaser() then
		arg1:BindJumpAction(false)
		arg1:SetLaserPointerMode("Navigation")
		return
	end

	arg1:BindJumpAction(true)
	arg1:SetLaserPointerMode("Hidden")
end

var13.Enable = function(arg1, arg2)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		arg1.navigationRequestedConn = var2.NavigationRequested:Connect(function(arg1, arg2)
			arg1:OnNavigationRequest(arg1, arg2)
		end)

		arg1.heartbeatConn = var4.Heartbeat:Connect(function(arg1)
			arg1:OnHeartbeat(arg1)
		end)

		var6:BindAction("MoveThumbstick", function(arg1, arg2, arg3)
			local var1 = arg1
			local var2 = arg2
			local var3 = arg3
			return arg1:ControlCharacterGamepad(var1, var2, var3)
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)

		var6:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		arg1.userCFrameEnabledConn = var2.UserCFrameEnabled:Connect(function()
			arg1:OnUserCFrameEnabled()
		end)

		arg1:OnUserCFrameEnabled()
		var2:SetTouchpadMode(Enum.VRTouchpad.Left, Enum.VRTouchpadMode.VirtualThumbstick)
		var2:SetTouchpadMode(Enum.VRTouchpad.Right, Enum.VRTouchpadMode.ABXY)
		arg1.enabled = true
		return
	end

	arg1:StopFollowingPath()
	var6:UnbindAction("MoveThumbstick")
	var6:UnbindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	arg1:BindJumpAction(false)
	arg1:SetLaserPointerMode("Disabled")
	if arg1.navigationRequestedConn then
		arg1.navigationRequestedConn:Disconnect()
		arg1.navigationRequestedConn = nil
	end

	if arg1.heartbeatConn then
		arg1.heartbeatConn:Disconnect()
		arg1.heartbeatConn = nil
	end

	if arg1.userCFrameEnabledConn then
		arg1.userCFrameEnabledConn:Disconnect()
		arg1.userCFrameEnabledConn = nil
	end

	arg1.enabled = false
end

return var13

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
if require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls") then
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = Instance.new("BindableEvent")
	local bool2 = false
	local var10 = game:GetService("Players")
	local function fn3(arg1)
		var6 = nil
		var7 = nil
		if var8 then
			var8:Disconnect()
			var8 = nil
		end

		if arg1 then
			var6 = arg1:FindFirstChild("AbilityManagerActor")
			var7 = arg1:FindFirstChildOfClass("Humanoid")
			while not var7 do
				arg1.ChildAdded:wait()
				var7 = arg1:FindFirstChildOfClass("Humanoid")
			end

			var9:Fire()
			var8 = var7:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				var9:Fire()
			end)

		end
	end

	return {
		isEnabled = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			local bool3 = false
			if var6 ~= nil then
				bool3 = var7
				bool3 = bool3 and (not var7.EvaluateStateMachine)
			end

			return bool3
		end,
		GetEnabledChangedSignal = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			return var9.Event
		end,
	}

end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = {}
	return var1
end

tbl1.trackConnection = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = function()
		arg3:Disconnect()
	end
end

tbl1.trackBoundFunction = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = arg3
end

tbl1.disconnect = function(arg1, arg2)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
		arg1._connections[arg2] = nil
	end
end

tbl1.disconnectAll = function(arg1)
	for k1, v1 in pairs(arg1._connections) do
		v1()
	end

	arg1._connections = {}
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.ConnectionUtil)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.AppCommonLib).Signal
var2.describe("ConnectionUtil", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should track a connection", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		var4.new():trackConnection("Signal", var1:Connect(fn2))
		var1:fire("Testing")
		var5(str1).toBe("Testing")
	end)

	var3("should disconnect from signal", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		var2:disconnect("Signal")
		var1:fire("Testing")
		var5(str1).toBe("")
	end)

	var3("should disconnect from all", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		local str2 = ""
		fn2 = function(arg1)
			str2 = arg1
		end

		var2:trackConnection("Signal1", var6.new():Connect(fn2))
		local str3 = ""
		fn2 = function(arg1)
			str3 = arg1
		end

		var2:trackConnection("Signal2", var6.new():Connect(fn2))
		var2:disconnectAll()
		var1:fire("TestingPrimary")
		var1:fire("TestingSecondary")
		var1:fire("TestingTertiary")
		var5(str1).toBe("")
		var5(str2).toBe("")
		var5(str3).toBe("")
	end)

	var3("should call manual disconnect", function()
		local str1 = ""
		local var1 = var4.new()
		var1:trackBoundFunction("Manual", function()
			str1 = "Disconnected"
		end)

		var1:disconnect("Manual")
		var5(str1).toBe("Disconnected")
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = game:GetService("Players")
local tbl1 = { _connectionUtil = require(script.Parent:WaitForChild(str1)).new() }
tbl1._boundEvents = {}
tbl1.getLocalPlayer = function()
	return var1.LocalPlayer
end

tbl1.onLocalPlayer = function(arg1)
	local var3 = tbl1.getLocalPlayer()
	if var3 then
		arg1(var3)
	end

	local function fn2()
		local var1 = tbl1.getLocalPlayer()
		assert(var1)
		tbl1._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(var1)
	end

	tbl1._connectionUtil:trackConnection("LOCAL_PLAYER", var1:GetPropertyChangedSignal("LocalPlayer"):Connect(fn2))
	local var4 = arg1
	return tbl1._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(var4)
end

tbl1.getCharacter = function()
	local var2 = tbl1.getLocalPlayer()
	if not var2 then
		return nil
	end

	return var2.Character
end

tbl1.onCharacter = function(arg1)
	local function fn2(arg1)
		local var2 = tbl1.getCharacter()
		if var2 then
			arg1(var2)
		end

		local function fn2(arg1)
			assert(arg1)
			tbl1._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(arg1)
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_ADDED", arg1.CharacterAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_LOCAL_PLAYER", tbl1.onLocalPlayer(fn2))
	local var1 = arg1
	return tbl1._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(var1)
end

tbl1.getChild = function(arg1, arg2)
	local var2 = tbl1.getCharacter()
	if not var2 then
		return nil
	end

	local var4 = var2:FindFirstChild(arg1)
	if var4 and var4:IsA(arg2) then
		return var4
	end

	return nil
end

tbl1.onChild = function(arg1, arg2, arg3)
	local function fn2(arg1)
		local var2 = tbl1.getChild(arg1, arg2)
		if var2 then
			arg3(var2)
		end

		local function fn2(arg1)
			if arg1.Name == arg1 and arg1:IsA(arg2) then
				tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2):Fire(arg1)
			end
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", arg1.ChildAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_CHARACTER", tbl1.onCharacter(fn2))
	local var1 = arg3
	return tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2).Event:Connect(var1)
end

tbl1._getOrCreateBoundEvent = function(arg1)
	if not tbl1._boundEvents[arg1] then
		tbl1._boundEvents[arg1] = Instance.new("BindableEvent")
	end

	return tbl1._boundEvents[arg1]
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.CameraWrapper)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.TestUtils).DeferredLuaHelpers.waitForEvents
var2.describe("CameraWrapper", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should return updated camera", function()
		local var1 = var4.new()
		var1:Enable()
		local var2 = Instance.new("Camera")
		var2.Parent = game.Workspace
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).never.toBe(var2)
		game.Workspace.CurrentCamera = var2
		var6()
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).toBe(var2)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.FlagUtil [ModuleScript]
-- y u r i

return { getUserFlag = function(arg1)
	local success, result = pcall(function()
		local var1 = arg1
		return UserSettings():IsUserFeatureEnabled(var1)
	end)

	return success and result
end }

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper [ModuleScript]
-- y u r i

local var1 = require(script.Parent.ConnectionUtil)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	return (setmetatable({
		_camera = game.Workspace.CurrentCamera,
		_callbacks = {},
		_connectionUtil = var1.new(),
		_enabled = false,
	}, tbl1))
end

tbl1._connectCallbacks = function(arg1)
	arg1._camera = game.Workspace.CurrentCamera
	if not arg1._camera then
		return
	end

	for k1, v1 in arg1._callbacks, nil do
		local var1 = v1
		arg1._connectionUtil:trackConnection(k1, arg1._camera:GetPropertyChangedSignal(k1):Connect(var1))
		v1()
	end
end

tbl1.Enable = function(arg1)
	if arg1._enabled then
		return
	end

	arg1._enabled = true
	arg1._cameraChangedConnection = game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		arg1:_connectCallbacks()
	end)

	arg1:_connectCallbacks()
end

tbl1.Disable = function(arg1)
	if not arg1._enabled then
		return
	end

	arg1._enabled = false
	if arg1._cameraChangedConnection then
		arg1._cameraChangedConnection:Disconnect()
		arg1._cameraChangedConnection = nil
	end

	arg1._connectionUtil:disconnectAll()
end

tbl1.Connect = function(arg1, arg2, arg3)
	arg1._callbacks[arg2] = arg3
	if not arg1._camera then
		return
	end

	local var1 = arg3
	arg1._connectionUtil:trackConnection(arg2, arg1._camera:GetPropertyChangedSignal(arg2):Connect(var1))
end

tbl1.Disconnect = function(arg1, arg2)
	arg1._connectionUtil:disconnect(arg2)
	arg1._callbacks[arg2] = nil
end

tbl1.getCamera = function(arg1)
	return arg1._camera
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerScriptsLoader [LocalScript]
-- y u r i

local str1 = "PlayerModule"
require(script.Parent:WaitForChild(str1))

--- Players.LocalPlayer.PlayerScripts.Player.PlayerLoaded [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
if not game:IsLoaded() then
	game.Loaded:Wait()
end

local var3 = var1:WaitForChild("RemoteEvents"):WaitForChild("PlayerLoaded")
assert(var3:IsA("RemoteEvent"), "ReplicatedStorage.RemoteEvents.PlayerLoaded must be a RemoteEvent")
while true do
	if var2:GetAttribute("ClientLoaded") == true then
		break
	end

	local var4 = var2.Character
	var4 = var4 or var2.CharacterAdded:Wait()
	local var6 = var4:WaitForChild("HumanoidRootPart", 15)
	if var6 and (var6:IsA("BasePart") and (var2.Character == var4 and var6:IsDescendantOf(var4))) then
		var3:FireServer()
	end

	task.wait(0.5)
end

--- Players.LocalPlayer.PlayerScripts.Player.Reset [LocalScript]
-- y u r i

local var1 = game:GetService("StarterGui")
repeat
	local var3 = pcall(function()
		var1:SetCore("ResetButtonCallback", false)
	end)

	if not var3 then
		task.wait(1)
	end
until var3

--- Players.LocalPlayer.PlayerGui.MainGameUI.UIController [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = var1:WaitForChild("UpSide")
local var3 = game:GetService("ReplicatedStorage")
local var4 = game:GetService("TweenService")
local var5 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var6 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var7 = game:GetService("Players").LocalPlayer
local var8 = var2:WaitForChild("Skip")
var8.Visible = false
local var9 = var2:WaitForChild("InfoDop")
local var10 = var1:WaitForChild("DownSide")
local var11 = var8:WaitForChild("Skip"):WaitForChild("Move")
local var12 = var11:WaitForChild("Use")
local var13 = var3:WaitForChild("WaveState")
local var14 = var3:WaitForChild("Modes")
local var15 = var3.RemoteEvents:WaitForChild("SkipWaveVote")
local var16 = var9:WaitForChild("Wave")
local var17 = var9:WaitForChild("Mode")
local var18 = (var10:FindFirstChild("Main") or var10):WaitForChild("UpSide"):WaitForChild("ToiletsCount"):WaitForChild("Amount")
local var19 = var8:WaitForChild("Amount")
local var20 = var11:WaitForChild("UIScale")
local bool1 = false
local bool2 = false
local var21 = nil
local tbl1 = {
	easy = "Easy",
	medium = "Medium",
	hard = "Hard",
	insane = "Insane",
	crazy = "Crazy",
	endless = "Endless",
}

local tbl2 = {
	Easy = true,
	Medium = true,
	Hard = true,
	Insane = true,
	Crazy = true,
	Endless = true,
	CurrentModeGradient = true,
}

local function removeModeGradients(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("UIGradient") then
			continue
		end

		if not tbl2[v1.Name] then
			continue
		end

		v1:Destroy()
	end
end

local function normalizeMode(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	local var2 = arg1:match("^%s*(.-)%s*$")
	if not var2 or var2 == "" then
		return nil
	end

	local var4 = var2:match("^(.-)%s+[Mm][Oo][Dd][Ee]$")
	if var4 and var4 ~= "" then
		var2 = var4
	end

	return tbl1[string.lower(var2)] or var2
end

local var22 = nil
local bool3 = false
local var23 = if var12:IsA("TextButton") then var12.Text else nil
local function tweenSkipScale(arg1, arg2)
	if var21 then
		var21:Cancel()
	end

	local var1 = var4:Create(var20, arg1, { Scale = arg2 })
	var21 = var1
	var1.Completed:Connect(function()
		if var21 == var1 then
			var21 = nil
		end
	end)

	var1:Play()
end

var12.MouseEnter:Connect(function()
	bool2 = true
	if bool1 then
		return
	end

	local var1 = tweenSkipScale
	local var2 = var5
	local var3
	if not var12.Active then
		var3 = 1
	else
		if bool1 then
			var3 = 0.965
		elseif bool2 then
			var3 = 1.035
		else
			var3 = 1
		end
	end

	var1(var2, var3)
end)

var12.MouseLeave:Connect(function()
	bool2 = false
	if bool1 then
		return
	end

	local var1 = tweenSkipScale
	local var2 = var5
	local var3
	if not var12.Active then
		var3 = 1
	else
		if bool1 then
			var3 = 0.965
		elseif bool2 then
			var3 = 1.035
		else
			var3 = 1
		end
	end

	var1(var2, var3)
end)

var12.InputBegan:Connect(function(arg1)
	if var12.Active then
		local bool5 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool5 = true
			if arg1.UserInputType ~= Enum.UserInputType.Touch then
				bool5 = arg1.KeyCode == Enum.KeyCode.ButtonA
			end
		end

		if not bool5 then
			return
		end
	end

	bool1 = true
	local var1 = tweenSkipScale
	local var2 = var6
	local var3
	if not var12.Active then
		var3 = 1
	else
		if bool1 then
			var3 = 0.965
		elseif bool2 then
			var3 = 1.035
		else
			var3 = 1
		end
	end

	var1(var2, var3)
end)

var12.InputEnded:Connect(function(arg1)
	local bool4 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool4 = true
		if arg1.UserInputType ~= Enum.UserInputType.Touch then
			bool4 = arg1.KeyCode == Enum.KeyCode.ButtonA
		end
	end

	if not bool4 then
		return
	end

	bool1 = false
	bool4 = tweenSkipScale
	local var1 = var6
	local var2
	if not var12.Active then
		var2 = 1
	else
		if bool1 then
			var2 = 0.965
		elseif bool2 then
			var2 = 1.035
		else
			var2 = 1
		end
	end

	bool4(var1, var2)
end)

local function updateSkipVote()
	local var2 = var13:GetAttribute("CurrentWave")
	local var3 = var13:GetAttribute("SkipVotes")
	local var4 = var13:GetAttribute("SkipVotesRequired")
	local var5 = var13:GetAttribute("Result")
	local bool5 = false
	if var13:GetAttribute("CanSkipWave") == true then
		bool5 = false
		if var5 ~= "Win" then
			bool5 = var5 ~= "Lose"
		end
	end

	if typeof(var3) ~= "number" then
		var3 = 0
	end

	if typeof(var4) ~= "number" then
		var4 = 1
	end

	var19.Text = ("Skip Wave (%d/%d)"):format(math.max(math.floor(var3), 0), (math.max(math.floor(var4), 1)))
	var8.Visible = bool5
	local bool6 = false
	if typeof(var2) == "number" then
		bool6 = var7:GetAttribute("SkipVoteWave") == var2
	end

	if bool6 or (not bool5 or var22 ~= var2) then
		bool3 = false
	end

	local var6 = bool5
	var6 = var6 and (not bool6 and (not bool3))
	var12.Active = var6
	var12.AutoButtonColor = var6
	if not var6 then
		bool2 = false
		bool1 = false
		if var21 then
			var21:Cancel()
			var21 = nil
		end

		var20.Scale = 1
	end

	if var12:IsA("TextButton") then
		if var23 then
			if bool6 then
				var12.Text = ""
				return
			end

			if bool3 then
				var12.Text = "..."
				return
			end

			var12.Text = var23
		end
	end
end

var12.Activated:Connect(function()
	local var1 = var13:GetAttribute("CurrentWave")
	local var2 = var13:GetAttribute("CanSkipWave") == true
	local bool1 = false
	if typeof(var1) == "number" then
		bool1 = var7:GetAttribute("SkipVoteWave") == var1
	end

	if not var2 or (bool1 or (bool3 or typeof(var1) ~= "number")) then
		return
	end

	bool3 = true
	var22 = var1
	updateSkipVote()
	var15:FireServer(var1)
	task.delay(1.5, function()
		if bool3 and var22 == var1 then
			bool3 = false
			updateSkipVote()
		end
	end)
end)

local function updateWave()
	local var1 = var13:GetAttribute("IntermissionRemaining")
	local var2 = var13:GetAttribute("CurrentWave")
	local var3 = var13:GetAttribute("TotalWaves")
	if var13:GetAttribute("MatchState") == "Intermission" and (typeof(var1) == "number" and 0 < var1) then
		var16.Text = ("Intermission %d"):format((math.ceil(var1)))
		return
	end

	if typeof(var2) ~= "number" or typeof(var3) ~= "number" then
		var16.Text = "Wave ?/?"
		return
	end

	if var13:GetAttribute("IsEndless") == true then
		var16.Text = ("Wave %d"):format(var2)
		return
	end

	var16.Text = ("Wave %d/%d"):format(var2, var3)
end

var13:GetAttributeChangedSignal("CurrentWave"):Connect(updateWave)
var13:GetAttributeChangedSignal("CurrentWave"):Connect(updateSkipVote)
var13:GetAttributeChangedSignal("TotalWaves"):Connect(updateWave)
var13:GetAttributeChangedSignal("MatchState"):Connect(updateWave)
local function updateHudVisibility()
	local var2 = var13:GetAttribute("Result")
	local bool2 = true
	if var2 ~= "Win" then
		bool2 = true
		if var2 ~= "Lose" then
			bool2 = var13:GetAttribute("MatchState") == "ContinueVote"
		end
	end

	var10.Visible = not bool2
end

var13:GetAttributeChangedSignal("MatchState"):Connect(updateHudVisibility)
var13:GetAttributeChangedSignal("IntermissionRemaining"):Connect(updateWave)
var13:GetAttributeChangedSignal("IsEndless"):Connect(updateWave)
var13:GetAttributeChangedSignal("MapMode"):Connect(function()
	local str1 = "MapMode"
	local var2 = normalizeMode(var13:GetAttribute(str1))
	if var2 then
		var17.Text = ("%s Mode"):format(var2)
	else
		var17.Text = "Loading..."
	end

	local var3 = var17
	removeModeGradients(var3)
	if not var2 then
	else
		local var5 = var14:FindFirstChild(var2)
		if var5 then
	if not not var5:IsA("UIGradient") then
				str1 = var5:Clone()
				str1.Name = "CurrentModeGradient"
				str1.Enabled = true
				str1.Parent = var3
			end
		end
	end

	local var7 = var3:FindFirstChildOfClass("UIStroke")
	if var7 then
		removeModeGradients(var7)
		if not var2 then
			return
		end

		str1 = var14:FindFirstChild(var2)
		if str1 then
			if not str1:IsA("UIGradient") then
				return
			end

			local var8 = str1:Clone()
			var8.Name = "CurrentModeGradient"
			var8.Enabled = true
			var8.Parent = var7
		end
	end
end)

var13:GetAttributeChangedSignal("EnemiesAlive"):Connect(function()
	local var1 = var13:GetAttribute("EnemiesAlive")
	if typeof(var1) ~= "number" then
		var18.Text = "?"
		return
	end

	var18.Text = tostring(var1)
end)

var13:GetAttributeChangedSignal("SkipVotes"):Connect(updateSkipVote)
var13:GetAttributeChangedSignal("SkipVotesRequired"):Connect(updateSkipVote)
var13:GetAttributeChangedSignal("CanSkipWave"):Connect(updateSkipVote)
var13:GetAttributeChangedSignal("Result"):Connect(updateHudVisibility)
var13:GetAttributeChangedSignal("Result"):Connect(updateSkipVote)
var7:GetAttributeChangedSignal("SkipVoteWave"):Connect(updateSkipVote)
local str1 = "MapMode"
local var25 = normalizeMode(var13:GetAttribute(str1))
if var25 then
	var17.Text = ("%s Mode"):format(var25)
else
	var17.Text = "Loading..."
end

removeModeGradients(var17)
if not var25 then
else
	local var27 = var14:FindFirstChild(var25)
	if var27 then
if not not var27:IsA("UIGradient") then
			local var28 = var27:Clone()
			var28.Name = "CurrentModeGradient"
			var28.Enabled = true
			var28.Parent = var17
		end
	end
end

local var30 = var17:FindFirstChildOfClass("UIStroke")
if var30 then
	removeModeGradients(var30)
	if not var25 then
	else
		local var32 = var14:FindFirstChild(var25)
		if var32 then
if not not var32:IsA("UIGradient") then
				str1 = var32:Clone()
				str1.Name = "CurrentModeGradient"
				str1.Enabled = true
				str1.Parent = var30
			end
		end
	end
end

updateWave()
var25 = var13:GetAttribute("EnemiesAlive")
if typeof(var25) ~= "number" then
	var18.Text = "?"
else
	var18.Text = tostring(var25)
end

var25 = var13:GetAttribute("Result")
var30 = true
if var25 ~= "Win" then
	var30 = true
	if var25 ~= "Lose" then
		var30 = var13:GetAttribute("MatchState") == "ContinueVote"
	end
end

var10.Visible = not var30
updateSkipVote()

--- Players.LocalPlayer.PlayerGui.MainGameUI.TowerController [LocalScript]
-- y u r i

local var1 = game:GetService("PhysicsService");
(function()
	pcall(function()
		var1:RegisterCollisionGroup("TowerPreview")
	end)

	pcall(function()
		var1:CollisionGroupSetCollidable("TowerPreview", "Default", false)
	end)

	pcall(function()
		for k1, v1 in ipairs(var1:GetRegisteredCollisionGroups()) do
			var1:CollisionGroupSetCollidable("TowerPreview", v1.name, false)
			var1:CollisionGroupSetCollidable(v1.name, "TowerPreview", false)
		end
	end)
end)()

local var2 = game:GetService("Players")
local var3 = game:GetService("ReplicatedStorage")
local var4 = var3:WaitForChild("Modules")
local str1 = "TowerAnimator"
local var5 = require(var4:WaitForChild(str1))
local var6 = var4:FindFirstChild("TowerConfig")
local str2 = "TowerUpgradeConfig"
local str3 = "TowerRangeColorConfig"
local str4 = "TowerBoosterConfig"
str1 = require(var4:WaitForChild(str2))
local var7 = require(var4:WaitForChild(str4))
local var8 = var3:WaitForChild("RemoteFunctions")
local var9 = require(var4:WaitForChild(str3))
local var10 = var3:WaitForChild("RemoteEvents")
local var11 = var3:WaitForChild("Visual")
local var12 = game:GetService("TweenService")
local function rememberSupportTransparency(arg1)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("GuiObject") then
			v1:SetAttribute("SupportBackgroundTransparency", v1.BackgroundTransparency)
		end

		if v1:IsA("TextLabel") or v1:IsA("TextButton") then
			v1:SetAttribute("SupportTextTransparency", v1.TextTransparency)
			v1:SetAttribute("SupportTextStrokeTransparency", v1.TextStrokeTransparency)
		end

		if v1:IsA("ImageLabel") or v1:IsA("ImageButton") then
			v1:SetAttribute("SupportImageTransparency", v1.ImageTransparency)
		end

		if v1:IsA("UIStroke") then
			v1:SetAttribute("SupportStrokeTransparency", v1.Transparency)
		end

		if not v1:IsA("CanvasGroup") then
			continue
		end

		v1:SetAttribute("SupportGroupTransparency", v1.GroupTransparency)
	end
end

local function getTransparencyGoals(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		local tbl2 = {}
		if v1:IsA("GuiObject") then
			local var1
			if arg2 then
				var1 = 1
			else
				var1 = v1:GetAttribute("SupportBackgroundTransparency")
				var1 = var1 or v1.BackgroundTransparency
			end

			tbl2.BackgroundTransparency = var1
		end

		if not v1:IsA("TextLabel") then
			if v1:IsA("TextButton") then
				if arg2 then
					var1 = 1
				else
					var1 = v1:GetAttribute("SupportTextTransparency")
					var1 = var1 or v1.TextTransparency
				end

				tbl2.TextTransparency = var1
				if arg2 then
					var1 = 1
				else
					var1 = v1:GetAttribute("SupportTextStrokeTransparency")
					var1 = var1 or v1.TextStrokeTransparency
				end

				tbl2.TextStrokeTransparency = var1
			end
		end

		if not v1:IsA("ImageLabel") then
			if v1:IsA("ImageButton") then
				if arg2 then
					var1 = 1
				else
					var1 = v1:GetAttribute("SupportImageTransparency")
					var1 = var1 or v1.ImageTransparency
				end

				tbl2.ImageTransparency = var1
			end
		end

		if v1:IsA("UIStroke") then
			if arg2 then
				var1 = 1
			else
				var1 = v1:GetAttribute("SupportStrokeTransparency")
				var1 = var1 or v1.Transparency
			end

			tbl2.Transparency = var1
		end

		if v1:IsA("CanvasGroup") then
			if arg2 then
				var1 = 1
			else
				var1 = v1:GetAttribute("SupportGroupTransparency")
				var1 = var1 or v1.GroupTransparency
			end

			tbl2.GroupTransparency = var1
		end

		if not next(tbl2) then
			continue
		end

		tbl1[v1] = tbl2
	end

	return tbl1
end

local function applyTransparencyGoals(arg1)
	for k1, v1 in pairs(arg1) do
		for k2, v2 in pairs(v1) do
			k1[k2] = v2
		end
	end
end

local function tweenTransparencyGoals(arg1, arg2)
	for k1, v1 in pairs(arg1) do
		var12:Create(k1, TweenInfo.new(arg2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v1):Play()
	end
end

local var13 = setmetatable({}, { __mode = "k" })
local function showSupportPopup(arg1)
	local var2 = arg1:GetAttribute("LastSupportType")
	local var3 = arg1:GetAttribute("LastSupportAmount")
	if (var2 == "Income" or var2 ~= "Heal") and typeof(var3) ~= "number" then
		return
	end

	local var4 = arg1:FindFirstChild("HumanoidRootPart")
	var4 = var4 or (arg1.PrimaryPart or arg1:FindFirstChildWhichIsA("BasePart", true))
	local var6 = var11:FindFirstChild(var2)
	if not var4 or (not var4:IsA("BasePart") or (not var6 or (not var6:IsA("BillboardGui")))) then
		return
	end

	local var8 = var4:FindFirstChild("SupportPopup")
	if var8 then
		var8:Destroy()
	end

	local var9 = var6:Clone()
	var9.Name = "SupportPopup"
	var9.Adornee = var4
	var9.Enabled = true
	local var12 = var9:FindFirstChild("Amount", true)
	if var12 and (var12:IsA("TextLabel") or var12:IsA("TextButton")) then
		var12.Text = "+" .. tostring((math.floor(var3)))
	end

	var9.Parent = var4
	rememberSupportTransparency(var9)
	local var13 = getTransparencyGoals(var9, true)
	applyTransparencyGoals(var13)
	tweenTransparencyGoals(getTransparencyGoals(var9, false), 0.25)
	task.delay(2.75, function()
		if not var9.Parent then
			return
		end

		tweenTransparencyGoals(var13, 0.25)
		task.delay(0.25, function()
			if var9.Parent then
				var9:Destroy()
			end
		end)
	end)
end

local var14 = workspace:WaitForChild("Towers")
local var15 = game:GetService("RunService")
local var16 = game:GetService("UserInputService")
local var17 = game:GetService("GuiService")
local var18 = Color3.fromRGB(0, 255, 0)
local var19 = Color3.fromRGB(255, 0, 0)
local tbl1 = {
	GUI_FORWARD_ROTATION = 90,
	SCREEN_THICKNESS_RATIO = 0.0045,
	MIN_SCREEN_THICKNESS = 4,
	MAX_SCREEN_THICKNESS = 9,
	MIN_GUI_THICKNESS = 8,
	MAX_GUI_THICKNESS = 56,
	GUI_THICKNESS_STEP = 1,
	MIN_FACE_SIZE = 0.05,
	MIN_SCREEN_PIXELS_PER_STUD = 0.001,
}

local var20 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var21 = var2.LocalPlayer
local var22 = workspace.CurrentCamera
local var23 = script.Parent
local var24 = require(var6 or var4:WaitForChild("TowerUnitConfig"))
str2 = var8:WaitForChild("GetData")
str3 = var8:WaitForChild("CanPlaceTower")
str4 = var8:WaitForChild("PlaceTower")
local var25 = var8:WaitForChild("SellTower")
local var26 = var8:WaitForChild("UpgradeTower")
local var27 = var10:WaitForChild("AnimateTower")
local var28 = var10:WaitForChild("Notify")
local var29 = var10:WaitForChild("PlayerLoaded")
local var30 = var3:WaitForChild("Towers")
local var31 = var11:WaitForChild("RangeCircle")
local var32 = workspace:FindFirstChild("Mobs")
local function watchSupportTower(arg1)
	if not arg1:IsA("Model") or var13[arg1] then
		return
	end

	local str1 = "LastSupportWave"
	local var1 = tonumber(arg1:GetAttribute(str1)) or 0
	local var2 = arg1:GetAttributeChangedSignal("LastSupportWave"):Connect(function()
		local str1 = "LastSupportWave"
		local var3 = tonumber(arg1:GetAttribute(str1)) or 0
		if var1 < var3 then
			var1 = var3
			showSupportPopup(arg1)
		end
	end)

	var13[arg1] = var2
	arg1.Destroying:Connect(function()
		var2:Disconnect()
		var13[arg1] = nil
	end)
end

for k1, v1 in ipairs(var14:GetChildren()) do
	watchSupportTower(v1)
end

var14.ChildAdded:Connect(watchSupportTower)
rememberSupportTransparency = var23:WaitForChild("DownSide")
getTransparencyGoals = (rememberSupportTransparency:FindFirstChild("Main") or rememberSupportTransparency):WaitForChild("Slots")
tweenTransparencyGoals = var23:WaitForChild("DownSide")
showSupportPopup = var23:WaitForChild("DownSide")
applyTransparencyGoals = (tweenTransparencyGoals:FindFirstChild("Main") or tweenTransparencyGoals):WaitForChild("UpSide"):WaitForChild("Cash"):WaitForChild("price")
tweenTransparencyGoals = (showSupportPopup:FindFirstChild("Main") or showSupportPopup):WaitForChild("UpSide"):WaitForChild("PlacedUnits"):WaitForChild("Amount")
showSupportPopup = var23:WaitForChild("UpgradeFrameNew")
watchSupportTower = showSupportPopup:WaitForChild("MainFrame")
local var33 = watchSupportTower:WaitForChild("Buttons")
local var34 = watchSupportTower:WaitForChild("Sell"):WaitForChild("Move")
local str5 = "TowerAbilityConfig"
rememberSupportTransparency = getTransparencyGoals:WaitForChild("Template")
local var35 = showSupportPopup:WaitForChild("OwnerFrame")
local var36 = var33:WaitForChild("Upgrade")
local var37 = var33:WaitForChild("UpgradeMax")
local var38 = var34:WaitForChild("Use")
local tbl2 = { Config = require(var4:WaitForChild(str5)), RequestInFlight = false }
tbl2.UseRemote = var8:WaitForChild("UseTowerAbility")
tbl2.ProjectileEvent = var10:WaitForChild("TowerAbilityProjectile")
tbl2.Root = showSupportPopup:WaitForChild("_MoreInfo"):WaitForChild("Ability")
tbl2.Refresh = function()
end

local var39 = tbl2.Root:WaitForChild("Template")
local var40 = var39:WaitForChild("Move")
tbl2.Card = var39
local var41 = var40:WaitForChild("SelectStatus")
tbl2.Button = var40:WaitForChild("Use")
tbl2.Icon = var40:WaitForChild("AbilityIcon")
tbl2.OnCooldown = var40:WaitForChild("OnCd")
tbl2.Price = var41:WaitForChild("Price")
tbl2.PriceText = tbl2.Price:WaitForChild("price")
tbl2.TimerText = var41:WaitForChild("Timer")
str5 = var36:WaitForChild("Move")
local var42 = var37:WaitForChild("Move")
local var43 = var34:FindFirstChild("X_Bind")
local var44 = var43
local var45 = var33:WaitForChild("Target")
local var46 = var45:WaitForChild("Move")
var40 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
var41 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var47 = str5:WaitForChild("Use")
local var48 = str5:WaitForChild("UIScale")
local var49 = str5:WaitForChild("E_Bind"):WaitForChild("Amount")
local var50 = var42:WaitForChild("Use")
local var51 = var42:WaitForChild("UIScale")
local var52 = var34:WaitForChild("UIScale")
var44 = var44 and var43:FindFirstChild("Amount")
local var53 = var46:WaitForChild("Use")
local var54 = var46:WaitForChild("UIScale")
local var55 = var46:WaitForChild("T_Bind"):WaitForChild("Amount")
var49.Text = "E"
var55.Text = "T"
var13 = function(arg1)
	if not arg1 or (not arg1:IsA("Model")) then
		return
	end

	var5.prepare(arg1)
	task.spawn(function()
		local var1 = os.clock() + 5
		repeat
			if not arg1.Parent then
				return
			end

			local var2 = arg1:FindFirstChildOfClass("Humanoid")
			var2 = var2 or arg1:FindFirstChildOfClass("AnimationController")
			local var3 = var2
			var3 = var3 and var2:FindFirstChildOfClass("Animator")
			if var2 and (not var3) then
				var3 = Instance.new("Animator")
				var3.Parent = var2
			end

			if var3 then
				var5.playIdle(arg1)
				return
			end

			task.wait(0.05)
		until var1 <= os.clock()
	end)
end

var39 = { visuals = {}, actions = {} }
if var44 and (var44:IsA("TextLabel") or var44:IsA("TextButton")) then
	var44.Text = "X"
end

local function bindScaleTween(arg1, arg2, arg3, arg4)
	local var1 = arg2.Scale
	local bool1 = false
	local bool2 = false
	local var2 = var1 * 0.95
	local bool3 = false
	local var3 = var1 * 1.05
	local var4 = nil
	local function tweenScale(arg1)
		if var4 then
			var4:Cancel()
		end

		local var5 = bool1
		local var6 = var12
		local var7 = arg2
		local var8 = arg1
		local tbl1 = {}
		local var9
		if var5 or bool2 then
			var9 = var2
		else
			if not arg1.Active then
				var9 = var1
			elseif bool3 then
				var9 = var3
			else
				var9 = var1
			end
		end

		tbl1.Scale = var9
		var6 = var6:Create(var7, var8, tbl1)
		var4 = var6
		var6.Completed:Connect(function()
			if var4 == var6 then
				var4 = nil
			end
		end)

		var6:Play()
	end

	arg1.MouseEnter:Connect(function()
		bool3 = true
		local var1 = bool1
		if not (var1 or bool2) then
			tweenScale(var40)
		end
	end)

	arg1.MouseLeave:Connect(function()
		bool3 = false
		local var1 = bool1
		if not (var1 or bool2) then
			tweenScale(var40)
		end
	end)

	arg1.InputBegan:Connect(function(arg1)
		if arg1.Active then
			local bool2 = true
			if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
				bool2 = arg1.UserInputType == Enum.UserInputType.Touch
			end

			if not bool2 then
				return
			end
		end

		bool1 = true
		tweenScale(var41)
	end)

	arg1.InputEnded:Connect(function(arg1)
		local bool2 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool2 = arg1.UserInputType == Enum.UserInputType.Touch
		end

		if not bool2 then
			return
		end

		bool1 = false
		tweenScale(var41)
	end)

	arg1:GetPropertyChangedSignal("Active"):Connect(function()
		if not arg1.Active then
			bool1 = false
		end

		tweenScale(var40)
	end)

	if arg3 then
		var39.visuals[arg3] = function(arg1)
			if arg1 then
				if bool2 or (not arg1.Active or (not showSupportPopup.Visible or (not watchSupportTower.Visible or arg4 and (not arg4.Visible)))) then
					return false
				end

				bool2 = true
				tweenScale(var41)
				return true
			end

			if not bool2 then
				return false
			end

			bool2 = false
			tweenScale(var41)
			return true
		end

	end
end

bindScaleTween(var47, var48, Enum.KeyCode.E, var36)
bindScaleTween(var50, var51)
bindScaleTween(var38, var52, Enum.KeyCode.X, var34)
bindScaleTween(var53, var54, Enum.KeyCode.T, var45)
var40 = watchSupportTower:WaitForChild("UpgradesAmounts")
var41 = var40:WaitForChild("LINES"):WaitForChild("Frame")
str5 = var41:WaitForChild("Template")
var47 = var40:WaitForChild("Progress")
var47.Size = UDim2.new(0, 0, 1, 0)
var47.Visible = false
local function isPressInput(arg1)
	local bool1 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool1 = arg1.UserInputType == Enum.UserInputType.Touch
	end

	return bool1
end

var55 = setmetatable({}, { __mode = "k" })
isPressInput = setmetatable({}, { __mode = "kv" })
local var56 = game:GetService("GamepadService")
local var57 = Instance.new("Frame")
var57.Name = "GamepadPlacementCursorAnchor"
var57.AnchorPoint = Vector2.new(0.5, 0.5)
var57.Position = UDim2.fromScale(0.5, 0.5)
var57.Size = UDim2.fromOffset(2, 2)
var57.BackgroundTransparency = 1
var57.BorderSizePixel = 0
var57.Active = false
var57.Visible = true
var57.Parent = var23
var39.gamepadIsPreferred = function()
	return var16.PreferredInput == Enum.PreferredInput.Gamepad
end

local var58 = nil
var39.enableGamepadCursorAtCenter = function()
	if not var39.gamepadIsPreferred() then
		return
	end

	pcall(function()
		var56:EnableGamepadCursor(var57)
	end)

	var58 = (var22 and var22.ViewportSize or Vector2.new(1920, 1080)) * 0.5
end

var39.gamepadCursorEnabled = function()
	return var56.GamepadCursorEnabled
end

local var59 = var21:WaitForChild("PlayerGui")
local var60 = var59:FindFirstChild("ForNotify")
local var61 = var60 or var59:WaitForChild("ForNotify", 3)
var60 = var61 or var59:FindFirstChild("ForNotify")
var48 = nil
var49 = false
var42 = nil
var50 = nil
var51 = function(arg1)
	if not arg1 or (not arg1:IsA("Model")) then
		return nil
	end

	local success, result, var1 = pcall(function()
		return arg1:GetBoundingBox()
	end)

	if not success or (typeof(result) ~= "CFrame" or typeof(var1) ~= "Vector3") then
		return nil
	end

	local success, result = pcall(function()
		return arg1:GetPivot()
	end)

	if not success or typeof(result) ~= "CFrame" then
		return nil
	end

	local var3 = result.Position.Y - (result.Position.Y - var1.Y / 2)
	if var3 ~= var3 or (var3 == math.huge or var3 <= 0) then
		return nil
	end

	return var3
end

var52 = nil
var43 = nil
var44 = nil
var45 = nil
var46 = nil
var53 = nil
var54 = nil
bindScaleTween = nil
local bool1 = false
local num1 = 0
local num2 = 0
local var62 = nil
local var63 = nil
local var64 = nil
local bool2 = false
local bool3 = false
local var65 = nil
local var66 = nil
local bool4 = false
local bool5 = false
local bool6 = false
local tbl3 = {}
local var67 = nil
var56 = true
var57 = false
local bool7 = false
local num3 = 0
local tbl4 = {}
local tbl5 = {}
if var60 and (not var60:IsA("ScreenGui")) then
	var60:Destroy()
	var60 = nil
end

if not var60 then
	var60 = Instance.new("ScreenGui")
	var60.Name = "ForNotify"
	var60.DisplayOrder = 100
	var60.IgnoreGuiInset = true
	var60.ResetOnSpawn = false
	var60.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	var60.Parent = var59
end

var61 = var60:FindFirstChild("Frame")
if var61 and (not var61:IsA("Frame")) then
	var61:Destroy()
	var61 = nil
end

if not var61 then
	var61 = Instance.new("Frame")
	var61.Name = "Frame"
	var61.AnchorPoint = Vector2.new(0.5, 0)
	var61.Position = UDim2.fromScale(0.5, 0.055)
	var61.Size = UDim2.new(1, 0, 0, 300)
	var61.BackgroundTransparency = 1
	var61.BorderSizePixel = 0
	var61.ClipsDescendants = false
	var61.Parent = var60
end

if not var61:FindFirstChildOfClass("UIListLayout") then
	local var68 = Instance.new("UIListLayout")
	var68.HorizontalAlignment = Enum.HorizontalAlignment.Center
	var68.VerticalAlignment = Enum.VerticalAlignment.Top
	var68.SortOrder = Enum.SortOrder.LayoutOrder
	var68.Padding = UDim.new(0, 4)
	var68.Parent = var61
end

local var70 = script:FindFirstChild("Template")
if var70 and (not var70:IsA("TextLabel")) then
	var70:Destroy()
	var70 = nil
end

if not var70 then
	var70 = Instance.new("TextLabel")
	var70.Name = "Template"
	var70.Size = UDim2.new(0.94, 0, 0, 54)
	var70.BackgroundTransparency = 1
	var70.BorderSizePixel = 0
	var70.Font = Enum.Font.FredokaOne
	var70.Text = "Notification"
	var70.TextColor3 = Color3.new(1, 1, 1)
	var70.TextTransparency = 0
	var70.TextStrokeColor3 = Color3.new(0, 0, 0)
	var70.TextStrokeTransparency = 0
	var70.TextScaled = true
	var70.TextWrapped = false
	var70.TextXAlignment = Enum.TextXAlignment.Center
	var70.TextYAlignment = Enum.TextYAlignment.Center
	var70.Visible = false
	var70.ZIndex = 101
	var70.RichText = false
	var70.Parent = script
end

local var72 = var70:FindFirstChild("UIShadow")
if var72 and (not var72:IsA("UIShadow") and (not var72:IsA("UIStroke"))) then
	var72:Destroy()
	var72 = nil
end

if not var72 then
	var72 = Instance.new("UIShadow")
	var72.Name = "UIShadow"
	var72.BlurRadius = UDim.new(0, 18)
	var72.Color = Color3.new(1, 1, 1)
	var72.Offset = UDim2.fromOffset(0, 0)
	var72.Spread = UDim2.new(0.12, 0, 0.12, 0)
	var72.Transparency = 0.35
	var72.ZIndex = -1
	var72.Parent = var70
end

local var74 = var70:FindFirstChild("UIScale")
if var74 and (not var74:IsA("UIScale")) then
	var74:Destroy()
	var74 = nil
end

if not var74 then
	var74 = Instance.new("UIScale")
	var74.Name = "UIScale"
	var74.Scale = 1
	var74.Parent = var70
end

local var76 = var70:FindFirstChild("UITextSizeConstraint")
if var76 and (not var76:IsA("UITextSizeConstraint")) then
	var76:Destroy()
	var76 = nil
end

if not var76 then
	var76 = Instance.new("UITextSizeConstraint")
	var76.Name = "UITextSizeConstraint"
	var76.MinTextSize = 20
	var76.MaxTextSize = 42
	var76.Parent = var70
end

local var77 = script:FindFirstChild("CashTemp")
local tbl6 = { "Amount", "amount", "Value", "value", "Price", "price" }
local function removeActiveNotification(arg1)
	for k1, v1 in ipairs(tbl4) do
		if v1 ~= arg1 then
			continue
		end

		table.remove(tbl4, k1)
		return
	end
end

local function closeNotification(arg1, arg2)
	if arg1.closing then
		return
	end

	arg1.closing = true
	removeActiveNotification(arg1)
	local var2 = arg1.label
	if not var2 or (not var2.Parent) then
		return
	end

	if arg2 then
		var2:Destroy()
		return
	end

	if arg1.kind ~= "WaveReward" then
		if arg1.kind == "TowerIncome" then
			local var6 = var2:FindFirstChildOfClass("UIScale")
			if var6 then
				local var7 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				var12:Create(var6, var7, { Scale = (arg1.targetScale or 1) * 0.84 }):Play()
			end

			task.delay(0.22, function()
				if var2 then
					var2:Destroy()
				end
			end)

			return
		end
	end

	local var9 = var2:FindFirstChildOfClass("UIScale")
	local var10 = var2:FindFirstChild("UIShadow")
	if var9 then
		var12:Create(var9, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Scale = 0.88 }):Play()
	end

	if var10 and (var10:IsA("UIShadow") or var10:IsA("UIStroke")) then
		var12:Create(var10, TweenInfo.new(0.18), { Transparency = 1 }):Play()
	end

	local var11 = var2.Size
	local var13 = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	local var14 = var12:Create(var2, var13, {
		Size = UDim2.new(var11.X.Scale, var11.X.Offset, 0, 0),
		TextTransparency = 1,
		TextStrokeTransparency = 1,
	})

	var14:Play()
	var14.Completed:Once(function()
		if var2 then
			var2:Destroy()
		end
	end)
end

var77 = var77 and (var77:IsA("GuiObject") or nil)
local function showNotification(arg1, arg2, arg3)
	if typeof(arg1) ~= "string" or arg1 == "" then
		return
	end

	if typeof(arg2) == "number" then
		local var1 = math.clamp(arg2, 0.5, 15)
		var1 = var1 or 2.5
	end

	arg2 = 2.5
	arg3 = typeof(arg3) == "Color3" and arg3 or Color3.new(1, 1, 1)
	while true do
		if 4 > (#tbl4) then
			break
		end

		local var2 = tbl4[1]
	if not var2.closing then
			var2.closing = true
			removeActiveNotification(var2)
			local var3 = var2.label
			if not var3 then
				continue
			end

	if not not var3.Parent then
				var3:Destroy()
			end
		end
	end

	local var4 = num3 + 1
	num3 = var4
	var4 = var70:Clone()
	var4.Name = "Notification"
	var4.LayoutOrder = num3
	var4.Text = arg1
	var4.Visible = false
	var4.Parent = var61
	local var5 = var4.Size
	if var5.Y.Scale == 0 and var5.Y.Offset <= 0 then
		var5 = UDim2.new(0.94, 0, 0, 54)
	end

	local var6 = var4:WaitForChild("UIShadow")
	var6.Color = arg3
	local var7 = var6.Transparency
	var6.Transparency = 1
	local var8 = var4:WaitForChild("UIScale")
	var8.Scale = 0.84
	var4.Size = UDim2.new(var5.X.Scale, var5.X.Offset, 0, 0)
	local var9 = var4.TextTransparency
	var4.TextTransparency = 1
	local var10 = var4.TextStrokeTransparency
	var4.TextStrokeTransparency = 1
	var4.Visible = true
	local tbl1 = { label = var4, closing = false }
	table.insert(tbl4, tbl1)
	var12:Create(var8, TweenInfo.new(0.24, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	local var11 = TweenInfo.new(0.16)
	var12:Create(var6, var11, { Transparency = var7 }):Play()
	var11 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	var12:Create(var4, var11, { Size = var5, TextTransparency = var9, TextStrokeTransparency = var10 }):Play()
	task.delay(arg2, function()
		closeNotification(tbl1, false)
	end)
end

local function findWaveRewardAmountLabel(arg1)
	for k1, v1 in ipairs(tbl6) do
		local var1 = arg1:FindFirstChild(v1, true)
		if not var1 then
			continue
		end

		local var2 = var1:IsA("TextLabel")
		if not (var2 or (var1:IsA("TextButton") or var1:IsA("TextBox"))) then
			continue
		end

		return var1
	end

	for k2, v2 in ipairs(arg1:GetDescendants()) do
		local var3 = v2:IsA("TextLabel")
		if not (var3 or (v2:IsA("TextButton") or v2:IsA("TextBox"))) then
			continue
		end

		var3 = v2.Text:gsub("[^%d%.%-]", "")
		if v2.Text == "??" or var3 ~= "" and tonumber(var3) ~= nil then
			return v2
		end
	end

	return nil
end

local function showWaveRewardNotification(arg1, arg2)
	local var2 = tonumber(arg1)
	if not var2 or var2 < 0 then
		return
	end

	local var3 = tostring((math.floor(var2)))
	if typeof(arg2) == "number" then
		local var4 = math.clamp(arg2, 0.5, 15)
		var4 = var4 or 2.5
	end

	arg2 = 2.5
	if not var77 then
		showNotification("Wave Reward: +" .. var3, arg2)
		return
	end

	local var5 = var77:Clone()
	local var7 = findWaveRewardAmountLabel(var5)
	if not var7 then
		var5:Destroy()
		showNotification("Wave Reward: +" .. var3, arg2)
		return
	end

	while true do
		if 4 > (#tbl4) then
			break
		end

		local var8 = tbl4[1]
	if not var8.closing then
			var8.closing = true
			removeActiveNotification(var8)
			local var9 = var8.label
			if not var9 then
				continue
			end

	if not not var9.Parent then
				var9:Destroy()
			end
		end
	end

	local var10 = num3 + 1
	num3 = var10
	var5.Name = "WaveRewardNotification"
	var5.LayoutOrder = num3
	var7.Text = var3
	var10 = var5:FindFirstChildOfClass("UIScale")
	if not var10 then
		var10 = Instance.new("UIScale")
		var10.Parent = var5
	end

	local var11 = var10.Scale
	var10.Scale = var11 * 0.84
	var5.Visible = true
	var5.Parent = var61
	local tbl1 = { label = var5, closing = false, kind = "WaveReward", targetScale = var11 }
	table.insert(tbl4, tbl1)
	local var13 = TweenInfo.new(0.24, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	var12:Create(var10, var13, { Scale = var11 }):Play()
	task.delay(arg2, function()
		closeNotification(tbl1, false)
	end)
end

local function createNotification(arg1, arg2, arg3, arg4)
	local var2 = arg4 == "WaveReward"
	local var3 = arg4 == "TowerIncome"
	local var4 = arg4 == "WaitingForPlayers"
	if var2 then
		if (typeof(arg1) == "string" or typeof(arg1) ~= "number") and tonumber(arg1) == nil then
			return
		end
	elseif var3 then
		if typeof(arg1) ~= "table" or (typeof(arg1.TowerName) ~= "string" or (arg1.TowerName == "" or (tonumber(arg1.Amount) == nil or tonumber(arg1.Amount) <= 0))) then
			return
		end
	else
		if typeof(arg1) ~= "string" or arg1 == "" then
			return
		end
	end

	if not var57 then
		if 10 <= (#tbl5) then
			table.remove(tbl5, 1)
		end

		table.insert(tbl5, { text = arg1, duration = arg2, color = arg3, kind = arg4 })
		return
	end

	if not var56 then
		if not var4 then
			return
		end
	end

	if var2 then
		showWaveRewardNotification(arg1, arg2)
		return
	end

	if var3 then
		local var5 = arg1.TowerName
		local var6 = tostring((math.floor((tonumber(arg1.Amount)))))
		if typeof(arg2) == "number" then
			local var7 = math.clamp(arg2, 0.5, 15)
			var7 = var7 or 2.5
		end

		local num2 = 2.5
		if not var77 then
			showNotification(var5 .. " give you +" .. var6, num2)
			return
		end

		local var8 = var77:Clone()
		local var11 = var8:FindFirstChild("Template", true)
		local var13 = findWaveRewardAmountLabel(var8)
		if var11 then
			local var14 = var11:IsA("TextLabel")
			if not (var14 or (var11:IsA("TextButton") or var11:IsA("TextBox"))) then
				var11 = nil
				for k1, v1 in ipairs(var8:GetDescendants()) do
					local var15 = v1:IsA("TextLabel")
					if not (var15 or (v1:IsA("TextButton") or v1:IsA("TextBox"))) then
						continue
					end

					if v1.Text == "??" then
						continue
					end

					var11 = v1
					break
				end
			end
		end

		if not var13 or (not var11) then
			var8:Destroy()
			showNotification(var5 .. " give you +" .. var6, num2)
			return
		end

		while true do
			if 4 > (#tbl4) then
				break
			end

			local var16 = tbl4[1]
	if not var16.closing then
				var16.closing = true
				removeActiveNotification(var16)
				local var17 = var16.label
				if not var17 then
					continue
				end

	if not not var17.Parent then
					var17:Destroy()
				end
			end
		end

		local var18 = num3 + 1
		num3 = var18
		var8.Name = "TowerIncomeNotification"
		var8.LayoutOrder = num3
		var11.Text = var5 .. " give you:"
		var13.Text = var6
		var18 = var8:FindFirstChildOfClass("UIScale")
		if not var18 then
			var18 = Instance.new("UIScale")
			var18.Parent = var8
		end

		local var19 = var18.Scale
		var18.Scale = var19 * 0.84
		var8.Visible = true
		var8.Parent = var61
		local tbl1 = { label = var8, closing = false, kind = "TowerIncome", targetScale = var19 }
		table.insert(tbl4, tbl1)
		local var20 = TweenInfo.new(0.24, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		var12:Create(var18, var20, { Scale = var19 }):Play()
		task.delay(num2, function()
			closeNotification(tbl1, false)
		end)

		return
	end

	showNotification(arg1, arg2, arg3)
end

var28.OnClientEvent:Connect(createNotification)
local function findPlayerValue(arg1)
	local var2 = var21:FindFirstChild(arg1)
	if var2 and var2:IsA("ValueBase") then
		return var2
	end

	local str1 = "Stats"
	for k1, v1 in ipairs({ "leaderstats", str1 }) do
		local var3 = var21:FindFirstChild(v1)
		local var4 = var3
		var4 = var4 and var3:FindFirstChild(arg1)
		if not var4 then
			continue
		end

		if not var4:IsA("ValueBase") then
			continue
		end

		return var4
	end

	return nil
end

local function isPointerOverGui(arg1)
	if not arg1 or (not arg1:IsA("GuiObject") or (not arg1.Visible)) then
		return false
	end

	local var1 = var58
	var1 = var1 or var16:GetMouseLocation() - var17:GetGuiInset()
	local function contains(arg1)
		if not arg1:IsA("GuiObject") or (not arg1.Visible) then
			return false
		end

		local var2 = arg1.AbsolutePosition
		local var4 = arg1.AbsoluteSize
		local bool2 = false
		if var2.X <= var1.X then
			bool2 = false
			if var1.X <= var2.X + var4.X then
				bool2 = false
				if var2.Y <= var1.Y then
					bool2 = var1.Y <= var2.Y + var4.Y
				end
			end
		end

		return bool2
	end

	if contains(arg1) then
		return true
	end

	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not contains(v1) then
			continue
		end

		return true
	end

	return false
end

local function getScreenPixelsPerStud(arg1, arg2)
	local var2 = workspace.CurrentCamera
	if not var2 or var2.ViewportSize.Y <= 0 then
		return nil
	end

	local var3 = Vector3.new(arg2.X, 0, arg2.Z)
	local var5 = if var3.Magnitude <= 0.0001 then nil else var3.Unit
	if not var5 then
		return nil
	end

	var3 = var5 * 0.5
	local var6 = var2:WorldToViewportPoint(arg1 - var3)
	local var8 = var2:WorldToViewportPoint(arg1 + var3)
	if var6.Z <= 0.05 or var8.Z <= 0.05 then
		return nil
	end

	return (Vector2.new(var8.X, var8.Y) - Vector2.new(var6.X, var6.Y)).Magnitude
end

local function getRequiredGuiThickness(arg1, arg2, arg3, arg4, arg5)
	if not arg4 then
		return nil
	end

	local var1 = Vector3.new(-arg4.Z, 0, arg4.X)
	local var3 = getScreenPixelsPerStud(arg3, var1)
	if not var3 or var3 < 0.001 then
		return nil
	end

	local var4
	local var5
	if arg1.SizingMode == Enum.SurfaceGuiSizingMode.PixelsPerStud then
		local var6 = math.max(arg1.PixelsPerStud, 0.01)
		var4 = var6
		var5 = var6
	else
		local var7 = arg1.CanvasSize
		var4 = math.max(var7.X / math.max(arg2.Size.Z, tbl1.MIN_FACE_SIZE), 0.01)
		var5 = math.max(var7.Y / math.max(arg2.Size.Y, tbl1.MIN_FACE_SIZE), 0.01)
	end

	return arg5 * math.sqrt((var1:Dot(arg2.CFrame.LookVector) * var4) ^ 2 + (var1:Dot(arg2.CFrame.UpVector) * var5) ^ 2) / var3
end

local function updateConeScreenThickness(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return
	end

	local var3 = Vector3.new(arg7.X, 0, arg7.Z)
	local var5 = if var3.Magnitude <= 0.0001 then nil else var3.Unit
	if not var5 then
		return
	end

	local var6 = CFrame.Angles(0, math.rad(-arg6), 0):VectorToWorldSpace(var5)
	local var7 = Vector3.new(var6.X, 0, var6.Z)
	var6 = CFrame.Angles(0, math.rad(arg6), 0):VectorToWorldSpace(var5)
	var7 = Vector3.new(var6.X, 0, var6.Z)
	var3 = if var7.Magnitude <= 0.0001 then nil else var7.Unit
	var6 = math.clamp(var2.ViewportSize.Y * 0.0045, 4, 9)
	local var8 = if var7.Magnitude <= 0.0001 then nil else var7.Unit
	local var9 = var8 or var5
	local var11 = math.max(getRequiredGuiThickness(arg2, arg3, arg4 + (var3 or var5) * arg5 * 0.5, var3, var6) or 0, getRequiredGuiThickness(arg2, arg3, arg4 + var9 * arg5 * 0.5, var8, var6) or 0)
	if var11 <= 0 then
		return
	end

	var11 = math.floor(math.clamp(var11, 8, 56) / 1 + 0.5) * 1
	for k1, v1 in pairs(arg1) do
		if 0.5 > math.abs(v1.Size.X.Offset - var11) then
			continue
		end

		v1.Size = UDim2.new(0, var11, 1, 0)
	end
end

local function setRangeCircleVisual(arg1, arg2, arg3)
	if not arg1 then
		return
	end

	if type(arg3) == "string" and arg3 ~= "" then
		arg1:SetAttribute("RangeUnitId", arg3)
	end

	arg1:SetAttribute("RangeState", arg2)
	local var1 = arg3
	local var2 = var9.Get(var1 or arg1:GetAttribute("RangeUnitId"), arg2)
	arg1.Color = var2.Circle
	arg1.Transparency = var2.Transparency
	local var3 = arg1
	var3 = var3 and arg1:FindFirstChild("Range", true)
	var1 = if var3 and (var3:IsA("ImageLabel") or var3:IsA("ImageButton")) then var3 else nil
	if var1 then
		var1.ImageColor3 = var2.Image
	end
end

local tbl7 = { Offsets = setmetatable({}, { __mode = "k" }) }
tbl7.GetOffset = function(arg1)
	if not arg1 or (not arg1:IsA("Model")) then
		return nil
	end

	local var2 = tbl7.Offsets[arg1]
	if var2 then
		return var2
	end

	local var4 = var51(arg1)
	if not var4 then
		local var5 = arg1.PrimaryPart
		var5 = var5 or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart"))
		if not var5 then
			return nil
		end

		local var7 = arg1:FindFirstChildOfClass("Humanoid")
		if var7 then
			var4 = var5.Size.Y / 2 + var7.HipHeight
		else
			local var8, var9 = arg1:GetBoundingBox()
			var4 = var9.Y / 2
		end
	end

	if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 < 0 or var4 == math.huge)) then
		return nil
	end

	tbl7.Offsets[arg1] = var4
	return var4
end

tbl7.GetGround = function(arg1)
	if arg1 == var44 then
		return var62
	end

	local var1 = arg1:GetAttribute("PlacementGroundPosition")
	if typeof(var1) == "Vector3" then
		return var1
	end

	local var2 = arg1:GetAttribute("ModelName")
	local var4 = tbl7.GetOffset((var30:FindFirstChild(var2 or arg1.Name)))
	if var4 == nil then
		return nil
	end

	return arg1:GetPivot().Position - Vector3.new(0, var4, 0)
end

tbl7.SetCircleVisible = function(arg1, arg2)
	if not arg1 then
		return
	end

	arg1.LocalTransparencyModifier = if arg2 then 0 else 1
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if v1:IsA("BasePart") then
			v1.LocalTransparencyModifier = if arg2 then 0 else 1
		elseif v1:IsA("SurfaceGui") then
			v1.Enabled = arg2
		end
	end
end

local function getTowerAimDirection(arg1)
	local var1
	if typeof(arg1) ~= "Instance" then
		var1 = nil
	else
		if arg1:IsA("BasePart") then
			var1 = arg1
		else
			if arg1:IsA("Model") then
				var1 = arg1.PrimaryPart
				var1 = var1 or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart"))
				if not var1 then
					var1 = arg1:FindFirstChildWhichIsA("BasePart", true)
				end
			else
				var1 = nil
			end
		end
	end

	local var2 = isPressInput[arg1]
	local var3
	if typeof(var2) ~= "Instance" then
		var3 = nil
	else
		if var2:IsA("BasePart") then
			var3 = var2
		else
			if var2:IsA("Model") then
				var3 = var2.PrimaryPart
				var3 = var3 or (var2:FindFirstChild("HumanoidRootPart") or var2:FindFirstChild("HumanoidPart"))
				if not var3 then
					var3 = var2:FindFirstChildWhichIsA("BasePart", true)
				end
			else
				var3 = nil
			end
		end
	end

	if var1 then
		if var3 then
			if var3:IsDescendantOf(workspace) then
				local var7 = var3.Position - var1.Position
				local var8 = Vector3.new(var7.X, 0, var7.Z)
				var2 = if var8.Magnitude <= 0.0001 then nil else var8.Unit
				if var2 then
					var55[arg1] = var2
					return var2
				end
			end
		end
	end

	var2 = var1
	if var2 then
		local var10 = var1.CFrame.LookVector
		local var11 = Vector3.new(var10.X, 0, var10.Z)
		var2 = if var11.Magnitude <= 0.0001 then nil else var11.Unit
	end

	local var12 = var2
	return var12 or (var55[arg1] or Vector3.new(0, 0, -1))
end

local function getConeLines(arg1)
	local var1 = arg1
	var1 = var1 and arg1:FindFirstChildWhichIsA("SurfaceGui", true)
	if not var1 then
		return nil
	end

	local var4 = var1:FindFirstChild("ConeLeft")
	local var5 = var1:FindFirstChild("ConeRight")
	if var4 and (var4:IsA("Frame") and (var5 and var5:IsA("Frame"))) then
		return { Left = var4, Right = var5 }
	end

	return nil
end

local function makeConeLines(arg1)
	local var2 = arg1:FindFirstChildWhichIsA("SurfaceGui", true)
	if not var2 then
		return nil
	end

	var2.Face = Enum.NormalId.Right
	if var2.SizingMode == Enum.SurfaceGuiSizingMode.FixedSize then
		local var4 = var2.CanvasSize
		local var5 = math.max(var4.X, var4.Y, 1)
		var2.CanvasSize = Vector2.new(var5, var5)
	end

	local function makeLine(arg1)
		local var1 = Instance.new("Frame")
		var1.Name = arg1
		var1.AnchorPoint = Vector2.new(0.5, 0.5)
		var1.Position = UDim2.fromScale(0.5, 0.5)
		var1.Size = UDim2.new(0, 8, 1, 0)
		var1.BackgroundColor3 = var9.Get(nil, "Selected").Cone
		var1.BackgroundTransparency = 0.15
		var1.BorderSizePixel = 0
		var1.Rotation = 90
		var1.Visible = false
		var1.ZIndex = 10
		var1.Parent = var2
		local var3 = Instance.new("UIGradient")
		var3.Rotation = 90
		local num1 = 1
		local num2 = 1
		var3.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0),
			NumberSequenceKeypoint.new(0.499, 0),
			NumberSequenceKeypoint.new(0.501, 1),
			NumberSequenceKeypoint.new(num1, num2),
		})

		var3.Parent = var1
		return var1
	end

	local tbl1 = { Left = makeLine("ConeLeft") }
	tbl1.Right = makeLine("ConeRight")
	return tbl1
end

local function updateConeLines(arg1, arg2, arg3, arg4, arg5, arg6)
	if not arg1 then
		return
	end

	local var1 = arg2.AttackAngle
	if typeof(var1) == "number" then
		if var1 ~= var1 or (var1 == math.huge or var1 == -math.huge) then
			var1 = 0
		end
	end

	var1 = math.clamp(var1, 0, 360)
	local bool2 = false
	if arg2.AttackType == "Cone" then
		bool2 = false
		if 0 < var1 then
			bool2 = var1 < 360
		end
	end

	arg1.Left.Visible = bool2
	arg1.Right.Visible = bool2
	if not bool2 then
		return
	end

	local var2 = Vector3.new(arg6.X, 0, arg6.Z)
	local var3 = var1 / 2
	local var4 = arg3.CFrame.UpVector
	local var5 = Vector3.new(var4.X, 0, var4.Z)
	local var6 = if var2.Magnitude <= 0.0001 then nil else var2.Unit
	var5 = arg3.CFrame.LookVector
	local var7 = Vector3.new(var5.X, 0, var5.Z)
	var2 = if var5.Magnitude <= 0.0001 then nil else var5.Unit
	var4 = if var7.Magnitude <= 0.0001 then nil else var7.Unit
	if not var6 or (not var2 or (not var4)) then
		return
	end

	var5 = math.deg((math.atan2(var6:Dot(var4), (var6:Dot(var2)))))
	var7 = var5 + var3
	local var8 = var5 - var3
	if 0.001 < math.abs(arg1.Left.Rotation - var7) then
		arg1.Left.Rotation = var7
	end

	if 0.001 < math.abs(arg1.Right.Rotation - var8) then
		arg1.Right.Rotation = var8
	end

	local var10 = arg3:FindFirstChildWhichIsA("SurfaceGui", true)
	if var10 then
		updateConeScreenThickness(arg1, var10, arg3, arg4, arg5, var3, var6)
	end
end

local function applyPreviewPhysics(arg1)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		v1.CanCollide = false
		v1.CanTouch = false
		v1.CanQuery = false
		v1.Massless = true
		pcall(function()
			v1.CollisionGroup = "TowerPreview"
		end)

	end
end

local function stopPlacement()
	if var44 then
		var44:Destroy()
	end

	var46 = nil
	local var2 = var45
	if var2 then
		var2:Destroy()
	end

	var44 = nil
	var45 = nil
	var54 = nil
	bindScaleTween = nil
	bool1 = false
	num1 = 0
	num2 = 0
	var62 = nil
	var63 = nil
	var64 = nil
	var2 = var23:FindFirstChild("PlaceInfo")
	if var2 and var2:IsA("GuiObject") then
		var2.Visible = false
	end
end

local function preparePreviewTower(arg1)
	local var1 = arg1.PrimaryPart
	applyPreviewPhysics(arg1)
	local function disablePreviewEffect(arg1)
		if arg1:IsA("ParticleEmitter") then
			arg1.Enabled = false
			arg1:Clear()
			return
		end

		if arg1:IsA("Beam") or (arg1:IsA("Trail") or (arg1:IsA("Fire") or (arg1:IsA("Smoke") or arg1:IsA("Sparkles")))) then
			arg1.Enabled = false
			return
		end

		if arg1:IsA("Light") then
			arg1.Enabled = false
			return
		end

		if arg1:IsA("Sound") then
			arg1:Stop()
		end
	end

	var1 = var1 or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart"))
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		disablePreviewEffect(v1)
		if not v1:IsA("BasePart") then
			continue
		end

		v1.LocalTransparencyModifier = 0
	end

	if var1 then
		var1.Anchored = true
	end

	arg1.DescendantAdded:Connect(function(arg1)
		disablePreviewEffect(arg1)
		if arg1:IsA("BasePart") then
			arg1.CanCollide = false
			arg1.CanTouch = false
			arg1.CanQuery = false
			arg1.Massless = true
			arg1.LocalTransparencyModifier = 0
			pcall(function()
				arg1.CollisionGroup = "TowerPreview"
			end)

		end
	end)

	local var3 = arg1:FindFirstChild("PlacementHighlight")
	if var3 and (not var3:IsA("Highlight")) then
		var3:Destroy()
		var3 = nil
	end

	if not var3 then
		var3 = Instance.new("Highlight")
		var3.Name = "PlacementHighlight"
		var3.Parent = arg1
	end

	var3.Adornee = arg1
	var3.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	var3.FillTransparency = 0.875
	var3.OutlineTransparency = 1
	var46 = var3
end

local function makeRangeCircle()
	local var1 = var31:Clone()
	var1.Anchored = true
	var1.CastShadow = false
	var1.CanCollide = false
	var1.CanTouch = false
	var1.CanQuery = false
	var1.Transparency = var9.Get(nil, "Selected").Transparency
	var1.Parent = var22
	local num1 = 0
	local bool1 = true
	while bool1 do
		for k1, v1 in ipairs(var22:GetChildren()) do
			if v1 == var1 then
				continue
			end

			if v1:GetAttribute("RangeStackSlot") ~= num1 then
				continue
			end

			local bool2 = false
			num1 = num1 + 1
			bool2 = true
			break
		end
	end

	var1:SetAttribute("RangeStackSlot", num1)
	tbl7.SetCircleVisible(var1, false)
	return var1, (makeConeLines(var1))
end

local function setUpgradeAffordable(arg1)
	for k1, v1 in ipairs(var36:GetDescendants()) do
		if not v1:IsA("UIGradient") then
			continue
		end

		if v1.Name == "Buy" then
			v1.Enabled = arg1
		else
			if v1.Name ~= "NoBuy" then
				continue
			end

			v1.Enabled = not arg1
		end
	end
end

local function getAbilityCooldownRemaining(arg1)
	local var1 = arg1:GetAttribute("AbilityCooldownRemaining")
	local var2 = arg1:GetAttribute("AbilityCooldownUpdatedAt")
	local var4 = arg1:GetAttribute("AbilityCooldownSpeed")
	local var5 = workspace:GetServerTimeNow()
	if typeof(var1) == "number" and (typeof(var2) == "number" and typeof(var4) == "number") then
		return (math.max(0, var1 - math.max(0, var5 - var2) * var4))
	end

	local var6 = var3:FindFirstChild("WaveState")
	local var7 = var6
	local str1 = "AbilityCooldownEndsAt"
	local var8 = tonumber(var7 and var6:GetAttribute("GameSpeed")) or 1
	local var9 = math.max(0, (tonumber(arg1:GetAttribute(str1)) or 0) - var5)
	return var9 * math.max(var8, 0.01)
end

local var78 = (function()
	local str1 = "PlacementConfig"
	local var1 = require(var3:WaitForChild("Shared"):WaitForChild(str1))
	local tbl1 = {}
	local var2 = var11:WaitForChild("CantPlacePart")
	local function updateZonePart(arg1, arg2)
		local var2 = arg2.PrimaryPart
		if not (var2 or (arg2:FindFirstChild("HumanoidRootPart") or arg2:FindFirstChild("HumanoidPart"))) then
			return false
		end

		local var3 = arg2
		local var5 = var1.GetRadius(var24.getUnitId(var3))
		if var5 <= 0 then
			return false
		end

		local var7 = tbl7.GetGround(arg2)
		if not var7 then
			return false
		end

		arg1.Size = Vector3.new(0.01, var5 * 2, var5 * 2)
		arg1.CFrame = CFrame.new(var7.X, var7.Y + var1.SurfaceOffset, var7.Z) * CFrame.Angles(0, 0, 1.5707963267948966)
		return true
	end

	str1 = false
	local var4 = nil
	local function createZone(arg1)
		if not var1.Enabled or (not arg1:IsA("Model") or tbl1[arg1]) then
			return
		end

		local var3 = var2:Clone()
		var3.Name = "CantPlacePart"
		var3.CastShadow = false
		var3.Anchored = true
		var3.CanCollide = false
		var3.CanTouch = false
		var3.CanQuery = false
		var3.Color = var1.Color
		local var4 = var3:FindFirstChildWhichIsA("SurfaceGui")
		local var5 = var4
		var5 = var5 and var4:FindFirstChild("Frame")
		local var6 = var5
		var6 = var6 and var5:FindFirstChild("Range")
		if var6 and (var6:IsA("ImageLabel") or var6:IsA("ImageButton")) then
			var6.ImageColor3 = var1.ImageColor
		end

		var3.Parent = var22
		tbl1[arg1] = var3
		var3.Transparency = 1
		local var8 = var3:FindFirstChildWhichIsA("SurfaceGui")
		if var8 then
			var8.Enabled = false
		end

		if updateZonePart(var3, arg1) then
			var8 = str1
			var3.Transparency = if var8 then var1.Transparency else 1
			local var10 = var3:FindFirstChildWhichIsA("SurfaceGui")
			if var10 then
				var10.Enabled = var8 == true
			end
		end
	end

	var14.ChildAdded:Connect(createZone)
	var14.ChildRemoved:Connect(function(arg1)
		local var2 = tbl1[arg1]
		if var2 then
			tbl1[arg1] = nil
			var2:Destroy()
		end
	end)

	local function hidePreview()
		if var4 then
			var4:Destroy()
			var4 = nil
		end
	end

	local function updatePreview(arg1, arg2, arg3)
		if var1.Enabled then
			if typeof(arg1) ~= "Vector3" then
				if var4 then
					var4:Destroy()
					var4 = nil
				end

				return
			end
		end

		local var5 = var1.GetRadius(arg2)
		if var5 <= 0 then
			if var4 then
				var4:Destroy()
				var4 = nil
			end

			return
		end

		if not var4 or (not var4.Parent) then
			local var6 = var2:Clone()
			var6.Name = "CantPlacePreview"
			var6.CastShadow = false
			var6.Anchored = true
			var6.CanCollide = false
			var6.CanTouch = false
			var6.CanQuery = false
			var6.Parent = var22
			var4 = var6
		end

		local var7 = var4
		local var8 = if arg3 then var1.PreviewBlockedColor else var1.PreviewAllowedColor
		var7.Color = var8
		var7.Transparency = var1.PreviewTransparency
		var7.Size = Vector3.new(0.01, var5 * 2, var5 * 2)
		var7.CFrame = CFrame.new(arg1.X, arg1.Y + var1.SurfaceOffset, arg1.Z) * CFrame.Angles(0, 0, 1.5707963267948966)
		local var10 = var7:FindFirstChildWhichIsA("SurfaceGui")
		local var11 = if arg3 then var1.PreviewBlockedImageColor else var1.PreviewAllowedImageColor
		if var10 then
			var10.Enabled = true
			local var12 = var10:FindFirstChild("Frame")
			local var13 = var12
			var13 = var13 and var12:FindFirstChild("Range")
			if var13 and (var13:IsA("ImageLabel") or var13:IsA("ImageButton")) then
				var13.ImageColor3 = var11
			end
		end
	end

	local function setVisible(arg1)
		if str1 == arg1 then
			return
		end

		str1 = arg1
		for k1, v1 in pairs(tbl1) do
			if not k1.Parent then
				continue
			end

			if not v1.Parent then
				continue
			end

			local var2 = arg1
			var2 = var2 and updateZonePart(v1, k1)
			v1.Transparency = if var2 then var1.Transparency else 1
			local var3 = v1:FindFirstChildWhichIsA("SurfaceGui")
			if not var3 then
				continue
			end

			var3.Enabled = var2 == true
		end
	end

	local function update()
		if not str1 then
			return
		end

		for k1, v1 in pairs(tbl1) do
			if not k1.Parent then
				continue
			end

			if not v1.Parent then
				continue
			end

			local var3 = updateZonePart(v1, k1)
			v1.Transparency = if var3 then var1.Transparency else 1
			local var4 = v1:FindFirstChildWhichIsA("SurfaceGui")
			if not var4 then
				continue
			end

			var4.Enabled = var3 == true
		end
	end

	local function isBlocked(arg1, arg2)
		if not var1.Enabled then
			return false
		end

		local var2 = arg1
		local var3 = var1.GetRadius(arg2)
		return var1.IsBlocked(var2, var3, var14:GetChildren())
	end

	for k1, v1 in ipairs(var14:GetChildren()) do
		createZone(v1)
	end

	setVisible(var1.ShowAlways == true)
	return {
		SetVisible = setVisible,
		Update = update,
		IsBlocked = isBlocked,
		UpdatePreview = updatePreview,
		HidePreview = hidePreview,
		ShowAlways = var1.ShowAlways == true,
	}
end)()

tbl2.Refresh = function()
	local var2 = var48
	if not var2 or (not var2.Parent or (not showSupportPopup.Visible)) then
		tbl2.Root.Visible = false
		tbl2.Card.Visible = false
		return
	end

	local var4 = tbl2.Config.get(var24.getUnitId(var2), (var24.getLevel(var2)))
	if not var4 then
		tbl2.Root.Visible = false
		tbl2.Card.Visible = false
		return
	end

	tbl2.Root.Visible = true
	tbl2.Card.Visible = true
	tbl2.Icon.Image = var4.Icon
	local var5 = getAbilityCooldownRemaining(var2)
	local var6 = 0 < var5
	tbl2.OnCooldown.Visible = var6
	local var7 = tbl2.Icon
	local var8 = if var6 then Color3.new(0, 0, 0) else Color3.new(1, 1, 1)
	var7.ImageColor3 = var8
	tbl2.Price.Visible = not var6
	tbl2.TimerText.Visible = var6
	tbl2.PriceText.Text = tostring((math.max(0, (math.floor(var4.Price)))))
	var7 = tbl2.TimerText
	if var6 then
		local var10 = math.max(0, (math.ceil(var5)))
		if 60 <= var10 then
			var8 = string.format("%d:%02d", math.floor(var10 / 60), var10 % 60)
		else
			var8 = tostring(var10) .. "s"
		end
	else
		var8 = ""
	end

	var7.Text = var8
	var7 = findPlayerValue("Cash")
	var8 = false
	if var7 ~= nil then
		var8 = var4.Price <= var7.Value
	end

	local var11 = var49
	var11 = var11 and (not var6 and (not tbl2.RequestInFlight and var8))
	tbl2.CanUse = var11
	tbl2.NotEnoughCash = not var8
	tbl2.IsCoolingDown = var6
	tbl2.CooldownRemaining = var5
	local var12 = var49
	var12 = var12 and (not tbl2.RequestInFlight)
	tbl2.Button.Active = var12
	tbl2.Button.Interactable = var12
	local var13 = tbl2.Icon
	var13.ImageTransparency = if var11 then 0 else 0.35
end

task.spawn(function()
	while true do
		task.wait(0.25)
		if tbl2.Root.Visible or var48 ~= nil then
			pcall(tbl2.Refresh)
		end
	end
end)

local function getTowerOwner(arg1)
	local var1 = arg1:GetAttribute("Owner")
	if typeof(var1) == "string" and var1 ~= "" then
		return var1
	end

	local var2 = arg1:FindFirstChild("Config")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Owner")
	return var3 and (var3:IsA("StringValue") and var3.Value) or "Unknown"
end

tbl2.Button.Activated:Connect(function()
	if tbl2.RequestInFlight then
		return
	end

	local var2 = var48
	if not var2 or (not var2.Parent or getTowerOwner(var2) ~= var21.Name) then
		return
	end

	local var3 = var2
	local var5 = tbl2.Config.get(var24.getUnitId(var2), var24.getLevel(var3))
	if not var5 then
		return
	end

	if tbl2.IsCoolingDown then
		local var7 = math.max(0, (math.ceil(tbl2.CooldownRemaining or 0)))
		local var8 = createNotification
		var3 = "Ability on cooldown: "
		local var9 = var3 .. (if 60 <= var7 then string.format("%d:%02d", math.floor(var7 / 60), var7 % 60) else tostring(var7) .. "s")
		local num1 = 255
		var7 = 170
		local num2 = 0
		var8(var9, 2, Color3.fromRGB(num1, var7, num2))
		return
	end

	if tbl2.NotEnoughCash then
		local var10 = findPlayerValue("Cash")
		local num3 = 255
		local num4 = 0
		local num5 = 0
		createNotification(("Not enough cash for %s (need %d more)"):format(var5.DisplayName, (math.max(0, (math.floor(var5.Price - (var10 and var10.Value or 0)))))), 2.5, Color3.fromRGB(num3, num4, num5))
		return
	end

	tbl2.RequestInFlight = true
	tbl2.Refresh()
	local success, result, var11 = pcall(function()
		local var1 = var2
		return tbl2.UseRemote:InvokeServer(var1)
	end)

	tbl2.RequestInFlight = false
	if success and (result and (typeof(var11) == "number" and var2.Parent)) then
		var2:SetAttribute("AbilityCooldownEndsAt", var11)
	end

	tbl2.Refresh()
end)

getAbilityCooldownRemaining = function(arg1)
	var35.Visible = true
	local var1 = var35
	local var3 = var1
	var3 = var3 and var1:FindFirstChild("PlayerName", true)
	if var3 and (var3:IsA("TextLabel") or var3:IsA("TextButton")) then
		var3.Text = tostring(arg1)
	end

	var1 = var35:FindFirstChild("PlayerIcon", true)
	var3 = var2:FindFirstChild(arg1)
	if var1 and ((var1:IsA("ImageLabel") or var1:IsA("ImageButton")) and var3) then
		task.spawn(function()
			local success, result = pcall(function()
				local var1 = var3.UserId
				local var4 = Enum.ThumbnailType.HeadShot
				local var5 = Enum.ThumbnailSize.Size100x100
				return var2:GetUserThumbnailAsync(var1, var4, var5)
			end)

			if success then
				var1.Image = result
			end
		end)

	end
end

local function setUpgradeButtonText(arg1, arg2)
	local var1 = arg1:FindFirstChild("Main", true)
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Cash", true)
	if var1 then
		local var4 = var1
		var4 = var4 and var1:FindFirstChild("Amount", true)
		if var4 and (var4:IsA("TextLabel") or var4:IsA("TextButton")) then
			var4.Text = tostring("Upgrade:")
		end
	end

	if var2 then
		local var6 = var2
		var6 = var6 and var2:FindFirstChild("price", true)
		if var6 and (var6:IsA("TextLabel") or var6:IsA("TextButton")) then
			var6.Text = tostring(arg2)
		end
	elseif var1 then
		local var7 = var1
		var7 = var7 and var1:FindFirstChild("price", true)
		if var7 and (var7:IsA("TextLabel") or var7:IsA("TextButton")) then
			var7.Text = tostring(arg2)
		end
	else
		local var8 = arg1
		var8 = var8 and arg1:FindFirstChild("Title", true)
		local var9 = "Upgrade: " .. arg2
		if var8 and (var8:IsA("TextLabel") or var8:IsA("TextButton")) then
			var8.Text = tostring(var9)
		end
	end

	local var10 = arg1
	var10 = var10 and arg1:FindFirstChild("Use", true)
	if var10 and var10:IsA("TextButton") then
		var10.Text = ""
	end
end

local function updateUpgradeAffordability(arg1)
	local var2 = var48
	if not var2 or (not var2.Parent) then
		setUpgradeAffordable(false)
		return
	end

	local var4 = var24.getStats(var2.Name, var2).UpgradePrice
	if typeof(arg1) ~= "number" then
		local var5 = findPlayerValue("Cash")
		arg1 = var5 and var5.Value or 0
	end

	local var7 = var49
	local var8 = setUpgradeAffordable
	if var7 then
		var7 = false
		if typeof(var4) == "number" then
			var7 = var4 <= arg1
		end
	end

	var8(var7)
end

local function formatTimer(arg1)
	local var2 = math.max(0, (math.ceil(arg1)))
	if 60 <= var2 then
		local str1 = "%d:%02d"
		local var3 = math.floor(var2 / 60)
		local var4 = var2 % 60
		return string.format(str1, var3, var4)
	end

	return tostring(var2) .. "s"
end

local function closeUpgradeFrame()
	var48 = nil
	var49 = false
	if var42 then
		var42:Disconnect()
		var42 = nil
	end

	if var50 then
		var50:Disconnect()
		var50 = nil
	end

	showSupportPopup:SetAttribute("BoostSignature", nil)
	local var2 = var52
	if var2 then
		var2:Destroy()
	end

	var52 = nil
	var53 = nil
	tbl2.Root.Visible = false
	tbl2.Card.Visible = false
	showSupportPopup.Visible = false
end

local function updateRangeCircle(arg1, arg2, arg3, arg4)
	if not arg1 or (not arg3) then
		return nil
	end

	local var1 = arg3.PrimaryPart
	if not (var1 or (arg3:FindFirstChild("HumanoidRootPart") or arg3:FindFirstChild("HumanoidPart"))) then
		return nil
	end

	local var2 = var24.getStats(arg3.Name, arg3)
	local var3, var4 = var7.applyToStats(arg3, 0, var2.Range, 1)
	local var5 = tbl7.GetGround(arg3)
	tbl7.SetCircleVisible(arg1, var5 ~= nil)
	local var6 = var4
	if not var5 then
		return nil
	end

	local var10 = Vector3.new(0.01, var6 * 2, var6 * 2)
	if arg4 ~= false and arg1.Size ~= var10 then
		arg1.Size = var10
	end

	local var11 = arg1:GetAttribute("RangeStackSlot")
	if typeof(var11) ~= "number" or (var11 ~= var11 or var11 < 0) then
		var11 = 0
	end

	local var12 = Vector3.new(var5.X, var5.Y + 0.08 + var11 * 0.02, var5.Z)
	local var13 = getTowerAimDirection(arg3)
	arg1.CFrame = CFrame.new(var12) * CFrame.Angles(0, 0, 1.5707963267948966)
	local var14 = var2.HandRange
	local var15 = arg1:FindFirstChild("HandRangeCircle")
	if typeof(var14) ~= "number" or (var14 ~= var14 or (var14 <= 0 or var6 <= var14)) then
		if var15 then
			var15:Destroy()
		end
	elseif not var15 then
		var15 = var31:Clone()
		var15.Name = "HandRangeCircle"
		var15.Anchored = true
		var15.CastShadow = false
		var15.CanCollide = false
		var15.CanTouch = false
		var15.CanQuery = false
		var15.Parent = arg1
	end

	updateConeLines(arg2, var2, arg1, var12, var6, var13)
	return var10
end

local function updateUpgradeProgress(arg1)
	local var2 = math.max(var24.getMaxLevel((var24.getUnitId(arg1))) - 1, 0)
	local var3 = math.max(var24.getLevel(arg1) - 1, 0)
	if 0 < var2 then
		local var4 = math.clamp(var3 / var2, 0, 1)
		var4 = var4 or 0
	end

	var40.Visible = 0 < var2
	local num1 = 0
	if var43 then
		var43:Cancel()
	end

	var47.Visible = 0 < var2
	var43 = var12:Create(var47, var20, { Size = UDim2.new(num1, 0, 1, 0) })
	var43:Play()
	for k1, v1 in ipairs(var41:GetChildren()) do
		if v1 == str5 then
			continue
		end

		if not v1:IsA("GuiObject") then
			continue
		end

		if v1.Name ~= "Template" then
			continue
		end

		v1:Destroy()
	end

	local var5 = math.max(var2 - 1, 0)
	str5.Visible = 0 < var5
	for i1 = 2, var5 do
		local var6 = str5:Clone()
		var6.Visible = true
		var6.LayoutOrder = i1
		var6.Parent = var41
	end
end

formatTimer = function(arg1, arg2)
	local var1 = var3:FindFirstChild("WaveState")
	local var2 = var1
	local var5 = tonumber(var2 and var1:GetAttribute("GameSpeed"))
	if not var5 or (var5 ~= var5 or (var5 <= 0 or var5 == math.huge)) then
		var5 = 1
	end

	getAbilityCooldownRemaining(arg2)
	watchSupportTower.Visible = true
	local var6 = watchSupportTower
	local var8 = var6
	var8 = var8 and var6:FindFirstChild("TowerName", true)
	local var9 = arg1.Name
	if var8 and (var8:IsA("TextLabel") or var8:IsA("TextButton")) then
		var8.Text = tostring(var9)
	end

	var6 = var24.getStats(arg1.Name, arg1)
	var8 = var24.getUnitId(arg1)
	var9 = math.max(var6.Level, 1)
	local var11 = var7.get(var8, var9)
	local bool1 = true
	if var11 == nil then
		bool1 = var6.SupportType == var7.SupportType
	end

	local var13 = var24.getNextStats(var24.getUnitId(arg1), var6.Level)
	var11 = bool1 and (var11 or var7.get(var8, var9))
	local var14, var15, var16 = var7.applyToStats(arg1, tonumber(var6.Damage) or 0, tonumber(var6.Range) or 0, tonumber(var6.Cooldown) or 1)
	local var17 = nil
	local var18 = nil
	local var19 = nil
	if var13 then
		local var20, var21, var22 = var7.applyToStats(arg1, tonumber(var13.Damage) or 0, tonumber(var13.Range) or 0, tonumber(var13.Cooldown) or 1)
		var17 = var20
		var18 = var21
		var19 = var22
	end

	local var23 = watchSupportTower
	local var25 = var23
	var25 = var25 and var23:FindFirstChild("lvl", true)
	local var26 = if var13 == nil then ("Lv. %* (MAX)"):format(var9) else ("Lv. %*"):format(var9)
	if var25 and (var25:IsA("TextLabel") or var25:IsA("TextButton")) then
		var25.Text = tostring(var26)
	end

	var23 = watchSupportTower:FindFirstChild("Stats")
	if var23 then
		var23 = var23:FindFirstChild("ScrollingFrame") or var23
		local var29 = var23:FindFirstChild("Damage")
		var25 = var23:FindFirstChild("Cash")
		local var30 = var23:FindFirstChild("Health")
		local var31 = var23:FindFirstChild("Range")
		local var32 = var23:FindFirstChild("Cooldown")
		local var35 = var6.SupportType == "Income"
		local var38 = var6.SupportType == "Heal"
		if var29 then
			if var29:IsA("GuiObject") then
				local var40 = bool1
				if not var40 then
					var40 = not var35
					if var40 then
						var40 = (tonumber(var6.Damage) or 0) ~= 0
					end
				end

				var29.Visible = var40
			end
		end

		if var31 then
			if var31:IsA("GuiObject") then
				local var42 = bool1
				if not var42 then
					var42 = not var35
					if var42 then
						var42 = (tonumber(var6.Range) or 0) ~= 0
					end
				end

				var31.Visible = var42
			end
		end

		if var32 then
			if var32:IsA("GuiObject") then
				local var44 = bool1
				if not var44 then
					var44 = not var35
					if var44 then
						var44 = (tonumber(var6.Cooldown) or 0) ~= 0
					end
				end

				var32.Visible = var44
			end
		end

		if var25 then
			if var25:IsA("GuiObject") then
				local var46 = var35
				if var46 then
					var46 = (tonumber(var6.Income) or 0) ~= 0
				end

				var25.Visible = var46
				if var25.Visible then
					var46 = var13
					if var46 then
						var46 = tonumber(var13.Income)
					end

					local var47 = tostring((math.floor(var6.Income)))
					local var49 = if var46 then tostring((math.floor(var46))) else nil
					var47 = var25
					var47 = var47 and var25:FindFirstChild("Amount", true)
					local var50 = if var49 == nil or (var49 == "" or var49 == var47) then var47 else var47 .. " > " .. var49
					if var47 and (var47:IsA("TextLabel") or var47:IsA("TextButton")) then
						var47.Text = tostring(var50)
					end
				end
			end
		end

		if var30 then
			if var30:IsA("GuiObject") then
				local var52 = var38
				if var52 then
					var52 = (tonumber(var6.Heal) or 0) ~= 0
				end

				var30.Visible = var52
				if var30.Visible then
					var52 = var13
					if var52 then
						var52 = tonumber(var13.Heal)
					end

					local var53 = tostring((math.floor(var6.Heal)))
					local var55 = if var52 then tostring((math.floor(var52))) else nil
					var53 = var30
					var53 = var53 and var30:FindFirstChild("Amount", true)
					local var56 = if var55 == nil or (var55 == "" or var55 == var53) then var53 else var53 .. " > " .. var55
					if var53 and (var53:IsA("TextLabel") or var53:IsA("TextButton")) then
						var53.Text = tostring(var56)
					end
				end
			end
		end

		if bool1 then
			local var64 = var7.get(var8, var9 + 1)
			local var65, var66, var67 = var7.formatLevel(var11)
			local var68 = nil
			local var69 = nil
			local var70 = nil
			if var64 then
				local var71, var72, var73 = var7.formatLevel(var64)
				var68 = var71
				var69 = var72
				var70 = var73
			end

			local var74 = var29
			var74 = var74 and var29:FindFirstChild("Amount", true)
			local var75 = if var68 == nil or (var68 == "" or var68 == var65) then var65 else var65 .. " > " .. var68
			if var74 and (var74:IsA("TextLabel") or var74:IsA("TextButton")) then
				var74.Text = tostring(var75)
			end

			var74 = var31
			var74 = var74 and var31:FindFirstChild("Amount", true)
			var75 = if var69 == nil or (var69 == "" or var69 == var66) then var66 else var66 .. " > " .. var69
			if var74 and (var74:IsA("TextLabel") or var74:IsA("TextButton")) then
				var74.Text = tostring(var75)
			end

			var74 = var32
			var74 = var74 and var32:FindFirstChild("Amount", true)
			var75 = if var70 == nil or (var70 == "" or var70 == var67) then var67 else var67 .. " > " .. var70
			if var74 and (var74:IsA("TextLabel") or var74:IsA("TextButton")) then
				var74.Text = tostring(var75)
			end
		else
			local var76 = string.format("%.2f", var14)
	if not not var76:find("%.") then
				var76 = var76:gsub("0+$", ""):gsub("%.$", "")
			end

			local var78
			if var17 then
				var78 = string.format("%.2f", var17)
	if not not var78:find("%.") then
					var78 = var78:gsub("0+$", ""):gsub("%.$", "")
				end
			else
				var78 = nil
			end

			var76 = var29
			var76 = var76 and var29:FindFirstChild("Amount", true)
			local var79 = if var78 == nil or (var78 == "" or var78 == var76) then var76 else var76 .. " > " .. var78
			if var76 and (var76:IsA("TextLabel") or var76:IsA("TextButton")) then
				var76.Text = tostring(var79)
			end

			var76 = string.format("%.2f", var15)
	if not not var76:find("%.") then
				var76 = var76:gsub("0+$", ""):gsub("%.$", "")
			end

			if var18 then
				var78 = string.format("%.2f", var18)
	if not not var78:find("%.") then
					var78 = var78:gsub("0+$", ""):gsub("%.$", "")
				end
			else
				var78 = nil
			end

			var76 = var31
			var76 = var76 and var31:FindFirstChild("Amount", true)
			var79 = if var78 == nil or (var78 == "" or var78 == var76) then var76 else var76 .. " > " .. var78
			if var76 and (var76:IsA("TextLabel") or var76:IsA("TextButton")) then
				var76.Text = tostring(var79)
			end

			local var81 = tonumber(var16)
			var78 = if not var81 or (var81 ~= var81 or var81 == math.huge) then nil else var81 / var5
			if not var78 then
				var76 = tostring(var16)
			else
				var76 = string.format("%.3f", var78)
	if not not var76:find("%.") then
					var76 = var76:gsub("0+$", ""):gsub("%.$", "")
				end
			end

			if var19 then
				local var83 = tonumber(var19)
				local var85 = if not var83 or (var83 ~= var83 or var83 == math.huge) then nil else var83 / var5
				if not var85 then
					var78 = tostring(var19)
				else
					var78 = string.format("%.3f", var85)
	if not not var78:find("%.") then
						var78 = var78:gsub("0+$", ""):gsub("%.$", "")
					end
				end
			else
				var78 = nil
			end

			var76 = var32
			var76 = var76 and var32:FindFirstChild("Amount", true)
			var79 = if var78 == nil or (var78 == "" or var78 == var76) then var76 else var76 .. " > " .. var78
			if var76 and (var76:IsA("TextLabel") or var76:IsA("TextButton")) then
				var76.Text = tostring(var79)
			end
		end

		local var87 = not var35
		local var88 = var23:FindFirstChild("Angle")
		if var87 then
			var87 = false
			if var6.AttackType == "Cone" then
				var87 = (tonumber(var6.AttackAngle) or 0) ~= 0
			end
		end

		if var88 and var88:IsA("GuiObject") then
			var88.Visible = var87
			if var87 then
				local var90 = var88
				var90 = var90 and var88:FindFirstChild("Amount", true)
				var78 = string.format("%g\194\176", var6.AttackAngle)
				if var90 and (var90:IsA("TextLabel") or var90:IsA("TextButton")) then
					var90.Text = tostring(var78)
				end
			end
		end
	end

	var25 = var33:FindFirstChild("Target")
	if var25 then
		if var25:IsA("GuiObject") then
			local bool5 = false
			if var6.SupportType ~= "Income" then
				bool5 = not bool1
			end

			var25.Visible = bool5
		end
	end

	local var93 = watchSupportTower:FindFirstChild("UnitInfo")
	if var93 then
		local var94 = var93
		var94 = var94 and var93:FindFirstChild("TowerName", true)
		local var95 = arg1.Name
		if var94 and (var94:IsA("TextLabel") or var94:IsA("TextButton")) then
			var94.Text = tostring(var95)
		end

		var95 = var93
		var95 = var95 and var93:FindFirstChild("lvl", true)
		if var95 and (var95:IsA("TextLabel") or var95:IsA("TextButton")) then
			var95.Text = tostring(var26)
		end

		var95 = var93:FindFirstChild("DPS", true)
		if var95 and var95:IsA("GuiObject") then
			var95.Visible = not bool1
		end

		if not bool1 then
			local var97 = tonumber(var16)
			var94 = math.max(0, var14)
			local num1 = 0.01
			var97 = var93
			var97 = var97 and var93:FindFirstChild("DPS", true)
			local var98 = "DPS: " .. string.format("%.1f", var94 / math.max(num1, (if not var97 or (var97 ~= var97 or var97 == math.huge) then nil else var97 / var5) or 1)):gsub("%.0$", "")
			if var97 and (var97:IsA("TextLabel") or var97:IsA("TextButton")) then
				var97.Text = tostring(var98)
			end
		end

		var94 = var93:FindFirstChild("TowerIcon", true)
		if var94 and (var94:IsA("ImageLabel") or var94:IsA("ImageButton")) then
			var94.Image = var6.Icon or ""
		end
	end

	local var99 = var34:WaitForChild("Title")
	local var100 = var99
	var100 = var100 and var99:FindFirstChild("_TITLE", true)
	if var100 and (var100:IsA("TextLabel") or var100:IsA("TextButton")) then
		var100.Text = tostring("Sell:")
	end

	var99 = var34:WaitForChild("Title"):WaitForChild("Cash")
	local var101 = var99
	var101 = var101 and var99:FindFirstChild("amount", true)
	var100 = tostring(arg1:GetAttribute("SellPrice") or 0)
	if var101 and (var101:IsA("TextLabel") or var101:IsA("TextButton")) then
		var101.Text = tostring(var100)
	end

	var99 = arg1:GetAttribute("TargetMode")
	if var99 ~= "First" then
		if var99 ~= "Last" and (var99 ~= "Strong" and (var99 ~= "Near" and var99 ~= "Random")) then
			var99 = "First"
		end
	end

	var100 = var33:FindFirstChild("Target")
	local var102 = var100
	var102 = var102 and var100:FindFirstChild("TargetName", true)
	if var102 and (var102:IsA("TextLabel") or var102:IsA("TextButton")) then
		var102.Text = tostring(var99)
	end

	var100 = var13 ~= nil
	var101 = var100
	if var101 then
		var101 = typeof(var6.UpgradePrice) == "number"
	end

	if var36:IsA("GuiObject") then
		var36.Visible = var101
		if var101 then
			setUpgradeButtonText(var36, var6.UpgradePrice)
		end
	end

	updateUpgradeAffordability()
	if var37:IsA("GuiObject") then
		var37.Visible = not var100
	end
end

local var80 = var59:FindFirstChild("TowerUpgradedLocal")
var67 = function(arg1)
	var48 = arg1
	showSupportPopup.Visible = true
	if var42 then
		var42:Disconnect()
	end

	var42 = arg1.Destroying:Connect(closeUpgradeFrame)
	if var50 then
		var50:Disconnect()
	end

	var50 = arg1:GetAttributeChangedSignal("Level"):Connect(function()
		if var48 == arg1 and (arg1.Parent == var14 and showSupportPopup.Visible) then
			var67(arg1)
		end
	end)

	local var2 = var52
	if var2 then
		var2:Destroy()
	end

	local var3, var4 = makeRangeCircle()
	var52 = var3
	var53 = var4
	local var5 = arg1
	setRangeCircleVisual(var52, "Selected", var24.getUnitId(var5))
	var3 = var53
	var4 = var9.Get(var24.getUnitId(arg1), "Selected").Cone
	if not not var3 then
		for k1, v1 in pairs(var3) do
			v1.BackgroundColor3 = var4
		end
	end

	updateRangeCircle(var52, var53, arg1, true)
	updateUpgradeProgress(arg1)
	var3 = getTowerOwner(arg1)
	var49 = var3 == var21.Name
	formatTimer(arg1, var3)
	local var6 = var36
	var4 = var49
	local var7
	if var6:IsA("GuiButton") then
		var7 = var6
	else
		var5 = var6:FindFirstChild("Use", true)
		var7 = if var5 and var5:IsA("GuiButton") then var5 else var6:FindFirstChildWhichIsA("GuiButton", true)
	end

	if var7 then
		var7.Active = var4
	end

	var38.Active = var4
	var5 = var33:FindFirstChild("Target")
	if var5:IsA("GuiButton") then
		var6 = var5
	else
		local var10 = var5:FindFirstChild("Use", true)
		var6 = if var10 and var10:IsA("GuiButton") then var10 else var5:FindFirstChildWhichIsA("GuiButton", true)
	end

	if var6 then
		var6.Active = var4
	end

	tbl2.Refresh()
	if not var49 then
		setUpgradeAffordable(false)
	end

	local str1 = "BoostDamageMult"
	local str2 = "BoostRangeMult"
	local str3 = "BoostCooldownMult"
	local var11 = tonumber(arg1:GetAttribute(str1)) or 1
	local str4 = "%.4f|%.4f|%.4f"
	local var12 = tonumber(arg1:GetAttribute(str2)) or 1
	local var13 = tonumber(arg1:GetAttribute(str3)) or 1
	showSupportPopup:SetAttribute("BoostSignature", string.format(str4, var11, var12, var13))
end

local tbl8 = {
	[Enum.KeyCode.One] = 1,
	[Enum.KeyCode.Two] = 2,
	[Enum.KeyCode.Three] = 3,
	[Enum.KeyCode.Four] = 4,
	[Enum.KeyCode.Five] = 5,
}

local function rememberTowerAim(arg1, arg2)
	if typeof(arg1) ~= "Instance" then
		return
	end

	if typeof(arg2) == "Instance" then
		isPressInput[arg1] = arg2
	else
		isPressInput[arg1] = nil
	end

	local var1
	if typeof(arg1) ~= "Instance" then
		var1 = nil
	else
		if arg1:IsA("BasePart") then
			var1 = arg1
		else
			if arg1:IsA("Model") then
				var1 = arg1.PrimaryPart
				var1 = var1 or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart"))
				if not var1 then
					var1 = arg1:FindFirstChildWhichIsA("BasePart", true)
				end
			else
				var1 = nil
			end
		end
	end

	local var2
	if typeof(arg2) ~= "Instance" then
		var2 = nil
	else
		if arg2:IsA("BasePart") then
			var2 = arg2
		else
			if arg2:IsA("Model") then
				var2 = arg2.PrimaryPart
				var2 = var2 or (arg2:FindFirstChild("HumanoidRootPart") or arg2:FindFirstChild("HumanoidPart"))
				if not var2 then
					var2 = arg2:FindFirstChildWhichIsA("BasePart", true)
				end
			else
				var2 = nil
			end
		end
	end

	if not var1 or (not var2) then
		return
	end

	local var3 = var2.Position - var1.Position
	local var4 = Vector3.new(var3.X, 0, var3.Z)
	local var6 = if var4.Magnitude <= 0.0001 then nil else var4.Unit
	if var6 then
		var55[arg1] = var6
	end
end

local function bindValueLabel(arg1, arg2, arg3)
	local var1 = nil
	local function refresh()
		if var1 then
			var1:Disconnect()
			var1 = nil
		end

		local var2 = findPlayerValue(arg1)
		arg2.Text = arg3(var2 and var2.Value or 0)
		if var2 then
			var1 = var2.Changed:Connect(function()
				arg2.Text = arg3(var2.Value)
			end)

		end
	end

	refresh()
	var21.ChildAdded:Connect(refresh)
	var21.ChildRemoved:Connect(refresh)
end

local function requestPlayerData()
	while true do
		local bool1 = false
		if var21.Parent == var2 then
			bool1 = script.Parent ~= nil
		end

		if not bool1 then
			break
		end

		while true do
			bool1 = false
			if var21.Parent == var2 then
				bool1 = script.Parent ~= nil
			end

			if not bool1 then
				break
			end

			if var21:GetAttribute("PlayerDataLoaded") ~= true or var21:GetAttribute("LoadoutReady") ~= true then
				task.wait(0.1)
				continue
			end
		end

		bool1 = false
		if var21.Parent == var2 then
			bool1 = script.Parent ~= nil
		end

		if not bool1 then
			return nil
		end

		local bool2 = false
		local var1 = nil
		bool1 = false
		task.spawn(function()
			local success, result = pcall(function()
				return str2:InvokeServer()
			end)

			bool2 = success
			var1 = result
			bool1 = true
		end)

		while not bool1 do
			local bool3 = false
			if var21.Parent == var2 then
				bool3 = script.Parent ~= nil
			end

			if not bool3 then
				break
			end

			task.wait()
		end

		local bool4 = false
		if var21.Parent == var2 then
			bool4 = script.Parent ~= nil
		end

		if not bool4 then
			return nil
		end

		if bool2 then
			local var3 = var1
			bool4 = false
			if typeof(var3) == "table" then
				bool4 = false
				if typeof(var3.Inventory) == "table" then
					bool4 = typeof(var3.Inventory.Slots) == "table"
				end
			end

			if bool4 then
				return var1
			end
		end

		task.wait(0.5)
	end

	return nil
end

local function raycastFromPointer(arg1, arg2)
	local var1 = var58
	var1 = var1 or var16:GetMouseLocation() - var17:GetGuiInset()
	local var3 = var22:ScreenPointToRay(var1.X, var1.Y)
	local var5 = workspace:FindFirstChild("EngineerUnits")
	var1 = { var22 }
	if var5 then
		table.insert(var1, var5)
	end

	if arg1 then
		table.insert(var1, arg1)
	end

	if arg2 then
		for k1, v1 in ipairs(arg2) do
			if not v1 then
				continue
			end

			table.insert(var1, v1)
		end
	end

	for k2, v2 in ipairs(var2:GetPlayers()) do
		if not v2.Character then
			continue
		end

		table.insert(var1, v2.Character)
	end

	local var6 = RaycastParams.new()
	var6.FilterType = Enum.RaycastFilterType.Exclude
	var6.FilterDescendantsInstances = var1
	local var7 = var3.Origin
	local var8 = var3.Direction * 1000
	local var9 = var6
	return workspace:Raycast(var7, var8, var9)
end

local function isPointerOverUpgradeControls()
	local var1 = var23:FindFirstChild("PlaceInfo")
	local var2 = var1
	local var3 = var1
	local var4 = var1
	return showSupportPopup.Visible and isPointerOverGui(watchSupportTower) or (isPointerOverGui(var35) or (isPointerOverGui(tbl2.Root) or var4 and (var1:IsA("GuiObject") and var1.Visible) and (isPointerOverGui(var2 and var1:FindFirstChild("Mobile")) or isPointerOverGui(var3 and var1:FindFirstChild("Pc")))))
end

local function findTowerNearPointer()
	local var1 = var58
	local var2 = var58
	var2 = var2 or var16:GetMouseLocation() - var17:GetGuiInset()
	local var3 = var22:ScreenPointToRay(var2.X, var2.Y)
	var1 = var1 or var16:GetMouseLocation() - var17:GetGuiInset()
	var2 = nil
	local num1 = math.huge
	for k1, v1 in ipairs(var14:GetChildren()) do
		if not v1:IsA("Model") then
			continue
		end

		local var4 = v1.PrimaryPart
		var4 = var4 or (v1:FindFirstChild("HumanoidRootPart") or v1:FindFirstChild("HumanoidPart"))
		var4 = var4 or v1:FindFirstChildWhichIsA("BasePart", true)
		if not var4 then
			continue
		end

		local var5, var6 = var22:WorldToScreenPoint(var4.Position)
		if not var6 then
			continue
		end

		local var7, var8 = v1:GetBoundingBox()
		local var9 = var4.Position
		local var10 = var3.Direction.Unit
		local var11 = var10
		local var12 = (var9 - (var3.Origin + var10 * math.max(0, (var9 - var3.Origin):Dot(var11)))).Magnitude
		local var13 = (Vector2.new(var5.X, var5.Y) - var1).Magnitude
		var9 = var13 + var12 * 4
		if var13 > 72 or var12 > math.max(5, math.max(var8.X, var8.Y, var8.Z) * 0.45) or var9 >= num1 then
			continue
		end

		var2 = v1
		local var15 = var9
	end

	return var2
end

local function startPlacement(arg1)
	if not arg1 then
		return
	end

	local success, result = pcall(function()
		local var1 = arg1
		return str3:InvokeServer(var1)
	end)

	if not success or (not result) then
		return
	end

	local var1 = arg1
	local num1 = 1
	local var3 = var30:FindFirstChild(str1.getModelName(var1, num1))
	if not var3 then
		return
	end

	stopPlacement()
	if var39.gamepadIsPreferred() then
		var39.enableGamepadCursorAtCenter()
	end

	bindScaleTween = arg1
	var44 = var3:Clone()
	local var4 = var3
	var44:SetAttribute("PlacementPivotOffset", tbl7.GetOffset(var4))
	var44:SetAttribute("PlacementGroundPosition", nil)
	var44:SetAttribute("UnitId", arg1)
	var44:SetAttribute("Level", 1)
	local var5
	if var24.getLevelStats(arg1, 1).SupportType ~= nil then
		for k1, v1 in ipairs(var44:GetDescendants()) do
			var5 = "BillboardGui"
			if not v1:IsA(var5) then
				continue
			end

			if v1.Name == "Income" or (v1.Name == "Heal" or v1.Name == "Health") then
				v1.Enabled = false
			end
		end
	end

	var44.Parent = var22
	preparePreviewTower(var44)
	var13(var44)
	local var6, var7 = makeRangeCircle()
	var45 = var6
	var54 = var7
	bool1 = false
	if var46 then
		var46.FillColor = bool1 and var18 or var19
		var46.FillTransparency = 0.875
	end

	var6 = if bool1 then "Allowed" else "Blocked"
	setRangeCircleVisual(var45, var6, bindScaleTween)
	var7 = var54
	num1 = var9.Get(bindScaleTween, var6).Cone
	if not not var7 then
		for k2, v2 in pairs(var7) do
			v2.BackgroundColor3 = num1
		end
	end

	var6 = var23:FindFirstChild("PlaceInfo")
	if var6 and var6:IsA("GuiObject") then
		var6.Visible = true
	end
end

local function placePreviewTower()
	if not var44 or (not bindScaleTween or (not bool1 or (not var64))) then
		return
	end

	local success, result = pcall(function()
		local var1 = bindScaleTween
		local var2 = var64
		return str4:InvokeServer(var1, var2)
	end)

	if success and (typeof(result) == "Instance" and (result:IsA("Model") and result:IsDescendantOf(var14))) then
		stopPlacement()
		var67(result)
	end
end

if not var80 or (not var80:IsA("BindableEvent")) then
	var80 = Instance.new("BindableEvent")
	var80.Name = "TowerUpgradedLocal"
	var80.Parent = var59
end

var80.Event:Connect(function(arg1, arg2)
	if var48 ~= arg1 or (not showSupportPopup.Visible) then
		return
	end

	local var2 = arg1
	if typeof(arg2) == "Instance" then
		if arg2:IsA("Model") and arg2.Parent == var14 then
			var2 = arg2
		end
	end

	if typeof(var2) == "Instance" and var2.Parent == var14 then
		var13(var2)
		var67(var2)
	end
end);

(function()
	local var2 = var3:FindFirstChild("WaveState")
	local function refresh()
		if var48 and (var48.Parent and showSupportPopup.Visible) then
			var67(var48)
		end
	end

	if var2 then
		var2:GetAttributeChangedSignal("GameSpeed"):Connect(refresh)
		return
	end

	task.spawn(function()
		local var2 = var3:WaitForChild("WaveState", 60)
		if var2 then
			var2:GetAttributeChangedSignal("GameSpeed"):Connect(refresh)
		end
	end)
end)()

local function updateSlotVisual(arg1, arg2, arg3)
	local var1 = var24.getSlotName(arg3)
	local var2 = var1
	var2 = var2 and var24.getStatsFromStorage(var1, var30)
	arg1.Name = tostring(arg2)
	arg1.LayoutOrder = arg2
	arg1.Visible = true
	local var4 = arg1:FindFirstChild("KeyBoard_Number", true)
	if var4 then
		if not var4:IsA("TextLabel") then
			if var4:IsA("TextButton") then
				local var5 = var16.KeyboardEnabled
				var4.Visible = var5 and (not var16.TouchEnabled)
				var4.Text = tostring(arg2)
			end
		end
	end

	local var6 = arg1:FindFirstChild("Price", true)
	local var7 = var6
	var7 = var7 and var6:FindFirstChild("price", true)
	local var8 = arg1:FindFirstChild("Icon", true)
	if var6 then
		if var6:IsA("GuiObject") then
			var6.Visible = var2 ~= nil
		end
	end

	if var7 then
		if not var7:IsA("TextLabel") then
			if var7:IsA("TextButton") then
				if var2 then
					local var9 = tostring(var2.Price or "")
					var9 = var9 or ""
				end

				var7.Text = ""
			end
		end
	end

	if var8 then
		if not var8:IsA("ImageLabel") then
			if not var8:IsA("ImageButton") then
				return
			end
		end

		local var10
		if var2 then
			var10 = var2.Icon
			if not var10 then
				var10 = ""
			end
		else
			var10 = ""
		end

		var8.Image = var10
	end
end

var16.InputChanged:Connect(function(arg1, arg2)
	if arg2 then
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement then
		var58 = var16:GetMouseLocation() - var17:GetGuiInset()
		return
	end

	if arg1.UserInputType == Enum.UserInputType.Touch then
		local var1 = var58
		var58 = Vector2.new(arg1.Position.X, arg1.Position.Y)
		if isPointerOverGui(getTransparencyGoals) or isPointerOverUpgradeControls() then
			var58 = var1
		end
	end
end)

var80 = function()
	if isPointerOverGui(getTransparencyGoals) or isPointerOverUpgradeControls() then
		return
	end

	local var1 = raycastFromPointer(nil)
	local var2 = var1
	local var3 = var1.Instance
	local var4 = var3:FindFirstAncestorOfClass("Model")
	var3 = var2 and (var3 and var3:FindFirstAncestorOfClass("Model") and (var4:IsDescendantOf(var14) and var4) or nil)
	var2 = var3 or findTowerNearPointer()
	if var2 then
		var67(var2)
		return
	end

	closeUpgradeFrame()
end

var16.InputBegan:Connect(function(arg1, arg2)
	local var2 = arg1.UserInputType == Enum.UserInputType.Gamepad1
	local var3 = var58
	if var2 and var39.gamepadCursorEnabled() then
		var58 = var16:GetMouseLocation() - var17:GetGuiInset()
	end

	if arg1.UserInputType ~= Enum.UserInputType.Touch then
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			if arg1.UserInputType == Enum.UserInputType.Touch then
				var58 = Vector2.new(arg1.Position.X, arg1.Position.Y)
			else
				var58 = var16:GetMouseLocation() - var17:GetGuiInset()
			end
		end
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
		var65 = os.clock()
		local var4 = var58
		var4 = var4 or var16:GetMouseLocation() - var17:GetGuiInset()
		var66 = var4
		var4 = arg2
		var4 = var4 or (isPointerOverGui(getTransparencyGoals) or isPointerOverUpgradeControls())
		bool4 = var4
		bool5 = var44 ~= nil
		bool6 = bool2
	else
		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			bool2 = true
		end
	end

	if var2 then
		if var44 then
			local var5 = isPointerOverGui(getTransparencyGoals)
			var5 = var5 or isPointerOverUpgradeControls()
			if arg1.KeyCode == Enum.KeyCode.ButtonA then
				if not var5 then
					placePreviewTower()
				end

				return
			end

			if arg1.KeyCode == Enum.KeyCode.ButtonX then
				local var6 = (num1 + 90) % 360
				num1 = var6
				return
			end

			if arg1.KeyCode == Enum.KeyCode.ButtonB then
				stopPlacement()
				return
			end
		else
			if var2 and (arg1.KeyCode == Enum.KeyCode.ButtonA and (not arg2 and (not isPointerOverGui(getTransparencyGoals) and (not isPointerOverUpgradeControls())))) then
				var80()
				return
			end
		end
	else
		if var2 and (arg1.KeyCode == Enum.KeyCode.ButtonA and (not arg2 and (not isPointerOverGui(getTransparencyGoals) and (not isPointerOverUpgradeControls())))) then
			var80()
			return
		end
	end

	if arg2 then
		if arg1.UserInputType == Enum.UserInputType.Touch then
			var58 = var3
			num2 = 0
		end

		return
	end

	if arg1.UserInputType == Enum.UserInputType.Touch and (isPointerOverGui(getTransparencyGoals) or isPointerOverUpgradeControls()) then
		var58 = var3
		num2 = 0
		return
	end

	if not var44 then
		if not var16:GetFocusedTextBox() then
			local var13 = var39.visuals[arg1.KeyCode]
			if var13 then
				if var13(true) then
					local var18 = var39.actions[arg1.KeyCode]
					if var18 then
						task.spawn(var18)
					end

					return
				end
			end
		end
	end

	local var21 = tbl8[arg1.KeyCode]
	if var21 then
		local var22 = tbl3
		local var25 = var22[var21]
		local var26 = var24.getSlotName
		if not var25 then
			var25 = var22[tostring(var21)]
			var25 = var25 or {}
		end

		var26 = var26(var25)
		if var26 then
			startPlacement(var26)
		end

		return
	end

	if var44 then
		if arg1.KeyCode == Enum.KeyCode.R then
			local var27 = num1 + 90
			num1 = var27
			return
		end

		if arg1.KeyCode == Enum.KeyCode.X or (arg1.KeyCode == Enum.KeyCode.C or arg1.KeyCode == Enum.KeyCode.Escape) then
			stopPlacement()
			return
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
			return
		end

		if arg1.UserInputType == Enum.UserInputType.Touch then
			local var29 = os.clock()
			if var29 - num2 <= 0.35 then
				placePreviewTower()
			end

			num2 = var29
			return
		end
	end

	if arg1.UserInputType == Enum.UserInputType.Touch then
		var80()
	end
end)

var16.InputEnded:Connect(function(arg1, arg2)
	local var2 = var39.visuals[arg1.KeyCode]
	if var2 then
		var2(false)
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton1 then
		if arg1.UserInputType == Enum.UserInputType.Touch then
			var58 = Vector2.new(arg1.Position.X, arg1.Position.Y)
		else
			var58 = var16:GetMouseLocation() - var17:GetGuiInset()
		end

		local var3 = var65
		var65 = nil
		local var4 = var66
		var66 = nil
		local var5 = bool4
		bool4 = false
		local var6 = bool5
		bool5 = false
		local var7 = bool6
		bool6 = false
		if arg2 or (var5 or (isPointerOverGui(getTransparencyGoals) or isPointerOverUpgradeControls())) then
			return
		end

		if var6 then
			if bool2 or var7 then
				return
			end

			if not var44 then
				return
			end

			local var9 = var3
			if var9 then
				var9 = var4
				if var9 then
					var9 = false
					if os.clock() - var3 <= 0.45 then
						local var10 = var58
						local var11 = ((var10 or var16:GetMouseLocation() - var17:GetGuiInset()) - var4).Magnitude
						var9 = var11 <= 18
					end
				end
			end

			if not var9 then
				return
			end

			placePreviewTower()
			return
		end

		if not not var44 then
			return
		end

		local var13 = var3
		if var13 then
			var13 = var4
			if var13 then
				var13 = false
				if os.clock() - var3 <= 0.8 then
					local var14 = var58
					local var15 = ((var14 or var16:GetMouseLocation() - var17:GetGuiInset()) - var4).Magnitude
					var13 = var15 <= 18
				end
			end
		end

		if not var13 then
			return
		end

		var80()
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		if arg1.UserInputType == Enum.UserInputType.Touch then
			var58 = Vector2.new(arg1.Position.X, arg1.Position.Y)
		else
			var58 = var16:GetMouseLocation() - var17:GetGuiInset()
		end

		bool2 = false
	end
end)

var15.Stepped:Connect(function()
	if var44 then
		applyPreviewPhysics(var44)
	end
end)

var15.RenderStepped:Connect(function()
	local var6
	if var39.gamepadIsPreferred() and var39.gamepadCursorEnabled() then
		var58 = var16:GetMouseLocation() - var17:GetGuiInset()
	end

	if not var78.ShowAlways then
		var78.SetVisible(var44 ~= nil)
	end

	var78.Update()
	if not var44 then
		var78.HidePreview()
	end

	if var44 then
		applyPreviewPhysics(var44)
		local var3 = raycastFromPointer(var44, { var14, var32 })
		if var3 and var3.Instance then
			local var4 = var78.IsBlocked(var3.Position, bindScaleTween)
			var78.UpdatePreview(var3.Position, bindScaleTween, var4)
			local var5 = var3.Instance
			while not var5 and var5 == workspace and var5.Name == "TowerAllow" do
			end

			bool1 = var6 == true
			if var46 then
				var46.FillColor = bool1 and var18 or var19
				var46.FillTransparency = 0.875
			end

			local var7 = if bool1 then "Allowed" else "Blocked"
			setRangeCircleVisual(var45, var7, bindScaleTween)
			var5 = var54
			local var8 = var9.Get(bindScaleTween, var7).Cone
	if not not var5 then
				for k1, v1 in pairs(var5) do
					v1.BackgroundColor3 = var8
				end
			end

			var7 = var44
			local var6 = var7.PrimaryPart
			var6 = var6 or (var7:FindFirstChild("HumanoidRootPart") or var7:FindFirstChild("HumanoidPart"))
			local var10
			if var6 then
				var6.CanCollide = false
				var6.CanTouch = false
				var6.CanQuery = false
				var6.Anchored = true
				var7 = var44:GetAttribute("PlacementPivotOffset")
				if typeof(var7) ~= "number" then
					var78.HidePreview()
					tbl7.SetCircleVisible(var45, false)
					bool1 = false
					if var46 then
						var46.FillColor = bool1 and var18 or var19
						var46.FillTransparency = 0.875
					end

					var5 = if bool1 then "Allowed" else "Blocked"
					setRangeCircleVisual(var45, var5, bindScaleTween)
					var8 = var54
					local var11 = var9.Get(bindScaleTween, var5).Cone
					if not var8 then
						return
					end

					for k2, v2 in pairs(var8) do
						v2.BackgroundColor3 = var11
					end

					return
				end

				var5 = var3.Position
				var10 = var44:GetAttribute("PreviewSway")
				local var12 = CFrame.new((Vector3.new(var5.X, var5.Y + var7, var5.Z))) * CFrame.Angles(0, math.rad(num1), 0)
				local var13 = var62 and var5 - var62 or Vector3.new(0, 0, 0)
				if typeof(var10) ~= "boolean" then
					local bool2 = false
					if var44.Name ~= "DJ Speaker Man" then
						bool2 = var24.getUnitId(var44) ~= "DJ Speaker Man"
					end

					var10 = bool2
				end

				local var15 = var12
				if var10 then
					var15 = var12 * CFrame.Angles(math.clamp(var13.Z * 0.64, -0.25, 0.25), 0, (math.clamp(-var13.X * 0.64, -0.25, 0.25)))
				end

				local var20 = var63 and var63:Lerp(var15, 0.35) or var15
				var63 = var20
				var44:PivotTo(var63)
				var64 = var12
				var62 = var5
				updateRangeCircle(var45, var54, var44, true)
			end
		else
			var78.HidePreview()
			tbl7.SetCircleVisible(var45, false)
			var62 = nil
			var63 = nil
			var64 = nil
			bool1 = false
			if var46 then
				var46.FillColor = bool1 and var18 or var19
				var46.FillTransparency = 0.875
			end

			local var21 = if bool1 then "Allowed" else "Blocked"
			setRangeCircleVisual(var45, var21, bindScaleTween)
			local var23 = var54
			local var25 = var9.Get(bindScaleTween, var21).Cone
	if not not var23 then
				for k3, v3 in pairs(var23) do
					v3.BackgroundColor3 = var25
				end
			end
		end
	end

	if var48 and var52 then
		updateRangeCircle(var52, var53, var48, true)
		local str2 = "BoostDamageMult"
		local str3 = "BoostRangeMult"
		local var26 = tonumber(var48:GetAttribute(str2)) or 1
		local str4 = "BoostCooldownMult"
		local var27 = string.format("%.4f|%.4f|%.4f", var26, tonumber(var48:GetAttribute(str3)) or 1, tonumber(var48:GetAttribute(str4)) or 1)
		if showSupportPopup.Visible and (showSupportPopup:GetAttribute("BoostSignature") ~= nil and showSupportPopup:GetAttribute("BoostSignature") ~= var27) then
			showSupportPopup:SetAttribute("BoostSignature", var27)
			formatTimer(var48, (getTowerOwner(var48)))
		end
	end
end)

var14.ChildAdded:Connect(var13)
local function loadSlots()
	local var2 = requestPlayerData()
	if var2 == nil then
		return false
	end

	local var3 = typeof(var2) == "table" and var2.Options or nil
	if typeof(var3) == "table" and typeof(var3.Notification) == "boolean" then
		var56 = var3.Notification
	end

	var57 = true
	var3 = tbl5
	tbl5 = {}
	for k1, v1 in ipairs(var3) do
		createNotification(v1.text, v1.duration, v1.color, v1.kind)
	end

	local var4 = var2
	var4 = var4 and var2.Inventory
	tbl3 = var24.normalizeSlots(var4 and var4.Slots or {}, var30)
	for k2, v2 in ipairs(getTransparencyGoals:GetChildren()) do
		if v2 == rememberSupportTransparency then
			continue
		end

		if not v2:IsA("GuiObject") then
			continue
		end

		v2:Destroy()
	end

	rememberSupportTransparency.Visible = false
	for i1 = 1, 5 do
		local var5 = tbl3
		local var7 = var5[i1]
		if not var7 then
			var7 = var5[tostring(i1)]
			var7 = var7 or {}
		end

		var5 = var24.getSlotName(var7)
		local var8 = rememberSupportTransparency:Clone()
		var8.Parent = getTransparencyGoals
		updateSlotVisual(var8, i1, var7)
		local var9
		if var8:IsA("GuiButton") then
			var9 = var8
		else
			local var11 = var8:FindFirstChild("Use", true)
			var9 = if var11 and var11:IsA("GuiButton") then var11 else var8:FindFirstChildWhichIsA("GuiButton", true)
		end

		if not var9 then
			continue
		end

		var9.Activated:Connect(function()
			if var5 then
				startPlacement(var5)
			end
		end)

	end

	return true
end

local function connectUpgradeButtons()
	local var1 = var23:WaitForChild("PlaceInfo")
	local var2 = var1:WaitForChild("Pc")
	local var3 = var1:WaitForChild("Mobile")
	local var4 = var2:Clone()
	var4.Name = "Gamepad"
	for k1, v1 in ipairs(var4:GetDescendants()) do
		if not v1:IsA("TextLabel") then
			if not v1:IsA("TextButton") then
				continue
			end
		end

		if v1.Text == "R" then
			v1.Text = "X"
		else
			if v1.Text == "X" or v1.Text == "C" then
				v1.Text = "B"
			end
		end
	end

	var4.Visible = false
	var4.Parent = var1
	local var5 = var33:WaitForChild("Target")
	local var6 = var3:WaitForChild("RotateInfo"):WaitForChild("Use")
	local var7 = var3:WaitForChild("CancelInfo"):WaitForChild("Use")
	local var9 = var5:WaitForChild("Move"):WaitForChild("Use")
	local var10 = var8:WaitForChild("ChangeTargetMode")
	var1.Visible = false
	local function updatePlacementControls()
		local var5 = var1.Visible
		local bool2 = true
		if var16.PreferredInput ~= Enum.PreferredInput.Touch then
			bool2 = var16.TouchEnabled
			bool2 = bool2 and (not var16.KeyboardEnabled and (not var16.MouseEnabled))
		end

		var3.Visible = var5 and bool2
		local var6 = var5
		local var7 = var16.PreferredInput == Enum.PreferredInput.Gamepad
		var2.Visible = var6 and (not bool2 and (not var7))
		var4.Visible = var5 and var7
	end

	updatePlacementControls()
	var1:GetPropertyChangedSignal("Visible"):Connect(updatePlacementControls)
	var16:GetPropertyChangedSignal("PreferredInput"):Connect(updatePlacementControls)
	var6.Active = true
	var6.Activated:Connect(function()
		num2 = 0
		if var44 then
			local var1 = (num1 + 90) % 360
			num1 = var1
		end
	end)

	var7.Active = true
	var7.Activated:Connect(function()
		num2 = 0
		if var44 then
			stopPlacement()
		end
	end)

	local bool1 = false
	var9.Active = true
	local function requestTargetModeChange()
		if bool1 then
			return
		end

		local var2 = var48
		if not var2 or (not var2.Parent or getTowerOwner(var2) ~= var21.Name) then
			return
		end

		bool1 = true
		var9.Active = false
		local success, result, var3 = pcall(function()
			local var1 = var2
			return var10:InvokeServer(var1)
		end)

		bool1 = false
		if var9.Parent then
			var9.Active = var49
		end

		if success then
			if result then
				if typeof(var3) == "string" then
					if var48 == var2 then
						if var2.Parent then
							local var13 = var5
							local var14 = var13
							var14 = var14 and var13:FindFirstChild("TargetName", true)
							if var14 and (var14:IsA("TextLabel") or var14:IsA("TextButton")) then
								var14.Text = tostring(var3)
							end
						end
					end
				end
			end
		end
	end

	var9.Activated:Connect(requestTargetModeChange)
	var39.actions[Enum.KeyCode.T] = requestTargetModeChange
	var38.Active = true
	local function requestSell()
		if bool3 then
			return
		end

		local var2 = var48
		if not var2 or (not var2.Parent or getTowerOwner(var2) ~= var21.Name) then
			return
		end

		bool3 = true
		var38.Active = false
		local success, result = pcall(function()
			local var1 = var2
			return var25:InvokeServer(var1)
		end)

		bool3 = false
		if var38.Parent then
			var38.Active = var49
		end

		if not success then
			return
		end

		if (result or (not var2.Parent)) and var48 == var2 then
			closeUpgradeFrame()
		end
	end

	var38.Activated:Connect(requestSell)
	var39.actions[Enum.KeyCode.X] = requestSell
	local var11 = var36
	local var12
	if var11:IsA("GuiButton") then
		var12 = var11
	else
		local var15 = var11:FindFirstChild("Use", true)
		var12 = if var15 and var15:IsA("GuiButton") then var15 else var11:FindFirstChildWhichIsA("GuiButton", true)
	end

	if var12 then
		var11 = false
		local function requestUpgrade()
			if var11 then
				return
			end

			local var2 = var48
			if not var2 or (not var2.Parent or (not var36.Visible or getTowerOwner(var2) ~= var21.Name)) then
				return
			end

			var11 = true
			var12.Active = false
			local success, result, var3 = pcall(function()
				local var1 = var2
				return var26:InvokeServer(var1)
			end)

			var11 = false
			if var12.Parent then
				var12.Active = var49
			end

			if success then
				if result then
					if typeof(var3) == "Instance" and var3:IsA("Model") then
						var13(var3)
						var67(var3)
						return
					end

					if var2.Parent then
						var13(var2)
						var67(var2)
					end
				end
			end
		end

		var12.Activated:Connect(requestUpgrade)
		var39.actions[Enum.KeyCode.E] = requestUpgrade
	end
end

for k2, v2 in ipairs(var14:GetChildren()) do
	var13(v2)
end

local var81 = (function()
	local var1 = setmetatable({}, { __mode = "k" })
	local function emitCoreRing(arg1, arg2)
		if not arg1.Parent then
			return
		end

		local var2 = arg1:FindFirstChild("Core", true)
		if not var2 or (not var2:IsA("BasePart")) then
			return
		end

		local var4 = var2:FindFirstChildWhichIsA("Attachment")
		local var7 = getTowerAimDirection(arg1)
		local var8 = if var4 then var4.WorldPosition else var2.Position
		if var7 then
			if var7.Magnitude <= 0.0001 then
				local var10 = var2.CFrame.LookVector
				local var11 = Vector3.new(var10.X, 0, var10.Z)
				var7 = (if var11.Magnitude <= 0.0001 then nil else var11.Unit) or Vector3.new(0, 0, -1)
			end
		end

		var7 = var7.Unit
		local var13 = var7:Cross(Vector3.new(0, 1, 0))
		if var13.Magnitude <= 0.0001 then
			var13 = var2.CFrame.RightVector
		end

		var13 = var13.Unit
		local var14 = (arg2 - 1) * 0.12 + 0.48
		local var15 = (arg2 - 1) * 0.55 + 3.2
		local var16 = var13:Cross(var7).Unit
		local var17 = var2.Color:Lerp(Color3.new(1, 1, 1), 0.22)
		local var18 = Instance.new("Folder")
		var18.Name = "TitanCoreRing"
		var18.Parent = workspace
		for i1 = 1, 16 do
			local var19 = (i1 - 1) / 16 * 3.1415926535897931 * 2
			local var20 = math.cos(var19)
			local var21 = math.sin(var19)
			local var22 = var13 * var20 + var16 * var21
			local var23 = (arg2 - 1) * 0.7 + 3.8
			local var24 = Instance.new("Part")
			var24.Name = "RingSegment"
			var24.Anchored = true
			var24.CanCollide = false
			var24.CanQuery = false
			var24.CanTouch = false
			var24.CastShadow = false
			var24.Material = Enum.Material.Neon
			var24.Color = var17
			var24.Transparency = 0.08
			local var25 = 6.2831853071795862 * var14 / 16 * 0.9
			var24.Size = Vector3.new(0.1, 0.1, var25)
			local var26 = var8 + var22 * var14
			local var27 = -var13 * var21 + var16 * var20
			var24.CFrame = CFrame.lookAt(var26, var26 + var27, var7)
			var24.Parent = var18
			local var28 = var8 + var7 * var23 + var22 * var15
			local var29 = TweenInfo.new(0.42, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local var30 = 6.2831853071795862 * var15 / 16 * 0.9
			local tbl1 = { CFrame = CFrame.lookAt(var28, var28 + var27, var7), Transparency = 1 }
			tbl1.Size = Vector3.new(0.18, 0.18, var30)
			local var31 = var12:Create(var24, var29, tbl1)
			local num1 = 16
			var31.Completed:Once(function()
				if var24.Parent then
					var24:Destroy()
				end

				local var1 = num1 - 1
				num1 = var1
				if num1 <= 0 and var18.Parent then
					var18:Destroy()
				end
			end)

			var31:Play()
		end

		task.delay(1.42, function()
			if var18.Parent then
				var18:Destroy()
			end
		end)
	end

	return function(arg1, arg2)
		if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or arg1.Name ~= "Titan Speaker Man 2.0") then
			return
		end

		local var2 = os.clock()
		if var2 - (var1[arg1] or 0) < math.clamp((tonumber(arg2) or 0.5) * 0.35, 0.12, 0.4) then
			return
		end

		var1[arg1] = var2
		local num1 = 1
		task.delay(0, function()
			emitCoreRing(arg1, num1)
		end)

		num1 = 2
		task.delay(0.1, function()
			emitCoreRing(arg1, num1)
		end)
	end
end)()

tbl2.GetTitanArmMuzzlePositions = (function()
	local tbl1 = { "Cube.480", "Cube.482" }
	return function(arg1)
		local tbl2 = {}
		if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or arg1.Name ~= "Titan Speaker Man 2.0") then
			return tbl2
		end

		local tbl3 = {}
		for k1, v1 in arg1:GetDescendants() do
			if not v1:IsA("BasePart") then
				continue
			end

			if tbl3[v1.Name] then
				continue
			end

			tbl3[v1.Name] = v1
		end

		for k2, v2 in ipairs(tbl1) do
			local var1 = tbl3[v2]
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("Attachment")
			if not var2 then
				continue
			end

			if not var2:IsA("Attachment") then
				continue
			end

			table.insert(tbl2, var2.WorldPosition)
		end

		return tbl2
	end
end)()

tbl2.EmitTitanSpeakerArmProjectile = (function()
	local tbl1 = { "Cube.480", "Cube.482" }
	local function fireFromArm(arg1, arg2, arg3, arg4)
		local var1 = nil
		for k1, v1 in arg1:GetDescendants() do
			if v1.Name ~= arg2 then
				continue
			end

			if not v1:IsA("BasePart") then
				continue
			end

			var1 = v1
			break
		end

		local var2 = var1
		var2 = var2 and var1:FindFirstChild("Attachment")
		if not var2 or (not var2:IsA("Attachment")) then
			return
		end

		local var3 = var2.WorldPosition
		local var4 = math.clamp((arg3 - var3).Magnitude / math.max(1, tonumber(arg4.NormalProjectileSpeed) or 175), 0.04, 1.5)
		local var5 = math.max(0.1, tonumber(arg4.NormalProjectileSize) or 0.72)
		local var6 = Instance.new("Part")
		var6.Name = "TitanArmProjectile"
		var6.Shape = Enum.PartType.Ball
		var6.Size = Vector3.new(1, 1, 1) * var5
		var6.CFrame = CFrame.new(var3)
		var6.Anchored = true
		var6.CanCollide = false
		var6.CanQuery = false
		var6.CanTouch = false
		var6.CastShadow = false
		var6.Material = Enum.Material.Neon
		local var7 = arg4.NormalProjectileColor
		var7 = var7 or Color3.fromRGB(255, 35, 35)
		var6.Color = var7
		var6.Parent = workspace
		local var8 = TweenInfo.new(var4, Enum.EasingStyle.Linear)
		local tbl1 = { CFrame = CFrame.new(arg3) }
		tbl1.Size = Vector3.new(1, 1, 1) * var5 * 0.72
		var7 = var12:Create(var6, var8, tbl1)
		var7.Completed:Once(function()
			if var6.Parent then
				var6:Destroy()
			end
		end)

		var7:Play()
		task.delay(var4 + 0.5, function()
			if var6.Parent then
				var6:Destroy()
			end
		end)
	end

	return function(arg1, arg2, arg3)
		if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or arg1.Name ~= "Titan Speaker Man 2.0") then
			return
		end

		local var2
		if typeof(arg2) == "Instance" then
			if arg2:IsA("Model") then
				var2 = arg2.PrimaryPart
				var2 = var2 or (arg2:FindFirstChild("HumanoidRootPart") or arg2:FindFirstChild("HumanoidPart"))
				if not var2 then
					var2 = arg2
				end
			end
		else
			var2 = nil
		end

		local var3
		if typeof(arg3) == "Vector3" then
			var3 = arg3
		else
			var3 = if var2 and var2:IsA("BasePart") then var2.Position else nil
		end

		local var4 = arg1
		local var6 = tbl2.Config.get(var24.getUnitId(arg1), var24.getLevel(var4))
		if not var3 or (not var6) then
			return
		end

		for k1, v1 in ipairs(tbl1) do
			fireFromArm(arg1, v1, var3, var6)
		end
	end
end)()

var27.OnClientEvent:Connect(function(arg1, arg2, arg3, arg4, arg5)
	rememberTowerAim(arg1, arg3)
	var5.play(arg1, arg2, arg4)
	if arg2 == "Attack" then
		tbl2.EmitTitanSpeakerArmProjectile(arg1, arg3, arg5)
	end

	local var1 = arg1
	var1 = var1 and (arg1.PrimaryPart or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart")))
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("Attack")
	if var2 then
		if var2:IsA("Sound") then
			if var2.Playing then
				var2.TimePosition = 0
			end

			var2:Play()
		end
	end
end)

tbl2.ProjectileEvent.OnClientEvent:Connect(function(arg1, arg2)
	if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or typeof(arg2) ~= "Instance") then
		return
	end

	local var1 = arg1
	local var2 = tbl2.Config.get(var24.getUnitId(arg1), var24.getLevel(var1))
	local var3 = arg2:FindFirstChild("HumanoidPart")
	local var4 = arg1:FindFirstChild("AbilityOrigin", true)
	var4 = var4 or (arg1:FindFirstChild("Core", true) or (arg1.PrimaryPart or (arg1:FindFirstChild("HumanoidRootPart") or arg1:FindFirstChild("HumanoidPart"))))
	var3 = arg2:IsA("Model") and (arg2.PrimaryPart or (arg2:FindFirstChild("HumanoidRootPart") or arg2:FindFirstChild("HumanoidPart"))) or arg2
	if not var2 or (not var4 or (not var4:IsA("BasePart") or (not var3 or (not var3:IsA("BasePart"))))) then
		return
	end

	rememberTowerAim(arg1, arg2)
	var81(arg1, var2.BurstInterval)
	local var5 = tbl2.GetTitanArmMuzzlePositions(arg1)
	var1 = var4:FindFirstChildWhichIsA("Attachment")
	if #var5 == 0 then
		var5 = { if var1 then var1.WorldPosition else var4.Position }
	end

	local var6 = var3.Position
	local var7 = math.max(1, tonumber(var2.ProjectileSpeed) or 120)
	local var8 = math.max(0.1, tonumber(var2.ProjectileSize) or 0.85)
	for k1, v1 in ipairs(var5) do
		local var9 = math.clamp((var6 - v1).Magnitude / var7, 0.04, 1.5)
		local var10 = Instance.new("Part")
		var10.Name = "TitanAbilityBall"
		var10.Shape = Enum.PartType.Ball
		var10.Size = Vector3.new(1, 1, 1) * var8
		var10.CFrame = CFrame.new(v1)
		var10.Anchored = true
		var10.CanCollide = false
		var10.CanQuery = false
		var10.CanTouch = false
		var10.CastShadow = false
		var10.Material = Enum.Material.Neon
		local var11 = var2.ProjectileColor
		var11 = var11 or Color3.fromRGB(255, 35, 35)
		var10.Color = var11
		var10.Parent = workspace
		local var13 = TweenInfo.new(var9, Enum.EasingStyle.Linear)
		local tbl1 = { CFrame = CFrame.new(var6) }
		tbl1.Size = Vector3.new(1, 1, 1) * var8 * 0.72
		var11 = var12:Create(var10, var13, tbl1)
		var11.Completed:Once(function()
			if var10.Parent then
				var10:Destroy()
			end
		end)

		var11:Play()
		task.delay(var9 + 0.5, function()
			if var10.Parent then
				var10:Destroy()
			end
		end)

	end
end)

bindValueLabel("Cash", applyTransparencyGoals, function(arg1)
	updateUpgradeAffordability(arg1)
	tbl2.Refresh()
	return (tostring(arg1))
end)

bindValueLabel("PlacedUnits", tweenTransparencyGoals, function(arg1)
	return tostring(arg1) .. "/" .. tostring(var21:GetAttribute("MaxPlacedUnits") or 8)
end)

tbl2.Root.Visible = false
tbl2.Card.Visible = false
showSupportPopup.Visible = false
connectUpgradeButtons()
task.spawn(function()
	while true do
		if not script.Parent then
			break
		end

		if showSupportPopup.Visible then
			tbl2.Refresh()
		end

		task.wait(0.1)
	end
end)

local function reportClientLoaded()
	while true do
		local bool1 = false
		if var21.Parent == var2 then
			bool1 = script.Parent ~= nil
		end

		if not bool1 then
			break
		end

		if game:IsLoaded() then
			break
		end

		task.wait(0.1)
	end

	while true do
		local bool2 = false
		if var21.Parent == var2 then
			bool2 = script.Parent ~= nil
		end

		if not bool2 then
			break
		end

		bool2 = var21.Character
		local var1 = bool2
		var1 = var1 and bool2:FindFirstChild("HumanoidRootPart")
		if bool2 and (bool2 == var21.Character and (bool2.Parent ~= nil and (var1 and (var1:IsA("BasePart") and var1:IsDescendantOf(bool2))))) then
			var29:FireServer()
			return
		end

		task.wait(0.1)
	end
end

task.defer(function()
	if loadSlots() then
		if var39.gamepadIsPreferred() then
			var39.enableGamepadCursorAtCenter()
		end

		reportClientLoaded()
	end
end)

var16:GetPropertyChangedSignal("PreferredInput"):Connect(function()
	if var39.gamepadIsPreferred() then
		task.defer(var39.enableGamepadCursorAtCenter)
	end
end)

task.spawn(function()
	while script.Parent do
		task.wait(2)
	if not bool7 then
			bool7 = true
			task.spawn(function()
				local success, result = pcall(function()
					return str2:InvokeServer()
				end)

				if success then
					local var1 = typeof(result) == "table" and result.Options or nil
					if typeof(var1) == "table" and typeof(var1.Notification) == "boolean" then
						var56 = var1.Notification
					end
				end

				bool7 = false
			end)

		end
	end
end)

--- Players.LocalPlayer.PlayerGui.MainGameUI.BossBarController [LocalScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainGameUI"):WaitForChild("UpSide"):WaitForChild("BossBar")
local tbl1 = {}
local tbl2 = {}
local var2 = game:GetService("TweenService")
local var3 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local function formatNumber(arg1)
	arg1 = math.max(0, (math.floor(arg1 + 0.5)))
	if 1000000000 <= arg1 then
		local var2 = ("%.1f"):format(arg1 / 1000000000)
		if var2:sub(-2) == ".0" then
			var2 = var2:sub(1, -3)
		end

		return var2 .. "B"
	end

	if 1000000 <= arg1 then
		local var4 = ("%.1f"):format(arg1 / 1000000)
		if var4:sub(-2) == ".0" then
			var4 = var4:sub(1, -3)
		end

		return var4 .. "M"
	end

	if 1000 <= arg1 then
		local var6 = ("%.1f"):format(arg1 / 1000)
		if var6:sub(-2) == ".0" then
			var6 = var6:sub(1, -3)
		end

		return var6 .. "k"
	end

	return (tostring(arg1))
end

local function updateEntry(arg1)
	local var4 = arg1.Humanoid
	if not var4 then
		return
	end

	local var5 = math.max(var4.MaxHealth, 1)
	local var6 = math.clamp(var4.Health, 0, var5)
	if arg1.Fill then
		var2:Create(arg1.Fill, var3, { Size = UDim2.new(var6 / var5, 0, arg1.Fill.Size.Y.Scale, arg1.Fill.Size.Y.Offset) }):Play()
	end

	if arg1.HealthLabel then
		arg1.HealthLabel.Text = ("%s/%s"):format(formatNumber(var6), (formatNumber(var5)))
	end
end

local function removeEntry(arg1)
	local var2 = tbl1[arg1]
	if var2 then
		tbl1[arg1] = nil
		var2:Disconnect()
	end

	local var4 = tbl2[arg1]
	if not var4 then
		return
	end

	tbl2[arg1] = nil
	for k1, v1 in ipairs(var4.Connections) do
		v1:Disconnect()
	end

	if var4.Frame then
		var4.Frame:Destroy()
	end
end

local var4 = game:GetService("CollectionService")
local var5 = var1:WaitForChild("Template")
local function updateName(arg1)
	if not arg1.NameLabel then
		return
	end

	local var1 = arg1.Mob:GetAttribute("HealthBarName")
	if typeof(var1) == "string" then
		if var1 == "" then
			var1 = arg1.Mob:GetAttribute("MobId")
		end
	end

	if typeof(var1) ~= "string" or var1 == "" then
		var1 = arg1.Mob.Name
	end

	arg1.NameLabel.Text = var1
end

local function bindHumanoid(arg1)
	local var1 = arg1.Mob
	local var2 = var1:FindFirstChildOfClass("Humanoid")
	var2 = var2 or var1:FindFirstChildWhichIsA("Humanoid", true)
	if not var2 then
		return false
	end

	arg1.Humanoid = var2
	local function fn2()
		updateEntry(arg1)
	end

	table.insert(arg1.Connections, var2:GetPropertyChangedSignal("Health"):Connect(fn2))
	fn2 = function()
		updateEntry(arg1)
	end

	table.insert(arg1.Connections, var2:GetPropertyChangedSignal("MaxHealth"):Connect(fn2))
	fn2 = function()
		removeEntry(arg1.Mob)
	end

	table.insert(arg1.Connections, var2.Died:Connect(fn2))
	updateEntry(arg1)
	return true
end

local str1 = "BossHealthBar"
local function addEntry(arg1)
	if tbl2[arg1] or (not arg1:IsA("Model")) then
		return
	end

	if not var4:HasTag(arg1, "BossHealthBar") then
		return
	end

	local var2 = var5:Clone()
	var2.Name = "Bar_" .. arg1.Name
	var2.Visible = true
	local var3 = var2:FindFirstChild("bar")
	local var6 = var3
	var6 = var6 and var3:FindFirstChild("Frame")
	local tbl1 = { Mob = arg1, Frame = var2, Fill = var6, Humanoid = nil }
	var6 = var3
	var6 = var6 and var3:FindFirstChild("Hp")
	tbl1.HealthLabel = var6
	tbl1.NameLabel = var2:FindFirstChild("Hp")
	tbl1.Icon = var2:FindFirstChild("Icon")
	tbl1.Connections = {}
	tbl2[arg1] = tbl1
	var6 = tbl1.Mob:GetAttribute("HealthBarOrder")
	local var7 = tbl1.Frame
	local var8 = if typeof(var6) == "number" then math.floor(var6) else 0
	var7.LayoutOrder = var8
	updateName(tbl1)
	if not tbl1.Icon then
	else
		var6 = tbl1.Mob:GetAttribute("HealthBarIcon")
		if typeof(var6) == "string" and var6 ~= "" then
			tbl1.Icon.Image = var6
		end
	end

	local function fn2()
		local var1 = tbl1
		local var2 = var1.Mob:GetAttribute("HealthBarOrder")
		local var3 = var1.Frame
		local var4 = if typeof(var2) == "number" then math.floor(var2) else 0
		var3.LayoutOrder = var4
	end

	table.insert(tbl1.Connections, arg1:GetAttributeChangedSignal("HealthBarOrder"):Connect(fn2))
	fn2 = function()
		updateName(tbl1)
	end

	table.insert(tbl1.Connections, arg1:GetAttributeChangedSignal("HealthBarName"):Connect(fn2))
	fn2 = function()
		local var1 = tbl1
		if not var1.Icon then
			return
		end

		local var2 = var1.Mob:GetAttribute("HealthBarIcon")
		if typeof(var2) == "string" and var2 ~= "" then
			var1.Icon.Image = var2
		end
	end

	table.insert(tbl1.Connections, arg1:GetAttributeChangedSignal("HealthBarIcon"):Connect(fn2))
	fn2 = function()
		if not arg1:IsDescendantOf(workspace) then
			removeEntry(arg1)
		end
	end

	table.insert(tbl1.Connections, arg1.AncestryChanged:Connect(fn2))
	fn2 = function()
		removeEntry(arg1)
	end

	table.insert(tbl1.Connections, arg1.Destroying:Connect(fn2))
	var2.Parent = var1
	if not bindHumanoid(tbl1) then
		var6 = nil
		table.insert(tbl1.Connections, (arg1.DescendantAdded:Connect(function(arg1)
			if arg1:IsA("Humanoid") and (tbl2[arg1] and (not tbl1.Humanoid)) then
				var6:Disconnect()
				bindHumanoid(tbl1)
			end
		end)))

	end
end

for k1, v1 in ipairs(var4:GetTagged(str1)) do
	if not v1:IsDescendantOf(workspace) then
		continue
	end

	addEntry(v1)
end

var4:GetInstanceAddedSignal("BossHealthBar"):Connect(function(arg1)
	if arg1:IsDescendantOf(workspace) then
		addEntry(arg1)
		return
	end

	local var2 = tbl1[arg1]
	if var2 then
		var2:Disconnect()
	end

	tbl1[arg1] = arg1.AncestryChanged:Connect(function()
		if not arg1:IsDescendantOf(workspace) then
			return
		end

		tbl1[arg1] = nil
		local var2 = tbl1[arg1]
		if var2 then
			var2:Disconnect()
		end

		addEntry(arg1)
	end)
end)

var4:GetInstanceRemovedSignal("BossHealthBar"):Connect(removeEntry)

--- Players.LocalPlayer.PlayerGui.MainGameUI.UpSide.InfoDop.Wave.Wave [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("WaveState")
local var2 = script.Parent
local function updateWaveText()
	local var3 = var1:GetAttribute("IntermissionRemaining")
	local var4 = var1:GetAttribute("CurrentWave")
	local var5 = var1:GetAttribute("TotalWaves")
	if var1:GetAttribute("MatchState") == "Intermission" and (typeof(var3) == "number" and 0 < var3) then
		var2.Text = ("Intermission %d"):format((math.ceil(var3)))
		return
	end

	if typeof(var4) ~= "number" or typeof(var5) ~= "number" then
		var2.Text = "Wave ?/?"
		return
	end

	if var1:GetAttribute("IsEndless") == true then
		var2.Text = ("Wave %d"):format(var4)
		return
	end

	var2.Text = ("Wave %d/%d"):format(var4, var5)
end

var1:GetAttributeChangedSignal("CurrentWave"):Connect(updateWaveText)
var1:GetAttributeChangedSignal("TotalWaves"):Connect(updateWaveText)
var1:GetAttributeChangedSignal("MatchState"):Connect(updateWaveText)
var1:GetAttributeChangedSignal("IntermissionRemaining"):Connect(updateWaveText)
var1:GetAttributeChangedSignal("IsEndless"):Connect(updateWaveText)
updateWaveText()

--- Players.LocalPlayer.PlayerGui.MainGameUI.UpSide.InfoDop.AutoSkip.AutoSkipController [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = var1:WaitForChild("Move")
local var3 = var2:WaitForChild("Use")
assert(var3:IsA("GuiButton"), "AutoSkip.Move.Use must be a GuiButton")
local var4 = var2:WaitForChild("UIScale")
assert(var4:IsA("UIScale"), "AutoSkip.Move.UIScale must be a UIScale")
local var5 = var2:WaitForChild("UIShadow")
assert(var5:IsA("UIShadow"), "AutoSkip.Move.UIShadow must be a UIShadow")
local var6 = var1.Parent.Parent:WaitForChild("Skip")
assert(var6:IsA("GuiObject"), "MainGameUI.UpSide.Skip must be a GuiObject")
local var7 = game:GetService("ReplicatedStorage")
local var8 = var7:WaitForChild("RemoteEvents"):WaitForChild("SkipWaveVote")
assert(var8:IsA("RemoteEvent"), "SkipWaveVote must be a RemoteEvent")
local var9 = game:GetService("TweenService")
local var10 = game:GetService("Players").LocalPlayer
local var11 = var7:WaitForChild("WaveState")
local var12 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var13 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var14 = Color3.fromRGB(255, 0, 0)
local var15 = Color3.fromRGB(0, 255, 0)
local tbl1 = {}
local tbl2 = {}
for k1, v1 in ipairs(var2:GetDescendants()) do
	if not v1:IsA("UIGradient") then
		continue
	end

	if v1.Name == "AutoOff" then
		table.insert(tbl1, v1)
	else
		if v1.Name ~= "AutoOn" then
			continue
		end

		table.insert(tbl2, v1)
	end
end

assert(0 < (#tbl1), "AutoSkip.Move must contain an AutoOff UIGradient")
assert(0 < (#tbl2), "AutoSkip.Move must contain an AutoOn UIGradient")
local bool1 = false
local bool2 = false
local var16 = nil
local bool3 = false
local var17 = nil
local function tweenScale(arg1)
	if var16 then
		var16:Cancel()
	end

	local var1 = var9
	local var2 = var4
	local var5 = arg1
	local tbl1 = {}
	local var6
	if not var3.Active then
		var6 = 1
	else
		if bool1 then
			var6 = 0.94
		elseif bool2 then
			var6 = 1.08
		else
			var6 = 1
		end
	end

	tbl1.Scale = var6
	var1 = var1:Create(var2, var5, tbl1)
	var16 = var1
	var1.Completed:Connect(function()
		if var16 == var1 then
			var16 = nil
		end
	end)

	var1:Play()
end

var3.MouseEnter:Connect(function()
	bool2 = true
	if bool1 then
		return
	end

	tweenScale(var12)
end)

var3.MouseLeave:Connect(function()
	bool2 = false
	if bool1 then
		return
	end

	tweenScale(var12)
end)

var3.InputBegan:Connect(function(arg1)
	if var3.Active then
		local bool2 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool2 = arg1.UserInputType == Enum.UserInputType.Touch
		end

		if not bool2 then
			return
		end
	end

	bool1 = true
	tweenScale(var13)
end)

var3.InputEnded:Connect(function(arg1)
	local bool2 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool2 = arg1.UserInputType == Enum.UserInputType.Touch
	end

	if not bool2 then
		return
	end

	bool1 = false
	tweenScale(var13)
end)

local function updateAppearance()
	for k1, v1 in ipairs(tbl1) do
		v1.Enabled = not bool3
	end

	for k2, v2 in ipairs(tbl2) do
		v2.Enabled = bool3
	end

	var5.Color = if bool3 then var15 else var14
end

local function tryAutoSkip()
	if not bool3 then
		return
	end

	local var1 = var11:GetAttribute("CurrentWave")
	if typeof(var1) ~= "number" then
		return
	end

	if var11:GetAttribute("CanSkipWave") ~= true then
		return
	end

	local var3 = var11:GetAttribute("Result")
	if var3 == "Win" or var3 == "Lose" then
		return
	end

	if var10:GetAttribute("SkipVoteWave") == var1 then
		return
	end

	if var17 == var1 then
		return
	end

	var17 = var1
	var8:FireServer(var1)
end

var3.Activated:Connect(function()
	local var1 = not bool3
	bool3 = var1
	updateAppearance()
	if bool3 then
		var6.Visible = false
	else
		var1 = var11:GetAttribute("Result")
		local var2 = var6
		local bool2 = false
		if var11:GetAttribute("CanSkipWave") == true then
			bool2 = false
			if var1 ~= "Win" then
				bool2 = var1 ~= "Lose"
			end
		end

		var2.Visible = bool2
	end

	if bool3 then
		tryAutoSkip()
	end
end)

var6:GetPropertyChangedSignal("Visible"):Connect(function()
	if bool3 and var6.Visible then
		var6.Visible = false
	end
end)

var11:GetAttributeChangedSignal("CurrentWave"):Connect(function()
	var17 = nil
	task.defer(tryAutoSkip)
end)

var11:GetAttributeChangedSignal("CanSkipWave"):Connect(function()
	if bool3 then
		var6.Visible = false
	else
		local var2 = var11:GetAttribute("Result")
		local var3 = var6
		local bool2 = false
		if var11:GetAttribute("CanSkipWave") == true then
			bool2 = false
			if var2 ~= "Win" then
				bool2 = var2 ~= "Lose"
			end
		end

		var3.Visible = bool2
	end

	tryAutoSkip()
end)

var4.Scale = 1
updateAppearance()
if bool3 then
	var6.Visible = false
else
	local var19 = var11:GetAttribute("Result")
	local bool5 = false
	if var11:GetAttribute("CanSkipWave") == true then
		bool5 = false
		if var19 ~= "Win" then
			bool5 = var19 ~= "Lose"
		end
	end

	var6.Visible = bool5
end

tryAutoSkip()

--- Players.LocalPlayer.PlayerGui.GameEndUI.ReplayController [LocalScript]
-- y u r i

local var1 = script.Parent:WaitForChild("Frame"):WaitForChild("Selector"):WaitForChild("Replay")
local var3 = var1:FindFirstChildOfClass("UIScale")
local var4 = game:GetService("ReplicatedStorage")
local var5 = game:GetService("TweenService")
local var6 = game:GetService("Players").LocalPlayer
local var7 = var1:WaitForChild("Use")
local var8 = var1:WaitForChild("main"):WaitForChild("Amount")
if not var3 then
	var3 = Instance.new("UIScale")
	var3.Name = "ReplayHoverScale"
	var3.Parent = var1
end

local bool1 = false
local bool2 = false
local var9 = nil
local var10 = var4:WaitForChild("WaveState")
local bool3 = false
local function tweenScale(arg1)
	if var9 then
		var9:Cancel()
	end

	local var1 = var5
	local var2 = var3
	local var4 = arg1
	local tbl1 = {}
	local var6
	if not var7.Active then
		var6 = 1
	else
		if bool1 then
			var6 = 0.965
		elseif bool2 then
			var6 = 1.035
		else
			var6 = 1
		end
	end

	tbl1.Scale = var6
	var1 = var1:Create(var2, var4, tbl1)
	var9 = var1
	var1.Completed:Connect(function()
		if var9 == var1 then
			var9 = nil
		end
	end)

	var1:Play()
end

local var11 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
var7.MouseEnter:Connect(function()
	bool2 = true
	tweenScale(var11)
end)

var7.MouseLeave:Connect(function()
	bool2 = false
	bool1 = false
	tweenScale(var11)
end)

var7.SelectionGained:Connect(function()
	bool2 = true
	tweenScale(var11)
end)

var7.SelectionLost:Connect(function()
	bool2 = false
	bool1 = false
	tweenScale(var11)
end)

local var12 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
var7.InputBegan:Connect(function(arg1)
	if var7.Active then
		local bool4 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool4 = true
			if arg1.UserInputType ~= Enum.UserInputType.Touch then
				bool4 = arg1.KeyCode == Enum.KeyCode.ButtonA
			end
		end

		if bool4 then
			bool1 = true
			tweenScale(var12)
		end
	end
end)

var7.InputEnded:Connect(function(arg1)
	local bool3 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool3 = true
		if arg1.UserInputType ~= Enum.UserInputType.Touch then
			bool3 = arg1.KeyCode == Enum.KeyCode.ButtonA
		end
	end

	if bool3 then
		bool1 = false
		tweenScale(var12)
	end
end)

local function update()
	local var3 = var10:GetAttribute("Result")
	local bool2 = true
	if var3 ~= "Win" then
		bool2 = var3 == "Lose"
	end

	local var4 = var10:GetAttribute("ReplayVotes")
	local var5 = var10:GetAttribute("ReplayVotesRequired")
	local var9 = var10:GetAttribute("ReplayVoteRound")
	local var12 = var6:GetAttribute("ReplayVoteRound")
	if typeof(var4) ~= "number" then
		var4 = 0
	end

	if typeof(var5) ~= "number" then
		var5 = 1
	end

	var4 = math.max(math.floor(var4), 0)
	var5 = math.max(math.floor(var5), 1)
	var8.Text = ("Replay (%d/%d)"):format(var4, var5)
	local var14 = bool2
	if var14 then
		var14 = false
		if typeof(var9) == "number" then
			var14 = false
			if 0 < var9 then
				var14 = var12 == var9
			end
		end
	end

	local var16 = bool2
	if var16 then
		var16 = not var14
		if var16 then
			var16 = not bool3
			if var16 then
				var16 = var4 < var5
			end
		end
	end

	var7.Active = var16
	var7.AutoButtonColor = var16
	var1.Visible = bool2
	if not var16 then
		bool1 = false
	end

	tweenScale(var11)
end

local var13 = var4:WaitForChild("RemoteEvents"):WaitForChild("ReplayVote")
var7.Activated:Connect(function()
	if not var7.Active then
		return
	end

	bool3 = true
	update()
	var13:FireServer()
	task.delay(1.5, function()
		if bool3 then
			bool3 = false
			update()
		end
	end)
end)

var10:GetAttributeChangedSignal("Result"):Connect(update)
var10:GetAttributeChangedSignal("ReplayVotes"):Connect(update)
var10:GetAttributeChangedSignal("ReplayVotesRequired"):Connect(update)
var10:GetAttributeChangedSignal("ReplayVoteRound"):Connect(update)
var6:GetAttributeChangedSignal("ReplayVoteRound"):Connect(update)
update()

--- Players.LocalPlayer.PlayerGui.GameEndUI.EndScreenController [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1:WaitForChild("Shared")
local str1 = "EndRewardsConfig"
local str2 = "MapConfig"
local var3 = require(var2:WaitForChild(str1))
local var4 = require(var2:WaitForChild(str2))
local var5 = game:GetService("TweenService")
local var6 = game:GetService("Players").LocalPlayer
str1 = script.Parent
str1.ResetOnSpawn = false
local var8 = str1:FindFirstChild("Frame")
str2 = str1:WaitForChild("NewFrame")
if var8 and var8:IsA("GuiObject") then
	var8.Visible = false
end

local var9 = str2:WaitForChild("Upside")
local var10 = str2:WaitForChild("ListRewards")
local var11 = var9:WaitForChild("WinStreak")
local var12 = str2:WaitForChild("_NewFrames"):WaitForChild("Frame")
local var13 = var9:WaitForChild("MapName")
local var14 = var9:WaitForChild("Mode"):WaitForChild("Mode")
local var15 = var9:WaitForChild("Timer"):WaitForChild("TextLabel")
local var16 = var9:WaitForChild("StatusFrame"):WaitForChild("Status")
local var17 = var9:WaitForChild("image"):WaitForChild("MapIcon")
local var18 = var10:WaitForChild("Template")
local var19 = var10:FindFirstChildOfClass("UIListLayout")
local var20 = var11:WaitForChild("Title")
local var21 = var12:WaitForChild("Template")
var21.Visible = false
local str3 = "Coins"
local str4 = "Xp"
local tbl1 = {}
for k1, v1 in ipairs({ str3, str4 }) do
	local var22 = var21:Clone()
	var22.Name = "Multiplier_" .. v1
	var22.LayoutOrder = k1
	var22.Visible = true
	local var23 = var22:WaitForChild("Icon")
	var23.Image = var3.Icons[v1]
	var22.Parent = var12
	tbl1[v1] = var22
end

local var24 = str2:WaitForChild("Selector")
local var25 = var1:WaitForChild("RemoteEvents")
local var26 = var24:WaitForChild("Lobby")
local var27 = var24:WaitForChild("Replay")
local var28 = var1:WaitForChild("WaveState")
local var29 = var1:WaitForChild("Modes")
local var30 = var1:WaitForChild("ReturnToLobby")
local var31 = var25:WaitForChild("ReplayVote")
local var32 = var25:WaitForChild("ContinueEndlessVote")
local var33 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var34 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
var18.Visible = false
local tbl2 = {
	Easy = true,
	Medium = true,
	Hard = true,
	Insane = true,
	Crazy = true,
	Endless = true,
	CurrentModeGradient = true,
}

local tbl3 = {
	easy = "Easy",
	medium = "Medium",
	hard = "Hard",
	insane = "Insane",
	crazy = "Crazy",
	endless = "Endless",
}

if var19 then
	var19.SortOrder = Enum.SortOrder.LayoutOrder
end

local function applyModeGradient(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("UIGradient") then
			continue
		end

		if not tbl2[v1.Name] then
			continue
		end

		v1:Destroy()
	end

	if not arg2 then
		return
	end

	local var2 = var29:FindFirstChild(arg2)
	if not var2 or (not var2:IsA("UIGradient")) then
		return
	end

	local var3 = var2:Clone()
	var3.Name = "CurrentModeGradient"
	var3.Enabled = true
	var3.Parent = arg1
end

local function findUseButton(arg1, arg2)
	local var2 = arg1:FindFirstChild("Use", true)
	if var2 and var2:IsA("GuiButton") then
		return var2
	end

	local var4 = arg1:FindFirstChildWhichIsA("GuiButton", true)
	if var4 then
		return var4
	end

	local var5 = Instance.new("TextButton")
	var5.Name = arg2
	var5.BackgroundTransparency = 1
	var5.Text = ""
	var5.AutoButtonColor = false
	var5.Size = UDim2.fromScale(1, 1)
	var5.ZIndex = 20
	var5.Parent = arg1
	return var5
end

local var36 = var24:FindFirstChild("Endless")
local bool1 = false
local bool2 = false
local bool3 = false
local bool4 = false
local bool5 = false
local function normalizeMode(arg1)
	if typeof(arg1) ~= "string" then
		return nil
	end

	local var2 = arg1:match("^%s*(.-)%s*$")
	if not var2 or var2 == "" then
		return nil
	end

	local var4 = var2:match("^(.-)%s+[Mm][Oo][Dd][Ee]$")
	if var4 and var4 ~= "" then
		var2 = var4
	end

	return tbl3[string.lower(var2)] or var2
end

local function makeButton(arg1, arg2)
	local var2 = arg1:FindFirstChildOfClass("UIScale")
	if not var2 then
		var2 = Instance.new("UIScale")
		var2.Name = "EndScreenScale"
		var2.Scale = 1
		var2.Parent = arg1
	end

	local var4 = arg1:FindFirstChild("_TITLE")
	local tbl1 = {
		Root = arg1,
		Use = findUseButton(arg1, arg2),
		Hovered = false,
		Pressed = false,
		Tween = nil,
	}

	local var6
	if var4 and var4:IsA("TextLabel") then
		var6 = var4
	else
		local var8 = arg1:FindFirstChild("_TITLE", true)
		var6 = if var8 and var8:IsA("TextLabel") then var8 else nil
	end

	tbl1.Title = var6
	tbl1.Scale = var2
	tbl1.Use.AutoButtonColor = false
	var4 = function(arg1)
		if tbl1.Tween then
			tbl1.Tween:Cancel()
		end

		local var1 = var5
		local var2 = tbl1.Scale
		local var3 = arg1
		local tbl2 = {}
		local var4
		if not tbl1.Use.Active then
			var4 = 1
		else
			if tbl1.Pressed then
				var4 = 0.965
			elseif tbl1.Hovered then
				var4 = 1.035
			else
				var4 = 1
			end
		end

		tbl2.Scale = var4
		var1 = var1:Create(var2, var3, tbl2)
		tbl1.Tween = var1
		var1:Play()
	end

	tbl1.Use.MouseEnter:Connect(function()
		tbl1.Hovered = true
		var4(var33)
	end)

	tbl1.Use.MouseLeave:Connect(function()
		tbl1.Hovered = false
		tbl1.Pressed = false
		var4(var33)
	end)

	tbl1.Use.SelectionGained:Connect(function()
		tbl1.Hovered = true
		var4(var33)
	end)

	tbl1.Use.SelectionLost:Connect(function()
		tbl1.Hovered = false
		tbl1.Pressed = false
		var4(var33)
	end)

	tbl1.Use.InputBegan:Connect(function(arg1)
		if tbl1.Use.Active then
			local bool3 = true
			if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
				bool3 = true
				if arg1.UserInputType ~= Enum.UserInputType.Touch then
					bool3 = arg1.KeyCode == Enum.KeyCode.ButtonA
				end
			end

			if bool3 then
				tbl1.Pressed = true
				var4(var34)
			end
		end
	end)

	tbl1.Use.InputEnded:Connect(function(arg1)
		local bool2 = true
		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			bool2 = true
			if arg1.UserInputType ~= Enum.UserInputType.Touch then
				bool2 = arg1.KeyCode == Enum.KeyCode.ButtonA
			end
		end

		if bool2 then
			tbl1.Pressed = false
			var4(var34)
		end
	end)

	return tbl1
end

if not var36 then
	local var37 = var27:Clone()
	var37.Name = "Endless"
	var37.LayoutOrder = var27.LayoutOrder + 1
	var37.Visible = false
	var37.Parent = var24
	var36 = var37
end

local function clearRows()
	for k1, v1 in ipairs(var10:GetChildren()) do
		if v1:GetAttribute("EndRewardRow") ~= true then
			continue
		end

		v1:Destroy()
	end
end

local var38 = makeButton(var26, "LobbyUse")
local var39 = makeButton(var27, "ReplayUse")
local var40 = makeButton(var36, "EndlessUse")
local function buildContext(arg1, arg2)
	local tbl1 = { Result = arg1, IsWin = arg2, IsEndless = var28:GetAttribute("IsEndless") == true }
	tbl1.MapId = tostring(var28:GetAttribute("MapId") or "")
	tbl1.MapName = tostring(var28:GetAttribute("MapDisplayName") or "")
	tbl1.Mode = tostring(var28:GetAttribute("MapMode") or "")
	local str1 = "MatchRewardCoins"
	local var2 = tonumber(var6:GetAttribute(str1))
	local var3 = if var2 == nil or var2 ~= var2 then 0 else var2
	local var4
	if var28:GetAttribute("MapMode") == "Endless" then
		local str3 = "MatchBonusCoins"
		local var7 = tonumber(var6:GetAttribute(str3))
		if var7 == nil or var7 ~= var7 then
			var4 = 0
		else
			var4 = var7
		end
	else
		var4 = 0
	end

	tbl1.Coins = var3 + var4
	str1 = "MatchRewardXp"
	var2 = tonumber(var6:GetAttribute(str1))
	local str4 = "EndlessRewardXp"
	local var9 = tonumber(var6:GetAttribute(str4))
	var3 = if var2 == nil or var2 ~= var2 then 0 else var2
	tbl1.Xp = var3 + (if var9 == nil or var9 ~= var9 then 0 else var9)
	str1 = "MatchRewardTickets"
	var2 = tonumber(var6:GetAttribute(str1))
	str4 = "EndlessRewardTickets"
	var9 = tonumber(var6:GetAttribute(str4))
	var3 = if var2 == nil or var2 ~= var2 then 0 else var2
	tbl1.Tickets = var3 + (if var9 == nil or var9 ~= var9 then 0 else var9)
	str1 = "MatchRewardFreeCrates"
	var2 = tonumber(var6:GetAttribute(str1))
	str4 = "EndlessRewardFreeCrates"
	var9 = tonumber(var6:GetAttribute(str4))
	var3 = if var2 == nil or var2 ~= var2 then 0 else var2
	tbl1.Crates = var3 + (if var9 == nil or var9 ~= var9 then 0 else var9)
	local str5 = "EndlessRewardSummonDiscount"
	var4 = tonumber(var6:GetAttribute(str5))
	tbl1.SummonDiscount = if var4 == nil or var4 ~= var4 then 0 else var4
	str1 = "MatchRewardConfetti"
	var2 = tonumber(var6:GetAttribute(str1))
	str4 = "EndlessRewardConfetti"
	var9 = tonumber(var6:GetAttribute(str4))
	var3 = if var2 == nil or var2 ~= var2 then 0 else var2
	tbl1.Confetti = var3 + (if var9 == nil or var9 ~= var9 then 0 else var9)
	tbl1.LimitedUnit = tostring(var6:GetAttribute("MatchRewardLimitedUnit") or "")
	str5 = "MatchRewardCoinMultiplier"
	var4 = tonumber(var6:GetAttribute(str5))
	var3 = 1
	if not var4 then
		str4 = "MatchCoinMultiplier"
		var9 = tonumber(var6:GetAttribute(str4))
		var4 = if var9 == nil or var9 ~= var9 then 0 else var9
	end

	tbl1.CoinMultiplier = math.max(var3, var4)
	str5 = "ElapsedSeconds"
	var4 = tonumber(var28:GetAttribute(str5))
	tbl1.ElapsedSeconds = if var4 == nil or var4 ~= var4 then 0 else var4
	return tbl1
end

local function renderHeader(arg1, arg2)
	local var1 = normalizeMode(arg1.Mode)
	local var2 = var13
	var2.Text = if arg1.MapName ~= "" then arg1.MapName else "???"
	var14.Text = var1 or "..."
	var2 = var14
	applyModeGradient(var2, var1)
	local var5 = var2:FindFirstChildOfClass("UIStroke")
	if var5 then
		applyModeGradient(var5, var1)
	end

	local var6 = math.max(math.floor(arg1.ElapsedSeconds), 0)
	var15.Text = ("%02d:%02d"):format(math.floor(var6 / 60), var6 % 60)
	var2 = var16
	if arg2 then
		var5 = "Continue?"
	else
		var5 = if arg1.IsWin then "Triumph!" else "You Lose!"
	end

	var2.Text = var5
	var2 = arg1.IsWin
	var5 = function(arg1)
		for k1, v1 in ipairs(arg1:GetChildren()) do
			if not v1:IsA("UIGradient") then
				continue
			end

			if v1.Name == "Win" then
				v1.Enabled = var2
			else
				if v1.Name ~= "Lose" then
					continue
				end

				v1.Enabled = not var2
			end
		end
	end

	var5(var16)
	local var8 = var16:FindFirstChildOfClass("UIStroke")
	if var8 then
		var5(var8)
	end

	var2 = if arg1.MapId ~= "" then var4.GetById(arg1.MapId) else nil
	if var2 and var2.Icon then
		var17.Image = var2.Icon
	end
end

local function renderRewards(arg1)
	clearRows()
	for k1, v1 in ipairs((var3.Build(arg1.MapId, arg1))) do
		local var1 = var18:Clone()
		var1.Name = "Reward_" .. v1.Id
		var1.LayoutOrder = v1.LayoutOrder
		var1:SetAttribute("EndRewardRow", true)
		var1.Visible = true
		local var4 = var1:FindFirstChild("Amount")
		if var4 and var4:IsA("TextLabel") then
			var4.Text = v1.Text
		end

		local var6 = var1:FindFirstChild("Icon")
		if var6 and var6:IsA("ImageLabel") then
			var6.Image = v1.Icon
		end

		var1.Parent = var10
	end
end

local function renderMultipliers(arg1)
	local str1 = "MatchWinStreak"
	local var2 = tonumber(var6:GetAttribute(str1))
	local num1 = 0
	local var3
	if not var2 then
		local str3 = "WinStreak"
		var3 = tonumber(var6:GetAttribute(str3))
		var2 = if var3 == nil or var3 ~= var3 then 0 else var3
	end

	local var4 = math.max(num1, (math.floor(var2)))
	var20.Text = tostring(var4)
	var11.Visible = true
	if arg1.Mode == "Endless" then
		num1 = 1
	else
		local str4 = "MatchXpMultiplier"
		num1 = tonumber(var6:GetAttribute(str4))
		if not num1 then
			var3 = 10
			num1 = math.min(var4, var3) * 0.05 + 1
		end
	end

	for k1, v1 in pairs(tbl1) do
		local var5 = v1:WaitForChild("Amount")
		var5.Text = "x" .. string.format("%.2f", if k1 == "Coins" then arg1.CoinMultiplier else num1):gsub("0+$", ""):gsub("%.$", "")
	end
end

local function updateReplayButton()
	local var2 = var28:GetAttribute("Result")
	local bool1 = true
	if var2 ~= "Win" then
		bool1 = var2 == "Lose"
	end

	local str1 = "ReplayVotes"
	local var4 = tonumber(var28:GetAttribute(str1))
	local str2 = "ReplayVotesRequired"
	local var7 = tonumber(var28:GetAttribute(str2))
	local var8 = math.max(math.floor(if var4 == nil or var4 ~= var4 then 0 else var4), 0)
	str1 = "ReplayVoteRound"
	var4 = tonumber(var28:GetAttribute(str1))
	local var9 = math.max(math.floor(if var7 == nil or var7 ~= var7 then 0 else var7), 1)
	str2 = "ReplayVoteRound"
	var7 = tonumber(var6:GetAttribute(str2))
	local var10 = if var4 == nil or var4 ~= var4 then 0 else var4
	var4 = bool1
	if var4 then
		var4 = false
		if 0 < var10 then
			var4 = (if var7 == nil or var7 ~= var7 then 0 else var7) == var10
		end
	end

	var7 = bool1
	if var7 then
		var7 = not var4
		if var7 then
			var7 = not bool2
			if var7 then
				var7 = var8 < var9
			end
		end
	end

	if var4 or (not bool1) then
		bool2 = false
	end

	local var11 = var39
	str1 = ("Replay (%d/%d)"):format(var8, var9)
	if var11.Title then
		var11.Title.Text = str1
	end

	var27.Visible = bool1
	var11 = var39
	var11.Use.Active = var7
	var11.Use.Selectable = var7
	if not var7 then
		var11.Pressed = false
		if var11.Tween then
			var11.Tween:Cancel()
			var11.Tween = nil
		end

		var11.Scale.Scale = 1
	end
end

local function updateContinueButton()
	local str1 = "ContinueVotes"
	local var2 = tonumber(var28:GetAttribute(str1))
	local var3 = var28:GetAttribute("MatchState") == "ContinueVote"
	local str2 = "ContinueVotesRequired"
	local var5 = tonumber(var28:GetAttribute(str2))
	local var7 = math.max(math.floor(if var2 == nil or var2 ~= var2 then 0 else var2), 0)
	local var9 = var3
	local var10 = math.max(math.floor(if var5 == nil or var5 ~= var5 then 0 else var5), 0)
	if var9 then
		var9 = var6:GetAttribute("ContinueVoteRound") ~= nil
	end

	if var9 or (not var3) then
		bool3 = false
	end

	local var11 = var40
	var2 = ("Continue (%d/%d)"):format(var7, var10)
	if var11.Title then
		var11.Title.Text = var2
	end

	var40.Root.Visible = var3
	var5 = var3
	var2 = var40
	var5 = var5 and (not var9 and (not bool3))
	var2.Use.Active = var5
	var2.Use.Selectable = var5
	if not var5 then
		var2.Pressed = false
		if var2.Tween then
			var2.Tween:Cancel()
			var2.Tween = nil
		end

		var2.Scale.Scale = 1
	end
end

local function playIntro()
	local var2 = str2:FindFirstChildOfClass("UIScale")
	if not var2 then
		return
	end

	var2.Scale = 0.92
	var5:Create(var2, TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
end

var38.Use.Activated:Connect(function()
	if bool1 or (not var38.Use.Active) then
		return
	end

	if var28:GetAttribute("MatchState") == "ContinueVote" then
		bool4 = true
		bool1 = true
		local var1 = var38
		local var2 = not bool1
		var1.Use.Active = var2
		var1.Use.Selectable = var2
		if not var2 then
			var1.Pressed = false
			if var1.Tween then
				var1.Tween:Cancel()
				var1.Tween = nil
			end

			var1.Scale.Scale = 1
		end

		var1 = var38
		var2 = if bool1 then "Teleporting..." else "Lobby"
		if var1.Title then
			var1.Title.Text = var2
		end

		var32:FireServer(false)
		return
	end

	local var4 = var28:GetAttribute("Result")
	if var4 ~= "Win" and var4 ~= "Lose" then
		return
	end

	bool1 = true
	local var5 = var38
	local var6 = not bool1
	var5.Use.Active = var6
	var5.Use.Selectable = var6
	if not var6 then
		var5.Pressed = false
		if var5.Tween then
			var5.Tween:Cancel()
			var5.Tween = nil
		end

		var5.Scale.Scale = 1
	end

	var5 = var38
	var6 = if bool1 then "Teleporting..." else "Lobby"
	if var5.Title then
		var5.Title.Text = var6
	end

	var30:FireServer()
end)

var39.Use.Activated:Connect(function()
	if not var39.Use.Active or bool2 then
		return
	end

	bool2 = true
	updateReplayButton()
	var31:FireServer()
	task.delay(1.5, function()
		if bool2 then
			bool2 = false
			updateReplayButton()
		end
	end)
end)

var40.Use.Activated:Connect(function()
	if not var40.Use.Active or bool3 then
		return
	end

	bool3 = true
	updateContinueButton()
	var32:FireServer(true)
	task.delay(1.5, function()
		if bool3 then
			bool3 = false
			updateContinueButton()
		end
	end)
end)

var30.OnClientEvent:Connect(function()
	bool1 = false
	local var1 = var38
	local var2 = not bool1
	var1.Use.Active = var2
	var1.Use.Selectable = var2
	if not var2 then
		var1.Pressed = false
		if var1.Tween then
			var1.Tween:Cancel()
			var1.Tween = nil
		end

		var1.Scale.Scale = 1
	end

	var1 = var38
	var2 = if bool1 then "Teleporting..." else "Lobby"
	if var1.Title then
		var1.Title.Text = var2
	end
end)

local str5 = "MatchState"
local function refresh()
	local var3 = var28:GetAttribute("Result")
	local var4 = var28:GetAttribute("MatchState") == "ContinueVote"
	if var3 ~= "Win" and (var3 ~= "Lose" and (not var4)) then
		bool1 = false
		str2.Visible = false
		str1.Enabled = false
		bool5 = false
		clearRows()
		local var5 = var38
		local var6 = not bool1
		var5.Use.Active = var6
		var5.Use.Selectable = var6
		if not var6 then
			var5.Pressed = false
			if var5.Tween then
				var5.Tween:Cancel()
				var5.Tween = nil
			end

			var5.Scale.Scale = 1
		end

		var5 = var38
		var6 = if bool1 then "Teleporting..." else "Lobby"
		if var5.Title then
			var5.Title.Text = var6
		end

		return
	end

	local bool2 = true
	bool2 = var3 == "Win" or var4
	local var7 = buildContext
	var7 = var7(if var4 then "Win" else tostring(var3), bool2)
	renderHeader(var7, var4)
	renderRewards(var7)
	renderMultipliers(var7)
	local var8 = var38
	local var9 = not bool1
	var8.Use.Active = var9
	var8.Use.Selectable = var9
	if not var9 then
		var8.Pressed = false
		if var8.Tween then
			var8.Tween:Cancel()
			var8.Tween = nil
		end

		var8.Scale.Scale = 1
	end

	var8 = var38
	var9 = if bool1 then "Teleporting..." else "Lobby"
	if var8.Title then
		var8.Title.Text = var9
	end

	updateReplayButton()
	updateContinueButton()
	str1.Enabled = true
	str2.Visible = true
	if not bool5 then
		bool5 = true
		playIntro()
	end

	if bool4 and (var3 == "Win" or var3 == "Lose") then
		bool4 = false
		bool1 = true
		var8 = var38
		var9 = not bool1
		var8.Use.Active = var9
		var8.Use.Selectable = var9
		if not var9 then
			var8.Pressed = false
			if var8.Tween then
				var8.Tween:Cancel()
				var8.Tween = nil
			end

			var8.Scale.Scale = 1
		end

		var8 = var38
		var9 = if bool1 then "Teleporting..." else "Lobby"
		if var8.Title then
			var8.Title.Text = var9
		end

		var30:FireServer()
	end
end

for k2, v2 in {
	"Result",
	str5,
	"ElapsedSeconds",
	"MapId",
	"MapDisplayName",
	"MapMode",
	"IsEndless",
	"RewardCoins",
	"ReplayVotes",
	"ReplayVotesRequired",
	"ReplayVoteRound",
	"ContinueVotes",
	"ContinueVotesRequired",
}, nil do

	var28:GetAttributeChangedSignal(v2):Connect(refresh)
end

local str6 = "ContinueVoteRound"
for k3, v3 in {
	"MatchRewardCoins",
	"MatchBonusCoins",
	"MatchRewardFreeCrates",
	"MatchRewardTickets",
	"EndlessRewardTickets",
	"EndlessRewardFreeCrates",
	"EndlessRewardSummonDiscount",
	"MatchRewardXp",
	"MatchRewardConfetti",
	"MatchRewardLimitedUnit",
	"EndlessRewardXp",
	"MatchCoinMultiplier",
	"MatchRewardCoinMultiplier",
	"MatchXpMultiplier",
	"WinStreak",
	"MatchWinStreak",
	"ReplayVoteRound",
	str6,
}, nil do

	var6:GetAttributeChangedSignal(v3):Connect(refresh)
end

str2.Visible = false
str1.Enabled = false
clearRows()
bool1 = false
local var41 = not bool1
var38.Use.Active = var41
var38.Use.Selectable = var41
if not var41 then
	var38.Pressed = false
	if var38.Tween then
		var38.Tween:Cancel()
		var38.Tween = nil
	end

	var38.Scale.Scale = 1
end

var41 = if bool1 then "Teleporting..." else "Lobby"
if var38.Title then
	var38.Title.Text = var41
end

refresh()

--- Players.LocalPlayer.PlayerGui.Folder: GameUI.Boosts.BoostController [LocalScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "GlobalEventConfig"
local var2 = require(var1:WaitForChild("Shared"):WaitForChild(str1))
local var3 = game:GetService("Players").LocalPlayer
local var4 = script.Parent
local var5 = game:GetService("GuiService")
local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("Workspace")
str1 = Vector2.new(12, 12)
local var9 = var3:WaitForChild("PlayerGui")
local var10 = var4:WaitForChild("Frame")
var4.Enabled = true
var4.ResetOnSpawn = false
local var11 = var2.Attributes
local var12 = nil
for k1, v1 in var10:GetChildren() do
	if v1.Name ~= "Template" then
		continue
	end

	if not v1:IsA("Frame") then
		continue
	end

	if var12 == nil then
		var12 = v1
	else
		v1:Destroy()
	end
end

var12.Visible = false
local str2 = "MoneyBoost"
for k2, v2 in {
	"XPBoost",
	str2,
	"LuckBoost",
	"LuckEvent",
	"SummonDiscountBoost",
	"GlobalEvent",
	"FriendBoost",
}, nil do

	local var13 = var10:FindFirstChild(v2)
	if not var13 then
		continue
	end

	var13:Destroy()
end

local var15 = var9:FindFirstChild("_ForHovers")
local function isHoverGuiReady(arg1)
	if not arg1 or (not arg1:IsA("ScreenGui")) then
		return false
	end

	local var1 = arg1:FindFirstChild("Frame")
	local var2 = var1
	local var3 = var1
	var2 = var2 and var1:FindFirstChild("_TITLE")
	var3 = var3 and var1:FindFirstChild("Template")
	local bool2 = false
	if var1 ~= nil then
		bool2 = var1:IsA("Frame")
		if bool2 then
			bool2 = false
			if var2 ~= nil then
				bool2 = var2:IsA("TextLabel")
				if bool2 then
					bool2 = false
					if var3 ~= nil then
						bool2 = var3:IsA("TextLabel")
					end
				end
			end
		end
	end

	return bool2
end

local function createHoverGui()
	local var1 = Instance.new("ScreenGui")
	var1.Name = "_BottomUI"
	var1.Enabled = false
	var1.ResetOnSpawn = false
	var1.DisplayOrder = 999
	var1.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	local var2 = Instance.new("Frame")
	var2.Name = "Frame"
	var2.Size = UDim2.fromOffset(210, 82)
	var2.BackgroundColor3 = Color3.new(1, 1, 1)
	var2.BorderSizePixel = 0
	var2.Visible = false
	var2.Parent = var1
	local var3 = Instance.new("UICorner")
	var3.CornerRadius = UDim.new(0, 9)
	var3.Parent = var2
	local var4 = Instance.new("UIStroke")
	var4.Color = Color3.fromRGB(65, 65, 65)
	var4.Thickness = 2
	var4.Parent = var2
	local str1 = "_TITLE"
	local str2 = "Template"
	for k1, v1 in { str1, str2 }, nil do
		local var5 = Instance.new("TextLabel")
		var5.Name = v1
		var5.BackgroundTransparency = 1
		local var6 = UDim2.new
		local num1 = 0
		local num2 = 10
		local num3 = 0
		var5.Position = var6(num1, num2, num3, if k1 == 1 then 9 else 44)
		var5.Size = UDim2.new(1, -20, 0, 27)
		var5.FontFace = Font.new("rbxasset://fonts/families/FredokaOne.json")
		var5.Text = ""
		var5.TextColor3 = Color3.new(1, 1, 1)
		var5.TextScaled = true
		var5.TextWrapped = true
		var5.Parent = var2
		var6 = Instance.new("UIStroke")
		var6.Color = Color3.fromRGB(35, 35, 35)
		var6.Thickness = 2
		var6.Parent = var5
	end

	return var1
end

if not var15 then
	var15 = Instance.new("Folder")
	var15.Name = "_ForHovers"
	var15.Parent = var9
end

local var16 = var15:FindFirstChild("_BottomUI")
if not isHoverGuiReady(var16) then
	local var19 = game:GetService("StarterGui"):FindFirstChild("_ForHovers")
	local var20 = var19
	var20 = var20 and var19:FindFirstChild("_BottomUI")
	local var21 = if isHoverGuiReady(var20) then var20:Clone() else createHoverGui()
	var21.Enabled = false
	var21.ResetOnSpawn = false
	var21.Frame.Visible = false
	if var16 then
		var16:Destroy()
	end

	var21.Parent = var15
	var16 = var21
end

local var22 = var16.Frame
var16.ResetOnSpawn = false
var16.Enabled = false
var22.Visible = false
var22.AnchorPoint = Vector2.zero
local var23 = nil
local tbl1 = {}
local var24 = var22._TITLE
local var25 = var22.Template
local function updateHoverPosition()
	if not var23 or (not var16 or (not var22 or (not var16.Enabled))) then
		return
	end

	local var1 = tbl1[var23.Name]
	while var1 do
		if var1 == var9 then
			break
		end

		if var1:IsA("GuiObject") and (not var1.Visible) or var1:IsA("ScreenGui") and (not var1.Enabled) then
			var23 = nil
			if var16 and var22 then
				var22.Visible = false
				var16.Enabled = false
			end

			return
		end

		var1 = var1.Parent
	end

	local var2 = var7:GetMouseLocation()
	if not var16.IgnoreGuiInset then
		var2 = var2 - var5:GetGuiInset()
	end

	local var3 = var8.CurrentCamera
	local var10 = var3 and var3.ViewportSize or Vector2.new(1920, 1080)
	if not var16.IgnoreGuiInset then
		local var11, var12 = var5:GetGuiInset()
		var10 = var10 - (var11 + var12)
	end

	local var13 = var22.AbsoluteSize
	local var14 = var2.X + str1.X
	local var15 = var2.Y + str1.Y
	if var10.X < var14 + var13.X + 8 then
		var14 = var2.X - var13.X - str1.X
	end

	if var10.Y < var15 + var13.Y + 8 then
		var15 = var2.Y - var13.Y - str1.Y
	end

	var22.Position = UDim2.fromOffset(math.clamp(var14, 8, (math.max(8, var10.X - var13.X - 8))), (math.clamp(var15, 8, (math.max(8, var10.Y - var13.Y - 8)))))
end

local tbl2 = {
	{
		Name = "XPBoost",
		Title = "Double XP",
		Description = "x2 XP",
		Icon = "rbxassetid://89533088608490",
		LayoutOrder = 8,
		GetRemaining = function()
			local str1 = "XPBoostTimeRemaining"
			return tonumber(var3:GetAttribute(str1)) or 0
		end,
	},
	{
		Name = "FriendBoost",
		Title = "Friend Boost",
		Description = "+10% Coins per friend",
		Icon = "rbxassetid://137253247460032",
		LayoutOrder = 0,
		GetRemaining = function()
			local str1 = "FriendsInMatch"
			return tonumber(var3:GetAttribute(str1)) or 0
		end,
		GetTimer = function()
			local str1 = "FriendCoinMultiplier"
			local var1 = math.round(((tonumber(var3:GetAttribute(str1)) or 1) - 1) * 100)
			return ("+%d%%"):format(var1)
		end,
	},
	{
		Name = "MoneyBoost",
		Title = "Coin Potion",
		Description = "x2 Coins",
		Icon = "rbxassetid://84869454803634",
		LayoutOrder = 1,
		GetRemaining = function()
			local str1 = "MoneyBoostTimeRemaining"
			return tonumber(var3:GetAttribute(str1)) or 0
		end,
	},
	{
		Name = "LuckBoost",
		Title = "Luck Potion",
		Description = "x2 Luck",
		Icon = "rbxassetid://139042882458711",
		LayoutOrder = 2,
		GetRemaining = function()
			local str1 = "LuckBoostTimeRemaining"
			return tonumber(var3:GetAttribute(str1)) or 0
		end,
	},
	{
		Name = "LuckEvent",
		Title = "Luck Event",
		Description = "Global Luck",
		LayoutOrder = 3,
		GetEndsAt = function()
			local str1 = "GlobalLuckEndsAt"
			return tonumber(var1:GetAttribute(str1)) or 0
		end,
		GetIcon = function()
			local str1 = "GlobalLuckMultiplier"
			local var3 = math.max(1, tonumber(var1:GetAttribute(str1)) or 1)
			if 8 <= var3 then
				return "rbxassetid://75663448431778"
			end

			if 4 <= var3 then
				return "rbxassetid://131505096627086"
			end

			return "rbxassetid://78824015618357"
		end,
		GetDescription = function()
			local str1 = "GlobalLuckMultiplier"
			return "x" .. tostring((math.max(1, tonumber(var1:GetAttribute(str1)) or 1))) .. " Global Luck"
		end,
		IsEnabled = function()
			local str1 = "GlobalLuckMultiplier"
			return 1 < (tonumber(var1:GetAttribute(str1)) or 1)
		end,
	},
	{
		Name = "GlobalEvent",
		Title = "Global Event",
		Description = "Global Event",
		LayoutOrder = 0,
		GetEndsAt = function()
			local var2 = var11.ActiveEndsAt
			return tonumber(var1:GetAttribute(var2)) or 0
		end,
		GetIcon = function()
			local var3 = var11.ActiveId
			local var5 = var2.GetById(var1:GetAttribute(var3))
			if var5 then
				return var5.Icon
			end

			return ""
		end,
		GetTitle = function()
			local var3 = var11.ActiveId
			local var5 = var2.GetById(var1:GetAttribute(var3))
			if var5 then
				return var5.HoverTitle
			end

			return "Global Event"
		end,
		GetDescription = function()
			local var3 = var11.ActiveId
			local var5 = var2.GetById(var1:GetAttribute(var3))
			if var5 then
				return var5.HoverText
			end

			return "Global Event"
		end,
		IsEnabled = function()
			if not var2.Enabled then
				return false
			end

			local var3 = var11.ActiveId
			return var2.GetById(var1:GetAttribute(var3)) ~= nil
		end,
	},
}

local function formatTimer(arg1)
	local var1 = math.max(0, (math.ceil(arg1)))
	local var7 = math.floor(var1 / 3600)
	local var8 = math.floor(var1 % 3600 / 60)
	if 0 < var7 then
		local str2 = "%02d:%02d:%02d"
		local var9 = var7
		local var10 = var8
		local var11 = var1 % 60
		return string.format(str2, var9, var10, var11)
	end

	local str3 = "%02d:%02d"
	local var12 = var8
	local var13 = var1 % 60
	return string.format(str3, var12, var13)
end

local function showHover(arg1)
	local var2 = tbl1[arg1.Name]
	if not var2 or (not var2.Visible or (not var16 or (not var22))) then
		return
	end

	var23 = arg1
	local var3 = var24
	local var4 = if arg1.GetTitle then arg1.GetTitle() else arg1.Title
	var3.Text = var4
	var3 = var25
	var4 = if arg1.GetDescription then arg1.GetDescription() else arg1.Description
	var3.Text = var4
	var16.Enabled = true
	var22.Visible = true
	updateHoverPosition()
end

for k3, v3 in tbl2, nil do
	local var26 = var12:Clone()
	var26.Name = v3.Name
	var26.LayoutOrder = v3.LayoutOrder
	var26.Visible = false
	var26.Active = true
	var26.Parent = var10
	local var27 = var26:WaitForChild("Icon")
	var27.Image = v3.Icon or ""
	if v3.Name == "FriendBoost" then
		var26.InputBegan:Connect(function(arg1)
			if arg1.UserInputType == Enum.UserInputType.Touch then
				if var23 == v3 then
					var23 = nil
					if not (var16 and var22) then
						return
					end

					if not var22 then
						return
					end

					var22.Visible = false
					var16.Enabled = false
					return
				end

				showHover(v3)
			end
		end)

	end

	tbl1[v3.Name] = var26
	var26.MouseEnter:Connect(function()
		showHover(v3)
	end)

	var26.MouseLeave:Connect(function()
		if var23 == v3 then
			var23 = nil
			if var16 and var22 then
				var22.Visible = false
				var16.Enabled = false
			end
		end
	end)

	var26.SelectionGained:Connect(function()
		showHover(v3)
	end)

	var26.SelectionLost:Connect(function()
		if var23 == v3 then
			var23 = nil
			if var16 and var22 then
				var22.Visible = false
				var16.Enabled = false
			end
		end
	end)

end

var6.RenderStepped:Connect(updateHoverPosition)
local function refresh()
	local var1 = var8:GetServerTimeNow()
	for k1, v1 in tbl2, nil do
		local var2 = tbl1[v1.Name]
		local var4 = if v1.GetRemaining then math.max(0, v1.GetRemaining()) else math.max(0, v1.GetEndsAt() - var1)
		local bool2 = false
		if 0 < var4 then
			bool2 = not v1.IsEnabled
			bool2 = bool2 or v1.IsEnabled()
		end

		var2.Visible = bool2
		if bool2 then
			local var5 = var2.Timer
			local var6 = if v1.GetTimer then v1.GetTimer() else formatTimer(var4)
			var5.Text = var6
			var5 = var2.Icon
			var6 = if v1.GetIcon then v1.GetIcon() else v1.Icon
			var5.Image = var6
		else
			var2.Timer.Text = "00:00"
			if var23 ~= v1 then
				continue
			end

			var23 = nil
			if not var16 or (not var22) then
				continue
			end

			var22.Visible = false
			var16.Enabled = false
		end
	end

	if var23 then
		if var25 then
			local var7 = var25
			local var9 = if var23.GetDescription then var23.GetDescription() else var23.Description
			var7.Text = var9
			if var23.GetTitle then
				var24.Text = var23.GetTitle()
			end
		end
	end
end

var3:GetAttributeChangedSignal("FriendsInMatch"):Connect(refresh)
var3:GetAttributeChangedSignal("FriendCoinMultiplier"):Connect(refresh)
var3:GetAttributeChangedSignal("MoneyBoostTimeRemaining"):Connect(refresh)
var3:GetAttributeChangedSignal("XPBoostTimeRemaining"):Connect(refresh)
var3:GetAttributeChangedSignal("LuckBoostTimeRemaining"):Connect(refresh)
var1:GetAttributeChangedSignal("GlobalLuckMultiplier"):Connect(refresh)
var1:GetAttributeChangedSignal("GlobalLuckEndsAt"):Connect(refresh)
var1:GetAttributeChangedSignal(var11.ActiveId):Connect(refresh)
var1:GetAttributeChangedSignal(var11.ActiveEndsAt):Connect(refresh)
refresh()
task.spawn(function()
	while script.Parent do
		refresh()
		task.wait(0.25)
	end
end)

--- Players.LocalPlayer.PlayerGui.Folder: GameUI.UnitManager.UnitManagerController [LocalScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = script.Parent
local var3 = var2:WaitForChild("Frame")
local var4 = var3:WaitForChild("MainList"):WaitForChild("ListUnits")
local var5 = game:GetService("ReplicatedStorage")
local var6 = var5:WaitForChild("RemoteFunctions")
local var7 = var5:WaitForChild("Modules")
local var8 = var7:FindFirstChild("TowerConfig")
local str1 = "TowerBoosterConfig"
local var9 = require(var7:WaitForChild(str1))
local var10 = var1:WaitForChild("PlayerGui")
local var11 = nil
task.spawn(function()
	local var2 = var10:WaitForChild("TowerUpgradedLocal", 30)
	if var2 and var2:IsA("BindableEvent") then
		var11 = var2
	end
end)

local var12 = game:GetService("TweenService")
local function attachHover(arg1, arg2)
	if not arg1 or (not arg1:IsA("GuiObject")) then
		return
	end

	if not arg2 or (not arg2:IsA("GuiButton")) then
		return
	end

	local var2 = arg1:FindFirstChildOfClass("UIScale")
	if not var2 then
		var2 = Instance.new("UIScale")
		var2.Name = "UIScale"
		var2.Parent = arg1
	end

	local var3 = 0 < var2.Scale and var2.Scale or 1
	local bool1 = false
	local bool2 = false
	local var4 = nil
	local function apply()
		local var5 = var3
		if bool1 then
			var5 = var3 * 0.98
		else
			if bool2 then
				var5 = var3 * 1.03
			end
		end

		if var4 then
			var4:Cancel()
			var4 = nil
		end

		local var6 = TweenInfo.new(if var3 < var5 then 0.12 else 0.09, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var4 = var12:Create(var2, var6, { Scale = var5 })
		var4:Play()
	end

	arg2.MouseEnter:Connect(function()
		bool2 = true
		apply()
	end)

	arg2.MouseLeave:Connect(function()
		bool2 = false
		bool1 = false
		apply()
	end)

	arg2.MouseButton1Down:Connect(function()
		bool1 = true
		apply()
	end)

	arg2.MouseButton1Up:Connect(function()
		bool1 = false
		apply()
	end)

	arg2.SelectionGained:Connect(function()
		bool2 = true
		apply()
	end)

	arg2.SelectionLost:Connect(function()
		bool2 = false
		bool1 = false
		apply()
	end)
end

local var14 = var3:FindFirstChildOfClass("UIScale")
local var15 = var4:WaitForChild("Template")
local var16 = var3:WaitForChild("Close")
local var17 = var6:WaitForChild("UpgradeTower")
local var18 = var6:WaitForChild("SellTower")
local var19 = require(var8 or var7:WaitForChild("TowerUnitConfig"))
local var20 = workspace:WaitForChild("Towers")
local function getTowerOwner(arg1)
	local var1 = arg1:GetAttribute("Owner")
	if type(var1) == "string" then
		return var1
	end

	local var2 = arg1:FindFirstChild("Configuration")
	var2 = var2 or arg1:FindFirstChild("Config")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Owner")
	if var3 and var3:IsA("StringValue") then
		return var3.Value
	end

	return nil
end

local function getPlayerCash()
	local str1 = "Stats"
	for k1, v1 in ipairs({ "leaderstats", str1 }) do
		local var2 = var1:FindFirstChild(v1)
		local var3 = var2
		var3 = var3 and var2:FindFirstChild("Cash")
		if not var3 then
			continue
		end

		if not var3:IsA("ValueBase") then
			continue
		end

		return tonumber(var3.Value) or 0
	end

	local var5 = var1:FindFirstChild("Cash")
	if var5 and var5:IsA("ValueBase") then
		return tonumber(var5.Value) or 0
	end

	return 0
end

local function attachHoverToAll(arg1)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("GuiButton") then
			continue
		end

		if v1.Name ~= "Use" then
			continue
		end

		local var1 = v1.Parent
		if not var1 then
			continue
		end

		if not var1:IsA("GuiObject") then
			continue
		end

		attachHover(var1, v1)
	end
end

local bool1 = false
if not var14 then
	var14 = Instance.new("UIScale")
	var14.Name = "UIScale"
	var14.Parent = var3
end

local var21 = nil
var15.Visible = false
local tbl1 = {}
local function fillCard(arg1)
	local var1 = arg1.Tower
	local var2 = arg1.Frame
	if not var1.Parent then
		return
	end

	local var3 = var19.getStats(var1.Name, var1)
	local var6 = var2:FindFirstChild("UnitInfo")
	local var7 = math.max(tonumber(var3.Level) or 1, 1)
	local var8 = var19.getNextStats(var19.getUnitId(var1), var3.Level)
	local var10, var11, var12 = var9.applyToStats(var1, tonumber(var3.Damage) or 0, tonumber(var3.Range) or 0, tonumber(var3.Cooldown) or 1)
	if var6 then
		local var13 = var1.Name
		if not var6 then
		else
			local var15 = var6:FindFirstChild("TowerName", true)
			if var15 and (var15:IsA("TextLabel") or var15:IsA("TextButton")) then
				var15.Text = var13
			end
		end

		var13 = if var8 == nil then ("Lv. %* (MAX)"):format(var7) else ("Lv. %*"):format(var7)
		if not var6 then
		else
			local var17 = var6:FindFirstChild("lvl", true)
			if var17 and (var17:IsA("TextLabel") or var17:IsA("TextButton")) then
				var17.Text = var13
			end
		end

		local var18 = var5:FindFirstChild("WaveState")
		local var20 = var18
		local var22 = tonumber(var20 and var18:GetAttribute("GameSpeed"))
		local var23 = string.format("%.1f", math.max(0, tonumber(var10) or 0) / math.max(0.01, (tonumber(var12) or 1) / (if not var22 or (var22 ~= var22 or (var22 <= 0 or var22 == math.huge)) then 1 else var22)))
		local str1 = "DPS: "
	if not not var23:find("%.") then
			var23 = var23:gsub("0+$", ""):gsub("%.$", "")
		end

		var20 = str1 .. var23
		if not var6 then
		else
			str1 = var6:FindFirstChild("DPS", true)
			if str1 and (str1:IsA("TextLabel") or str1:IsA("TextButton")) then
				str1.Text = var20
			end
		end

		var20 = var6:FindFirstChild("TowerIcon", true)
		if var20 and (var20:IsA("ImageLabel") or var20:IsA("ImageButton")) then
			var20.Image = var3.Icon or ""
		end
	end

	local var25 = var2:FindFirstChild("Selector")
	if not var25 then
		return
	end

	local var28 = var8 ~= nil
	local var29 = var25:FindFirstChild("Upgrade")
	local var30 = var25:FindFirstChild("UpgradeMax")
	local var31 = var25:FindFirstChild("Sell")
	local var32 = tonumber(var3.UpgradePrice)
	if var28 then
		var28 = var32 ~= nil
	end

	if var29 and var29:IsA("GuiObject") then
		var29.Visible = var28
		if var28 then
			local var33 = tostring((math.floor(var32)))
			if not var29 then
			else
				local var35 = var29:FindFirstChild("price", true)
				if var35 and (var35:IsA("TextLabel") or var35:IsA("TextButton")) then
					var35.Text = var33
				end
			end

			if not var29 then
			else
				var33 = var29:FindFirstChild("Amount", true)
				if var33 and (var33:IsA("TextLabel") or var33:IsA("TextButton")) then
					var33.Text = "Upgrade:"
				end
			end

			local var37 = var29:FindFirstChild("Move")
			var33 = var32 <= getPlayerCash()
			if var37 then
				for k1, v1 in ipairs(var37:GetDescendants()) do
					if not v1:IsA("UIGradient") then
						continue
					end

					if v1.Name == "Buy" then
						v1.Enabled = var33
					else
						if v1.Name ~= "NoBuy" then
							continue
						end

						v1.Enabled = not var33
					end
				end
			end
		end
	end

	if var30 and var30:IsA("GuiObject") then
		var30.Visible = not var28
		if not var30 then
		else
			local var39 = var30:FindFirstChild("Amount", true)
			if var39 and (var39:IsA("TextLabel") or var39:IsA("TextButton")) then
				var39.Text = "Max"
			end
		end
	end

	if var31 then
		if var31:IsA("GuiObject") then
			if not var31 then
			else
				local var41 = var31:FindFirstChild("_TITLE", true)
				if var41 and (var41:IsA("TextLabel") or var41:IsA("TextButton")) then
					var41.Text = "Sell:"
				end
			end

			local var42 = tostring(var1:GetAttribute("SellPrice") or 0)
			if not var31 then
				return
			end

			local var44 = var31:FindFirstChild("amount", true)
			if var44 and (var44:IsA("TextLabel") or var44:IsA("TextButton")) then
				var44.Text = var42
			end
		end
	end
end

local num1 = 0
local function bindCardButtons(arg1)
	local var2 = arg1.Frame
	local var4 = var2:FindFirstChild("Selector")
	if not var4 then
		return
	end

	local var5 = var4:FindFirstChild("Upgrade")
	local var6 = var5
	var5 = var6 and var5:FindFirstChild("Use", true)
	var6 = var4:FindFirstChild("Sell")
	local var7 = var6
	var6 = var7 and var6:FindFirstChild("Use", true)
	if var5 and var5:IsA("GuiButton") then
		var5.Activated:Connect(function()
			if arg1.UpgradeInFlight then
				return
			end

			local var2 = arg1.Tower
			if not var2.Parent or getTowerOwner(var2) ~= var1.Name then
				return
			end

			arg1.UpgradeInFlight = true
			local success, result, var3 = pcall(function()
				local var1 = var2
				return var17:InvokeServer(var1)
			end)

			arg1.UpgradeInFlight = false
			if success and (result and (typeof(var3) == "Instance" and var3:IsA("Model"))) then
				tbl1[arg1.Tower] = nil
				arg1.Tower = var3
				tbl1[var3] = arg1
			end

			if success and (result and var11) then
				var11:Fire(var2, arg1.Tower)
			end

			if arg1.Tower.Parent then
				fillCard(arg1)
			end
		end)

	end

	if var6 and var6:IsA("GuiButton") then
		var6.Activated:Connect(function()
			if arg1.SellInFlight then
				return
			end

			local var2 = arg1.Tower
			if not var2.Parent or getTowerOwner(var2) ~= var1.Name then
				return
			end

			arg1.SellInFlight = true
			pcall(function()
				local var1 = var2
				return var18:InvokeServer(var1)
			end)

			arg1.SellInFlight = false
		end)

	end

	attachHoverToAll(var2)
end

local function createCard(arg1)
	local var1 = num1 + 1
	num1 = var1
	var1 = var15:Clone()
	var1.Name = "Unit_" .. num1
	var1.Visible = true
	var1.Parent = var4
	local tbl2 = { Frame = var1, Tower = arg1, UpgradeInFlight = false, SellInFlight = false }
	tbl1[arg1] = tbl2
	bindCardButtons(tbl2)
	fillCard(tbl2)
	return tbl2
end

local var22 = var16:FindFirstChild("Move")
local var23 = var22
var23 = var23 and var22:FindFirstChild("Use", true)
local function fn10(arg1)
	bool1 = arg1
	if var21 then
		var21:Cancel()
		var21 = nil
	end

	if arg1 then
		var3.Visible = true
		var14.Scale = 0.85
		var21 = var12:Create(var14, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 })
		var21:Play()
		return
	end

	var21 = var12:Create(var14, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Scale = 0 })
	local var1 = var21
	var1.Completed:Connect(function()
		if not bool1 then
			var3.Visible = false
		end
	end)

	var1:Play()
end

local function refreshList()
	local tbl2 = {}
	for k1, v1 in ipairs(var20:GetChildren()) do
		local var2
		if not v1:IsA("Model") then
			var2 = false
		else
			var2 = getTowerOwner(v1) == var1.Name
		end

		if not var2 then
			continue
		end

		tbl2[v1] = true
		if tbl1[v1] then
			continue
		end

		createCard(v1)
	end

	for k2, v2 in pairs(tbl1) do
		if tbl2[k2] then
			if not k2.Parent then
				var2 = tbl1[k2]
	if not not var2 then
					tbl1[k2] = nil
					var2.Frame:Destroy()
					continue
				end
			else
				fillCard(v2)
			end
		end
	end
end

if var23 and var23:IsA("GuiButton") then
	var23.Activated:Connect(function()
		fn10(false)
	end)

end

attachHoverToAll(var16)
var22 = function(arg1)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("GuiObject") then
			continue
		end

		if v1.Name ~= "UnitManager" then
			continue
		end

		local var1 = v1:FindFirstChild("Move")
		local var2 = var1
		if not var1 then
			continue
		end

		var2 = var2 and var1:FindFirstChild("Use")
		if not var1:IsA("GuiObject") or (not var2) then
			continue
		end

		if not var2:IsA("GuiButton") then
			continue
		end

		return var1, var2
	end

	return nil, nil
end

task.spawn(function()
	local var2 = var10:WaitForChild("MainGameUI", 30)
	if not var2 then
		return
	end

	local var3 = nil
	local var4 = nil
	local var5 = os.clock() + 30
	repeat
		local var6, var7 = var22(var2)
		var4 = var7
		if var4 then
			break
		end

		var3 = var6
		task.wait(0.25)
	until var5 <= os.clock()

	if not var4 then
		return
	end

	attachHover(var3, var4)
	var4.Activated:Connect(function()
		fn10(not bool1)
		if bool1 then
			refreshList()
		end
	end)
end)

var2.ResetOnSpawn = false
var2.Enabled = true
var3.Visible = false
var14.Scale = 0
if var4:IsA("ScrollingFrame") then
	var4.CanvasSize = UDim2.new()
	var4.AutomaticCanvasSize = Enum.AutomaticSize.Y
end

var20.ChildAdded:Connect(function(arg1)
	if not bool1 then
		return
	end

	task.wait(0.1)
	local var2
	if not arg1:IsA("Model") then
		var2 = false
	else
		var2 = getTowerOwner(arg1) == var1.Name
	end

	if var2 and (not tbl1[arg1]) then
		createCard(arg1)
	end
end)

var20.ChildRemoved:Connect(function(arg1)
	if arg1:IsA("Model") then
		local var2 = tbl1[arg1]
		if not var2 then
			return
		end

		tbl1[arg1] = nil
		var2.Frame:Destroy()
	end
end)

task.spawn(function()
	while true do
		if not var2.Parent then
			break
		end

		if bool1 then
			refreshList()
		end

		task.wait(0.25)
	end
end)

--- Players.LocalPlayer.PlayerGui.EndlessEarned.EndlessEarnedController [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = game:GetService("ReplicatedStorage")
local var3 = game:GetService("Players").LocalPlayer
local var4 = var1:WaitForChild("Currency")
var4.Visible = false
var1.ResetOnSpawn = false
var1.Parent = var3:WaitForChild("PlayerGui")
local var6 = var4:FindFirstChildOfClass("UIAspectRatioConstraint")
local var7 = var4:WaitForChild("Template")
local var8 = var4:WaitForChild("Title")
local var9 = var4:WaitForChild("UIListLayout")
local var10 = if var6 then var6.AspectRatio else 3.823758
if var6 then
	var6:Destroy()
end

var4.AutomaticSize = Enum.AutomaticSize.None
var9.VerticalFlex = Enum.UIFlexAlignment.None
local tbl1 = {}
for k1, v1 in ipairs(var4:GetChildren()) do
	if not v1:IsA("Frame") then
		continue
	end

	if v1.Name ~= "PLOT_!" then
		continue
	end

	table.insert(tbl1, v1)
end

local var11 = var2:WaitForChild("WaveState")
local tbl2 = {
	{ Id = "Coins", Attribute = "MatchBonusCoins", Icon = "rbxassetid://74516079442282" },
	{
		Id = "Tickets",
		Attribute = "EndlessRewardTickets",
		Icon = "rbxassetid://80410844802074",
	},
	{
		Id = "FreeCrates",
		Attribute = "EndlessRewardFreeCrates",
		Icon = "rbxassetid://115975950061415",
	},
	{
		Id = "SummonDiscount",
		Attribute = "EndlessRewardSummonDiscount",
		Icon = "rbxassetid://97393457754585",
	},
}

for k2, v2 in ipairs(var4:GetChildren()) do
	local var12 = v2:GetAttribute("EndlessRewardRow")
	if var12 ~= true then
		continue
	end

	v2:Destroy()
end

local tbl3 = {}
for k3, v3 in ipairs(tbl2) do
	local var14 = if k3 == 1 then var7 else var7:Clone()
	local var15
	if var14 ~= var7 then
		var14.Name = v3.Id
		var15 = true
		var14:SetAttribute("EndlessRewardRow", var15)
	end

	var14.LayoutOrder = k3 - 1
	local var16 = var14:WaitForChild("IconCurrency")
	var16.Image = v3.Icon
	var16 = var14:WaitForChild("Amount")
	var16.Text = "0"
	var14.Visible = k3 == 1
	var14.Parent = var4
	tbl3[v3.Id] = var14
end

local num1 = -1
local num2 = -1
local function resizePanel()
	local var1 = var4.AbsoluteSize.X
	local num3 = 0
	for k1, v1 in pairs(tbl3) do
		if not v1.Visible then
			continue
		end

		num3 = num3 + 1
	end

	if var1 <= 0 or var1 == num1 and num3 == num2 then
		return
	end

	num1 = var1
	num2 = num3
	local var2 = var1 / math.max(1, var10)
	local var3 = var2 * 0.56394
	local num4 = 0
	var8.Size = UDim2.new(1, 0, num4, var3)
	local var5 = var2 * 0.095
	local var6 = var2 * 0.005
	for k2, v2 in pairs(tbl3) do
		v2.Size = UDim2.new(1, 0, 0, var2)
	end

	for k3, v3 in ipairs(tbl1) do
		v3.Size = UDim2.new(1, 0, 0, var6)
	end

	var9.Padding = UDim.new(0, var5)
	var4.Size = UDim2.new(var4.Size.X.Scale, var4.Size.X.Offset, 0, (math.ceil(var3 + num3 * var2 + #tbl1 * var6 + (num3 + #tbl1) * var5)))
end

var4:GetPropertyChangedSignal("AbsoluteSize"):Connect(resizePanel)
local function update()
	local str1 = "IsEndless"
	local var1 = var4
	local bool1 = false
	if var11:GetAttribute(str1) == true then
		str1 = "MatchState"
		bool1 = var11:GetAttribute(str1) ~= "Finished"
	end

	var1.Visible = bool1
	for k1, v1 in ipairs(tbl2) do
		local var2 = var3:GetAttribute(v1.Attribute)
		local var5 = tbl3[v1.Id]
		local var6 = if typeof(var2) ~= "number" or (var2 ~= var2 or math.abs(var2) == math.huge) then 0 else math.max(0, (math.floor(var2)))
		var5.Amount.Text = tostring(var6)
		var2 = true
		if v1.Id ~= "Coins" then
			var2 = 0 < var6
		end

		var5.Visible = var2
	end

	resizePanel()
end

var11:GetAttributeChangedSignal("IsEndless"):Connect(update)
var11:GetAttributeChangedSignal("MatchState"):Connect(update)
for k4, v4 in ipairs(tbl2) do
	var3:GetAttributeChangedSignal(v4.Attribute):Connect(update)
end

update()

--- ReplicatedStorage.Template [ModuleScript]
-- y u r i

local function DeepFreeze(arg1)
	if type(arg1) ~= "table" then
		return
	end

	for k1, v1 in pairs(arg1) do
		DeepFreeze(v1)
	end

	table.freeze(arg1)
	return arg1
end

local tbl1 = { DEFAULT_PLAYER_DATA = {
	EventTokens = 0,
	PlayingBefore = false,
	Tutorial = {
		Initialized = false,
		Step = 0,
		Progress = 0,
		Skipped = false,
		Completed = false,
		PendingLobbyCompletion = false,
	},
	LastLog = false,
	Wins = 0,
	WinStreak = 0,
	EndlessBestWave = 0,
	Lose = 0,
	Inventory = { Troops = {}, Items = { Crates = {}, FreeCrates = {} }, Slots = { {}, {}, {}, {}, {} } },
	Index = { SchemaVersion = 1, Units = {}, Crates = {}, Boosts = {}, ClaimedMilestones = 0 },
	ForeverPack = { SchemaVersion = 1, CycleId = 0, Claimed = 0 },
	SignLog = { Used = 0, ResetAt = 0 },
	GroupReward = { ClaimedBefore = false, ResetAt = 0 },
	VIPChest = { ClaimedBefore = false, ResetAt = 0 },
	Quests = { SchemaVersion = 1, ResetAt = 0, CycleId = "", Revision = 0, Slots = {} },
	GlobalQuests = { ClaimedCycles = {} },
	SeasonPass = {
		SchemaVersion = 1,
		SeasonId = "",
		XP = 0,
		Premium = false,
		SkipTiers = 0,
		ClaimedFree = {},
		ClaimedPremium = {},
	},
	Boosts = {
		MoneyTimeRemaining = 0,
		LuckTimeRemaining = 0,
		MoneyEndsAt = 0,
		LuckEndsAt = 0,
		Inventory = { Money = 0, Luck = 0 },
	},
	Currency = { Coins = 100, Tickets = 0 },
	SummonPity = { Legendary = 0, Mythic = 0 },
	SummonAutoSell = {
		Basic = false,
		Uncommon = false,
		Rare = false,
		Epic = false,
		Legendary = false,
		Mythic = false,
	},
	Options = { Notification = true, Trading = true, Music = true },
	Shop = {
		Gamepasses = { x2Coins = false, x2Luck = false, GoldenBat = false, VIP = false },
		PendingGoldenBatGift = {},
		GoldenBatGiftCredits = {},
		RedeemedCodes = {},
		ProcessedReceipts = {},
	},
	PlayerInfo = {
		FirstJoinUnix = 0,
		FirstJoinKnown = false,
		FirstJoinPending = false,
		AllTimeSeconds = 0,
		DailyDayKey = 0,
		DailySeconds = 0,
	},
} }

DeepFreeze(tbl1.DEFAULT_PLAYER_DATA)
return tbl1

--- ReplicatedStorage.Shared.PathMath [ModuleScript]
-- y u r i

local tbl1 = { Lerp = function(arg1, arg2, arg3)
	return arg1 + (arg2 - arg1) * arg3
end }

tbl1.QuadBezier = function(arg1, arg2, arg3, arg4)
	local var1 = tbl1.Lerp(arg1, arg2, arg4)
	local var2 = tbl1.Lerp(arg2, arg3, arg4)
	local var3 = arg4
	return tbl1.Lerp(var1, var2, var3)
end

tbl1.QuadBezierDerivative = function(arg1, arg2, arg3, arg4)
	return (arg2 - arg1) * (2 * (1 - arg4)) + (arg3 - arg2) * (2 * arg4)
end

tbl1.GetSortedWaypoints = function(arg1)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		table.insert(tbl1, v1)
	end

	table.sort(tbl1, function(arg1, arg2)
		local var3 = tonumber(arg1.Name)
		local var4 = tonumber(arg2.Name)
		if var3 then
			if var4 then
				return var3 < var4
			end
		end

		if var3 then
			return true
		end

		if var4 then
			return false
		end

		return arg1.Name < arg2.Name
	end)

	return tbl1
end

tbl1.PlanarUnit = function(arg1, arg2)
	local var1 = Vector3.new(arg1.X, 0, arg1.Z)
	if 0.001 < var1.Magnitude then
		return var1.Unit
	end

	local var2 = Vector3.new(arg2.X, 0, arg2.Z)
	if arg2 and 0.001 < var2.Magnitude then
		return var2.Unit
	end

	return Vector3.new(0, 0, -1)
end

tbl1.SideVector = function(arg1, arg2)
	local var1 = tbl1.PlanarUnit(arg1, arg2)
	return (Vector3.new(-var1.Z, 0, var1.X))
end

tbl1.ApplyOffsets = function(arg1, arg2, arg3, arg4, arg5)
	return arg1 + Vector3.new(0, arg3, 0) + tbl1.SideVector(arg2, arg5) * arg4
end

tbl1.BuildCurveLookup = function(arg1, arg2, arg3, arg4)
	local var1 = math.max(arg4 or 48, 4)
	local tbl2 = { { T = 0, Length = 0 } }
	local num1 = 0
	local var2 = arg1
	for i1 = 1, var1 do
		local var3 = i1 / var1
		local var4 = tbl1.QuadBezier(arg1, arg2, arg3, var3)
		num1 = num1 + (var4 - var2).Magnitude
		table.insert(tbl2, { T = var3, Length = num1 })
		local var5 = var4
	end

	return tbl2, num1
end

tbl1.CurveDistanceToT = function(arg1, arg2, arg3)
	if arg2 <= 0 then
		return 0
	end

	if arg3 <= arg2 then
		return 1
	end

	for i1 = 2, #arg1 do
		local var1 = arg1[i1]
		if arg2 > var1.Length then
			continue
		end

		local var2 = arg1[i1 - 1]
		local var4 = var1.Length - var2.Length
		if var4 <= 0.0001 then
			return var1.T
		end

		return var2.T + (var1.T - var2.T) * ((arg2 - var2.Length) / var4)
	end

	return 1
end

return tbl1

--- ReplicatedStorage.Shared.MapConfig [ModuleScript]
-- y u r i

local str1 = "ModeRewardConfig"
local var1 = require(script.Parent:WaitForChild(str1))
str1 = function(arg1)
	local var1 = table.clone(arg1)
	if arg1.Sky then
		var1.Sky = table.clone(arg1.Sky)
	end

	if arg1.Atmosphere then
		var1.Atmosphere = table.clone(arg1.Atmosphere)
	end

	if arg1.Bloom then
		var1.Bloom = table.clone(arg1.Bloom)
	end

	if arg1.ColorCorrection then
		var1.ColorCorrection = table.clone(arg1.ColorCorrection)
	end

	if arg1.SunRays then
		var1.SunRays = table.clone(arg1.SunRays)
	end

	return var1
end

local var2 = var1.GetRequired("Easy")
local var3 = var1.GetRequired("Endless")
local var4 = var1.GetRequired("Medium")
local var5 = var1.GetRequired("Hard")
local var6 = var1.GetRequired("Insane")
local var7 = var1.GetRequired("Crazy")
local tbl1 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 211, 194),
	Brightness = 2.5,
	ClockTime = 12.5,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 0,
	FogEnd = 3000,
	GeographicLatitude = 0,
	GlobalShadows = true,
	ShadowSoftness = 0.3,
}

tbl1.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl1.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl1.FogColor = Color3.fromRGB(223, 199, 250)
tbl1.OutdoorAmbient = Color3.fromRGB(170, 156, 138)
tbl1.Sky = {
	SkyboxBk = "rbxassetid://591058823",
	SkyboxDn = "rbxassetid://591059876",
	SkyboxFt = "rbxassetid://591058104",
	SkyboxLf = "rbxassetid://591057861",
	SkyboxRt = "rbxassetid://591057625",
	SkyboxUp = "rbxassetid://591059642",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = true,
	StarCount = 3000,
}

local tbl2 = {
	Density = 0.25,
	Offset = 0.15,
	Color = Color3.fromRGB(199, 220, 255),
	Glare = 0.1,
	Haze = 1,
}

tbl2.Decay = Color3.fromRGB(106, 120, 145)
tbl1.Atmosphere = tbl2
tbl1.Bloom = { Enabled = false, Intensity = 0.1, Size = 24, Threshold = 1.8 }
tbl2 = {
	Enabled = true,
	Brightness = 0.03,
	Contrast = 0.1,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 248, 238),
}

tbl1.ColorCorrection = tbl2
tbl1.SunRays = { Enabled = false, Intensity = 0.03, Spread = 0.8 }
local tbl3 = {
	Id = "City",
	DisplayName = "City",
	Mode = "Easy",
	Icon = "rbxassetid://121048408445888",
	CoinReward = var2.WinCoins,
	XpReward = var2.XpEarn,
	Waves = 20,
	Lighting = tbl1,
}

tbl2 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 211, 194),
	Brightness = 3,
	ClockTime = 14.5,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 90,
	FogEnd = 750,
	GeographicLatitude = 40,
	GlobalShadows = true,
	ShadowSoftness = 0.35,
}

tbl2.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl2.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl2.FogColor = Color3.fromRGB(199, 170, 107)
tbl2.OutdoorAmbient = Color3.fromRGB(234, 137, 0)
tbl2.Sky = {
	SkyboxBk = "rbxassetid://600830446",
	SkyboxDn = "rbxassetid://600831635",
	SkyboxFt = "rbxassetid://600832720",
	SkyboxLf = "rbxassetid://600886090",
	SkyboxRt = "rbxassetid://600833862",
	SkyboxUp = "rbxassetid://600835177",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = true,
	StarCount = 3000,
}

local tbl4 = {
	Density = 0.442,
	Offset = 0,
	Color = Color3.fromRGB(199, 170, 107),
	Glare = 0,
	Haze = 0,
}

tbl4.Decay = Color3.fromRGB(92, 60, 13)
tbl2.Atmosphere = tbl4
tbl2.Bloom = { Enabled = false, Intensity = 0.18, Size = 32, Threshold = 1.4 }
tbl4 = {
	Enabled = true,
	Brightness = 0.03,
	Contrast = 0.12,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 255, 255),
}

tbl2.ColorCorrection = tbl4
tbl2.SunRays = { Enabled = false, Intensity = 0.09, Spread = 0.55 }
tbl1 = {
	Id = "Canyon",
	DisplayName = "Canyon Bridge",
	Mode = "Medium",
	Icon = "rbxassetid://95909190279599",
	CoinReward = var4.WinCoins,
	XpReward = var4.XpEarn,
	Waves = 30,
	Lighting = tbl2,
}

tbl4 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 175, 89),
	Brightness = 3,
	ClockTime = 9.9,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 0,
	FogEnd = 10000000,
	GeographicLatitude = 25,
	GlobalShadows = true,
	ShadowSoftness = 0.15,
}

tbl4.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl4.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl4.FogColor = Color3.fromRGB(220, 167, 103)
tbl4.OutdoorAmbient = Color3.fromRGB(155, 119, 82)
tbl4.Sky = {
	SkyboxBk = "rbxassetid://706982625",
	SkyboxDn = "rbxassetid://706983129",
	SkyboxFt = "rbxassetid://706982625",
	SkyboxLf = "rbxassetid://706982625",
	SkyboxRt = "rbxassetid://706982625",
	SkyboxUp = "rbxassetid://706983714",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = false,
	StarCount = 3000,
}

local tbl5 = {
	Density = 0.525,
	Offset = 0.2,
	Color = Color3.fromRGB(199, 177, 139),
	Glare = 0,
	Haze = 0,
}

tbl5.Decay = Color3.fromRGB(125, 125, 125)
tbl4.Atmosphere = tbl5
tbl4.Bloom = { Enabled = false, Intensity = 0.15, Size = 30, Threshold = 1.5 }
tbl5 = {
	Enabled = true,
	Brightness = 0.1,
	Contrast = 0.05,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 253, 238),
}

tbl4.ColorCorrection = tbl5
tbl4.SunRays = { Enabled = false, Intensity = 0.08, Spread = 0.65 }
tbl2 = {
	Id = "WildDesert",
	DisplayName = "Wild Desert",
	Mode = "Hard",
	Icon = "rbxassetid://81140162953587",
	CoinReward = var5.WinCoins,
	XpReward = var5.XpEarn,
	Waves = 40,
	Lighting = tbl4,
}

tbl5 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 211, 194),
	Brightness = 2.5,
	ClockTime = 12.5,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 0,
	FogEnd = 3000,
	GeographicLatitude = 0,
	GlobalShadows = true,
	ShadowSoftness = 0.3,
}

tbl5.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl5.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl5.FogColor = Color3.fromRGB(223, 199, 250)
tbl5.OutdoorAmbient = Color3.fromRGB(170, 156, 138)
tbl5.Sky = {
	SkyboxBk = "rbxassetid://591058823",
	SkyboxDn = "rbxassetid://591059876",
	SkyboxFt = "rbxassetid://591058104",
	SkyboxLf = "rbxassetid://591057861",
	SkyboxRt = "rbxassetid://591057625",
	SkyboxUp = "rbxassetid://591059642",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = true,
	StarCount = 3000,
}

local tbl6 = {
	Density = 0.25,
	Offset = 0.15,
	Color = Color3.fromRGB(199, 220, 255),
	Glare = 0.1,
	Haze = 1,
}

tbl6.Decay = Color3.fromRGB(106, 120, 145)
tbl5.Atmosphere = tbl6
tbl5.Bloom = { Enabled = false, Intensity = 0.1, Size = 24, Threshold = 1.8 }
tbl6 = {
	Enabled = true,
	Brightness = 0.03,
	Contrast = 0.1,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 248, 238),
}

tbl5.ColorCorrection = tbl6
tbl5.SunRays = { Enabled = false, Intensity = 0.03, Spread = 0.8 }
tbl4 = {
	Id = "Camera Lab",
	DisplayName = "Camera Lab",
	Mode = "Insane",
	Icon = "rbxassetid://81140162953587",
	CoinReward = var6.WinCoins,
	XpReward = var6.XpEarn,
	Waves = 50,
	Lighting = tbl5,
}

tbl6 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 211, 194),
	Brightness = 2.5,
	ClockTime = 12.5,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 0,
	FogEnd = 3000,
	GeographicLatitude = 0,
	GlobalShadows = true,
	ShadowSoftness = 0.3,
}

tbl6.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl6.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl6.FogColor = Color3.fromRGB(223, 199, 250)
tbl6.OutdoorAmbient = Color3.fromRGB(170, 156, 138)
tbl6.Sky = {
	SkyboxBk = "rbxassetid://591058823",
	SkyboxDn = "rbxassetid://591059876",
	SkyboxFt = "rbxassetid://591058104",
	SkyboxLf = "rbxassetid://591057861",
	SkyboxRt = "rbxassetid://591057625",
	SkyboxUp = "rbxassetid://591059642",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = true,
	StarCount = 3000,
}

local tbl7 = {
	Density = 0.25,
	Offset = 0.15,
	Color = Color3.fromRGB(199, 220, 255),
	Glare = 0.1,
	Haze = 1,
}

tbl7.Decay = Color3.fromRGB(106, 120, 145)
tbl6.Atmosphere = tbl7
tbl6.Bloom = { Enabled = false, Intensity = 0.1, Size = 24, Threshold = 1.8 }
tbl7 = {
	Enabled = true,
	Brightness = 0.03,
	Contrast = 0.1,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 248, 238),
}

tbl6.ColorCorrection = tbl7
tbl6.SunRays = { Enabled = false, Intensity = 0.03, Spread = 0.8 }
tbl5 = {
	Id = "ToiletBunker",
	DisplayName = "Toilet Bunker",
	Mode = "Crazy",
	Icon = "rbxassetid://121048408445888",
	CoinReward = var7.WinCoins,
	XpReward = var7.XpEarn,
	Waves = 60,
	Lighting = tbl6,
}

tbl7 = {
	LightingStyle = "Soft",
	Ambient = Color3.fromRGB(225, 211, 194),
	Brightness = 2.5,
	ClockTime = 12.5,
	EnvironmentDiffuseScale = 0.4,
	EnvironmentSpecularScale = 0.5,
	ExposureCompensation = 0,
	FogStart = 0,
	FogEnd = 3000,
	GeographicLatitude = 0,
	GlobalShadows = true,
	ShadowSoftness = 0.3,
}

tbl7.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl7.ColorShift_Top = Color3.fromRGB(215, 190, 135)
tbl7.FogColor = Color3.fromRGB(223, 199, 250)
tbl7.OutdoorAmbient = Color3.fromRGB(170, 156, 138)
tbl7.Sky = {
	SkyboxBk = "rbxassetid://591058823",
	SkyboxDn = "rbxassetid://591059876",
	SkyboxFt = "rbxassetid://591058104",
	SkyboxLf = "rbxassetid://591057861",
	SkyboxRt = "rbxassetid://591057625",
	SkyboxUp = "rbxassetid://591059642",
	SkyboxOrientation = Vector3.new(0, 0, 0),
	CelestialBodiesShown = true,
	StarCount = 3000,
}

local tbl8 = {
	Density = 0.25,
	Offset = 0.15,
	Color = Color3.fromRGB(199, 220, 255),
	Glare = 0.1,
	Haze = 1,
}

tbl8.Decay = Color3.fromRGB(106, 120, 145)
tbl7.Atmosphere = tbl8
tbl7.Bloom = { Enabled = false, Intensity = 0.1, Size = 24, Threshold = 1.8 }
tbl8 = {
	Enabled = true,
	Brightness = 0.03,
	Contrast = 0.1,
	Saturation = 0.1,
	TintColor = Color3.fromRGB(255, 248, 238),
}

tbl7.ColorCorrection = tbl8
tbl7.SunRays = { Enabled = false, Intensity = 0.03, Spread = 0.8 }
local function cloneArray(arg1, arg2)
	local tbl1 = {}
	for k1, v1 in ipairs(arg1) do
		tbl1[k1] = arg2(v1)
	end

	return tbl1
end

local tbl9 = { Maps = {
	tbl3,
	tbl1,
	tbl2,
	tbl4,
	tbl5,
	{
		Id = "Endless",
		DisplayName = "Endless",
		Mode = "Endless",
		Icon = "rbxassetid://121048408445888",
		CoinReward = var3.CoinsPerClearedWave,
		XpReward = 0,
		Waves = 20,
		Lighting = tbl7,
	},
} }

local function cloneMap(arg1)
	local var1 = table.clone(arg1)
	var1.Lighting = str1(arg1.Lighting)
	return var1
end

tbl9.GetAll = function()
	return (cloneArray(tbl9.Maps, cloneMap))
end

tbl9.GetById = function(arg1)
	for k1, v1 in ipairs(tbl9.Maps) do
		if v1.Id ~= arg1 then
			continue
		end

		local var1 = table.clone(v1)
		var1.Lighting = str1(v1.Lighting)
		return var1
	end

	return nil
end

return tbl9

--- ReplicatedStorage.Shared.ModeRewardConfig [ModuleScript]
-- y u r i

local tbl1 = {
	Easy = { WinCoins = 100, XpEarn = 35, CoinsPerClearedWave = 4 },
	Endless = { WinCoins = 0, XpEarn = 0, CoinsPerClearedWave = 4 },
	Medium = { WinCoins = 275, XpEarn = 50, CoinsPerClearedWave = 5 },
	Hard = { WinCoins = 500, XpEarn = 75, CoinsPerClearedWave = 8 },
	Insane = { WinCoins = 850, XpEarn = 100, CoinsPerClearedWave = 10 },
	Crazy = { WinCoins = 1000, XpEarn = 125, CoinsPerClearedWave = 10 },
}

local tbl2 = {}
for k1, v1 in pairs(tbl1) do
	local var1 = v1.WinCoins
	local var2 = ("%s.WinCoins"):format(k1)
	if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or (var1 == -math.huge or (var1 < 0 or var1 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format(var2, (tostring(var1))), 2)
	end

	var1 = v1.XpEarn
	var2 = ("%s.XpEarn"):format(k1)
	if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or (var1 == -math.huge or (var1 < 0 or var1 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format(var2, (tostring(var1))), 2)
	end

	var1 = v1.CoinsPerClearedWave
	var2 = ("%s.CoinsPerClearedWave"):format(k1)
	if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or (var1 == -math.huge or (var1 < 0 or var1 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format(var2, (tostring(var1))), 2)
	end
end

tbl2.Get = function(arg1)
	local var2 = tbl1[arg1]
	if not var2 then
		return nil
	end

	return (table.clone(var2))
end

tbl2.GetRequired = function(arg1)
	local var2 = tbl2.Get(arg1)
	if not var2 then
		error(("Unknown reward mode %q. Expected Easy, Medium, or Hard."):format((tostring(arg1))), 2)
	end

	return var2
end

tbl2.Calculate = function(arg1, arg2, arg3)
	if arg2 ~= "Win" and arg2 ~= "Lose" then
		error(("Match result must be %q or %q, got %q"):format("Win", "Lose", (tostring(arg2))), 2)
	end

	if typeof(arg3) ~= "number" or (arg3 ~= arg3 or (arg3 == math.huge or (arg3 == -math.huge or (arg3 < 0 or arg3 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format("completedWaves", (tostring(arg3))), 2)
	end

	local var2 = tbl2.GetRequired(arg1)
	local var3 = if arg2 == "Win" then var2.WinCoins else arg3 * var2.CoinsPerClearedWave
	if typeof(var3) ~= "number" or (var3 ~= var3 or (var3 == math.huge or (var3 == -math.huge or (var3 < 0 or var3 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format("calculated reward", (tostring(var3))), 2)
	end

	return var3
end

tbl2.CalculateXp = function(arg1, arg2)
	if arg2 ~= "Win" and arg2 ~= "Lose" then
		error(("Match result must be %q or %q, got %q"):format("Win", "Lose", (tostring(arg2))), 2)
	end

	if arg2 ~= "Win" then
		return 0
	end

	local var1 = tbl2.GetRequired(arg1).XpEarn
	if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or (var1 == -math.huge or (var1 < 0 or var1 % 1 ~= 0)))) then
		error(("%s must be a non-negative finite integer, got %s"):format("calculated xp", (tostring(var1))), 2)
	end

	return var1
end

return tbl2

--- ReplicatedStorage.Shared.QuestConfig [ModuleScript]
-- y u r i

local tbl1 = {
	SummonUnits = true,
	KillAnyToilet = true,
	SummonRarity = true,
	KillSpecificToilet = true,
	WinAnyMode = true,
	Playtime = true,
}

local function durationTitle(arg1)
	if arg1 % 60 == 0 then
		local var2 = arg1 / 60
		local str1 = "Play for %d %s"
		local var3 = var2
		local var4 = if var2 == 1 then "minute" else "minutes"
		return str1:format(var3, var4)
	end

	local var5 = arg1
	return ("Play for %d seconds"):format(var5)
end

local tbl2 = {
	General = {
		SchemaVersion = 1,
		SlotCount = 3,
		ResetSeconds = 3600,
		ClaimCooldownSeconds = 0.25,
		MaxRewardAmount = 1000000,
		MaxCurrencyBalance = 1000000000000,
	},
	Currencies = { Coins = { DisplayName = "Coins", Icon = "rbxassetid://102505941801998" } },
	ToiletMobIds = {
		Toilet = true,
		["Vacuum Toilet"] = true,
		["DJ Toilet"] = true,
		["Spider Toilet"] = true,
		["Rocket Toilet"] = true,
		["Glasses Toilet"] = true,
		["Mask Toilet"] = true,
		["Angel Toilet"] = true,
		["Party Toilet"] = true,
		["Glitch Toilet"] = true,
		["Scientist Toilet"] = true,
		["G-Toilet"] = true,
		["G-Toilet 2.0"] = true,
		["G-Toilet 3.0"] = true,
	},
	Definitions = {
		{
			Id = "summon_units_50",
			Enabled = true,
			Weight = 10,
			Type = "SummonUnits",
			Target = 50,
			Params = {},
			Reward = { Currency = "Coins", Amount = 600 },
		},
		{
			Id = "kill_toilets_50",
			Enabled = true,
			Weight = 10,
			Type = "KillAnyToilet",
			Target = 50,
			Params = {},
			Reward = { Currency = "Coins", Amount = 150 },
		},
		{
			Id = "summon_epic_3",
			Enabled = true,
			Weight = 8,
			Type = "SummonRarity",
			Target = 3,
			Params = { Rarity = "Epic" },
			Reward = { Currency = "Coins", Amount = 300 },
		},
		{
			Id = "kill_gman_2",
			Enabled = true,
			Weight = 7,
			Type = "KillSpecificToilet",
			Target = 2,
			Params = { MobId = "G-Toilet" },
			Reward = { Currency = "Coins", Amount = 250 },
		},
		{
			Id = "win_any_mode_5",
			Enabled = true,
			Weight = 6,
			Type = "WinAnyMode",
			Target = 5,
			Params = {},
			Reward = { Currency = "Coins", Amount = 500 },
		},
		{
			Id = "playtime_5_minutes",
			Enabled = true,
			Weight = 10,
			Type = "Playtime",
			Target = 300,
			Params = {},
			Reward = { Currency = "Coins", Amount = 75 },
		},
	},
	IsSupportedType = function(arg1)
		local bool1 = false
		if type(arg1) == "string" then
			bool1 = tbl1[arg1] == true
		end

		return bool1
	end,
	BuildTitle = function(arg1)
		local var1 = arg1.Params
		local var5 = arg1.Type
		local var6 = arg1.Target
		var1 = var1 or {}
		if var5 == "SummonUnits" then
			local var7 = var6
			return ("Summon %d Units"):format(var7)
		end

		if var5 == "KillAnyToilet" then
			local var9 = var6
			return ("Kill %d Toilets"):format(var9)
		end

		if var5 == "SummonRarity" then
			local var10 = tostring(var1.Rarity)
			return ("Summon %s Rarity"):format(var10)
		end

		if var5 == "KillSpecificToilet" then
			local var11 = tostring(var1.MobId)
			return ("Kill %s"):format(var11)
		end

		if var5 == "WinAnyMode" then
			return "Win Any Mode"
		end

		if var5 == "Playtime" then
			local var13 = var6
			return durationTitle(var13)
		end

		return (tostring(arg1.Id))
	end,
}

tbl2.Validate = function()
	local var1 = tbl2.General
	local var2 = var1.SchemaVersion
	local bool2 = false
	if typeof(var2) == "number" then
		bool2 = false
		if var2 == var2 then
			bool2 = false
			if var2 ~= math.huge then
				bool2 = false
				if 0 < var2 then
					bool2 = var2 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "QuestConfig.General.SchemaVersion must be a positive integer")
	var2 = var1.SlotCount
	bool2 = false
	if typeof(var2) == "number" then
		bool2 = false
		if var2 == var2 then
			bool2 = false
			if var2 ~= math.huge then
				bool2 = false
				if 0 < var2 then
					bool2 = var2 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "QuestConfig.General.SlotCount must be a positive integer")
	var2 = var1.ResetSeconds
	bool2 = false
	if typeof(var2) == "number" then
		bool2 = false
		if var2 == var2 then
			bool2 = false
			if var2 ~= math.huge then
				bool2 = false
				if 0 < var2 then
					bool2 = var2 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "QuestConfig.General.ResetSeconds must be a positive integer")
	var2 = var1.MaxRewardAmount
	bool2 = false
	if typeof(var2) == "number" then
		bool2 = false
		if var2 == var2 then
			bool2 = false
			if var2 ~= math.huge then
				bool2 = false
				if 0 < var2 then
					bool2 = var2 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "QuestConfig.General.MaxRewardAmount must be a positive integer")
	var2 = var1.MaxCurrencyBalance
	bool2 = false
	if typeof(var2) == "number" then
		bool2 = false
		if var2 == var2 then
			bool2 = false
			if var2 ~= math.huge then
				bool2 = false
				if 0 < var2 then
					bool2 = var2 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "QuestConfig.General.MaxCurrencyBalance must be a positive integer")
	assert(var1.MaxRewardAmount <= var1.MaxCurrencyBalance, "MaxCurrencyBalance must be at least MaxRewardAmount")
	bool2 = false
	if typeof(var1.ClaimCooldownSeconds) == "number" then
		bool2 = false
		if var1.ClaimCooldownSeconds == var1.ClaimCooldownSeconds then
			bool2 = false
			if 0 <= var1.ClaimCooldownSeconds then
				bool2 = var1.ClaimCooldownSeconds < math.huge
			end
		end
	end

	assert(bool2, "QuestConfig.General.ClaimCooldownSeconds must be finite and non-negative")
	local num1 = 0
	bool2 = {}
	for k1, v1 in pairs(tbl2.Currencies) do
		local bool3 = false
		if type(k1) == "string" then
			bool3 = k1 ~= ""
		end

		assert(bool3, "Currency name must be a non-empty string")
		local var3 = k1
		assert(type(v1) == "table", ("Currency %s needs metadata"):format(var3))
		bool3 = false
		if type(v1.DisplayName) == "string" then
			bool3 = v1.DisplayName ~= ""
		end

		var3 = k1
		assert(bool3, ("Currency %s needs DisplayName"):format(var3))
		var3 = k1
		assert(type(v1.Icon) == "string", ("Currency %s needs Icon string"):format(var3))
	end

	for k2, v2 in ipairs(tbl2.Definitions) do
		local bool4 = false
		if type(v2.Id) == "string" then
			bool4 = v2.Id ~= ""
		end

		local var4 = k2
		assert(bool4, ("Quest definition #%d needs Id"):format(var4))
		var4 = v2.Id
		assert(not bool2[v2.Id], ("Duplicate quest Id %q"):format(var4))
		bool2[v2.Id] = true
		var4 = v2.Id
		assert(type(v2.Enabled) == "boolean", ("%s.Enabled must be boolean"):format(var4))
		var4 = tostring(v2.Type)
		assert(tbl2.IsSupportedType(v2.Type), ("Unsupported quest type %q"):format(var4))
		local var5 = v2.Target
		bool4 = false
		if typeof(var5) == "number" then
			bool4 = false
			if var5 == var5 then
				bool4 = false
				if var5 ~= math.huge then
					bool4 = false
					if 0 < var5 then
						bool4 = var5 % 1 == 0
					end
				end
			end
		end

		var4 = v2.Id
		assert(bool4, ("%s.Target must be a positive integer"):format(var4))
		var4 = v2.Id
		assert(type(v2.Params) == "table", ("%s.Params must be a table"):format(var4))
		bool4 = false
		if typeof(v2.Weight) == "number" then
			bool4 = false
			if v2.Weight == v2.Weight then
				bool4 = false
				if 0 <= v2.Weight then
					bool4 = v2.Weight < math.huge
				end
			end
		end

		var4 = v2.Id
		assert(bool4, ("%s.Weight must be finite and non-negative"):format(var4))
		var4 = v2.Id
		assert(type(v2.Reward) == "table", ("%s needs Reward"):format(var4))
		var4 = v2.Id
		local var6 = tostring(v2.Reward.Currency)
		assert(tbl2.Currencies[v2.Reward.Currency] ~= nil, ("%s uses unsupported currency %q"):format(var4, var6))
		var5 = v2.Reward.Amount
		bool4 = false
		if typeof(var5) == "number" then
			bool4 = false
			if var5 == var5 then
				bool4 = false
				if var5 ~= math.huge then
					bool4 = false
					if 0 < var5 then
						bool4 = var5 % 1 == 0
					end
				end
			end
		end

		var4 = v2.Id
		assert(bool4, ("%s.Reward.Amount must be a positive integer"):format(var4))
		var4 = v2.Id
		assert(v2.Reward.Amount <= var1.MaxRewardAmount, ("%s.Reward.Amount exceeds MaxRewardAmount"):format(var4))
		if v2.Type == "SummonRarity" then
			bool4 = false
			if type(v2.Params) == "table" then
				bool4 = false
				if type(v2.Params.Rarity) == "string" then
					bool4 = v2.Params.Rarity ~= ""
				end
			end

			var4 = v2.Id
			assert(bool4, ("%s needs non-empty Params.Rarity"):format(var4))
		else
			if v2.Type == "KillSpecificToilet" then
				bool4 = false
				if type(v2.Params) == "table" then
					bool4 = false
					if type(v2.Params.MobId) == "string" then
						bool4 = v2.Params.MobId ~= ""
					end
				end

				var4 = v2.Id
				assert(bool4, ("%s needs non-empty Params.MobId"):format(var4))
			end
		end

		if v2.Enabled ~= true then
			continue
		end

		if 0 >= v2.Weight then
			continue
		end

		num1 = num1 + 1
	end

	local var7 = var1.SlotCount
	assert(var1.SlotCount <= num1, ("At least %d enabled quests with Weight > 0 are required"):format(var7))
end

return tbl2

--- ReplicatedStorage.Shared.EndlessConfig [ModuleScript]
-- y u r i

local tbl1 = {
	FriendBonusPerPlayer = 0.1,
	RewardEveryWaves = 10,
	Rewards = {
		{ Id = "Coins", Weight = 50, Min = 50, Max = 100 },
		{ Id = "Tickets", Weight = 25, Min = 1, Max = 3 },
		{ Id = "FreeCrates", Weight = 10, Min = 1, Max = 2 },
		{ Id = "SummonDiscount", Weight = 15, Min = 1, Max = 1 },
	},
	EnabledModes = { Endless = true },
	ContinueVoteDuration = 60,
	ContinueVoteExtension = 30,
	TemplateWaveCount = 10,
	HealthGrowthPerWave = 0.15,
	EnemyCountGrowthPerWave = 0.025,
	SpawnDelayReductionPerWave = 0.01,
	MinimumSpawnDelay = 0.12,
}

tbl1.IsEnabled = function(arg1)
	return tbl1.EnabledModes[arg1] == true
end

tbl1.GetEndlessWaveIndex = function(arg1, arg2)
	return (math.max(math.floor(arg1) - math.floor(arg2), 0))
end

tbl1.GetHealthMultiplier = function(arg1, arg2)
	return 1 + tbl1.GetEndlessWaveIndex(arg1, arg2) * tbl1.HealthGrowthPerWave
end

tbl1.GetEnemyCountMultiplier = function(arg1, arg2)
	return 1 + tbl1.GetEndlessWaveIndex(arg1, arg2) * tbl1.EnemyCountGrowthPerWave
end

tbl1.GetSpawnDelay = function(arg1, arg2, arg3)
	return (math.max(tbl1.MinimumSpawnDelay, arg1 * math.max(0, 1 - tbl1.GetEndlessWaveIndex(arg2, arg3) * tbl1.SpawnDelayReductionPerWave)))
end

tbl1.RollReward = function(arg1)
	local num1 = 0
	for k1, v1 in ipairs(tbl1.Rewards) do
		local var1 = v1.Weight
		num1 = num1 + var1
	end

	local var2 = arg1:NextNumber(0, num1)
	local num2 = 0
	for k2, v2 in ipairs(tbl1.Rewards) do
		num2 = num2 + v2.Weight
		if var2 < num2 or k2 == (#tbl1.Rewards) then
			local var5 = v2.Min
			local var6 = v2.Max
			return v2.Id, arg1:NextInteger(var5, var6)
		end
	end

	error("Endless reward pool is empty")
end

return tbl1

--- ReplicatedStorage.Shared.SeasonPassConfig [ModuleScript]
-- y u r i

local tbl1 = {
	SchemaVersion = 1,
	SeasonId = "season_1_alliance_td#2",
	SeasonNumber = 1,
	DisplayName = "Season 1 - Alliance TD",
	StartUnix = DateTime.fromUniversalTime(2026, 9, 4, 16, 0, 0).UnixTimestamp,
}

tbl1.EndUnix = DateTime.fromUniversalTime(2026, 9, 25, 16, 0, 0).UnixTimestamp
tbl1.DurationSeconds = tbl1.EndUnix - tbl1.StartUnix
tbl1.AutoRepeat = false
tbl1.MaxTier = 50
tbl1.XPPerTier = 250
tbl1.XPPerTierOverrides = {}
tbl1.MaxXP = 10000000
tbl1.MaxSingleXPGain = 100000
tbl1.Products = { Premium = 3710309709, SkipTier = 3710309892 }
tbl1.SkipTierAmount = 1
tbl1.Icons = {
	Coins = "rbxassetid://102505941801998",
	Tickets = "rbxassetid://80410844802074",
	XP = "rbxassetid://129521960793404",
	Locked = "rbxassetid://129521960793404",
}

tbl1.CurrencyDisplayNames = { Coins = "Coins", Tickets = "Tickets" }
tbl1.Tiers = {
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 150 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 1 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 175 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 250 },
	},
	{
		Free = { Type = "Boost", Id = "Money", Amount = 1 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 1 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 200 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 500 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 1 },
		Premium = { Type = "Crate", Id = "Free", Amount = 2 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 200 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 2 },
	},
	{
		Free = { Type = "Boost", Id = "Luck", Amount = 1 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 350 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 250 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 2 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 1 },
		Premium = { Type = "Boost", Id = "Money", Amount = 2 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 1 },
		Premium = { Type = "Crate", Id = "Free", Amount = 3 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 250 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 700 },
	},
	{
		Free = { Type = "Boost", Id = "Money", Amount = 1 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 3 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 2 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 1 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 1 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 800 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 2 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 2 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 300 },
		Premium = { Type = "Boost", Id = "Luck", Amount = 2 },
	},
	{
		Free = { Type = "Boost", Id = "Luck", Amount = 1 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 900 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 350 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 3 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 2 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 4 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 2 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 4 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 350 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1000 },
	},
	{
		Free = { Type = "Boost", Id = "Money", Amount = 1 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 2 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 400 },
		Premium = { Type = "Boost", Id = "Money", Amount = 3 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 2 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1100 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 2 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 2500 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 400 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 5 },
	},
	{
		Free = { Type = "Boost", Id = "Luck", Amount = 1 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1200 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 450 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 4 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 3 },
		Premium = { Type = "Boost", Id = "Luck", Amount = 3 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 3 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 8 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 450 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1300 },
	},
	{
		Free = { Type = "Boost", Id = "Money", Amount = 2 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 3 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 500 },
		Premium = { Type = "Boost", Id = "Money", Amount = 4 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 3 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1400 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 3 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 2 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 500 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 15 },
	},
	{
		Free = { Type = "Boost", Id = "Luck", Amount = 2 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1500 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 550 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 5 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 4 },
		Premium = { Type = "Boost", Id = "Luck", Amount = 4 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 4 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 6 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 550 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1600 },
	},
	{
		Free = { Type = "Boost", Id = "Money", Amount = 3 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 4 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 600 },
		Premium = { Type = "Boost", Id = "Money", Amount = 5 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 4 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1700 },
	},
	{
		Free = { Type = "Crate", Id = "Free", Amount = 4 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1800 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 600 },
		Premium = { Type = "Currency", Id = "Tickets", Amount = 7 },
	},
	{
		Free = { Type = "Boost", Id = "Luck", Amount = 3 },
		Premium = { Type = "Currency", Id = "Coins", Amount = 1900 },
	},
	{
		Free = { Type = "Currency", Id = "Coins", Amount = 650 },
		Premium = { Type = "Crate", Id = "PartyCrate", Amount = 6 },
	},
	{
		Free = { Type = "Currency", Id = "Tickets", Amount = 5 },
		Premium = { Type = "Boost", Id = "Luck", Amount = 5 },
	},
	{
		Free = { Type = "Unit", Id = "Builder Camera Man", Amount = 1 },
		Premium = { Type = "Crate", Id = "ScientistCrate", Amount = 10 },
	},
}

tbl1.ToNonNegativeInteger = function(arg1)
	local bool2 = false
	if typeof(arg1) == "number" then
		bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end
	end

	if not bool2 or arg1 < 0 then
		return 0
	end

	return (math.floor(arg1))
end

tbl1.GetTierCost = function(arg1)
	local var1 = tbl1.XPPerTierOverrides[arg1]
	local bool2 = false
	if typeof(var1) == "number" then
		bool2 = false
		if var1 == var1 then
			bool2 = false
			if var1 ~= math.huge then
				bool2 = var1 ~= -math.huge
			end
		end
	end

	if bool2 and 0 < var1 then
		return (math.floor(var1))
	end

	return tbl1.XPPerTier
end

tbl1.GetTotalXPForTier = function(arg1)
	local num1 = 0
	for i1 = 1, math.clamp(math.floor(arg1), 1, tbl1.MaxTier) - 1 do
		num1 = num1 + tbl1.GetTierCost(i1)
	end

	return num1
end

tbl1.GetMaxXP = function()
	return tbl1.GetTotalXPForTier(tbl1.MaxTier) + tbl1.GetTierCost(tbl1.MaxTier)
end

tbl1.ResolveProgress = function(arg1)
	local var1 = tbl1.ToNonNegativeInteger(arg1)
	local num1 = 1
	local var2 = tbl1.GetTierCost(num1)
	while num1 < tbl1.MaxTier and var1 >= var2 do
		var1 = var1 - var2
		num1 = num1 + 1
	end

	if tbl1.MaxTier <= num1 then
		var2 = tbl1.GetTierCost(tbl1.MaxTier)
		return tbl1.MaxTier, math.min(var1, var2), var2, true
	end

	return num1, var1, tbl1.GetTierCost(num1), false
end

tbl1.GetSeasonWindow = function(arg1)
	local var1 = arg1
	local var2 = tbl1.ToNonNegativeInteger(var1 or os.time())
	var1 = tbl1.StartUnix
	local var4 = math.max(1, tbl1.DurationSeconds)
	if tbl1.AutoRepeat then
		if var1 + var4 <= var2 then
			var1 = var1 + math.floor((var2 - var1) / var4) * var4
		end
	end

	local var5 = var1 + var4
	local var6 = var1
	local var7 = var5
	local bool1 = false
	if var1 <= var2 then
		bool1 = var2 < var5
	end

	return var6, var7, bool1
end

tbl1.GetSeasonKey = function(arg1)
	local var2 = tbl1.GetSeasonWindow(arg1)
	if var2 == tbl1.StartUnix then
		return tbl1.SeasonId
	end

	return (("%*#%*"):format(tbl1.SeasonId, math.floor((var2 - tbl1.StartUnix) / math.max(1, tbl1.DurationSeconds)) + 1))
end

tbl1.GetSecondsLeft = function(arg1)
	local var1 = arg1
	var1 = var1 or os.time()
	local var2, var3 = tbl1.GetSeasonWindow(var1)
	return (math.max(0, var3 - var1))
end

tbl1.GetReward = function(arg1, arg2)
	local var1 = tbl1.Tiers[arg1]
	if type(var1) ~= "table" then
		return nil
	end

	local var2 = var1[arg2]
	if type(var2) ~= "table" then
		return nil
	end

	return var2
end

tbl1.EnsureState = function(arg1, arg2)
	if type(arg1) ~= "table" then
		return nil, false
	end

	local var1 = arg1.SeasonPass
	local var4 = type(var1) ~= "table"
	local var5 = tbl1.GetSeasonKey(arg2)
	if not var4 then
		local bool3 = true
		if var1.SchemaVersion == tbl1.SchemaVersion then
			bool3 = true
			if var1.SeasonId == var5 then
				local var6 = var1.XP
				local bool5 = false
				if typeof(var6) == "number" then
					bool5 = false
					if var6 == var6 then
						bool5 = false
						if var6 ~= math.huge then
							bool5 = var6 ~= -math.huge
						end
					end
				end

				bool3 = not bool5
				if not bool3 then
					bool3 = true
					if type(var1.ClaimedFree) == "table" then
						bool3 = true
						if type(var1.ClaimedPremium) == "table" then
							bool3 = type(var1.Premium) ~= "boolean"
						end
					end
				end
			end
		end

		var4 = bool3
	end

	if var4 then
		var1 = {
			SchemaVersion = tbl1.SchemaVersion,
			SeasonId = var5,
			XP = 0,
			Premium = false,
			SkipTiers = 0,
			ClaimedFree = {},
			ClaimedPremium = {},
		}

		arg1.SeasonPass = var1
		return var1, true
	end

	local var7 = math.min(tbl1.ToNonNegativeInteger(var1.XP), tbl1.MaxXP)
	var1.XP = var7
	var7 = tbl1.ToNonNegativeInteger(var1.SkipTiers)
	var1.SkipTiers = var7
	local str1 = "ClaimedPremium"
	for k1, v1 in { "ClaimedFree", str1 }, nil do
		local tbl2 = {}
		for k2, v2 in pairs(var1[v1]) do
			local var8 = tonumber(k2)
			if v2 ~= true or var8 == nil then
				continue
			end

			if var8 % 1 ~= 0 or 1 > var8 then
				continue
			end

			if var8 > tbl1.MaxTier then
				continue
			end

			local var9 = tostring((math.floor(var8)))
			tbl2[var9] = true
		end

		var1[v1] = tbl2
	end

	return var1, false
end

tbl1.IsClaimed = function(arg1, arg2, arg3)
	if type(arg1) ~= "table" then
		return false
	end

	local var1 = if arg3 == "Premium" then arg1.ClaimedPremium else arg1.ClaimedFree
	if type(var1) ~= "table" then
		return false
	end

	local bool1 = true
	if var1[tostring(arg2)] ~= true then
		bool1 = var1[arg2] == true
	end

	return bool1
end

tbl1.MarkClaimed = function(arg1, arg2, arg3)
	if type(arg1) ~= "table" then
		return
	end

	local var1 = if arg3 == "Premium" then arg1.ClaimedPremium else arg1.ClaimedFree
	if type(var1) ~= "table" then
		return
	end

	var1[arg2] = nil
	local var2 = tostring(arg2)
	var1[var2] = true
end

tbl1.GetPlayerTier = function(arg1)
	if type(arg1) ~= "table" then
		return 1, 0, tbl1.GetTierCost(1), false
	end

	local var1 = arg1.XP
	return tbl1.ResolveProgress(var1)
end

tbl1.AddXP = function(arg1, arg2, arg3)
	local var2 = tbl1.EnsureState(arg1, arg3)
	if var2 == nil then
		return 0, 1, 1
	end

	local var3, var4, var5 = tbl1.GetSeasonWindow(arg3)
	if not var5 then
		local var6 = tbl1.GetPlayerTier(var2)
		return 0, var6, var6
	end

	local var9 = math.min(tbl1.ToNonNegativeInteger(arg2), tbl1.MaxSingleXPGain)
	local var10 = tbl1.GetPlayerTier(var2)
	if var9 <= 0 then
		return 0, var10, var10
	end

	local var11 = math.min(var2.XP + var9, (tbl1.GetMaxXP()))
	local var12 = var11 - var2.XP
	var2.XP = var11
	return var12, tbl1.GetPlayerTier(var2), var10
end

tbl1.SkipTier = function(arg1, arg2, arg3)
	local var2 = tbl1.EnsureState(arg1, arg3)
	if var2 == nil then
		return 0, 1, 1
	end

	local var3 = arg2
	local var4 = math.max(1, tbl1.ToNonNegativeInteger(var3))
	local var5 = tbl1.GetPlayerTier(var2)
	local var6 = tbl1.GetMaxXP()
	var3 = 0
	for i1 = 1, var4 do
		local var7, var8, var9, var10 = tbl1.GetPlayerTier(var2)
		if var10 then
			break
		end

		local var11 = math.min(var2.XP + math.max(0, var9 - var8), var6)
		if var11 == var2.XP then
			break
		end

		var2.XP = var11
		local var12 = tbl1.ToNonNegativeInteger(var2.SkipTiers) + 1
		var2.SkipTiers = var12
		if tbl1.MaxTier <= var7 + 1 then
			break
		end

		var3 = var3 + 1
	end

	return var3, tbl1.GetPlayerTier(var2), var5
end

return tbl1

--- ReplicatedStorage.Shared.SeasonQuestConfig [ModuleScript]
-- y u r i

local tbl1 = {
	SummonUnits = true,
	KillAnyToilet = true,
	SummonRarity = true,
	KillSpecificToilet = true,
	WinAnyMode = true,
	Playtime = true,
}

local tbl2 = {
	SchemaVersion = 1,
	ClaimCooldownSeconds = 0.25,
	MaxXPReward = 100000,
	XPIcon = "rbxassetid://129521960793404",
	XPDisplayName = "XP",
	Tracks = {
		{
			Id = "Hourly",
			DisplayName = "Hourly Quests",
			SlotCount = 3,
			ResetSeconds = 3600,
			DataKey = "SeasonQuestsHourly",
		},
		{
			Id = "Daily",
			DisplayName = "Daily Quests",
			SlotCount = 3,
			ResetSeconds = 86400,
			DataKey = "SeasonQuestsDaily",
		},
	},
	ToiletMobIds = {
		Toilet = true,
		["Vacuum Toilet"] = true,
		["DJ Toilet"] = true,
		["Spider Toilet"] = true,
		["Rocket Toilet"] = true,
		["Glasses Toilet"] = true,
		["Mask Toilet"] = true,
		["Angel Toilet"] = true,
		["Party Toilet"] = true,
		["Glitch Toilet"] = true,
		["Scientist Toilet"] = true,
		["G-Toilet"] = true,
		["G-Toilet 2.0"] = true,
		["G-Toilet 3.0"] = true,
	},
	Definitions = {
		Hourly = {
			{
				Id = "season_h_summon_50",
				Enabled = true,
				Weight = 10,
				Type = "SummonUnits",
				Target = 50,
				Params = {},
				XP = 40,
			},
			{
				Id = "season_h_kill_50",
				Enabled = true,
				Weight = 10,
				Type = "KillAnyToilet",
				Target = 50,
				Params = {},
				XP = 40,
			},
			{
				Id = "season_h_epic_3",
				Enabled = true,
				Weight = 8,
				Type = "SummonRarity",
				Target = 3,
				Params = { Rarity = "Epic" },
				XP = 40,
			},
			{
				Id = "season_h_gman_2",
				Enabled = true,
				Weight = 7,
				Type = "KillSpecificToilet",
				Target = 2,
				Params = { MobId = "G-Toilet" },
				XP = 40,
			},
			{
				Id = "season_h_win_2",
				Enabled = true,
				Weight = 6,
				Type = "WinAnyMode",
				Target = 2,
				Params = {},
				XP = 40,
			},
			{
				Id = "season_h_playtime_10",
				Enabled = true,
				Weight = 10,
				Type = "Playtime",
				Target = 600,
				Params = {},
				XP = 40,
			},
		},
		Daily = {
			{
				Id = "season_d_summon_400",
				Enabled = true,
				Weight = 10,
				Type = "SummonUnits",
				Target = 400,
				Params = {},
				XP = 250,
			},
			{
				Id = "season_d_kill_400",
				Enabled = true,
				Weight = 10,
				Type = "KillAnyToilet",
				Target = 400,
				Params = {},
				XP = 250,
			},
			{
				Id = "season_d_legendary_5",
				Enabled = true,
				Weight = 8,
				Type = "SummonRarity",
				Target = 5,
				Params = { Rarity = "Legendary" },
				XP = 250,
			},
			{
				Id = "season_d_gman_20",
				Enabled = true,
				Weight = 7,
				Type = "KillSpecificToilet",
				Target = 20,
				Params = { MobId = "G-Toilet" },
				XP = 250,
			},
			{
				Id = "season_d_win_15",
				Enabled = true,
				Weight = 8,
				Type = "WinAnyMode",
				Target = 15,
				Params = {},
				XP = 250,
			},
			{
				Id = "season_d_playtime_60",
				Enabled = true,
				Weight = 10,
				Type = "Playtime",
				Target = 3600,
				Params = {},
				XP = 250,
			},
		},
	},
	IsSupportedType = function(arg1)
		local bool1 = false
		if type(arg1) == "string" then
			bool1 = tbl1[arg1] == true
		end

		return bool1
	end,
}

tbl2.GetTrack = function(arg1)
	if type(arg1) ~= "string" then
		return nil
	end

	for k1, v1 in ipairs(tbl2.Tracks) do
		if v1.Id ~= arg1 then
			continue
		end

		return v1
	end

	return nil
end

local function durationTitle(arg1)
	if arg1 % 3600 == 0 then
		local var2 = arg1 / 3600
		local str1 = "Play for %d %s"
		local var3 = var2
		local var4 = if var2 == 1 then "hour" else "hours"
		return str1:format(var3, var4)
	end

	if arg1 % 60 == 0 then
		local var6 = arg1 / 60
		local str2 = "Play for %d %s"
		local var7 = var6
		local var8 = if var6 == 1 then "minute" else "minutes"
		return str2:format(var7, var8)
	end

	local var9 = arg1
	return ("Play for %d seconds"):format(var9)
end

tbl2.BuildTitle = function(arg1)
	local var1 = arg1.Params
	local var5 = arg1.Type
	local var6 = arg1.Target
	var1 = var1 or {}
	if var5 == "SummonUnits" then
		local var7 = var6
		return ("Summon %d Units"):format(var7)
	end

	if var5 == "KillAnyToilet" then
		local var9 = var6
		return ("Kill %d Toilets"):format(var9)
	end

	if var5 == "SummonRarity" then
		local var10 = var6
		local var11 = tostring(var1.Rarity)
		return ("Summon %d %s"):format(var10, var11)
	end

	if var5 == "KillSpecificToilet" then
		local var12 = var6
		local var13 = tostring(var1.MobId)
		return ("Kill %d %s"):format(var12, var13)
	end

	if var5 == "WinAnyMode" then
		local var15 = var6
		return ("Win %d Matches"):format(var15)
	end

	if var5 == "Playtime" then
		local var17 = var6
		return durationTitle(var17)
	end

	return (tostring(arg1.Id))
end

tbl2.Validate = function()
	local var1 = tbl2.SchemaVersion
	local bool2 = false
	if typeof(var1) == "number" then
		bool2 = false
		if var1 == var1 then
			bool2 = false
			if var1 ~= math.huge then
				bool2 = false
				if 0 < var1 then
					bool2 = var1 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "SchemaVersion must be a positive integer")
	var1 = tbl2.MaxXPReward
	bool2 = false
	if typeof(var1) == "number" then
		bool2 = false
		if var1 == var1 then
			bool2 = false
			if var1 ~= math.huge then
				bool2 = false
				if 0 < var1 then
					bool2 = var1 % 1 == 0
				end
			end
		end
	end

	assert(bool2, "MaxXPReward must be a positive integer")
	bool2 = false
	if typeof(tbl2.ClaimCooldownSeconds) == "number" then
		bool2 = false
		if 0 <= tbl2.ClaimCooldownSeconds then
			bool2 = tbl2.ClaimCooldownSeconds < math.huge
		end
	end

	assert(bool2, "ClaimCooldownSeconds must be finite and non-negative")
	assert(0 < (#tbl2.Tracks), "At least one track is required")
	local tbl1 = {}
	bool2 = {}
	var1 = {}
	for k1, v1 in ipairs(tbl2.Tracks) do
		local bool3 = false
		if type(v1.Id) == "string" then
			bool3 = v1.Id ~= ""
		end

		assert(bool3, "Track needs Id")
		local var2 = v1.Id
		assert(not tbl1[v1.Id], ("Duplicate track Id %q"):format(var2))
		tbl1[v1.Id] = true
		bool3 = false
		if type(v1.DisplayName) == "string" then
			bool3 = v1.DisplayName ~= ""
		end

		var2 = v1.Id
		assert(bool3, ("%s needs DisplayName"):format(var2))
		bool3 = false
		if type(v1.DataKey) == "string" then
			bool3 = v1.DataKey ~= ""
		end

		var2 = v1.Id
		assert(bool3, ("%s needs DataKey"):format(var2))
		var2 = v1.DataKey
		assert(not bool2[v1.DataKey], ("Duplicate DataKey %q"):format(var2))
		bool2[v1.DataKey] = true
		local var3 = v1.SlotCount
		bool3 = false
		if typeof(var3) == "number" then
			bool3 = false
			if var3 == var3 then
				bool3 = false
				if var3 ~= math.huge then
					bool3 = false
					if 0 < var3 then
						bool3 = var3 % 1 == 0
					end
				end
			end
		end

		var2 = v1.Id
		assert(bool3, ("%s.SlotCount must be a positive integer"):format(var2))
		var3 = v1.ResetSeconds
		bool3 = false
		if typeof(var3) == "number" then
			bool3 = false
			if var3 == var3 then
				bool3 = false
				if var3 ~= math.huge then
					bool3 = false
					if 0 < var3 then
						bool3 = var3 % 1 == 0
					end
				end
			end
		end

		var2 = v1.Id
		assert(bool3, ("%s.ResetSeconds must be a positive integer"):format(var2))
		local var4 = tbl2.Definitions[v1.Id]
		local var5 = v1.Id
		assert(type(var4) == "table", ("No definitions for track %q"):format(var5))
		bool3 = 0
		for k2, v2 in ipairs(var4) do
			local bool4 = false
			if type(v2.Id) == "string" then
				bool4 = v2.Id ~= ""
			end

			local var6 = v1.Id
			local var7 = k2
			assert(bool4, ("%s definition #%d needs Id"):format(var6, var7))
			var6 = v2.Id
			assert(not var1[v2.Id], ("Duplicate quest Id %q"):format(var6))
			var1[v2.Id] = true
			var6 = v2.Id
			assert(type(v2.Enabled) == "boolean", ("%s.Enabled must be boolean"):format(var6))
			var6 = tostring(v2.Type)
			assert(tbl2.IsSupportedType(v2.Type), ("Unsupported quest type %q"):format(var6))
			local var8 = v2.Target
			bool4 = false
			if typeof(var8) == "number" then
				bool4 = false
				if var8 == var8 then
					bool4 = false
					if var8 ~= math.huge then
						bool4 = false
						if 0 < var8 then
							bool4 = var8 % 1 == 0
						end
					end
				end
			end

			var6 = v2.Id
			assert(bool4, ("%s.Target must be a positive integer"):format(var6))
			var6 = v2.Id
			assert(type(v2.Params) == "table", ("%s.Params must be a table"):format(var6))
			bool4 = false
			if typeof(v2.Weight) == "number" then
				bool4 = false
				if v2.Weight == v2.Weight then
					bool4 = false
					if 0 <= v2.Weight then
						bool4 = v2.Weight < math.huge
					end
				end
			end

			var6 = v2.Id
			assert(bool4, ("%s.Weight must be finite and non-negative"):format(var6))
			var8 = v2.XP
			bool4 = false
			if typeof(var8) == "number" then
				bool4 = false
				if var8 == var8 then
					bool4 = false
					if var8 ~= math.huge then
						bool4 = false
						if 0 < var8 then
							bool4 = var8 % 1 == 0
						end
					end
				end
			end

			var6 = v2.Id
			assert(bool4, ("%s.XP must be a positive integer"):format(var6))
			var6 = v2.Id
			assert(v2.XP <= tbl2.MaxXPReward, ("%s.XP exceeds MaxXPReward"):format(var6))
			if v2.Type == "SummonRarity" then
				bool4 = false
				if type(v2.Params.Rarity) == "string" then
					bool4 = v2.Params.Rarity ~= ""
				end

				var6 = v2.Id
				assert(bool4, ("%s needs non-empty Params.Rarity"):format(var6))
			else
				if v2.Type == "KillSpecificToilet" then
					bool4 = false
					if type(v2.Params.MobId) == "string" then
						bool4 = v2.Params.MobId ~= ""
					end

					var6 = v2.Id
					assert(bool4, ("%s needs non-empty Params.MobId"):format(var6))
				end
			end

			if v2.Enabled ~= true then
				continue
			end

			if 0 >= v2.Weight then
				continue
			end

			bool3 = bool3 + 1
		end

		local var9 = v1.Id
		local var10 = v1.SlotCount
		assert(v1.SlotCount <= bool3, ("Track %s needs at least %d enabled quests with Weight > 0"):format(var9, var10))
	end
end

return tbl2

--- ReplicatedStorage.Shared.GlobalEventConfig [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local tbl1 = {
	Enabled = true,
	CycleSeconds = 10800,
	StudioQuickTest = true,
	StudioCycleSeconds = 120,
	Events = {
		{
			Id = "Coins",
			DisplayName = "Coin Event",
			HoverTitle = "Global Event",
			HoverText = "Global x2 Coins",
			Icon = "rbxassetid://102505941801998",
			DurationSeconds = 1500,
			CoinMultiplier = 2,
			LuckMultiplier = 1,
		},
		{
			Id = "Luck",
			DisplayName = "Luck Event",
			HoverTitle = "Global Event",
			HoverText = "Global x1.5 Luck",
			Icon = "rbxassetid://78824015618357",
			DurationSeconds = 300,
			CoinMultiplier = 1,
			LuckMultiplier = 1.5,
		},
	},
	Attributes = {
		ActiveId = "GlobalEventId",
		ActiveStartedAt = "GlobalEventStartedAt",
		ActiveEndsAt = "GlobalEventEndsAt",
		NextId = "GlobalEventNextId",
		NextStartsAt = "GlobalEventNextStartsAt",
		CoinMultiplier = "GlobalEventCoinMultiplier",
		LuckMultiplier = "GlobalEventLuckMultiplier",
	},
}

tbl1.GetCycleSeconds = function()
	if tbl1.StudioQuickTest and var1:IsStudio() then
		return (math.max(30, tbl1.StudioCycleSeconds))
	end

	return (math.max(60, tbl1.CycleSeconds))
end

tbl1.Now = function()
	local success, result = pcall(function()
		return workspace:GetServerTimeNow()
	end)

	if success then
		local bool2 = false
		if typeof(result) == "number" then
			bool2 = false
			if result == result then
				bool2 = false
				if result ~= math.huge then
					bool2 = result ~= -math.huge
				end
			end
		end

		if bool2 then
			return result
		end
	end

	return os.time()
end

tbl1.GetById = function(arg1)
	if typeof(arg1) ~= "string" or arg1 == "" then
		return nil
	end

	for k1, v1 in ipairs(tbl1.Events) do
		if v1.Id ~= arg1 then
			continue
		end

		return v1
	end

	return nil
end

tbl1.GetEventForCycle = function(arg1)
	return tbl1.Events[arg1 % #tbl1.Events + 1]
end

tbl1.GetSchedule = function(arg1)
	local bool2 = false
	if typeof(arg1) == "number" then
		bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end
	end

	local var1 = if bool2 then arg1 else tbl1.Now()
	bool2 = tbl1.GetCycleSeconds()
	local var2 = math.floor(var1 / bool2)
	local var3 = tbl1.GetEventForCycle(var2)
	local var4 = var2 * bool2
	local var7 = tbl1.Enabled
	local var8 = var4 + math.clamp(var3.DurationSeconds, 0, bool2)
	if var7 then
		var7 = var1 < var8
	end

	local var9 = var4 + bool2
	local var10 = tbl1.GetEventForCycle(var2 + 1)
	return {
		Active = if var7 then var3 else nil,
		ActiveStartedAt = if var7 then var4 else 0,
		ActiveEndsAt = if var7 then var8 else 0,
		Next = var10,
		NextStartsAt = var9,
	}
end

tbl1.GetActiveEvent = function(arg1)
	return tbl1.GetSchedule(arg1).Active
end

tbl1.GetCoinMultiplier = function(arg1)
	local var2 = tbl1.GetActiveEvent(arg1)
	if not var2 then
		return 1
	end

	return (math.max(1, var2.CoinMultiplier))
end

tbl1.GetLuckMultiplier = function(arg1)
	local var2 = tbl1.GetActiveEvent(arg1)
	if not var2 then
		return 1
	end

	return (math.max(1, var2.LuckMultiplier))
end

return tbl1

--- ReplicatedStorage.Shared.EndRewardsConfig [ModuleScript]
-- y u r i

local str1 = "Event10MConfig"
local tbl1 = {
	Coins = "rbxassetid://74516079442282",
	Win = "rbxassetid://138375652479160",
	Lose = "rbxassetid://74266621389909",
	Xp = "rbxassetid://129521960793404",
	Tickets = "rbxassetid://80410844802074",
	Crate = "rbxassetid://115975950061415",
	Confetti = "rbxassetid://87227456385539",
	LimitedUnit = require(script.Parent:WaitForChild(str1)).LimitedUnit.Icon,
}

local tbl2 = { Icons = tbl1 }
tbl2.Rows = {
	{
		Id = "SummonDiscount",
		LayoutOrder = 60,
		Enabled = true,
		Icon = "rbxassetid://97393457754585",
		Prefix = "+",
		ShowOn = "Always",
		Amount = function(arg1)
			return arg1.SummonDiscount or 0
		end,
	},
	{
		Id = "Coins",
		LayoutOrder = 10,
		Enabled = true,
		Icon = tbl2.Icons.Coins,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Always",
		Amount = function(arg1)
			return arg1.Coins
		end,
	},
	{
		Id = "Result",
		LayoutOrder = 20,
		Enabled = true,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Always",
		IconFor = function(arg1)
			if arg1.IsWin then
				return tbl2.Icons.Win
			end

			return tbl2.Icons.Lose
		end,
		Amount = function(arg1)
			if arg1.IsEndless and (not arg1.IsWin) then
				return 0
			end

			return 1
		end,
	},
	{
		Id = "Xp",
		LayoutOrder = 30,
		Enabled = true,
		Icon = tbl2.Icons.Xp,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Always",
		Amount = function(arg1)
			return arg1.Xp
		end,
	},
	{
		Id = "Tickets",
		LayoutOrder = 40,
		Enabled = true,
		Icon = tbl2.Icons.Tickets,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Win",
		Amount = function(arg1)
			return arg1.Tickets
		end,
	},
	{
		Id = "Crates",
		LayoutOrder = 50,
		Enabled = true,
		Icon = tbl2.Icons.Crate,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Win",
		Amount = function(arg1)
			return arg1.Crates
		end,
	},
	{
		Id = "Confetti",
		LayoutOrder = 70,
		Enabled = true,
		Icon = tbl2.Icons.Confetti,
		Prefix = "+",
		HideWhenZero = true,
		ShowOn = "Win",
		Amount = function(arg1)
			return arg1.Confetti or 0
		end,
	},
	{
		Id = "LimitedUnit",
		LayoutOrder = 5,
		Enabled = true,
		Icon = tbl2.Icons.LimitedUnit,
		HideWhenZero = true,
		ShowOn = "Win",
		Amount = function(arg1)
			if type(arg1.LimitedUnit) == "string" and arg1.LimitedUnit ~= "" then
				return 1
			end

			return 0
		end,
		Text = function(_, _)
			return "LIMITED!"
		end,
	},
}

tbl2.Maps = {
	City = { Rows = { Tickets = { Enabled = false }, Crates = { Enabled = false } } },
	Canyon = { Rows = { Tickets = { Enabled = false }, Crates = { Enabled = false } } },
	WildDesert = { Rows = { Tickets = { Enabled = false }, Crates = { Enabled = false } } },
	["Camera Lab"] = { Rows = { Tickets = { Enabled = false } } },
	ToiletBunker = { Rows = { Crates = { Enabled = false } } },
	Endless = { Rows = {
		Tickets = { Enabled = true, ShowOn = "Always" },
		Crates = { Enabled = true, ShowOn = "Always" },
	} },
}

tbl2.Get = function(arg1)
	local var1 = if type(arg1) == "string" then tbl2.Maps[arg1] else nil
	local var2 = if type(var1) == "table" then var1.Rows else nil
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.Rows) do
		local var4 = table.clone(v1)
		local var5
		local var6
		if var2 then
			local var7 = var2[var4.Id]
	if type(var7) == "table" then
				for k2, v2 in pairs(var7) do
					var4[k2] = v2
				end
			end
		end

		if var4.Enabled == false then
			continue
		end

		table.insert(tbl1, var4)
	end

	if type(var1) == "table" and type(var1.Extra) == "table" then
		for k3, v3 in ipairs(var1.Extra) do
			local var8 = table.clone(v3)
			if var8.Enabled == false then
				continue
			end

			table.insert(tbl1, var8)
		end
	end

	table.sort(tbl1, function(arg1, arg2)
		if arg1.LayoutOrder == arg2.LayoutOrder then
			return arg1.Id < arg2.Id
		end

		return arg1.LayoutOrder < arg2.LayoutOrder
	end)

	return tbl1
end

tbl2.Build = function(arg1, arg2)
	local var1 = arg1
	local tbl1 = {}
	for k1, v1 in ipairs(tbl2.Get(var1)) do
		local var2 = v1.Amount
		if type(var2) == "function" then
			local success, result = pcall(var2, arg2)
			local var3
			if not success then
				var3 = 0
			else
				success = tonumber(result)
				var3 = if success == nil or success ~= success then 0 else success
			end
		end

		local var5 = v1.ShowOn or "Always"
		if var5 == "Win" and (not arg2.IsWin) then
			var2 = false
		else
			if var5 == "Lose" and arg2.IsWin then
				var2 = false
			else
				var2 = if v1.HideWhenZero ~= false and var3 <= 0 then false else true
			end
		end

		if not var2 then
			continue
		end

		var2 = nil
		if type(v1.Text) == "function" then
			local success, result = pcall(v1.Text, arg2, var3)
			var2 = if success and type(result) == "string" then result else nil
		end

		if var2 == nil then
			var2 = (v1.Prefix or "") .. tostring((math.floor(var3))) .. (v1.Suffix or "")
		end

		local success, result = pcall(v1.IconFor, arg2)
		success = v1.Icon or ""
		if type(v1.IconFor) == "function" and (success and type(result) == "string") then
			success = result
		end

		local tbl3 = { Id = v1.Id, LayoutOrder = v1.LayoutOrder, Icon = success, Text = var2, Amount = var3 }
		table.insert(tbl1, tbl3)
	end

	return tbl1
end

return tbl2

--- ReplicatedStorage.Shared.PlacementConfig [ModuleScript]
-- y u r i

local tbl1 = {
	Enabled = true,
	DefaultRadius = 2.5,
	Radii = {
		["Builder Camera Man"] = 1.75,
		["Camera Helicopter"] = 1.75,
		["Camera Man"] = 1.75,
		["Camera Woman"] = 1.75,
		["DJ Speaker Man"] = 3,
		["Dark Speaker Man"] = 1.75,
		["Engineer Camera Man"] = 1.75,
		["Jester Speaker Man"] = 1.75,
		["Large Camera Man"] = 2,
		["Large Scientist Camera Man"] = 2,
		["Large Speaker Man"] = 2,
		["Large TV Man"] = 2,
		["Party Camera Man"] = 1.75,
		["Party Titan TV Man"] = 3,
		["Plunger Camera Man"] = 1.75,
		["Scientist Camera Man"] = 1.75,
		["Speaker Man"] = 1.75,
		["Speaker Woman"] = 1.75,
		["TV Man"] = 1.75,
		["TV Woman"] = 1.75,
		["Titan Camera Man"] = 2.5,
		["Titan Cinema Man"] = 2.5,
		["Titan Speaker Man"] = 2.5,
		["Titan Speaker Man 2.0"] = 3,
		["Titan TV Man"] = 2.5,
		["Upgraded Titan Camera Man"] = 3,
		["10M Titan Speaker Man"] = 3,
		["Present Camera Man"] = 1.75,
		["10M Camera Man"] = 1.75,
		["10M TV Woman"] = 1.75,
		["10M Speaker Man"] = 1.75,
	},
	OverlapMode = "Sum",
	ShowAlways = false,
	SurfaceOffset = 0.05,
	Color = Color3.fromRGB(255, 70, 70),
}

tbl1.Transparency = 0.5
tbl1.ImageColor = Color3.fromRGB(255, 90, 90)
tbl1.PreviewAllowedColor = Color3.fromRGB(90, 255, 120)
tbl1.PreviewAllowedImageColor = Color3.fromRGB(120, 255, 150)
tbl1.PreviewBlockedColor = Color3.fromRGB(255, 60, 60)
tbl1.PreviewBlockedImageColor = Color3.fromRGB(255, 80, 80)
tbl1.PreviewTransparency = 0.35
tbl1.BlockedMessage = "Too Close To Another Unit!"
tbl1.GetRadius = function(arg1)
	local var1 = arg1
	if typeof(arg1) == "Instance" then
		local var2 = arg1:GetAttribute("UnitId")
		var1 = if typeof(var2) == "string" and var2 ~= "" then var2 else arg1.Name
	end

	local var3
	if typeof(var1) == "string" then
		local var5 = tonumber(tbl1.Radii[var1])
		if var5 == nil or (var5 ~= var5 or (var5 == math.huge or var5 == -math.huge)) then
			var3 = nil
		else
			var3 = var5
		end
	else
		var3 = nil
	end

	if var3 == nil then
		local var7 = tonumber(tbl1.DefaultRadius)
		var3 = (if var7 == nil or (var7 ~= var7 or (var7 == math.huge or var7 == -math.huge)) then nil else var7) or 0
	end

	return (math.max(0, var3))
end

tbl1.GetMinDistance = function(arg1, arg2)
	local var2 = tonumber(arg1)
	local num1 = 0
	local var4 = tonumber(arg2)
	local var5 = math.max(num1, (if var2 == nil or (var2 ~= var2 or (var2 == math.huge or var2 == -math.huge)) then nil else var2) or 0)
	local num2 = 0
	num1 = math.max(num2, (if var4 == nil or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then nil else var4) or 0)
	if tbl1.OverlapMode == "Max" then
		return (math.max(var5, num1))
	end

	return var5 + num1
end

tbl1.GetTowerPosition = function(arg1)
	if not arg1:IsA("Model") then
		return nil
	end

	local var2 = arg1.PrimaryPart
	if var2 then
		return var2.Position
	end

	local success, result = pcall(function()
		return arg1:GetPivot()
	end)

	if success and typeof(result) == "CFrame" then
		return result.Position
	end

	return nil
end

tbl1.FindBlockingTower = function(arg1, arg2, arg3, arg4)
	if not tbl1.Enabled then
		return nil
	end

	if typeof(arg1) ~= "Vector3" then
		return nil
	end

	for k1, v1 in ipairs(arg3) do
		if v1 == arg4 then
			continue
		end

		if not v1:IsA("Model") then
			continue
		end

		local var1 = tbl1.GetTowerPosition(v1)
		if not var1 then
			continue
		end

		local var2 = tbl1.GetMinDistance(arg2, (tbl1.GetRadius(v1)))
		if 0 >= var2 then
			continue
		end

		if Vector3.new(arg1.X - var1.X, 0, arg1.Z - var1.Z).Magnitude >= var2 then
			continue
		end

		return v1
	end

	return nil
end

tbl1.IsBlocked = function(arg1, arg2, arg3, arg4)
	return tbl1.FindBlockingTower(arg1, arg2, arg3, arg4) ~= nil
end

return tbl1

--- ReplicatedStorage.Shared.Event10MConfig [ModuleScript]
-- y u r i

local tbl1 = { 100 }
tbl1[3] = 300
tbl1[10] = 900
local tbl2 = {
	Enabled = true,
	Currency = { Key = "EventTokens", DisplayName = "Confetti", Symbol = "\240\159\142\137" },
	Prices = {
		LuckyBlockI = { 100 },
		LuckyBlockII = { 400 },
		LuckyBlockIII = { 1000 },
		["10MCrate"] = tbl1,
	},
	WinConfetti = { Easy = 25, Medium = 45, Hard = 65, Insane = 90, Crazy = 125, Endless = 0 },
	EndlessConfettiPerWave = 2,
}

tbl2.LimitedUnit = {
	Enabled = true,
	UnitName = "10M Speaker Man",
	Rarity = "Event",
	Icon = "rbxassetid://72134910652720",
	Price = 100,
	HasDPS = true,
	IsAoe = false,
	MaxSupply = 75000,
	WinChances = { Easy = 0.05, Medium = 0.1, Hard = 0.2, Insane = 0.35, Crazy = 0.5 },
	ModeOrder = { "Easy", "Medium", "Hard", "Insane", "Crazy" },
	SupplyStore = "Event10MLimitedSupply_v1",
	InventoryLimit = 500,
	ReserveTimeoutSeconds = 10,
	Settings = { IsInSummon = true, TradeAble = true, SellAble = true },
}

tbl2.GetWinConfetti = function(arg1)
	if not tbl2.Enabled or type(arg1) ~= "string" then
		return 0
	end

	local var2 = tonumber(tbl2.WinConfetti[arg1]) or 0
	if var2 ~= var2 or (var2 <= 0 or var2 == math.huge) then
		return 0
	end

	return (math.floor(var2))
end

tbl2.GetEndlessWaveConfetti = function()
	if not tbl2.Enabled then
		return 0
	end

	local var2 = tonumber(tbl2.EndlessConfettiPerWave) or 0
	if var2 ~= var2 or (var2 <= 0 or var2 == math.huge) then
		return 0
	end

	return (math.floor(var2))
end

tbl2.GetLimitedChance = function(arg1)
	local var2 = tbl2.LimitedUnit
	if not tbl2.Enabled or (not var2.Enabled or type(arg1) ~= "string") then
		return 0
	end

	local var4 = tonumber(var2.WinChances[arg1]) or 0
	if var4 ~= var4 or var4 <= 0 then
		return 0
	end

	return (math.min(var4, 100))
end

return tbl2

--- ReplicatedStorage.Modules.TowerMuzzleConfig [ModuleScript]
-- y u r i

local tbl1 = { Color = Color3.fromRGB(255, 214, 138), Brightness = 6, Range = 14, Duration = 0.07 }
local tbl2 = {
	DefaultStates = { Attack = true },
	Units = { ["Camera Man"] = {
		Sources = { { PartName = "Cube.086", AttachmentName = "Attachment" } },
		States = { Attack = true },
		BurstTime = 0.2,
		MinEmit = 3,
		MaxEmit = 40,
		EmitCounts = { Smoke = 6, flare = 4, shockwave = 1, shockwave2 = 1 },
		Light = tbl1,
		Cooldown = 0.05,
	} },
}

tbl2.get = function(arg1)
	if typeof(arg1) ~= "string" or arg1 == "" then
		return nil
	end

	local var1 = tbl2.Units[arg1]
	if typeof(var1) ~= "table" or typeof(var1.Sources) ~= "table" then
		return nil
	end

	return var1
end

tbl2.handlesState = function(arg1, arg2)
	if typeof(arg1) ~= "table" or typeof(arg2) ~= "string" then
		return false
	end

	local var1 = arg1.States
	return (var1 or tbl2.DefaultStates)[arg2] == true
end

return tbl2

--- ReplicatedStorage.Modules.TowerAmmoConfig [ModuleScript]
-- y u r i

local tbl1 = {
	DefaultReloadState = "Reload",
	Units = { ["Camera Man"] = { MagazineSize = 6, ReloadTime = 2 } },
}

tbl1.get = function(arg1, arg2)
	if typeof(arg1) ~= "string" or arg1 == "" then
		return nil
	end

	local var1 = tbl1.Units[arg1]
	if typeof(var1) ~= "table" then
		return nil
	end

	local var2 = var1.MagazineSize
	local var3 = var1.ReloadTime
	local var4 = if typeof(var2) ~= "number" or (var2 ~= var2 or (var2 <= 0 or var2 == math.huge)) then 0 else var2
	local var5 = var1.Levels
	var2 = if typeof(var3) ~= "number" or (var3 ~= var3 or (var3 <= 0 or var3 == math.huge)) then 0 else var3
	var3 = var1.ReloadState
	if typeof(var5) == "table" then
		if typeof(arg2) == "number" then
			local var6 = var5[math.max(1, (math.floor(arg2)))]
			if typeof(var6) == "table" then
				local var7 = var6.MagazineSize
				local var8 = var4
				var7 = var6.ReloadTime
				var4 = if typeof(var7) ~= "number" or (var7 ~= var7 or (var7 <= 0 or var7 == math.huge)) then var8 else var7
				var8 = var2
				var2 = if typeof(var7) ~= "number" or (var7 ~= var7 or (var7 <= 0 or var7 == math.huge)) then var8 else var7
				var3 = var6.ReloadState or var3
			end
		end
	end

	if var4 < 1 then
		return nil
	end

	local tbl2 = { MagazineSize = math.floor(var4) }
	tbl2.ReloadTime = math.max(0, var2)
	local var9 = if typeof(var3) == "string" and var3 ~= "" then var3 else tbl1.DefaultReloadState
	tbl2.ReloadState = var9
	return tbl2
end

tbl1.has = function(arg1)
	return tbl1.get(arg1, 1) ~= nil
end

return tbl1

--- ReplicatedStorage.Modules.TowerAmmo [ModuleScript]
-- y u r i

local str1 = "TowerAmmoConfig"
local var1 = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild(str1))
local tbl1 = {
	MaxAttribute = "AmmoMax",
	CurrentAttribute = "AmmoCurrent",
	ReloadingAttribute = "AmmoReloading",
	ReloadEndsAtAttribute = "AmmoReloadEndsAt",
	getSettings = function(arg1)
		local bool2 = false
		if typeof(arg1) == "Instance" then
			bool2 = arg1:IsA("Model")
		end

		if not bool2 then
			return nil
		end

		local var2 = arg1:GetAttribute("UnitId")
		bool2 = var1.get
		local var3 = arg1:GetAttribute("Level")
		local var4 = if typeof(var2) == "string" and var2 ~= "" then var2 else arg1.Name
		var2 = if typeof(var3) == "number" and var3 == var3 then math.max(1, (math.floor(var3))) else 1
		return bool2(var4, var2)
	end,
}

tbl1.isEnabled = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return false
	end

	local var1 = arg1:GetAttribute(tbl1.MaxAttribute)
	if 0 < (if typeof(var1) ~= "number" or var1 ~= var1 then 0 else var1) then
		return true
	end

	return tbl1.getSettings(arg1) ~= nil
end

tbl1.getMax = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return 0
	end

	local var1 = arg1:GetAttribute(tbl1.MaxAttribute)
	bool2 = if typeof(var1) ~= "number" or var1 ~= var1 then 0 else var1
	if 0 < bool2 then
		return (math.floor(bool2))
	end

	local var3 = tbl1.getSettings(arg1)
	if var3 then
		return var3.MagazineSize
	end

	return 0
end

tbl1.getCurrent = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return 0
	end

	local var1 = arg1:GetAttribute(tbl1.CurrentAttribute)
	local num1 = 0
	return (math.max(num1, (math.floor(if typeof(var1) ~= "number" or var1 ~= var1 then 0 else var1))))
end

tbl1.isReloading = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return false
	end

	return arg1:GetAttribute(tbl1.ReloadingAttribute) == true
end

tbl1.getReloadRemaining = function(arg1)
	if not tbl1.isReloading(arg1) then
		return 0
	end

	local var1 = arg1:GetAttribute(tbl1.ReloadEndsAtAttribute)
	local var3 = if typeof(var1) ~= "number" or var1 ~= var1 then 0 else var1
	if var3 <= 0 then
		return 0
	end

	return (math.max(0, var3 - workspace:GetServerTimeNow()))
end

tbl1.format = function(arg1)
	local var1 = arg1
	local str1 = "%d / %d"
	local var2 = tbl1.getCurrent(arg1)
	return string.format(str1, var2, tbl1.getMax(var1))
end

tbl1.apply = function(arg1, arg2, arg3)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return
	end

	local var3 = arg2
	bool2 = var1.get
	if not var3 then
		local var4 = arg1:GetAttribute("UnitId")
		var3 = if typeof(var4) == "string" and var4 ~= "" then var4 else arg1.Name
	end

	local var6 = arg3
	if not var6 then
		local var7 = arg1:GetAttribute("Level")
		var6 = if typeof(var7) == "number" and var7 == var7 then math.max(1, (math.floor(var7))) else 1
	end

	bool2 = bool2(var3, var6)
	if not bool2 then
		arg1:SetAttribute(tbl1.MaxAttribute, nil)
		arg1:SetAttribute(tbl1.CurrentAttribute, nil)
		arg1:SetAttribute(tbl1.ReloadingAttribute, nil)
		arg1:SetAttribute(tbl1.ReloadEndsAtAttribute, nil)
		return
	end

	arg1:SetAttribute(tbl1.MaxAttribute, bool2.MagazineSize)
	arg1:SetAttribute(tbl1.CurrentAttribute, bool2.MagazineSize)
	arg1:SetAttribute(tbl1.ReloadingAttribute, false)
	arg1:SetAttribute(tbl1.ReloadEndsAtAttribute, 0)
end

tbl1.getReloadTime = function(arg1)
	local var2 = tbl1.getSettings(arg1)
	if var2 then
		return var2.ReloadTime
	end

	return 0
end

tbl1.getReloadState = function(arg1)
	local var3 = tbl1.getSettings(arg1)
	if var3 and var3.ReloadState then
		return var3.ReloadState
	end

	return var1.DefaultReloadState
end

tbl1.consume = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return true
	end

	if not tbl1.isEnabled(arg1) then
		return true
	end

	bool2 = tbl1.getCurrent(arg1)
	if bool2 <= 0 then
		return false
	end

	arg1:SetAttribute(tbl1.CurrentAttribute, bool2 - 1)
	return true
end

tbl1.beginReload = function(arg1, arg2)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return
	end

	arg1:SetAttribute(tbl1.ReloadingAttribute, true)
	arg1:SetAttribute(tbl1.ReloadEndsAtAttribute, workspace:GetServerTimeNow() + (if typeof(arg2) == "number" and (arg2 == arg2 and 0 < arg2) then arg2 else 0))
end

tbl1.finishReload = function(arg1)
	local bool2 = false
	if typeof(arg1) == "Instance" then
		bool2 = arg1:IsA("Model")
	end

	if not bool2 then
		return
	end

	local var1 = arg1
	arg1:SetAttribute(tbl1.CurrentAttribute, tbl1.getMax(var1))
	arg1:SetAttribute(tbl1.ReloadingAttribute, false)
	arg1:SetAttribute(tbl1.ReloadEndsAtAttribute, 0)
end

return tbl1

--- ReplicatedStorage.Modules.TowerRangeColorConfig [ModuleScript]
-- y u r i

local tbl1 = { Circle = Color3.fromRGB(253, 254, 255), Transparency = 0.7 }
tbl1.Image = Color3.fromRGB(255, 255, 255)
local tbl2 = { Selected = tbl1 }
tbl1 = { Circle = Color3.fromRGB(170, 255, 0), Transparency = 0.7 }
tbl1.Image = Color3.fromRGB(106, 255, 65)
tbl2.Allowed = tbl1
tbl1 = { Circle = Color3.fromRGB(255, 0, 0), Transparency = 0.7 }
tbl1.Image = Color3.fromRGB(255, 32, 73)
tbl2.Blocked = tbl1
local tbl3 = { Default = tbl2 }
local tbl4 = { Circle = Color3.fromRGB(0, 170, 255) }
tbl4.Image = Color3.fromRGB(0, 170, 255)
tbl4.HandCircle = Color3.fromRGB(0, 255, 255)
tbl4.HandImage = Color3.fromRGB(85, 255, 255)
tbl2 = { ["10M Upgraded Titan Speakerman"] = { Selected = tbl4 } }
tbl4 = { Circle = Color3.fromRGB(255, 87, 87) }
tbl4.Image = Color3.fromRGB(255, 44, 44)
tbl4.HandCircle = Color3.fromRGB(170, 0, 255)
tbl4.HandImage = Color3.fromRGB(133, 0, 200)
tbl2["Titan Cinema Man"] = { Selected = tbl4 }
tbl4 = { Circle = Color3.fromRGB(0, 170, 255) }
tbl4.Image = Color3.fromRGB(0, 170, 255)
tbl4.HandCircle = Color3.fromRGB(255, 155, 55)
tbl4.HandImage = Color3.fromRGB(255, 155, 55)
tbl2["Upgraded Titan Camera Man"] = { Selected = tbl4 }
tbl3.Units = tbl2
tbl2 = { Selected = true, Allowed = true, Blocked = true }
tbl3.Get = function(arg1, arg2)
	local var1 = tbl3.Default
	local var2 = if type(arg2) == "string" and tbl2[arg2] then arg2 else "Selected"
	local var3
	if type(var1) ~= "table" then
		var3 = nil
	else
		local var4 = var1[var2]
		var3 = if type(var4) ~= "table" then nil else var4
	end

	if not var3 then
		var1 = tbl3.Default
		if type(var1) ~= "table" then
			var3 = nil
		else
			local var5 = var1.Selected
			var3 = if type(var5) ~= "table" then nil else var5
		end

		var3 = var3 or {}
	end

	var1 = nil
	if type(arg1) == "string" then
		if arg1 ~= "" then
			local var6 = tbl3.Units[arg1]
			if type(var6) ~= "table" then
				var1 = nil
			else
				local var7 = var6[var2]
				var1 = if type(var7) ~= "table" then nil else var7
			end
		end
	end

	local function resolve(arg1, arg2)
		local var2
		if var1 then
			for k1, v1 in ipairs(arg1) do
				if not (typeof(var1[v1]) == "Color3") then
					continue
				end

				return var1[v1]
			end
		end

		for k2, v2 in ipairs(arg1) do
			if not (typeof(var3[v2]) == "Color3") then
				continue
			end

			return var3[v2]
		end

		return arg2
	end

	local num1 = 255
	local num2 = 255
	local num3 = 255
	local var8 = resolve({ "Circle" }, Color3.fromRGB(num1, num2, num3))
	num3 = var3.Transparency
	local var9 = resolve({ "Image", "Circle" }, var8)
	local var10 = resolve({ "HandCircle", "Circle" }, var8)
	num1 = 0.7
	num2 = false
	if typeof(num3) == "number" then
		num2 = false
		if num3 == num3 then
			num2 = false
			if 0 <= num3 then
				num2 = num3 <= 1
			end
		end
	end

	if num2 then
		num1 = var3.Transparency
	end

	if var1 then
		num3 = var1.Transparency
		num2 = false
		if typeof(num3) == "number" then
			num2 = false
			if num3 == num3 then
				num2 = false
				if 0 <= num3 then
					num2 = num3 <= 1
				end
			end
		end

		if num2 then
			num1 = var1.Transparency
		end
	end

	num2 = { Circle = var8, Image = var9, Cone = resolve({ "Cone", "Image", "Circle" }, var9) }
	num2.Transparency = num1
	num2.HandCircle = var10
	num2.HandImage = resolve({ "HandImage", "HandCircle", "Image", "Circle" }, var10)
	return num2
end

tbl3.HasOverride = function(arg1)
	local bool2 = false
	if type(arg1) == "string" then
		bool2 = false
		if arg1 ~= "" then
			bool2 = type(tbl3.Units[arg1]) == "table"
		end
	end

	return bool2
end

tbl3.Units["10M Titan Speaker Man"] = tbl3.Units["10M Upgraded Titan Speakerman"]
return tbl3

--- ReplicatedStorage.Modules.TowerBoosterConfig [ModuleScript]
-- y u r i

local tbl1 = {
	Stacking = "Best",
	SupportType = "Booster",
	Units = { ["DJ Speaker Man"] = {
		{ DamageBonus = 0.1, RangeBonus = 0.05, CooldownReduction = 0.05 },
		{ DamageBonus = 0.15, RangeBonus = 0.08, CooldownReduction = 0.1 },
		{ DamageBonus = 0.2, RangeBonus = 0.1, CooldownReduction = 0.15 },
		{ DamageBonus = 0.25, RangeBonus = 0.12, CooldownReduction = 0.2 },
	} },
	MinCooldownMultiplier = 0.35,
	MaxDamageMultiplier = 5,
	MaxRangeMultiplier = 3,
}

tbl1.isBooster = function(arg1)
	if typeof(arg1) == "Instance" then
		local var1 = arg1:GetAttribute("UnitId")
		arg1 = if typeof(var1) == "string" and var1 ~= "" then var1 else arg1.Name
	end

	local bool1 = false
	if typeof(arg1) == "string" then
		bool1 = tbl1.Units[arg1] ~= nil
	end

	return bool1
end

tbl1.get = function(arg1, arg2)
	local var2 = tbl1.Units[arg1]
	if not var2 then
		return nil
	end

	local num1 = 1
	local var3 = math.max(num1, (math.floor(if typeof(arg2) ~= "number" or (arg2 ~= arg2 or (arg2 == math.huge or arg2 == -math.huge)) then 1 else arg2)))
	num1 = nil
	for i1 = 1, var3 do
		if not var2[i1] then
			continue
		end

		num1 = var2[i1]
	end

	local var4 = num1
	return var4 or var2[1]
end

tbl1.getMaxLevel = function(arg1)
	local var2 = tbl1.Units[arg1]
	if not var2 then
		return 0
	end

	local num1 = 1
	for k1 in pairs(var2) do
		if num1 >= k1 then
			continue
		end

		num1 = k1
	end

	return num1
end

tbl1.formatPercent = function(arg1, arg2)
	local var1 = (if typeof(arg1) ~= "number" or (arg1 ~= arg1 or (arg1 == math.huge or arg1 == -math.huge)) then 0 else arg1) * 100
	if arg2 then
		var1 = -var1
	end

	local var2 = string.format("%.1f", math.floor(math.abs(var1) * 10 + 0.5) / 10):gsub("%.0$", "")
	return (if var1 < 0 then "-" else "+") .. var2 .. "%"
end

local tbl2 = { DamageBonus = 0, RangeBonus = 0, CooldownReduction = 0 }
tbl1.formatLevel = function(arg1)
	local var1 = arg1
	var1 = var1 or tbl2
	local var2 = var1.CooldownReduction
	local bool1 = true
	return tbl1.formatPercent(var1.DamageBonus), tbl1.formatPercent(var1.RangeBonus), tbl1.formatPercent(var2, bool1)
end

tbl1.neutralMultipliers = function()
	return 1, 1, 1
end

tbl1.combine = function(arg1, arg2, arg3, arg4)
	if not arg4 then
		return arg1, arg2, arg3
	end

	local var1 = arg4.DamageBonus
	local num1 = 0
	local var2 = arg4.RangeBonus
	local var3 = math.max(num1, if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then 0 else var1) + 1
	local num2 = 0
	var2 = arg4.CooldownReduction
	local var4 = math.max(num2, if typeof(var2) ~= "number" or (var2 ~= var2 or (var2 == math.huge or var2 == -math.huge)) then 0 else var2) + 1
	num1 = 1 - math.clamp(if typeof(var2) ~= "number" or (var2 ~= var2 or (var2 == math.huge or var2 == -math.huge)) then 0 else var2, 0, 0.95)
	if tbl1.Stacking == "Sum" then
		arg1 = arg1 + (var3 - 1)
		arg2 = arg2 + (var4 - 1)
		arg3 = arg3 - (1 - num1)
	else
		arg1 = math.max(arg1, var3)
		arg2 = math.max(arg2, var4)
		arg3 = math.min(arg3, num1)
	end

	var1 = arg1
	var2 = arg2
	local var5 = arg3
	return tbl1.clampMultipliers(var1, var2, var5)
end

tbl1.clampMultipliers = function(arg1, arg2, arg3)
	local var1 = math.clamp(if typeof(arg1) ~= "number" or (arg1 ~= arg1 or (arg1 == math.huge or arg1 == -math.huge)) then 1 else arg1, 1, tbl1.MaxDamageMultiplier)
	local var2 = math.clamp(if typeof(arg2) ~= "number" or (arg2 ~= arg2 or (arg2 == math.huge or arg2 == -math.huge)) then 1 else arg2, 1, tbl1.MaxRangeMultiplier)
	return var1, var2, (math.clamp(if typeof(arg3) ~= "number" or (arg3 ~= arg3 or (arg3 == math.huge or arg3 == -math.huge)) then 1 else arg3, tbl1.MinCooldownMultiplier, 1))
end

tbl1.readMultipliers = function(arg1)
	if not arg1 then
		return 1, 1, 1
	end

	local var1 = arg1:GetAttribute("BoostDamageMult")
	local var2 = tbl1.clampMultipliers
	local var3 = arg1:GetAttribute("BoostRangeMult")
	local var4 = if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then 1 else var1
	local var5 = arg1:GetAttribute("BoostCooldownMult")
	var1 = if typeof(var3) ~= "number" or (var3 ~= var3 or (var3 == math.huge or var3 == -math.huge)) then 1 else var3
	var3 = if typeof(var5) ~= "number" or (var5 ~= var5 or (var5 == math.huge or var5 == -math.huge)) then 1 else var5
	return var2(var4, var1, var3)
end

tbl1.isBoosted = function(arg1)
	local var4, var5, var6 = tbl1.readMultipliers(arg1)
	local bool2 = true
	if 1.0001 >= var4 then
		bool2 = true
		if 1.0001 >= var5 then
			bool2 = var6 < 0.9999
		end
	end

	return bool2
end

tbl1.applyToStats = function(arg1, arg2, arg3, arg4)
	local var1, var2, var3 = tbl1.readMultipliers(arg1)
	local var4 = (if typeof(arg2) ~= "number" or (arg2 ~= arg2 or (arg2 == math.huge or arg2 == -math.huge)) then 0 else arg2) * var1
	local var5 = (if typeof(arg3) ~= "number" or (arg3 ~= arg3 or (arg3 == math.huge or arg3 == -math.huge)) then 0 else arg3) * var2
	return var4, var5, (if typeof(arg4) ~= "number" or (arg4 ~= arg4 or (arg4 == math.huge or arg4 == -math.huge)) then 1 else arg4) * var3
end

for k1, v1 in pairs(tbl1.Units) do
	for k2, v2 in pairs(v1) do
		table.freeze(v2)
	end

	table.freeze(v1)
end

table.freeze(tbl1.Units)
return tbl1

--- ReplicatedStorage.Modules.TowerBurnConfig [ModuleScript]
-- y u r i

local tbl1 = { Units = { ["TV Woman"] = {
	{ DamagePerTick = 12, TickInterval = 0.5, Duration = 3 },
	{ DamagePerTick = 18, TickInterval = 0.45, Duration = 3.5 },
	{ DamagePerTick = 27, TickInterval = 0.4, Duration = 4 },
	{ DamagePerTick = 40, TickInterval = 0.35, Duration = 4.5 },
} } }

tbl1.get = function(arg1, arg2)
	local var2 = tbl1.Units[arg1]
	if not var2 then
		return nil
	end

	local var3 = nil
	for i1 = 1, math.max(1, (math.floor(arg2))) do
		if not var2[i1] then
			continue
		end

		var3 = var2[i1]
	end

	return var3
end

return tbl1

--- ReplicatedStorage.Modules.TowerAbilityConfig [ModuleScript]
-- y u r i

local num1 = 35
local tbl1 = {
	DisplayName = "Core Barrage",
	Icon = "rbxassetid://91321590732869",
	MinLevel = 1,
	Price = 3000,
	Cooldown = 60,
	DamagePerProjectile = 250,
	ProjectileCount = 40,
	BurstInterval = 0.015,
	ProjectileSpeed = 200,
	ProjectileSize = 1,
	ProjectileColor = Color3.fromRGB(255, 35, 35),
	NormalProjectileSpeed = 175,
	NormalProjectileSize = 0.72,
	Range = 80,
}

tbl1.NormalProjectileColor = Color3.fromRGB(255, num1, 35)
local tbl2 = { Units = { ["Titan Speaker Man 2.0"] = tbl1 } }
tbl2.get = function(arg1, arg2)
	local var2 = tbl2.Units[arg1]
	if not var2 or arg2 < var2.MinLevel then
		return nil
	end

	return var2
end

for k1, v1 in pairs(tbl2.Units) do
	table.freeze(v1)
end

table.freeze(tbl2.Units)
tbl1 = tbl2
return table.freeze(tbl1)

--- ReplicatedStorage.Modules.BoostConfig [ModuleScript]
-- y u r i

local num1 = 255
local tbl1 = {
	DisplayName = "Double XP",
	Description = "x2 XP",
	ShopDescription = "Double XP Last 1 Hour!",
	Icon = "rbxassetid://89533088608490",
	BackgroundColor = Color3.fromRGB(40, 210, num1),
	DurationSeconds = 3600,
	Multiplier = 2,
	RemainingField = "XPTimeRemaining",
	LegacyEndsAtField = "XPEndsAt",
	PlayerAttribute = "XPBoostTimeRemaining",
}

local tbl2 = { XP = tbl1 }
tbl2.Money = {
	DisplayName = "Coin Potion",
	Description = "x2 Coins",
	Icon = "rbxassetid://84869454803634",
	DurationSeconds = 2100,
	Multiplier = 2,
	RemainingField = "MoneyTimeRemaining",
	LegacyEndsAtField = "MoneyEndsAt",
	PlayerAttribute = "MoneyBoostTimeRemaining",
}

tbl2.Luck = {
	DisplayName = "Luck Potion",
	Description = "x2 Luck",
	Icon = "rbxassetid://139042882458711",
	DurationSeconds = 900,
	Multiplier = 2,
	RemainingField = "LuckTimeRemaining",
	LegacyEndsAtField = "LuckEndsAt",
	PlayerAttribute = "LuckBoostTimeRemaining",
}

tbl2.SummonDiscount = {
	DisplayName = "Summon Discount",
	Description = "-15% Summon Cost",
	Icon = "rbxassetid://97393457754585",
	DurationSeconds = 300,
	Multiplier = 0.85,
	DiscountPercent = 15,
	RemainingField = "SummonDiscountTimeRemaining",
	LegacyEndsAtField = "SummonDiscountEndsAt",
	PlayerAttribute = "SummonDiscountBoostTimeRemaining",
}

for k1, v1 in pairs(tbl2) do
	table.freeze(v1)
end

local var1 = tbl2
return table.freeze(var1)

--- ReplicatedStorage.Modules.TowerAnimationConfig [ModuleScript]
-- y u r i

local str1 = "PresentGiftConfig"
local var1 = require(script.Parent:WaitForChild(str1))
str1 = {
	PartNames = { "Cube.232" },
	AttackColor = Color3.fromRGB(255, 76, 70),
	AttackTime = 0.08,
	IdleTime = 0.3,
}

str1.IdleColor = Color3.fromRGB(67, 67, 74)
local tbl1 = {
	["10M Upgraded Titan Speakerman"] = {
		Idle = { AnimationId = "rbxassetid://119530772312411" },
		Charge = { AnimationId = "rbxassetid://89380882468171", Cooldown = 0.7, Hold = true },
		Attack = { AnimationId = "rbxassetid://100165624381646" },
		Lower = { AnimationId = "rbxassetid://92167717061120", Cooldown = 0.7 },
	},
	["Upgraded Titan Camera Man"] = {
		Idle = { AnimationId = "rbxassetid://83062780787008" },
		Charge = { AnimationId = "rbxassetid://138954129650463", Cooldown = 0.65, Hold = true },
		Attack = { AnimationId = "rbxassetid://86866487662390" },
		Lower = { AnimationId = "rbxassetid://82356587874239", Cooldown = 0.4 },
		HandAttack = { AnimationId = "rbxassetid://73513470188018" },
	},
	["Present Camera Man"] = {
		Idle = { AnimationId = var1.Animations.Idle },
		Attack = { AnimationId = var1.Animations.Attack, Cooldown = var1.ReleaseDelay + var1.ThrowSeconds },
	},
	["Camera Man"] = {
		Idle = { AnimationId = "rbxassetid://80780134266172" },
		Charge = { AnimationId = "rbxassetid://84108368579459", Cooldown = 0.5, Hold = true },
		Attack = { AnimationId = "rbxassetid://76466701524544" },
		Lower = { AnimationId = "rbxassetid://79184716298273", Cooldown = 0.5 },
		Reload = { AnimationId = "rbxassetid://116493191639561", Cooldown = 2 },
	},
	["Builder Camera Man"] = { Build = { AnimationId = "rbxassetid://124018126660813" } },
	["Titan Speaker Man 2.0"] = {
		Idle = { AnimationId = "rbxassetid://133888295374829" },
		Charge = { AnimationId = "rbxassetid://116258491071994", Cooldown = 0.9 },
		Attack = { AnimationId = "rbxassetid://139939898423217" },
		Lower = { AnimationId = "rbxassetid://70807874675978", Cooldown = 0.9 },
		AbilityCharge = { AnimationId = "rbxassetid://115749952509903", Cooldown = 0.9, FireTime = 2.4 },
		AbilityAttack = { AnimationId = "rbxassetid://139939898423217" },
		AbilityLower = { AnimationId = "rbxassetid://70807874675978", Cooldown = 0.9 },
	},
	["TV Woman"] = {
		Idle = { AnimationId = "rbxassetid://138368661591179" },
		Charge = { AnimationId = "rbxassetid://111498150764772", Cooldown = 1.05 },
		Attack = { AnimationId = "rbxassetid://135230996023034" },
		Lower = { AnimationId = "rbxassetid://75214659706229", Cooldown = 1.05 },
	},
	["10M TV Woman"] = {
		Idle = { AnimationId = "rbxassetid://89074405301293" },
		Charge = { AnimationId = "rbxassetid://98947390240304", Cooldown = 1.05 },
		Attack = { AnimationId = "rbxassetid://124246444319333" },
		Lower = { AnimationId = "rbxassetid://130102782759819", Cooldown = 1.05 },
	},
	["Titan TV Man"] = { Screen = str1 },
}

str1 = {
	PartNames = { "Cube.299" },
	AttackColor = Color3.fromRGB(255, 76, 70),
	AttackTime = 0.08,
	IdleTime = 0.3,
}

str1.IdleColor = Color3.fromRGB(67, 67, 74)
local tbl2 = { Screen = str1 }
tbl2.Idle = { AnimationId = "rbxassetid://117137458290937" }
tbl2.Charge = { AnimationId = "rbxassetid://76867470313407", Cooldown = 0.75 }
tbl2.Attack = { AnimationId = "rbxassetid://127836963624404" }
tbl2.HandAttack = { AnimationId = "rbxassetid://89032208286888" }
tbl2.Lower = { AnimationId = "rbxassetid://134914958362595", Cooldown = 0.8 }
tbl1["Titan Cinema Man"] = tbl2
local tbl3 = { Units = tbl1 }
tbl3.getAnimationId = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var3 = if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil
	return var3 and var3.AnimationId or nil
end

tbl3.hasState = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	return (if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil) ~= nil
end

tbl3.getCooldown = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var3 = if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil
	var1 = var3
	var1 = var1 and var3.Cooldown
	if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then
		return 0
	end

	return (math.max(0, var1))
end

tbl3.isHold = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var4 = if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil
	var1 = false
	if var4 ~= nil then
		var1 = var4.Hold == true
	end

	return var1
end

tbl3.holdLoops = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var4 = if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil
	var1 = false
	if var4 ~= nil then
		var1 = var4.HoldLoop == true
	end

	return var1
end

tbl3.keepsIdle = function(arg1, arg2)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var4 = if typeof(var2) == "table" and (typeof(var2.AnimationId) == "string" and var2.AnimationId ~= "") then var2 else nil
	var1 = false
	if var4 ~= nil then
		var1 = var4.KeepIdle == true
	end

	return var1
end

tbl3.getScreen = function(arg1)
	local var1 = tbl3.Units[arg1]
	local var2 = var1
	var2 = var2 and var1.Screen
	if typeof(var2) == "table" and (typeof(var2.AttackColor) == "Color3" and typeof(var2.IdleColor) == "Color3") then
		return var2
	end

	return nil
end

tbl3.Units["10M Titan Speaker Man"] = tbl3.Units["10M Upgraded Titan Speakerman"]
return tbl3

--- ReplicatedStorage.Modules.TowerAttackConfig [ModuleScript]
-- y u r i

return {
	Defaults = {
		Volume = 0.7,
		PlaybackSpeed = 1,
		RollOffMinDistance = 8,
		RollOffMaxDistance = 90,
		MaxConcurrent = 4,
		CleanupSeconds = 15,
	},
	Units = {
		["Speaker Man"] = { Sound = {
			Mode = "Random",
			Clips = {
				{ SoundId = "rbxassetid://95606007827569" },
				{ SoundId = "rbxassetid://112747183402438" },
				{ SoundId = "rbxassetid://121613078753621" },
			},
		} },
		["Camera Man"] = { Sound = { Mode = "Random", Clips = { { SoundId = "rbxassetid://131135705801530" } } } },
		["Titan Speaker Man"] = { Sound = { Mode = "Random", Clips = { { SoundId = "rbxassetid://113489630888038" } } } },
		["Party Camera Man"] = { Sound = { Mode = "Random", Clips = { { SoundId = "rbxassetid://122149536464655" } } } },
		["Camera Woman"] = { Sound = { Mode = "Random", Clips = { { SoundId = "rbxassetid://113029053355393" } } } },
		["Titan Speaker Man 2.0"] = { Sound = { Mode = "Random", Clips = { { SoundId = "rbxassetid://116171962323317" } } } },
	},
}

--- ReplicatedStorage.Modules.TowerUpgradeConfig [ModuleScript]
-- y u r i

local tbl1 = { Models = {
	["10M Titan Speaker Man"] = {
		{ ModelName = "10M Upgraded Titan Speakerman" },
		{ ModelName = "10M Upgraded Titan Speakerman" },
		{ ModelName = "10M Upgraded Titan Speakerman" },
		{ ModelName = "10M Upgraded Titan Speakerman" },
	},
	["Speaker Man"] = { { ModelName = "Speaker Man" }, { ModelName = "Speaker Man" } },
	["Camera Man"] = { { ModelName = "Camera Man" } },
	["Scientist Camera Man"] = {
		{ ModelName = "Scientist Camera Man" },
		{ ModelName = "Scientist Camera Man" },
		{ ModelName = "Scientist Camera Man" },
		{ ModelName = "Scientist Camera Man" },
	},
	["Large Scientist Camera Man"] = {
		{ ModelName = "Large Scientist Camera Man" },
		{ ModelName = "Large Scientist Camera Man" },
		{ ModelName = "Large Scientist Camera Man" },
		{ ModelName = "Large Scientist Camera Man" },
	},
} }

tbl1.getModelName = function(arg1, arg2)
	local var1 = tbl1.Models[arg1]
	local var2 = var1
	var2 = var2 and var1[arg2]
	local var3 = var2
	var3 = var3 and var2.ModelName
	if typeof(var3) == "string" and var3 ~= "" then
		return var3
	end

	return arg1
end

tbl1.modelChanges = function(arg1, arg2, arg3)
	return tbl1.getModelName(arg1, arg2) ~= tbl1.getModelName(arg1, arg3)
end

return tbl1

--- ReplicatedStorage.Modules.TowerLevelStats [ModuleScript]
-- y u r i

local var1 = Color3.fromRGB(163, 162, 165)
local str1 = "PresentGiftConfig"
local var2 = require(script.Parent:WaitForChild(str1))
local tbl1 = { {
	MeshId = "rbxassetid://103774984866635",
	TextureId = "rbxassetid://90941956249171",
	Size = Vector3.new(2.0201, 2.1107, 4.7403),
	Color = var1,
	Offset = Vector3.new(0, 0, 0),
} }

local tbl2 = { Walk = "rbxassetid://82482705287358" }
local tbl3 = { Levels = {
	["Speaker Man"] = {
		{
			Price = 100,
			UpgradePrice = 75,
			SellPrice = 70,
			Damage = 18,
			Range = 12,
			Cooldown = 0.75,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Common",
			Icon = "rbxassetid://101986091591878",
		},
		{ UpgradePrice = 100, SellPrice = 123, Damage = 30, Range = 12, Cooldown = 0.72 },
		{ UpgradePrice = 125, SellPrice = 193, Damage = 45, Range = 13, Cooldown = 0.68 },
		{ SellPrice = 280, Damage = 60, Range = 14, Cooldown = 0.65 },
	},
	["Camera Man"] = {
		{
			Price = 100,
			UpgradePrice = 125,
			SellPrice = 70,
			Damage = 60,
			Range = 16,
			Cooldown = 1.25,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Uncommon",
			Icon = "rbxassetid://102805185355127",
		},
		{ UpgradePrice = 175, SellPrice = 193, Damage = 90, Range = 17, Cooldown = 1.18 },
		{ UpgradePrice = 250, SellPrice = 315, Damage = 120, Range = 18, Cooldown = 1.08 },
		{ SellPrice = 490, Damage = 150, Range = 20, Cooldown = 1 },
	},
	["TV Man"] = {
		{
			Price = 200,
			UpgradePrice = 200,
			SellPrice = 175,
			Damage = 50,
			Range = 14,
			Cooldown = 1,
			AttackType = "Cone",
			AttackAngle = 90,
			Rarity = "Rare",
			Icon = "rbxassetid://140644970749961",
		},
		{
			UpgradePrice = 300,
			SellPrice = 315,
			Damage = 72,
			Range = 15,
			Cooldown = 0.9,
			AttackAngle = 100,
		},
		{
			UpgradePrice = 450,
			SellPrice = 525,
			Damage = 94,
			Range = 16,
			Cooldown = 0.85,
			AttackAngle = 110,
		},
		{ SellPrice = 840, Damage = 128, Range = 18, Cooldown = 0.75, AttackAngle = 120 },
	},
	["Large Speaker Man"] = {
		{
			Price = 250,
			UpgradePrice = 325,
			SellPrice = 175,
			Damage = 90,
			Range = 14,
			Cooldown = 0.72,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Rare",
			Icon = "rbxassetid://87876322478269",
		},
		{ UpgradePrice = 450, SellPrice = 403, Damage = 135, Range = 14, Cooldown = 0.7 },
		{ UpgradePrice = 650, SellPrice = 718, Damage = 180, Range = 15, Cooldown = 0.68 },
		{ SellPrice = 1173, Damage = 200, Range = 16, Cooldown = 0.66 },
	},
	["Camera Woman"] = {
		{
			Price = 150,
			UpgradePrice = 250,
			SellPrice = 105,
			Damage = 100,
			Range = 18,
			Cooldown = 1.8,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Rare",
			Icon = "rbxassetid://98990845428595",
		},
		{ UpgradePrice = 350, SellPrice = 280, Damage = 160, Range = 19, Cooldown = 1.7 },
		{ UpgradePrice = 500, SellPrice = 525, Damage = 260, Range = 21, Cooldown = 1.6 },
		{ SellPrice = 875, Damage = 390, Range = 22, Cooldown = 1.5 },
	},
	["Plunger Camera Man"] = {
		{
			Price = 250,
			UpgradePrice = 450,
			SellPrice = 175,
			Damage = 140,
			Range = 13,
			Cooldown = 0.8,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Epic",
			Icon = "rbxassetid://114399458554574",
		},
		{ UpgradePrice = 650, SellPrice = 490, Damage = 220, Range = 14, Cooldown = 0.75 },
		{ UpgradePrice = 900, SellPrice = 945, Damage = 300, Range = 15, Cooldown = 0.7 },
		{ SellPrice = 1575, Damage = 363, Range = 17, Cooldown = 0.66 },
	},
	["Large Camera Man"] = {
		{
			Price = 450,
			UpgradePrice = 500,
			SellPrice = 390,
			Damage = 220,
			Range = 9,
			Cooldown = 1.4,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Epic",
			Icon = "rbxassetid://133061255832139",
		},
		{ UpgradePrice = 600, SellPrice = 775, Damage = 360, Range = 9, Cooldown = 1.3 },
		{ UpgradePrice = 800, SellPrice = 1270, Damage = 500, Range = 10, Cooldown = 1.2 },
		{ SellPrice = 1865, Damage = 660, Range = 11, Cooldown = 1.1 },
	},
	["Large TV Man"] = {
		{
			Price = 350,
			UpgradePrice = 450,
			SellPrice = 245,
			Damage = 88,
			Range = 14,
			Cooldown = 1.25,
			AttackType = "Cone",
			AttackAngle = 100,
			Rarity = "Epic",
			Icon = "rbxassetid://72851740966622",
		},
		{
			UpgradePrice = 650,
			SellPrice = 560,
			Damage = 138,
			Range = 15,
			Cooldown = 1.15,
			AttackAngle = 110,
		},
		{
			UpgradePrice = 850,
			SellPrice = 1015,
			Damage = 203,
			Range = 16,
			Cooldown = 1.07,
			AttackAngle = 120,
		},
		{ SellPrice = 1610, Damage = 320, Range = 17, Cooldown = 1, AttackAngle = 130 },
	},
	["Titan Speaker Man"] = {
		{
			Price = 1200,
			UpgradePrice = 900,
			SellPrice = 840,
			Damage = 180,
			Range = 18,
			Cooldown = 0.5,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Legendary",
			Icon = "rbxassetid://136941360608846",
		},
		{ UpgradePrice = 1200, SellPrice = 1470, Damage = 280, Range = 19, Cooldown = 0.47 },
		{ UpgradePrice = 1600, SellPrice = 2310, Damage = 400, Range = 20, Cooldown = 0.44 },
		{ SellPrice = 3430, Damage = 504, Range = 22, Cooldown = 0.42 },
	},
	["Titan Speaker Man 2.0"] = {
		{
			Price = 2500,
			UpgradePrice = 2000,
			SellPrice = 1000,
			Damage = 500,
			Range = 17,
			Cooldown = 1,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Mythic",
			Icon = "rbxassetid://104213958021417",
		},
		{ UpgradePrice = 3500, SellPrice = 1500, Damage = 1000, Range = 20, Cooldown = 0.75 },
		{ UpgradePrice = 6500, SellPrice = 2500, Damage = 1500, Range = 22, Cooldown = 0.5 },
		{ SellPrice = 5000, Damage = 1750, Range = 24, Cooldown = 0.4 },
	},
	["TV Woman"] = {
		{
			Price = 500,
			UpgradePrice = 1000,
			SellPrice = 250,
			Damage = 100,
			Range = 13,
			Cooldown = 1.5,
			AttackType = "Cone",
			AttackAngle = 95,
			Rarity = "Exclusive",
			Icon = "rbxassetid://94559091004757",
			SlowPercent = 0,
		},
		{
			UpgradePrice = 2500,
			SellPrice = 1250,
			Damage = 300,
			Range = 15,
			AttackAngle = 105,
			Cooldown = 1,
			SlowPercent = 10,
		},
		{
			UpgradePrice = 4000,
			SellPrice = 2590,
			Damage = 675,
			Range = 19,
			AttackAngle = 115,
			Cooldown = 1,
			SlowPercent = 12,
		},
		{
			SellPrice = 4130,
			Damage = 900,
			Range = 22,
			AttackAngle = 125,
			Cooldown = 0.8,
			SlowPercent = 20,
		},
	},
	["Titan TV Man"] = {
		{
			Price = 2000,
			UpgradePrice = 1400,
			SellPrice = 1400,
			Damage = 30,
			Range = 16,
			Cooldown = 0.3,
			AttackType = "Cone",
			AttackAngle = 115,
			Rarity = "Legendary",
			Icon = "rbxassetid://122105783054314",
		},
		{
			UpgradePrice = 1900,
			SellPrice = 2380,
			Damage = 44,
			Range = 17,
			Cooldown = 0.2,
			AttackAngle = 125,
		},
		{
			UpgradePrice = 2500,
			SellPrice = 3710,
			Damage = 60,
			Range = 18,
			Cooldown = 0.15,
			AttackAngle = 135,
		},
		{ SellPrice = 5460, Damage = 65, Range = 19, Cooldown = 0.1, AttackAngle = 145 },
	},
	["Titan Camera Man"] = {
		{
			Price = 1250,
			UpgradePrice = 1250,
			SellPrice = 650,
			Damage = 400,
			Range = 20,
			Cooldown = 1.5,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Exclusive",
			Icon = "rbxassetid://121397856317625",
		},
		{ UpgradePrice = 2200, SellPrice = 1600, Damage = 600, Range = 22, Cooldown = 1 },
		{ UpgradePrice = 2800, SellPrice = 2650, Damage = 750, Range = 25, Cooldown = 1 },
		{ SellPrice = 4075, Damage = 250, Range = 28, Cooldown = 0.1 },
	},
	["Scientist Camera Man"] = {
		{
			Price = 150,
			UpgradePrice = 350,
			SellPrice = 140,
			Damage = 0,
			Range = 0,
			Cooldown = 1,
			AttackType = "Single",
			AttackAngle = 0,
			SupportType = "Income",
			Income = 50,
			Rarity = "Exclusive",
			Icon = "rbxassetid://94742421864994",
		},
		{ UpgradePrice = 1200, SellPrice = 560, Income = 100 },
		{ UpgradePrice = 2000, SellPrice = 1190, Income = 300 },
		{ SellPrice = 2170, Income = 750 },
	},
	["Large Scientist Camera Man"] = {
		{
			Price = 250,
			UpgradePrice = 550,
			SellPrice = 125,
			Damage = 120,
			Range = 12,
			Cooldown = 0.8,
			AttackType = "Single",
			AttackAngle = 0,
			SupportType = "Heal",
			Heal = 10,
			SlowPercent = 12,
			SlowDuration = 1.25,
			Rarity = "Exclusive",
			Icon = "rbxassetid://103385877459009",
		},
		{
			UpgradePrice = 1150,
			SellPrice = 490,
			Damage = 200,
			Range = 14,
			Cooldown = 0.7,
			Heal = 20,
			SlowPercent = 15,
			SlowDuration = 1.35,
		},
		{
			UpgradePrice = 1500,
			SellPrice = 980,
			Damage = 325,
			Range = 16,
			Cooldown = 0.68,
			Heal = 35,
			SlowPercent = 18,
			SlowDuration = 1.5,
		},
		{
			SellPrice = 1680,
			Damage = 500,
			Range = 18,
			Cooldown = 0.62,
			Heal = 55,
			SlowPercent = 20,
			SlowDuration = 1.75,
		},
	},
	["Engineer Camera Man"] = {
		{
			Price = 250,
			UpgradePrice = 1000,
			SellPrice = 175,
			Cooldown = 10,
			AttackType = "Single",
			AttackAngle = 0,
			SpawnUnits = { { Unit = "Camera Toilet", Name = "Camera Toilet", Cooldown = 20, HeightOffset = 0 } },
			SpawnerHp = 2000,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 2,
			Rarity = "Exclusive",
			Icon = "rbxassetid://134338568907080",
		},
		{
			UpgradePrice = 3000,
			SellPrice = 875,
			Cooldown = 10,
			SpawnUnits = { { Unit = "Camera Toilet", Name = "Camera Toilet", Cooldown = 19, HeightOffset = 0 } },
			SpawnerHp = 8000,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 2,
		},
		{
			UpgradePrice = 5000,
			SellPrice = 2975,
			Cooldown = 10,
			SpawnUnits = { {
				Unit = "Large Camera Toilet",
				Name = "Large Camera Toilet",
				Cooldown = 18,
				HeightOffset = 0,
			} },
			SpawnerHp = 12000,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 3,
		},
		{
			UpgradePrice = 9000,
			SellPrice = 6475,
			Cooldown = 10,
			SpawnUnits = { {
				Unit = "Large Camera Toilet",
				Name = "Large Camera Toilet",
				Cooldown = 17,
				HeightOffset = 0,
			} },
			SpawnerHp = 25000,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 4,
		},
		{
			SellPrice = 13475,
			Cooldown = 10,
			SpawnUnits = { {
				Unit = "Large Camera Toilet",
				Name = "Large Camera Toilet",
				Cooldown = 15,
				HeightOffset = 0,
			} },
			SpawnerHp = 45000,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 4,
		},
	},
	["Party Camera Man"] = {
		{
			Price = 200,
			UpgradePrice = 250,
			SellPrice = 88,
			Damage = 20,
			Range = 14,
			Cooldown = 1.2,
			AttackType = "Splash",
			AttackAngle = 0,
			SplashRadius = 4,
			Icon = "rbxassetid://121454848252009",
		},
		{
			UpgradePrice = 350,
			SellPrice = 158,
			Damage = 30,
			Range = 15,
			Cooldown = 1,
			SplashRadius = 5,
		},
		{
			UpgradePrice = 500,
			SellPrice = 315,
			Damage = 40,
			Range = 17,
			Cooldown = 0.8,
			SplashRadius = 6,
		},
		{ SellPrice = 525, Damage = 50, Range = 16, Cooldown = 0.3, SplashRadius = 7 },
	},
	["Jester Speaker Man"] = {
		{
			Price = 250,
			UpgradePrice = 222,
			SellPrice = 175,
			Damage = 80,
			Range = 12,
			Cooldown = 1,
			AttackType = "Cone",
			AttackAngle = 90,
			Icon = "rbxassetid://99828580701098",
		},
		{
			UpgradePrice = 360,
			SellPrice = 385,
			Damage = 115,
			Range = 13,
			Cooldown = 0.7,
			AttackAngle = 100,
		},
		{
			UpgradePrice = 500,
			SellPrice = 710,
			Damage = 130,
			Range = 14,
			Cooldown = 0.6,
			AttackAngle = 110,
		},
		{ SellPrice = 1250, Damage = 170, Range = 15, Cooldown = 0.5, AttackAngle = 120 },
	},
	["Party Titan TV Man"] = {
		{
			Price = 2500,
			UpgradePrice = 2000,
			SellPrice = 1260,
			Damage = 35,
			Range = 17,
			Cooldown = 0.25,
			AttackType = "Cone",
			AttackAngle = 115,
			Icon = "rbxassetid://123981686282973",
		},
		{
			UpgradePrice = 4000,
			SellPrice = 2520,
			Damage = 60,
			Range = 19,
			Cooldown = 0.2,
			AttackAngle = 125,
		},
		{
			UpgradePrice = 6750,
			SellPrice = 3780,
			Damage = 85,
			Range = 20,
			Cooldown = 0.15,
			AttackAngle = 135,
		},
		{ SellPrice = 5460, Damage = 85, Range = 23, Cooldown = 0.1, AttackAngle = 145 },
	},
	["Dark Speaker Man"] = {
		{
			Price = 250,
			UpgradePrice = 125,
			SellPrice = 125,
			Damage = 240,
			Range = 16,
			Cooldown = 0.8,
			AttackType = "Single",
			AttackAngle = 0,
			SlowPercent = 20,
			SlowDuration = 1.2,
			Rarity = "Legendary",
			Icon = "rbxassetid://81958944688997",
		},
		{
			UpgradePrice = 1500,
			SellPrice = 200,
			Damage = 320,
			Range = 18,
			Cooldown = 0.75,
			SlowPercent = 24,
			SlowDuration = 1.3,
		},
		{
			UpgradePrice = 2200,
			SellPrice = 1000,
			Damage = 400,
			Range = 20,
			Cooldown = 0.7,
			SlowPercent = 28,
			SlowDuration = 1.4,
		},
		{
			SellPrice = 2000,
			Damage = 450,
			Range = 22,
			Cooldown = 0.65,
			SlowPercent = 32,
			SlowDuration = 1.5,
		},
	},
	["Speaker Woman"] = {
		{
			Price = 1000,
			UpgradePrice = 1600,
			SellPrice = 500,
			Damage = 60,
			Range = 22,
			Cooldown = 1,
			AttackType = "Cone",
			AttackAngle = 55,
			Rarity = "Legendary",
			Icon = "rbxassetid://105526732651289",
		},
		{
			UpgradePrice = 2800,
			SellPrice = 1250,
			Damage = 92,
			Range = 25,
			Cooldown = 0.8,
			AttackAngle = 45,
		},
		{
			UpgradePrice = 5000,
			SellPrice = 2500,
			Damage = 140,
			Range = 28,
			Cooldown = 0.7,
			AttackAngle = 35,
		},
		{ SellPrice = 4000, Damage = 198, Range = 31, Cooldown = 0.6, AttackAngle = 30 },
	},
	["DJ Speaker Man"] = {
		{
			Price = 1250,
			UpgradePrice = 950,
			SellPrice = 875,
			Damage = 0,
			Range = 14,
			Cooldown = 1,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Legendary",
			Icon = "rbxassetid://91266318307652",
			SupportType = "Booster",
		},
		{ UpgradePrice = 1500, SellPrice = 1540, Range = 17 },
		{ UpgradePrice = 2200, SellPrice = 2590, Range = 20 },
		{ SellPrice = 4130, Range = 24 },
	},
	["Titan Cinema Man"] = {
		{
			Price = 3750,
			UpgradePrice = 3250,
			SellPrice = 1000,
			Damage = 50,
			Range = 15,
			Cooldown = 0.2,
			AttackType = "Cone",
			AttackAngle = 100,
			Rarity = "Legendary",
			Icon = "rbxassetid://123045542048297",
			HandRange = 6,
			HandDamage = 200,
			HandCooldown = 1.5,
		},
		{
			UpgradePrice = 5500,
			SellPrice = 1500,
			Damage = 60,
			Range = 17,
			Cooldown = 0.15,
			HandRange = 7,
			HandDamage = 350,
			HandCooldown = 1.2,
		},
		{
			UpgradePrice = 8500,
			SellPrice = 2500,
			Damage = 75,
			Range = 19,
			Cooldown = 0.1,
			HandRange = 9,
			HandDamage = 400,
			HandCooldown = 0.8,
		},
		{
			SellPrice = 5000,
			Damage = 125,
			Range = 22,
			Cooldown = 0.1,
			HandRange = 10,
			HandDamage = 650,
			HandCooldown = 0.3,
		},
	},
	["Builder Camera Man"] = {
		{
			Price = 250,
			UpgradePrice = 900,
			SellPrice = 175,
			Range = 10,
			Cooldown = 2,
			Rarity = "Legendary",
			Icon = "rbxassetid://87325234755652",
			NoAttack = true,
			Barricade = {
				Pieces = { {
					MeshId = "rbxassetid://86690132593713",
					TextureId = "rbxassetid://90941956249171",
					Size = Vector3.new(1.4754, 1.7716, 1.4754),
					Color = var1,
					Offset = Vector3.new(0, 0, 0),
				} },
				DisplayName = "Barricade",
				Health = 250,
				MaxUnits = 5,
				Cooldown = 2,
				Lifetime = 0,
				BlockRadius = 4,
				MobDamage = 25,
				MobHitCooldown = 0.5,
				Spacing = 8,
				HeightOffset = 0,
			},
		},
		{
			UpgradePrice = 2700,
			SellPrice = 805,
			Range = 16,
			Cooldown = 2,
			Barricade = {
				Pieces = {
					{
						MeshId = "rbxassetid://86690132593713",
						TextureId = "rbxassetid://90941956249171",
						Size = Vector3.new(1.4754, 1.7716, 1.4754),
						Color = var1,
						Offset = Vector3.new(-1.1097, 0, 0.5637),
					},
					{
						MeshId = "rbxassetid://86690132593713",
						TextureId = "rbxassetid://90941956249171",
						Size = Vector3.new(1.4754, 1.7716, 1.4754),
						Color = var1,
						Offset = Vector3.new(1.1183, 0, 0.5637),
					},
					{
						MeshId = "rbxassetid://86690132593713",
						TextureId = "rbxassetid://90941956249171",
						Size = Vector3.new(1.4754, 1.7716, 1.4754),
						Color = var1,
						Offset = Vector3.new(0.0086, 0, -1.1281),
					},
				},
				DisplayName = "Barricade",
				Health = 500,
				MaxUnits = 5,
				Cooldown = 2,
				BlockRadius = 4,
				MobDamage = 25,
				MobHitCooldown = 0.5,
				Spacing = 8,
			},
		},
		{
			UpgradePrice = 4500,
			SellPrice = 2695,
			Range = 16,
			Cooldown = 7,
			Barricade = {
				Pieces = tbl1,
				DisplayName = "Barricade",
				Health = 3000,
				MaxUnits = 5,
				Cooldown = 7,
				BlockRadius = 4,
				MobDamage = 25,
				MobHitCooldown = 0.5,
				Spacing = 8,
			},
		},
		{
			UpgradePrice = 8500,
			SellPrice = 5845,
			Range = 14,
			Cooldown = 3,
			Barricade = {
				Pieces = tbl1,
				DisplayName = "Barricade",
				Health = 8000,
				MaxUnits = 5,
				Cooldown = 3,
				BlockRadius = 4,
				MobDamage = 25,
				MobHitCooldown = 0.5,
				Spacing = 8,
			},
		},
	},
	["Upgraded Titan Camera Man"] = {
		{
			HandRange = 6,
			HandDamage = 120,
			HandCooldown = 1.5,
			SplashRadius = 10,
			Price = 4000,
			UpgradePrice = 7500,
			SellPrice = 1000,
			Damage = 1000,
			Range = 13,
			Cooldown = 1,
			AttackType = "Single",
			AttackAngle = 100,
			Rarity = "Mythic",
			Icon = "rbxassetid://120049088096507",
		},
		{
			HandRange = 7,
			HandDamage = 200,
			HandCooldown = 1.3,
			SplashRadius = 11,
			UpgradePrice = 10000,
			SellPrice = 1500,
			Damage = 1500,
			Range = 15,
			Cooldown = 0.7,
		},
		{
			HandRange = 9,
			HandDamage = 500,
			HandCooldown = 1.1,
			SplashRadius = 12,
			UpgradePrice = 15000,
			SellPrice = 2500,
			Damage = 1800,
			Range = 22,
			Cooldown = 0.5,
		},
		{
			HandRange = 10,
			HandDamage = 1000,
			HandCooldown = 1,
			SplashRadius = 13,
			SellPrice = 5000,
			Damage = 2000,
			Range = 25,
			Cooldown = 0.35,
		},
	},
	["Present Camera Man"] = {
		{
			Price = 200,
			UpgradePrice = 1000,
			SellPrice = 100,
			NoAttack = true,
			Damage = 0,
			Rarity = "Exclusive",
			Icon = "rbxassetid://135258816549317",
		},
		{ UpgradePrice = 2250, SellPrice = 1200 },
		{ UpgradePrice = 3500, SellPrice = 2000 },
		{ SellPrice = 5000 },
	},
	["10M Camera Man"] = {
		{
			Price = 500,
			UpgradePrice = 750,
			SellPrice = 350,
			Damage = 140,
			Range = 14,
			Cooldown = 0.8,
			AttackType = "Single",
			AttackAngle = 100,
			Rarity = "Epic",
			Icon = "rbxassetid://103974247512120",
		},
		{ UpgradePrice = 1100, SellPrice = 875, Damage = 220, Range = 16, Cooldown = 0.75 },
		{ UpgradePrice = 1600, SellPrice = 1645, Damage = 320, Range = 18, Cooldown = 0.7 },
		{ SellPrice = 2765, Damage = 420, Range = 20, Cooldown = 0.65 },
	},
	["10M TV Woman"] = {
		{
			Price = 1000,
			UpgradePrice = 1500,
			SellPrice = 700,
			Damage = 100,
			Range = 14,
			Cooldown = 1.5,
			AttackType = "Cone",
			AttackAngle = 95,
			Rarity = "Legendary",
			Icon = "rbxassetid://92148897297948",
			SlowPercent = 0,
		},
		{
			UpgradePrice = 2500,
			SellPrice = 1750,
			Damage = 260,
			Range = 16,
			Cooldown = 1.1,
			AttackAngle = 105,
			SlowPercent = 10,
		},
		{
			UpgradePrice = 4000,
			SellPrice = 3500,
			Damage = 500,
			Range = 19,
			Cooldown = 0.9,
			AttackAngle = 115,
			SlowPercent = 12,
		},
		{
			SellPrice = 6300,
			Damage = 750,
			Range = 22,
			Cooldown = 0.65,
			AttackAngle = 125,
			SlowPercent = 20,
		},
	},
	["10M Titan Speaker Man"] = {
		{
			Price = 2500,
			UpgradePrice = 3000,
			SellPrice = 1750,
			Damage = 60,
			Range = 18,
			Cooldown = 1,
			AttackType = "Single",
			AttackAngle = 0,
			Rarity = "Mythic",
			Icon = "rbxassetid://79501329608644",
		},
		{ UpgradePrice = 5000, SellPrice = 3850, Damage = 100, Range = 21, Cooldown = 0.6 },
		{ UpgradePrice = 8000, SellPrice = 7350, Damage = 150, Range = 24, Cooldown = 0.3 },
		{ SellPrice = 12950, Damage = 100, Range = 26, Cooldown = 0.1 },
	},
	["10M Speaker Man"] = {
		{
			Price = 200,
			UpgradePrice = 1000,
			SellPrice = 100,
			Cooldown = 10,
			AttackType = "Single",
			AttackAngle = 0,
			SpawnUnits = { {
				Unit = "Cupcake",
				Name = "Cupcake",
				Cooldown = 10,
				HeightOffset = -0.75,
				DeathSplashDamage = 400,
				DeathSplashRadius = 8,
				Animations = { Walk = "rbxassetid://82482705287358" },
			} },
			SpawnerHp = 1500,
			SpawnLifetime = 200,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 2,
			NoAttack = true,
			Rarity = "Event",
			Icon = "rbxassetid://72134910652720",
		},
		{
			UpgradePrice = 2250,
			SellPrice = 1500,
			SpawnUnits = { {
				Unit = "Cupcake",
				Name = "Cupcake",
				Cooldown = 10,
				HeightOffset = -0.75,
				DeathSplashDamage = 1000,
				DeathSplashRadius = 8,
				Animations = { Walk = "rbxassetid://82482705287358" },
			} },
			SpawnerHp = 6000,
			SpawnLifetime = 250,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 2,
		},
		{
			UpgradePrice = 3500,
			SellPrice = 2500,
			SpawnUnits = { {
				Unit = "Cupcake",
				Name = "Cupcake",
				Cooldown = 10,
				HeightOffset = -0.75,
				DeathSplashDamage = 2200,
				DeathSplashRadius = 10,
				Animations = { Walk = "rbxassetid://82482705287358" },
			} },
			SpawnerHp = 10000,
			SpawnLifetime = 208,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 3,
		},
		{
			SellPrice = 5000,
			SpawnUnits = { {
				Unit = "Cupcake",
				Name = "Cupcake",
				Cooldown = 10,
				HeightOffset = -0.75,
				DeathSplashDamage = 4000,
				DeathSplashRadius = 12,
				Animations = tbl2,
			} },
			SpawnerHp = 20000,
			SpawnLifetime = 302,
			SpawnMoveSpeed = 10,
			SpawnMaxUnits = 4,
		},
	},
} }

local var3 = tbl3.Levels
local tbl4 = {
	{ Range = 12, Damage = 30, Cooldown = 1.5, Angle = 100 },
	{ Range = 15, Damage = 60, Cooldown = 0.9, Angle = 100 },
	{ Range = 18, Damage = 90, Cooldown = 0.4, Angle = 100 },
	{ Range = 22, Damage = 130, Cooldown = 0.1, Angle = 100 },
}

for k1, v1 in pairs(var3["10M Titan Speaker Man"]) do
	v1.HandRange = tbl4[k1].Range
	v1.HandDamage = tbl4[k1].Damage
	v1.HandCooldown = tbl4[k1].Cooldown
	v1.HandAttackAngle = tbl4[k1].Angle
end

local var4 = tbl3.Levels
local var5 = var2.UnitName
for k2, v2 in pairs(var4[var5]) do
	local var6 = var2.GetLevel(k2)
	v2.Range = var6.Range
	v2.Cooldown = var6.Cooldown
end

local function sanitizeBarricadePieces(arg1)
	if typeof(arg1) ~= "table" or #arg1 == 0 then
		return nil
	end

	local tbl1 = {}
	for k1, v1 in ipairs(arg1) do
		if typeof(v1) ~= "table" then
			continue
		end

		if typeof(v1.MeshId) ~= "string" then
			continue
		end

		if v1.MeshId == "" then
			continue
		end

		local var1 = if typeof(v1.TextureId) == "string" then v1.TextureId else nil
		local tbl3 = { MeshId = v1.MeshId, TextureId = var1 }
		if typeof(v1.Size) == "Vector3" then
			var1 = v1.Size
		else
			var1 = Vector3.new(2, 2, 2)
		end

		tbl3.Size = var1
		var1 = if typeof(v1.Color) == "Color3" then v1.Color else nil
		tbl3.Color = var1
		var1 = if typeof(v1.Offset) == "Vector3" then v1.Offset else Vector3.new(0, 0, 0)
		tbl3.Offset = var1
		table.insert(tbl1, tbl3)
	end

	if #tbl1 == 0 then
		return nil
	end

	return tbl1
end

local function sanitizeSpawnUnits(arg1)
	local tbl1 = {}
	if typeof(arg1) ~= "table" then
		return tbl1
	end

	for k1, v1 in ipairs(arg1) do
		if typeof(v1) ~= "table" then
			continue
		end

		if typeof(v1.Unit) ~= "string" then
			continue
		end

		if v1.Unit == "" then
			continue
		end

		local var1 = if typeof(v1.Cooldown) == "number" then v1.Cooldown else 0
		local var2 = if typeof(v1.HeightOffset) == "number" then v1.HeightOffset else 0
		local var3 = if typeof(v1.Name) == "string" and v1.Name ~= "" then v1.Name else v1.Unit
		local var5 = if typeof(v1.SpawnerHp) == "number" then v1.SpawnerHp else nil
		if var5 ~= nil then
			if var5 ~= var5 or (var5 == math.huge or var5 == -math.huge) then
				var5 = nil
			end
		end

		local var6 = nil
		if typeof(v1.Animations) == "table" then
			local var7 = if typeof(v1.Animations.Walk) == "string" then v1.Animations.Walk else nil
			local tbl3 = { Walk = var7 }
			if typeof(v1.Animations.Attack) == "string" then
				var7 = v1.Animations.Attack
			else
				var7 = nil
			end

			tbl3.Attack = var7
			var6 = tbl3
		end

		local var8 = if var5 ~= nil then math.max(1, var5) else nil
		local tbl4 = { Unit = v1.Unit, Name = var3, SpawnerHp = var8 }
		tbl4.Cooldown = math.max(0, var1)
		tbl4.HeightOffset = if var2 == var2 and (var2 ~= math.huge and var2 ~= -math.huge) then var2 else 0
		var8 = if typeof(v1.Damage) == "number" then math.max(0, v1.Damage) else nil
		tbl4.Damage = var8
		var8 = if typeof(v1.Range) == "number" then math.max(0, v1.Range) else nil
		tbl4.Range = var8
		var8 = if typeof(v1.AttackCooldown) == "number" then math.max(0, v1.AttackCooldown) else nil
		tbl4.AttackCooldown = var8
		var8 = if typeof(v1.DeathSplashDamage) == "number" then math.max(0, v1.DeathSplashDamage) else nil
		tbl4.DeathSplashDamage = var8
		var8 = if typeof(v1.DeathSplashRadius) == "number" then math.max(0, v1.DeathSplashRadius) else nil
		tbl4.DeathSplashRadius = var8
		tbl4.Animations = var6
		table.insert(tbl1, tbl4)
	end

	return tbl1
end

local function sanitizeBarricade(arg1)
	if typeof(arg1) ~= "table" then
		return nil
	end

	local var1 = arg1.Health
	local var2 = arg1.MaxUnits
	local var3 = if typeof(var1) ~= "number" or (var1 ~= var1 or (var1 == math.huge or var1 == -math.huge)) then 0 else math.max(0, var1)
	var1 = math.floor(if typeof(var2) ~= "number" or (var2 ~= var2 or (var2 == math.huge or var2 == -math.huge)) then 0 else math.max(0, var2))
	if var3 <= 0 or var1 <= 0 then
		return nil
	end

	var2 = if typeof(arg1.Unit) == "string" and arg1.Unit ~= "" then arg1.Unit else nil
	local tbl1 = { Unit = var2 }
	tbl1.Pieces = sanitizeBarricadePieces(arg1.Pieces)
	var2 = if typeof(arg1.DisplayName) == "string" and arg1.DisplayName ~= "" then arg1.DisplayName else "Barricade"
	tbl1.DisplayName = var2
	tbl1.Health = var3
	tbl1.MaxUnits = var1
	local var4 = arg1.Cooldown
	local num1 = 0.5
	tbl1.Cooldown = math.max(num1, if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then 8 else math.max(0, var4))
	num1 = arg1.Lifetime
	var2 = if typeof(num1) ~= "number" or (num1 ~= num1 or (num1 == math.huge or num1 == -math.huge)) then 0 else math.max(0, num1)
	tbl1.Lifetime = var2
	var4 = arg1.BlockRadius
	num1 = 1
	tbl1.BlockRadius = math.max(num1, if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then 4 else math.max(0, var4))
	num1 = arg1.MobDamage
	var2 = if typeof(num1) ~= "number" or (num1 ~= num1 or (num1 == math.huge or num1 == -math.huge)) then 25 else math.max(0, num1)
	tbl1.MobDamage = var2
	var4 = arg1.MobHitCooldown
	num1 = 0.1
	tbl1.MobHitCooldown = math.max(num1, if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then 0.5 else math.max(0, var4))
	var4 = arg1.Spacing
	num1 = 1
	tbl1.Spacing = math.max(num1, if typeof(var4) ~= "number" or (var4 ~= var4 or (var4 == math.huge or var4 == -math.huge)) then 8 else math.max(0, var4))
	var2 = if typeof(arg1.HeightOffset) == "number" then arg1.HeightOffset else 0
	tbl1.HeightOffset = var2
	var2 = if typeof(arg1.Size) == "Vector3" then arg1.Size else Vector3.new(4, 3, 1)
	tbl1.Size = var2
	var2 = if typeof(arg1.Color) == "Color3" then arg1.Color else Color3.fromRGB(255, 132, 40)
	tbl1.Color = var2
	return tbl1
end

str1 = {
	Price = 0,
	UpgradePrice = nil,
	SellPrice = 0,
	Damage = 0,
	Range = 0,
	Cooldown = 1,
	AttackType = "Single",
	AttackAngle = 0,
	SplashRadius = 0,
	Level = 1,
	Rarity = "Common",
	Icon = "",
	SupportType = nil,
	Income = 0,
	Heal = 0,
	SlowPercent = 0,
	SlowDuration = 0,
	SpawnUnit = nil,
	SpawnCooldown = 0,
	SpawnUnits = {},
	SpawnerHp = nil,
	SpawnLifetime = 0,
	SpawnMoveSpeed = 0,
	SpawnMaxUnits = 0,
}

tbl3.hasLevel = function(arg1, arg2)
	local var2 = tbl3.Levels[arg1]
	local bool1 = false
	if var2 ~= nil then
		bool1 = var2[arg2] ~= nil
	end

	return bool1
end

tbl3.getMaxLevel = function(arg1)
	local var2 = tbl3.Levels[arg1]
	local num1 = 0
	if not var2 then
		return num1
	end

	for k1 in pairs(var2) do
		if num1 >= k1 then
			continue
		end

		num1 = k1
	end

	return num1
end

tbl3.hasNextLevel = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2 + 1
	return tbl3.hasLevel(var1, var2)
end

local function copyDefaultStats(arg1)
	local tbl1 = {
		Price = str1.Price,
		UpgradePrice = nil,
		SellPrice = str1.SellPrice,
		Damage = str1.Damage,
		Range = str1.Range,
		Cooldown = str1.Cooldown,
		AttackType = str1.AttackType,
		AttackAngle = str1.AttackAngle,
		SplashRadius = str1.SplashRadius,
		Level = arg1,
		Rarity = str1.Rarity,
		Icon = str1.Icon,
		SupportType = str1.SupportType,
		Income = str1.Income,
		Heal = str1.Heal,
		SlowPercent = str1.SlowPercent,
		SlowDuration = str1.SlowDuration,
		SpawnUnit = str1.SpawnUnit,
		SpawnCooldown = str1.SpawnCooldown,
		SpawnUnits = sanitizeSpawnUnits(str1.SpawnUnits),
		Barricade = nil,
		NoAttack = false,
		HandRange = 0,
		HandDamage = 0,
		HandCooldown = 0,
		HandAttackAngle = 0,
	}

	tbl1.SpawnerHp = str1.SpawnerHp
	tbl1.SpawnLifetime = str1.SpawnLifetime
	tbl1.SpawnMoveSpeed = str1.SpawnMoveSpeed
	tbl1.SpawnMaxUnits = str1.SpawnMaxUnits
	return tbl1
end

local function applyStats(arg1, arg2)
	if arg2.Price ~= nil then
		arg1.Price = arg2.Price
	end

	if arg2.SellPrice ~= nil then
		arg1.SellPrice = arg2.SellPrice
	end

	if arg2.Damage ~= nil then
		arg1.Damage = arg2.Damage
	end

	if arg2.Range ~= nil then
		arg1.Range = arg2.Range
	end

	if arg2.Cooldown ~= nil then
		arg1.Cooldown = arg2.Cooldown
	end

	if arg2.AttackType ~= nil then
		arg1.AttackType = arg2.AttackType
	end

	if arg2.AttackAngle ~= nil then
		local var3 = arg2.AttackAngle
		local var4 = if var3 ~= var3 or (var3 == math.huge or var3 == -math.huge) then 0 else math.clamp(var3, 0, 360)
		arg1.AttackAngle = var4
	end

	if arg2.SplashRadius ~= nil then
		arg1.SplashRadius = math.max(0, arg2.SplashRadius)
	end

	if arg2.Rarity ~= nil then
		arg1.Rarity = arg2.Rarity
	end

	if arg2.Icon ~= nil then
		arg1.Icon = arg2.Icon
	end

	if arg2.SupportType ~= nil then
		arg1.SupportType = arg2.SupportType
	end

	if arg2.Income ~= nil then
		arg1.Income = math.max(0, arg2.Income)
	end

	if arg2.Heal ~= nil then
		arg1.Heal = math.max(0, arg2.Heal)
	end

	if arg2.SlowPercent ~= nil then
		arg1.SlowPercent = math.clamp(arg2.SlowPercent, 0, 100)
	end

	if arg2.SlowDuration ~= nil then
		arg1.SlowDuration = math.max(0, arg2.SlowDuration)
	end

	if arg2.SpawnUnit ~= nil then
		arg1.SpawnUnit = arg2.SpawnUnit
	end

	if arg2.SpawnCooldown ~= nil then
		arg1.SpawnCooldown = math.max(0, arg2.SpawnCooldown)
	end

	if arg2.SpawnUnits ~= nil then
		arg1.SpawnUnits = sanitizeSpawnUnits(arg2.SpawnUnits)
	end

	local var6 = arg2.SpawnerHp
	if arg2.SpawnerHp ~= nil and (var6 == var6 and (var6 ~= math.huge and var6 ~= -math.huge)) then
		arg1.SpawnerHp = math.max(1, var6)
	end

	if arg2.SpawnLifetime ~= nil then
		arg1.SpawnLifetime = math.max(0, arg2.SpawnLifetime)
	end

	if arg2.SpawnMoveSpeed ~= nil then
		arg1.SpawnMoveSpeed = math.max(0, arg2.SpawnMoveSpeed)
	end

	if arg2.SpawnMaxUnits ~= nil then
		arg1.SpawnMaxUnits = math.max(0, (math.floor(arg2.SpawnMaxUnits)))
	end

	if arg2.Barricade ~= nil then
		arg1.Barricade = sanitizeBarricade(arg2.Barricade)
	end

	if arg2.NoAttack ~= nil then
		arg1.NoAttack = arg2.NoAttack == true
	end

	if arg2.HandRange ~= nil then
		local var7 = arg2.HandRange
		local num1 = 0
		arg1.HandRange = math.max(num1, if typeof(var7) ~= "number" or (var7 ~= var7 or (var7 == math.huge or var7 == -math.huge)) then 0 else math.max(0, var7))
	end

	if arg2.HandDamage ~= nil then
		local var8 = arg2.HandDamage
		local num2 = 0
		arg1.HandDamage = math.max(num2, if typeof(var8) ~= "number" or (var8 ~= var8 or (var8 == math.huge or var8 == -math.huge)) then 0 else math.max(0, var8))
	end

	if arg2.HandCooldown ~= nil then
		local var9 = arg2.HandCooldown
		local num3 = 0
		arg1.HandCooldown = math.max(num3, if typeof(var9) ~= "number" or (var9 ~= var9 or (var9 == math.huge or var9 == -math.huge)) then 0 else math.max(0, var9))
	end

	if arg2.HandAttackAngle ~= nil then
		local var12 = arg2.HandAttackAngle
		var6 = if var12 ~= var12 or (var12 == math.huge or var12 == -math.huge) then 0 else math.clamp(var12, 0, 360)
		arg1.HandAttackAngle = var6
	end
end

tbl3.getStats = function(arg1, arg2)
	local var1 = math.max(1, (math.floor(arg2 or 1)))
	local var3 = tbl3.Levels[arg1]
	local var4 = copyDefaultStats(var1)
	if not var3 then
		return var4
	end

	for i1 = 1, var1 do
		local var5 = var3[i1]
		if not var5 then
			continue
		end

		applyStats(var4, var5)
	end

	local var6 = var3[var1]
	var4.UpgradePrice = var6 and var6.UpgradePrice or nil
	return var4
end

tbl3.getNextStats = function(arg1, arg2)
	local var1 = arg2 + 1
	if not tbl3.hasLevel(arg1, var1) then
		return nil
	end

	local var2 = arg1
	local var3 = var1
	return tbl3.getStats(var2, var3)
end

tbl3.getBaseUnits = function()
	local tbl1 = {}
	for k1 in pairs(tbl3.Levels) do
		tbl1[k1] = tbl3.getStats(k1, 1)
	end

	return tbl1
end

return tbl3

--- ReplicatedStorage.Modules.TroopsData [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules")
local var2 = var1:FindFirstChild("TowerConfig")
local var3 = require(var2 or var1:WaitForChild("TowerUnitConfig"))
return { Troops = var3.Units, DefaultInventory = { Inventory = { Slots = var3.DefaultSlots } } }

--- ReplicatedStorage.Modules.TowerAnimator [ModuleScript]
-- y u r i

local str1 = "TowerAnimationConfig"
local var1 = require(script.Parent:WaitForChild(str1))
local var2 = game:GetService("ReplicatedStorage")
local var3 = setmetatable({}, { __mode = "k" })
local num1 = 1
local var4 = setmetatable({}, { __mode = "k" })
local function refreshAllSpeeds()
	for k1, v1 in pairs(var4) do
		for k2, v2 in pairs(v1) do
			local var1 = var3[v2]
			if not var1 then
				continue
			end

			if not v2.IsPlaying then
				continue
			end

			v2:AdjustSpeed(var1 * num1)
		end
	end
end

local function bindGameSpeed()
	local var3 = var2:FindFirstChild("WaveState")
	if not var3 then
		return false
	end

	local var4 = var2:FindFirstChild("WaveState")
	local var5 = var4
	var5 = var5 and var4:GetAttribute("GameSpeed")
	local var6 = if typeof(var5) == "number" and 0 < var5 then var5 else 1
	num1 = var6
	refreshAllSpeeds()
	var3:GetAttributeChangedSignal("GameSpeed"):Connect(function()
		local var1 = var2:FindFirstChild("WaveState")
		local var3 = var1
		var3 = var3 and var1:GetAttribute("GameSpeed")
		local var4 = if typeof(var3) == "number" and 0 < var3 then var3 else 1
		num1 = var4
		refreshAllSpeeds()
	end)

	return true
end

task.spawn(function()
	if bindGameSpeed() then
		return
	end

	if var2:WaitForChild("WaveState", 30) then
		bindGameSpeed()
	end
end)

local var5 = setmetatable({}, { __mode = "k" })
local var6 = setmetatable({}, { __mode = "k" })
local var7 = game:GetService("TweenService")
local function collectScreenParts(arg1, arg2)
	local var2 = var5[arg1]
	local var3
	if var2 == nil or #var2 == 0 then
		var3 = false
	else
		for k1, v1 in ipairs(var2) do
			if v1.Parent ~= nil then
				continue
			end

			var3 = false
		end

		var3 = true
	end

	if var3 then
		return var2
	end

	local var4 = arg2.PartNames
	var3 = {}
	local var7 = nil
	if type(var4) == "table" and 0 < (#var4) then
		var7 = {}
		for k2, v2 in ipairs(var4) do
			if type(v2) ~= "string" or v2 == "" then
				continue
			end

			var7[v2] = true
		end
	end

	for k3, v3 in ipairs(arg1:GetDescendants()) do
		if not v3:IsA("BasePart") then
			continue
		end

		if var7 then
			if not var7[v3.Name] then
				continue
			end

			table.insert(var3, v3)
		else
			local var8 = v3.Color
			local var9 = arg2.IdleColor
			local bool2 = false
			if math.abs(var8.R - var9.R) <= 0.02 then
				bool2 = false
				if math.abs(var8.G - var9.G) <= 0.02 then
					bool2 = math.abs(var8.B - var9.B) <= 0.02
				end
			end

			if not bool2 then
				continue
			end

			table.insert(var3, v3)
		end
	end

	if var7 and #var3 == 0 then
		for k4, v4 in ipairs(arg1:GetDescendants()) do
			if not v4:IsA("BasePart") then
				continue
			end

			local var10 = v4.Color
			local var11 = arg2.IdleColor
			local bool4 = false
			if math.abs(var10.R - var11.R) <= 0.02 then
				bool4 = false
				if math.abs(var10.G - var11.G) <= 0.02 then
					bool4 = math.abs(var10.B - var11.B) <= 0.02
				end
			end

			if not bool4 then
				continue
			end

			table.insert(var3, v4)
		end
	end

	if 0 < (#var3) then
		var5[arg1] = var3
		return var3
	end

	var5[arg1] = nil
	return var3
end

local tbl1 = { Attack = true, AbilityAttack = true }
local function tweenScreenParts(arg1, arg2, arg3)
	for k1, v1 in ipairs(arg1) do
		local var2 = var6[v1]
		if var2 then
			var2:Cancel()
			var6[v1] = nil
		end

		if not v1.Parent then
			continue
		end

		if arg3 <= 0 then
			v1.Color = arg2
		else
			local var3 = TweenInfo.new(arg3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local var4 = var7:Create(v1, var3, { Color = arg2 })
			var6[v1] = var4
			var4:Play()
		end
	end
end

local var8 = setmetatable({}, { __mode = "k" })
local tbl2 = { Idle = true, Lower = true, AbilityLower = true }
str1 = setmetatable({}, { __mode = "k" })
local var9 = setmetatable({}, { __mode = "k" })
local var10 = setmetatable({}, { __mode = "k" })
local var11 = setmetatable({}, { __mode = "k" })
local var12 = setmetatable({}, { __mode = "k" })
local var13 = game:GetService("ContentProvider")
local tbl3 = {
	["Engineer Camera Man"] = { Idle = "rbxassetid://80798075253258" },
	["Scientist Camera Man"] = { Idle = "rbxassetid://110033341731609" },
	["Large Scientist Camera Man"] = { Idle = "rbxassetid://115210838085240", Attack = "rbxassetid://98967875479404" },
}

local function findAnimation(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= arg2 then
			continue
		end

		if not v1:IsA("Animation") then
			continue
		end

		return v1
	end

	return nil
end

local function restoreIdle(arg1)
	if not var10[arg1] then
		return
	end

	var10[arg1] = nil
	local var1 = var4[arg1]
	local var2 = var1
	var2 = var2 and var1.Idle
	if var2 and (not var2.IsPlaying) then
		var2.Looped = true
		var2.Priority = Enum.AnimationPriority.Idle
		var2:Play(0.15, 1, num1 * 1)
		var3[var2] = 1
		var2:AdjustSpeed(num1 * 1)
	end
end

local tbl4 = { updateScreen = function(arg1, arg2, arg3)
	if not arg1 or (not arg1.Parent) then
		return
	end

	local var2 = arg1:GetAttribute("UnitId")
	local var3 = var1.getScreen
	var3 = var3(if typeof(var2) == "string" and var2 ~= "" then var2 else arg1.Name)
	if var3 == nil then
		return
	end

	local var4 = collectScreenParts(arg1, var3)
	if #var4 == 0 then
		return
	end

	if tbl1[arg2] then
		tweenScreenParts(var4, var3.AttackColor, var3.AttackTime or 0.08)
		var2 = (var8[arg1] or 0) + 1
		var8[arg1] = var2
		local var5 = var3.HoldTime
		if typeof(var5) == "number" then
			if var5 <= 0 then
				local var7 = tonumber(arg3)
				var5 = if var7 and 0 < var7 then var7 * 1.15 else 0.6
			end
		end

		task.delay(var5, function()
			if var8[arg1] ~= var2 or (not arg1.Parent) then
				return
			end

			tweenScreenParts(var4, var3.IdleColor, var3.IdleTime or 0.3)
		end)

		return
	end

	if tbl2[arg2] then
		var8[arg1] = (var8[arg1] or 0) + 1
		tweenScreenParts(var4, var3.IdleColor, var3.IdleTime or 0.3)
	end
end }

local tbl5 = { Idle = true, Lower = true, AbilityLower = true }
local function getAnimation(arg1, arg2)
	local var2 = arg1:GetAttribute("UnitId")
	local var3 = if typeof(var2) == "string" and var2 ~= "" then var2 else arg1.Name
	local var4 = var1.getAnimationId(var3, arg2)
	var2 = tbl3[var3]
	var4 = var4 or var2 and var2[arg2]
	local var6 = arg1:FindFirstChild("Animations")
	if var4 then
		if not var6 then
			var6 = Instance.new("Folder")
			var6.Name = "Animations"
			var6.Parent = arg1
		end

		local var8 = findAnimation(var6, arg2)
		if not var8 then
			var8 = Instance.new("Animation")
			var8.Name = arg2
			var8.Parent = var6
		end

		if var8.AnimationId ~= var4 then
			var8.AnimationId = var4
		end

		return var8
	end

	if var6 then
		return (findAnimation(var6, arg2))
	end

	return nil
end

local function stopConflictingActionTracks(arg1, arg2, arg3)
	for k1, v1 in ipairs(arg1:GetPlayingAnimationTracks()) do
		if v1 == arg3 then
			continue
		end

		if v1.Animation and v1.Animation.AnimationId == arg2.AnimationId or (v1.Priority == Enum.AnimationPriority.Action or (v1.Priority == Enum.AnimationPriority.Action2 or (v1.Priority == Enum.AnimationPriority.Action3 or v1.Priority == Enum.AnimationPriority.Action4))) then
			v1:Stop(0.05)
		end
	end
end

local function adjustSpeedWhenLoaded(arg1, arg2, arg3, arg4, arg5)
	local var2 = if typeof(arg4) ~= "number" or (arg4 ~= arg4 or (arg4 == math.huge or (arg4 == -math.huge or arg4 <= 0))) then nil else arg4
	if not var2 then
		return
	end

	if 0 < arg3.Length then
		local var5 = arg2 ~= "Attack"
		local var8 = if typeof(var2) ~= "number" or (var2 ~= var2 or (var2 == math.huge or (var2 == -math.huge or var2 <= 0))) then nil else var2
		local var9 = arg3.Length
		local var10
		if not var8 or var9 <= 0 then
			var10 = 1
		elseif var5 then
			var11 = 0.05
		else
			var11 = 1
		end

		var3[arg3] = var10
		arg3:AdjustSpeed(var10 * num1)
		return
	end

	task.spawn(function()
		for i1 = 1, 60 do
			local var5 = var4[arg1]
			if str1[arg1] ~= arg5 or (not arg1.Parent or (not var5 or var5[arg2] ~= arg3)) then
				return
			end

			task.wait()
			if 0 >= arg3.Length then
				continue
			end

			var5 = var4[arg1]
			if str1[arg1] == arg5 then
				if arg1.Parent then
					if arg3.IsPlaying then
						if var5 then
							if var5[arg2] == arg3 then
								if arg3.TimePosition <= 0.05 then
									local var6 = var2
									local var7 = arg3
									local var8 = arg3
									local var9 = arg2 ~= "Attack"
									local var12 = if typeof(var6) ~= "number" or (var6 ~= var6 or (var6 == math.huge or (var6 == -math.huge or var6 <= 0))) then nil else var6
									local var13 = var8.Length
									local var14
									if not var12 or var13 <= 0 then
										var14 = 1
									elseif var9 then
										var15 = 0.05
									else
										var15 = 1
									end

									var3[var7] = var14
									var7:AdjustSpeed(var14 * num1)
								end
							end
						end
					end
				end
			end

			return
		end
	end)
end

tbl4.play = function(arg1, arg2, arg3)
	if not arg1 or (not arg1.Parent) then
		return
	end

	tbl4.updateScreen(arg1, arg2, arg3)
	if tbl5[arg2] then
		local var6 = var9[arg1]
		if var6 then
			if var6 ~= nil then
				if var6.IsPlaying then
					var6:Stop(0.15)
				end

				var11[var6] = nil
				var9[arg1] = nil
			end
		end

		restoreIdle(arg1)
	end

	local var8 = arg1:FindFirstChildOfClass("Humanoid")
	local var13 = getAnimation(arg1, arg2)
	local var14
	if var8 then
		var14 = var8:FindFirstChildOfClass("Animator")
	else
		local var16 = arg1:FindFirstChildOfClass("AnimationController")
		var14 = if var16 then var16:FindFirstChildOfClass("Animator") else nil
	end

	if not var13 or (not var14) then
		return
	end

	local var17 = var4[arg1]
	var4[arg1] = var17 or {}
	if not var4[arg1][arg2] then
		var4[arg1][arg2] = var14:LoadAnimation(var13)
	end

	var8 = var4[arg1][arg2]
	if arg2 == "Idle" then
		var8.Looped = true
		var8.Priority = Enum.AnimationPriority.Idle
		if not var8.IsPlaying then
			var8:Play(0.1, 1, num1 * 1)
		end

		var3[var8] = 1
		var8:AdjustSpeed(num1 * 1)
		return
	end

	local var18 = arg1:GetAttribute("UnitId")
	var17 = var1.isHold
	if var17(if typeof(var18) == "string" and var18 ~= "" then var18 else arg1.Name, arg2) then
		var17 = var9[arg1]
		if var17 then
			if var17 ~= var8 then
				if var17.IsPlaying then
					var17:Stop(0.15)
				end

				var11[var17] = nil
				var9[arg1] = nil
			end
		end

		if var8 == nil then
			restoreIdle(arg1)
		end

		var18 = arg1:GetAttribute("UnitId")
		var17 = var1.holdLoops
		var17 = var17(if typeof(var18) == "string" and var18 ~= "" then var18 else arg1.Name, arg2)
		local bool2 = false
		if var9[arg1] == var8 then
			bool2 = var8.IsPlaying
		end

		var8.Looped = true
		var8.Priority = Enum.AnimationPriority.Movement
		if not var8.IsPlaying then
			var11[var8] = nil
			var8.TimePosition = 0
			var8:Play(0.15, 1, num1 * 1)
		end

		var9[arg1] = var8
		if not var11[var8] then
			var3[var8] = 1
			var8:AdjustSpeed(num1 * 1)
			if not var17 and (not bool2) then
				var18 = (var12[arg1] or 0) + 1
				var12[arg1] = var18
				task.spawn(function()
					local num2 = 0
					while var8.Length <= 0 and num2 < 60 do
						task.wait()
						if var12[arg1] == var18 then
							continue
						end

						return
					end

					if var8.Length <= 0 then
						return
					end

					local var1 = math.max(0, var8.Length - 0.03)
					local var2 = var8.TimePosition
					local var4 = var8.TimePosition
					while var12[arg1] == var18 and var9[arg1] == var8 and var8.IsPlaying and (not var11[var8]) and var4 >= var2 and var8.Length - math.max((var4 - var2) * 1.25, 0.03) > var4 do
						task.wait()
						local var5 = var4
					end

					if var12[arg1] ~= var18 or (var9[arg1] ~= var8 or (not var8.IsPlaying)) then
						return
					end

					var11[var8] = true
					var4 = var8
					var3[var4] = 0
					var4:AdjustSpeed(num1 * 0)
					var8.TimePosition = var1
				end)

			end
		end

		local var19 = arg1:GetAttribute("UnitId")
		var18 = var1.keepsIdle
		if not var18(if typeof(var19) == "string" and var19 ~= "" then var19 else arg1.Name, arg2) then
			local var21 = var4[arg1]
			var18 = var21
			var18 = var18 and var21.Idle
			if var18 and var18.IsPlaying then
				var18:Stop(0.15)
				var10[arg1] = true
			end
		end

		return
	end

	var8.Looped = false
	var8.Priority = Enum.AnimationPriority.Action
	stopConflictingActionTracks(var14, var13, var8)
	local var22 = arg2 ~= "Attack"
	var18 = if typeof(arg3) ~= "number" or (arg3 ~= arg3 or (arg3 == math.huge or (arg3 == -math.huge or arg3 <= 0))) then nil else arg3
	local var24 = var8.Length
	if not var18 or var24 <= 0 then
		var17 = 1
	elseif var22 then
		var25 = 0.05
	else
		var25 = 1
	end

	var18 = if typeof(arg3) ~= "number" or (arg3 ~= arg3 or (arg3 == math.huge or (arg3 == -math.huge or arg3 <= 0))) then nil else arg3
	var22 = if not var18 then 0.05 else math.min(0.05, var18 * 0.25)
	var18 = (str1[arg1] or 0) + 1
	str1[arg1] = var18
	if var8.IsPlaying and 0 < var8.Length then
		var3[var8] = var17
		var8:AdjustSpeed(var17 * num1)
		var8.TimePosition = 0
	else
		if var8.IsPlaying then
			var8:Stop(0)
		end

		var8:Play(var22, 1, var17 * num1)
		var3[var8] = var17
		var8.TimePosition = 0
	end

	adjustSpeedWhenLoaded(arg1, arg2, var8, arg3, var18)
end

tbl4.playIdle = function(arg1)
	tbl4.play(arg1, "Idle")
end

tbl4.playAttack = function(arg1, arg2)
	tbl4.play(arg1, "Attack", arg2)
end

local var14 = setmetatable({}, { __mode = "k" })
local tbl6 = {
	"Idle",
	"Charge",
	"Attack",
	"HandAttack",
	"Build",
	"Reload",
	"Lower",
	"AbilityCharge",
	"AbilityAttack",
	"AbilityLower",
}

tbl4.prepare = function(arg1)
	if not arg1 or (not arg1.Parent or var14[arg1]) then
		return
	end

	var14[arg1] = true
	task.spawn(function()
		local var1 = arg1
		local var3 = var1:FindFirstChildOfClass("Humanoid")
		local var5
		if var3 then
			var5 = var3:FindFirstChildOfClass("Animator")
		else
			local var7 = var1:FindFirstChildOfClass("AnimationController")
			var5 = if var7 then var7:FindFirstChildOfClass("Animator") else nil
		end

		var1 = 0
		while not var5 and var1 < 120 do
			task.wait()
			if not arg1.Parent then
				return
			end

			var3 = arg1
			local var9 = var3:FindFirstChildOfClass("Humanoid")
			local var10
			if var9 then
				var5 = var9:FindFirstChildOfClass("Animator")
			else
				local var12 = var3:FindFirstChildOfClass("AnimationController")
				if var12 then
					var10 = "Animator"
					var5 = var12:FindFirstChildOfClass(var10)
				else
					var5 = nil
				end
			end

			var1 = var1 + 1
		end

		if not var5 or (not arg1.Parent) then
			return
		end

		var3 = {}
		for k1, v1 in ipairs(tbl6) do
			local var14 = getAnimation(arg1, v1)
			if not var14 then
				continue
			end

			table.insert(var3, var14)
		end

		if #var3 == 0 then
			return
		end

		pcall(function()
			var13:PreloadAsync(var3)
		end)

		if not arg1.Parent then
			return
		end

		local var16 = var4[arg1]
		if not var16 then
			var16 = {}
			var4[arg1] = var16
		end

		for k2, v2 in ipairs(tbl6) do
			if var16[v2] then
				continue
			end

			local var17 = getAnimation(arg1, v2)
			if not var17 then
				continue
			end

			var16[v2] = var5:LoadAnimation(var17)
		end
	end)
end

task.spawn(function()
	local var2 = workspace:WaitForChild("Towers", 60)
	if not var2 then
		return
	end

	for k1, v1 in ipairs(var2:GetChildren()) do
		if not v1:IsA("Model") then
			continue
		end

		tbl4.prepare(v1)
	end

	var2.ChildAdded:Connect(function(arg1)
		if arg1:IsA("Model") then
			tbl4.prepare(arg1)
		end
	end)
end)

local function reviveModel(arg1)
	local var2 = var4[arg1]
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2) do
		local var3 = v1.IsPlaying
		if not var3 then
			continue
		end

		return
	end

	local var6 = var9[arg1]
	if var6 then
		for k2, v2 in pairs(var2) do
			if v2 ~= var6 then
				continue
			end

			local var7 = k2
		end

		local var8 = nil
		var8 = var8 or nil
	end

	local var14 = nil
	if var14 then
		var9[arg1] = nil
		var11[var6] = nil
		var12[arg1] = (var12[arg1] or 0) + 1
		tbl4.play(arg1, var14)
		return
	end

	var10[arg1] = nil
	tbl4.play(arg1, "Idle")
end

task.spawn(function()
	while true do
		task.wait(0.4)
		for k1 in pairs(var4) do
			if typeof(k1) ~= "Instance" then
				continue
			end

			if not k1.Parent then
				continue
			end

			pcall(reviveModel, k1)
		end
	end
end)

return tbl4

--- ReplicatedStorage.Modules.TowerConfig [ModuleScript]
-- y u r i

local str1 = "TowerLevelStats"
local var1 = require(script.Parent:WaitForChild(str1))
local tbl1 = { Units = var1.getBaseUnits() }
tbl1.DefaultSlots = { {}, {}, {}, {}, {} }
tbl1.getUnitId = function(arg1)
	if typeof(arg1) == "Instance" then
		local var1 = arg1:GetAttribute("UnitId")
		if typeof(var1) == "string" and var1 ~= "" then
			return var1
		end

		return arg1.Name
	end

	if typeof(arg1) == "string" and arg1 ~= "" then
		return arg1
	end

	return ""
end

tbl1.getLevel = function(arg1)
	local var1
	if not arg1 then
		var1 = nil
	else
		local var2 = arg1:GetAttribute("Level")
		if typeof(var2) == "number" then
			var1 = var2
		else
			var1 = if typeof(var2) == "string" then tonumber(var2) else nil
		end
	end

	if var1 then
		return (math.max(1, (math.floor(var1))))
	end

	return 1
end

tbl1.getStats = function(arg1, arg2)
	local var2 = tbl1.getLevel(arg2)
	local var3 = var1.getStats(arg2 and tbl1.getUnitId(arg2) or arg1, var2)
	local var4
	if not arg2 then
		var4 = nil
	else
		local var5 = arg2:GetAttribute("Price")
		if typeof(var5) == "number" then
			var4 = var5
		else
			var4 = if typeof(var5) == "string" then tonumber(var5) else nil
		end
	end

	var4 = var4 or var3.Price
	local var6
	if not arg2 then
		var6 = nil
	else
		local var7 = arg2:GetAttribute("Damage")
		if typeof(var7) == "number" then
			var6 = var7
		else
			var6 = if typeof(var7) == "string" then tonumber(var7) else nil
		end
	end

	var6 = var6 or var3.Damage
	local var8
	if not arg2 then
		var8 = nil
	else
		local var9 = arg2:GetAttribute("Range")
		if typeof(var9) == "number" then
			var8 = var9
		else
			var8 = if typeof(var9) == "string" then tonumber(var9) else nil
		end
	end

	var8 = var8 or var3.Range
	local var10
	if not arg2 then
		var10 = nil
	else
		local var11 = arg2:GetAttribute("Cooldown")
		if typeof(var11) == "number" then
			var10 = var11
		else
			var10 = if typeof(var11) == "string" then tonumber(var11) else nil
		end
	end

	var10 = var10 or var3.Cooldown
	local var12
	if not arg2 then
		var12 = nil
	else
		local var13 = arg2:GetAttribute("SellPrice")
		if typeof(var13) == "number" then
			var12 = var13
		else
			var12 = if typeof(var13) == "string" then tonumber(var13) else nil
		end
	end

	var12 = var12 or var3.SellPrice
	local var14
	if not arg2 then
		var14 = nil
	else
		local var15 = arg2:GetAttribute("UpgradePrice")
		if typeof(var15) == "number" then
			var14 = var15
		else
			var14 = if typeof(var15) == "string" then tonumber(var15) else nil
		end
	end

	var14 = var14 or var3.UpgradePrice
	local var16
	if not arg2 then
		var16 = nil
	else
		local var18 = arg2:GetAttribute("AttackType")
		var16 = if var18 == "Single" or (var18 == "Cone" or var18 == "Splash") then var18 else nil
	end

	var16 = var16 or var3.AttackType
	local var19
	if not arg2 then
		var19 = nil
	else
		local var20 = arg2:GetAttribute("AttackAngle")
		if typeof(var20) == "number" then
			var19 = var20
		else
			var19 = if typeof(var20) == "string" then tonumber(var20) else nil
		end
	end

	var19 = var19 or var3.AttackAngle
	local var21
	if not arg2 then
		var21 = nil
	else
		local var22 = arg2:GetAttribute("SplashRadius")
		if typeof(var22) == "number" then
			var21 = var22
		else
			var21 = if typeof(var22) == "string" then tonumber(var22) else nil
		end
	end

	var21 = var21 or var3.SplashRadius
	local var23
	if not arg2 then
		var23 = nil
	else
		local var25 = arg2:GetAttribute("SupportType")
		var23 = if var25 == "Income" or (var25 == "Heal" or var25 == "Booster") then var25 else nil
	end

	var23 = var23 or var3.SupportType
	local var26
	if not arg2 then
		var26 = nil
	else
		local var27 = arg2:GetAttribute("Income")
		if typeof(var27) == "number" then
			var26 = var27
		else
			var26 = if typeof(var27) == "string" then tonumber(var27) else nil
		end
	end

	var26 = var26 or var3.Income
	local var28
	if not arg2 then
		var28 = nil
	else
		local var29 = arg2:GetAttribute("Heal")
		if typeof(var29) == "number" then
			var28 = var29
		else
			var28 = if typeof(var29) == "string" then tonumber(var29) else nil
		end
	end

	var28 = var28 or var3.Heal
	local var30
	if not arg2 then
		var30 = nil
	else
		local var31 = arg2:GetAttribute("SlowPercent")
		if typeof(var31) == "number" then
			var30 = var31
		else
			var30 = if typeof(var31) == "string" then tonumber(var31) else nil
		end
	end

	var30 = var30 or var3.SlowPercent
	local var32
	if not arg2 then
		var32 = nil
	else
		local var33 = arg2:GetAttribute("SlowDuration")
		if typeof(var33) == "number" then
			var32 = var33
		else
			var32 = if typeof(var33) == "string" then tonumber(var33) else nil
		end
	end

	var32 = var32 or var3.SlowDuration
	local var34
	if not arg2 then
		var34 = nil
	else
		local var35 = arg2:GetAttribute("SpawnUnit")
		var34 = if typeof(var35) == "string" and var35 ~= "" then var35 else nil
	end

	var34 = var34 or var3.SpawnUnit
	local var36
	if not arg2 then
		var36 = nil
	else
		local var37 = arg2:GetAttribute("SpawnCooldown")
		if typeof(var37) == "number" then
			var36 = var37
		else
			var36 = if typeof(var37) == "string" then tonumber(var37) else nil
		end
	end

	var36 = var36 or var3.SpawnCooldown
	local var38 = var3.SpawnUnits
	local var39
	if not arg2 then
		var39 = nil
	else
		local var40 = arg2:GetAttribute("SpawnerHp")
		if typeof(var40) == "number" then
			var39 = var40
		else
			var39 = if typeof(var40) == "string" then tonumber(var40) else nil
		end
	end

	var39 = var39 or var3.SpawnerHp
	local var41
	if not arg2 then
		var41 = nil
	else
		local var42 = arg2:GetAttribute("SpawnLifetime")
		if typeof(var42) == "number" then
			var41 = var42
		else
			var41 = if typeof(var42) == "string" then tonumber(var42) else nil
		end
	end

	var41 = var41 or var3.SpawnLifetime
	local var43
	if not arg2 then
		var43 = nil
	else
		local var44 = arg2:GetAttribute("SpawnMoveSpeed")
		if typeof(var44) == "number" then
			var43 = var44
		else
			var43 = if typeof(var44) == "string" then tonumber(var44) else nil
		end
	end

	var43 = var43 or var3.SpawnMoveSpeed
	local var45
	if not arg2 then
		var45 = nil
	else
		local var46 = arg2:GetAttribute("SpawnMaxUnits")
		if typeof(var46) == "number" then
			var45 = var46
		else
			var45 = if typeof(var46) == "string" then tonumber(var46) else nil
		end
	end

	var45 = var45 or var3.SpawnMaxUnits
	local var47
	if not arg2 then
		var47 = nil
	else
		local var48 = arg2:GetAttribute("HandRange")
		if typeof(var48) == "number" then
			var47 = var48
		else
			var47 = if typeof(var48) == "string" then tonumber(var48) else nil
		end
	end

	var47 = var47 or var3.HandRange
	local var49
	if not arg2 then
		var49 = nil
	else
		local var50 = arg2:GetAttribute("HandDamage")
		if typeof(var50) == "number" then
			var49 = var50
		else
			var49 = if typeof(var50) == "string" then tonumber(var50) else nil
		end
	end

	var49 = var49 or var3.HandDamage
	local var51
	if not arg2 then
		var51 = nil
	else
		local var52 = arg2:GetAttribute("HandCooldown")
		if typeof(var52) == "number" then
			var51 = var52
		else
			var51 = if typeof(var52) == "string" then tonumber(var52) else nil
		end
	end

	var51 = var51 or var3.HandCooldown
	local var53 = if var19 ~= var19 or (var19 == math.huge or var19 == -math.huge) then 0 else math.clamp(var19, 0, 360)
	local tbl2 = {
		Price = var4,
		UpgradePrice = var14,
		SellPrice = var12,
		Damage = var6,
		Range = var8,
		Cooldown = var10,
		AttackType = var16,
		AttackAngle = var53,
	}

	tbl2.SplashRadius = math.max(0, var21)
	tbl2.Level = var2
	tbl2.Rarity = var3.Rarity
	tbl2.Icon = var3.Icon
	tbl2.SupportType = var23
	tbl2.Income = math.max(0, var26)
	tbl2.Heal = math.max(0, var28)
	tbl2.SlowPercent = math.clamp(var30, 0, 100)
	tbl2.SlowDuration = math.max(0, var32)
	tbl2.SpawnUnit = var34
	tbl2.SpawnCooldown = math.max(0, var36)
	tbl2.SpawnUnits = var38
	var53 = if typeof(var39) == "number" then math.max(1, var39) else nil
	tbl2.SpawnerHp = var53
	tbl2.SpawnLifetime = math.max(0, var41)
	tbl2.SpawnMoveSpeed = math.max(0, var43)
	tbl2.SpawnMaxUnits = math.max(0, (math.floor(var45)))
	tbl2.HandRange = math.max(0, var47 or 0)
	tbl2.HandDamage = math.max(0, var49 or 0)
	tbl2.HandCooldown = math.max(0, var51 or 0)
	return tbl2
end

tbl1.getStatsFromStorage = function(arg1, arg2)
	local var5 = arg2:FindFirstChild(arg1)
	if var5 and var5:IsA("Model") then
		local var6 = arg1
		local var7 = var5
		return tbl1.getStats(var6, var7)
	end

	local var8 = arg1
	local num1 = 1
	return var1.getStats(var8, num1)
end

tbl1.getLevelStats = function(arg1, arg2)
	local var2 = arg1
	local var3 = arg2
	return var1.getStats(var2, var3)
end

tbl1.getNextStats = function(arg1, arg2)
	local var2 = arg1
	local var3 = arg2
	return var1.getNextStats(var2, var3)
end

tbl1.hasNextLevel = function(arg1, arg2)
	local var2 = arg1
	local var3 = arg2
	return var1.hasNextLevel(var2, var3)
end

tbl1.getMaxLevel = function(arg1)
	local var2 = arg1
	return var1.getMaxLevel(var2)
end

tbl1.getSlotName = function(arg1)
	if typeof(arg1) == "table" then
		return arg1.Name
	end

	if typeof(arg1) == "string" and arg1 ~= "" then
		return arg1
	end

	return nil
end

tbl1.getDefaultSlots = function(_)
	return { {}, {}, {}, {}, {} }
end

tbl1.hasAnySlot = function(arg1)
	for i1 = 1, 5 do
		local var2 = arg1[i1]
		if not var2 then
			var2 = arg1[tostring(i1)]
		end

		if not tbl1.getSlotName(var2) then
			continue
		end

		return true
	end

	return false
end

tbl1.normalizeSlots = function(arg1, arg2)
	local var1 = tbl1.getDefaultSlots(arg2)
	if typeof(arg1) ~= "table" then
		return var1
	end

	for i1 = 1, 5 do
		local var3 = arg1[i1]
		if not var3 then
			var3 = arg1[tostring(i1)]
		end

		local var4 = tbl1.getSlotName(var3)
		if not var4 then
			continue
		end

		if tbl1.Units[var4] == nil then
			continue
		end

		var1[i1] = { Name = var4 }
	end

	return var1
end

return tbl1

--- ReplicatedStorage.Modules.PresentGiftConfig [ModuleScript]
-- y u r i

local tbl1 = {
	UnitName = "Present Camera Man",
	Types = { "Boom", "Confusion", "Poison" },
	Models = { Boom = "GiftBoom", Confusion = "GiftConfusion", Poison = "GiftPoison" },
	GiftScale = 0.4,
	ThrowSeconds = 0.6,
	ThrowHeight = 4,
	ReleaseDelay = 0.3,
	Spacing = 4,
	ContactRadius = 2,
	MaxVerticalContactDistance = 12,
	Lifetime = 120,
	DefaultEmitCount = 12,
	EffectSeconds = 6,
	PoisonColor = Color3.fromRGB(60, 255, 70),
}

tbl1.PoisonFillTransparency = 0.65
tbl1.PoisonOutlineTransparency = 0
tbl1.Animations = { Idle = "rbxassetid://111129961393487", Attack = "rbxassetid://72303081763273" }
tbl1.Levels = {
	{
		Range = 14,
		Cooldown = 8,
		MaxGifts = 6,
		Health = 100,
		Boom = { Radius = 6, Damage = 150 },
		Confusion = { Radius = 6, SlowPercent = 25, Duration = 3 },
		Poison = { Radius = 6, DamagePerTick = 10, Duration = 5, TickInterval = 1 },
	},
	{
		Range = 16,
		Cooldown = 7,
		MaxGifts = 8,
		Health = 250,
		Boom = { Radius = 7, Damage = 300 },
		Confusion = { Radius = 7, SlowPercent = 30, Duration = 4 },
		Poison = { Radius = 7, DamagePerTick = 20, Duration = 6, TickInterval = 1 },
	},
	{
		Range = 18,
		Cooldown = 6,
		MaxGifts = 10,
		Health = 500,
		Boom = { Radius = 8, Damage = 650 },
		Confusion = { Radius = 8, SlowPercent = 35, Duration = 5 },
		Poison = { Radius = 8, DamagePerTick = 35, Duration = 7, TickInterval = 1 },
	},
	{
		Range = 20,
		Cooldown = 5,
		MaxGifts = 12,
		Health = 900,
		Boom = { Radius = 9, Damage = 1000 },
		Confusion = { Radius = 9, SlowPercent = 40, Duration = 6 },
		Poison = { Radius = 9, DamagePerTick = 60, Duration = 8, TickInterval = 1 },
	},
}

tbl1.GetLevel = function(arg1)
	return tbl1.Levels[math.clamp(math.floor(tonumber(arg1) or 1), 1, #tbl1.Levels)]
end

tbl1.ContactDamage = function(arg1, arg2)
	return (math.max(0, (math.min(arg1, arg2))))
end

return tbl1

--- ReplicatedStorage.Modules.TitanCannonConfig [ModuleScript]
-- y u r i

local tbl1 = {
	Guns = { "Cube.713", "Cube.768" },
	Core = "Cylinder.028",
	Color = Color3.fromRGB(65, 190, 255),
	Speed = 130,
	Size = 1.1,
	CoreDuration = 0.2,
}

local tbl2 = { ["10M Upgraded Titan Speakerman"] = tbl1 }
tbl1 = { Guns = { "Circle.032" }, Color = Color3.fromRGB(65, 190, 255), Speed = 130, Size = 0.9 }
tbl2["Upgraded Titan Camera Man"] = tbl1
tbl2["10M Titan Speaker Man"] = tbl2["10M Upgraded Titan Speakerman"]
return tbl2

--- ReplicatedStorage.Modules.TitanCannonEffects [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local str1 = "TitanCannonConfig"
local var2 = require(var1:WaitForChild("Modules"):WaitForChild(str1))
local var3 = game:GetService("TweenService")
local var4 = game:GetService("Debris")
local function findPart(arg1, arg2)
	for k1, v1 in ipairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if v1.Name ~= arg2 then
			continue
		end

		return v1
	end

	return nil
end

local function fireProjectile(arg1, arg2, arg3)
	local var5 = var1:FindFirstChild("WaveState")
	local var6 = math.max(0.1, tonumber(arg3.Size) or 0.72)
	local var7 = math.clamp((arg2 - arg1).Magnitude / math.max(1, tonumber(arg3.Speed) or 175), 0.04, 1.5)
	if var5 then
		local str2 = "GameSpeed"
		local var8 = tonumber(var5:GetAttribute(str2))
		var8 = var8 or 1
	end

	local var9 = var7 / math.clamp(1 or 1, 0.1, 10)
	var7 = Instance.new("Part")
	var7.Name = "TitanCannonBall"
	var7.Anchored = true
	var7.CanCollide = false
	var7.CanQuery = false
	var7.CanTouch = false
	var7.CastShadow = false
	var7.Material = Enum.Material.Neon
	var7.Color = arg3.Color
	var7.Shape = Enum.PartType.Ball
	var7.Size = Vector3.new(1, 1, 1) * var6
	var7.CFrame = CFrame.new(arg1)
	var7.Parent = workspace
	local var10 = TweenInfo.new(var9, Enum.EasingStyle.Linear)
	local var11 = var3:Create(var7, var10, { Position = arg2, Size = Vector3.new(1, 1, 1) * var6 * 0.72 })
	var11.Completed:Once(function()
		var7:Destroy()
	end)

	var4:AddItem(var7, var9 + 0.5)
	var11:Play()
end

local function fireCore(arg1, arg2, arg3)
	local var5 = (arg2 - arg1).Magnitude
	if var5 < 0.01 then
		return
	end

	local var6 = Instance.new("Part")
	var6.Name = "TitanCoreBeam"
	var6.Anchored = true
	var6.CanCollide = false
	var6.CanQuery = false
	var6.CanTouch = false
	var6.CastShadow = false
	var6.Material = Enum.Material.Neon
	var6.Color = arg3.Color
	local var7 = math.max(0.1, tonumber(arg3.CoreWidth) or 0.65)
	var6.Size = Vector3.new(var7, var7, var5)
	var6.CFrame = CFrame.lookAt((arg1 + arg2) * 0.5, arg2)
	var6.Parent = workspace
	local var9 = var1:FindFirstChild("WaveState")
	local var10 = math.max(0.03, tonumber(arg3.CoreDuration) or 0.16)
	if var9 then
		local str2 = "GameSpeed"
		local var11 = tonumber(var9:GetAttribute(str2))
		var11 = var11 or 1
	end

	local var12 = var10 / math.clamp(1 or 1, 0.1, 10)
	var3:Create(var6, TweenInfo.new(var12), { Transparency = 1 }):Play()
	var4:AddItem(var6, var12 + 0.05)
end

var1:WaitForChild("RemoteEvents"):WaitForChild("TitanCannonEffect").OnClientEvent:Connect(function(arg1, arg2, arg3)
	if typeof(arg1) ~= "Instance" or (not arg1:IsA("Model") or (not arg1:IsDescendantOf(workspace) or typeof(arg3) ~= "Vector3")) then
		return
	end

	local var1 = arg1:GetAttribute("UnitId")
	if typeof(var1) == "string" then
		if var1 == "" then
			var1 = arg1.Name
		end
	end

	local var4 = var2[var1]
	if not var4 then
		return
	end

	if arg2 == "Guns" then
		local var5 = var4.Guns
		for k1, v1 in ipairs(var5 or {}) do
			local var6 = findPart(arg1, v1)
			if not var6 then
				continue
			end

			local var8 = var6:FindFirstChild("Muzzle", true)
			local var9 = fireProjectile
			local var10
			if var8 and var8:IsA("Attachment") then
				var10 = var8.WorldPosition
			else
				local var12 = var6:FindFirstChildWhichIsA("Attachment", true)
				var10 = if var12 then var12.WorldPosition else var6.Position
			end

			var9(var10, arg3, var4)
		end

		return
	end

	if arg2 == "Core" then
		if var4.Core then
			local var19 = findPart(arg1, var4.Core)
			if var19 then
				local var21 = var19:FindFirstChild("Muzzle", true)
				local var22 = fireCore
				local var23
				if var21 and var21:IsA("Attachment") then
					var23 = var21.WorldPosition
				else
					local var25 = var19:FindFirstChildWhichIsA("Attachment", true)
					var23 = if var25 then var25.WorldPosition else var19.Position
				end

				var22(var23, arg3, var4)
				for k2, v2 in ipairs(var19:GetDescendants()) do
					if not v2:IsA("ParticleEmitter") then
						continue
					end

					v2:Emit(3)
				end
			end
		end
	end
end)

--- Workspace.Map.Decor.Easymap.UIs.Health.SurfaceGui.BaseController [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.hspspjl.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

