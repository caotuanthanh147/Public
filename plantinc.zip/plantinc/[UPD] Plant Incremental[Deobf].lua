--- Players.LocalPlayer.PlayerScripts.PlayerModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local str1 = "CameraModule"
	local var1 = setmetatable({}, tbl1)
	var1.cameras = require(script:WaitForChild(str1))
	str1 = "ControlModule"
	var1.controls = require(script:WaitForChild(str1))
	return var1
end

tbl1.GetCameras = function(arg1)
	return arg1.cameras
end

tbl1.GetControls = function(arg1)
	return arg1.controls
end

tbl1.GetClickToMoveController = function(arg1)
	return arg1.controls:GetClickToMoveController()
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
local var1 = script.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local var3 = require(var1:WaitForChild(str2))
local str4 = "CameraInput"
local var4 = require(script:WaitForChild(str3))
local str5 = "ClassicCamera"
str1 = require(script:WaitForChild(str4))
local str6 = "OrbitalCamera"
str2 = require(script:WaitForChild(str5))
local str7 = "LegacyCamera"
str3 = require(script:WaitForChild(str6))
local str8 = "VehicleCamera"
str4 = require(script:WaitForChild(str7))
local str9 = "VRCamera"
str5 = require(script:WaitForChild(str8))
local str10 = "VRVehicleCamera"
str6 = require(script:WaitForChild(str9))
local str11 = "Invisicam"
str7 = require(script:WaitForChild(str10))
local str12 = "Poppercam"
str8 = require(script:WaitForChild(str11))
local str13 = "TransparencyController"
str9 = require(script:WaitForChild(str12))
local str14 = "MouseLockController"
str10 = require(script:WaitForChild(str13))
local var5 = game:GetService("Players")
str11 = require(script:WaitForChild(str14))
local tbl2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock",
}

local tbl3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode",
}

local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("VRService")
local var9 = UserSettings():GetService("UserGameSettings")
str12 = {}
str13 = {}
if not var5.LocalPlayer then
	return {}
end

assert(var5.LocalPlayer, "Strict typing check")
str14 = var5.LocalPlayer:WaitForChild("PlayerScripts")
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
str14:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
str14:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
str14 = var3.getUserFlag("UserPlayerConnectionMemoryLeak")
local var10 = var3.getUserFlag("UserPSFixCameraControllerReset")
tbl1.new = function()
	local tbl4 = { activeTransparencyController = str10.new() }
	local var1 = if str14 then var2.new() else nil
	tbl4.connectionUtil = var1
	local var3 = setmetatable(tbl4, tbl1)
	var3.activeCameraController = nil
	var3.activeOcclusionModule = nil
	var3.activeMouseLockController = nil
	var3.currentComputerCameraMovementMode = nil
	var3.cameraSubjectChangedConn = nil
	var3.cameraTypeChangedConn = nil
	for k1, v1 in pairs(var5:GetPlayers()) do
		var3:OnPlayerAdded(v1)
	end

	var5.PlayerAdded:Connect(function(arg1)
		var3:OnPlayerAdded(arg1)
	end)

	if str14 then
		var5.PlayerRemoving:Connect(function(arg1)
			var3:OnPlayerRemoving(arg1)
		end)

	end

	var3.activeTransparencyController:Enable(true)
	var3.activeMouseLockController = str11.new()
	assert(var3.activeMouseLockController, "Strict typing check")
	tbl4 = var3.activeMouseLockController:GetBindableToggleEvent()
	if tbl4 then
		tbl4:Connect(function()
			var3:OnMouseLockToggled()
		end)

	end

	var3:ActivateCameraController()
	var3:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
	var3:OnCurrentCameraChanged()
	local function fn2(arg1)
		var3:Update(arg1)
	end

	var6:BindToRenderStep("cameraRenderUpdate", Enum.RenderPriority.Camera.Value, fn2)
	for k2, v2 in pairs(tbl2) do
		var5.LocalPlayer:GetPropertyChangedSignal(v2):Connect(function()
			var3:OnLocalPlayerCameraPropertyChanged(v2)
		end)

	end

	for k3, v3 in pairs(tbl3) do
		var9:GetPropertyChangedSignal(v3):Connect(function()
			var3:OnUserGameSettingsPropertyChanged(v3)
		end)

	end

	game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		var3:OnCurrentCameraChanged()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var3:OnPreferredInputChanged()
	end)

	return var3
end

tbl1.GetCameraMovementModeFromSettings = function(_)
	if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		local var2 = Enum.ComputerCameraMovementMode.Classic
		return var4.ConvertCameraModeEnumToStandard(var2)
	end

	local var8 = nil
	local var10 = nil
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevTouchCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.TouchCameraMovementMode)
	else
		var8 = var4.ConvertCameraModeEnumToStandard(var5.LocalPlayer.DevComputerCameraMode)
		var10 = var4.ConvertCameraModeEnumToStandard(var9.ComputerCameraMovementMode)
	end

	if var8 == Enum.DevComputerCameraMovementMode.UserChoice then
		return var10
	end

	return var8
end

tbl1.ActivateOcclusionModule = function(arg1, arg2)
	local var2 = nil
	if arg2 == Enum.DevCameraOcclusionMode.Zoom then
		var2 = str9
	else
		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			var2 = str8
		else
			warn("CameraScript ActivateOcclusionModule called with unsupported mode")
			return
		end
	end

	arg1.occlusionMode = arg2
	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() == arg2 then
			if not arg1.activeOcclusionModule:GetEnabled() then
				arg1.activeOcclusionModule:Enable(true)
			end

			return
		end
	end

	local var3 = arg1.activeOcclusionModule
	arg1.activeOcclusionModule = str13[var2]
	if not arg1.activeOcclusionModule then
		arg1.activeOcclusionModule = var2.new()
		if arg1.activeOcclusionModule then
			str13[var2] = arg1.activeOcclusionModule
		end
	end

	if arg1.activeOcclusionModule then
		if arg1.activeOcclusionModule:GetOcclusionMode() ~= arg2 then
			warn("CameraScript ActivateOcclusionModule mismatch: ", arg1.activeOcclusionModule:GetOcclusionMode(), "~=", arg2)
		end

		if var3 then
			if var3 ~= arg1.activeOcclusionModule then
				var3:Enable(false)
			else
				warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
			end
		end

		if arg2 == Enum.DevCameraOcclusionMode.Invisicam then
			if var5.LocalPlayer.Character then
				arg1.activeOcclusionModule:CharacterAdded(var5.LocalPlayer.Character, var5.LocalPlayer)
			end
		else
			for k1, v1 in pairs(var5:GetPlayers()) do
				if not v1 then
					continue
				end

				if not v1.Character then
					continue
				end

				arg1.activeOcclusionModule:CharacterAdded(v1.Character, v1)
			end

			arg1.activeOcclusionModule:OnCameraSubjectChanged(game.Workspace.CurrentCamera.CameraSubject)
		end

		arg1.activeOcclusionModule:Enable(true)
	end
end

tbl1.ShouldUseVehicleCamera = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return false
	end

	local var4 = var2.CameraType
	local var5 = var2.CameraSubject
	local bool1 = true
	if var4 ~= Enum.CameraType.Custom then
		bool1 = var4 == Enum.CameraType.Follow
	end

	local var6 = var5 and var5:IsA("VehicleSeat")
	return var6 and (bool1 and arg1.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam)
end

tbl1.ActivateCameraController = function(arg1)
	local var2 = workspace.CurrentCamera.CameraType
	local var3 = arg1:GetCameraMovementModeFromSettings()
	local var4 = nil
	if var2 == Enum.CameraType.Scriptable then
		if arg1.activeCameraController then
			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = nil
		end

		return
	end

	if var2 == Enum.CameraType.Custom then
		var3 = arg1:GetCameraMovementModeFromSettings()
	else
		if var2 == Enum.CameraType.Track then
			var3 = Enum.ComputerCameraMovementMode.Classic
		else
			if var2 == Enum.CameraType.Follow then
				var3 = Enum.ComputerCameraMovementMode.Follow
			else
				if var2 == Enum.CameraType.Orbital then
					var3 = Enum.ComputerCameraMovementMode.Orbital
				else
					if var2 == Enum.CameraType.Attach or (var2 == Enum.CameraType.Watch or var2 == Enum.CameraType.Fixed) then
						var4 = str4
					else
						warn("CameraScript encountered an unhandled Camera.CameraType value: ", var2)
					end
				end
			end
		end
	end

	if not var4 then
		if var8.VREnabled then
			var4 = str6
		else
			if var3 == Enum.ComputerCameraMovementMode.Classic or (var3 == Enum.ComputerCameraMovementMode.Follow or (var3 == Enum.ComputerCameraMovementMode.Default or var3 == Enum.ComputerCameraMovementMode.CameraToggle)) then
				var4 = str2
			else
				if var3 == Enum.ComputerCameraMovementMode.Orbital then
					var4 = str3
				else
					warn("ActivateCameraController did not select a module.")
					return
				end
			end
		end
	end

	if arg1:ShouldUseVehicleCamera() then
		var4 = if var8.VREnabled then str7 else str5
	end

	local var6 = nil
	if not str12[var4] then
		var6 = var4.new()
		str12[var4] = var6
	else
		var6 = str12[var4]
		if var10 then
			if var6.Reset and arg1.activeCameraController ~= var6 then
				var6:Reset()
			end
		else
			if var6.Reset then
				var6:Reset()
			end
		end
	end

	if arg1.activeCameraController then
		if arg1.activeCameraController ~= var6 then
			if var6.HandleSubjectDistance then
				var6:HandleSubjectDistance(arg1.activeCameraController)
			end

			arg1.activeCameraController:Enable(false)
			arg1.activeCameraController = var6
			arg1.activeCameraController:Enable(true)
		else
			if not arg1.activeCameraController:GetEnabled() then
				arg1.activeCameraController:Enable(true)
			end
		end
	elseif var6 ~= nil then
		arg1.activeCameraController = var6
		assert(arg1.activeCameraController, "Strict typing check")
		arg1.activeCameraController:Enable(true)
	end

	if arg1.activeCameraController then
		arg1.activeCameraController:SetCameraMovementMode(var3)
		arg1.activeCameraController:SetCameraType(var2)
	end
end

tbl1.OnCameraSubjectChanged = function(arg1)
	local var2 = workspace.CurrentCamera
	local var4 = if var2 then var2.CameraSubject else nil
	if arg1.activeTransparencyController then
		arg1.activeTransparencyController:SetSubject(var4)
	end

	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:OnCameraSubjectChanged(var4)
	end

	arg1:ActivateCameraController()
end

tbl1.OnCameraTypeChanged = function(arg1, arg2)
	if arg2 == Enum.CameraType.Scriptable and var7.MouseBehavior == Enum.MouseBehavior.LockCenter then
		var4.restoreMouseBehavior()
	end

	arg1:ActivateCameraController()
end

tbl1.OnCurrentCameraChanged = function(arg1)
	local var2 = game.Workspace.CurrentCamera
	if not var2 then
		return
	end

	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
	end

	if arg1.cameraTypeChangedConn then
		arg1.cameraTypeChangedConn:Disconnect()
	end

	arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		arg1:OnCameraSubjectChanged()
	end)

	arg1.cameraTypeChangedConn = var2:GetPropertyChangedSignal("CameraType"):Connect(function()
		arg1:OnCameraTypeChanged(var2.CameraType)
	end)

	arg1:OnCameraSubjectChanged()
	arg1:OnCameraTypeChanged(var2.CameraType)
end

tbl1.OnLocalPlayerCameraPropertyChanged = function(arg1, arg2)
	if arg2 == "CameraMode" then
		if var5.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			if not arg1.activeCameraController or arg1.activeCameraController:GetModuleName() ~= "ClassicCamera" then
				arg1:ActivateCameraController()
			end

			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end

		if var5.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
			arg1:ActivateCameraController()
			return
		end

		warn("Unhandled value for property player.CameraMode: ", var5.LocalPlayer.CameraMode)
		return
	end

	if arg2 == "DevComputerCameraMode" or arg2 == "DevTouchCameraMode" then
		arg1:ActivateCameraController()
		return
	end

	if arg2 == "DevCameraOcclusionMode" then
		arg1:ActivateOcclusionModule(var5.LocalPlayer.DevCameraOcclusionMode)
		return
	end

	if arg2 ~= "CameraMinZoomDistance" then
		if arg2 == "CameraMaxZoomDistance" then
			if not arg1.activeCameraController then
				return
			end

			arg1.activeCameraController:UpdateForDistancePropertyChange()
			return
		end
	end

	if arg2 == "DevTouchMovementMode" then
		return
	end

	if arg2 == "DevComputerMovementMode" then
		return
	end

	if arg2 == "DevEnableMouseLock" then
	end
end

tbl1.OnUserGameSettingsPropertyChanged = function(arg1, arg2)
	if arg2 == "ComputerCameraMovementMode" or arg2 == "TouchCameraMovementMode" then
		arg1:ActivateCameraController()
	end
end

tbl1.OnPreferredInputChanged = function(arg1)
	arg1:ActivateCameraController()
end

tbl1.Update = function(arg1, arg2)
	if arg1.activeCameraController then
		arg1.activeCameraController:UpdateMouseBehavior()
		local var5, var6 = arg1.activeCameraController:Update(arg2)
		if arg1.activeOcclusionModule and (not arg1.activeCameraController.skipOcclusion) then
			local var7, var8 = arg1.activeOcclusionModule:Update(arg2, var5, var6)
			var5 = var7
			var6 = var8
		end

		local var9 = game.Workspace.CurrentCamera
		var9.CFrame = var5
		var9.Focus = var6
		if arg1.activeTransparencyController then
			arg1.activeTransparencyController:Update(arg2)
		end

		if str1.getInputEnabled() then
			str1.resetInputForFrameEnd()
		end
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterAdded(arg2, arg3)
	end
end

tbl1.OnCharacterRemoving = function(arg1, arg2, arg3)
	if arg1.activeOcclusionModule then
		arg1.activeOcclusionModule:CharacterRemoving(arg2, arg3)
	end
end

tbl1.OnPlayerAdded = function(arg1, arg2)
	if str14 then
		if not arg1.connectionUtil then
			return
		end

		local function fn6(arg1)
			arg1:OnCharacterAdded(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterAdded"):format(arg2.UserId), arg2.CharacterAdded:Connect(fn6))
		fn6 = function(arg1)
			arg1:OnCharacterRemoving(arg1, arg2)
		end

		arg1.connectionUtil:trackConnection(("%*CharacterRemoving"):format(arg2.UserId), arg2.CharacterRemoving:Connect(fn6))
		return
	end

	arg2.CharacterAdded:Connect(function(arg1)
		arg1:OnCharacterAdded(arg1, arg2)
	end)

	arg2.CharacterRemoving:Connect(function(arg1)
		arg1:OnCharacterRemoving(arg1, arg2)
	end)
end

tbl1.OnPlayerRemoving = function(arg1, arg2)
	if arg1.connectionUtil then
		arg1.connectionUtil:disconnect((("%*CharacterAdded"):format(arg2.UserId)))
		arg1.connectionUtil:disconnect((("%*CharacterRemoving"):format(arg2.UserId)))
	end
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = arg1.activeMouseLockController:GetIsMouseLocked()
	local var2 = arg1.activeMouseLockController:GetMouseLockOffset()
	if arg1.activeMouseLockController and arg1.activeCameraController then
		arg1.activeCameraController:SetIsMouseLocked(var1)
		arg1.activeCameraController:SetMouseLockOffset(var2)
	end
end

tbl1.new()
return {}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ClassicCamera [ModuleScript]
-- y u r i

Vector2.new(0, 0)
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixCameraFPError")
local str2 = "CameraInput"
local str3 = "CameraUtils"
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = CFrame.fromOrientation(-0.26179938779914941, 0, 0)
local var5 = game:GetService("Players")
str2 = setmetatable({}, var3)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(var3.new(), str2)
	var1.isFollowCamera = false
	var1.isCameraToggle = false
	var1.lastUpdate = tick()
	var1.cameraToggleSpring = var2.Spring.new(5, 0)
	return var1
end

str2.GetCameraToggleOffset = function(arg1, arg2)
	if arg1.isCameraToggle then
		local var4 = arg1.currentSubjectDistance
		if str1.getTogglePan() then
			arg1.cameraToggleSpring.goal = math.clamp(var2.map(var4, 0.5, arg1.FIRST_PERSON_DISTANCE_THRESHOLD, 0, 1), 0, 1)
		else
			arg1.cameraToggleSpring.goal = 0
		end

		return (Vector3.new(0, arg1.cameraToggleSpring:step(arg2) * (math.clamp(var2.map(var4, 0.5, 64, 0, 1), 0, 1) + 1), 0))
	end

	return (Vector3.new())
end

str2.SetCameraMovementMode = function(arg1, arg2)
	var3.SetCameraMovementMode(arg1, arg2)
	arg1.isFollowCamera = arg2 == Enum.ComputerCameraMovementMode.Follow
	arg1.isCameraToggle = arg2 == Enum.ComputerCameraMovementMode.CameraToggle
end

local num1 = 0
str2.Update = function(arg1, arg2)
	local var3 = workspace.CurrentCamera
	local var8 = tick()
	local var9 = var3.CFrame
	local var10 = var3.Focus
	local var11 = nil
	if arg1.resetCameraAngle then
		local var13 = arg1:GetHumanoidRootPart()
		arg1.resetCameraAngle = false
		var11 = if var13 then (var13.CFrame * var4).lookVector else var4.lookVector
	end

	local var14 = var3.CameraSubject
	local var15 = var14
	local var16 = var14
	local var17 = arg1:GetHumanoid()
	local var19 = var17
	local var20 = var5.LocalPlayer
	var15 = var15 and var14:IsA("VehicleSeat")
	var16 = var16 and var14:IsA("SkateboardPlatform")
	if var19 then
		var19 = var17:GetState() == Enum.HumanoidStateType.Climbing
	end

	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:StepZoom()
	local var22 = str1.getRotation(arg2)
	local var23 = arg1:GetCameraHeight()
	if var22 ~= Vector2.new() then
		num1 = 0
		arg1.lastUserPanCamera = tick()
	end

	local var26 = arg1:GetSubjectPosition()
	local var27 = var8 - arg1.lastUserPanCamera < 2
	if var26 then
		if var20 then
			if var3 then
				local var31 = arg1:GetCameraToSubjectDistance()
				if var31 < 0.5 then
					var31 = 0.5
				end

				if arg1:GetIsMouseLocked() then
					if not arg1:IsInFirstPerson() then
						local var32 = arg1:CalculateNewLookCFrameFromArg(var11, var22)
						local var33 = arg1:GetMouseLockOffset()
						if var17 then
							var33 = var33 + var17.CameraOffset
						end

						local var34 = var33.X * var32.RightVector + var33.Y * var32.UpVector + var33.Z * var32.LookVector
						if var2.IsFiniteVector3(var34) then
							var26 = var26 + var34
						end
					else
						if not (var22 ~= Vector2.new()) then
							if arg1.lastCameraTransform then
								local var37 = arg1:IsInFirstPerson()
								if not var15 then
									if var16 or arg1.isFollowCamera and var19 then
										if arg1.lastUpdate then
											if var17 then
												if var17.Torso then
													if var37 then
														if arg1.lastSubjectCFrame then
															if not var15 then
																if var16 then
																	if var14:IsA("BasePart") then
																		local var47 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																		if var2.IsFinite(var47) then
																			var22 = var22 + Vector2.new(var47, 0)
																		end

																		num1 = 0
																	end
																end
															end
														end
													elseif not var27 then
														local var48 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
														num1 = var48
														local var49 = var17.Torso.CFrame.lookVector
														var48 = math.clamp(num1 * arg2, 0, 1)
														if arg1:IsInFirstPerson() then
															var48 = arg1.isFollowCamera and arg1.isClimbing or 1
														end

														local var50 = var2.GetAngleBetweenXZVectors(var49, arg1:GetCameraLookVector())
														if var2.IsFinite(var50) and 0.0001 < math.abs(var50) then
															var22 = var22 + Vector2.new(var50 * var48, 0)
														end
													end
												else
													local var52 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
													if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var52) and (0.0001 < math.abs(var52) and 0.4 * arg2 < math.abs(var52))))) then
														var22 = var22 + Vector2.new(var52, 0)
													end
												end
											else
												local var54 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var54) and (0.0001 < math.abs(var54) and 0.4 * arg2 < math.abs(var54))))) then
													var22 = var22 + Vector2.new(var54, 0)
												end
											end
										else
											local var56 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var56) and (0.0001 < math.abs(var56) and 0.4 * arg2 < math.abs(var56))))) then
												var22 = var22 + Vector2.new(var56, 0)
											end
										end
									else
										local var58 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var37 and (not var27 and (var2.IsFinite(var58) and (0.0001 < math.abs(var58) and 0.4 * arg2 < math.abs(var58))))) then
											var22 = var22 + Vector2.new(var58, 0)
										end
									end
								end
							end
						end
					end
				else
					if not (var22 ~= Vector2.new()) then
						if arg1.lastCameraTransform then
							local var61 = arg1:IsInFirstPerson()
							if not var15 then
								if var16 or arg1.isFollowCamera and var19 then
									if arg1.lastUpdate then
										if var17 then
											if var17.Torso then
												if var61 then
													if arg1.lastSubjectCFrame then
														if not var15 then
															if var16 then
																if var14:IsA("BasePart") then
																	local var71 = -var2.GetAngleBetweenXZVectors(arg1.lastSubjectCFrame.lookVector, var14.CFrame.lookVector)
																	if var2.IsFinite(var71) then
																		var22 = var22 + Vector2.new(var71, 0)
																	end

																	num1 = 0
																end
															end
														end
													end
												elseif not var27 then
													local var72 = math.clamp(num1 + 3.839724354387525 * arg2, 0, 4.3633231299858242)
													num1 = var72
													local var73 = var17.Torso.CFrame.lookVector
													var72 = math.clamp(num1 * arg2, 0, 1)
													if arg1:IsInFirstPerson() then
														var72 = arg1.isFollowCamera and arg1.isClimbing or 1
													end

													local var74 = var2.GetAngleBetweenXZVectors(var73, arg1:GetCameraLookVector())
													if var2.IsFinite(var74) and 0.0001 < math.abs(var74) then
														var22 = var22 + Vector2.new(var74 * var72, 0)
													end
												end
											else
												local var76 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
												if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var76) and (0.0001 < math.abs(var76) and 0.4 * arg2 < math.abs(var76))))) then
													var22 = var22 + Vector2.new(var76, 0)
												end
											end
										else
											local var78 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
											if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var78) and (0.0001 < math.abs(var78) and 0.4 * arg2 < math.abs(var78))))) then
												var22 = var22 + Vector2.new(var78, 0)
											end
										end
									else
										local var80 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
										if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var80) and (0.0001 < math.abs(var80) and 0.4 * arg2 < math.abs(var80))))) then
											var22 = var22 + Vector2.new(var80, 0)
										end
									end
								else
									local var82 = var2.GetAngleBetweenXZVectors(-(arg1.lastCameraTransform.p - var26), arg1:GetCameraLookVector())
									if arg1.isFollowCamera and (not var61 and (not var27 and (var2.IsFinite(var82) and (0.0001 < math.abs(var82) and 0.4 * arg2 < math.abs(var82))))) then
										var22 = var22 + Vector2.new(var82, 0)
									end
								end
							end
						end
					end
				end

				if not arg1.isFollowCamera then
					var10 = CFrame.new(var26)
					local var87 = var10.p
					local var88 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					if var1 then
						var9 = CFrame.lookAlong(var87 - var31 * var88, var88)
					else
						var9 = CFrame.new(var87 - var31 * var88, var87)
					end
				else
					var10 = CFrame.new(var26)
					local var90 = arg1:CalculateNewLookVectorFromArg(var11, var22)
					var9 = if var1 then CFrame.lookAlong(var10.p - var31 * var90, var90) else CFrame.new(var10.p - var31 * var90, var10.p) + Vector3.new(0, var23, 0)
				end

				local var91 = arg1:GetCameraToggleOffset(arg2)
				var9 = var9 + var91
				arg1.lastCameraTransform = var9
				var10 = var10 + var91
				arg1.lastCameraFocus = var10
				if (var15 or var16) and var14:IsA("BasePart") then
					arg1.lastSubjectCFrame = var14.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var8
	return var9, var10
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUtils [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("UserInputService")
local var3 = UserSettings():GetService("UserGameSettings")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2)
	return (setmetatable({ freq = arg1, goal = arg2, pos = arg2, vel = 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = arg1.pos - var1
	local var4 = arg1.vel
	local var5 = math.exp(-var2 * arg2)
	local var6 = (var3 * (var2 * arg2 + 1) + var4 * arg2) * var5 + var1
	arg1.pos = var6
	arg1.vel = (var4 * (1 - var2 * arg2) - var3 * (var2 * var2 * arg2)) * var5
	return var6
end

local tbl2 = {
	Spring = tbl1,
	map = function(arg1, arg2, arg3, arg4, arg5)
		return (arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4
	end,
	mapClamp = function(arg1, arg2, arg3, arg4, arg5)
		return (math.clamp((arg1 - arg2) * (arg5 - arg4) / (arg3 - arg2) + arg4, math.min(arg4, arg5), (math.max(arg4, arg5))))
	end,
	getLooseBoundingSphere = function(arg1)
		local var1 = table.create(#arg1)
		for k1, v1 in pairs(arg1) do
			var1[k1] = v1.Position
		end

		local var2 = var1[1]
		local var3 = var2
		local num1 = 0
		for k2, v2 in ipairs(var1) do
			local var4 = (v2 - var2).Magnitude
			if num1 >= var4 then
				continue
			end

			var3 = v2
			local var5 = var4
		end

		local var6 = var3
		local num2 = 0
		for k3, v3 in ipairs(var1) do
			local var7 = (v3 - var3).Magnitude
			if num2 >= var7 then
				continue
			end

			var6 = v3
			local var8 = var7
		end

		local var9 = (var3 + var6) * 0.5
		local var10 = (var3 - var6).Magnitude * 0.5
		for k4, v4 in ipairs(var1) do
			local var11 = (v4 - var9).Magnitude
			if var10 >= var11 then
				continue
			end

			var9 = var9 + (var11 - var10) * 0.5 * (v4 - var9).Unit
			var10 = (var11 + var10) * 0.5
		end

		return var9, var10
	end,
	sanitizeAngle = function(arg1)
		return (arg1 + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
	end,
	Round = function(arg1, arg2)
		local var1 = 10 ^ arg2
		return math.floor(arg1 * var1 + 0.5) / var1
	end,
	IsFinite = function(arg1)
		local bool2 = false
		if arg1 == arg1 then
			bool2 = false
			if arg1 ~= math.huge then
				bool2 = arg1 ~= -math.huge
			end
		end

		return bool2
	end,
}

tbl2.IsFiniteVector3 = function(arg1)
	local var1 = tbl2.IsFinite(arg1.X)
	return var1 and (tbl2.IsFinite(arg1.Y) and tbl2.IsFinite(arg1.Z))
end

tbl2.GetAngleBetweenXZVectors = function(arg1, arg2)
	return (math.atan2(arg2.X * arg1.Z - arg2.Z * arg1.X, arg2.X * arg1.X + arg2.Z * arg1.Z))
end

tbl2.RotateVectorByAngleAndRound = function(arg1, arg2, arg3)
	if 0 < arg1.Magnitude then
		arg1 = arg1.Unit
		return math.floor((math.atan2(arg1.Z, arg1.X) + arg2) / arg3 + 0.5) * arg3 - math.atan2(arg1.Z, arg1.X)
	end

	return 0
end

tbl2.GamepadLinearToCurve = function(arg1)
	local var2 = arg1.X
	local var3 = Vector2.new
	local num2 = 1
	if var2 < 0 then
		num2 = -1
	end

	local var5 = math.clamp((math.abs((math.abs(var2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	local var6 = math.clamp(((if 0 <= var5 then var5 * 0.35 / (0.35 - var5 + 1) else -(-var5 * 0.8 / (var5 + 0.8 + 1))) / 2 + 0.5) * num2, -1, 1)
	num2 = arg1.Y
	local num4 = 1
	if num2 < 0 then
		num4 = -1
	end

	local var8 = math.clamp((math.abs((math.abs(num2))) * 2 - 1) * 1.1 - 0.1, -1, 1)
	var2 = math.clamp(((if 0 <= var8 then var8 * 0.35 / (0.35 - var8 + 1) else -(-var8 * 0.8 / (var8 + 0.8 + 1))) / 2 + 0.5) * num4, -1, 1)
	return var3(var6, var2)
end

tbl2.ConvertCameraModeEnumToStandard = function(arg1)
	if arg1 == Enum.TouchCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.ComputerCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Classic or (arg1 == Enum.DevTouchCameraMovementMode.Classic or (arg1 == Enum.DevComputerCameraMovementMode.Classic or arg1 == Enum.ComputerCameraMovementMode.Classic)) then
		return Enum.ComputerCameraMovementMode.Classic
	end

	if arg1 == Enum.TouchCameraMovementMode.Follow or (arg1 == Enum.DevTouchCameraMovementMode.Follow or (arg1 == Enum.DevComputerCameraMovementMode.Follow or arg1 == Enum.ComputerCameraMovementMode.Follow)) then
		return Enum.ComputerCameraMovementMode.Follow
	end

	if arg1 == Enum.TouchCameraMovementMode.Orbital or (arg1 == Enum.DevTouchCameraMovementMode.Orbital or (arg1 == Enum.DevComputerCameraMovementMode.Orbital or arg1 == Enum.ComputerCameraMovementMode.Orbital)) then
		return Enum.ComputerCameraMovementMode.Orbital
	end

	if arg1 == Enum.ComputerCameraMovementMode.CameraToggle or arg1 == Enum.DevComputerCameraMovementMode.CameraToggle then
		return Enum.ComputerCameraMovementMode.CameraToggle
	end

	if arg1 == Enum.DevTouchCameraMovementMode.UserChoice or arg1 == Enum.DevComputerCameraMovementMode.UserChoice then
		return Enum.DevComputerCameraMovementMode.UserChoice
	end

	return Enum.ComputerCameraMovementMode.Classic
end

local var4 = nil
local str1 = ""
tbl2.setMouseIconOverride = function(arg1)
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon ~= var4 then
		str1 = var5.Icon
	end

	var5.Icon = arg1
	var4 = arg1
end

tbl2.restoreMouseIcon = function()
	local var3 = var1.LocalPlayer
	if not var3 then
		var1:GetPropertyChangedSignal("LocalPlayer"):Wait()
		var3 = var1.LocalPlayer
	end

	assert(var3)
	local var5 = var3:GetMouse()
	if var5.Icon == var4 then
		var5.Icon = str1
	end

	var4 = nil
end

local var5 = nil
local var6 = Enum.MouseBehavior.Default
tbl2.setMouseBehaviorOverride = function(arg1)
	if var2.MouseBehavior ~= var5 then
		var6 = var2.MouseBehavior
	end

	var2.MouseBehavior = arg1
	var5 = arg1
end

tbl2.restoreMouseBehavior = function()
	if var2.MouseBehavior == var5 then
		var2.MouseBehavior = var6
	end

	var5 = nil
end

local var7 = nil
local var8 = Enum.RotationType.MovementRelative
tbl2.setRotationTypeOverride = function(arg1)
	if var3.RotationType ~= var7 then
		var8 = var3.RotationType
	end

	var3.RotationType = arg1
	var7 = arg1
end

tbl2.restoreRotationType = function()
	if var3.RotationType == var7 then
		var3.RotationType = var8
	end

	var7 = nil
end

return tbl2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController [ModuleScript]
-- y u r i

game:GetService("Players")
game:GetService("UserInputService")
UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
local str2 = "CameraUI"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local var3 = require(script.Parent:WaitForChild(str3))
var2.setCameraModeToastEnabled(false)
str1 = false
str3 = false
str2 = tick()
local bool1 = false
local bool2 = false
return function(arg1)
	local var5 = var1.getTogglePan()
	if arg1 and var5 ~= str1 then
		str3 = true
	end

	if str1 == var5 then
		if 3 < tick() - str2 then
			local var7 = var5
			if var7 then
				var7 = tick() - str2 < 3
			end

			var2.setCameraModeToastOpen(var7)
			if var5 then
				str3 = false
			end

			str2 = tick()
			str1 = var5
		end
	end

	if arg1 ~= bool1 then
		if arg1 then
			bool2 = var1.getTogglePan()
			var1.setTogglePan(true)
		else
			if not str3 then
				var1.setTogglePan(bool2)
			end
		end
	end

	if arg1 then
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		else
			var3.restoreMouseIcon()
			var3.restoreMouseBehavior()
			var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		end
	else
		if var1.getTogglePan() then
			var3.setMouseIconOverride("rbxasset://textures/Cursors/CrossMouseIcon.png")
			var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
		else
			if var1.getHoldPan() then
				var3.restoreMouseIcon()
				var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
				var3.setRotationTypeOverride(Enum.RotationType.MovementRelative)
			else
				var3.restoreMouseIcon()
				var3.restoreMouseBehavior()
				var3.restoreRotationType()
			end
		end
	end

	bool1 = arg1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector [ModuleScript]
-- y u r i

local tbl1 = { JUMP_STUDS = 4, SETTLED_STUDS = 1, DEBOUNCE_SECONDS = 0.25 }
tbl1.shouldRecenter = function(arg1, arg2, arg3, arg4)
	if arg2 <= tbl1.JUMP_STUDS then
		return false
	end

	if arg1 ~= nil and tbl1.SETTLED_STUDS <= arg1 then
		return false
	end

	if arg3 ~= nil and arg4 - arg3 < tbl1.DEBOUNCE_SECONDS then
		return false
	end

	return true
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera [ModuleScript]
-- y u r i

local str1 = "CameraInput"
local str2 = "ZoomController"
local var1 = require(script.Parent:WaitForChild(str2))
local var2 = require(script.Parent:WaitForChild(str1))
local str3 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str3)).getUserFlag("UserVRRemoveLuaEdgeBlur")
local str4 = "BaseCamera"
local var3 = require(script.Parent:WaitForChild(str4))
local var4 = game:GetService("VRService")
local var5 = game:GetService("Players").LocalPlayer
local var6 = game:GetService("Lighting")
local var7 = game:GetService("RunService")
local var8 = UserSettings():GetService("UserGameSettings")
str3 = setmetatable({}, var3)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(var3.new(), str3)
	var1.gamepadZoomLevels = { 0, 7 }
	var1.headScale = 1
	var1:SetCameraToSubjectDistance(7)
	var1.VRFadeResetTimer = 0
	var1.VREdgeBlurTimer = 0
	var1.gamepadResetConnection = nil
	var1.needsReset = true
	var1.recentered = false
	var1:Reset()
	return var1
end

str3.Reset = function(arg1)
	arg1.stepRotateTimeout = 0
end

str3.GetModuleName = function(_)
	return "VRBaseCamera"
end

str3.GamepadZoomPress = function(arg1)
	var3.GamepadZoomPress(arg1)
	arg1:GamepadReset()
	arg1:ResetZoom()
end

str3.GamepadReset = function(arg1)
	arg1.stepRotateTimeout = 0
	arg1.needsReset = true
end

str3.ResetZoom = function(arg1)
	var1.SetZoomParameters(arg1.currentSubjectDistance, 0)
	var1.ReleaseSpring()
end

str3.OnEnabledChanged = function(arg1)
	var3.OnEnabledChanged(arg1)
	if arg1.enabled then
		arg1.gamepadResetConnection = var2.gamepadReset:Connect(function()
			arg1:GamepadReset()
		end)

		arg1.thirdPersonOptionChanged = var4:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function()
			arg1:Reset()
		end)

		arg1.vrRecentered = var4.UserCFrameChanged:Connect(function(arg1, _)
			if arg1 == Enum.UserCFrame.Floor then
				arg1.recentered = true
			end
		end)

		return
	end

	if arg1.inFirstPerson then
		arg1:GamepadZoomPress()
	end

	if arg1.thirdPersonOptionChanged then
		arg1.thirdPersonOptionChanged:Disconnect()
		arg1.thirdPersonOptionChanged = nil
	end

	if arg1.vrRecentered then
		arg1.vrRecentered:Disconnect()
		arg1.vrRecentered = nil
	end

	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	if arg1.gamepadResetConnection then
		arg1.gamepadResetConnection:Disconnect()
		arg1.gamepadResetConnection = nil
	end

	if not str2 then
		arg1.VREdgeBlurTimer = 0
		arg1:UpdateEdgeBlur(var5, 1)
	end

	local var7 = var6:FindFirstChild("VRFade")
	if var7 then
		var7.Brightness = 0
	end
end

str3.OnCurrentCameraChanged = function(arg1)
	var3.OnCurrentCameraChanged(arg1)
	if arg1.cameraHeadScaleChangedConn then
		arg1.cameraHeadScaleChangedConn:Disconnect()
		arg1.cameraHeadScaleChangedConn = nil
	end

	local var2 = workspace.CurrentCamera
	if var2 then
		arg1.cameraHeadScaleChangedConn = var2:GetPropertyChangedSignal("HeadScale"):Connect(function()
			arg1:OnHeadScaleChanged()
		end)

		arg1:OnHeadScaleChanged()
	end
end

str3.OnHeadScaleChanged = function(arg1)
	local var1 = workspace.CurrentCamera.HeadScale
	for k1, v1 in arg1.gamepadZoomLevels, nil do
		arg1.gamepadZoomLevels[k1] = v1 * var1 / arg1.headScale
	end

	arg1:SetCameraToSubjectDistance(arg1:GetCameraToSubjectDistance() * var1 / arg1.headScale)
	arg1.headScale = var1
end

str3.GetVRFocus = function(arg1, arg2, arg3)
	local var1 = Vector3.new(arg1.cameraTranslationConstraints.x, math.min(1, arg1.cameraTranslationConstraints.y + arg3), arg1.cameraTranslationConstraints.z)
	arg1.cameraTranslationConstraints = var1
	local var2 = arg2 + Vector3.new(0, arg1:GetCameraHeight(), 0)
	local var3 = arg1.cameraTranslationConstraints.y
	return (CFrame.new(Vector3.new(arg2.x, (arg1.lastCameraFocus or arg2).y, arg2.z):Lerp(var2, var3)))
end

str3.StartFadeFromBlack = function(arg1)
	if var8.VignetteEnabled == false then
		return
	end

	local var2 = var6:FindFirstChild("VRFade")
	if not var2 then
		var2 = Instance.new("ColorCorrectionEffect")
		var2.Name = "VRFade"
		var2.Parent = var6
	end

	var2.Brightness = -1
	arg1.VRFadeResetTimer = 0.1
end

str3.UpdateFadeFromBlack = function(arg1, arg2)
	local var1 = var6:FindFirstChild("VRFade")
	if 0 < arg1.VRFadeResetTimer then
		local var2 = math.max(arg1.VRFadeResetTimer - arg2, 0)
		arg1.VRFadeResetTimer = var2
		var2 = var6:FindFirstChild("VRFade")
		if not (var2 and var2.Brightness < 0) then
			return
		end

		if var2.Brightness >= 0 then
			return
		end

		local var3 = math.min(var2.Brightness + arg2 * 10, 0)
		var2.Brightness = var3
		return
	end

	if var1 then
		var1.Brightness = 0
	end
end

str3.StartVREdgeBlur = function(arg1, arg2, arg3)
	if not arg3 and var8.VignetteEnabled == false then
		return
	end

	local var1 = nil
	var1 = workspace.CurrentCamera:FindFirstChild("VRBlurPart")
	if not var1 then
		var1 = Instance.new("Part")
		var1.Name = "VRBlurPart"
		var1.Parent = workspace.CurrentCamera
		var1.CanTouch = false
		var1.CanCollide = false
		var1.CanQuery = false
		var1.Anchored = true
		var1.Size = Vector3.new(0.44, 0.47, 1)
		var1.Transparency = 1
		var1.CastShadow = false
		var7.RenderStepped:Connect(function(_)
			local var2 = var4:GetUserCFrame(Enum.UserCFrame.Head)
			local var3 = workspace.CurrentCamera.CFrame * (CFrame.new(var2.p * workspace.CurrentCamera.HeadScale) * (var2 - var2.p))
			var1.CFrame = var3 * CFrame.Angles(0, 3.1415926535897931, 0) + var3.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
			var1.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
		end)

	end

	local var2 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var3 = nil
	var3 = var2 and var2:FindFirstChild("VRBlur")
	if not var3 then
		var2 = var2 or Instance.new("ScreenGui")
		var2.Name = "VRBlurScreen"
		var2.Parent = arg2.PlayerGui
		var2.Adornee = var1
		var3 = Instance.new("ImageLabel")
		var3.Name = "VRBlur"
		var3.Parent = var2
		var3.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
		var3.AnchorPoint = Vector2.new(0.5, 0.5)
		var3.Position = UDim2.new(0.5, 0, 0.5, 0)
		var3.Size = UDim2.fromScale(workspace.CurrentCamera.ViewportSize.X * 2.3 / 512, workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512)
		var3.BackgroundTransparency = 1
		var3.Active = true
		var3.ScaleType = Enum.ScaleType.Stretch
	end

	var3.Visible = true
	var3.ImageTransparency = 0
	arg1.VREdgeBlurTimer = 0.14
end

str3.UpdateEdgeBlur = function(arg1, arg2, arg3)
	local var3 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
	local var4 = nil
	if var3 then
		var4 = var3:FindFirstChild("VRBlur")
	end

	if var4 then
		if 0 < arg1.VREdgeBlurTimer then
			local var5 = arg1.VREdgeBlurTimer - arg3
			arg1.VREdgeBlurTimer = var5
			var5 = arg2.PlayerGui:FindFirstChild("VRBlurScreen")
			local var6 = var5:FindFirstChild("VRBlur")
			if not (var5 and var6) then
				return
			end

			var6 = var5:FindFirstChild("VRBlur")
			if not var6 then
				return
			end

			var6.ImageTransparency = 1 - math.clamp(arg1.VREdgeBlurTimer, 0.01, 0.14) * 7.1428571428571423
			return
		end

		var4.Visible = false
	end
end

str3.GetCameraHeight = function(arg1)
	if not arg1.inFirstPerson then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

str3.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectCFrame(arg1)
	if not var2 then
		return var4
	end

	if var2:IsA("Humanoid") then
		if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
			var4 = arg1.lastSubjectCFrame
		end
	end

	if var4 then
		arg1.lastSubjectCFrame = var4
	end

	return var4
end

str3.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var4 = var3.GetSubjectPosition(arg1)
	if var2 then
		if var2:IsA("Humanoid") then
			if var2:GetState() == Enum.HumanoidStateType.Dead and var2 == arg1.lastSubject then
				var4 = arg1.lastSubjectPosition
			end
		else
			if var2:IsA("VehicleSeat") then
				var4 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
			end
		end
	else
		return nil
	end

	arg1.lastSubjectPosition = var4
	return var4
end

str3.getRotation = function(arg1, arg2)
	local var3 = var2.getRotation(arg2)
	local num2 = 0
	if var8.VRSmoothRotationEnabled then
		return var3.X
	end

	if 0.03 < math.abs(var3.X) then
		if 0 < arg1.stepRotateTimeout then
			local var4 = arg1.stepRotateTimeout - arg2
			arg1.stepRotateTimeout = var4
		end

		if arg1.stepRotateTimeout <= 0 then
			num2 = 1
			if var3.X < 0 then
				num2 = -1
			end

			arg1:StartFadeFromBlack()
			arg1.stepRotateTimeout = 0.25
			num2 = num2 * 0.52359877559829882
			return num2
		end
	end

	if math.abs(var3.X) < 0.02 then
		arg1.stepRotateTimeout = 0
	end

	return num2
end

str3.HandleSubjectDistance = function(arg1, arg2)
	if arg2 and (arg2.IsInFirstPerson and arg2:IsInFirstPerson()) then
		arg1:SetCameraToSubjectDistance(0)
	end
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.LegacyCamera [ModuleScript]
-- y u r i

Vector2.new()
local str1 = "CameraUtils"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str2))
local str3 = "BaseCamera"
str1 = require(script.Parent:WaitForChild(str3))
local var2 = game:GetService("Players")
str2 = setmetatable({}, str1)
str2.__index = str2
str2.new = function()
	local var1 = setmetatable(str1.new(), str2)
	var1.cameraType = Enum.CameraType.Fixed
	var1.lastUpdate = tick()
	var1.lastDistanceToSubject = nil
	return var1
end

str2.GetModuleName = function(_)
	return "LegacyCamera"
end

str2.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return str1.SetCameraToSubjectDistance(var1, var2)
end

str2.Update = function(arg1, arg2)
	if not arg1.cameraType then
		return nil, nil
	end

	local var3 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4.CFrame
	local var6 = var4.Focus
	local var7 = var2.LocalPlayer
	local var8 = var1.getRotation(arg2)
	if arg1.lastUpdate == nil or 1 < var3 - arg1.lastUpdate then
		arg1.lastDistanceToSubject = nil
	end

	local var10 = arg1:GetSubjectPosition()
	if arg1.cameraType == Enum.CameraType.Fixed then
		if var10 and (var7 and var4) then
			var5 = CFrame.new(var4.CFrame.p, var4.CFrame.p + arg1:GetCameraToSubjectDistance() * arg1:CalculateNewLookVectorFromArg(nil, var8))
			var6 = var4.Focus
		end
	else
		if arg1.cameraType == Enum.CameraType.Attach then
			local var12 = arg1:GetSubjectCFrame()
			local var13, var14 = var12:ToEulerAnglesYXZ()
			var6 = CFrame.new(var12.p) * CFrame.fromEulerAnglesYXZ(math.clamp(var4.CFrame:ToEulerAnglesYXZ() - var8.Y, -1.3962634015954636, 1.3962634015954636), var14, 0)
			var5 = var6 * CFrame.new(0, 0, arg1:StepZoom())
		else
			if arg1.cameraType == Enum.CameraType.Watch then
				if var10 then
					if var7 then
						if var4 then
							local var15 = nil
							if var10 == var4.CFrame.p then
								warn("Camera cannot watch subject in same position as itself")
								return var4.CFrame, var4.Focus
							end

							local var18 = arg1:GetHumanoid()
							if var18 then
								if var18.RootPart then
									local var20 = var10 - var4.CFrame.p
									var15 = var20.unit
									if arg1.lastDistanceToSubject and arg1.lastDistanceToSubject == arg1:GetCameraToSubjectDistance() then
										arg1:SetCameraToSubjectDistance(var20.magnitude)
									end
								end
							end

							local var21 = arg1:GetCameraToSubjectDistance()
							var6 = CFrame.new(var10)
							var5 = CFrame.new(var10 - var21 * arg1:CalculateNewLookVectorFromArg(var15, var8), var10)
							arg1.lastDistanceToSubject = var21
						end
					end
				end
			else
				return var4.CFrame, var4.Focus
			end
		end
	end

	arg1.lastUpdate = var3
	return var5, var6
end

return str2

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.TransparencyController [ModuleScript]
-- y u r i

local str1 = "CameraUtils"
local var1 = game:GetService("VRService")
local var2 = require(script.Parent:WaitForChild(str1))
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.transparencyDirty = false
	var1.enabled = false
	var1.lastTransparency = nil
	var1.descendantAddedConn = nil
	var1.descendantRemovingConn = nil
	var1.toolDescendantAddedConns = {}
	var1.toolDescendantRemovingConns = {}
	var1.cachedParts = {}
	return var1
end

tbl1.HasToolAncestor = function(arg1, arg2)
	if arg2.Parent == nil then
		return false
	end

	assert(arg2.Parent, "")
	local var1 = arg2.Parent:IsA("Tool")
	return var1 or arg1:HasToolAncestor(arg2.Parent)
end

local tbl2 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion",
}

tbl1.IsValidPartToModify = function(arg1, arg2)
	for k1, v1 in tbl2, nil do
		if not arg2:IsA(v1) then
			continue
		end

		return not arg1:HasToolAncestor(arg2)
	end

	return false
end

tbl1.CachePartsRecursive = function(arg1, arg2)
	if arg2 then
		if arg1:IsValidPartToModify(arg2) then
			arg1.cachedParts[arg2] = true
			arg1.transparencyDirty = true
		end

		for k1, v1 in pairs(arg2:GetChildren()) do
			arg1:CachePartsRecursive(v1)
		end
	end
end

tbl1.TeardownTransparency = function(arg1)
	for k1, v1 in pairs(arg1.cachedParts) do
		k1.LocalTransparencyModifier = 0
	end

	arg1.cachedParts = {}
	arg1.transparencyDirty = true
	arg1.lastTransparency = nil
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
		arg1.descendantAddedConn = nil
	end

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
		arg1.descendantRemovingConn = nil
	end

	for k2, v2 in pairs(arg1.toolDescendantAddedConns) do
		v2:Disconnect()
		arg1.toolDescendantAddedConns[k2] = nil
	end

	for k3, v3 in pairs(arg1.toolDescendantRemovingConns) do
		v3:Disconnect()
		arg1.toolDescendantRemovingConns[k3] = nil
	end
end

tbl1.SetupTransparency = function(arg1, arg2)
	arg1:TeardownTransparency()
	if arg1.descendantAddedConn then
		arg1.descendantAddedConn:disconnect()
	end

	arg1.descendantAddedConn = arg2.DescendantAdded:Connect(function(arg1)
		if arg1:IsValidPartToModify(arg1) then
			arg1.cachedParts[arg1] = true
			arg1.transparencyDirty = true
			return
		end

		if arg1:IsA("Tool") then
			if arg1.toolDescendantAddedConns[arg1] then
				arg1.toolDescendantAddedConns[arg1]:Disconnect()
			end

			arg1.toolDescendantAddedConns[arg1] = arg1.DescendantAdded:Connect(function(arg1)
				arg1.cachedParts[arg1] = nil
				if arg1:IsA("BasePart") or arg1:IsA("Decal") then
					arg1.LocalTransparencyModifier = 0
				end
			end)

			if arg1.toolDescendantRemovingConns[arg1] then
				arg1.toolDescendantRemovingConns[arg1]:disconnect()
			end

			arg1.toolDescendantRemovingConns[arg1] = arg1.DescendantRemoving:Connect(function(arg1)
				wait()
				if arg2 and (arg1 and (arg1:IsDescendantOf(arg2) and arg1:IsValidPartToModify(arg1))) then
					arg1.cachedParts[arg1] = true
					arg1.transparencyDirty = true
				end
			end)

		end
	end)

	if arg1.descendantRemovingConn then
		arg1.descendantRemovingConn:disconnect()
	end

	arg1.descendantRemovingConn = arg2.DescendantRemoving:connect(function(arg1)
		if arg1.cachedParts[arg1] then
			arg1.cachedParts[arg1] = nil
			arg1.LocalTransparencyModifier = 0
		end
	end)

	arg1:CachePartsRecursive(arg2)
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
	end
end

tbl1.SetSubject = function(arg1, arg2)
	local var1 = nil
	var1 = arg2 and (arg2:IsA("Humanoid") and arg2.Parent)
	if arg2 then
		if arg2:IsA("VehicleSeat") and arg2.Occupant then
			var1 = arg2.Occupant.Parent
		end
	end

	if var1 then
		arg1:SetupTransparency(var1)
		return
	end

	arg1:TeardownTransparency()
end

tbl1.Update = function(arg1, arg2)
	local var6 = workspace.CurrentCamera
	if var6 then
		if arg1.enabled then
			local var9 = (var6.Focus.p - var6.CoordinateFrame.p).magnitude
			local var11 = var9 < 2 and 1 - (var9 - 0.5) / 1.5 or 0
			if var11 < 0.5 then
				var11 = 0
			end

			if arg1.lastTransparency and (var11 < 1 and arg1.lastTransparency < 0.95) then
				local var13 = 2.8 * arg2
				var11 = arg1.lastTransparency + math.clamp(var11 - arg1.lastTransparency, -var13, var13)
			else
				arg1.transparencyDirty = true
			end

			local num3 = 1
			var11 = math.clamp(var2.Round(var11, 2), 0, num3)
			if arg1.transparencyDirty or arg1.lastTransparency ~= var11 then
				for k1, v1 in pairs(arg1.cachedParts) do
					if var1.VREnabled and var1.AvatarGestures then
						if k1.Parent:IsA("Accessory") and ({
							[Enum.AccessoryType.Hat] = true,
							[Enum.AccessoryType.Hair] = true,
							[Enum.AccessoryType.Face] = true,
							[Enum.AccessoryType.Eyebrow] = true,
							[Enum.AccessoryType.Eyelash] = true,
						})[k1.Parent.AccessoryType] or k1.Name == "Head" then

							k1.LocalTransparencyModifier = var11
						else
							k1.LocalTransparencyModifier = 0
							continue
						end
					else
						k1.LocalTransparencyModifier = var11
					end
				end

				arg1.transparencyDirty = false
				arg1.lastTransparency = var11
			end
		end
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController [ModuleScript]
-- y u r i

local str1 = "Popper"
local var1 = require(script:WaitForChild(str1))
local var2 = game:GetService("Players").LocalPlayer
assert(var2)
local var3 = nil
local var4 = nil
local function updateBounds()
	var3 = var2.CameraMinZoomDistance
	var4 = var2.CameraMaxZoomDistance
end

var2:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(updateBounds)
var2:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(updateBounds)
var3 = var2.CameraMinZoomDistance
var4 = var2.CameraMaxZoomDistance
var2 = {}
var2.__index = var2
local var5 = math.clamp
var2.new = function(arg1, arg2, arg3, arg4)
	arg2 = var5(arg2, arg3, arg4)
	return (setmetatable({ freq = arg1, x = arg2, v = 0, minValue = arg3, maxValue = arg4, goal = arg2 }, var2))
end

local var6 = math.exp
var2.Step = function(arg1, arg2)
	local var1 = arg1.goal
	local var2 = arg1.freq * 2 * 3.1415926535897931
	local var3 = var2 * arg2
	local var4 = arg1.v
	local var5 = var1 - arg1.x
	local var7 = var6(-var3)
	local var11 = var1 + (var4 * arg2 - var5 * (var3 + 1)) * var7
	local var12 = arg1.minValue
	local var13 = arg1.maxValue
	local var14 = ((var5 * var2 - var4) * var3 + var4) * var7
	if var11 < var12 then
		var11 = var12
		var14 = 0
	elseif var13 < var11 then
		var11 = var13
		var14 = 0
	end

	arg1.x = var11
	arg1.v = var14
	return var11
end

updateBounds = var2.new(4.5, 12.5, 0.5, var4)
local num1 = 0
local var7 = math.max
str1 = math.min
return {
	Update = function(arg1, arg2, arg3)
		local num2 = math.huge
		if 1 < updateBounds.goal then
			local var8 = updateBounds.goal
			local var9 = num1
			local var10 = var3
			var8 = var5(var8 + var9 * (var8 * 0.0375 + 1), var10, var4)
			local var11 = updateBounds.x
			if var8 < 1 then
				var8 = var9 <= 0 and var10 or 1
			end

			local var12 = var7(var11, var8)
			num2 = var1(arg2 * CFrame.new(0, 0, 0.5), var12 - 0.5, arg3) + 0.5
		end

		updateBounds.minValue = 0.5
		updateBounds.maxValue = str1(var4, num2)
		local var13 = arg1
		return updateBounds:Step(var13)
	end,
	GetZoomRadius = function()
		return updateBounds.x
	end,
	SetZoomParameters = function(arg1, arg2)
		updateBounds.goal = arg1
		num1 = arg2
	end,
	ReleaseSpring = function()
		updateBounds.x = updateBounds.goal
		updateBounds.v = 0
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper [ModuleScript]
-- y u r i

local var1 = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "FlagUtil"
local str2 = "CameraWrapper"
local str3 = "ConnectionUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
local var4 = require(var1:WaitForChild(str3))
str2 = var2.getUserFlag("UserCurrentCameraUpdate2")
local var5 = game:GetService("Players")
str1 = var2.getUserFlag("UserRaycastUpdateAPI2")
str3 = var2.getUserFlag("UserPlayerConnectionMemoryLeak")
local var6 = if str2 then var3.new() else nil
local var7 = if str2 then nil else game.Workspace.CurrentCamera
if str2 then
	var6:Enable()
end

local var8 = RaycastParams.new()
var8.IgnoreWater = true
var8.FilterType = Enum.RaycastFilterType.Exclude
var8.RespectCanCollide = true
local var9 = RaycastParams.new()
var9.IgnoreWater = true
var9.FilterType = Enum.RaycastFilterType.Include
local var10 = math.min
local var11 = math.tan
local var12 = math.rad
local var13 = Ray.new
local var16 = if str3 then var4.new() else nil
local var17 = nil
local var18 = nil
local var19 = nil
if str2 then
	local function updateProjection()
		local var1 = var6:getCamera()
		local var2 = var1.ViewportSize
		var19 = var11(var12(var1.FieldOfView) / 2) * 2
		var18 = var2.X / var2.Y * var19
	end

	var6:Connect("FieldOfView", updateProjection)
	var6:Connect("ViewportSize", updateProjection)
	local var20 = var6:getCamera()
	local var21 = var20.ViewportSize
	var19 = var11(var12(var20.FieldOfView) / 2) * 2
	var18 = var21.X / var21.Y * var19
	var17 = var6:getCamera().NearPlaneZ
	var6:Connect("NearPlaneZ", function()
		var17 = var6:getCamera().NearPlaneZ
	end)

else
	updateProjection = function()
		local var1 = var7.ViewportSize
		var19 = var11(var12(var7.FieldOfView) / 2) * 2
		var18 = var1.X / var1.Y * var19
	end

	var7:GetPropertyChangedSignal("FieldOfView"):Connect(updateProjection)
	var7:GetPropertyChangedSignal("ViewportSize"):Connect(updateProjection)
	local var22 = var7.ViewportSize
	var19 = var11(var12(var7.FieldOfView) / 2) * 2
	var17 = var7.NearPlaneZ
	var7:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		var17 = var7.NearPlaneZ
	end)

	var18 = var22.X / var22.Y * var19
end

updateProjection = {}
local tbl1 = {}
local function playerAdded(arg1)
	local function characterAdded(arg1)
		tbl1[arg1] = arg1
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	local function characterRemoving()
		tbl1[arg1] = nil
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end

	if str3 then
		local var2 = characterAdded
		var16:trackConnection(("%*CharacterAdded"):format(arg1.UserId), arg1.CharacterAdded:Connect(var2))
		var2 = characterRemoving
		var16:trackConnection(("%*CharacterRemoving"):format(arg1.UserId), arg1.CharacterRemoving:Connect(var2))
	else
		arg1.CharacterAdded:Connect(characterAdded)
		arg1.CharacterRemoving:Connect(characterRemoving)
	end

	if arg1.Character then
		tbl1[arg1] = arg1.Character
		updateProjection = {}
		local num1 = 1
		for k1, v1 in pairs(tbl1) do
			updateProjection[num1] = v1
			num1 = num1 + 1
		end
	end
end

var5.PlayerAdded:Connect(playerAdded)
var5.PlayerRemoving:Connect(function(arg1)
	tbl1[arg1] = nil
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end

	if str3 then
		var16:disconnect((("%*CharacterAdded"):format(arg1.UserId)))
		var16:disconnect((("%*CharacterRemoving"):format(arg1.UserId)))
	end
end)

local function refreshIgnoreList()
	updateProjection = {}
	local num1 = 1
	for k1, v1 in pairs(tbl1) do
		updateProjection[num1] = v1
		num1 = num1 + 1
	end
end

for k1, v1 in ipairs(var5:GetPlayers()) do
	playerAdded(v1)
end

updateProjection = {}
local num1 = 1
for k2, v2 in pairs(tbl1) do
	updateProjection[num1] = v2
	num1 = num1 + 1
end

tbl1 = nil
refreshIgnoreList = nil
if str2 then
	var6:Connect("CameraSubject", function()
		local var2 = var6:getCamera().CameraSubject
		if var2 and var2:IsA("Humanoid") then
			refreshIgnoreList = var2.RootPart
			return
		end

		if var2 and var2:IsA("BasePart") then
			refreshIgnoreList = var2
			return
		end

		refreshIgnoreList = nil
	end)

else
	var7:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		local var1 = var7.CameraSubject
		if var1:IsA("Humanoid") then
			refreshIgnoreList = var1.RootPart
			return
		end

		if var1:IsA("BasePart") then
			refreshIgnoreList = var1
			return
		end

		refreshIgnoreList = nil
	end)

end

local num2 = 0
local num3 = 0.2
local function queryPoint(arg1, arg2, arg3, arg4)
	debug.profilebegin("queryPoint")
	arg3 = arg3 + var17
	local var1 = arg1 + arg2 * arg3
	local num1 = math.huge
	local num2 = math.huge
	local var2 = arg1
	local num3 = 0
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var3 = #updateProjection
		while true do
			local var7 = workspace:Raycast(var2, var1 - var2, var8)
			if var7 then
				local var10 = var7.Position
				num3 = num3 + 1
				local var12 = var7.Instance
				local var14 = (var10 - arg1).Magnitude
				if 64 <= num3 then
					num2 = var14
				else
					local bool2 = false
					if 1 - (1 - var12.Transparency) * (1 - var12.LocalTransparencyModifier) < 0.25 then
						if not str1 then
							bool2 = var12.CanCollide
							if bool2 then
								bool2 = false
								if tbl1 ~= (var12:GetRootPart() or var12) then
									bool2 = not var12:IsA("TrussPart")
								end
							end
						end
					end

					if bool2 then
						var9.FilterDescendantsInstances = { var12 }
						if workspace:Raycast(var1, var10 - var1, var9) then
							local var15
							if arg4 then
								var15 = workspace:Raycast(arg4, var1 - arg4, var9)
								if not var15 then
									var15 = workspace:Raycast(var1, arg4 - var1, var9)
								end
							else
								var15 = false
							end

							if var15 then
								num2 = var14
							elseif arg3 < num1 then
								num1 = var14
							end
						else
							num2 = var14
						end
					end
				end

				var8:AddToFilter(var12)
				var2 = var10 - arg2 * 0.001
				if num2 >= math.huge and var12 then
					continue
				end
			end
		end
	else
		repeat
			local var19, var20 = workspace:FindPartOnRayWithIgnoreList(var13(var2, var1 - var2), updateProjection, false, true)
			num3 = num3 + 1
			if var19 then
				local var21 = 64 <= num3
				local bool4 = false
				if 1 - (1 - var19.Transparency) * (1 - var19.LocalTransparencyModifier) < 0.25 then
					if not str1 then
						bool4 = var19.CanCollide
						if bool4 then
							bool4 = false
							if tbl1 ~= (var19:GetRootPart() or var19) then
								bool4 = not var19:IsA("TrussPart")
							end
						end
					end
				end

				if bool4 or var21 then
					bool4 = { var19 }
					var15 = (var20 - arg1).Magnitude
					if workspace:FindPartOnRayWithWhitelist(var13(var1, var20 - var1), bool4, true) then
						if not var21 then
							local bool5 = false
							if arg4 and workspace:FindPartOnRayWithWhitelist(var13(var1, arg4 - var1), bool4, true) then
								num2 = var15
							elseif arg3 < num1 then
								num1 = var15
							end
						else
							num2 = var15
						end
					else
						num2 = var15
					end
				end

				updateProjection[#updateProjection + 1] = var19
			end

			local var22 = var20 - arg2 * 0.001
		until num2 < math.huge or (not var19)

		local var23 = updateProjection
		for i1 = #var23, var3 + 1, -1 do
			var23[i1] = nil
		end
	end

	debug.profileend()
	return num1 - var17, num2 - var17
end

num1 = function(arg1, arg2)
	if str1 then
		var8.FilterDescendantsInstances = updateProjection
		local var2 = workspace:Raycast(arg1, arg2, var8)
		if var2 then
			return var2.Position, true
		end
	else
		local var3 = #updateProjection
		repeat
			local var7, var9 = workspace:FindPartOnRayWithIgnoreList(var13(arg1, arg2), updateProjection, false, true)
			if var7 then
				if var7.CanCollide then
					local var11 = updateProjection
					for i1 = #var11, var3 + 1, -1 do
						var11[i1] = nil
					end

					return var9, true
				end

				updateProjection[#updateProjection + 1] = var7
			end
		until not var7

		local var12 = updateProjection
		for i2 = #var12, var3 + 1, -1 do
			var12[i2] = nil
		end
	end

	return arg1 + arg2, false
end

local tbl2 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(num2, num3),
}

local function queryViewport(arg1, arg2)
	debug.profilebegin("queryViewport")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	local var5 = if str2 then var6:getCamera() else var7
	var7 = var5
	var5 = var7.ViewportSize
	local num1 = math.huge
	local num2 = math.huge
	for i1 = 0, 1 do
		for i2 = 0, 1 do
			local var8 = var2 * ((i1 - 0.5) * var18)
			local var11, var12 = queryPoint(var1 + var17 * (var8 + var3 * ((i2 - 0.5) * var19)), var4, arg2, var7:ViewportPointToRay(var5.x * i1, var5.y * i2).Origin)
			if var12 < num1 then
				num1 = var12
			end

			if var11 >= num2 then
				continue
			end

			num2 = var11
		end
	end

	debug.profileend()
	return num2, num1
end

local function testPromotion(arg1, arg2, arg3)
	debug.profilebegin("testPromotion")
	debug.profilebegin("extrapolate")
	local var1 = arg1.p
	local var2 = arg1.rightVector
	local var3 = arg1.upVector
	local var4 = -arg1.lookVector
	for i1 = 0, var10(1.25, arg3.rotVelocity.magnitude + (num1(var1, arg3.posVelocity * 1.25) - var1).Magnitude / arg3.posVelocity.magnitude), 0.0625 do
		local var5 = arg3.extrapolate(i1)
		if arg2 > queryPoint(var5.p, -var5.lookVector, arg2) then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profilebegin("testOffsets")
	for k1, v1 in ipairs(tbl2) do
		local var6 = num1(var1, var2 * v1.x + var3 * v1.y)
		if queryPoint(var6, (var1 + var4 * arg2 - var6).Unit, arg2) ~= math.huge then
			continue
		end

		return false
	end

	debug.profileend()
	debug.profileend()
	return true
end

return function(arg1, arg2, arg3)
	debug.profilebegin("popper")
	local var1 = refreshIgnoreList and refreshIgnoreList:GetRootPart() or refreshIgnoreList
	tbl1 = var1
	local var4, var5 = queryViewport(arg1, arg2)
	var1 = arg2
	if var5 < var1 then
		var1 = var5
	end

	if var4 < var1 and testPromotion(arg1, arg2, arg3) then
		var1 = var4
	end

	tbl1 = nil
	debug.profileend()
	return var1
end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.MouseLockController [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local str2 = "CameraUtils"
local var2 = game:GetService("Players")
str1 = game:GetService("ContextActionService")
local var3 = game:GetService("UserInputService")
local var4 = UserSettings().GameSettings
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = var1.getUserFlag("UserFixStuckShiftLock")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.isMouseLocked = false
	var1.savedMouseCursor = nil
	var1.boundKeys = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift }
	var1.mouseLockToggledEvent = Instance.new("BindableEvent")
	local var6 = script:FindFirstChild("BoundKeys")
	if var6 then
		if not var6:IsA("StringValue") then
			if var6 then
				var6:Destroy()
			end

			var6 = Instance.new("StringValue")
			assert(var6, "")
			var6.Name = "BoundKeys"
			var6.Value = "LeftShift,RightShift"
			var6.Parent = script
		end
	end

	if var6 then
		var6.Changed:Connect(function(arg1)
			var1:OnBoundKeysObjectChanged(arg1)
		end)

		var1:OnBoundKeysObjectChanged(var6.Value)
	end

	var4.Changed:Connect(function(arg1)
		if arg1 == "ControlMode" or arg1 == "ComputerMovementMode" then
			var1:UpdateMouseLockAvailability()
		end
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var3:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMouseLockAvailability()
	end)

	var1:UpdateMouseLockAvailability()
	return var1
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.isMouseLocked
end

tbl1.GetBindableToggleEvent = function(arg1)
	return arg1.mouseLockToggledEvent.Event
end

tbl1.GetMouseLockOffset = function(_)
	return Vector3.new(1.75, 0, 0)
end

tbl1.UpdateMouseLockAvailability = function(arg1)
	local var1 = var3.PreferredInput == Enum.PreferredInput.KeyboardAndMouse
	var1 = var1 and (var2.LocalPlayer.DevEnableMouseLock and (var4.ControlMode == Enum.ControlMode.MouseLockSwitch and (not (var4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove) and (not (var2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable)))))
	if var1 ~= arg1.enabled then
		arg1:EnableMouseLock(var1)
	end
end

tbl1.OnBoundKeysObjectChanged = function(arg1, arg2)
	arg1.boundKeys = {}
	for k1 in string.gmatch(arg2, "[^%s,]+") do
		for k2, v1 in pairs(Enum.KeyCode:GetEnumItems()) do
			if k1 ~= v1.Name then
				continue
			end

			arg1.boundKeys[#arg1.boundKeys + 1] = v1
			break
		end
	end

	arg1:UnbindContextActions()
	arg1:BindContextActions()
end

tbl1.OnMouseLockToggled = function(arg1)
	local var1 = not arg1.isMouseLocked
	arg1.isMouseLocked = var1
	if arg1.isMouseLocked then
		var1 = script:FindFirstChild("CursorImage")
		if var1 and (var1:IsA("StringValue") and var1.Value) then
			var5.setMouseIconOverride(var1.Value)
		elseif var1 then
			var1:Destroy()
		end
	else
		var5.restoreMouseIcon()
	end

	arg1.mouseLockToggledEvent:Fire()
end

tbl1.DoMouseLockSwitch = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1:OnMouseLockToggled()
		return Enum.ContextActionResult.Sink
	end

	return Enum.ContextActionResult.Pass
end

local var7 = Enum.ContextActionPriority.Medium.Value
tbl1.BindContextActions = function(arg1)
	local var1 = arg1.boundKeys
	str1:BindActionAtPriority("MouseLockSwitchAction", function(arg1, arg2, arg3)
		local var1 = arg1
		local var2 = arg2
		local var3 = arg3
		return arg1:DoMouseLockSwitch(var1, var2, var3)
	end, false, var7, unpack(var1))
end

tbl1.UnbindContextActions = function(_)
	str1:UnbindAction("MouseLockSwitchAction")
end

tbl1.IsMouseLocked = function(arg1)
	local var1 = arg1.enabled
	return var1 and arg1.isMouseLocked
end

tbl1.EnableMouseLock = function(arg1, arg2)
	if arg2 ~= arg1.enabled then
		arg1.enabled = arg2
		if arg1.enabled then
			arg1:BindContextActions()
			return
		end

		var5.restoreMouseIcon()
		arg1:UnbindContextActions()
		if var6 then
			if not arg1.isMouseLocked then
				return
			end

			arg1.isMouseLocked = false
			arg1.mouseLockToggledEvent:Fire()
			return
		end

		if arg1.isMouseLocked then
			arg1.mouseLockToggledEvent:Fire()
		end

		arg1.isMouseLocked = false
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec [ModuleScript]
-- y u r i

local var1 = require(game:GetService("CorePackages").Packages.Dev.JestGlobals)
local var2 = require(script.Parent.VRCameraTeleportDetector)
local var3 = var1.it
local var4 = var1.expect
local var5 = var2.shouldRecenter
local var6 = var2.JUMP_STUDS
local var7 = var2.SETTLED_STUDS
local var8 = var2.DEBOUNCE_SECONDS
var1.describe("VRCameraTeleportDetector.shouldRecenter", function()
	var3("fires on a discrete jump from rest (no prior step, never recentered)", function()
		local var1 = nil
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("fires on a discrete jump preceded by a near-still frame", function()
		local var1 = var7 - 0.5
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(true)
	end)

	var3("does not fire for sub-threshold motion", function()
		local num1 = 0
		local var1 = var6 - 0.1
		local var2 = nil
		local num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
		num1 = 0
		var1 = 0
		var2 = nil
		num2 = 100
		var4(var5(num1, var1, var2, num2)).toBe(false)
	end)

	var3("does not fire when the previous frame was already moving (continuous motion)", function()
		local var1 = var7 + 0.1
		local var2 = var6 + 10
		local var3 = nil
		local num1 = 100
		var4(var5(var1, var2, var3, num1)).toBe(false)
	end)

	var3("does not fire within the debounce interval", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 - 0.01
		var4(var5(var1, var2, num1, var3)).toBe(false)
	end)

	var3("fires again once the debounce interval has elapsed", function()
		local var1 = nil
		local var2 = var6 + 10
		local num1 = 100
		local var3 = 100 + var8 + 0.01
		var4(var5(var1, var2, num1, var3)).toBe(true)
	end)

	var3("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function()
		local num1 = 0
		local var1 = nil
		local var2 = nil
		local num2 = 0
		for i1 = 1, 120 do
			local var3 = var6 + 10
			if var5(var1, var3, var2, num1) then
				num2 = num2 + 1
			end

			local var7 = num1
			num1 = num1 + 0.016666666666666666
			local var8 = var3
		end

		var4(num2).toBe(1)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera [ModuleScript]
-- y u r i

local str1 = "VRBaseCamera"
local str2 = "CameraUtils"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
local var3 = require(script.Parent:WaitForChild(str2))
local str4 = "VehicleCameraConfig"
str2 = game:GetService("RunService")
str3 = game:GetService("VRService")
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local var6 = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild(str4))
local var7 = RaycastParams.new()
var7.FilterType = Enum.RaycastFilterType.Exclude
var7.IgnoreWater = true
local var8 = OverlapParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local var9 = setmetatable({}, var1)
var9.__index = var9
local num1 = 0.016666666666666666
var9.new = function()
	local var2 = setmetatable(var1.new(), var9)
	var2.skipOcclusion = true
	var2:Reset()
	if var2.thirdPersonOptionChanged then
		var2.thirdPersonOptionChanged:Disconnect()
		var2.thirdPersonOptionChanged = nil
	end

	str2.Stepped:Connect(function(_, arg2)
		num1 = arg2
	end)

	return var2
end

local tbl1 = { 0, 30 }
var9.Reset = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1, "VRVehicleCamera initialization error")
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	arg1.lastOrbitalDir = nil
	arg1.wasInFirstPerson = nil
	local var4 = var2:GetConnectedParts(true)
	table.insert(var4, var2)
	str1 = var2:FindFirstAncestorOfClass("Model")
	local var5, var6 = var3.getLooseBoundingSphere(var4)
	arg1.vehicleModel = str1 or var2.Parent
	arg1.assemblyRadius = math.max(var6, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var5
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.headScale * arg1.assemblyRadius / 10)
	end

	arg1.lastCameraFocus = nil
	if not arg1:IsInFirstPerson() then
		arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
	end

	arg1.needsReset = false
end

var9._getThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * var6.verticalCenterOffset, 0)
end

var9._getFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = var5.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_getThirdPersonLocalOffset()
end

local function findObstructions(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return 0, {}
	end

	local var3 = str3:GetUserCFrame(Enum.UserCFrame.Head)
	local var4 = arg1 * (CFrame.new(var3.Position * var2.HeadScale) * var3.Rotation)
	local var6 = arg2.Position
	local var9 = var4.Position - var6
	local var11 = var9.Magnitude
	if var11 < 0.5 then
		return 0, {}
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var12 = var5
	var12 = var12 and var5.Character
	if var12 then
		table.insert(tbl1, var12)
	end

	var7.FilterDescendantsInstances = tbl1
	local var15 = workspace:Raycast(var6, var9, var7)
	local var16 = (var15.Position - var6).Magnitude
	if var15 and var16 < var11 then
		local var17 = var15.Position
		local var18 = var4.Position
		local var19 = math.max(math.clamp((1 - -var9.Unit:Dot(var4.LookVector)) / 0.13397459621556129, 0, 1), 1 - var16 / arg3, 0.15)
		local var20 = Vector3.new(2, 2, (var18 - var17).Magnitude)
		local var21 = CFrame.lookAt((var17 + var18) / 2, var18)
		var8.FilterDescendantsInstances = tbl1
		return var19, (workspace:GetPartBoundsInBox(var21, var20, var8))
	end

	return 0, {}
end

var9._vrOccludeVignette = function(arg1, arg2, arg3, arg4)
	local var1 = CFrame.new(arg2.Position + arg3 * arg4) * CFrame.Angles(0, math.atan2(arg3.X, arg3.Z), 0)
	local var3 = var4:FindFirstChild("VRFade")
	local var6, var7 = findObstructions(var1, arg2, arg4, arg1.vehicleModel)
	if not var3 then
		var3 = Instance.new("ColorCorrectionEffect")
		var3.Name = "VRFade"
		var3.Parent = var4
	end

	var3.Brightness = -var6
	local var8
	if arg1.lastOccludedParts then
		for k1, v1 in arg1.lastOccludedParts, nil do
			v1.LocalTransparencyModifier = 0
		end
	end

	if 0 < (#var7) then
		for k2, v2 in var7, nil do
			v2.LocalTransparencyModifier = 1
		end

		arg1:StartVREdgeBlur(var5, true)
	end

	arg1.lastOccludedParts = var7
	return var1
end

var9.Update = function(arg1)
	local var1 = num1
	num1 = 0
	arg1:UpdateFadeFromBlack(var1)
	arg1:UpdateEdgeBlur(var5, var1)
	local var2, var3 = arg1:_updateStepRotation(var1)
	return var2, var3
end

local var10 = var3.mapClamp
local function vrOccludeDisplace(arg1, arg2, arg3, arg4)
	local var2 = workspace.CurrentCamera
	local var3 = CFrame.new(arg1.Position + arg2 * arg3) * CFrame.Angles(0, math.atan2(arg2.X, arg2.Z), 0)
	if not var2 then
		return var3
	end

	local var4 = arg1.Position
	local var6 = (var3.Position - var4) * Vector3.new(1, 0, 1)
	local var9 = var6.Magnitude
	if var9 < 0.5 then
		return var3
	end

	local tbl1 = { var2 }
	if arg4 then
		table.insert(tbl1, arg4)
	end

	local var10 = var5
	var10 = var10 and var5.Character
	if var10 then
		table.insert(tbl1, var10)
	end

	var7.FilterDescendantsInstances = tbl1
	local var14 = workspace:Raycast(var4, var6, var7)
	local var15 = var6.Unit
	local var16 = (var14.Position - var4).Magnitude - 0.5
	if var14 and (var14.Normal:Dot(var15) < 0 and var16 < var9) then
		return CFrame.new(arg1.Position + var15 * math.max(var16, 0.5)) * var3.Rotation
	end

	return var3
end

var9._updateStepRotation = function(arg1, arg2)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var3 = arg1:GetSubjectCFrame()
	local var4 = CFrame.new(var3 * arg1:_getThirdPersonLocalOffset():Lerp(arg1:_getFirstPersonLocalOffset(var3), (var10(var1, 0.5, arg1.assemblyRadius, 1, 0))) + Vector3.new(0, arg1:GetCameraHeight(), 0))
	if arg1.needsReset or arg1.recentered then
		arg1.lastOrbitalDir = nil
		arg1.needsReset = false
		arg1.recentered = false
	end

	local var7 = arg1.lastOrbitalDir
	if not var7 then
		arg1:StartFadeFromBlack()
		var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
	end

	local var9 = 2 < (arg1:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude
	if not var9 then
		local var11 = arg1:getRotation(arg2)
		if 0 < math.abs(var11) then
			var7 = (CFrame.Angles(0, -var11, 0) * CFrame.new(var7)).Position.Unit
			arg1.lastRotateTime = os.clock()
		end
	else
		var2.getRotation(arg2)
	end

	local var12 = nil
	if arg1:IsInFirstPerson() then
		if not arg1.wasInFirstPerson or var9 then
			arg1.wasInFirstPerson = true
			var7 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
		end

		local var14 = math.atan2(-var3.LookVector.X, -var3.LookVector.Z)
		local var15 = (var14 - arg1.lastVehicleYaw + 3.1415926535897931) % 6.2831853071795862 - 3.1415926535897931
		if arg1.lastVehicleYaw and 0.001 < math.abs(var15) then
			var7 = (CFrame.Angles(0, var15, 0) * CFrame.new(var7)).Position.Unit
		end

		arg1.lastVehicleYaw = var14
		var12 = CFrame.new(var4.Position + var7 * var1) * CFrame.Angles(0, math.atan2(var7.X, var7.Z), 0)
	else
		arg1.wasInFirstPerson = false
		arg1.lastVehicleYaw = nil
		local var17 = arg1.lastRotateTime
		if var17 then
			var17 = os.clock() - arg1.lastRotateTime < var6.autocorrectDelay
		end

		if var9 and (not var17) then
			local var19 = (var3.LookVector * Vector3.new(-1, 0, -1)).Unit
			var7 = var7:Lerp(var19, (math.min(0.01 + math.acos((math.clamp(var7:Dot(var19), -1, 1))) / 3.1415926535897931 * 0.05 + math.abs((var3.YVector:Dot((arg1:GetSubjectRotVelocity())))) * 0.02, 0.15)))
		end

		var12 = vrOccludeDisplace(var4, var7, var1, arg1.vehicleModel)
	end

	arg1.lastOrbitalDir = var7
	return var12, var12 * CFrame.new(0, 0, -var1)
end

return var9

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VRCamera [ModuleScript]
-- y u r i

UserSettings():GetService("UserGameSettings")
local str1 = "CameraInput"
require(script.Parent:WaitForChild(str1))
local str2 = "CameraUtils"
require(script.Parent:WaitForChild(str2))
local str3 = "VRCameraTeleportDetector"
local var1 = require(script.Parent:WaitForChild(str3))
local str4 = "FlagUtil"
str2 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str4))
local str5 = "VRBaseCamera"
str4 = require(script.Parent:WaitForChild(str5))
local var2 = game:GetService("Players")
local var3 = game:GetService("VRService")
str3 = str2.getUserFlag("UserVRRemoveLuaEdgeBlur")
local var4 = str2.getUserFlag("UserVRRecenterOnExternalTeleport")
local var5 = setmetatable({}, str4)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str4.new(), var5)
	var1.lastUpdate = tick()
	var1.focusOffset = CFrame.new()
	var1:Reset()
	local str1 = "ControlModule"
	var1.controlModule = require(var2.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild(str1))
	var1.savedAutoRotate = true
	return var1
end

var5.Reset = function(arg1)
	arg1.needsReset = true
	arg1.needsBlackout = true
	arg1.motionDetTime = 0
	arg1.blackOutTimer = 0
	arg1.lastCameraResetPosition = nil
	str4.Reset(arg1)
end

var5.Update = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	arg1:GetHumanoid()
	local var4 = var1.CFrame
	local var5 = var1.Focus
	local var6 = var2.LocalPlayer
	if arg1.lastUpdate == nil or 1 < arg2 then
		arg1.lastCameraTransform = nil
	end

	arg1:UpdateFadeFromBlack(arg2)
	if not str3 then
		arg1:UpdateEdgeBlur(var6, arg2)
	end

	local var7 = arg1.lastSubjectPosition
	local var8 = arg1:GetSubjectPosition()
	if arg1.needsBlackout then
		arg1:StartFadeFromBlack()
		local var9 = arg1.blackOutTimer + math.clamp(arg2, 0.0001, 0.1)
		arg1.blackOutTimer = var9
		if 0.1 < arg1.blackOutTimer and game:IsLoaded() then
			arg1.needsBlackout = false
			arg1.needsReset = true
		end
	end

	if var8 then
		if var6 then
			if var1 then
				var5 = arg1:GetVRFocus(var8, arg2)
				if arg1:IsInFirstPerson() then
					if var3.AvatarGestures then
						local var20, var21 = arg1:UpdateImmersionCamera(arg2, var4, var5, var7, var8)
						var4 = var20
						var5 = var21
					else
						local var22, var23 = arg1:UpdateFirstPersonTransform(arg2, var4, var5, var7, var8)
						var4 = var22
						var5 = var23
					end
				else
					if var3.ThirdPersonFollowCamEnabled then
						local var26, var27 = arg1:UpdateThirdPersonFollowTransform(arg2, var4, var5, var7, var8)
						var4 = var26
						var5 = var27
					else
						local var28, var29 = arg1:UpdateThirdPersonComfortTransform(arg2, var4, var5, var7, var8)
						var4 = var28
						var5 = var29
					end
				end

				arg1.lastCameraTransform = var4
				arg1.lastCameraFocus = var5
			end
		end
	end

	arg1.lastUpdate = tick()
	return var4, var5
end

var5.GetAvatarFeetWorldYValue = function(_)
	local var2 = workspace.CurrentCamera.CameraSubject
	if not var2 then
		return nil
	end

	if var2:IsA("Humanoid") and var2.RootPart then
		local var4 = var2.RootPart
		return var4.Position.Y - var4.Size.Y / 2 - var2.HipHeight
	end

	return nil
end

var5.UpdateFirstPersonTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	if arg1.needsReset then
		arg1:StartFadeFromBlack()
		arg1.needsReset = false
	end

	local var1 = var2.LocalPlayer
	if not str3 and 0.01 < (arg5 - arg6).magnitude then
		arg1:StartVREdgeBlur(var1)
	end

	local var3 = arg1:GetCameraLookVector()
	local var4 = arg1:getRotation(arg2)
	local num1 = 0
	local var5 = arg1:CalculateNewLookVectorFromArg(Vector3.new(var3.X, 0, var3.Z).Unit, Vector2.new(var4, num1))
	local var6 = arg4.p
	return CFrame.new(var6 - 0.5 * var5, var6), arg4
end

var5.UpdateImmersionCamera = function(arg1, arg2, arg3, _, arg5, arg6)
	local var7 = arg1:GetHumanoid()
	local var8 = arg1:GetSubjectCFrame()
	local var9 = workspace.CurrentCamera
	local var10 = var2.LocalPlayer.Character
	if not var7 then
		return var9.CFrame, var9.Focus
	end

	local var12 = var10:FindFirstChild("HumanoidRootPart")
	if not var12 then
		return var9.CFrame, var9.Focus
	end

	local var13 = nil
	if var4 then
		var13 = if arg5 then Vector3.new(arg6.X - arg5.X, 0, arg6.Z - arg5.Z).Magnitude else 0
	end

	arg1.characterOrientation = var12:FindFirstChild("CharacterAlignOrientation")
	if not arg1.characterOrientation then
		local var15 = var12:FindFirstChild("RootAttachment")
		if not var15 then
			return
		end

		arg1.characterOrientation = Instance.new("AlignOrientation")
		arg1.characterOrientation.Name = "CharacterAlignOrientation"
		arg1.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		arg1.characterOrientation.Attachment0 = var15
		arg1.characterOrientation.RigidityEnabled = true
		arg1.characterOrientation.Parent = var12
	end

	if arg1.characterOrientation.Enabled == false then
		arg1.characterOrientation.Enabled = true
	end

	if arg1.needsReset then
		arg1.needsReset = false
		arg1.savedAutoRotate = var7.AutoRotate
		var7.AutoRotate = false
		if var4 then
			var3:RecenterUserHeadCFrame()
			arg1.lastTeleportRecenter = tick()
		end

		arg1:StartFadeFromBlack()
		arg3 = var8
	else
		if var7.Sit then
			arg3 = var8
			if not str3 and 0.01 < (arg3.Position - var9.CFrame.Position).Magnitude then
				arg1:StartVREdgeBlur(var2.LocalPlayer)
			end
		else
			arg1.characterOrientation.CFrame = var9.CFrame * arg1.controlModule:GetEstimatedVRTorsoFrame()
			if 0 < arg1.controlModule.inputMoveVector.Magnitude then
				arg1.motionDetTime = 0.1
			end

			if 0 < arg1.controlModule.inputMoveVector.Magnitude or 0 < arg1.motionDetTime then
				local var16 = arg1.motionDetTime - arg2
				arg1.motionDetTime = var16
				if not str3 then
					arg1:StartVREdgeBlur(var2.LocalPlayer)
				end

				var16 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				local var17 = var10.HumanoidRootPart
				local var18 = var17.CFrame.LookVector
				local var19 = arg6 - (var9.CFrame * (var16.Rotation + var16.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var17.Size.Y / 2, 0) - Vector3.new(var18.X, 0, var18.Z).Unit * var17.Size.Y * 0.125).Position + var9.CFrame.Position
				arg3 = var9.CFrame.Rotation + Vector3.new(var19.X, arg6.Y, var19.Z)
			else
				if var4 and var1.shouldRecenter(arg1.prevSubjStep, var13, arg1.lastTeleportRecenter, tick()) then
					local var23 = var3:GetUserCFrame(Enum.UserCFrame.Head)
					local var24 = var10.HumanoidRootPart
					local var25 = var24.CFrame.LookVector
					local var26 = arg6 - (var9.CFrame * (var23.Rotation + var23.Position * var9.HeadScale) * CFrame.new(0, -0.7 * var24.Size.Y / 2, 0) - Vector3.new(var25.X, 0, var25.Z).Unit * var24.Size.Y * 0.125).Position + var9.CFrame.Position
					var3:RecenterUserHeadCFrame()
					arg1:StartFadeFromBlack()
					arg3 = var9.CFrame.Rotation + Vector3.new(var26.X, arg6.Y, var26.Z)
					arg1.lastTeleportRecenter = tick()
				else
					arg3 = var9.CFrame.Rotation + Vector3.new(var9.CFrame.Position.X, arg6.Y, var9.CFrame.Position.Z)
				end
			end

			local var27 = arg1:getRotation(arg2)
			if 0 < math.abs(var27) then
				local var30 = var3:GetUserCFrame(Enum.UserCFrame.Head)
				var30 = var30.Rotation + var30.Position * var9.HeadScale
				local var31 = arg3 * var30
				arg3 = CFrame.new(var31.Position) * CFrame.Angles(0, -math.rad(var27 * 90), 0) * var31.Rotation * var30:Inverse()
			end
		end
	end

	if var4 then
		arg1.prevSubjStep = var13
	end

	return arg3, arg3 * CFrame.new(0, 0, -0.5)
end

var5.UpdateThirdPersonComfortTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var4 = arg1:GetCameraToSubjectDistance()
	if var4 < 0.5 then
		var4 = 0.5
	end

	if arg5 ~= nil then
		if arg1.lastCameraFocus ~= nil then
			local var5 = arg1.controlModule:GetMoveVector()
			local bool1 = true
			if 0.01 >= (arg5 - arg6).magnitude then
				bool1 = 0.01 < var5.magnitude
			end

			if bool1 then
				arg1.motionDetTime = 0.1
			end

			local var6 = arg1.motionDetTime - arg2
			arg1.motionDetTime = var6
			if 0 < arg1.motionDetTime then
				bool1 = true
			end

			if bool1 and (not arg1.needsReset) then
				arg1.VRCameraFocusFrozen = true
				arg4 = arg1.lastCameraFocus
				return arg3, arg4
			end

			var6 = true
			if arg1.lastCameraResetPosition ~= nil then
				var6 = 1 < (arg6 - arg1.lastCameraResetPosition).Magnitude
			end

			local var7 = arg1:getRotation(arg2)
			if 0 < math.abs(var7) then
				arg3 = arg4 * CFrame.Angles(0, -var7, 0) * arg4:ToObjectSpace(arg3)
			end

			if arg1.VRCameraFocusFrozen and var6 or arg1.needsReset then
				var3:RecenterUserHeadCFrame()
				arg1.VRCameraFocusFrozen = false
				arg1.needsReset = false
				arg1.lastCameraResetPosition = arg6
				arg1:ResetZoom()
				arg1:StartFadeFromBlack()
				local var8 = arg1:GetHumanoid()
				local var9 = var8.Torso and var8.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
				local var10 = arg4.Position - Vector3.new(var9.X, 0, var9.Z) * var4
				arg3 = CFrame.new(var10, (Vector3.new(arg4.Position.X, var10.Y, arg4.Position.Z)))
			end
		end
	end

	return arg3, arg4
end

var5.UpdateThirdPersonFollowTransform = function(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = workspace.CurrentCamera
	local var4 = arg1:GetCameraToSubjectDistance()
	local var5 = arg1:GetVRFocus(arg6, arg2)
	if arg1.needsReset then
		arg1.needsReset = false
		var3:RecenterUserHeadCFrame()
		arg1:ResetZoom()
		arg1:StartFadeFromBlack()
	end

	if arg1.recentered then
		local var7 = arg1:GetSubjectCFrame()
		if not var7 then
			return var1.CFrame, var1.Focus
		end

		arg3 = var5 * var7.Rotation * CFrame.new(0, 0, var4)
		arg1.focusOffset = var5:ToObjectSpace(arg3)
		arg1.recentered = false
		return arg3, var5
	end

	local var8 = arg1.controlModule
	local var12 = var5:ToWorldSpace(arg1.focusOffset)
	if 0.01 < (arg5 - arg6).magnitude or 0 < var8:GetMoveVector().magnitude then
		local var13 = var8:GetEstimatedVRTorsoFrame()
		local var14 = var1.CFrame * (var13.Rotation + var13.Position * var1.HeadScale)
		local var15 = var14.LookVector
		arg3 = var12:Lerp(CFrame.new(var1.CFrame.Position + (var5.Position - Vector3.new(var15.X, 0, var15.Z).Unit * var4) - var14.Position) * var12.Rotation, 0.01)
	else
		arg3 = var12
	end

	local var16 = arg1:getRotation(arg2)
	if 0 < math.abs(var16) then
		arg3 = var5 * CFrame.Angles(0, -var16, 0) * var5:ToObjectSpace(arg3)
	end

	arg1.focusOffset = var5:ToObjectSpace(arg3)
	arg4 = arg3 * CFrame.new(0, 0, -var4)
	if not str3 and 0.01 < (arg4.Position - var1.Focus.Position).Magnitude then
		arg1:StartVREdgeBlur(var2.LocalPlayer)
	end

	return arg3, arg4
end

var5.LeaveFirstPerson = function(arg1)
	str4.LeaveFirstPerson(arg1)
	arg1.needsReset = true
	if arg1.VRBlur then
		arg1.VRBlur.Visible = false
	end

	if arg1.characterOrientation then
		arg1.characterOrientation.Enabled = false
	end

	local var2 = arg1:GetHumanoid()
	if var2 then
		var2.AutoRotate = arg1.savedAutoRotate
	end
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseCamera [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "FlagUtil"
require(var1:WaitForChild(str2))
local var2 = require(var1:WaitForChild(str1))
local str3 = "CameraUtils"
local str4 = "ZoomController"
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "CameraToggleStateController"
str1 = require(script.Parent:WaitForChild(str4))
local str6 = "CameraInput"
str2 = require(script.Parent:WaitForChild(str5))
local str7 = "CameraUI"
str3 = require(script.Parent:WaitForChild(str6))
str4 = require(script.Parent:WaitForChild(str7))
Vector2.new(0, 0)
local var4 = game:GetService("VRService")
local var5 = UserSettings():GetService("UserGameSettings")
str5 = game:GetService("Players").LocalPlayer
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = var2.new()
	var1.gamepadZoomLevels = { 0, 10, 20 }
	var1.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	var1.cameraType = nil
	var1.cameraMovementMode = nil
	var1.lastCameraTransform = nil
	var1.lastUserPanCamera = tick()
	var1.humanoidRootPart = nil
	var1.humanoidCache = {}
	var1.lastSubject = nil
	var1.lastSubjectPosition = Vector3.new(0, 5, 0)
	var1.lastSubjectCFrame = CFrame.new(var1.lastSubjectPosition)
	var1.currentSubjectDistance = math.clamp(12.5, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
	var1.inFirstPerson = false
	var1.inMouseLockedMode = false
	var1.resetCameraAngle = true
	var1.enabled = false
	var1.cameraChangedConn = nil
	var1.shouldUseVRRotation = false
	var1.VRRotationIntensityAvailable = false
	var1.lastVRRotationIntensityCheckTime = 0
	var1.lastVRRotationTime = 0
	var1.vrRotateKeyCooldown = {}
	var1.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	var1.humanoidJumpOrigin = nil
	var1.trackingHumanoid = nil
	var1.cameraFrozen = false
	var1.subjectStateChangedConn = nil
	var1.gamepadZoomPressConnection = nil
	var1.mouseLockOffset = Vector3.new(0, 0, 0)
	var5:SetCameraYInvertVisible()
	var5:SetGamepadCameraSensitivityVisible()
	return var1
end

tbl1.GetModuleName = function(_)
	return "BaseCamera"
end

tbl1._setUpConfigurations = function(arg1)
	local function fn2(arg1)
		arg1:OnCharacterAdded(arg1)
	end

	arg1._connections:trackConnection("CHARACTER_ADDED", str5.CharacterAdded:Connect(fn2))
	arg1.humanoidRootPart = nil
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MODE_CHANGED", str5:GetPropertyChangedSignal("CameraMode"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(fn2))
	fn2 = function()
		arg1:OnPlayerCameraPropertyChange()
	end

	arg1._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", str5:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(fn2))
	arg1:OnPlayerCameraPropertyChange()
end

tbl1.OnCharacterAdded = function(arg1, _)
	local var1 = arg1.resetCameraAngle
	var1 = var1 or arg1:GetEnabled()
	arg1.resetCameraAngle = var1
	arg1.humanoidRootPart = nil
end

tbl1.GetHumanoidRootPart = function(arg1)
	local var2 = str5.Character:FindFirstChildOfClass("Humanoid")
	if not arg1.humanoidRootPart and (str5.Character and var2) then
		arg1.humanoidRootPart = var2.RootPart
	end

	return arg1.humanoidRootPart
end

tbl1.GetBodyPartToFollow = function(_, arg2, _)
	if arg2:GetState() == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			if var3:IsA("Model") then
				local var4 = var3:FindFirstChild("Head")
				return var4 or arg2.RootPart
			end
		end
	end

	return arg2.RootPart
end

tbl1.GetSubjectCFrame = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectCFrame
	if not var2 then
		return var3
	end

	if var2:IsA("Humanoid") then
		local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
		local var5 = var2.CameraOffset
		if arg1:GetIsMouseLocked() then
			var5 = Vector3.new()
		end

		local var6 = var2.RootPart
		var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
		if var6 then
			if var6:IsA("BasePart") then
				local var13 = nil
				if var2.RigType == Enum.HumanoidRigType.R15 then
					if var2.AutomaticScalingEnabled then
						local var16 = var2.RootPart
						var13 = Vector3.new(0, 1.5, 0)
						if var6 == var16 then
							var13 = var13 + Vector3.new(0, (var16.Size.Y - 2) / 2, 0)
						end
					else
						var13 = Vector3.new(0, 2, 0)
					end
				else
					var13 = Vector3.new(0, 1.5, 0)
				end

				if var4 then
					var13 = Vector3.new(0, 0, 0)
				end

				var3 = var6.CFrame * CFrame.new(var13 + var5)
			end
		end
	else
		if var2:IsA("BasePart") then
			var3 = var2.CFrame
		else
			if var2:IsA("Model") then
				var3 = if var2.PrimaryPart then var2:GetPrimaryPartCFrame() else CFrame.new()
			end
		end
	end

	if var3 then
		arg1.lastSubjectCFrame = var3
	end

	return var3
end

tbl1.GetSubjectVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.Velocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.Velocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.Velocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetSubjectRotVelocity = function(_)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	if not var2 then
		return Vector3.new(0, 0, 0)
	end

	if var2:IsA("BasePart") then
		return var2.RotVelocity
	end

	if var2:IsA("Humanoid") then
		local var5 = var2.RootPart
		if var5 then
			return var5.RotVelocity
		end
	else
		local var7 = var2.PrimaryPart
		if var2:IsA("Model") and var7 then
			return var7.RotVelocity
		end
	end

	return Vector3.new(0, 0, 0)
end

tbl1.StepZoom = function(arg1)
	local var1 = str3.getZoomDelta()
	local var4 = arg1.currentSubjectDistance
	if 0 < math.abs(var1) then
		local var6 = nil
		var6 = if 0 < var1 then math.max(var4 + var1 * (var4 * 0.5 + 1), arg1.FIRST_PERSON_DISTANCE_THRESHOLD) else math.max((var4 + var1) / (1 - var1 * 0.5), 0.5)
		if var6 < arg1.FIRST_PERSON_DISTANCE_THRESHOLD then
			var6 = 0.5
		end

		arg1:SetCameraToSubjectDistance(var6)
	end

	return str1.GetZoomRadius()
end

tbl1.GetSubjectPosition = function(arg1)
	local var1 = game.Workspace.CurrentCamera
	local var2 = var1
	var2 = var2 and var1.CameraSubject
	local var3 = arg1.lastSubjectPosition
	if var2 then
		if var2:IsA("Humanoid") then
			local var4 = var2:GetState() == Enum.HumanoidStateType.Dead
			local var5 = var2.CameraOffset
			if arg1:GetIsMouseLocked() then
				var5 = Vector3.new()
			end

			local var6 = var2.RootPart
			var6 = var4 and (var2.Parent and (var2.Parent:IsA("Model") and (var2.Parent:FindFirstChild("Head") or var6)))
			if var6 then
				if var6:IsA("BasePart") then
					local var10 = nil
					if var2.RigType == Enum.HumanoidRigType.R15 then
						if var2.AutomaticScalingEnabled then
							var10 = Vector3.new(0, 1.5, 0)
							if var6 == var2.RootPart then
								var10 = var10 + Vector3.new(0, var2.RootPart.Size.Y / 2 - 1, 0)
							end
						else
							var10 = Vector3.new(0, 2, 0)
						end
					else
						var10 = Vector3.new(0, 1.5, 0)
					end

					if var4 then
						var10 = Vector3.new(0, 0, 0)
					end

					var3 = var6.CFrame.p + var6.CFrame:vectorToWorldSpace(var10 + var5)
				end
			end
		else
			if var2:IsA("VehicleSeat") then
				var3 = var2.CFrame.p + var2.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
			else
				if var2:IsA("SkateboardPlatform") then
					var3 = var2.CFrame.p + Vector3.new(0, 5, 0)
				else
					if var2:IsA("BasePart") then
						var3 = var2.CFrame.p
					else
						if var2:IsA("Model") then
							if var2.PrimaryPart then
								var3 = var2:GetPrimaryPartCFrame().p
							else
								var3 = var2:GetModelCFrame().p
							end
						end
					end
				end
			end
		end
	else
		return nil
	end

	arg1.lastSubject = var2
	arg1.lastSubjectPosition = var3
	return var3
end

tbl1.OnCurrentCameraChanged = function(arg1)
	if arg1.cameraSubjectChangedConn then
		arg1.cameraSubjectChangedConn:Disconnect()
		arg1.cameraSubjectChangedConn = nil
	end

	local var2 = game.Workspace.CurrentCamera
	if var2 then
		arg1.cameraSubjectChangedConn = var2:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			arg1:OnNewCameraSubject()
		end)

		arg1:OnNewCameraSubject()
	end
end

tbl1.OnPlayerCameraPropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.InputTranslationToCameraAngleChange = function(_, arg2, arg3)
	return arg2 * arg3
end

tbl1.GamepadZoomPress = function(arg1)
	local var1 = arg1:GetCameraToSubjectDistance()
	local var2 = str5.CameraMaxZoomDistance
	for i1 = #arg1.gamepadZoomLevels, 1, -1 do
		local var3 = arg1.gamepadZoomLevels[i1]
		if var2 < var3 then
			continue
		end

		if var3 < str5.CameraMinZoomDistance then
			var3 = str5.CameraMinZoomDistance
			if var2 == var3 then
				break
			end
		end

		if var3 + (var2 - var3) / 2 < var1 then
			arg1:SetCameraToSubjectDistance(var3)
			return
		end

		local var4 = var3
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

tbl1.Enable = function(arg1, arg2)
	if arg1.enabled ~= arg2 then
		arg1.enabled = arg2
		arg1:OnEnabledChanged()
	end
end

tbl1.OnEnabledChanged = function(arg1)
	if arg1.enabled then
		arg1:_setUpConfigurations()
		str3.setInputEnabled(true)
		arg1.gamepadZoomPressConnection = str3.gamepadZoomPress:Connect(function()
			arg1:GamepadZoomPress()
		end)

		if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		end

		if arg1.cameraChangedConn then
			arg1.cameraChangedConn:Disconnect()
			arg1.cameraChangedConn = nil
		end

		arg1.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			arg1:OnCurrentCameraChanged()
		end)

		arg1:OnCurrentCameraChanged()
		return
	end

	arg1._connections:disconnectAll()
	str3.setInputEnabled(false)
	if arg1.gamepadZoomPressConnection then
		arg1.gamepadZoomPressConnection:Disconnect()
		arg1.gamepadZoomPressConnection = nil
	end

	arg1:Cleanup()
end

tbl1.GetEnabled = function(arg1)
	return arg1.enabled
end

tbl1.Cleanup = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end

	if arg1.cameraChangedConn then
		arg1.cameraChangedConn:Disconnect()
		arg1.cameraChangedConn = nil
	end

	arg1.lastCameraTransform = nil
	arg1.lastSubjectCFrame = nil
	var3.restoreMouseBehavior()
end

tbl1.UpdateMouseBehavior = function(arg1)
	if arg1.isCameraToggle and var5.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove == false then
		str4.setCameraModeToastEnabled(true)
		str3.enableCameraToggleInput()
		str2(arg1.inFirstPerson)
		return
	end

	str4.setCameraModeToastEnabled(false)
	str3.disableCameraToggleInput()
	if arg1.inFirstPerson or arg1.inMouseLockedMode then
		var3.setRotationTypeOverride(Enum.RotationType.CameraRelative)
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
		return
	end

	var3.restoreRotationType()
	if str3.getRotationActivated() then
		var3.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
		return
	end

	var3.restoreMouseBehavior()
end

tbl1.UpdateForDistancePropertyChange = function(arg1)
	arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance)
end

tbl1.SetCameraToSubjectDistance = function(arg1, arg2)
	local var1 = arg1.currentSubjectDistance
	if str5.CameraMode == Enum.CameraMode.LockFirstPerson then
		arg1.currentSubjectDistance = 0.5
		if not arg1.inFirstPerson then
			arg1:EnterFirstPerson()
		end
	else
		local var3 = math.clamp(arg2, str5.CameraMinZoomDistance, str5.CameraMaxZoomDistance)
		if var3 < 1 then
			arg1.currentSubjectDistance = 0.5
			if not arg1.inFirstPerson then
				arg1:EnterFirstPerson()
			end
		else
			arg1.currentSubjectDistance = var3
			if arg1.inFirstPerson then
				arg1:LeaveFirstPerson()
			end
		end
	end

	str1.SetZoomParameters(arg1.currentSubjectDistance, (math.sign(arg2 - var1)))
	return arg1.currentSubjectDistance
end

tbl1.SetCameraType = function(arg1, arg2)
	arg1.cameraType = arg2
end

tbl1.GetCameraType = function(arg1)
	return arg1.cameraType
end

tbl1.SetCameraMovementMode = function(arg1, arg2)
	arg1.cameraMovementMode = arg2
end

tbl1.GetCameraMovementMode = function(arg1)
	return arg1.cameraMovementMode
end

tbl1.SetIsMouseLocked = function(arg1, arg2)
	arg1.inMouseLockedMode = arg2
end

tbl1.GetIsMouseLocked = function(arg1)
	return arg1.inMouseLockedMode
end

tbl1.SetMouseLockOffset = function(arg1, arg2)
	arg1.mouseLockOffset = arg2
end

tbl1.GetMouseLockOffset = function(arg1)
	return arg1.mouseLockOffset
end

tbl1.InFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.EnterFirstPerson = function(arg1)
	arg1.inFirstPerson = true
	arg1:UpdateMouseBehavior()
end

tbl1.LeaveFirstPerson = function(arg1)
	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
end

tbl1.GetCameraToSubjectDistance = function(arg1)
	return arg1.currentSubjectDistance
end

tbl1.GetMeasuredDistanceToFocus = function(_)
	local var2 = game.Workspace.CurrentCamera
	if var2 then
		return (var2.CoordinateFrame.p - var2.Focus.p).magnitude
	end

	return nil
end

tbl1.GetCameraLookVector = function(_)
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end

tbl1.CalculateNewLookCFrameFromArg = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 + -1.3962634015954636, var2 + 1.3962634015954636)))
	return CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)
end

tbl1.CalculateNewLookVectorFromArg = function(arg1, arg2, arg3)
	return arg1:CalculateNewLookCFrameFromArg(arg2, arg3).LookVector
end

tbl1.CalculateNewLookVectorVRFromArg = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, 0)
	return ((CFrame.Angles(0, -var1.X, 0) * CFrame.new(Vector3.new(0, 0, 0), ((arg1:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit) * CFrame.Angles(-var1.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end

tbl1.GetHumanoid = function(arg1)
	local var1 = str5
	var1 = var1 and str5.Character
	if var1 then
		local var4 = arg1.humanoidCache[str5]
		if var4 and var4.Parent == var1 then
			return var4
		end

		arg1.humanoidCache[str5] = nil
		local var6 = var1:FindFirstChildOfClass("Humanoid")
		if var6 then
			arg1.humanoidCache[str5] = var6
		end

		return var6
	end

	return nil
end

tbl1.GetHumanoidPartToFollow = function(_, arg2, arg3)
	if arg3 == Enum.HumanoidStateType.Dead then
		local var3 = arg2.Parent
		if var3 then
			local var4 = var3:FindFirstChild("Head")
			return var4 or arg2.Torso
		end

		return arg2.Torso
	end

	return arg2.Torso
end

tbl1.OnNewCameraSubject = function(arg1)
	if arg1.subjectStateChangedConn then
		arg1.subjectStateChangedConn:Disconnect()
		arg1.subjectStateChangedConn = nil
	end
end

tbl1.IsInFirstPerson = function(arg1)
	return arg1.inFirstPerson
end

tbl1.Update = function(_, _)
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end

tbl1.GetCameraHeight = function(arg1)
	if var4.VREnabled and (not arg1.inFirstPerson) then
		return 0.25881904510252074 * arg1.currentSubjectDistance
	end

	return 0
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Invisicam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("Players")
local var3 = RaycastParams.new()
var3.FilterType = Enum.RaycastFilterType.Exclude
local var4 = RaycastParams.new()
var4.FilterType = Enum.RaycastFilterType.Include
local str2 = "BaseOcclusion"
local var5 = require(script.Parent:WaitForChild(str2))
local var6 = setmetatable({}, var5)
var6.__index = var6
local tbl1 = {
	LIMBS = 2,
	MOVEMENT = 3,
	CORNERS = 4,
	CIRCLE1 = 5,
	CIRCLE2 = 6,
	LIMBMOVE = 7,
	SMART_CIRCLE = 8,
	CHAR_OUTLINE = 9,
}

var6.new = function()
	local var1 = setmetatable(var5.new(), var6)
	var1.char = nil
	var1.humanoidRootPart = nil
	var1.torsoPart = nil
	var1.headPart = nil
	var1.childAddedConn = nil
	var1.childRemovedConn = nil
	var1.behaviors = {}
	var1.behaviors[tbl1.LIMBS] = var1.LimbBehavior
	var1.behaviors[tbl1.MOVEMENT] = var1.MoveBehavior
	var1.behaviors[tbl1.CORNERS] = var1.CornerBehavior
	var1.behaviors[tbl1.CIRCLE1] = var1.CircleBehavior
	var1.behaviors[tbl1.CIRCLE2] = var1.CircleBehavior
	var1.behaviors[tbl1.LIMBMOVE] = var1.LimbMoveBehavior
	var1.behaviors[tbl1.SMART_CIRCLE] = var1.SmartCircleBehavior
	var1.behaviors[tbl1.CHAR_OUTLINE] = var1.CharacterOutlineBehavior
	var1.mode = tbl1.SMART_CIRCLE
	var1.behaviorFunction = var1.SmartCircleBehavior
	var1.savedHits = {}
	var1.trackedLimbs = {}
	var1.camera = game.Workspace.CurrentCamera
	var1.enabled = false
	return var1
end

var6.Enable = function(arg1, arg2)
	arg1.enabled = arg2
	if not arg2 then
		arg1:Cleanup()
	end
end

var6.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Invisicam
end

var6.LimbBehavior = function(arg1, arg2)
	for k1, v1 in pairs(arg1.trackedLimbs) do
		arg2[#arg2 + 1] = k1.Position
	end
end

var6.MoveBehavior = function(arg1, arg2)
	for i1 = 1, 3 do
		local var1 = arg1.humanoidRootPart.Velocity
		arg2[#arg2 + 1] = arg1.humanoidRootPart.Position + (i1 - 1) * arg1.humanoidRootPart.CFrame.lookVector * (Vector3.new(var1.X, 0, var1.Z).Magnitude / 2)
	end
end

local tbl2 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1),
}

var6.CornerBehavior = function(arg1, arg2)
	local var1 = arg1.humanoidRootPart.CFrame
	local var2 = var1.Position
	local var3 = arg1.char:GetExtentsSize() / 2
	arg2[#arg2 + 1] = var2
	for i1 = 1, #tbl2 do
		local var4 = var1 - var2
		arg2[#arg2 + 1] = var2 + var4 * (var3 * tbl2[i1])
	end
end

var6.CircleBehavior = function(arg1, arg2)
	local var2 = nil
	if arg1.mode == tbl1.CIRCLE1 then
		var2 = arg1.humanoidRootPart.CFrame
	else
		local var3 = arg1.camera.CoordinateFrame
		var2 = var3 - var3.Position + arg1.humanoidRootPart.Position
	end

	arg2[#arg2 + 1] = var2.Position
	for i1 = 0, 9 do
		local var4 = 0.62831853071795862 * i1
		arg2[#arg2 + 1] = var2 * (Vector3.new(math.cos(var4), math.sin(var4), 0) * 3)
	end
end

var6.LimbMoveBehavior = function(arg1, arg2)
	arg1:LimbBehavior(arg2)
	arg1:MoveBehavior(arg2)
end

var6.CharacterOutlineBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var3 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var3
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var3
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = CFrame.new(Vector3.new(0, 0, 0), (Vector3.new(arg1.camera.CoordinateFrame.lookVector.X, 0, arg1.camera.CoordinateFrame.lookVector.Z)))
	local var6 = arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position
	local tbl2 = { arg1.torsoPart }
	if arg1.headPart then
		tbl2[#tbl2 + 1] = arg1.headPart
	end

	for i1 = 1, 24 do
		local var7 = 6.2831853071795862 * i1 / 24
		local var8 = var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 3)
		var8 = Vector3.new(var8.X, math.max(var8.Y, -2.25), var8.Z)
		if var1 then
			var4.FilterDescendantsInstances = tbl2
			local var9 = game.Workspace:Raycast(var6 + var8, -3 * var8, var4)
			if not var9 then
				continue
			end

			local var10 = var9.Position
			arg2[#arg2 + 1] = var10 + 0.2 * (var6 - var10).unit
		else
			local var11, var12 = game.Workspace:FindPartOnRayWithWhitelist(Ray.new(var6 + var8, -3 * var8), tbl2, false)
			if not var11 then
				continue
			end

			arg2[#arg2 + 1] = var12 + 0.2 * (var6 - var12).unit
		end
	end
end

local function RayIntersection(arg1, arg2, arg3, arg4)
	local var1 = arg2:Cross(arg4)
	local var2 = -arg4.Y
	local var3 = var1.Z
	local var4 = var1.Y
	local var5 = -arg4.Z
	local var6 = arg2.Y
	local var7 = arg2.Z
	local var9 = arg2.X * (var2 * var3 - var4 * var5) - -arg4.X * (var6 * var3 - var4 * var7) + var1.X * (var6 * var5 - var2 * var7)
	local var10 = arg3.X - arg1.X
	local var11 = arg3.Y - arg1.Y
	local var12 = arg3.Z - arg1.Z
	if var9 == 0 then
		return Vector3.new(0, 0, 0)
	end

	var2 = -arg4.Y
	var5 = var1.Z
	var4 = var1.Y
	var7 = -arg4.Z
	local var13 = (var10 * (var2 * var5 - var4 * var7) - -arg4.X * (var11 * var5 - var4 * var12) + var1.X * (var11 * var7 - var2 * var12)) / var9
	var3 = var1.Z
	var7 = var1.Y
	var4 = arg2.Y
	var5 = arg2.Z
	var6 = arg3 + (arg2.X * (var11 * var3 - var7 * var12) - var10 * (var4 * var3 - var7 * var5) + var1.X * (var4 * var12 - var11 * var5)) / var9 * arg4
	local var14 = arg1 + var13 * arg2
	var2 = var14 + (var6 - var14) * 0.5
	if (var6 - var14).Magnitude < 0.25 then
		return var2
	end

	return Vector3.new(0, 0, 0)
end

var6.SmartCircleBehavior = function(arg1, arg2)
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p
	local var2 = arg1.torsoPart.CFrame.upVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var2
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var2
	local var4 = arg1.torsoPart.CFrame.rightVector.unit
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p + var4
	arg2[#arg2 + 1] = arg1.torsoPart.CFrame.p - var4
	if arg1.headPart then
		arg2[#arg2 + 1] = arg1.headPart.CFrame.p
	end

	local var5 = arg1.camera.CFrame - arg1.camera.CFrame.p
	local var6 = Vector3.new(0, 0.5, 0) + (arg1.torsoPart and arg1.torsoPart.Position or arg1.humanoidRootPart.Position)
	for i1 = 1, 24 do
		local var7 = 0.26179938779914941 * i1 - 1.5707963267948966
		local var8 = var6 + var5 * (Vector3.new(math.cos(var7), math.sin(var7), 0) * 2.5)
		local var9 = var8 - arg1.camera.CFrame.p
		if var1 then
			var3.FilterDescendantsInstances = { arg1.char }
			local var16 = game.Workspace:Raycast(var6, var8 - var6, var3)
			local var17 = var8
			if var16 then
				local var18 = var16.Normal
				local var19 = var16.Position + 0.1 * var18.unit
				local var20 = var19 - var6
				local var21 = var20:Cross(var9).unit:Cross(var18).unit
				if var20.unit:Dot(-var21) < var20.unit:Dot((var19 - arg1.camera.CFrame.p).unit) then
					var17 = RayIntersection(var19, var21, var8, var9)
					if 0 < var17.Magnitude then
						var16 = game.Workspace:Raycast(var19, var17 - var19, var3)
						if var16 then
							var17 = var16.Position + 0.1 * var16.Normal.Unit
						end
					else
						var17 = var19
					end
				else
					var17 = var19
				end

				var16 = game.Workspace:Raycast(var6, var17 - var6, var3)
				if var16 then
					var17 = var16.Position - 0.1 * (var17 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var17
		else
			local var28, var29, var30 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var8 - var6), { arg1.char }, false, false)
			local var31 = var8
			if var28 then
				local var32 = var29 + 0.1 * var30.unit
				local var33 = var32 - var6
				local var34 = var33:Cross(var9).unit:Cross(var30).unit
				if var33.unit:Dot(-var34) < var33.unit:Dot((var32 - arg1.camera.CFrame.p).unit) then
					var31 = RayIntersection(var32, var34, var8, var9)
					if 0 < var31.Magnitude then
						local var37, var38, var39 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var32, var31 - var32), { arg1.char }, false, false)
						if var37 then
							var31 = var38 + 0.1 * var39.unit
						end
					else
						var31 = var32
					end
				else
					var31 = var32
				end

				local var41, var42, var43 = game.Workspace:FindPartOnRayWithIgnoreList(Ray.new(var6, var31 - var6), { arg1.char }, false, false)
				if var41 then
					var31 = var42 - 0.1 * (var31 - var6).unit
				end
			end

			arg2[#arg2 + 1] = var31
		end
	end
end

var6.CheckTorsoReference = function(arg1)
	if arg1.char then
		arg1.torsoPart = arg1.char:FindFirstChild("Torso")
		if not arg1.torsoPart then
			arg1.torsoPart = arg1.char:FindFirstChild("UpperTorso")
			if not arg1.torsoPart then
				arg1.torsoPart = arg1.char:FindFirstChild("HumanoidRootPart")
			end
		end

		arg1.headPart = arg1.char:FindFirstChild("Head")
	end
end

str1 = {
	Head = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	LeftLowerArm = true,
	RightLowerArm = true,
	LeftUpperLeg = true,
	RightUpperLeg = true,
}

var6.CharacterAdded = function(arg1, arg2, arg3)
	if arg3 ~= var2.LocalPlayer then
		return
	end

	if arg1.childAddedConn then
		arg1.childAddedConn:Disconnect()
		arg1.childAddedConn = nil
	end

	if arg1.childRemovedConn then
		arg1.childRemovedConn:Disconnect()
		arg1.childRemovedConn = nil
	end

	arg1.char = arg2
	arg1.trackedLimbs = {}
	arg1.childAddedConn = arg2.ChildAdded:Connect(function(arg1)
		if arg1:IsA("BasePart") then
			if str1[arg1.Name] then
				arg1.trackedLimbs[arg1] = true
			end

			if arg1.Name == "Torso" or arg1.Name == "UpperTorso" then
				arg1.torsoPart = arg1
			end

			if arg1.Name == "Head" then
				arg1.headPart = arg1
			end
		end
	end)

	arg1.childRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		arg1.trackedLimbs[arg1] = nil
		arg1:CheckTorsoReference()
	end)

	for k1, v1 in pairs(arg1.char:GetChildren()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if str1[v1.Name] then
			arg1.trackedLimbs[v1] = true
		end

		if v1.Name == "Torso" or v1.Name == "UpperTorso" then
			arg1.torsoPart = v1
		end

		if v1.Name ~= "Head" then
			continue
		end

		arg1.headPart = v1
	end
end

local function AssertTypes(arg1, ...)
	local tbl1 = {}
	local str1 = ""
	for k1, v1 in pairs({ ... }) do
		tbl1[v1] = true
		local var1 = str1
		str1 = var1 .. (if str1 == "" then "" else " or ") .. v1
	end

	local var2 = type(arg1)
	assert(tbl1[var2], str1 .. " type expected, got: " .. var2)
end

var6.SetMode = function(arg1, arg2)
	AssertTypes(arg2, "number")
	for k1, v1 in pairs(tbl1) do
		if v1 ~= arg2 then
			continue
		end

		arg1.mode = arg2
		arg1.behaviorFunction = arg1.behaviors[arg1.mode]
		return
	end

	error("Invalid mode number")
end

var6.GetObscuredParts = function(arg1)
	return arg1.savedHits
end

var6.Cleanup = function(arg1)
	for k1, v1 in pairs(arg1.savedHits) do
		k1.LocalTransparencyModifier = v1
	end
end

var6.Update = function(arg1, _, arg3, arg4)
	if not arg1.enabled or (not arg1.char) then
		return arg3, arg4
	end

	arg1.camera = game.Workspace.CurrentCamera
	if not arg1.humanoidRootPart then
		local var3 = arg1.char:FindFirstChildOfClass("Humanoid")
		if var3 and var3.RootPart then
			arg1.humanoidRootPart = var3.RootPart
		else
			arg1.humanoidRootPart = arg1.char:FindFirstChild("HumanoidRootPart")
			if not arg1.humanoidRootPart then
				return arg3, arg4
			end
		end

		local var4 = nil
		arg1.humanoidRootPart.AncestryChanged:Connect(function(arg1, arg2)
			if arg1 == arg1.humanoidRootPart and (not arg2) then
				arg1.humanoidRootPart = nil
				if var4 and var4.Connected then
					var4:Disconnect()
					var4 = nil
				end
			end
		end)

	end

	if not arg1.torsoPart then
		arg1:CheckTorsoReference()
		if not arg1.torsoPart then
			return arg3, arg4
		end
	end

	local tbl1 = {}
	arg1.behaviorFunction(arg1, tbl1)
	local tbl2 = {}
	local tbl3 = { arg1.char }
	local var5 = nil
	var5 = arg1.camera:GetPartsObscuringTarget({
		arg1.headPart and arg1.headPart.CFrame.p or tbl1[1],
		arg1.torsoPart and arg1.torsoPart.CFrame.p or tbl1[2],
	}, tbl3)

	local num1 = 0
	local tbl4 = {}
	local num2 = 0.75
	local num3 = 0.75
	for i1 = 1, #var5 do
		local var6 = var5[i1]
		tbl4[var6] = true
		num1 = num1 + 1
		for k1, v1 in pairs(var6:GetChildren()) do
			if v1:IsA("Decal") or v1:IsA("Texture") then
				num1 = num1 + 1
				break
			end
		end
	end

	if 0 < num1 then
		num2 = math.pow(0.375 / num1 + 0.375, 1 / num1)
		num3 = math.pow(0.25 / num1 + 0.25, 1 / num1)
	end

	var5 = arg1.camera:GetPartsObscuringTarget(tbl1, tbl3)
	local tbl5 = {}
	for i2 = 1, #var5 do
		local var7 = var5[i2]
		tbl5[var7] = tbl4[var7] and num2 or num3
		if var7.Transparency < tbl5[var7] then
			tbl2[var7] = true
			if not arg1.savedHits[var7] then
				arg1.savedHits[var7] = var7.LocalTransparencyModifier
			end
		end

		for k2, v2 in pairs(var7:GetChildren()) do
			if (v2:IsA("Decal") or v2:IsA("Texture")) and v2.Transparency < tbl5[var7] then
				local var8 = tbl5[var7]
				tbl5[v2] = var8
				tbl2[v2] = true
				if arg1.savedHits[v2] then
					continue
				end

				arg1.savedHits[v2] = v2.LocalTransparencyModifier
			end
		end
	end

	for k3, v3 in pairs(arg1.savedHits) do
		if tbl2[k3] then
			k3.LocalTransparencyModifier = k3.Transparency < 1 and (tbl5[k3] - k3.Transparency) / (1 - k3.Transparency) or 0
		else
			k3.LocalTransparencyModifier = v3
			arg1.savedHits[k3] = nil
		end
	end

	return arg3, arg4
end

return var6

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
setmetatable(tbl1, { __call = function(_, ...)
	return tbl1.new(...)
end })

tbl1.new = function()
	return (setmetatable({}, tbl1))
end

tbl1.CharacterAdded = function(_, _, _)
end

tbl1.CharacterRemoving = function(_, _, _)
end

tbl1.OnCameraSubjectChanged = function(_, _)
end

tbl1.GetOcclusionMode = function(_)
	warn("BaseOcclusion GetOcclusionMode must be overridden by derived classes")
	return nil
end

tbl1.Enable = function(_, _)
	warn("BaseOcclusion Enable must be overridden by derived classes")
end

tbl1.Update = function(_, _, arg3, arg4)
	warn("BaseOcclusion Update must be overridden by derived classes")
	return arg3, arg4
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserFixOrbitalCameraAzimuth")
local str2 = "CameraUtils"
local str3 = "CameraInput"
local var2 = require(script.Parent:WaitForChild(str3))
str1 = require(script.Parent:WaitForChild(str2))
local str4 = "BaseCamera"
str2 = require(script.Parent:WaitForChild(str4))
local var3 = game:GetService("Players")
str3 = setmetatable({}, str2)
str3.__index = str3
str3.new = function()
	local var1 = setmetatable(str2.new(), str3)
	var1.lastUpdate = tick()
	var1.changedSignalConnections = {}
	var1.refAzimuthRad = nil
	var1.curAzimuthRad = nil
	var1.minAzimuthAbsoluteRad = nil
	var1.maxAzimuthAbsoluteRad = nil
	var1.useAzimuthLimits = nil
	var1.curElevationRad = nil
	var1.minElevationRad = nil
	var1.maxElevationRad = nil
	var1.curDistance = nil
	var1.minDistance = nil
	var1.maxDistance = nil
	var1.gamepadDollySpeedMultiplier = 1
	var1.lastUserPanCamera = tick()
	var1.externalProperties = {}
	var1.externalProperties.InitialDistance = 25
	var1.externalProperties.MinDistance = 10
	var1.externalProperties.MaxDistance = 100
	var1.externalProperties.InitialElevation = 35
	var1.externalProperties.MinElevation = 35
	var1.externalProperties.MaxElevation = 35
	var1.externalProperties.ReferenceAzimuth = -45
	var1.externalProperties.CWAzimuthTravel = 90
	var1.externalProperties.CCWAzimuthTravel = 90
	var1.externalProperties.UseAzimuthLimits = false
	var1:LoadNumberValueParameters()
	return var1
end

str3.LoadOrCreateNumberValueParameter = function(arg1, arg2, arg3, arg4)
	local var2 = script:FindFirstChild(arg2)
	if var2 and var2:IsA(arg3) then
		arg1.externalProperties[arg2] = var2.Value
	else
		if arg1.externalProperties[arg2] ~= nil then
			var2 = Instance.new(arg3)
			var2.Name = arg2
			var2.Parent = script
			var2.Value = arg1.externalProperties[arg2]
		else
			return
		end
	end

	if arg4 then
		if arg1.changedSignalConnections[arg2] then
			arg1.changedSignalConnections[arg2]:Disconnect()
		end

		arg1.changedSignalConnections[arg2] = var2.Changed:Connect(function(arg1)
			arg1.externalProperties[arg2] = arg1
			arg4(arg1)
		end)

	end
end

str3.SetAndBoundsCheckAzimuthValues = function(arg1)
	arg1.minAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) - math.abs((math.rad(arg1.externalProperties.CWAzimuthTravel)))
	arg1.maxAzimuthAbsoluteRad = math.rad(arg1.externalProperties.ReferenceAzimuth) + math.abs((math.rad(arg1.externalProperties.CCWAzimuthTravel)))
	arg1.useAzimuthLimits = arg1.externalProperties.UseAzimuthLimits
	if arg1.useAzimuthLimits then
		local var1 = math.max(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
		var1 = math.min(arg1.curAzimuthRad, arg1.maxAzimuthAbsoluteRad)
		arg1.curAzimuthRad = var1
	end
end

str3.SetAndBoundsCheckElevationValues = function(arg1)
	local var1 = math.max(arg1.externalProperties.MinElevation, -80)
	local var2 = math.min(arg1.externalProperties.MaxElevation, 80)
	arg1.minElevationRad = math.rad((math.min(var1, var2)))
	arg1.maxElevationRad = math.rad((math.max(var1, var2)))
	local var3 = math.max(arg1.curElevationRad, arg1.minElevationRad)
	arg1.curElevationRad = var3
	var3 = math.min(arg1.curElevationRad, arg1.maxElevationRad)
	arg1.curElevationRad = var3
end

str3.SetAndBoundsCheckDistanceValues = function(arg1)
	arg1.minDistance = arg1.externalProperties.MinDistance
	arg1.maxDistance = arg1.externalProperties.MaxDistance
	local var1 = math.max(arg1.curDistance, arg1.minDistance)
	arg1.curDistance = var1
	var1 = math.min(arg1.curDistance, arg1.maxDistance)
	arg1.curDistance = var1
end

str3.LoadNumberValueParameters = function(arg1)
	arg1:LoadOrCreateNumberValueParameter("InitialElevation", "NumberValue", nil)
	arg1:LoadOrCreateNumberValueParameter("InitialDistance", "NumberValue", nil)
	local str1 = "ReferenceAzimuth"
	local str2 = "NumberValue"
	arg1:LoadOrCreateNumberValueParameter(str1, str2, if var1 then arg1.SetAndBoundsCheckAzimuthValues else arg1.SetAndBoundsCheckAzimuthValue)
	arg1:LoadOrCreateNumberValueParameter("CWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("CCWAzimuthTravel", "NumberValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1:LoadOrCreateNumberValueParameter("MinElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MaxElevation", "NumberValue", arg1.SetAndBoundsCheckElevationValues)
	arg1:LoadOrCreateNumberValueParameter("MinDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("MaxDistance", "NumberValue", arg1.SetAndBoundsCheckDistanceValues)
	arg1:LoadOrCreateNumberValueParameter("UseAzimuthLimits", "BoolValue", arg1.SetAndBoundsCheckAzimuthValues)
	arg1.curAzimuthRad = math.rad(arg1.externalProperties.ReferenceAzimuth)
	arg1.curElevationRad = math.rad(arg1.externalProperties.InitialElevation)
	arg1.curDistance = arg1.externalProperties.InitialDistance
	arg1:SetAndBoundsCheckAzimuthValues()
	arg1:SetAndBoundsCheckElevationValues()
	arg1:SetAndBoundsCheckDistanceValues()
end

str3.GetModuleName = function(_)
	return "OrbitalCamera"
end

str3.SetInitialOrientation = function(arg1, arg2)
	if not arg2 or (not arg2.RootPart) then
		warn("OrbitalCamera could not set initial orientation due to missing humanoid")
		return
	end

	assert(arg2.RootPart, "")
	local var1 = (arg2.RootPart.CFrame.LookVector - Vector3.new(0, 0.23, 0)).Unit
	local var2 = math.asin(arg1:GetCameraLookVector().Y) - math.asin(var1.Y)
	if not str1.IsFinite((str1.GetAngleBetweenXZVectors(var1, arg1:GetCameraLookVector()))) then
	end

	if not str1.IsFinite(var2) then
	end
end

str3.GetCameraToSubjectDistance = function(arg1)
	return arg1.curDistance
end

str3.SetCameraToSubjectDistance = function(arg1, arg2)
	if var3.LocalPlayer then
		arg1.currentSubjectDistance = math.clamp(arg2, arg1.minDistance, arg1.maxDistance)
		local var1 = math.max(arg1.currentSubjectDistance, arg1.FIRST_PERSON_DISTANCE_THRESHOLD)
		arg1.currentSubjectDistance = var1
	end

	arg1.inFirstPerson = false
	arg1:UpdateMouseBehavior()
	return arg1.currentSubjectDistance
end

str3.CalculateNewLookVector = function(arg1, arg2, arg3)
	local var1 = arg2
	var1 = var1 or arg1:GetCameraLookVector()
	local var2 = math.asin(var1.Y)
	local var3 = Vector2.new(arg3.X, (math.clamp(arg3.Y, var2 - 1.3962634015954636, var2 - -1.3962634015954636)))
	return (CFrame.Angles(0, -var3.X, 0) * CFrame.new(Vector3.new(0, 0, 0), var1) * CFrame.Angles(-var3.Y, 0, 0)).LookVector
end

str3.Update = function(arg1, arg2)
	local var1 = tick()
	local var4 = workspace.CurrentCamera
	local var5 = var4
	var5 = var5 and var4.CameraSubject
	local var6 = var5
	local var7 = var5
	local var8 = var2.getRotation(arg2) ~= Vector2.new()
	local var9 = var4.CFrame
	local var10 = var4.Focus
	local var11 = var3.LocalPlayer
	var6 = var6 and var5:IsA("VehicleSeat")
	var7 = var7 and var5:IsA("SkateboardPlatform")
	if arg1.lastUpdate == nil or 1 < var1 - arg1.lastUpdate then
		arg1.lastCameraTransform = nil
	end

	if var8 then
		arg1.lastUserPanCamera = tick()
	end

	local var13 = arg1:GetSubjectPosition()
	if var13 then
		if var11 then
			if var4 then
				if arg1.gamepadDollySpeedMultiplier ~= 1 then
					arg1:SetCameraToSubjectDistance(arg1.currentSubjectDistance * arg1.gamepadDollySpeedMultiplier)
				end

				local var14 = var2.getRotation(arg2)
				var10 = CFrame.new(var13)
				local var15 = arg1.curAzimuthRad - var14.X
				arg1.curAzimuthRad = var15
				if arg1.useAzimuthLimits then
					var15 = math.clamp(arg1.curAzimuthRad, arg1.minAzimuthAbsoluteRad, arg1.maxAzimuthAbsoluteRad)
					arg1.curAzimuthRad = var15
				else
					if arg1.curAzimuthRad ~= 0 then
						var15 = math.sign(arg1.curAzimuthRad) * (math.abs(arg1.curAzimuthRad) % 6.2831853071795862)
						var15 = var15 or 0
					end

					arg1.curAzimuthRad = 0
				end

				var15 = math.clamp(arg1.curElevationRad + var14.Y, arg1.minElevationRad, arg1.maxElevationRad)
				arg1.curElevationRad = var15
				var9 = CFrame.new(var13 + arg1.currentSubjectDistance * (CFrame.fromEulerAnglesYXZ(-arg1.curElevationRad, arg1.curAzimuthRad, 0) * Vector3.new(0, 0, 1)), var13)
				arg1.lastCameraTransform = var9
				arg1.lastCameraFocus = var10
				if (var6 or var7) and var5:IsA("BasePart") then
					arg1.lastSubjectCFrame = var5.CFrame
				else
					arg1.lastSubjectCFrame = nil
				end
			end
		end
	end

	arg1.lastUpdate = var1
	return var9, var10
end

return str3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraInput [ModuleScript]
-- y u r i

game:GetService("RunService")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Instance.new("BindableEvent")
local var3 = nil
local var4 = Instance.new("BindableEvent")
local var5 = nil
local var6 = game:GetService("UserInputService")
var6.InputBegan:Connect(function(arg1, arg2)
	if not arg2 and arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var2:Fire()
	end
end)

var6.InputEnded:Connect(function(arg1, _)
	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		var4:Fire()
	end
end)

var3 = var2.Event
var2 = nil
var5 = var4.Event
local var7 = game:GetService("Players").LocalPlayer
local num1 = 0
local var8 = game:GetService("ContextActionService")
local var9 = UserSettings():GetService("UserGameSettings")
local var10 = game:GetService("VRService")
local var11 = game:GetService("GuiService")
local var12 = var1.getUserFlag("UserPSSinkUnknownTouchEvents")
local var13 = var1.getUserFlag("UserPSTextboxResetCameraInput")
str1 = var1.getUserFlag("UserFixVRCameraGamepadReset")
local var14 = var1.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local var15 = Vector2.new(1, 0.77) * 0.069813170079773182 * 60
local var16 = Vector2.new(1, 0.77) * 0.0087266462599716477
local var17 = Vector2.new(1, 0.77) * 0.12217304763960307
local var18 = Vector2.new(1, 0.66) * 0.017453292519943295
local tbl1 = { Thumbstick2 = Vector2.new(), ButtonLeft = 0, ButtonRight = 0 }
local tbl2 = { Movement = Vector2.new(), Wheel = 0, Pinch = 0 }
tbl2.Pan = Vector2.new()
local var19 = Instance.new("BindableEvent")
local tbl3 = { Move = Vector2.new(), Pinch = 0 }
local var21 = Enum.ContextActionPriority.Medium.Value
var2 = function(arg1)
	return math.sign(arg1) * math.clamp((math.exp((math.abs(arg1) - 0.1) / 0.9 * 2) - 1) / 6.3890560989306504, 0, 1)
end

var4 = function(arg1)
	local var2 = workspace.CurrentCamera
	if not var2 then
		return arg1
	end

	local var3 = var2.CFrame:ToEulerAnglesYXZ()
	if 0 <= arg1.Y * var3 then
		return arg1
	end

	return Vector2.new(1, (1 - (math.abs(var3) * 2 / 3.1415926535897931) ^ 0.75) * 0.75 + 0.25) * arg1
end

local function isInDynamicThumbstickArea(arg1)
	local var1 = var7:FindFirstChildOfClass("PlayerGui")
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("TouchGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("TouchControlFrame")
	local var4 = var3
	var4 = var4 and var3:FindFirstChild("DynamicThumbstickFrame")
	if not var4 then
		return false
	end

	if not var2.Enabled then
		return false
	end

	local var5 = var4.AbsolutePosition
	local var8 = var5 + var4.AbsoluteSize
	local bool2 = false
	if var5.X <= arg1.X then
		bool2 = false
		if var5.Y <= arg1.Y then
			bool2 = false
			if arg1.X <= var8.X then
				bool2 = arg1.Y <= var8.Y
			end
		end
	end

	return bool2
end

local function incPanInputCount()
	local var1 = math.max(0, num1 + 1)
	num1 = var1
end

local function decPanInputCount()
	local var1 = math.max(0, num1 - 1)
	num1 = var1
end

local function resetPanInputCount()
	num1 = 0
end

local var22 = nil
local tbl4 = { gamepadZoomPress = var19.Event }
local tbl5 = {}
local tbl6 = { Left = 0, Right = 0, I = 0, O = 0 }
if str1 then
	var22 = Instance.new("BindableEvent")
	tbl4.gamepadReset = var22.Event
else
	var22 = var10.VREnabled and Instance.new("BindableEvent") or nil
	if var10.VREnabled then
		tbl4.gamepadReset = var22.Event
	end
end

tbl4.getRotationActivated = function()
	if var14 then
		local bool3 = true
		if 0 >= num1 then
			bool3 = true
			if 0 >= tbl1.Thumbstick2.Magnitude then
				bool3 = tbl1.ButtonRight - tbl1.ButtonLeft ~= 0
			end
		end

		return bool3
	end

	local bool4 = true
	if 0 >= num1 then
		bool4 = 0 < tbl1.Thumbstick2.Magnitude
	end

	return bool4
end

tbl4.getRotation = function(arg1, arg2)
	local var2 = Vector2.new(1, var9:GetCameraYInvertValue())
	local var3 = Vector2.new(tbl6.Right - tbl6.Left, 0) * arg1
	local var5 = nil
	var5 = if var14 then (tbl1.Thumbstick2 + Vector2.new(tbl1.ButtonRight - tbl1.ButtonLeft, 0)) * var9.GamepadCameraSensitivity * arg1 else tbl1.Thumbstick2 * var9.GamepadCameraSensitivity * arg1
	local var6 = tbl2.Movement
	local var7 = tbl2.Pan
	local var8 = var4(tbl3.Move)
	if arg2 then
		var3 = Vector2.new()
	end

	return (var3 * 2.0943951023931953 + var5 * var15 + var6 * var16 + var7 * var17 + var8 * var18) * var2
end

tbl4.getZoomDelta = function()
	return (tbl6.O - tbl6.I) * 0.1 + (-tbl2.Wheel + tbl2.Pinch) * 1 + -tbl3.Pinch * 0.04
end

local var23 = nil
local tbl7 = {}
local var24 = nil
local var25 = nil
local var26 = nil
local var27 = nil
local var28 = nil
var24 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Begin)
	if var23 == nil and (isInDynamicThumbstickArea(arg1.Position) and (not arg2)) then
		var23 = arg1
		return
	end

	if not arg2 then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end

	tbl7[arg1] = arg2
end

var27 = function(arg1, arg2)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.Change)
	if arg1 == var23 then
		return
	end

	if tbl7[arg1] == nil then
		if var12 then
			tbl7[arg1] = true
		else
			tbl7[arg1] = arg2
		end
	end

	local tbl1 = {}
	for k1, v1 in pairs(tbl7) do
		if v1 then
			continue
		end

		table.insert(tbl1, k1)
	end

	if #tbl1 == 1 and tbl7[arg1] == false then
		local var3 = tbl3
		local var4 = arg1.Delta
		local var5 = var3.Move + Vector2.new(var4.X, var4.Y)
		var3.Move = var5
	end

	if #tbl1 == 2 then
		local var10 = (tbl1[1].Position - tbl1[2].Position).Magnitude
		if var25 then
			local var11 = tbl3
			local var13 = var11.Pinch + (var10 - var25)
			var11.Pinch = var13
		end

		var25 = var10
		return
	end

	var25 = nil
end

var26 = function(arg1, _)
	assert(arg1.UserInputType == Enum.UserInputType.Touch)
	assert(arg1.UserInputState == Enum.UserInputState.End)
	if arg1 == var23 then
		var23 = nil
	end

	if tbl7[arg1] == false then
		var25 = nil
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end

	tbl7[arg1] = nil
end

local bool1 = false
local function resetInputDevices()
	local var1 = tbl6
	for k1, v1 in pairs({ tbl1, var1, tbl2, tbl3 }) do
		for k2, v2 in pairs(v1) do
			if type(v2) == "boolean" then
				v1[k2] = false
			else
				local var2 = v1[k2] * 0
				v1[k2] = var2
			end
		end
	end

	num1 = 0
end

var28 = function()
	tbl7 = {}
	var23 = nil
	var25 = nil
	num1 = 0
end

local function thumbstick(_, _, arg3)
	local var1 = arg3.Position
	tbl1[arg3.KeyCode.Name] = Vector2.new(var2(var1.X), -var2(var1.Y))
	return Enum.ContextActionResult.Pass
end

local function directionalButtons(_, arg2, arg3)
	if arg2 == Enum.UserInputState.Cancel then
		tbl1[arg3.KeyCode.Name] = 0
	else
		tbl1[arg3.KeyCode.Name] = var2(arg3.Position.Z)
	end

	return Enum.ContextActionResult.Pass
end

local function keypress(_, arg2, arg3)
	local var1 = tbl6
	local var2 = arg3.KeyCode.Name
	var1[var2] = if arg2 == Enum.UserInputState.Begin then 1 else 0
end

local function gamepadReset(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var22:Fire()
	end
end

local function gamepadZoomPress(_, arg2, _)
	if arg2 == Enum.UserInputState.Begin then
		var19:Fire()
	end
end

var23 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var24(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 and (not arg2) then
		local var1 = math.max(0, num1 + 1)
		num1 = var1
	end
end

var25 = function(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var27(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseMovement then
		local var2 = arg1.Delta
		tbl2.Movement = Vector2.new(var2.X, var2.Y)
	end
end

local function inputEnded(arg1, arg2)
	if arg1.UserInputType == Enum.UserInputType.Touch then
		var26(arg1, arg2)
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
		local var1 = math.max(0, num1 - 1)
		num1 = var1
	end
end

tbl7 = function(arg1, arg2, arg3, arg4)
	if not arg4 then
		tbl2.Wheel = arg1
		tbl2.Pan = arg2
		tbl2.Pinch = -arg3
	end
end

tbl4.setInputEnabled = function(arg1)
	if bool1 == arg1 then
		return
	end

	bool1 = arg1
	resetInputDevices()
	var28()
	local var1
	if bool1 then
		var8:BindActionAtPriority("RbxCameraThumbstick", thumbstick, false, var21, Enum.KeyCode.Thumbstick2)
		if var14 then
			var8:BindActionAtPriority("RbxCameraDirectionalButtons", directionalButtons, false, var21, Enum.KeyCode.ButtonLeft, Enum.KeyCode.ButtonRight)
		end

		var8:BindActionAtPriority("RbxCameraKeypress", keypress, false, var21, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.I, Enum.KeyCode.O)
		if var10.VREnabled then
			var8:BindAction("RbxCameraGamepadReset", gamepadReset, false, Enum.KeyCode.ButtonL3)
		end

		var8:BindAction("RbxCameraGamepadZoom", gamepadZoomPress, false, Enum.KeyCode.ButtonR3)
		var1 = var23
		table.insert(tbl5, var6.InputBegan:Connect(var1))
		var1 = var25
		table.insert(tbl5, var6.InputChanged:Connect(var1))
		var1 = inputEnded
		table.insert(tbl5, var6.InputEnded:Connect(var1))
		var1 = tbl7
		table.insert(tbl5, var6.PointerAction:Connect(var1))
		var1 = var28
		table.insert(tbl5, var11.MenuOpened:connect(var1))
		return
	end

	var8:UnbindAction("RbxCameraThumbstick")
	if var14 then
		var8:UnbindAction("RbxCameraDirectionalButtons")
	end

	var8:UnbindAction("RbxCameraMouseMove")
	var8:UnbindAction("RbxCameraMouseWheel")
	var8:UnbindAction("RbxCameraKeypress")
	var8:UnbindAction("RbxCameraGamepadZoom")
	if var10.VREnabled then
		var8:UnbindAction("RbxCameraGamepadReset")
	end

	for k1, v1 in pairs(tbl5) do
		v1:Disconnect()
	end

	tbl5 = {}
end

tbl4.getInputEnabled = function()
	return bool1
end

tbl4.resetInputForFrameEnd = function()
	tbl2.Movement = Vector2.new()
	tbl3.Move = Vector2.new()
	tbl3.Pinch = 0
	tbl2.Wheel = 0
	tbl2.Pan = Vector2.new()
	tbl2.Pinch = 0
end

var6.WindowFocused:Connect(resetInputDevices)
var6.WindowFocusReleased:Connect(resetInputDevices)
if var13 then
	var6.TextBoxFocusReleased:Connect(resetInputDevices)
end

tbl5 = false
tbl4.getHoldPan = function()
	return tbl5
end

num1 = false
tbl4.getTogglePan = function()
	return num1
end

tbl4.getPanning = function()
	local var1 = num1
	return var1 or tbl5
end

tbl4.setTogglePan = function(arg1)
	num1 = arg1
end

decPanInputCount = false
resetPanInputCount = nil
tbl1 = nil
incPanInputCount = 0
tbl4.enableCameraToggleInput = function()
	if decPanInputCount then
		return
	end

	decPanInputCount = true
	tbl5 = false
	num1 = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
	end

	if tbl1 then
		tbl1:Disconnect()
	end

	resetPanInputCount = var3:Connect(function()
		tbl5 = true
		incPanInputCount = tick()
	end)

	tbl1 = var5:Connect(function()
		tbl5 = false
		if tick() - incPanInputCount < 0.3 and (num1 or var6:GetMouseDelta().Magnitude < 2) then
			local var1 = not num1
			num1 = var1
		end
	end)
end

tbl4.disableCameraToggleInput = function()
	if not decPanInputCount then
		return
	end

	decPanInputCount = false
	if resetPanInputCount then
		resetPanInputCount:Disconnect()
		resetPanInputCount = nil
	end

	if tbl1 then
		tbl1:Disconnect()
		tbl1 = nil
	end
end

return tbl4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.Poppercam [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local str2 = "ZoomController"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag
local var2 = require(script.Parent:WaitForChild(str2))
var1 = var1("UserFixCameraFPError")
str1 = {}
str1.__index = str1
str2 = CFrame.new()
str1.new = function()
	return (setmetatable({ lastCFrame = nil }, str1))
end

str1.Step = function(arg1, arg2, arg3)
	local var1 = arg1.lastCFrame or arg3
	arg1.lastCFrame = arg3
	local var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13 = arg3:GetComponents()
	local var14, var15, var16, var17, var18, var19, var20, var21, var22, var23, var24, var25 = var1:GetComponents()
	local var26 = arg3.Position
	local var27 = CFrame.new(0, 0, 0, var5, var6, var7, var8, var9, var10, var11, var12, var13)
	local var28, var29 = (var27 * CFrame.new(0, 0, 0, var17, var18, var19, var20, var21, var22, var23, var24, var25):inverse()):ToAxisAngle()
	var14 = (var26 - var1.p) / arg2
	var15 = var28 * var29 / arg2
	return {
		extrapolate = function(arg1)
			local var1 = var15 * arg1
			local var3 = var1.Magnitude
			local var4 = var14 * arg1 + var26
			return (if 1e-05 < var3 then CFrame.fromAxisAngle(var1, var3) else str2) * var27 + var4
		end,
		posVelocity = var14,
		rotVelocity = var15,
	}
end

str1.Reset = function(arg1)
	arg1.lastCFrame = nil
end

local function cframeToAxis(arg1)
	local var1, var2 = arg1:ToAxisAngle()
	return var1 * var2
end

local function extractRotation(arg1)
	local var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12 = arg1:GetComponents()
	local num1 = 0
	local num2 = 0
	local num3 = 0
	local var13 = var4
	local var14 = var5
	local var15 = var6
	local var16 = var7
	local var17 = var8
	local var18 = var9
	local var19 = var10
	local var20 = var11
	local var21 = var12
	return CFrame.new(num1, num2, num3, var13, var14, var15, var16, var17, var18, var19, var20, var21)
end

extractRotation = "BaseOcclusion"
local function axisToCFrame(arg1)
	local var4 = arg1.Magnitude
	if 1e-05 < var4 then
		local var5 = arg1
		local var6 = var4
		return CFrame.fromAxisAngle(var5, var6)
	end

	return str2
end

str2 = require(script.Parent:WaitForChild(extractRotation))
cframeToAxis = setmetatable({}, str2)
cframeToAxis.__index = cframeToAxis
cframeToAxis.new = function()
	local var1 = setmetatable(str2.new(), cframeToAxis)
	var1.focusExtrapolator = str1.new()
	return var1
end

cframeToAxis.GetOcclusionMode = function(_)
	return Enum.DevCameraOcclusionMode.Zoom
end

cframeToAxis.Enable = function(arg1, _)
	arg1.focusExtrapolator:Reset()
end

cframeToAxis.Update = function(arg1, arg2, arg3, arg4, _)
	local var4 = nil
	var4 = if var1 then CFrame.lookAlong(arg4.p, -arg3.LookVector) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1) else CFrame.new(arg4.p, arg3.p) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	return var4 * CFrame.new(0, 0, (var2.Update(arg2, var4, (arg1.focusExtrapolator:Step(arg2, var4))))), arg4
end

cframeToAxis.CharacterAdded = function(_, _, _)
end

cframeToAxis.CharacterRemoving = function(_, _, _)
end

cframeToAxis.OnCameraSubjectChanged = function(_, _)
end

return cframeToAxis

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera [ModuleScript]
-- y u r i

local str1 = "BaseCamera"
local str2 = "CameraInput"
local var1 = require(script.Parent:WaitForChild(str1))
local str3 = "CameraUtils"
local var2 = require(script.Parent:WaitForChild(str2))
local str4 = "ZoomController"
require(script.Parent:WaitForChild(str4))
local var3 = require(script.Parent:WaitForChild(str3))
local str5 = "VehicleCameraCore"
local str6 = "VehicleCameraConfig"
str2 = require(script:WaitForChild(str5))
str3 = require(script:WaitForChild(str6))
local num1 = 0.016666666666666666
game:GetService("RunService").Stepped:Connect(function(_, arg2)
	num1 = arg2
end)

str4 = game:GetService("Players").LocalPlayer
local var4 = setmetatable({}, var1)
var4.__index = var4
var4.new = function()
	local var2 = setmetatable(var1.new(), var4)
	var2:Reset()
	return var2
end

str6 = var3.Spring
local tbl1 = { 0, 15, 30 }
var4.Reset = function(arg1)
	local var1 = str2.new(arg1:GetSubjectCFrame())
	arg1.vehicleCameraCore = var1
	arg1.pitchSpring = str6.new(0, -math.rad(str3.pitchBaseAngle))
	arg1.yawSpring = str6.new(0, 0)
	arg1.lastPanTick = 0
	var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var4, var5 = var3.getLooseBoundingSphere((var2:GetConnectedParts(true)))
	arg1.assemblyRadius = math.max(var5, 5)
	arg1.assemblyOffset = var2.CFrame:Inverse() * var4
	arg1.gamepadZoomLevels = {}
	for k1, v1 in tbl1, nil do
		table.insert(arg1.gamepadZoomLevels, v1 * arg1.assemblyRadius / 10)
	end

	arg1:SetCameraToSubjectDistance(arg1.gamepadZoomLevels[#arg1.gamepadZoomLevels])
end

local var5 = var3.sanitizeAngle
local var6 = var3.mapClamp
var4._StepRotation = function(arg1, arg2, arg3)
	local var1 = var2.getRotation(arg2, true)
	local var3 = arg1.yawSpring
	local var4 = var5(var3.pos + -var1.X)
	var3.pos = var4
	local var7 = arg1.pitchSpring
	var4 = var5((math.clamp(var7.pos + -var1.Y, -1.3962634015954636, 1.3962634015954636)))
	var7.pos = var4
	if var2.getRotationActivated() then
		arg1.lastPanTick = os.clock()
	end

	var4 = -math.rad(str3.pitchBaseAngle)
	local var8 = math.rad(str3.pitchDeadzoneAngle)
	if str3.autocorrectDelay < os.clock() - arg1.lastPanTick then
		local var9 = var6(arg3, str3.autocorrectMinCarSpeed, str3.autocorrectMaxCarSpeed, 0, str3.autocorrectResponse)
		var3.freq = var9
		var7.freq = var9
		if var3.freq < 0.001 then
			var3.vel = 0
		end

		if var7.freq < 0.001 then
			var7.vel = 0
		end

		if math.abs((var5(var4 - var7.pos))) <= var8 then
			var7.goal = var7.pos
		else
			var7.goal = var4
		end
	else
		var3.freq = 0
		var3.vel = 0
		var7.freq = 0
		var7.vel = 0
		var7.goal = var4
	end

	local var10 = var7:step(arg2)
	local var11 = var3:step(arg2)
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var10, var11, num1)
end

var4._GetThirdPersonLocalOffset = function(arg1)
	return arg1.assemblyOffset + Vector3.new(0, arg1.assemblyRadius * str3.verticalCenterOffset, 0)
end

var4._GetFirstPersonLocalOffset = function(arg1, arg2)
	local var3 = str4.Character
	local var4 = var3:FindFirstChild("Head")
	if var3 and (var3.Parent and (var4 and var4:IsA("BasePart"))) then
		return arg2:Inverse() * var4.Position
	end

	return arg1:_GetThirdPersonLocalOffset()
end

var4.Update = function(arg1)
	local var1 = workspace.CurrentCamera
	local var2 = var1
	assert(var1)
	var2 = var2 and var1.CameraSubject
	assert(var2)
	local str1 = "VehicleSeat"
	assert(var2:IsA(str1))
	local var3 = num1
	num1 = 0
	local var4 = arg1:GetSubjectCFrame()
	str1 = arg1:GetSubjectRotVelocity()
	local var5 = arg1:StepZoom()
	local var7 = var6(var5, 0.5, arg1.assemblyRadius, 1, 0)
	local var8 = arg1.vehicleCameraCore
	var8:setTransform(var4)
	local var9 = CFrame.new(var4 * arg1:_GetThirdPersonLocalOffset():Lerp(arg1:_GetFirstPersonLocalOffset(var4), var7)) * var8:step(var3, math.abs((var4.XVector:Dot(str1))), math.abs((var4.YVector:Dot(str1))), var7) * arg1:_StepRotation(var3, (math.abs((arg1:GetSubjectVelocity():Dot(var4.ZVector)))))
	return var9 * CFrame.new(0, 0, var5), var9
end

var4.ApplyVRTransform = function(_)
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig [ModuleScript]
-- y u r i

return {
	pitchStiffness = 0.5,
	yawStiffness = 2.5,
	autocorrectDelay = 1,
	autocorrectMinCarSpeed = 16,
	autocorrectMaxCarSpeed = 32,
	autocorrectResponse = 0.5,
	cutoffMinAngularVelYaw = 60,
	cutoffMaxAngularVelYaw = 180,
	cutoffMinAngularVelPitch = 15,
	cutoffMaxAngularVelPitch = 60,
	pitchBaseAngle = 18,
	pitchDeadzoneAngle = 12,
	firstPersonResponseMul = 10,
	yawReponseDampingRising = 1,
	yawResponseDampingFalling = 3,
	pitchReponseDampingRising = 1,
	pitchResponseDampingFalling = 3,
	verticalCenterOffset = 0.33,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore [ModuleScript]
-- y u r i

local var1 = require(script.Parent.Parent.CameraUtils)
local var2 = var1.sanitizeAngle
local var3 = require(script.Parent.VehicleCameraConfig)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1, arg2, arg3)
	return (setmetatable({ fRising = arg1, fFalling = arg2, g = arg3, p = arg3, v = arg3 * 0 }, tbl1))
end

tbl1.step = function(arg1, arg2)
	local var1 = arg1.v
	local var2 = arg1.g
	local var3 = 6.2831853071795862 * (0 < var1 and arg1.fRising or arg1.fFalling)
	local var4 = arg1.p - var2
	local var5 = math.exp(-var3 * arg2)
	local var6 = (var4 * (1 + var3 * arg2) + var1 * arg2) * var5 + var2
	arg1.p = var6
	arg1.v = (var1 * (1 - var3 * arg2) - var4 * (var3 * var3 * arg2)) * var5
	return var6
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.new = function(arg1)
	assert(typeof(arg1) == "CFrame")
	local var1, var4 = arg1:toEulerAnglesYXZ()
	local var5, var6 = arg1:toEulerAnglesYXZ()
	local tbl3 = { yawG = var2(var4), yawV = 0, pitchV = 0 }
	tbl3.yawP = var2(var6)
	tbl3.pitchG = var2((arg1:toEulerAnglesYXZ()))
	tbl3.pitchP = var2((arg1:toEulerAnglesYXZ()))
	tbl3.fSpringYaw = tbl1.new(var3.yawReponseDampingRising, var3.yawResponseDampingFalling, 0)
	tbl3.fSpringPitch = tbl1.new(var3.pitchReponseDampingRising, var3.pitchResponseDampingFalling, 0)
	return (setmetatable(tbl3, tbl2))
end

tbl2.setGoal = function(arg1, arg2)
	assert(typeof(arg2) == "CFrame")
	local var1, var3 = arg2:toEulerAnglesYXZ()
	arg1.yawG = var2(var3)
	arg1.pitchG = var2((arg2:toEulerAnglesYXZ()))
end

tbl2.getCFrame = function(arg1)
	local var1 = arg1.pitchP
	local var2 = arg1.yawP
	local num1 = 0
	return CFrame.fromEulerAnglesYXZ(var1, var2, num1)
end

local var4 = var1.mapClamp
local var5 = var1.map
tbl2.step = function(arg1, arg2, arg3, arg4, arg5)
	assert(typeof(arg2) == "number")
	assert(typeof(arg4) == "number")
	assert(typeof(arg3) == "number")
	assert(typeof(arg5) == "number")
	local var1 = arg1.fSpringYaw
	var1.g = var4(var5(arg5, 0, 1, arg4, 0), math.rad(var3.cutoffMinAngularVelYaw), math.rad(var3.cutoffMaxAngularVelYaw), 1, 0)
	local var6 = arg1.fSpringPitch
	var6.g = var4(var5(arg5, 0, 1, arg3, 0), math.rad(var3.cutoffMinAngularVelPitch), math.rad(var3.cutoffMaxAngularVelPitch), 1, 0)
	local var7 = arg1.yawG
	local var8 = 6.2831853071795862 * var3.yawStiffness * var1:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var9 = var2(arg1.yawP - var7)
	local var10 = arg1.yawV
	local var11 = math.exp(-var8 * arg2)
	local var12 = 6.2831853071795862 * var3.pitchStiffness * var6:step(arg2) * var5(arg5, 0, 1, 1, var3.firstPersonResponseMul)
	local var13 = var2((var9 * (1 + var8 * arg2) + var10 * arg2) * var11 + var7)
	arg1.yawP = var13
	arg1.yawV = (var10 * (1 - var8 * arg2) - var9 * (var8 * var8 * arg2)) * var11
	var7 = arg1.pitchG
	var9 = var2(arg1.pitchP - var7)
	var10 = arg1.pitchV
	var11 = math.exp(-var12 * arg2)
	var13 = var2((var9 * (1 + var12 * arg2) + var10 * arg2) * var11 + var7)
	arg1.pitchP = var13
	arg1.pitchV = (var10 * (1 - var12 * arg2) - var9 * (var12 * var12 * arg2)) * var11
	return arg1:getCFrame()
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.new = function(arg1)
	return (setmetatable({ vrs = tbl2.new(arg1) }, tbl3))
end

tbl3.step = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg2
	local var2 = arg3
	local var3 = arg4
	local var4 = arg5
	return arg1.vrs:step(var1, var2, var3, var4)
end

tbl3.setTransform = function(arg1, arg2)
	arg1.vrs:setGoal(arg2)
end

return tbl3

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CameraModule.CameraUI [ModuleScript]
-- y u r i

local bool1 = false
local tbl1 = {}
local var1 = game:GetService("StarterGui")
tbl1.setCameraModeToastEnabled = function(arg1)
	if not arg1 and (not bool1) then
		return
	end

	if not bool1 then
		bool1 = true
	end

	if not arg1 then
		tbl1.setCameraModeToastOpen(false)
	end
end

tbl1.setCameraModeToastOpen = function(arg1)
	assert(bool1)
	if arg1 then
		var1:SetCore("SendNotification", { Title = "Camera Control Enabled", Text = "Right click to toggle", Duration = 3 })
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
script.Parent:WaitForChild("CommonUtils")
local str1 = "Keyboard"
local str2 = "Gamepad"
local var1 = require(script:WaitForChild(str1))
local str3 = "DynamicThumbstick"
local var2 = require(script:WaitForChild(str2))
local var3 = require(script:WaitForChild(str3))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local str4 = "TouchThumbstick"
local str5 = "ClickToMoveController"
success = require(script:WaitForChild(str4))
local str6 = "TouchJump"
result = require(script:WaitForChild(str5))
local str7 = "VehicleController"
local var4 = require(script:WaitForChild(str6))
str4 = require(script:WaitForChild(str7))
local success, result = pcall(function()
	local str1 = "UserPlayerScriptsSupportMicroGamepad"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str5 = nil
str5 = success and result
local var5 = game:GetService("Players")
local var6 = game:GetService("RunService")
local var7 = game:GetService("UserInputService")
local var8 = game:GetService("GuiService")
local var9 = game:GetService("Workspace")
local var10 = UserSettings():GetService("UserGameSettings")
local var11 = game:GetService("VRService")
success = Enum.ContextActionPriority.Medium.Value
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1.controllers = {}
	var1.activeControlModule = nil
	var1.activeController = nil
	var1.touchJumpController = nil
	var1.moveFunction = var5.LocalPlayer.Move
	var1.humanoid = nil
	var1.controlsEnabled = true
	var1.humanoidSeatedConn = nil
	var1.vehicleController = nil
	var1.touchControlFrame = nil
	var1.currentTorsoAngle = 0
	var1.inputMoveVector = Vector3.new(0, 0, 0)
	var1.vehicleController = str4.new(success)
	var5.LocalPlayer.CharacterAdded:Connect(function(arg1)
		var1:OnCharacterAdded(arg1)
	end)

	var5.LocalPlayer.CharacterRemoving:Connect(function(arg1)
		var1:OnCharacterRemoving(arg1)
	end)

	if var5.LocalPlayer.Character then
		var1:OnCharacterAdded(var5.LocalPlayer.Character)
	end

	var6:BindToRenderStep("ControlScriptRenderstep", Enum.RenderPriority.Input.Value, function(arg1)
		var1:OnRenderStepped(arg1)
	end)

	var10:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var10:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var5.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = nil
	var1.touchGui = nil
	var1.playerGuiAddedConn = nil
	var8:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		var1:UpdateMovementMode()
		var1:UpdateActiveControlModuleEnabled()
	end)

	var7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		var1:UpdateMovementMode()
	end)

	var1.playerGui = var5.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not var1.playerGui then
		var1.playerGuiAddedConn = var5.LocalPlayer.ChildAdded:Connect(function(arg1)
			if arg1:IsA("PlayerGui") then
				var1.playerGui = arg1
				var1.playerGuiAddedConn:Disconnect()
				var1.playerGuiAddedConn = nil
				var1:UpdateMovementMode()
			end
		end)

	end

	var1:UpdateMovementMode()
	return var1
end

tbl1.GetMoveVector = function(arg1)
	if arg1.activeController then
		return arg1.activeController:GetMoveVector()
	end

	return Vector3.new(0, 0, 0)
end

tbl1.GetEstimatedVRTorsoFrame = function(arg1)
	local var1 = var11:GetUserCFrame(Enum.UserCFrame.Head)
	local var2, var3, var4 = var1:ToEulerAnglesYXZ()
	var3 = -var3
	if not var11:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) or (not var11:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)) then
		arg1.currentTorsoAngle = var3
	else
		local var5 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.LeftHand).Position
		local var6 = var1.Position - var11:GetUserCFrame(Enum.UserCFrame.RightHand).Position
		local var7 = -math.atan2(var5.X, var5.Z)
		local var9 = (-math.atan2(var6.X, var6.Z) - var7 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var12 = (var7 + var9 / 2 + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var12 then
			var12 = var12 - 6.2831853071795862
		end

		var9 = (var3 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var9 then
			var9 = var9 - 6.2831853071795862
		end

		local var14 = (var12 - arg1.currentTorsoAngle + 12.566370614359172) % 6.2831853071795862
		if 3.1415926535897931 < var14 then
			var14 = var14 - 6.2831853071795862
		end

		local bool1 = false
		if -1.5707963267948966 < var14 then
			bool1 = var14 < 1.5707963267948966
		end

		if not bool1 then
			var14 = var9
		end

		local var16 = math.min(var14, var9)
		local var17 = math.max(var14, var9)
		local num2 = 0
		if 0 < var16 then
			num2 = var16
		else
			if var17 < 0 then
				num2 = var17
			end
		end

		local var18 = num2 + arg1.currentTorsoAngle
		arg1.currentTorsoAngle = var18
	end

	return CFrame.new(var1.Position) * CFrame.fromEulerAnglesYXZ(0, -arg1.currentTorsoAngle, 0)
end

tbl1.GetActiveController = function(arg1)
	return arg1.activeController
end

tbl1.UpdateActiveControlModuleEnabled = function(arg1)
	local function fn2()
		if arg1.touchControlFrame then
			if var7.PreferredInput == Enum.PreferredInput.Touch then
				if arg1.activeControlModule ~= result then
					if arg1.activeControlModule == success or arg1.activeControlModule == var3 then
						if not arg1.controllers[var4] then
							arg1.controllers[var4] = var4.new()
						end

						arg1.touchJumpController = arg1.controllers[var4]
						arg1.touchJumpController:Enable(true, arg1.touchControlFrame)
					else
						if arg1.touchJumpController then
							arg1.touchJumpController:Enable(false)
						end
					end
				end
			else
				if arg1.touchJumpController then
					arg1.touchJumpController:Enable(false)
				end
			end
		else
			if arg1.touchJumpController then
				arg1.touchJumpController:Enable(false)
			end
		end

		if arg1.activeControlModule == result then
			arg1.activeController:Enable(true, var5.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, arg1.touchJumpController)
			return
		end

		if arg1.touchControlFrame then
			arg1.activeController:Enable(true, arg1.touchControlFrame)
			return
		end

		arg1.activeController:Enable(true)
	end

	if not arg1.activeController then
		return
	end

	if not arg1.controlsEnabled then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	if not var8.TouchControlsEnabled and (var7.PreferredInput == Enum.PreferredInput.Touch and (arg1.activeControlModule == result or (arg1.activeControlModule == success or arg1.activeControlModule == var3))) then
		arg1.activeController:Enable(false)
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(false)
		end

		if arg1.moveFunction then
			arg1.moveFunction(var5.LocalPlayer, Vector3.new(0, 0, 0), true)
		end

		return
	end

	fn2()
end

tbl1.Enable = function(arg1, arg2)
	arg2 = arg2 == nil and true
	if arg1.controlsEnabled == arg2 then
		return
	end

	arg1.controlsEnabled = arg2
	if not arg1.activeController then
		return
	end

	arg1:UpdateActiveControlModuleEnabled()
end

tbl1.Disable = function(arg1)
	arg1:Enable(false)
end

result = {
	[Enum.TouchMovementMode.DPad] = var3,
	[Enum.DevTouchMovementMode.DPad] = var3,
	[Enum.TouchMovementMode.Thumbpad] = var3,
	[Enum.DevTouchMovementMode.Thumbpad] = var3,
	[Enum.TouchMovementMode.Thumbstick] = success,
	[Enum.DevTouchMovementMode.Thumbstick] = success,
	[Enum.TouchMovementMode.DynamicThumbstick] = var3,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = var3,
	[Enum.TouchMovementMode.ClickToMove] = result,
	[Enum.DevTouchMovementMode.ClickToMove] = result,
	[Enum.TouchMovementMode.Default] = var3,
	[Enum.ComputerMovementMode.Default] = var1,
	[Enum.ComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.KeyboardMouse] = var1,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = result,
	[Enum.DevComputerMovementMode.ClickToMove] = result,
}

tbl1.SelectComputerMovementModule = function(_)
	if not var7.KeyboardEnabled and (not var7.GamepadEnabled) then
		return nil, false
	end

	local var4 = var5.LocalPlayer.DevComputerMovementMode
	local var6 = nil
	if var4 == Enum.DevComputerMovementMode.UserChoice then
		local bool3 = false
		if str5 then
			pcall(function()
				bool3 = var7.PreferredInput == Enum.PreferredInput.MicroGamepad
			end)

		end

		if var7.PreferredInput == Enum.PreferredInput.Gamepad or bool3 then
			var6 = var2
		else
			if var7.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				var6 = var1
			end
		end

		if var10.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove and var6 == var1 then
			var6 = result
		end
	else
		var6 = result[var4]
		if not var6 and var4 ~= Enum.DevComputerMovementMode.Scriptable then
			warn("No character control module is associated with DevComputerMovementMode ", var4)
		end
	end

	if var6 then
		return var6, true
	end

	if var4 == Enum.DevComputerMovementMode.Scriptable then
		return nil, true
	end

	return nil, false
end

tbl1.SelectTouchModule = function(_)
	local var3 = var5.LocalPlayer.DevTouchMovementMode
	local var4 = nil
	if var3 == Enum.DevTouchMovementMode.UserChoice then
		var4 = result[var10.TouchMovementMode]
	else
		if var3 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end

		var4 = result[var3]
	end

	return var4, true
end

local function getGamepadRightThumbstickPosition()
	for k1, v1 in pairs((var7:GetGamepadState(Enum.UserInputType.Gamepad1))) do
		if v1.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end

		return v1.Position
	end

	return Vector3.new(0, 0, 0)
end

tbl1.calculateRawMoveVector = function(arg1, arg2, arg3)
	local var2 = var9.CurrentCamera
	if not var2 then
		return arg3
	end

	local var5 = var2.CFrame
	if var11.VREnabled then
		if arg2.RootPart then
			var11:GetUserCFrame(Enum.UserCFrame.Head)
			local var8 = arg1:GetEstimatedVRTorsoFrame()
			var5 = if (var2.Focus.Position - var5.Position).Magnitude < 3 then var5 * var8 else var2.CFrame * (var8.Rotation + var8.Position * var2.HeadScale)
		end
	end

	if arg2:GetState() == Enum.HumanoidStateType.Swimming then
		if var11.VREnabled then
			arg3 = Vector3.new(arg3.X, 0, arg3.Z)
			if arg3.Magnitude < 0.01 then
				return Vector3.new(0, 0, 0)
			end

			local var10, var12, var13 = var5:ToEulerAnglesYXZ()
			return CFrame.fromEulerAnglesYXZ(-getGamepadRightThumbstickPosition().Y * 1.3962634015954636, math.atan2(-arg3.X, -arg3.Z) + var12, 0).LookVector
		end

		local var14 = arg3
		return var5:VectorToWorldSpace(var14)
	end

	local var29, var30, var31, var32, var33, var34, var35, var36, var37, var38, var39, var40 = var5:GetComponents()
	local var41 = nil
	local var42 = nil
	if var37 < 1 and -1 < var37 then
		var41 = var40
		var42 = var34
	else
		var41 = var32
		var42 = -var33 * math.sign(var37)
	end

	local var43 = math.sqrt(var41 * var41 + var42 * var42)
	return (Vector3.new((var41 * arg3.X + var42 * arg3.Z) / var43, 0, (var41 * arg3.Z - var42 * arg3.X) / var43))
end

tbl1.OnRenderStepped = function(arg1, arg2)
	if arg1.activeController then
		if arg1.activeController.enabled then
			if arg1.humanoid then
				local var7 = arg1:GetClickToMoveController()
				local var8 = arg1.activeController:GetMoveVector()
				local var9 = arg1.activeController:IsMoveVectorCameraRelative()
				if arg1.activeController == var7 then
					var7:OnRenderStepped(arg2)
				else
					if 0 < var8.magnitude then
						var7:CleanupPath()
					else
						var7:OnRenderStepped(arg2)
						var8 = var7:GetMoveVector()
						var9 = var7:IsMoveVectorCameraRelative()
					end
				end

				if arg1.vehicleController then
					local var10, var12 = arg1.vehicleController:Update(var8, var9, arg1.activeControlModule == var2)
					var8 = var10
				end

				if var9 then
					var8 = arg1:calculateRawMoveVector(arg1.humanoid, var8)
				end

				arg1.inputMoveVector = var8
				if var11.VREnabled then
					var8 = arg1:updateVRMoveVector(var8)
				end

				arg1.moveFunction(var5.LocalPlayer, var8, false)
				local var13 = arg1.activeController:GetIsJumping()
				var13 = var13 or arg1.touchJumpController and arg1.touchJumpController:GetIsJumping()
				arg1.humanoid.Jump = var13
			end
		end
	end
end

tbl1.updateVRMoveVector = function(arg1, arg2)
	local var1 = workspace.CurrentCamera
	local bool2 = false
	if (var1.Focus.Position - var1.CFrame.Position).Magnitude < 5 then
		bool2 = true
	end

	if arg2.Magnitude == 0 and (bool2 and (var11.AvatarGestures and (arg1.humanoid and (not arg1.humanoid.Sit)))) then
		local var4 = var11:GetUserCFrame(Enum.UserCFrame.Head)
		local var5 = (var1.CFrame * (var4.Rotation + var4.Position * var1.HeadScale) * CFrame.new(0, -0.7 * arg1.humanoid.RootPart.Size.Y / 2, 0)).Position - arg1.humanoid.RootPart.CFrame.Position
		return (Vector3.new(var5.x, 0, var5.z))
	end

	return arg2
end

tbl1.OnHumanoidSeated = function(arg1, arg2, arg3)
	if arg2 then
		if not arg3 then
			return
		end

		if not arg3:IsA("VehicleSeat") then
			return
		end

		if not arg1.vehicleController then
			local var1 = arg1.vehicleController.new(success)
			arg1.vehicleController = var1
		end

		arg1.vehicleController:Enable(true, arg3)
		return
	end

	if arg1.vehicleController then
		arg1.vehicleController:Enable(false, arg3)
	end
end

tbl1.OnCharacterAdded = function(arg1, arg2)
	arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	while not arg1.humanoid do
		arg2.ChildAdded:wait()
		arg1.humanoid = arg2:FindFirstChildOfClass("Humanoid")
	end

	if arg1.humanoidSeatedConn then
		arg1.humanoidSeatedConn:Disconnect()
		arg1.humanoidSeatedConn = nil
	end

	arg1.humanoidSeatedConn = arg1.humanoid.Seated:Connect(function(arg1, arg2)
		arg1:OnHumanoidSeated(arg1, arg2)
	end)

	arg1:UpdateMovementMode()
end

tbl1.OnCharacterRemoving = function(arg1, _)
	arg1.humanoid = nil
	arg1:UpdateMovementMode()
end

tbl1.UpdateTouchGuiVisibility = function(arg1)
	local var2 = arg1.humanoid
	if var2 then
		var2 = var8.TouchControlsEnabled
		if var2 then
			var2 = var7.PreferredInput == Enum.PreferredInput.Touch
		end
	end

	if var2 and (not arg1.touchGui) then
		arg1:CreateTouchGuiContainer()
	end

	if arg1.touchGui then
		arg1.touchGui.Enabled = not not var2
	end
end

tbl1.SwitchToController = function(arg1, arg2)
	if not arg2 then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = nil
		arg1.activeControlModule = nil
		return
	end

	if not arg1.controllers[arg2] then
		arg1.controllers[arg2] = arg2.new(success)
	end

	if arg1.activeController ~= arg1.controllers[arg2] then
		if arg1.activeController then
			arg1.activeController:Enable(false)
		end

		arg1.activeController = arg1.controllers[arg2]
		arg1.activeControlModule = arg2
		arg1:UpdateActiveControlModuleEnabled()
	end
end

tbl1.UpdateMovementMode = function(arg1)
	arg1:UpdateTouchGuiVisibility()
	if var7.PreferredInput == Enum.PreferredInput.Touch then
		local var1, var2 = arg1:SelectTouchModule()
		if not (var2 and arg1.touchControlFrame) then
			return
		end

		if not arg1.touchControlFrame then
			return
		end

		arg1:SwitchToController(var1)
		return
	end

	arg1:SwitchToController((arg1:SelectComputerMovementModule()))
end

tbl1.CreateTouchGuiContainer = function(arg1)
	if not arg1.playerGui then
		return
	end

	if arg1.touchGui then
		arg1.touchGui:Destroy()
	end

	arg1.touchGui = Instance.new("ScreenGui")
	arg1.touchGui.Name = "TouchGui"
	arg1.touchGui.ResetOnSpawn = false
	arg1.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	if str1 then
		arg1.touchGui.ClipToDeviceSafeArea = false
	end

	arg1.touchControlFrame = Instance.new("Frame")
	arg1.touchControlFrame.Name = "TouchControlFrame"
	arg1.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
	arg1.touchControlFrame.BackgroundTransparency = 1
	arg1.touchControlFrame.Parent = arg1.touchGui
	arg1.touchGui.Parent = arg1.playerGui
end

tbl1.GetClickToMoveController = function(arg1)
	if not arg1.controllers[result] then
		arg1.controllers[result] = result.new(success)
	end

	return arg1.controllers[result]
end

return tbl1.new()

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick [ModuleScript]
-- y u r i

local tbl1 = { 0.10999999999999999, 0.30000000000000004, 0.4, 0.5, 0.6, 0.7, 0.75 }
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local success, result = pcall(function()
	local str1 = "UserDynamicThumbstickSafeAreaUpdate"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

str1 = nil
str1 = success and result
local var2 = var1.getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
success = nil
local var3 = game:GetService("Players")
result = var3.LocalPlayer
local var4 = Enum.ContextActionPriority.High.Value
local var5 = #tbl1
local var6 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local var7 = game:GetService("GuiService")
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("ContextActionService")
local var10 = game:GetService("RunService")
local var11 = game:GetService("TweenService")
local var12 = var1.getUserFlag("UserAllowAbilityControlsBonus")
success = var2 and require(script.Parent:WaitForChild(str2))
if not result then
	var3:GetPropertyChangedSignal("LocalPlayer"):Wait()
	result = var3.LocalPlayer
end

local str3 = "BaseCharacterController"
local var13 = require(script.Parent:WaitForChild(str3))
local var14 = setmetatable({}, var13)
var14.__index = var14
var14.new = function()
	local var1 = setmetatable(var13.new(), var14)
	var1.moveTouchObject = nil
	var1.moveTouchLockedIn = false
	var1.moveTouchFirstChanged = false
	var1.moveTouchStartPosition = nil
	var1.startImage = nil
	var1.endImage = nil
	var1.middleImages = {}
	var1.startImageFadeTween = nil
	var1.endImageFadeTween = nil
	var1.middleImageFadeTweens = {}
	var1.isFirstTouch = true
	var1.thumbstickFrame = nil
	var1.onRenderSteppedConn = nil
	var1.fadeInAndOutBalance = 0.5
	var1.fadeInAndOutHalfDuration = 0.3
	var1.hasFadedBackgroundInPortrait = false
	var1.hasFadedBackgroundInLandscape = false
	var1.tweenInAlphaStart = nil
	var1.tweenOutAlphaStart = nil
	return var1
end

var14.GetIsJumping = function(arg1)
	local var1 = arg1.isJumping
	arg1.isJumping = false
	return var1
end

var14.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1:BindContextActions()
	else
		arg1:UnbindContextActions()
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
	arg1.thumbstickFrame.Visible = arg2
	return nil
end

var14.OnInputEnded = function(arg1)
	arg1.moveTouchObject = nil
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1:FadeThumbstick(false)
end

var14.FadeThumbstick = function(arg1, arg2)
	if not arg2 and arg1.moveTouchObject then
		return
	end

	if arg1.isFirstTouch then
		return
	end

	if arg1.startImageFadeTween then
		arg1.startImageFadeTween:Cancel()
	end

	if arg1.endImageFadeTween then
		arg1.endImageFadeTween:Cancel()
	end

	for i1 = 1, #arg1.middleImages do
		if not arg1.middleImageFadeTweens[i1] then
			continue
		end

		arg1.middleImageFadeTweens[i1]:Cancel()
	end

	if arg2 then
		arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 0 })
		arg1.startImageFadeTween:Play()
		arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 0.2 })
		arg1.endImageFadeTween:Play()
		for i2 = 1, #arg1.middleImages do
			arg1.middleImageFadeTweens[i2] = var11:Create(arg1.middleImages[i2], var6, { ImageTransparency = tbl1[i2] })
			arg1.middleImageFadeTweens[i2]:Play()
		end

		return
	end

	arg1.startImageFadeTween = var11:Create(arg1.startImage, var6, { ImageTransparency = 1 })
	arg1.startImageFadeTween:Play()
	arg1.endImageFadeTween = var11:Create(arg1.endImage, var6, { ImageTransparency = 1 })
	arg1.endImageFadeTween:Play()
	for i3 = 1, #arg1.middleImages do
		arg1.middleImageFadeTweens[i3] = var11:Create(arg1.middleImages[i3], var6, { ImageTransparency = 1 })
		arg1.middleImageFadeTweens[i3]:Play()
	end
end

var14.FadeThumbstickFrame = function(arg1, arg2, arg3)
	arg1.fadeInAndOutHalfDuration = arg2 * 0.5
	arg1.fadeInAndOutBalance = arg3
	arg1.tweenInAlphaStart = tick()
end

var14.InputInFrame = function(arg1, arg2)
	local var1 = arg1.thumbstickFrame.AbsolutePosition
	local var2 = arg2.Position
	local var4 = var1 + arg1.thumbstickFrame.AbsoluteSize
	if var1.X <= var2.X and (var1.Y <= var2.Y and (var2.X <= var4.X and var2.Y <= var4.Y)) then
		return true
	end

	return false
end

var14.DoFadeInBackground = function(arg1)
	local var2 = result:FindFirstChildOfClass("PlayerGui")
	local bool2 = false
	if var2 then
		if var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft or var2.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight then
			bool2 = arg1.hasFadedBackgroundInLandscape
			arg1.hasFadedBackgroundInLandscape = true
		else
			if var2.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait then
				bool2 = arg1.hasFadedBackgroundInPortrait
				arg1.hasFadedBackgroundInPortrait = true
			end
		end
	end

	if not bool2 then
		arg1.fadeInAndOutHalfDuration = 0.3
		arg1.fadeInAndOutBalance = 0.5
		arg1.tweenInAlphaStart = tick()
	end
end

var14.DoMove = function(arg1, arg2)
	local var1 = arg2
	if var1.Magnitude < arg1.radiusOfDeadZone then
		var1 = Vector3.new(0, 0, 0)
	else
		var1 = var1.Unit * (1 - math.max(0, (arg1.radiusOfMaxSpeed - var1.Magnitude) / arg1.radiusOfMaxSpeed))
		var1 = Vector3.new(var1.X, 0, var1.Y)
	end

	arg1.moveVector = var1
end

var14.LayoutMiddleImages = function(arg1, arg2, arg3)
	local var1 = arg3 - arg2
	local var4 = var1.Magnitude - arg1.thumbstickRingSize / 2 - arg1.middleSize
	local var6 = arg1.thumbstickSize / 2 + arg1.middleSize
	local var7 = var1.Unit
	local var8 = arg1.middleSpacing
	if arg1.middleSpacing * var5 < var4 then
		var8 = var4 / var5
	end

	for i1 = 1, var5 do
		local var10 = arg1.middleImages[i1]
		if var6 + var8 * (i1 - 2) < var4 then
			local var11 = var6 + var8 * (i1 - 1)
			local var12 = math.clamp(1 - (var11 - var4) / var8, 0, 1)
			var10.Visible = true
			local var13 = arg3 - var7 * var11
			var10.Position = UDim2.new(0, var13.X, 0, var13.Y)
			var10.Size = UDim2.new(0, arg1.middleSize * var12, 0, arg1.middleSize * var12)
		else
			var10.Visible = false
		end
	end
end

var14.MoveStick = function(arg1, arg2)
	local var1 = Vector2.new(arg2.X, arg2.Y) - arg1.thumbstickFrame.AbsolutePosition
	local var2 = Vector2.new(arg1.moveTouchStartPosition.X, arg1.moveTouchStartPosition.Y) - arg1.thumbstickFrame.AbsolutePosition
	arg1.endImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
	arg1:LayoutMiddleImages(var2, var1)
end

var14.BindContextActions = function(arg1)
	local function inputBegan(arg1)
		if arg1.moveTouchObject then
			return Enum.ContextActionResult.Pass
		end

		if not arg1:InputInFrame(arg1) then
			return Enum.ContextActionResult.Pass
		end

		if arg1.isFirstTouch then
			arg1.isFirstTouch = false
			local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
			var11:Create(arg1.startImage, var1, { Size = UDim2.new(0, 0, 0, 0) }):Play()
			local tbl1 = { Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize) }
			tbl1.ImageColor3 = Color3.new(0, 0, 0)
			var11:Create(arg1.endImage, var1, tbl1):Play()
		end

		arg1.moveTouchLockedIn = false
		arg1.moveTouchObject = arg1
		arg1.moveTouchStartPosition = arg1.Position
		arg1.moveTouchFirstChanged = true
		arg1:DoFadeInBackground()
		return Enum.ContextActionResult.Pass
	end

	var9:BindActionAtPriority("DynamicThumbstickAction", function(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Begin then
			return (inputBegan(arg3))
		end

		if arg2 == Enum.UserInputState.Change then
			if arg3 == arg1.moveTouchObject then
				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.End then
			if arg3 == arg1.moveTouchObject then
				arg1:OnInputEnded()
				if arg1.moveTouchLockedIn then
					return Enum.ContextActionResult.Sink
				end
			end

			return Enum.ContextActionResult.Pass
		end

		if arg2 == Enum.UserInputState.Cancel then
			arg1:OnInputEnded()
		end
	end, false, var4, Enum.UserInputType.Touch)

	local function inputChanged(arg1)
		if arg1 == arg1.moveTouchObject then
			if arg1.moveTouchFirstChanged then
				arg1.moveTouchFirstChanged = false
				local var1 = Vector2.new(arg1.Position.X - arg1.thumbstickFrame.AbsolutePosition.X, arg1.Position.Y - arg1.thumbstickFrame.AbsolutePosition.Y)
				arg1.startImage.Visible = true
				arg1.startImage.Position = UDim2.new(0, var1.X, 0, var1.Y)
				arg1.endImage.Visible = true
				arg1.endImage.Position = arg1.startImage.Position
				arg1:FadeThumbstick(true)
				arg1:MoveStick(arg1.Position)
			end

			arg1.moveTouchLockedIn = true
			local var2 = Vector2.new(arg1.Position.X - arg1.moveTouchStartPosition.X, arg1.Position.Y - arg1.moveTouchStartPosition.Y)
			if 0 < math.abs(var2.X) or 0 < math.abs(var2.Y) then
				arg1:DoMove(var2)
				arg1:MoveStick(arg1.Position)
			end

			return Enum.ContextActionResult.Sink
		end

		return Enum.ContextActionResult.Pass
	end

	arg1.TouchMovedCon = var8.TouchMoved:Connect(function(arg1, _)
		inputChanged(arg1)
	end)
end

var14.UnbindContextActions = function(arg1)
	var9:UnbindAction("DynamicThumbstickAction")
	if arg1.TouchMovedCon then
		arg1.TouchMovedCon:Disconnect()
	end
end

var14.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onRenderSteppedConn then
			arg1.onRenderSteppedConn:Disconnect()
			arg1.onRenderSteppedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var2 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	local var1 = if str1 then 100 else 0
	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.BorderSizePixel = 0
	arg1.thumbstickFrame.Name = "DynamicThumbstickFrame"
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	arg1.thumbstickFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	arg1.thumbstickFrame.Active = false
	arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
	arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	arg1.startImage = Instance.new("ImageLabel")
	arg1.startImage.Name = "ThumbstickStart"
	arg1.startImage.Visible = true
	arg1.startImage.BackgroundTransparency = 1
	arg1.startImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.startImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.startImage.ImageRectSize = Vector2.new(144, 144)
	arg1.startImage.ImageColor3 = Color3.new(0, 0, 0)
	arg1.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.startImage.ZIndex = 10
	arg1.startImage.Parent = arg1.thumbstickFrame
	arg1.endImage = Instance.new("ImageLabel")
	arg1.endImage.Name = "ThumbstickEnd"
	arg1.endImage.Visible = true
	arg1.endImage.BackgroundTransparency = 1
	arg1.endImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
	arg1.endImage.ImageRectOffset = Vector2.new(1, 1)
	arg1.endImage.ImageRectSize = Vector2.new(144, 144)
	arg1.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
	arg1.endImage.ZIndex = 10
	arg1.endImage.Parent = arg1.thumbstickFrame
	local function layoutThumbstickFrame(arg1)
		if arg1 then
			arg1.thumbstickFrame.Size = UDim2.new(1, var1, 0.4, var1)
			arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.6, 0)
			return
		end

		arg1.thumbstickFrame.Size = UDim2.new(0.4, var1, 0.66666666666666663, var1)
		arg1.thumbstickFrame.Position = UDim2.new(0, -var1, 0.33333333333333331, 0)
	end

	for i1 = 1, var5 do
		arg1.middleImages[i1] = Instance.new("ImageLabel")
		arg1.middleImages[i1].Name = "ThumbstickMiddle"
		arg1.middleImages[i1].Visible = false
		arg1.middleImages[i1].BackgroundTransparency = 1
		arg1.middleImages[i1].Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.middleImages[i1].ImageRectOffset = Vector2.new(1, 1)
		arg1.middleImages[i1].ImageRectSize = Vector2.new(144, 144)
		arg1.middleImages[i1].ImageTransparency = tbl1[i1]
		arg1.middleImages[i1].AnchorPoint = Vector2.new(0.5, 0.5)
		arg1.middleImages[i1].ZIndex = 9
		arg1.middleImages[i1].Parent = arg1.thumbstickFrame
	end

	local function ResizeThumbstick()
		local var3 = arg2.AbsoluteSize
		local var5 = 500 < math.min(var3.X, var3.Y)
		if var2 then
			local var7 = if var5 then 2 else 1
			if var12 and (success.isEnabled() and var5) then
				var7 = 1.6216216216216217
			end

			arg1.thumbstickSize = 45 * var7
			arg1.thumbstickRingSize = 20 * var7
			arg1.middleSize = 10 * var7
			arg1.middleSpacing = 14 * var7
			arg1.radiusOfDeadZone = 2 * var7
			arg1.radiusOfMaxSpeed = 20 * var7
			local var8 = 74 * var7
			if success.isEnabled() then
				local var9 = if var5 then 100 else 64
				arg1.startImage.Position = UDim2.new(0, var8 * 0.5 + var1 + var9, 1, -var8 * 0.5 - var1 - (if var5 then 112 else 64))
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			else
				arg1.startImage.Position = UDim2.new(0, arg1.thumbstickRingSize * 3.3 + var1, 1, -arg1.thumbstickRingSize * 2.8 - var1)
				arg1.startImage.Size = UDim2.new(0, var8, 0, var8)
			end
		elseif var5 then
			arg1.thumbstickSize = 90
			arg1.thumbstickRingSize = 40
			arg1.middleSize = 20
			arg1.middleSpacing = 28
			arg1.radiusOfDeadZone = 4
			arg1.radiusOfMaxSpeed = 40
		else
			arg1.thumbstickSize = 45
			arg1.thumbstickRingSize = 20
			arg1.middleSize = 10
			arg1.middleSpacing = 14
			arg1.radiusOfDeadZone = 2
			arg1.radiusOfMaxSpeed = 20
		end

		arg1.endImage.Position = arg1.startImage.Position
		arg1.endImage.Size = UDim2.new(0, arg1.thumbstickSize * 0.8, 0, arg1.thumbstickSize * 0.8)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var2 then
		arg1.avatarAbilitiesEnabledChangedConn = success.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	local var3 = nil
	local function onCurrentCameraChanged()
		if var3 then
			var3:Disconnect()
			var3 = nil
		end

		local var2 = workspace.CurrentCamera
		if var2 then
			var3 = var2:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				local var1 = var2.ViewportSize
				layoutThumbstickFrame(var1.X < var1.Y)
			end)

			local var4 = var2.ViewportSize
			layoutThumbstickFrame(var4.X < var4.Y)
		end
	end

	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(onCurrentCameraChanged)
	if workspace.CurrentCamera then
		onCurrentCameraChanged()
	end

	arg1.moveTouchStartPosition = nil
	arg1.startImageFadeTween = nil
	arg1.endImageFadeTween = nil
	arg1.middleImageFadeTweens = {}
	arg1.onRenderSteppedConn = var10.RenderStepped:Connect(function()
		if arg1.tweenInAlphaStart ~= nil then
			local var3 = tick() - arg1.tweenInAlphaStart
			local var4 = arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = 1 - math.min(var3 / var4, 1) * 0.35
			if var4 >= var3 then
				return
			end

			arg1.tweenOutAlphaStart = tick()
			arg1.tweenInAlphaStart = nil
			return
		end

		if arg1.tweenOutAlphaStart ~= nil then
			local var7 = tick() - arg1.tweenOutAlphaStart
			local var8 = arg1.fadeInAndOutHalfDuration * 2 - arg1.fadeInAndOutHalfDuration * 2 * arg1.fadeInAndOutBalance
			arg1.thumbstickFrame.BackgroundTransparency = math.min(var7 / var8, 1) * 0.35 + 0.65
			if var8 < var7 then
				arg1.tweenOutAlphaStart = nil
			end
		end
	end)

	arg1.onTouchEndedConn = var8.TouchEnded:connect(function(arg1)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var7.MenuOpened:connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	local var4 = result:FindFirstChildOfClass("PlayerGui")
	while not var4 do
		result.ChildAdded:wait()
		var4 = result:FindFirstChildOfClass("PlayerGui")
	end

	local var6 = nil
	local bool1 = true
	if var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.LandscapeLeft then
		bool1 = var4.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight
	end

	var4:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		if bool1 and var4.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait or not bool1 and var4.CurrentScreenOrientation ~= Enum.ScreenOrientation.Portrait then
			var6:disconnect()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
			if bool1 then
				arg1.hasFadedBackgroundInPortrait = true
				return
			end

			arg1.hasFadedBackgroundInLandscape = true
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
	if game:IsLoaded() then
		arg1.fadeInAndOutHalfDuration = 2.5
		arg1.fadeInAndOutBalance = 0.05
		arg1.tweenInAlphaStart = tick()
	else
		coroutine.wrap(function()
			game.Loaded:Wait()
			arg1.fadeInAndOutHalfDuration = 2.5
			arg1.fadeInAndOutBalance = 0.05
			arg1.tweenInAlphaStart = tick()
		end)()

	end
end

return var14

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController [ModuleScript]
-- y u r i

local success, result = pcall(function()
	local str1 = "UserExcludeNonCollidableForPathfinding"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local success, result = pcall(function()
	local str1 = "UserClickToMoveSupportAgentCanClimb2"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

game:GetService("Debris")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("PathfindingService")
local var4 = game:GetService("Players")
local var5 = game:GetService("StarterGui")
local var6 = game:GetService("Workspace")
local var7 = game:GetService("CollectionService")
local var8 = game:GetService("GuiService")
local str2 = "ClickToMoveDisplay"
local var9 = require(script.Parent:WaitForChild(str2))
local var10 = RaycastParams.new()
var10.FilterType = Enum.RaycastFilterType.Exclude
local var11 = success and result
local var12 = success and result
local bool1 = true
str1 = true
local bool2 = false
local num1 = 1
local num2 = 8
local tbl1 = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true,
	[Enum.KeyCode.Down] = true,
}

local var13 = var4.LocalPlayer
local tbl2 = {}
if not var1 then
	str2 = function(arg1)
		if arg1 then
			local var2 = arg1:FindFirstChildOfClass("Humanoid")
			if var2 then
				return arg1, var2
			end

			local var3 = arg1.Parent
			return str2(var3)
		end
	end

	tbl2.FindCharacterAncestor = str2
	local function Raycast(arg1, arg2, arg3)
		local var1 = arg3
		arg3 = var1 or {}
		local var7, var8, var9, var10 = var6:FindPartOnRayWithIgnoreList(arg1, arg3)
		if var7 then
			if arg2 then
				if var7.CanCollide == false then
					local var13
					if var7 then
						local var15 = var7:FindFirstChildOfClass("Humanoid")
						if var15 then
							local var16 = var7
							var13 = var15
						else
							local var17, var18 = str2(var7.Parent)
							local var19 = var17
							var13 = var18
						end
					else
						local var20 = nil
						var13 = nil
					end

					if var13 == nil then
						table.insert(arg3, var7)
						local var21 = arg1
						local var22 = arg2
						local var23 = arg3
						return Raycast(var21, var22, var23)
					end
				end
			end

			return var7, var8, var9, var10
		end

		return nil, nil
	end

	tbl2.Raycast = Raycast
end

str2 = {}
local var14 = nil
local var15 = nil
local var16 = nil
local var17 = nil
local function getCollidableExtentsSize(arg1)
	if arg1 == nil or arg1.PrimaryPart == nil then
		return
	end

	assert(arg1, "")
	assert(arg1.PrimaryPart, "")
	local var1 = arg1.PrimaryPart.CFrame:Inverse()
	local var2 = Vector3.new(inf, inf, inf)
	local var3 = Vector3.new(-inf, -inf, -inf)
	for k1, v1 in pairs(arg1:GetDescendants()) do
		if not v1:IsA("BasePart") then
			continue
		end

		if not v1.CanCollide then
			continue
		end

		local var4 = Vector3.new(v1.Size.X / 2, v1.Size.Y / 2, v1.Size.Z / 2)
		local var5 = Vector3.new(-var4.X, var4.Y, var4.Z)
		local var6 = var1 * v1.CFrame
		for k2, v2 in ipairs({
			Vector3.new(var4.X, var4.Y, var4.Z),
			Vector3.new(var4.X, var4.Y, -var4.Z),
			Vector3.new(var4.X, -var4.Y, var4.Z),
			Vector3.new(var4.X, -var4.Y, -var4.Z),
			var5,
			Vector3.new(-var4.X, var4.Y, -var4.Z),
			Vector3.new(-var4.X, -var4.Y, var4.Z),
			(Vector3.new(-var4.X, -var4.Y, -var4.Z)),
		}) do

			local var7 = var2
			local var8 = var6 * v2
			var2 = Vector3.new(math.min(var7.X, var8.X), math.min(var7.Y, var8.Y), (math.min(var7.Z, var8.Z)))
			var7 = var3
			var3 = Vector3.new(math.max(var7.X, var8.X), math.max(var7.Y, var8.Y), (math.max(var7.Z, var8.Z)))
		end
	end

	local var9 = var3 - var2
	if var9.X < 0 or (var9.Y < 0 or var9.Z < 0) then
		return nil
	end

	return var9
end

local var18 = nil
local var19 = nil
local var20 = nil
local function GetEquippedTool(arg1)
	if arg1 ~= nil then
		for k1, v1 in pairs(arg1:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			return v1
		end
	end
end

local function Pather(arg1, arg2, arg3)
	local var5 = nil
	local var7 = nil
	local tbl1 = {}
	if arg3 ~= nil then
		var5 = arg3
		var7 = arg3
	else
		var5 = bool2
		var7 = true
	end

	tbl1.Cancelled = false
	tbl1.Started = false
	tbl1.Finished = Instance.new("BindableEvent")
	tbl1.PathFailed = Instance.new("BindableEvent")
	tbl1.PathComputing = false
	tbl1.PathComputed = false
	tbl1.OriginalTargetPoint = arg1
	tbl1.TargetPoint = arg1
	tbl1.TargetSurfaceNormal = arg2
	tbl1.DiedConn = nil
	tbl1.SeatedConn = nil
	tbl1.BlockedConn = nil
	tbl1.TeleportedConn = nil
	tbl1.CurrentPoint = 0
	tbl1.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPosition = nil
	tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	tbl1.CurrentWaypointPlaneDistance = 0
	tbl1.CurrentWaypointNeedsJump = false
	tbl1.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	tbl1.CurrentHumanoidVelocity = 0
	tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
	tbl1.NextActionJump = false
	tbl1.Timeout = 0
	local var8 = var13
	local var14 = var8
	var14 = var14 and var8.Character
	local var16
	if var14 then
		local var19 = str2[var8]
		if var19 and var19.Parent == var14 then
			var16 = var19
		else
			str2[var8] = nil
			local var21 = var14:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var8] = var21
			end

			var16 = var21
		end
	else
		var16 = nil
	end

	tbl1.Humanoid = var16
	tbl1.OriginPoint = nil
	tbl1.AgentCanFollowPath = false
	tbl1.DirectPath = false
	tbl1.DirectPathRiseFirst = false
	tbl1.stopTraverseFunc = nil
	tbl1.setPointFunc = nil
	tbl1.pointList = nil
	var16 = tbl1.Humanoid
	var16 = var16 and tbl1.Humanoid.RootPart
	if var16 then
		tbl1.OriginPoint = var16.CFrame.Position
		local var24 = tbl1.Humanoid.SeatPart
		var8 = 2
		var14 = 5
		local bool3 = true
		if var24 then
			if var24:IsA("VehicleSeat") then
				local var27 = var24:FindFirstAncestorOfClass("Model")
				if var27 then
					local var28 = var27.PrimaryPart
					var27.PrimaryPart = var24
					if var7 then
						local var30 = var27:GetExtentsSize()
						var8 = num1 * 0.5 * math.sqrt(var30.X * var30.X + var30.Z * var30.Z)
						tbl1.AgentCanFollowPath = true
						tbl1.DirectPath = var7
						var14 = num1 * var30.Y
						bool3 = false
					end

					var27.PrimaryPart = var28
				end
			else
				local var33 = nil
				if var11 then
					local var34 = var13
					var34 = var34 and var13.Character
					if var34 ~= nil then
						var33 = getCollidableExtentsSize(var34)
					end
				end

				if var33 == nil then
					local var35 = var13
					var33 = (var35 and var13.Character):GetExtentsSize()
				end

				assert(var33, "")
				var8 = num1 * 0.5 * math.sqrt(var33.X * var33.X + var33.Z * var33.Z)
				tbl1.AgentCanFollowPath = true
				tbl1.DirectPath = var5
				tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
				var14 = num1 * var33.Y
				bool3 = 0 < tbl1.Humanoid.JumpPower
			end
		else
			local var38 = nil
			if var11 then
				local var39 = var13
				var39 = var39 and var13.Character
				if var39 ~= nil then
					var38 = getCollidableExtentsSize(var39)
				end
			end

			if var38 == nil then
				local var40 = var13
				var38 = (var40 and var13.Character):GetExtentsSize()
			end

			assert(var38, "")
			var8 = num1 * 0.5 * math.sqrt(var38.X * var38.X + var38.Z * var38.Z)
			tbl1.AgentCanFollowPath = true
			tbl1.DirectPath = var5
			tbl1.DirectPathRiseFirst = tbl1.Humanoid.Sit
			var14 = num1 * var38.Y
			bool3 = 0 < tbl1.Humanoid.JumpPower
		end

		if var12 then
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3, AgentCanClimb = true })
		else
			tbl1.pathResult = var3:CreatePath({ AgentRadius = var8, AgentHeight = var14, AgentCanJump = bool3 })
		end
	end

	tbl1.Cleanup = function(_)
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		if tbl1.BlockedConn then
			tbl1.BlockedConn:Disconnect()
			tbl1.BlockedConn = nil
		end

		if tbl1.DiedConn then
			tbl1.DiedConn:Disconnect()
			tbl1.DiedConn = nil
		end

		if tbl1.SeatedConn then
			tbl1.SeatedConn:Disconnect()
			tbl1.SeatedConn = nil
		end

		if tbl1.TeleportedConn then
			tbl1.TeleportedConn:Disconnect()
			tbl1.TeleportedConn = nil
		end

		tbl1.Started = false
	end

	tbl1.Cancel = function(_)
		tbl1.Cancelled = true
		tbl1:Cleanup()
	end

	tbl1.IsActive = function(_)
		local var1 = tbl1.AgentCanFollowPath
		return var1 and (tbl1.Started and (not tbl1.Cancelled))
	end

	tbl1.OnPathInterrupted = function(_)
		tbl1.Cancelled = true
		tbl1:OnPointReached(false)
	end

	tbl1.ComputePath = function(_)
		if tbl1.OriginPoint then
			if tbl1.PathComputed or tbl1.PathComputing then
				return
			end

			tbl1.PathComputing = true
			if tbl1.AgentCanFollowPath then
				if tbl1.DirectPath then
					local var5 = tbl1.TargetPoint
					local var6 = tbl1.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk
					local tbl2 = {
						PathWaypoint.new(tbl1.OriginPoint, Enum.PathWaypointAction.Walk),
						PathWaypoint.new(var5, var6),
					}

					tbl1.pointList = tbl2
					tbl1.PathComputed = true
				else
					tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
					tbl1.pointList = tbl1.pathResult:GetWaypoints()
					tbl1.BlockedConn = tbl1.pathResult.Blocked:Connect(function(arg1)
						tbl1:OnPathBlocked(arg1)
					end)

					tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
				end
			end

			tbl1.PathComputing = false
		end
	end

	tbl1.IsValidPath = function(_)
		tbl1:ComputePath()
		local var1 = tbl1.PathComputed
		return var1 and tbl1.AgentCanFollowPath
	end

	tbl1.Recomputing = false
	tbl1.OnPathBlocked = function(_, arg2)
		if not (tbl1.CurrentPoint <= arg2) or tbl1.Recomputing then
			return
		end

		tbl1.Recomputing = true
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
			tbl1.stopTraverseFunc = nil
		end

		tbl1.OriginPoint = tbl1.Humanoid.RootPart.CFrame.p
		tbl1.pathResult:ComputeAsync(tbl1.OriginPoint, tbl1.TargetPoint)
		tbl1.pointList = tbl1.pathResult:GetWaypoints()
		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = tbl1.pointList[1].Position - tbl1.OriginPoint
		end

		tbl1.PathComputed = tbl1.pathResult.Status == Enum.PathStatus.Success
		if bool1 then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if tbl1.PathComputed then
			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
		else
			tbl1.PathFailed:Fire()
			tbl1:Cleanup()
		end

		tbl1.Recomputing = false
	end

	tbl1.OnRenderStepped = function(_, arg2)
		if tbl1.Started and (not tbl1.Cancelled) then
			tbl1.Timeout = tbl1.Timeout + arg2
			if num2 < tbl1.Timeout then
				tbl1:OnPointReached(false)
				return
			end

			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			while tbl1.Started and tbl1:IsCurrentWaypointReached() do
				tbl1:OnPointReached(true)
			end

			if tbl1.Started then
				tbl1.NextActionMoveDirection = tbl1.CurrentWaypointPosition - tbl1.CurrentHumanoidPosition
				if 1e-06 < tbl1.NextActionMoveDirection.Magnitude then
					tbl1.NextActionMoveDirection = tbl1.NextActionMoveDirection.Unit
				else
					tbl1.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end

				if tbl1.CurrentWaypointNeedsJump then
					tbl1.NextActionJump = true
					tbl1.CurrentWaypointNeedsJump = false
					return
				end

				tbl1.NextActionJump = false
			end
		end
	end

	tbl1.IsCurrentWaypointReached = function(_)
		local bool1 = false
		if tbl1.CurrentWaypointPlaneNormal ~= Vector3.new(0, 0, 0) then
			bool1 = tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidPosition) - tbl1.CurrentWaypointPlaneDistance < math.max(1, 0.0625 * -tbl1.CurrentWaypointPlaneNormal:Dot(tbl1.CurrentHumanoidVelocity))
		else
			bool1 = true
		end

		if bool1 then
			tbl1.CurrentWaypointPosition = nil
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		return bool1
	end

	tbl1.OnPointReached = function(_, arg2)
		if arg2 then
			if not tbl1.Cancelled then
				if tbl1.setPointFunc then
					tbl1.setPointFunc(tbl1.CurrentPoint)
				end

				local var2 = tbl1.CurrentPoint + 1
				if #tbl1.pointList < var2 then
					if tbl1.stopTraverseFunc then
						tbl1.stopTraverseFunc()
					end

					tbl1.Finished:Fire()
					tbl1:Cleanup()
					return
				end

				local var4 = tbl1.Humanoid:GetState()
				local var5 = tbl1.pointList[tbl1.CurrentPoint]
				local var6 = tbl1.pointList[var2]
				local bool2 = true
				if var4 ~= Enum.HumanoidStateType.FallingDown then
					bool2 = true
					if var4 ~= Enum.HumanoidStateType.Freefall then
						bool2 = var4 == Enum.HumanoidStateType.Jumping
					end
				end

				if bool2 then
					local var10 = var6.Action == Enum.PathWaypointAction.Jump
					if not var10 then
						if 1 < tbl1.CurrentPoint then
							local var13 = var5.Position - tbl1.pointList[tbl1.CurrentPoint - 1].Position
							local var14 = var6.Position - var5.Position
							var10 = Vector2.new(var13.x, var13.z).Unit:Dot(Vector2.new(var14.x, var14.z).Unit) < 0.996
						end
					end

					if var10 then
						tbl1.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end

				tbl1:MoveToNextWayPoint(var5, var6, var2)
				return
			end
		end

		tbl1.PathFailed:Fire()
		tbl1:Cleanup()
	end

	tbl1.MoveToNextWayPoint = function(_, arg2, arg3, arg4)
		tbl1.CurrentWaypointPlaneNormal = arg2.Position - arg3.Position
		if not var12 or arg3.Label ~= "Climb" then
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(tbl1.CurrentWaypointPlaneNormal.X, 0, tbl1.CurrentWaypointPlaneNormal.Z)
		end

		if 1e-06 < tbl1.CurrentWaypointPlaneNormal.Magnitude then
			tbl1.CurrentWaypointPlaneNormal = tbl1.CurrentWaypointPlaneNormal.Unit
			tbl1.CurrentWaypointPlaneDistance = tbl1.CurrentWaypointPlaneNormal:Dot(arg3.Position)
		else
			tbl1.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			tbl1.CurrentWaypointPlaneDistance = 0
		end

		tbl1.CurrentWaypointNeedsJump = arg3.Action == Enum.PathWaypointAction.Jump
		tbl1.CurrentWaypointPosition = arg3.Position
		tbl1.CurrentPoint = arg4
		tbl1.Timeout = 0
	end

	tbl1.Start = function(_, arg2)
		if not tbl1.AgentCanFollowPath then
			tbl1.PathFailed:Fire()
			return
		end

		if tbl1.Started then
			return
		end

		tbl1.Started = true
		var9.CancelFailureAnimation()
		if bool1 and (arg2 == nil or arg2) then
			local var1, var2 = var9.CreatePathDisplay(tbl1.pointList, tbl1.OriginalTargetPoint)
			tbl1.stopTraverseFunc = var1
			tbl1.setPointFunc = var2
		end

		if 0 < (#tbl1.pointList) then
			tbl1.HumanoidOffsetFromPath = Vector3.new(0, tbl1.pointList[1].Position.Y - tbl1.OriginPoint.Y, 0)
			tbl1.CurrentHumanoidPosition = tbl1.Humanoid.RootPart.Position + tbl1.HumanoidOffsetFromPath
			tbl1.CurrentHumanoidVelocity = tbl1.Humanoid.RootPart.Velocity
			tbl1.SeatedConn = tbl1.Humanoid.Seated:Connect(function(_, _)
				tbl1:OnPathInterrupted()
			end)

			tbl1.DiedConn = tbl1.Humanoid.Died:Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.TeleportedConn = tbl1.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
				tbl1:OnPathInterrupted()
			end)

			tbl1.CurrentPoint = 1
			tbl1:OnPointReached(true)
			return
		end

		tbl1.PathFailed:Fire()
		if tbl1.stopTraverseFunc then
			tbl1.stopTraverseFunc()
		end
	end

	var8 = tbl1.TargetPoint + tbl1.TargetSurfaceNormal * 1.5
	if var1 then
		var14 = var10
		local var41
		if var17 then
			var41 = var17
		else
			var17 = {}
			assert(var17, "")
			local var42 = var13
			table.insert(var17, var42 and var13.Character)
			var41 = var17
		end

		var14.FilterDescendantsInstances = var41
		var14 = var6:Raycast(var8, Vector3.new(-0, -50, -0), var10)
		if var14 then
			tbl1.TargetPoint = var14.Position
		end
	else
		var41 = var6
		local var43 = Ray.new(var8, Vector3.new(0, -50, 0))
		local var44
		if var17 then
			var44 = var17
		else
			var17 = {}
			assert(var17, "")
			local var45 = var13
			table.insert(var17, var45 and var13.Character)
			var44 = var17
		end

		local var46, var47 = var41:FindPartOnRayWithIgnoreList(var43, var44)
		if var46 then
			tbl1.TargetPoint = var47
		end
	end

	tbl1:ComputePath()
	return tbl1
end

local function HandleMoveTo(arg1, arg2, arg3, arg4, arg5)
	if var18 then
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end

	var18 = arg1
	arg1:Start(arg5)
	var19 = arg1.Finished.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		local var2 = GetEquippedTool(arg4)
		if arg3 and var2 then
			var2:Activate()
		end
	end)

	var20 = arg1.PathFailed.Event:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end

		if arg5 ~= nil then
			if not arg5 then
				return
			end
		end

		local var1 = str1
		if var1 and (not var18:IsActive()) then
			var9.PlayFailureAnimation()
		end

		var9.DisplayFailureWaypoint(arg2)
	end)
end

function OnTap(arg1, arg2, arg3)
	local var2 = var13
	local var3 = var2
	var3 = var3 and var2.Character
	local var8 = var6.CurrentCamera
	local var11 = var13.Character
	local var12
	if var3 then
		local var15 = str2[var2]
		if var15 and var15.Parent == var3 then
			var12 = var15
		else
			str2[var2] = nil
			local var21 = var3:FindFirstChildOfClass("Humanoid")
			if var21 then
				str2[var2] = var21
			end

			var12 = var21
		end
	else
		var12 = nil
	end

	local bool1 = false
	if var12 ~= nil then
		bool1 = 0 < var12.Health
	end

	if not bool1 then
		return
	end

	if #arg1 ~= 1 then
		if arg2 then
			if not var8 then
				return
			end

			bool1 = var8:ScreenPointToRay(arg1[1].X, arg1[1].Y)
			if var1 then
				var12 = nil
				var2 = nil
				var3 = nil
				local var22
				if var17 then
					var22 = var17
				else
					var17 = {}
					assert(var17, "")
					local var23 = var13
					table.insert(var17, var23 and var13.Character)
					var22 = var17
				end

				var22 = var22 or {}
				repeat
					var10.FilterDescendantsInstances = var22
					var3 = var6:Raycast(bool1.Origin, bool1.Direction * 1000, var10)
					local bool2 = true
					if var3 then
						local var25 = var3.Instance
						if not var25.CanCollide then
							repeat
								var12 = var25:FindFirstChildOfClass("Humanoid")
								var2 = var25
								var25 = var25.Parent
							until var12 or (not var25)

							if not var12 and var25 then
								table.insert(var22, var25)
								var2 = nil
								bool2 = false
							end
						end
					end
				until bool2

				if arg3 then
					if var12 then
						if var5:GetCore("AvatarContextMenuEnabled") then
							if var4:GetPlayerFromCharacter(var12.Parent) then
								if var18 then
									var18:Cancel()
									var18 = nil
								end

								if var19 then
									var19:Disconnect()
									var19 = nil
								end

								if var20 then
									var20:Disconnect()
									var20 = nil
								end

								return
							end
						end
					end
				end

				if not var3 or (not var11) then
					return
				end

				local var27 = var3.Position
				if arg2 then
					var2 = nil
					var27 = arg2
				end

				if var18 then
					var18:Cancel()
					var18 = nil
				end

				if var19 then
					var19:Disconnect()
					var19 = nil
				end

				if var20 then
					var20:Disconnect()
					var20 = nil
				end

				local var28 = Pather(var27, var3.Normal)
				if var28:IsValidPath() then
					HandleMoveTo(var28, var27, var2, var11)
					return
				end

				var28:Cleanup()
				if var18 and var18:IsActive() then
					var18:Cancel()
				end

				if str1 then
					var9.PlayFailureAnimation()
				end

				var9.DisplayFailureWaypoint(var27)
				return
			end

			var2 = tbl2.Raycast
			var3 = Ray.new(bool1.Origin, bool1.Direction * 1000)
			var22 = true
			local var29
			if var17 then
				var29 = var17
			else
				var17 = {}
				assert(var17, "")
				local var30 = var13
				table.insert(var17, var30 and var13.Character)
				var29 = var17
			end

			local var31, var32, var33 = var2(var3, var22, var29)
			local var34, var35 = tbl2.FindCharacterAncestor(var31)
			if arg3 then
				if var35 then
					if var5:GetCore("AvatarContextMenuEnabled") then
						if var4:GetPlayerFromCharacter(var35.Parent) then
							if var18 then
								var18:Cancel()
								var18 = nil
							end

							if var19 then
								var19:Disconnect()
								var19 = nil
							end

							if var20 then
								var20:Disconnect()
								var20 = nil
							end

							return
						end
					end
				end
			end

			if arg2 then
				var32 = arg2
				var34 = nil
			end

			if not var32 then
				return
			end

			if not var11 then
				return
			end

			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var36 = Pather(var32, var33)
			if var36:IsValidPath() then
				HandleMoveTo(var36, var32, var34, var11)
				return
			end

			var36:Cleanup()
			if var18 and var18:IsActive() then
				var18:Cancel()
			end

			if str1 then
				var9.PlayFailureAnimation()
			end

			var9.DisplayFailureWaypoint(var32)
			return
		end
	end

	bool1 = GetEquippedTool(var11)
	if 2 <= (#arg1) and (var8 and bool1) then
		bool1:Activate()
	end
end

local str3 = "Keyboard"
local var21 = require(script.Parent:WaitForChild(str3))
local var22 = setmetatable({}, var21)
var22.__index = var22
var22.new = function(arg1)
	local var1 = setmetatable(var21.new(arg1), var22)
	var1.fingerTouches = {}
	var1.numUnsunkTouches = 0
	var1.mouse2DownTime = tick()
	var1.mouse2DownPos = Vector2.new()
	var1.mouse2UpTime = tick()
	var1.keyboardMoveVector = Vector3.new(0, 0, 0)
	var1.tapConn = nil
	var1.inputBeganConn = nil
	var1.inputChangedConn = nil
	var1.inputEndedConn = nil
	var1.humanoidDiedConn = nil
	var1.characterChildAddedConn = nil
	var1.onCharacterAddedConn = nil
	var1.characterChildRemovedConn = nil
	var1.renderSteppedConn = nil
	var1.menuOpenedConnection = nil
	var1.preferredInputChangedConnection = nil
	var1.running = false
	var1.wasdEnabled = false
	return var1
end

var22.DisconnectEvents = function(arg1)
	local var2 = arg1.tapConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputBeganConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputChangedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.inputEndedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.humanoidDiedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.onCharacterAddedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.renderSteppedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.characterChildRemovedConn
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.menuOpenedConnection
	if var2 then
		var2:Disconnect()
	end

	var2 = arg1.preferredInputChangedConnection
	if var2 then
		var2:Disconnect()
	end
end

var22.OnTouchBegan = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil and (not arg3) then
		local var1 = arg1.numUnsunkTouches + 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = arg3
end

var22.OnTouchChanged = function(arg1, arg2, arg3)
	if arg1.fingerTouches[arg2] == nil then
		arg1.fingerTouches[arg2] = arg3
		if not arg3 then
			local var1 = arg1.numUnsunkTouches + 1
			arg1.numUnsunkTouches = var1
		end
	end
end

var22.OnTouchEnded = function(arg1, arg2, _)
	if arg1.fingerTouches[arg2] ~= nil and arg1.fingerTouches[arg2] == false then
		local var1 = arg1.numUnsunkTouches - 1
		arg1.numUnsunkTouches = var1
	end

	arg1.fingerTouches[arg2] = nil
end

var22.OnPreferredInputChanged = function(_)
	local var3 = var13.Character
	if var3 then
		local var4 = var2.PreferredInput == Enum.PreferredInput.Touch
		for k1, v1 in pairs(var3:GetChildren()) do
			if not v1:IsA("Tool") then
				continue
			end

			v1.ManualActivationOnly = var4
		end
	end
end

var22.OnCharacterAdded = function(arg1, arg2)
	arg1:DisconnectEvents()
	arg1.inputBeganConn = var2.InputBegan:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchBegan(arg1, arg2)
		end

		if arg1.wasdEnabled then
			if arg2 == false then
				if arg1.UserInputType == Enum.UserInputType.Keyboard then
					if tbl1[arg1.KeyCode] then
						if var18 then
							var18:Cancel()
							var18 = nil
						end

						if var19 then
							var19:Disconnect()
							var19 = nil
						end

						if var20 then
							var20:Disconnect()
							var20 = nil
						end

						var9.CancelFailureAnimation()
					end
				end
			end
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2DownTime = tick()
			arg1.mouse2DownPos = arg1.Position
		end
	end)

	arg1.inputChangedConn = var2.InputChanged:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchChanged(arg1, arg2)
		end
	end)

	arg1.inputEndedConn = var2.InputEnded:Connect(function(arg1, arg2)
		if arg1.UserInputType == Enum.UserInputType.Touch then
			arg1:OnTouchEnded(arg1, arg2)
		end

		if arg1.UserInputType == Enum.UserInputType.MouseButton2 then
			arg1.mouse2UpTime = tick()
			local var2 = var18
			local var3 = arg1.Position
			if not var2 then
				var2 = arg1.keyboardMoveVector.Magnitude <= 0
			end

			if arg1.mouse2UpTime - arg1.mouse2DownTime < 0.25 and ((var3 - arg1.mouse2DownPos).magnitude < 5 and var2) then
				OnTap({ var3 })
			end
		end
	end)

	arg1.tapConn = var2.TouchTap:Connect(function(arg1, arg2)
		if not arg2 then
			OnTap(arg1, nil, true)
		end
	end)

	arg1.menuOpenedConnection = var8.MenuOpened:Connect(function()
		if var18 then
			var18:Cancel()
			var18 = nil
		end

		if var19 then
			var19:Disconnect()
			var19 = nil
		end

		if var20 then
			var20:Disconnect()
			var20 = nil
		end
	end)

	local function OnCharacterChildAdded(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = true
		end

		if arg1:IsA("Humanoid") then
			local var4 = arg1.humanoidDiedConn
			if var4 then
				var4:Disconnect()
			end

			arg1.humanoidDiedConn = arg1.Died:Connect(function()
			end)

		end
	end

	arg1.characterChildAddedConn = arg2.ChildAdded:Connect(function(arg1)
		OnCharacterChildAdded(arg1)
	end)

	arg1.characterChildRemovedConn = arg2.ChildRemoved:Connect(function(arg1)
		if var2.PreferredInput == Enum.PreferredInput.Touch and arg1:IsA("Tool") then
			arg1.ManualActivationOnly = false
		end
	end)

	for k1, v1 in pairs(arg2:GetChildren()) do
		OnCharacterChildAdded(v1)
	end

	arg1.preferredInputChangedConnection = var2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		arg1:OnPreferredInputChanged()
	end)
end

var22.Start = function(arg1)
	arg1:Enable(true)
end

var22.Stop = function(arg1)
	arg1:Enable(false)
end

var22.CleanupPath = function(_)
	if var18 then
		var18:Cancel()
		var18 = nil
	end

	if var19 then
		var19:Disconnect()
		var19 = nil
	end

	if var20 then
		var20:Disconnect()
		var20 = nil
	end
end

var22.Enable = function(arg1, arg2, arg3, arg4)
	if arg2 then
		if not arg1.running then
			if var13.Character then
				arg1:OnCharacterAdded(var13.Character)
			end

			arg1.onCharacterAddedConn = var13.CharacterAdded:Connect(function(arg1)
				arg1:OnCharacterAdded(arg1)
			end)

			arg1.running = true
		end

		arg1.touchJumpController = arg4
		if arg1.touchJumpController then
			arg1.touchJumpController:Enable(arg1.jumpEnabled)
		end
	else
		if arg1.running then
			arg1:DisconnectEvents()
			if var18 then
				var18:Cancel()
				var18 = nil
			end

			if var19 then
				var19:Disconnect()
				var19 = nil
			end

			if var20 then
				var20:Disconnect()
				var20 = nil
			end

			local var3 = var13.Character
			if var2.PreferredInput == Enum.PreferredInput.Touch and var3 then
				for k1, v1 in pairs(var3:GetChildren()) do
					if not v1:IsA("Tool") then
						continue
					end

					v1.ManualActivationOnly = false
				end
			end

			arg1.running = false
		end

		if arg1.touchJumpController and (not arg1.jumpEnabled) then
			arg1.touchJumpController:Enable(true)
		end

		arg1.touchJumpController = nil
	end

	var21.Enable(arg1, arg2)
	arg1.wasdEnabled = arg2 and arg3
	arg1.enabled = arg2
end

var22.OnRenderStepped = function(arg1, arg2)
	arg1.isJumping = false
	if var18 then
		var18:OnRenderStepped(arg2)
		if var18 then
			arg1.moveVector = var18.NextActionMoveDirection
			arg1.moveVectorIsCameraRelative = false
			if var18.NextActionJump then
				arg1.isJumping = true
			end
		else
			arg1.moveVector = arg1.keyboardMoveVector
			arg1.moveVectorIsCameraRelative = true
		end
	else
		arg1.moveVector = arg1.keyboardMoveVector
		arg1.moveVectorIsCameraRelative = true
	end

	if arg1.jumpRequested then
		arg1.isJumping = true
	end
end

var22.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.keyboardMoveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg1.wasdEnabled then
		arg1.keyboardMoveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
	end
end

var22.UpdateJump = function(_)
end

var22.SetShowPath = function(_, arg2)
	bool1 = arg2
end

var22.GetShowPath = function(_)
	return bool1
end

var22.SetWaypointTexture = function(_, arg2)
	var9.SetWaypointTexture(arg2)
end

var22.GetWaypointTexture = function(_)
	return var9.GetWaypointTexture()
end

var22.SetWaypointRadius = function(_, arg2)
	var9.SetWaypointRadius(arg2)
end

var22.GetWaypointRadius = function(_)
	return var9.GetWaypointRadius()
end

var22.SetEndWaypointTexture = function(_, arg2)
	var9.SetEndWaypointTexture(arg2)
end

var22.GetEndWaypointTexture = function(_)
	return var9.GetEndWaypointTexture()
end

var22.SetWaypointsAlwaysOnTop = function(_, arg2)
	var9.SetWaypointsAlwaysOnTop(arg2)
end

var22.GetWaypointsAlwaysOnTop = function(_)
	return var9.GetWaypointsAlwaysOnTop()
end

var22.SetFailureAnimationEnabled = function(_, arg2)
	str1 = arg2
end

var22.GetFailureAnimationEnabled = function(_)
	return str1
end

local function UpdateIgnoreTag(arg1)
	if arg1 == var14 then
		return
	end

	if var15 then
		var15:Disconnect()
		var15 = nil
	end

	if var16 then
		var16:Disconnect()
		var16 = nil
	end

	var14 = arg1
	local var1 = var13
	var17 = { var1 and var13.Character }
	if var14 ~= nil then
		for k1, v1 in ipairs((var7:GetTagged(var14))) do
			table.insert(var17, v1)
		end

		var15 = var7:GetInstanceAddedSignal(var14):Connect(function(arg1)
			table.insert(var17, arg1)
		end)

		var16 = var7:GetInstanceRemovedSignal(var14):Connect(function(arg1)
			for i1 = 1, #var17 do
				if var17[i1] ~= arg1 then
					continue
				end

				var17[i1] = var17[#var17]
				table.remove(var17)
				return
			end
		end)

	end
end

var22.SetIgnoredPartsTag = function(_, arg2)
	UpdateIgnoreTag(arg2)
end

var22.GetIgnoredPartsTag = function(_)
	return var14
end

var22.SetUseDirectPath = function(_, arg2)
	bool2 = arg2
end

var22.GetUseDirectPath = function(_)
	return bool2
end

var22.SetAgentSizeIncreaseFactor = function(_, arg2)
	num1 = arg2 / 100 + 1
end

var22.GetAgentSizeIncreaseFactor = function(_)
	return (num1 - 1) * 100
end

var22.SetUnreachableWaypointTimeout = function(_, arg2)
	num2 = arg2
end

var22.GetUnreachableWaypointTimeout = function(_)
	return num2
end

var22.SetUserJumpEnabled = function(arg1, arg2)
	arg1.jumpEnabled = arg2
	if arg1.touchJumpController then
		arg1.touchJumpController:Enable(arg2)
	end
end

var22.GetUserJumpEnabled = function(arg1)
	return arg1.jumpEnabled
end

var22.MoveTo = function(_, arg2, arg3, arg4)
	local var2 = var13.Character
	if var2 == nil then
		return false
	end

	local var4 = Pather(arg2, Vector3.new(0, 1, 0), arg4)
	if var4 and var4:IsValidPath() then
		HandleMoveTo(var4, arg2, nil, var2, arg3)
		return true
	end

	return false
end

return var22

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.PathDisplay [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
local var2 = RaycastParams.new()
var2.FilterType = Enum.RaycastFilterType.Exclude
str1 = {
	spacing = 8,
	image = "rbxasset://textures/Cursors/Gamepad/Pointer.png",
	imageSize = Vector2.new(2, 2),
}

local var3 = Instance.new("Model")
var3.Name = "PathDisplayPoints"
local var4 = Instance.new("Part")
var4.Anchored = true
var4.CanCollide = false
var4.Transparency = 1
var4.Name = "PathDisplayAdornee"
var4.CFrame = CFrame.new(0, 0, 0)
var4.Parent = var3
local num1 = 30
local tbl1 = {}
local tbl2 = {}
local tbl3 = {}
for i1 = 1, num1 do
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Archivable = false
	var5.Adornee = var4
	var5.Image = str1.image
	var5.Size = str1.imageSize
	tbl3[i1] = var5
end

str1.setCurrentPoints = function(arg1)
	if typeof(arg1) == "table" then
		tbl1 = arg1
		return
	end

	tbl1 = {}
end

str1.clearRenderedPath = function()
	for k1, v1 in ipairs(tbl2) do
		v1.Parent = nil
		local var1 = num1 + 1
		num1 = var1
		tbl3[num1] = v1
	end

	tbl2 = {}
	var3.Parent = nil
end

local function renderPoint(arg1, _)
	if num1 == 0 then
		return nil
	end

	local var5 = tbl3[1]
	local var6
	if not var5 then
		var6 = nil
	else
		tbl3[1] = tbl3[num1]
		tbl3[num1] = nil
		local var7 = num1 - 1
		num1 = var7
		var6 = var5
	end

	if var1 then
		var2.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
		var5 = workspace:Raycast(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), var2)
		if not var5 then
			return nil
		end

		var6.CFrame = CFrame.lookAlong(var5.Position, var5.Normal)
		var6.Parent = var3
		return var6
	end

	local var8, var9, var10 = workspace:FindPartOnRayWithIgnoreList(Ray.new(arg1 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0)), { game.Players.LocalPlayer.Character, workspace.CurrentCamera })
	if not var8 then
		return nil
	end

	var6.CFrame = CFrame.new(var9, var9 + var10)
	var6.Parent = var3
	return var6
end

str1.renderPath = function()
	str1.clearRenderedPath()
	if not tbl1 or #tbl1 == 0 then
		return
	end

	local var1 = #tbl1
	tbl2[1] = renderPoint(tbl1[var1], true)
	local num1 = 0
	if not tbl2[1] then
		return
	end

	while true do
		local var2 = tbl1[var1]
		local var4 = tbl1[var1 - 1]
		if var1 < 2 then
			break
		end

		local var5 = var4 - var2
		local var7 = var5.magnitude
		if var7 < num1 then
			num1 = num1 - var7
		else
			local var9 = renderPoint(var2 + var5.unit * num1, false)
			if var9 then
				tbl2[#tbl2 + 1] = var9
			end
		end

		var1 = var1 - 1
		num1 = num1 + str1.spacing
	end

	var3.Parent = workspace.CurrentCamera
end

return str1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchJump [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "ConnectionUtil"
local str2 = "CharacterUtil"
local str3 = "FlagUtil"
local var2 = require(var1:WaitForChild(str1))
local var3 = require(var1:WaitForChild(str2))
str1 = require(var1:WaitForChild(str3)).getUserFlag("UserAllowAbilityControls")
local str4 = "AvatarAbilitiesInterface"
str2 = nil
str2 = str1 and require(script.Parent:WaitForChild(str4))
local str5 = "BaseCharacterController"
local var4 = require(script.Parent:WaitForChild(str5))
local var5 = game:GetService("GuiService")
str4 = setmetatable({}, var4)
str4.__index = str4
str4.new = function()
	local var1 = setmetatable(var4.new(), str4)
	var1.parentUIFrame = nil
	var1.jumpButton = nil
	var1.externallyEnabled = false
	var1.isJumping = false
	var1._active = false
	var1._connectionUtil = var2.new()
	return var1
end

str3 = {
	"rbxasset://textures/ui/Input/JumpButtonRegular.png",
	"rbxasset://textures/ui/Input/JumpButtonPressed.png",
}

str4._reset = function(arg1)
	arg1.isJumping = false
	arg1.touchObject = nil
	if arg1.jumpButton then
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[1]
			return
		end

		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end

str4.EnableButton = function(arg1, arg2)
	if arg2 == arg1._active then
		return
	end

	if arg2 then
		if not arg1.jumpButton then
			arg1:Create()
		end

		arg1.jumpButton.Visible = true
		local function fn2(arg1)
			if arg1 == arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("JUMP_INPUT_ENDED", arg1.jumpButton.InputEnded:Connect(fn2))
		fn2 = function()
			if arg1.touchObject then
				arg1:_reset()
			end
		end

		arg1._connectionUtil:trackConnection("MENU_OPENED", var5.MenuOpened:Connect(fn2))
	else
		if arg1.jumpButton then
			arg1.jumpButton.Visible = false
		end

		arg1._connectionUtil:disconnect("JUMP_INPUT_ENDED")
		arg1._connectionUtil:disconnect("MENU_OPENED")
	end

	arg1:_reset()
	arg1._active = arg2
end

str4.UpdateEnabled = function(arg1)
	local var2 = var3.getChild("Humanoid", "Humanoid")
	if var2 and (arg1.externallyEnabled and (var2.UseJumpPower and 0 < var2.JumpPower or not var2.UseJumpPower and (0 < var2.JumpHeight and var2:GetStateEnabled(Enum.HumanoidStateType.Jumping)))) then
		arg1:EnableButton(true)
		return
	end

	arg1:EnableButton(false)
end

str4._setupConfigurations = function(arg1)
	local function update()
		arg1:UpdateEnabled()
	end

	arg1._connectionUtil:trackConnection("HUMANOID", (var3.onChild("Humanoid", "Humanoid", function(arg1)
		arg1:UpdateEnabled()
		arg1:_reset()
		local var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", arg1:GetPropertyChangedSignal("JumpPower"):Connect(var1))
		var1 = update
		arg1._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", arg1:GetPropertyChangedSignal("JumpHeight"):Connect(var1))
		var1 = function(arg1, arg2)
			if arg1 == Enum.HumanoidStateType.Jumping and arg2 ~= arg1._active then
				arg1:UpdateEnabled()
			end
		end

		arg1._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", arg1.StateEnabledChanged:Connect(var1))
	end)))
end

str4.Enable = function(arg1, arg2, arg3)
	if arg3 then
		arg1.parentUIFrame = arg3
	end

	if arg1.externallyEnabled == arg2 then
		return
	end

	arg1.externallyEnabled = arg2
	arg1:UpdateEnabled()
	if arg2 then
		arg1:_setupConfigurations()
		return
	end

	arg1._connectionUtil:disconnectAll()
end

str4.Create = function(arg1)
	if not arg1.parentUIFrame then
		return
	end

	if arg1.jumpButton then
		arg1.jumpButton:Destroy()
		arg1.jumpButton = nil
	end

	if arg1.absoluteSizeChangedConn then
		arg1.absoluteSizeChangedConn:Disconnect()
		arg1.absoluteSizeChangedConn = nil
	end

	if str1 and arg1.avatarAbilitiesEnabledChangedConn then
		arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
		arg1.avatarAbilitiesEnabledChangedConn = nil
	end

	arg1.jumpButton = Instance.new("ImageButton")
	arg1.jumpButton.Name = "JumpButton"
	arg1.jumpButton.Visible = false
	arg1.jumpButton.BackgroundTransparency = 1
	if str1 and str2.isEnabled() then
		arg1.jumpButton.Image = str3[1]
	else
		arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
		arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
	end

	local function ResizeJumpButton()
		local var2 = math.min(arg1.parentUIFrame.AbsoluteSize.x, arg1.parentUIFrame.AbsoluteSize.y) <= 500
		if str1 then
			if str2.isEnabled() then
				local var3 = if var2 then 72 else 120
				local var4 = if var2 then 64 else 100
				arg1.jumpButton.Image = str3[1]
				arg1.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				arg1.jumpButton.ImageRectSize = Vector2.new(0, 0)
				arg1.jumpButton.Size = UDim2.new(0, var3, 0, var3)
				arg1.jumpButton.Position = UDim2.new(1, -var3 - var4, 1, -var3 - (if var2 then 64 else 112))
				return
			end
		end

		local var5 = if var2 then 70 else 120
		if str1 then
			arg1.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			arg1.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			arg1.jumpButton.ImageRectSize = Vector2.new(144, 144)
		end

		arg1.jumpButton.Size = UDim2.new(0, var5, 0, var5)
		local var6 = var2 and UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 - 20) or UDim2.new(1, -(var5 * 1.5 - 10), 1, -var5 * 1.75)
		arg1.jumpButton.Position = var6
	end

	ResizeJumpButton()
	arg1.absoluteSizeChangedConn = arg1.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeJumpButton)
	if str1 then
		arg1.avatarAbilitiesEnabledChangedConn = str2.GetEnabledChangedSignal():Connect(ResizeJumpButton)
	end

	arg1.touchObject = nil
	arg1.jumpButton.InputBegan:connect(function(arg1)
		if arg1.touchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.touchObject = arg1
		if str1 and str2.isEnabled() then
			arg1.jumpButton.Image = str3[2]
		else
			arg1.jumpButton.ImageRectOffset = Vector2.new(146, 146)
		end

		arg1.isJumping = true
	end)

	arg1.jumpButton.Parent = arg1.parentUIFrame
end

return str4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick [ModuleScript]
-- y u r i

game:GetService("Players")
UserSettings():GetService("UserGameSettings")
local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls")
local str2 = "AvatarAbilitiesInterface"
local var2 = nil
var2 = var1 and require(script.Parent:WaitForChild(str2))
str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var3 = game:GetService("GuiService")
local var4 = game:GetService("UserInputService")
local var5 = setmetatable({}, str1)
var5.__index = var5
var5.new = function()
	local var1 = setmetatable(str1.new(), var5)
	var1.isFollowStick = false
	var1.thumbstickFrame = nil
	var1.moveTouchObject = nil
	var1.onTouchMovedConn = nil
	var1.onTouchEndedConn = nil
	var1.screenPos = nil
	var1.stickImage = nil
	var1.thumbstickSize = nil
	return var1
end

var5.Enable = function(arg1, arg2, arg3)
	if arg2 == nil then
		return false
	end

	arg2 = if arg2 then true else false
	if arg1.enabled == arg2 then
		return true
	end

	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		if not arg1.thumbstickFrame then
			arg1:Create(arg3)
		end

		arg1.thumbstickFrame.Visible = true
	else
		arg1.thumbstickFrame.Visible = false
		arg1:OnInputEnded()
	end

	arg1.enabled = arg2
end

var5.OnInputEnded = function(arg1)
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickFrame.Size.X.Offset / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickFrame.Size.Y.Offset / 2 - arg1.thumbstickSize / 4)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	arg1.thumbstickFrame.Position = arg1.screenPos
	arg1.moveTouchObject = nil
end

var5.Create = function(arg1, arg2)
	if arg1.thumbstickFrame then
		arg1.thumbstickFrame:Destroy()
		arg1.thumbstickFrame = nil
		if arg1.onTouchMovedConn then
			arg1.onTouchMovedConn:Disconnect()
			arg1.onTouchMovedConn = nil
		end

		if arg1.onTouchEndedConn then
			arg1.onTouchEndedConn:Disconnect()
			arg1.onTouchEndedConn = nil
		end

		if arg1.absoluteSizeChangedConn then
			arg1.absoluteSizeChangedConn:Disconnect()
			arg1.absoluteSizeChangedConn = nil
		end

		if var1 and arg1.avatarAbilitiesEnabledChangedConn then
			arg1.avatarAbilitiesEnabledChangedConn:Disconnect()
			arg1.avatarAbilitiesEnabledChangedConn = nil
		end
	end

	arg1.thumbstickFrame = Instance.new("Frame")
	arg1.thumbstickFrame.Name = "ThumbstickFrame"
	arg1.thumbstickFrame.Active = true
	arg1.thumbstickFrame.Visible = false
	arg1.thumbstickFrame.BackgroundTransparency = 1
	local var5 = Instance.new("ImageLabel")
	var5.Name = "OuterImage"
	var5.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	var5.ImageRectOffset = Vector2.new()
	var5.ImageRectSize = Vector2.new(220, 220)
	var5.BackgroundTransparency = 1
	var5.Position = UDim2.new(0, 0, 0, 0)
	arg1.stickImage = Instance.new("ImageLabel")
	arg1.stickImage.Name = "StickImage"
	arg1.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	arg1.stickImage.ImageRectOffset = Vector2.new(220, 0)
	arg1.stickImage.ImageRectSize = Vector2.new(111, 111)
	arg1.stickImage.BackgroundTransparency = 1
	arg1.stickImage.ZIndex = 2
	local function ResizeThumbstick()
		local var4 = math.min(arg2.AbsoluteSize.X, arg2.AbsoluteSize.Y) <= 500
		if var1 then
			if var2.isEnabled() then
				local var6 = if var4 then 64 else 100
				local var7 = if var4 then 64 else 112
				local var8 = arg1
				var8.thumbstickSize = if var4 then 72 else 120
				arg1.screenPos = UDim2.new(0, var6, 1, -arg1.thumbstickSize - var7)
			else
				local var9 = arg1
				var9.thumbstickSize = if var4 then 70 else 120
				local var10 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
				arg1.screenPos = var10
			end
		else
			local var11 = arg1
			var11.thumbstickSize = if var4 then 70 else 120
			local var12 = var4 and UDim2.new(0, arg1.thumbstickSize / 2 - 10, 1, -arg1.thumbstickSize - 20) or UDim2.new(0, arg1.thumbstickSize / 2, 1, -arg1.thumbstickSize * 1.75)
			arg1.screenPos = var12
		end

		arg1.thumbstickFrame.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.thumbstickFrame.Position = arg1.screenPos
		var5.Size = UDim2.new(0, arg1.thumbstickSize, 0, arg1.thumbstickSize)
		arg1.stickImage.Size = UDim2.new(0, arg1.thumbstickSize / 2, 0, arg1.thumbstickSize / 2)
		arg1.stickImage.Position = UDim2.new(0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4, 0, arg1.thumbstickSize / 2 - arg1.thumbstickSize / 4)
	end

	ResizeThumbstick()
	arg1.absoluteSizeChangedConn = arg2:GetPropertyChangedSignal("AbsoluteSize"):Connect(ResizeThumbstick)
	if var1 then
		arg1.avatarAbilitiesEnabledChangedConn = var2.GetEnabledChangedSignal():Connect(ResizeThumbstick)
	end

	var5.Parent = arg1.thumbstickFrame
	arg1.stickImage.Parent = arg1.thumbstickFrame
	local var6 = nil
	arg1.thumbstickFrame.InputBegan:Connect(function(arg1)
		if arg1.moveTouchObject or (arg1.UserInputType ~= Enum.UserInputType.Touch or arg1.UserInputState ~= Enum.UserInputState.Begin) then
			return
		end

		arg1.moveTouchObject = arg1
		arg1.thumbstickFrame.Position = UDim2.new(0, arg1.Position.X - arg1.thumbstickFrame.Size.X.Offset / 2, 0, arg1.Position.Y - arg1.thumbstickFrame.Size.Y.Offset / 2)
		var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
		Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y)
	end)

	local function MoveStick(arg1)
		local var1 = Vector2.new(arg1.X - var6.X, arg1.Y - var6.Y)
		local var5 = arg1.thumbstickFrame.AbsoluteSize.X / 2
		local var7 = var1.magnitude
		if arg1.isFollowStick and var5 < var7 then
			local var8 = var1.unit * var5
			arg1.thumbstickFrame.Position = UDim2.new(0, arg1.X - arg1.thumbstickFrame.AbsoluteSize.X / 2 - var8.X, 0, arg1.Y - arg1.thumbstickFrame.AbsoluteSize.Y / 2 - var8.Y)
		else
			var1 = var1.unit * math.min(var7, var5)
		end

		arg1.stickImage.Position = UDim2.new(0, var1.X + arg1.stickImage.AbsoluteSize.X / 2, 0, var1.Y + arg1.stickImage.AbsoluteSize.Y / 2)
	end

	arg1.onTouchMovedConn = var4.TouchMoved:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			var6 = Vector2.new(arg1.thumbstickFrame.AbsolutePosition.X + arg1.thumbstickFrame.AbsoluteSize.X / 2, arg1.thumbstickFrame.AbsolutePosition.Y + arg1.thumbstickFrame.AbsoluteSize.Y / 2)
			local var1 = Vector2.new(arg1.Position.X - var6.X, arg1.Position.Y - var6.Y) / (arg1.thumbstickSize / 2)
			local var3 = var1.magnitude
			if var3 < 0.05 then
				var1 = Vector3.new()
			else
				var1 = var1.unit * math.min(1, (var3 - 0.05) / 0.95)
				var1 = Vector3.new(var1.X, 0, var1.Y)
			end

			arg1.moveVector = var1
			MoveStick(arg1.Position)
		end
	end)

	arg1.onTouchEndedConn = var4.TouchEnded:Connect(function(arg1, _)
		if arg1 == arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	var3.MenuOpened:Connect(function()
		if arg1.moveTouchObject then
			arg1:OnInputEnded()
		end
	end)

	arg1.thumbstickFrame.Parent = arg2
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Keyboard [ModuleScript]
-- y u r i

script.Parent.Parent:WaitForChild("CommonUtils")
local str1 = "BaseCharacterController"
local var1 = require(script.Parent:WaitForChild(str1))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = Vector3.new()
local var5 = setmetatable({}, var1)
var5.__index = var5
var5.new = function(arg1)
	local var2 = setmetatable(var1.new(), var5)
	var2.CONTROL_ACTION_PRIORITY = arg1
	var2.forwardValue = 0
	var2.backwardValue = 0
	var2.leftValue = 0
	var2.rightValue = 0
	var2.jumpEnabled = true
	return var2
end

var5.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.moveVector = var4
	arg1.jumpRequested = false
	arg1:UpdateJump()
	if arg2 then
		arg1:BindContextActions()
		arg1:ConnectFocusEventListeners()
	else
		arg1._connectionUtil:disconnectAll()
	end

	arg1.enabled = arg2
	return true
end

var5.UpdateMovement = function(arg1, arg2)
	if arg2 == Enum.UserInputState.Cancel then
		arg1.moveVector = var4
		return
	end

	arg1.moveVector = Vector3.new(arg1.leftValue + arg1.rightValue, 0, arg1.forwardValue + arg1.backwardValue)
end

var5.UpdateJump = function(arg1)
	arg1.isJumping = arg1.jumpRequested
end

var5.BindContextActions = function(arg1)
	var3:BindActionAtPriority("moveForwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.forwardValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterForward)

	var3:BindActionAtPriority("moveBackwardAction", function(_, arg2, _)
		local var1 = arg1
		var1.backwardValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterBackward)

	var3:BindActionAtPriority("moveLeftAction", function(_, arg2, _)
		local var1 = arg1
		var1.leftValue = if arg2 == Enum.UserInputState.Begin then -1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterLeft)

	var3:BindActionAtPriority("moveRightAction", function(_, arg2, _)
		local var1 = arg1
		var1.rightValue = if arg2 == Enum.UserInputState.Begin then 1 else 0
		arg1:UpdateMovement(arg2)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterRight)

	var3:BindActionAtPriority("jumpAction", function(_, arg2, _)
		local var2 = arg1.jumpEnabled
		local var3 = arg1
		if var2 then
			var2 = arg2 == Enum.UserInputState.Begin
		end

		var3.jumpRequested = var2
		arg1:UpdateJump()
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.PlayerActions.CharacterJump)

	arg1._connectionUtil:trackBoundFunction("moveForwardAction", function()
		var3:UnbindAction("moveForwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveBackwardAction", function()
		var3:UnbindAction("moveBackwardAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveLeftAction", function()
		var3:UnbindAction("moveLeftAction")
	end)

	arg1._connectionUtil:trackBoundFunction("moveRightAction", function()
		var3:UnbindAction("moveRightAction")
	end)

	arg1._connectionUtil:trackBoundFunction("jumpAction", function()
		var3:UnbindAction("jumpAction")
	end)
end

var5.ConnectFocusEventListeners = function(arg1)
	local function onFocusReleased()
		arg1.moveVector = var4
		arg1.forwardValue = 0
		arg1.backwardValue = 0
		arg1.leftValue = 0
		arg1.rightValue = 0
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	local var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("textBoxFocusReleased", var2.TextBoxFocusReleased:Connect(var1))
	var1 = function(_)
		arg1.jumpRequested = false
		arg1:UpdateJump()
	end

	arg1._connectionUtil:trackConnection("textBoxFocused", var2.TextBoxFocused:Connect(var1))
	var1 = onFocusReleased
	arg1._connectionUtil:trackConnection("windowFocusReleased", var2.WindowFocused:Connect(var1))
end

return var5

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay [ModuleScript]
-- y u r i

local var1 = UDim2.new(0, 42, 0, 50)
local var2 = Vector2.new(0, 0.5)
local var3 = Vector2.new(0, 1)
local var4 = Vector2.new(0, 0.5)
local var5 = Vector2.new(0.1, 0.5)
local var6 = Vector2.new(-0.1, 0.5)
local var7 = Vector2.new(1.5, 1.5)
local var8 = RaycastParams.new()
var8.FilterType = Enum.RaycastFilterType.Exclude
local str1 = "FlagUtil"
local bool1 = false
local str2 = "rbxasset://textures/ui/traildot.png"
local str3 = "rbxasset://textures/ui/waypoint.png"
local var9 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserRaycastUpdateAPI2")
str1 = function()
	local var3 = Instance.new("Part")
	var3.Size = Vector3.new(1, 1, 1)
	var3.Anchored = true
	var3.CanCollide = false
	var3.Name = "TrailDot"
	var3.Transparency = 1
	local var5 = Instance.new("ImageHandleAdornment")
	var5.Name = "TrailDotImage"
	var5.Size = var7
	var5.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var5.AlwaysOnTop = bool1
	var5.Image = str2
	var5.Adornee = var3
	var5.Parent = var3
	local var6 = Instance.new("Part")
	var6.Size = Vector3.new(2, 2, 2)
	var6.Anchored = true
	var6.CanCollide = false
	var6.Name = "EndWaypoint"
	var6.Transparency = 1
	local var8 = Instance.new("ImageHandleAdornment")
	var8.Name = "TrailDotImage"
	var8.Size = var7
	var8.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var8.AlwaysOnTop = bool1
	var8.Image = str2
	var8.Adornee = var6
	var8.Parent = var6
	local var9 = Instance.new("BillboardGui")
	var9.Name = "EndWaypointBillboard"
	var9.Size = var1
	var9.LightInfluence = 0
	var9.SizeOffset = var2
	var9.AlwaysOnTop = true
	var9.Adornee = var6
	var9.Parent = var6
	local var10 = Instance.new("ImageLabel")
	var10.Image = str3
	var10.BackgroundTransparency = 1
	var10.Size = UDim2.new(1, 0, 1, 0)
	var10.Parent = var9
	local var11 = Instance.new("Part")
	var11.Size = Vector3.new(2, 2, 2)
	var11.Anchored = true
	var11.CanCollide = false
	var11.Name = "FailureWaypoint"
	var11.Transparency = 1
	local var12 = Instance.new("ImageHandleAdornment")
	var12.Name = "TrailDotImage"
	var12.Size = var7
	var12.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	var12.AlwaysOnTop = bool1
	var12.Image = str2
	var12.Adornee = var11
	var12.Parent = var11
	local var13 = Instance.new("BillboardGui")
	var13.Name = "FailureWaypointBillboard"
	var13.Size = var1
	var13.LightInfluence = 0
	var13.SizeOffset = var4
	var13.AlwaysOnTop = true
	var13.Adornee = var11
	var13.Parent = var11
	local var14 = Instance.new("Frame")
	var14.BackgroundTransparency = 1
	var14.Size = UDim2.new(0, 0, 0, 0)
	var14.Position = UDim2.new(0.5, 0, 1, 0)
	var14.Parent = var13
	local var15 = Instance.new("ImageLabel")
	var15.Image = str3
	var15.BackgroundTransparency = 1
	var15.Position = UDim2.new(0, -var1.X.Offset / 2, 0, -var1.Y.Offset)
	var15.Size = var1
	var15.Parent = var14
	return var3, var6, var11
end

local var10 = game:GetService("Workspace")
local var11 = game:GetService("Players").LocalPlayer
local var12 = game:GetService("TweenService")
local var13 = game:GetService("RunService")
local var14, var15, var16 = str1()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

local function placePathWaypoint(arg1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var2 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if not var2 then
			return
		end

		arg1.CFrame = CFrame.lookAlong(var2.Position, var2.Normal)
		local var3 = var10.CurrentCamera
		local var5 = var3:FindFirstChild("ClickToMoveDisplay")
		if not var5 then
			var5 = Instance.new("Model")
			var5.Name = "ClickToMoveDisplay"
			var5.Parent = var3
		end

		arg1.Parent = var5
		return
	end

	local var12, var13, var14 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var12 then
		arg1.CFrame = CFrame.new(var13, var13 + var14)
		local var15 = var10.CurrentCamera
		local var17 = var15:FindFirstChild("ClickToMoveDisplay")
		if not var17 then
			var17 = Instance.new("Model")
			var17.Name = "ClickToMoveDisplay"
			var17.Parent = var15
		end

		arg1.Parent = var17
	end
end

tbl1.NewDisplayModel = function(_, arg2)
	local var1 = var14:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({}, tbl1)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.ClosestWayPoint = arg2
	return var1
end

local tbl2 = {}
tbl2.__index = tbl2
tbl2.Destroy = function(arg1)
	arg1.Destroyed = true
	arg1.Tween:Cancel()
	arg1.DisplayModel:Destroy()
end

tbl2.NewDisplayModel = function(_, arg2)
	local var1 = var15:Clone()
	placePathWaypoint(var1, arg2)
	return var1
end

tbl2.CreateTween = function(arg1)
	local var1 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, -1, true)
	local var2 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, var1, { SizeOffset = var3 })
	var2:Play()
	return var2
end

tbl2.TweenInFrom = function(arg1, arg2)
	arg1.DisplayModel.EndWaypointBillboard.StudsOffset = Vector3.new(0, (arg2 - arg1.DisplayModel.Position).Y, 0)
	local var1 = var12:Create(arg1.DisplayModel.EndWaypointBillboard, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), { StudsOffset = Vector3.new(0, 0, 0) })
	var1:Play()
	return var1
end

tbl2.new = function(arg1, arg2, arg3)
	local var1 = setmetatable({}, tbl2)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	var1.Destroyed = false
	if arg3 and 5 < (arg3 - arg1).Magnitude then
		var2 = var1:TweenInFrom(arg3)
		var1.Tween = var2
		coroutine.wrap(function()
			var1.Tween.Completed:Wait()
			if not var1.Destroyed then
				var1.Tween = var1:CreateTween()
			end
		end)()

	else
		var2 = var1:CreateTween()
		var1.Tween = var2
	end

	var1.ClosestWayPoint = arg2
	return var1
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.Hide = function(arg1)
	arg1.DisplayModel.Parent = nil
end

tbl3.Destroy = function(arg1)
	arg1.DisplayModel:Destroy()
end

tbl3.NewDisplayModel = function(_, arg2)
	local var1 = var16:Clone()
	placePathWaypoint(var1, arg2)
	if var9 then
		var8.FilterDescendantsInstances = { var10.CurrentCamera, var11.Character }
		local var3 = var10:Raycast(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), var8)
		if var3 then
			var1.CFrame = CFrame.lookAlong(var3.Position, var3.Normal)
			local var4 = var10.CurrentCamera
			local var6 = var4:FindFirstChild("ClickToMoveDisplay")
			if not var6 then
				var6 = Instance.new("Model")
				var6.Name = "ClickToMoveDisplay"
				var6.Parent = var4
			end

			var1.Parent = var6
			return var1
		end
	end

	local var13, var14, var15 = var10:FindPartOnRayWithIgnoreList(Ray.new(arg2 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { var10.CurrentCamera, var11.Character })
	if var13 then
		var1.CFrame = CFrame.new(var14, var14 + var15)
		local var17 = var10.CurrentCamera
		local var19 = var17:FindFirstChild("ClickToMoveDisplay")
		if not var19 then
			var19 = Instance.new("Model")
			var19.Name = "ClickToMoveDisplay"
			var19.Parent = var17
		end

		var1.Parent = var19
	end

	return var1
end

tbl3.RunFailureTween = function(arg1)
	wait(0.125)
	local var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local var2 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var5 })
	var2:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 10 }):Play()
	var2.Completed:wait()
	local var3 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	local var7 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var3, { SizeOffset = var6 })
	var7:Play()
	var1 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame.ImageLabel, var1, { ImageColor3 = Color3.new(0.75, 0.75, 0.75) }):Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = -10 }):Play()
	var7.Completed:wait()
	var1 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	var3 = var12:Create(arg1.DisplayModel.FailureWaypointBillboard, var1, { SizeOffset = var4 })
	var3:Play()
	var12:Create(arg1.DisplayModel.FailureWaypointBillboard.Frame, var1, { Rotation = 0 }):Play()
	var3.Completed:wait()
	wait(0.125)
end

tbl3.new = function(arg1)
	local var1 = setmetatable({}, tbl3)
	local var2 = var1:NewDisplayModel(arg1)
	var1.DisplayModel = var2
	return var1
end

local var17 = Instance.new("Animation")
var17.AnimationId = "rbxassetid://2874840706"
local var18 = nil
local num1 = 0
local function createTrailDots(arg1, arg2)
	local tbl3 = {}
	local num1 = 1
	for i1 = 1, #arg1 - 1 do
		local var1 = (arg1[i1].Position - arg1[#arg1].Position).Magnitude < 3
		local bool2 = false
		if i1 % 2 == 0 then
			bool2 = not var1
		end

		if not bool2 then
			continue
		end

		tbl3[num1] = tbl1.new(arg1[i1].Position, i1)
		num1 = num1 + 1
	end

	table.insert(tbl3, (tbl2.new(arg1[#arg1].Position, #arg1, arg2)))
	num1 = 1
	local tbl4 = {}
	for i2 = #tbl3, 1, -1 do
		tbl4[num1] = tbl3[i2]
		num1 = num1 + 1
	end

	return tbl4
end

local var19 = nil
return {
	CreatePathDisplay = function(arg1, arg2)
		local var1 = num1 + 1
		num1 = var1
		var1 = createTrailDots(arg1, arg2)
		local var2 = "ClickToMoveResizeTrail" .. num1
		var13:BindToRenderStep(var2, Enum.RenderPriority.Camera.Value - 1, function()
			if #var1 == 0 then
				var13:UnbindFromRenderStep(var2)
				return
			end

			local var3 = var10.CurrentCamera.CFrame.p
			for i1 = 1, #var1 do
				local var4 = var1[i1].DisplayModel:FindFirstChild("TrailDotImage")
				if not var4 then
					continue
				end

				var4.Size = var7 * (math.clamp((var1[i1].DisplayModel.Position - var3).Magnitude - 10, 0, 90) / 90 * 1.5 + 1)
			end
		end)

		local function removePathBeforePoint(arg1)
			for i1 = #var1, 1, -1 do
				local var2 = var1[i1]
				if var2.ClosestWayPoint > arg1 then
					break
				end

				var2:Destroy()
				var1[i1] = nil
				continue
			end
		end

		return function()
			removePathBeforePoint(#arg1)
		end, removePathBeforePoint
	end,
	DisplayFailureWaypoint = function(arg1)
		if var19 then
			var19:Hide()
		end

		local var1 = tbl3.new(arg1)
		var19 = var1
		coroutine.wrap(function()
			var1:RunFailureTween()
			var1:Destroy()
			var1 = nil
		end)()
	end,
	CreateEndWaypoint = function(arg1)
		local var1 = arg1
		return tbl2.new(var1)
	end,
	PlayFailureAnimation = function()
		local var2 = var11.Character
		local var4 = if var2 then var2:FindFirstChildOfClass("Humanoid") else nil
		if var4 then
			if var4 == nil then
				var2 = var18
			else
				var18 = var4:LoadAnimation(var17)
				assert(var18, "")
				var18.Priority = Enum.AnimationPriority.Action
				var18.Looped = false
				var2 = var18
			end

			var2:Play()
		end
	end,
	CancelFailureAnimation = function()
		if var18 ~= nil and var18.IsPlaying then
			var18:Stop()
		end
	end,
	SetWaypointTexture = function(arg1)
		str2 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointTexture = function()
		return str2
	end,
	SetWaypointRadius = function(arg1)
		var7 = Vector2.new(arg1, arg1)
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointRadius = function()
		return var7.X
	end,
	SetEndWaypointTexture = function(arg1)
		str3 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetEndWaypointTexture = function()
		return str3
	end,
	SetWaypointsAlwaysOnTop = function(arg1)
		bool1 = arg1
		local var1, var2, var3 = str1()
		var14 = var1
		var15 = var2
		var16 = var3
	end,
	GetWaypointsAlwaysOnTop = function()
		return bool1
	end,
}

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VehicleController [ModuleScript]
-- y u r i

local var1 = game:GetService("ContextActionService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function(arg1)
	local var1 = setmetatable({}, tbl1)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.enabled = false
	var1.vehicleSeat = nil
	var1.throttle = 0
	var1.steer = 0
	var1.acceleration = 0
	var1.decceleration = 0
	var1.turningRight = 0
	var1.turningLeft = 0
	var1.vehicleMoveVector = Vector3.new(0, 0, 0)
	var1.autoPilot = {}
	var1.autoPilot.MaxSpeed = 0
	var1.autoPilot.MaxSteeringAngle = 0
	return var1
end

tbl1.BindContextActions = function(arg1)
	var1:BindActionAtPriority("throttleAccel", function(arg1, arg2, arg3)
		arg1:OnThrottleAccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonR2)

	var1:BindActionAtPriority("throttleDeccel", function(arg1, arg2, arg3)
		arg1:OnThrottleDeccel(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonL2)

	var1:BindActionAtPriority("arrowSteerRight", function(arg1, arg2, arg3)
		arg1:OnSteerRight(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Right)

	var1:BindActionAtPriority("arrowSteerLeft", function(arg1, arg2, arg3)
		arg1:OnSteerLeft(arg1, arg2, arg3)
		return Enum.ContextActionResult.Pass
	end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Left)
end

tbl1.Enable = function(arg1, arg2, arg3)
	if arg2 == arg1.enabled and arg3 == arg1.vehicleSeat then
		return
	end

	arg1.enabled = arg2
	arg1.vehicleMoveVector = Vector3.new(0, 0, 0)
	if arg2 then
		if not arg3 then
			return
		end

		arg1.vehicleSeat = arg3
		arg1:SetupAutoPilot()
		arg1:BindContextActions()
		return
	end

	var1:UnbindAction("throttleAccel")
	var1:UnbindAction("throttleDeccel")
	var1:UnbindAction("arrowSteerRight")
	var1:UnbindAction("arrowSteerLeft")
	arg1.vehicleSeat = nil
end

tbl1.OnThrottleAccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.acceleration = 0
	else
		arg1.acceleration = -1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnThrottleDeccel = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.decceleration = 0
	else
		arg1.decceleration = 1
	end

	arg1.throttle = arg1.acceleration + arg1.decceleration
end

tbl1.OnSteerRight = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningRight = 0
	else
		arg1.turningRight = 1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.OnSteerLeft = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.End or arg3 == Enum.UserInputState.Cancel then
		arg1.turningLeft = 0
	else
		arg1.turningLeft = -1
	end

	arg1.steer = arg1.turningRight + arg1.turningLeft
end

tbl1.Update = function(arg1, arg2, arg3, arg4)
	if arg1.vehicleSeat then
		if arg3 then
			arg2 = arg2 + Vector3.new(arg1.steer, 0, arg1.throttle)
	if not arg4 then
				arg1.vehicleSeat.ThrottleFloat = -arg2.Z
			end

			arg1.vehicleSeat.SteerFloat = arg2.X
			return arg2, true
		end

		local var1 = arg1.vehicleSeat.Occupant.RootPart.CFrame:VectorToObjectSpace(arg2)
		arg1.vehicleSeat.ThrottleFloat = arg1:ComputeThrottle(var1)
		arg1.vehicleSeat.SteerFloat = arg1:ComputeSteer(var1)
		return Vector3.new(0, 0, 0), true
	end

	return arg2, false
end

tbl1.ComputeThrottle = function(_, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -arg2.Z
	end

	return 0
end

tbl1.ComputeSteer = function(arg1, arg2)
	if arg2 ~= Vector3.new(0, 0, 0) then
		return -math.atan2(-arg2.x, -arg2.z) * 57.295779513082323 / arg1.autoPilot.MaxSteeringAngle
	end

	return 0
end

tbl1.SetupAutoPilot = function(arg1)
	arg1.autoPilot.MaxSpeed = arg1.vehicleSeat.MaxSpeed
	arg1.autoPilot.MaxSteeringAngle = 35
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = Vector3.new()
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var3 = setmetatable({}, tbl1)
	var3.enabled = false
	var3.moveVector = var2
	var3.moveVectorIsCameraRelative = true
	var3.isJumping = false
	var3._connectionUtil = var1.new()
	return var3
end

tbl1.GetMoveVector = function(arg1)
	return arg1.moveVector
end

tbl1.IsMoveVectorCameraRelative = function(arg1)
	return arg1.moveVectorIsCameraRelative
end

tbl1.GetIsJumping = function(arg1)
	return arg1.isJumping
end

tbl1.Enable = function(_, _)
	error("BaseCharacterController:Enable must be overridden in derived classes and should not be called.")
	return false
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.Gamepad [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local str2 = "BaseCharacterController"
str1 = require(script.Parent:WaitForChild(str2))
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("ContextActionService")
local var4 = setmetatable({}, str1)
var4.__index = var4
local var5 = Enum.UserInputType.None
var4.new = function(arg1)
	local var1 = setmetatable(str1.new(), var4)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.forwardValue = 0
	var1.backwardValue = 0
	var1.leftValue = 0
	var1.rightValue = 0
	var1.thumbstickVector = Vector3.new(0, 0, 0)
	var1.activeGamepad = var5
	var1.gamepadConnectedConn = nil
	var1.gamepadDisconnectedConn = nil
	return var1
end

var4.Enable = function(arg1, arg2)
	if arg2 == arg1.enabled then
		return true
	end

	arg1.forwardValue = 0
	arg1.backwardValue = 0
	arg1.leftValue = 0
	arg1.rightValue = 0
	arg1.thumbstickVector = Vector3.new(0, 0, 0)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		local var1 = arg1:GetHighestPriorityGamepad()
		arg1.activeGamepad = var1
		if arg1.activeGamepad ~= var5 then
			arg1:BindContextActions()
			arg1:ConnectGamepadConnectionListeners()
		else
			return false
		end
	else
		arg1:UnbindContextActions()
		arg1:DisconnectGamepadConnectionListeners()
		arg1.activeGamepad = var5
	end

	arg1.enabled = arg2
	return true
end

var4.GetHighestPriorityGamepad = function(_)
	local var1 = var5
	for k1, v1 in pairs((var2:GetConnectedGamepads())) do
		if v1.Value >= var1.Value then
			continue
		end

		var1 = v1
	end

	return var1
end

var4.UpdateMovement = function(arg1)
	arg1.moveVector = arg1.thumbstickVector + Vector3.new(0, 0, arg1.forwardValue + arg1.backwardValue)
end

var4.BindContextActions = function(arg1)
	if arg1.activeGamepad == var5 then
		return false
	end

	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	local function fn4(_, arg2, _)
		arg1.isJumping = arg2 == Enum.UserInputState.Begin
		return Enum.ContextActionResult.Sink
	end

	local function fn6(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			if var1 then
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
				arg1:UpdateMovement()
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end

			return Enum.ContextActionResult.Sink
		end

		if arg1.activeGamepad ~= arg3.UserInputType then
			return Enum.ContextActionResult.Pass
		end

		if arg3.KeyCode ~= Enum.KeyCode.Thumbstick1 then
			return
		end

		if var1 then
			if 0.2 < arg3.Position.magnitude then
				arg1.thumbstickVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.thumbstickVector = Vector3.new(0, 0, 0)
			end

			arg1:UpdateMovement()
		else
			if 0.2 < arg3.Position.magnitude then
				arg1.moveVector = Vector3.new(arg3.Position.X, 0, -arg3.Position.Y)
			else
				arg1.moveVector = Vector3.new(0, 0, 0)
			end
		end

		return Enum.ContextActionResult.Sink
	end

	local function fn8(_, arg2, arg3)
		if arg2 == Enum.UserInputState.Cancel then
			arg1.forwardValue = 0
			arg1.backwardValue = 0
			arg1:UpdateMovement()
			return Enum.ContextActionResult.Sink
		end

		local num2 = 0
		if 0.2 < arg3.Position.magnitude then
			num2 = arg3.Position.Z
		end

		if arg3.KeyCode == Enum.KeyCode.ButtonUp then
			arg1.forwardValue = -num2
		else
			if arg3.KeyCode == Enum.KeyCode.ButtonDown then
				arg1.backwardValue = num2
			end
		end

		arg1:UpdateMovement()
		return Enum.ContextActionResult.Sink
	end

	if var1 then
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonCenter)
		var3:BindActionAtPriority("moveDirectionalButton", fn8, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonUp, Enum.KeyCode.ButtonDown)
	else
		var3:BindActionAtPriority("jumpAction", fn4, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
	end

	var3:BindActionAtPriority("moveThumbstick", fn6, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
	return true
end

var4.UnbindContextActions = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	if var1 then
		var3:UnbindAction("moveDirectionalButton")
	end

	var3:UnbindAction("moveThumbstick")
	var3:UnbindAction("jumpAction")
end

var4.OnNewGamepadConnected = function(arg1)
	local var2 = arg1:GetHighestPriorityGamepad()
	if var2 == arg1.activeGamepad then
		return
	end

	if var2 == var5 then
		warn("Gamepad:OnNewGamepadConnected found no connected gamepads")
		arg1:UnbindContextActions()
		return
	end

	if arg1.activeGamepad ~= var5 then
		arg1:UnbindContextActions()
	end

	arg1.activeGamepad = var2
	arg1:BindContextActions()
end

var4.OnCurrentGamepadDisconnected = function(arg1)
	if arg1.activeGamepad ~= var5 then
		var3:UnbindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
	end

	local var2 = arg1:GetHighestPriorityGamepad()
	if arg1.activeGamepad ~= var5 and var2 == arg1.activeGamepad then
		warn("Gamepad:OnCurrentGamepadDisconnected found the supposedly disconnected gamepad in connectedGamepads.")
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	if var2 == var5 then
		arg1:UnbindContextActions()
		arg1.activeGamepad = var5
		return
	end

	arg1.activeGamepad = var2
	var3:BindActivate(arg1.activeGamepad, Enum.KeyCode.ButtonR2)
end

var4.ConnectGamepadConnectionListeners = function(arg1)
	arg1.gamepadConnectedConn = var2.GamepadConnected:Connect(function(_)
		arg1:OnNewGamepadConnected()
	end)

	arg1.gamepadDisconnectedConn = var2.GamepadDisconnected:Connect(function(arg1)
		if arg1.activeGamepad == arg1 then
			arg1:OnCurrentGamepadDisconnected()
		end
	end)
end

var4.DisconnectGamepadConnectionListeners = function(arg1)
	if arg1.gamepadConnectedConn then
		arg1.gamepadConnectedConn:Disconnect()
		arg1.gamepadConnectedConn = nil
	end

	if arg1.gamepadDisconnectedConn then
		arg1.gamepadDisconnectedConn:Disconnect()
		arg1.gamepadDisconnectedConn = nil
	end
end

return var4

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.VRNavigation [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
local var1 = require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1))
local var2 = game:GetService("VRService")
local var3 = game:GetService("UserInputService")
local var4 = game:GetService("RunService")
local var5 = game:GetService("PathfindingService")
local var6 = game:GetService("ContextActionService")
local var7 = game:GetService("StarterGui")
local var8 = game:GetService("Players").LocalPlayer
str1 = RaycastParams.new()
str1.FilterType = Enum.RaycastFilterType.Exclude
local var9 = var1.getUserFlag("UserRaycastUpdateAPI2")
local var10 = Instance.new("BindableEvent")
var10.Name = "MovementUpdate"
var10.Parent = script
local var11 = nil
coroutine.wrap(function()
	local var2 = script.Parent:WaitForChild("PathDisplay")
	if var2 then
		var11 = require(var2)
	end
end)()

local str2 = "BaseCharacterController"
local var12 = require(script.Parent:WaitForChild(str2))
local var13 = setmetatable({}, var12)
var13.__index = var13
var13.new = function(arg1)
	local var1 = setmetatable(var12.new(), var13)
	var1.CONTROL_ACTION_PRIORITY = arg1
	var1.navigationRequestedConn = nil
	var1.heartbeatConn = nil
	var1.currentDestination = nil
	var1.currentPath = nil
	var1.currentPoints = nil
	var1.currentPointIdx = 0
	var1.expectedTimeToNextPoint = 0
	var1.timeReachedLastPoint = tick()
	var1.moving = false
	var1.isJumpBound = false
	var1.moveLatch = false
	var1.userCFrameEnabledConn = nil
	return var1
end

var13.SetLaserPointerMode = function(_, arg2)
	pcall(function()
		var7:SetCore("VRLaserPointerMode", arg2)
	end)
end

var13.GetLocalHumanoid = function(_)
	local var2 = var8.Character
	if not var2 then
		return
	end

	for k1, v1 in pairs(var2:GetChildren()) do
		if not v1:IsA("Humanoid") then
			continue
		end

		return v1
	end

	return nil
end

var13.HasBothHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 and var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.HasAnyHandControllers = function(_)
	local var1 = var2:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	return var1 or var2:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end

var13.IsMobileVR = function(_)
	return var3.TouchEnabled
end

var13.HasGamepad = function(_)
	return var3.GamepadEnabled
end

var13.ShouldUseNavigationLaser = function(arg1)
	if arg1:IsMobileVR() then
		return true
	end

	if arg1:HasBothHandControllers() then
		return false
	end

	if not arg1:HasAnyHandControllers() then
		return not arg1:HasGamepad()
	end

	return true
end

var13.StartFollowingPath = function(arg1, arg2)
	currentPath = arg2
	currentPoints = currentPath:GetPointCoordinates()
	currentPointIdx = 1
	moving = true
	timeReachedLastPoint = tick()
	local var2 = arg1:GetLocalHumanoid()
	if var2 and (var2.Torso and 1 <= (#currentPoints)) then
		expectedTimeToNextPoint = (currentPoints[1] - var2.Torso.Position).magnitude / var2.WalkSpeed
	end

	var10:Fire("targetPoint", arg1.currentDestination)
end

var13.GoToPoint = function(arg1, arg2)
	currentPath = true
	currentPoints = { arg2 }
	currentPointIdx = 1
	moving = true
	local var1 = arg1:GetLocalHumanoid()
	timeReachedLastPoint = tick()
	expectedTimeToNextPoint = (var1.Torso.Position - arg2).magnitude / var1.WalkSpeed
	var10:Fire("targetPoint", arg2)
end

var13.StopFollowingPath = function(arg1)
	currentPath = nil
	currentPoints = nil
	currentPointIdx = 0
	moving = false
	arg1.moveVector = Vector3.new(0, 0, 0)
end

var13.TryComputePath = function(_, arg2, arg3)
	local num1 = 0
	local var1 = nil
	while not var1 do
		if num1 >= 5 then
			break
		end

		var1 = var5:ComputeSmoothPathAsync(arg2, arg3, 200)
		if var1.Status == Enum.PathStatus.ClosestNoPath or var1.Status == Enum.PathStatus.ClosestOutOfRange then
			var1 = nil
			return var1
		end

		if var1 then
			if var1.Status == Enum.PathStatus.FailStartNotEmpty then
				var1 = nil
			end
		end

		if not var1 then
			continue
		end

		if var1.Status ~= Enum.PathStatus.FailFinishNotEmpty then
			continue
		end

		arg2 = arg2 + (arg3 - arg2).Unit
		arg3 = arg3 + Vector3.new(0, 1, 0)
		num1 = num1 + 1
		var1 = nil
	end

	return var1
end

var13.OnNavigationRequest = function(arg1, arg2, _)
	local var1 = arg2.Position
	local var3 = var1.x
	local var4 = arg1.currentDestination
	local bool2 = false
	if var3 == var3 then
		bool2 = false
		if var3 ~= math.huge then
			bool2 = var3 ~= -math.huge
		end
	end

	if bool2 then
		var3 = var1.y
		bool2 = false
		if var3 == var3 then
			bool2 = false
			if var3 ~= math.huge then
				bool2 = var3 ~= -math.huge
			end
		end

		if bool2 then
			var3 = var1.z
			bool2 = false
			if var3 == var3 then
				bool2 = false
				if var3 ~= math.huge then
					bool2 = var3 ~= -math.huge
				end
			end
		end
	end

	if not bool2 then
		return
	end

	arg1.currentDestination = var1
	bool2 = arg1:GetLocalHumanoid()
	if not bool2 or (not bool2.Torso) then
		return
	end

	var3 = bool2.Torso.Position
	if (arg1.currentDestination - var3).magnitude < 12 then
		arg1:GoToPoint(arg1.currentDestination)
		return
	end

	if var4 then
		if 4 < (arg1.currentDestination - var4).magnitude then
			local var8 = arg1:TryComputePath(var3, arg1.currentDestination)
			if var8 then
				arg1:StartFollowingPath(var8)
				if not var11 then
					return
				end

				var11.setCurrentPoints(arg1.currentPoints)
				var11.renderPath()
				return
			end

			arg1:StopFollowingPath()
			if not var11 then
				return
			end

			var11.clearRenderedPath()
			return
		end
	end

	if moving then
		arg1.currentPoints[#currentPoints] = arg1.currentDestination
		return
	end

	arg1:GoToPoint(arg1.currentDestination)
end

var13.OnJumpAction = function(arg1, _, arg3, _)
	if arg3 == Enum.UserInputState.Begin then
		arg1.isJumping = true
	end

	return Enum.ContextActionResult.Sink
end

var13.BindJumpAction = function(arg1, arg2)
	if arg2 then
		if not not arg1.isJumpBound then
			return
		end

		arg1.isJumpBound = true
		var6:BindActionAtPriority("VRJumpAction", function()
			return arg1:OnJumpAction()
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)

		return
	end

	if arg1.isJumpBound then
		arg1.isJumpBound = false
		var6:UnbindAction("VRJumpAction")
	end
end

var13.ControlCharacterGamepad = function(arg1, _, arg3, arg4)
	if arg4.KeyCode ~= Enum.KeyCode.Thumbstick1 then
		return
	end

	if arg3 == Enum.UserInputState.Cancel then
		arg1.moveVector = Vector3.new(0, 0, 0)
		return
	end

	if arg3 ~= Enum.UserInputState.End then
		arg1:StopFollowingPath()
		if var11 then
			var11.clearRenderedPath()
		end

		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(true)
			arg1:SetLaserPointerMode("Hidden")
		end

		if 0.22 < arg4.Position.magnitude then
			arg1.moveVector = Vector3.new(arg4.Position.X, 0, -arg4.Position.Y)
			if 0 < arg1.moveVector.magnitude then
				local var1 = arg1.moveVector.unit * math.min(1, arg4.Position.magnitude)
				arg1.moveVector = var1
			end

			arg1.moveLatch = true
		end
	else
		arg1.moveVector = Vector3.new(0, 0, 0)
		if arg1:ShouldUseNavigationLaser() then
			arg1:BindJumpAction(false)
			arg1:SetLaserPointerMode("Navigation")
		end

		if arg1.moveLatch then
			arg1.moveLatch = false
			var10:Fire("offtrack")
		end
	end

	return Enum.ContextActionResult.Sink
end

var13.OnHeartbeat = function(arg1, arg2)
	local var2 = arg1:GetLocalHumanoid()
	local var3 = arg1.moveVector
	if not var2 or (not var2.Torso) then
		return
	end

	if arg1.moving then
		if arg1.currentPoints then
			local var13 = var2.Torso.Position
			local var14 = (currentPoints[1] - var13) * Vector3.new(1, 0, 1)
			local var15 = var14.magnitude
			if var15 < 1 then
				local var16 = var14 / var15
				local num1 = 0
				local var17 = currentPoints[1]
				for k1, v1 in pairs(currentPoints) do
					if k1 == 1 then
						continue
					end

					local var18 = (v1 - var17).magnitude
					num1 = num1 + var18 / var2.WalkSpeed
					var17 = v1
				end

				table.remove(currentPoints, 1)
				local var19 = currentPointIdx + 1
				currentPointIdx = var19
				if #currentPoints == 0 then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					return
				end

				if var11 then
					var11.setCurrentPoints(currentPoints)
					var11.renderPath()
				end

				expectedTimeToNextPoint = (currentPoints[1] - var13).magnitude / var2.WalkSpeed
				timeReachedLastPoint = tick()
			else
				if var9 then
					str1.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var22 = workspace:Raycast(var13 - Vector3.new(0, 1, 0), var16 * 3, str1)
					local var23 = workspace:Raycast(var22.Position + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0), str1).Position.Y - var13.Y
					if var22 and (var23 < 6 and -2 < var23) then
						var2.Jump = true
					end
				else
					local tbl1 = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local var29, var30, var31 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var13 - Vector3.new(0, 1, 0), var16 * 3), tbl1)
					local var32, var33, var34 = workspace:FindPartOnRayWithIgnoreList(Ray.new(var30 + var16 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0)), tbl1)
					local var35 = var33.Y - var13.Y
					if var29 and (var35 < 6 and -2 < var35) then
						var2.Jump = true
					end
				end

				if expectedTimeToNextPoint + 2 < tick() - timeReachedLastPoint then
					arg1:StopFollowingPath()
					if var11 then
						var11.clearRenderedPath()
					end

					var10:Fire("offtrack")
				end

				var3 = arg1.moveVector:Lerp(var16, arg2 * 10)
			end
		end
	end

	local var37 = var3.x
	local bool2 = false
	if var37 == var37 then
		bool2 = false
		if var37 ~= math.huge then
			bool2 = var37 ~= -math.huge
		end
	end

	if bool2 then
		var37 = var3.y
		bool2 = false
		if var37 == var37 then
			bool2 = false
			if var37 ~= math.huge then
				bool2 = var37 ~= -math.huge
			end
		end

		if bool2 then
			var37 = var3.z
			bool2 = false
			if var37 == var37 then
				bool2 = false
				if var37 ~= math.huge then
					bool2 = var37 ~= -math.huge
				end
			end
		end
	end

	if bool2 then
		arg1.moveVector = var3
	end
end

var13.OnUserCFrameEnabled = function(arg1)
	if arg1:ShouldUseNavigationLaser() then
		arg1:BindJumpAction(false)
		arg1:SetLaserPointerMode("Navigation")
		return
	end

	arg1:BindJumpAction(true)
	arg1:SetLaserPointerMode("Hidden")
end

var13.Enable = function(arg1, arg2)
	arg1.moveVector = Vector3.new(0, 0, 0)
	arg1.isJumping = false
	if arg2 then
		arg1.navigationRequestedConn = var2.NavigationRequested:Connect(function(arg1, arg2)
			arg1:OnNavigationRequest(arg1, arg2)
		end)

		arg1.heartbeatConn = var4.Heartbeat:Connect(function(arg1)
			arg1:OnHeartbeat(arg1)
		end)

		var6:BindAction("MoveThumbstick", function(arg1, arg2, arg3)
			local var1 = arg1
			local var2 = arg2
			local var3 = arg3
			return arg1:ControlCharacterGamepad(var1, var2, var3)
		end, false, arg1.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)

		var6:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		arg1.userCFrameEnabledConn = var2.UserCFrameEnabled:Connect(function()
			arg1:OnUserCFrameEnabled()
		end)

		arg1:OnUserCFrameEnabled()
		var2:SetTouchpadMode(Enum.VRTouchpad.Left, Enum.VRTouchpadMode.VirtualThumbstick)
		var2:SetTouchpadMode(Enum.VRTouchpad.Right, Enum.VRTouchpadMode.ABXY)
		arg1.enabled = true
		return
	end

	arg1:StopFollowingPath()
	var6:UnbindAction("MoveThumbstick")
	var6:UnbindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	arg1:BindJumpAction(false)
	arg1:SetLaserPointerMode("Disabled")
	if arg1.navigationRequestedConn then
		arg1.navigationRequestedConn:Disconnect()
		arg1.navigationRequestedConn = nil
	end

	if arg1.heartbeatConn then
		arg1.heartbeatConn:Disconnect()
		arg1.heartbeatConn = nil
	end

	if arg1.userCFrameEnabledConn then
		arg1.userCFrameEnabledConn:Disconnect()
		arg1.userCFrameEnabledConn = nil
	end

	arg1.enabled = false
end

return var13

--- Players.LocalPlayer.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface [ModuleScript]
-- y u r i

local str1 = "FlagUtil"
if require(script.Parent.Parent:WaitForChild("CommonUtils"):WaitForChild(str1)).getUserFlag("UserAllowAbilityControls") then
	local var6 = nil
	local var7 = nil
	local var8 = nil
	local var9 = Instance.new("BindableEvent")
	local bool2 = false
	local var10 = game:GetService("Players")
	local function fn3(arg1)
		var6 = nil
		var7 = nil
		if var8 then
			var8:Disconnect()
			var8 = nil
		end

		if arg1 then
			var6 = arg1:FindFirstChild("AbilityManagerActor")
			var7 = arg1:FindFirstChildOfClass("Humanoid")
			while not var7 do
				arg1.ChildAdded:wait()
				var7 = arg1:FindFirstChildOfClass("Humanoid")
			end

			var9:Fire()
			var8 = var7:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				var9:Fire()
			end)

		end
	end

	return {
		isEnabled = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			local bool3 = false
			if var6 ~= nil then
				bool3 = var7
				bool3 = bool3 and (not var7.EvaluateStateMachine)
			end

			return bool3
		end,
		GetEnabledChangedSignal = function()
			if not bool2 then
				bool2 = true
				local var2 = var10.LocalPlayer
				if var2 then
					var2.characterAdded:Connect(fn3)
					if var2.Character then
						fn3(var2.Character)
					end
				end
			end

			return var9.Event
		end,
	}

end

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil [ModuleScript]
-- y u r i

local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	local var1 = setmetatable({}, tbl1)
	var1._connections = {}
	return var1
end

tbl1.trackConnection = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = function()
		arg3:Disconnect()
	end
end

tbl1.trackBoundFunction = function(arg1, arg2, arg3)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
	end

	arg1._connections[arg2] = arg3
end

tbl1.disconnect = function(arg1, arg2)
	if arg1._connections[arg2] then
		arg1._connections[arg2]()
		arg1._connections[arg2] = nil
	end
end

tbl1.disconnectAll = function(arg1)
	for k1, v1 in pairs(arg1._connections) do
		v1()
	end

	arg1._connections = {}
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.ConnectionUtil)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.AppCommonLib).Signal
var2.describe("ConnectionUtil", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should track a connection", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		var4.new():trackConnection("Signal", var1:Connect(fn2))
		var1:fire("Testing")
		var5(str1).toBe("Testing")
	end)

	var3("should disconnect from signal", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		var2:disconnect("Signal")
		var1:fire("Testing")
		var5(str1).toBe("")
	end)

	var3("should disconnect from all", function()
		local str1 = ""
		local var1 = var6.new()
		local function fn2(arg1)
			str1 = arg1
		end

		local var2 = var4.new()
		var2:trackConnection("Signal", var1:Connect(fn2))
		local str2 = ""
		fn2 = function(arg1)
			str2 = arg1
		end

		var2:trackConnection("Signal1", var6.new():Connect(fn2))
		local str3 = ""
		fn2 = function(arg1)
			str3 = arg1
		end

		var2:trackConnection("Signal2", var6.new():Connect(fn2))
		var2:disconnectAll()
		var1:fire("TestingPrimary")
		var1:fire("TestingSecondary")
		var1:fire("TestingTertiary")
		var5(str1).toBe("")
		var5(str2).toBe("")
		var5(str3).toBe("")
	end)

	var3("should call manual disconnect", function()
		local str1 = ""
		local var1 = var4.new()
		var1:trackBoundFunction("Manual", function()
			str1 = "Disconnected"
		end)

		var1:disconnect("Manual")
		var5(str1).toBe("Disconnected")
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil [ModuleScript]
-- y u r i

local str1 = "ConnectionUtil"
local var1 = game:GetService("Players")
local tbl1 = { _connectionUtil = require(script.Parent:WaitForChild(str1)).new() }
tbl1._boundEvents = {}
tbl1.getLocalPlayer = function()
	return var1.LocalPlayer
end

tbl1.onLocalPlayer = function(arg1)
	local var3 = tbl1.getLocalPlayer()
	if var3 then
		arg1(var3)
	end

	local function fn2()
		local var1 = tbl1.getLocalPlayer()
		assert(var1)
		tbl1._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(var1)
	end

	tbl1._connectionUtil:trackConnection("LOCAL_PLAYER", var1:GetPropertyChangedSignal("LocalPlayer"):Connect(fn2))
	local var4 = arg1
	return tbl1._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(var4)
end

tbl1.getCharacter = function()
	local var2 = tbl1.getLocalPlayer()
	if not var2 then
		return nil
	end

	return var2.Character
end

tbl1.onCharacter = function(arg1)
	local function fn2(arg1)
		local var2 = tbl1.getCharacter()
		if var2 then
			arg1(var2)
		end

		local function fn2(arg1)
			assert(arg1)
			tbl1._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(arg1)
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_ADDED", arg1.CharacterAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_LOCAL_PLAYER", tbl1.onLocalPlayer(fn2))
	local var1 = arg1
	return tbl1._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(var1)
end

tbl1.getChild = function(arg1, arg2)
	local var2 = tbl1.getCharacter()
	if not var2 then
		return nil
	end

	local var4 = var2:FindFirstChild(arg1)
	if var4 and var4:IsA(arg2) then
		return var4
	end

	return nil
end

tbl1.onChild = function(arg1, arg2, arg3)
	local function fn2(arg1)
		local var2 = tbl1.getChild(arg1, arg2)
		if var2 then
			arg3(var2)
		end

		local function fn2(arg1)
			if arg1.Name == arg1 and arg1:IsA(arg2) then
				tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2):Fire(arg1)
			end
		end

		tbl1._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", arg1.ChildAdded:Connect(fn2))
	end

	tbl1._connectionUtil:trackConnection("ON_CHARACTER", tbl1.onCharacter(fn2))
	local var1 = arg3
	return tbl1._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. arg1 .. arg2).Event:Connect(var1)
end

tbl1._getOrCreateBoundEvent = function(arg1)
	if not tbl1._boundEvents[arg1] then
		tbl1._boundEvents[arg1] = Instance.new("BindableEvent")
	end

	return tbl1._boundEvents[arg1]
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec [ModuleScript]
-- y u r i

local var1 = game:GetService("CorePackages")
local var2 = require(var1.Packages.Dev.JestGlobals)
local var3 = var2.it
local var4 = require(script.Parent.CameraWrapper)
local var5 = var2.expect
local var6 = require(var1.Workspace.Packages.TestUtils).DeferredLuaHelpers.waitForEvents
var2.describe("CameraWrapper", function()
	var3("should instantiate", function()
		var5((var4.new())).never.toBeNil()
	end)

	var3("should return updated camera", function()
		local var1 = var4.new()
		var1:Enable()
		local var2 = Instance.new("Camera")
		var2.Parent = game.Workspace
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).never.toBe(var2)
		game.Workspace.CurrentCamera = var2
		var6()
		var5(var1:getCamera()).toBe(game.Workspace.CurrentCamera)
		var5(var1:getCamera()).toBe(var2)
	end)
end)

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.FlagUtil [ModuleScript]
-- y u r i

return { getUserFlag = function(arg1)
	local success, result = pcall(function()
		local var1 = arg1
		return UserSettings():IsUserFeatureEnabled(var1)
	end)

	return success and result
end }

--- Players.LocalPlayer.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper [ModuleScript]
-- y u r i

local var1 = require(script.Parent.ConnectionUtil)
local tbl1 = {}
tbl1.__index = tbl1
tbl1.new = function()
	return (setmetatable({
		_camera = game.Workspace.CurrentCamera,
		_callbacks = {},
		_connectionUtil = var1.new(),
		_enabled = false,
	}, tbl1))
end

tbl1._connectCallbacks = function(arg1)
	arg1._camera = game.Workspace.CurrentCamera
	if not arg1._camera then
		return
	end

	for k1, v1 in arg1._callbacks, nil do
		local var1 = v1
		arg1._connectionUtil:trackConnection(k1, arg1._camera:GetPropertyChangedSignal(k1):Connect(var1))
		v1()
	end
end

tbl1.Enable = function(arg1)
	if arg1._enabled then
		return
	end

	arg1._enabled = true
	arg1._cameraChangedConnection = game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		arg1:_connectCallbacks()
	end)

	arg1:_connectCallbacks()
end

tbl1.Disable = function(arg1)
	if not arg1._enabled then
		return
	end

	arg1._enabled = false
	if arg1._cameraChangedConnection then
		arg1._cameraChangedConnection:Disconnect()
		arg1._cameraChangedConnection = nil
	end

	arg1._connectionUtil:disconnectAll()
end

tbl1.Connect = function(arg1, arg2, arg3)
	arg1._callbacks[arg2] = arg3
	if not arg1._camera then
		return
	end

	local var1 = arg3
	arg1._connectionUtil:trackConnection(arg2, arg1._camera:GetPropertyChangedSignal(arg2):Connect(var1))
end

tbl1.Disconnect = function(arg1, arg2)
	arg1._connectionUtil:disconnect(arg2)
	arg1._callbacks[arg2] = nil
end

tbl1.getCamera = function(arg1)
	return arg1._camera
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.PlayerScriptsLoader [LocalScript]
-- y u r i

local str1 = "PlayerModule"
require(script.Parent:WaitForChild(str1))

--- Players.LocalPlayer.PlayerScripts.Client.Main [LocalScript]
-- y u r i

require(game:GetService("ReplicatedStorage").Framework).Stat.WaitForLoad(game:GetService("Players").LocalPlayer)
local var1 = game:GetService("StarterGui")
var1:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
local var3 = (function()
	local num1 = 0
	local tbl1 = {}
	local var1 = tick()
	local num2 = 0
	local function LoadModule(arg1)
		if not arg1:IsA("ModuleScript") then
			return
		end

		local success, result = pcall(function()
			local var2 = require(arg1)
			if var2 then
				var2:Init()
			end

			return var2
		end)

		local var1 = arg1.Name
		if success then
			local var2 = num1 + 1
			num1 = var2
			return
		end

		local str1 = "[ModuleLoader] Failed to load %s:"
		local var3 = var1
		warn(string.format(str1, var3))
		str1 = result
		warn(debug.traceback(str1))
		table.insert(tbl1, { Name = var1, Error = result })
	end

	for k1, v1 in script.Parent:GetDescendants() do
		if not v1:IsA("ModuleScript") then
			continue
		end

		if v1.Parent:IsA("ModuleScript") then
			continue
		end

		task.spawn(LoadModule, v1)
		num2 = num2 + 1
	end

	local var2 = (tick() - var1) * 1000
	return {
		Success = #tbl1 == 0,
		LoadedCount = num1,
		FailedCount = #tbl1,
		FailedModules = tbl1,
		TimeTakenMs = var2,
	}
end)()

local function DisableResetButton()
	while true do
		local success, result = pcall(function()
			var1:SetCore("ResetButtonCallback", false)
		end)

		if success then
			break
		end

		task.wait(1.375)
	end
end

if var3 and (var3.FailedModules and var3.FailedCount ~= 0) then
	print(var3.FailedModules)
end

DisableResetButton()

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.DailyReward [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = require(var1.Modules.Client.UI)
local var4 = game:GetService("Players").LocalPlayer
local var5 = var4.PlayerGui:WaitForChild("Frames"):WaitForChild("DailyReward")
local var6 = var5.MainBG.Frames
local var7 = require(var1.Framework)
local bool1 = false
local bool2 = false
local var8 = var6.Today
local var9 = var6.Tomorrow
local var10 = var3.PopUps
local var11 = require(var1.Modules.Shared.StatInformation)
local var12 = var7.Stat.Get(var4, "DailyTime")
local var13 = require(var2.Client.Hover)
local var14 = require(var1.Modules.Shared.Multipliers)
local var15 = var5.Streak
local var16 = var7.Stat.Get(var4, "DailyStreak")
local var17 = require(var1.Modules.Shared.BigNum)
local function ClaimedDaily(arg1, arg2)
	if arg2 then
		bool1 = true
		bool2 = true
		var8.Button.BG.Color.TextLabel.Text = "Claimed!"
		var9.Button.BG.Color.TextLabel.Text = "Claimed!"
	end

	var7.Sound.Play("Daily")
	var10.CreatePopUp(var4, var11.Ruby.Icon, arg1, var11.Ruby.Colour)
end

local var18 = require(var2.Shared.Daily)
local var19 = game:GetService("MarketplaceService")
local function TweenButton(arg1)
	local var1 = arg1.Size
	arg1.MouseEnter:Connect(function()
		var13.Hover(arg1, var1)
	end)

	arg1.MouseLeave:Connect(function()
		var13.Up(arg1, var1)
	end)

	arg1.Button.MouseButton1Down:Connect(function()
		var13.Down(arg1, var1)
	end)

	arg1.Button.MouseButton1Up:Connect(function()
		var13.Up(arg1, var1)
	end)
end

local function UpdateStreak()
	local var1 = (var14.DailyStreakMultiplier(var4) - 1) * 100
	var15.Visible = 0 < var16.Value
	var15.Text = ([[🔥 Daily Login Streak: <font color="#ffaa00">%* Days</font> (+%*%% <font color="#71ff6f">Cash</font> Boost)]]):format(var16.Value + 1, (var17.toSuffix(var1)))
end

local function ClaimToday()
	if bool1 then
		return
	end

	if os.time() < var12.Value then
		return
	end

	var7.Network.Fire("ClaimDaily")
	bool1 = true
	var8.Button.BG.Color.TextLabel.Text = "Claimed!"
end

local var20 = var7.Stat.Get(var4, "RobuxDailySkipClaimed")
return { Init = function(_)
	var5.Topbar.closebutton.Close.MouseButton1Click:Connect(function()
		if bool1 then
		else
		if os.time() >= var12.Value then
				var7.Network.Fire("ClaimDaily")
				bool1 = true
				var8.Button.BG.Color.TextLabel.Text = "Claimed!"
			end
		end

		var7.Sound.Play("UIClick")
		var3.FrameOpenings.CloseFrame(var5)
	end)

	local var1 = var7.Stat.GetDataFolder(var4).TempValues
	local var2 = var7.Stat.Get(var4, "DaysClaimed")
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	var7.Network.Connect("ClaimDaily", ClaimedDaily)
	local success, result = pcall(var19.GetProductInfoAsync, var19, 3711782941, Enum.InfoType.Product)
	local var6 = var12.Value <= os.time()
	local var10 = var18.Reward(var4)
	local var11 = var18.Reward(var4, var2.Value + 1)
	if success and result then
		var9.Button.BG.Color.TextLabel.Text = ("\238\128\130%*"):format(result.PriceInRobux)
	end

	var5.Visible = var6
	var8.Main.Gems.Amount.Text = ("+%*"):format(var10)
	var9.Main.Gems.Amount.Text = ("+%*"):format(var11)
	TweenButton(var8.Button)
	TweenButton(var9.Button)
	local var13 = (var14.DailyStreakMultiplier(var4) - 1) * 100
	var15.Visible = 0 < var16.Value
	var15.Text = ([[🔥 Daily Login Streak: <font color="#ffaa00">%* Days</font> (+%*%% <font color="#71ff6f">Cash</font> Boost)]]):format(var16.Value + 1, (var17.toSuffix(var13)))
	var16.Changed:Connect(UpdateStreak)
	var8.Button.Button.MouseButton1Click:Connect(ClaimToday)
	var9.Button.Button.MouseButton1Click:Connect(function()
		if var20.Value then
			return
		end

		if bool2 then
			return
		end

		var19:PromptProductPurchase(var4, 3711782941)
	end)

	task.spawn(function()
		while true do
			if not task.wait(1) then
				break
			end

			local var1 = var12.Value <= os.time()
			var6 = var1
			var1 = var9.Time
			local var2 = if var6 then "1d" else var7.Short.toTime(var12.Value - os.time())
			var1.Text = var2
			var1 = var8.Button.BG.Color.TextLabel
			var1.Text = if var6 then "Claim!" else "Claimed!"
			var1 = var9.Button.BG.Color.TextLabel
			var2 = if var20.Value then "Claimed!" else ("\238\128\130%*"):format(result.PriceInRobux)
			var1.Text = var2
			var1 = var5.MainBG.Time
			var2 = if var6 then "Log in daily for more rewards! \240\159\142\129" else ("Next Reward In: %* \240\159\142\129"):format((var7.Short.toTime(var12.Value - os.time())))
			var1.Text = var2
			if not var6 then
				continue
			end

			bool1 = false
			bool2 = false
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Stats [ModuleScript]
-- y u r i

game:GetService("TweenService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
require(var3.Hover)
local var4 = var2.Shared
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = require(var3.Suffix)
local var8 = require(var4.Multipliers)
local var9 = require(var4.BigNum)
local var10 = require(var4.Seeds)
local var11 = var6.PlayerGui:WaitForChild("Frames"):WaitForChild("Stats")
local function UpdateStat(arg1, arg2, arg3)
	local var2 = arg1[arg2]
	if arg2 ~= "PlayTime" and arg2 ~= "SpawnCooldown" then
		arg3.Text = var7.short(var2)
		return
	end

	if arg2 == "PlayTime" then
		arg3.Text = var5.Short.toTime(var2)
		return
	end

	if arg2 == "SpawnCooldown" then
		arg3.Text = var7.short(var2) .. "s"
	end
end

return { Init = function(_)
	while var6 and var6.Parent do
		local var1 = var5.Stat.Get(var6, "Seed").Value
		local tbl1 = { PlayTime = var5.Stat.Get(var6, "PlayTime").Value }
		tbl1.RobuxSpent = var5.Stat.Get(var6, "RobuxSpent").Value
		tbl1.Collects = var5.Stat.Get(var6, "Collects").Value
		tbl1.TotalCash = var5.Stat.Get(var6, "TotalCash").Value
		tbl1.SpawnCooldown = var8.GetCollectibleCooldown(var6)
		tbl1.SpawnLimit = var8.GetCollectibleCap(var6)
		tbl1.SeedMultiplier = var9.mul(var10.Seeds[var1].Reward(var6), var10.Seeds[var1].Multiplier)
		tbl1.Clicks = var5.Stat.Get(var6, "Clicks").Value
		tbl1.TreeHits = var5.Stat.Get(var6, "TreeHits").Value
		tbl1.LeavesCollected = var5.Stat.Get(var6, "LeavesCollected").Value
		tbl1.DailyMultiplier = var8.DailyStreakMultiplier(var6)
		for k1, v1 in var11.Main:GetChildren() do
			if not v1:IsA("Frame") then
				continue
			end

			local var2 = v1.Name
			local var3 = v1.Amount
			if not tbl1[var2] then
				print(var2 .. " Doesn't exist!")
			else
				UpdateStat(tbl1, var2, var3)
			end
		end

		task.wait(0.5)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Boosts [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = var2.PlayerGui:WaitForChild("Front"):WaitForChild("MainFrame")
local var4 = require(var1.Framework)
local var5 = nil
local var6 = var3:WaitForChild("Hoverframecontainer"):WaitForChild("Hoverframe")
local var7 = var4.Stat.Get("Device")
local var8 = var2:GetMouse()
local var9 = game:GetService("RunService")
local var10 = require(var1.Modules.Shared.Boosts)
local var11 = var1.Frames
local var12 = var3:WaitForChild("Boosts")
local function HoverBegan(arg1)
	if var7.Value ~= "PC" then
		return
	end

	if var5 then
		var5:Disconnect()
		var5 = nil
	end

	var6.Visible = false
	var6.Position = UDim2.fromOffset(var8.X, var8.Y + 60)
	var5 = var9.Heartbeat:Connect(function()
		local var1 = Vector2.new(var8.X, var8.Y)
		local var2 = var1.X
		local var3 = var1.Y
		var6.Position = UDim2.fromOffset(var2, var3 + 60)
		local var4 = arg1.AbsolutePosition
		local var7 = arg1.AbsoluteSize
		if not arg1.Visible then
			if var5 then
				var5:Disconnect()
				var5 = nil
			end

			var6.Visible = false
			return
		end

		if var2 >= var4.X then
			if not (var4.X + var7.X < var2 or (var3 < var4.Y or var4.Y + var7.Y < var3)) then
				return
			end

			if not (var3 < var4.Y or var4.Y + var7.Y < var3) then
				return
			end

			if var4.Y + var7.Y >= var3 then
				return
			end
		end

		if var5 then
			var5:Disconnect()
			var5 = nil
		end

		var6.Visible = false
	end)

	task.wait()
	var6.Visible = true
end

return { Init = function(_)
	var4.Stat.WaitForLoad(var2)
	var4.Stat.GetDataFolder(var2)
	for k1, v1 in var10, nil do
		local var1 = var4.Stat.Get(var2, k1)
		local var3 = var11.Boost:Clone()
		var3.Parent = var12
		var3.LayoutOrder = v1.Rank
		var3.ImageLabel.Image = v1.Icon
		var1.Changed:Connect(function()
			local var5 = var4.Stat.Get(var2, k1)
			local var7 = var3
			var7.Visible = 1 <= var5.Value
			var7.Time.Text = var4.Short.toTime(var5.Value)
			if var6.TutorialLabel.Text == v1.Display then
				var6.Description2.Text = var4.Short.toTime(var1.Value)
			end
		end)

		var3.MouseEnter:Connect(function()
			var6.TutorialLabel.Text = v1.Display
			var6.Description.Text = v1.Description
			var6.Description2.Text = var4.Short.toTime(var1.Value)
			HoverBegan(var3)
		end)

		local var5 = var4.Stat.Get(var2, k1)
		var3.Visible = 1 <= var5.Value
		var3.Time.Text = var4.Short.toTime(var5.Value)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Settings [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
var3.Stat.WaitForLoad(var4)
local var5 = require(var2.Shared.Multipliers)
local var6 = require(var2.Client.Hover)
local var7 = var4.PlayerGui:WaitForChild("Frames"):WaitForChild("Settings"):WaitForChild("Main")
local tbl1 = { Colour = Color3.fromRGB(235, 235, 235) }
tbl1.Position = UDim2.new(0.076, 0, 0.147, 0)
local tbl2 = { Off = tbl1 }
tbl1 = { Colour = Color3.fromRGB(102, 255, 79) }
tbl1.Position = UDim2.new(0.367, 0, 0.147, 0)
tbl2.On = tbl1
local var8 = TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
local bool1 = false
local function UpdateSlider(arg1, arg2)
	local var1 = arg2 and tbl2.On or tbl2.Off
	var3.Tween.Play(arg1, var8, { Position = var1.Position })
	var3.Tween.Play(arg1.Parent, var8, { BackgroundColor3 = var1.Colour })
end

tbl1 = { Ignore = true }
local function SetupWalkspeed(arg1)
	local var1 = var3.Stat.Get(var4, "ChosenWalkspeed")
	local var2 = arg1.Field.TextBox
	local function Sync()
		if not var1 or var2:IsFocused() then
			return
		end

		local var3 = var2
		local var4 = if 0 < var1.Value then tostring(var1.Value) else ""
		var3.Text = var4
	end

	if var1 then
		var1.Changed:Connect(Sync)
		if var1 then
			if var2:IsFocused() then
			else
				local var7 = if 0 < var1.Value then tostring(var1.Value) else ""
				var2.Text = var7
			end
		end
	end

	var2.ClearTextOnFocus = false
	var2.Focused:Connect(function()
		var2.PlaceholderText = ("Min : 16, Max : %*"):format((var5.GetPlayerSpeed(var4)))
	end)

	var2.FocusLost:Connect(function()
		var3.Network.Fire("ChangeWalkspeed", var2.Text)
		task.delay(0.5, Sync)
	end)

	var6.CreateHover(var2, var2.Size)
end

local function SetupToggle(arg1)
	local var1 = arg1.Name
	local var5 = var3.Stat.Get(var4, var1)
	if not var5 then
		warn((("[Settings] %* is not a valid stat"):format(var1)))
		return
	end

	local var7 = arg1.TextButton
	var7.MouseButton1Click:Connect(function()
		if bool1 then
			return
		end

		bool1 = true
		var3.Sound.Play("UIClick")
		var3.Network.Fire("Settings", var1)
		task.wait(0.15)
		bool1 = false
	end)

	local var8 = var7.Ball
	var5.Changed:Connect(function()
		UpdateSlider(var8, var5.Value)
	end)

	UpdateSlider(var8, var5.Value)
	var6.CreateHover(var7, var7.Size)
end

return { Init = function(_)
	for k1, v1 in var7:GetChildren() do
		if not v1:IsA("Frame") then
			continue
		end

		if tbl1[v1.Name] then
			continue
		end

		if v1.Name == "Walkspeed" then
			SetupWalkspeed(v1)
		else
			SetupToggle(v1)
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Quests [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = require(var1.Framework)
var3.Stat.WaitForLoad(var2)
local var4 = var2:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("Quests")
local var5 = workspace.Features:FindFirstChild("Quests")
local var6 = require(var1.Modules.Shared.Quests)
local var7 = require(var1.Modules.Client.Suffix)
var5 = var5 or var1.Assets.Features:FindFirstChild("Quests")
local var8 = var3.Stat.Get("Quests")
local tbl1 = { Daily = {}, Weekly = {} }
local var9 = var4.Template
local function TweenButton(arg1)
	local var1 = arg1:FindFirstChild("UIScale")
	var1 = var1 or Instance.new("UIScale", arg1)
	var3.Tween.Play(var1, TweenInfo.new(0.08), { Scale = 0.95 })
	task.wait(0.08)
	var3.Tween.Play(var1, TweenInfo.new(0.08), { Scale = 1 })
end

local function UpdateExclamations()
	local var1 = #tbl1.Daily
	local var2 = #tbl1.Weekly
	var5.Quests.Exclamation.Enabled = 0 < var1 + var2
	var4.Buttons.Daily.Notification.Visible = 0 < var1
	var4.Buttons.Weekly.Notification.Visible = 0 < var2
	var4.Buttons.Daily.Notification.TextLabel.Text = var1
	var4.Buttons.Weekly.Notification.TextLabel.Text = var2
end

local var10 = var8.QuestRerolls
local tbl2 = { "Daily", "Weekly" }
local function UpdateQuests(arg1, arg2)
	local var1 = var4:FindFirstChild(arg1)
	local var5 = var1:FindFirstChild(arg2.Name)
	if not var5 then
		var5 = var9:Clone()
		var5.Parent = var1
		var5.Name = arg2.Name
		var5.Visible = true
		var5.Main.Claim.Click.MouseButton1Click:Connect(function()
			var3.Network.Fire("ClaimQuest", arg1, arg2.Name)
			TweenButton(var5.Main.Claim)
		end)

		var5.Main.Use.Click.MouseButton1Click:Connect(function()
			var3.Network.Fire("RerollQuest", arg1, arg2.Name)
			TweenButton(var5.Main.Use)
		end)

	end

	local var10 = var6.Pool[arg2.QuestName.Value]
	local var11 = var5.Main
	if not var10 then
		return
	end

	local var12 = arg2.QuestProgress.Value
	local var13 = var10.Requirements[arg1]
	local var14 = var10.Format
	local var15 = var13 <= var12
	local var16 = arg2.Claimed.Value
	local var17 = math.clamp(var12 / var13, 0, 1)
	var11.Claim.Visible = var15 or var16
	var11.Use.Visible = not var11.Claim.Visible
	local var18 = arg2.RewardAmount.Value
	local var19 = var6.Rewards[arg2.QuestReward.Value]
	var14 = var14 or var7.short
	local var20 = var11.Claim.BG.Amount.TextLabel
	var20.Text = if var16 then "Claimed!" else "Claim!"
	var20 = var11.Claim.BG.Amount.TextLabel.TextLabel
	var20.Text = if var16 then "Claimed!" else "Claim!"
	local var21 = var13
	var20 = var11.Title
	local var22 = var10.Display:format(var14(var21))
	var20.Text = var22 .. (if var16 then " - Completed!" else "")
	var11.Icon.Image = var10.Image
	var11.TextLabel.Text = ("[%*/%*]"):format(var14(var12), (var14(var13)))
	var11.Progressbar.Progress.Text = ("%*%%"):format((math.floor(var17 * 100)))
	var11.Progressbar.Bar.Size = UDim2.fromScale(var17, 1)
	var11.Rewards.Gold.Amount.Text = ("+%*"):format((var19.Format(var18)))
	var11.Rewards.Gold.Amount.SubText.Text = ("+%*"):format((var19.Format(var18)))
	var11.Rewards.Gold.Icon.Image = var19.Image
	var20 = var15
	var20 = var20 and (not var16)
	local var24 = table.find(tbl1[arg1], arg2)
	if var20 and (not var24) then
		table.insert(tbl1[arg1], arg2)
		UpdateExclamations()
	elseif not var20 and var24 then
		table.remove(tbl1[arg1], var24)
		UpdateExclamations()
	end
end

local function UpdateButton(arg1, arg2)
	for k1, v1 in arg1:GetDescendants() do
		if not v1:IsA("UIStroke") then
			if not v1:IsA("UIGradient") then
				continue
			end
		end

		if v1.Name == "Ignore" then
			continue
		end

		local var1 = arg2 and Color3.fromRGB(10, 106, 29) or Color3.fromRGB(172, 77, 0)
		if v1:IsA("UIStroke") then
			v1.Color = var1
		else
			local num1 = 1
			local var2 = arg2 and Color3.fromRGB(1, 255, 73) or Color3.fromRGB(255, 136, 0)
			v1.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, arg2 and Color3.fromRGB(197, 255, 204) or Color3.fromRGB(255, 224, 180)),
				ColorSequenceKeypoint.new(num1, var2),
			})

		end

		arg1.BackgroundColor3 = var1
		if arg1.BG:FindFirstChild("Color") then
			if not arg1.BG.Color:FindFirstChild("TextLabel") then
				continue
			end

			arg1.BG.Color.TextLabel.TextColor3 = var1
		else
			if not arg1.BG:FindFirstChild("TextLabel") then
				continue
			end

			arg1.BG.TextLabel.TextColor3 = var1
		end
	end
end

return { Init = function(_)
	var4.Topbar.Rerolls.TextLabel.Text = var10.Value
	for k1, v1 in tbl2, nil do
		local var1 = var8:FindFirstChild(v1)
		if not var1 then
			continue
		end

		for k2, v2 in var1:GetChildren() do
			UpdateQuests(v1, v2)
			v2:WaitForChild("QuestProgress").Changed:Connect(function()
				UpdateQuests(v1, v2)
			end)

			v2:WaitForChild("QuestName").Changed:Connect(function()
				UpdateQuests(v1, v2)
			end)

			v2:WaitForChild("Claimed").Changed:Connect(function()
				UpdateQuests(v1, v2)
			end)

			v2:WaitForChild("QuestReward").Changed:Connect(function()
				UpdateQuests(v1, v2)
			end)

			v2:WaitForChild("RewardAmount").Changed:Connect(function()
				UpdateQuests(v1, v2)
			end)

		end
	end

	for k3, v3 in var4.Buttons:GetChildren() do
		if not v3:IsA("Frame") then
			continue
		end

		v3.Click.MouseButton1Click:Connect(function()
			for k1, v1 in var4.Buttons:GetChildren() do
				if not v1:IsA("Frame") then
					continue
				end

				local var1 = var4:FindFirstChild(v1.Name)
				var1.Visible = v3.Name == var1.Name
				UpdateButton(v1, v3.Name == var1.Name)
			end

			var4.TextLabel.Text = ("Resets in %*"):format((var3.Short.toTime((var4.Daily.Visible and var8.LastDailyReset.Value or var8.LastWeeklyReset.Value) - os.time())))
			TweenButton(v3)
		end)

		UpdateButton(v3, v3.Name == "Daily")
	end

	task.spawn(function()
		while true do
			if not task.wait(1) then
				break
			end

			if not var4.Visible then
				var4:GetPropertyChangedSignal("Visible"):Wait()
			end

			var4.TextLabel.Text = ("Resets in %*"):format((var3.Short.toTime((var4.Daily.Visible and var8.LastDailyReset.Value or var8.LastWeeklyReset.Value) - os.time())))
			var4.FreeReroll.Text = ("Free Reroll in: %*"):format((var3.Short.toTime(var8.DailyReroll.Value - os.time())))
		end
	end)

	var10.Changed:Connect(function()
		var4.Topbar.Rerolls.TextLabel.Text = var10.Value
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Rewards [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
var1.PlayerGui:WaitForChild("Front"):WaitForChild("MainFrame").Left.Buttons:WaitForChild("Rewards")
local var2 = require(game:GetService("ReplicatedStorage").Framework)
local var3 = var2.Stat.Get("ServerVerified")
local var4 = var1.PlayerGui:WaitForChild("Frames"):WaitForChild("Rewards").Background.Verification
local function UpdateUI()
	var4.Verified.Visible = var3.Value
	var4.Field.Visible = not var3.Value
	var4.Redeem.Visible = not var3.Value
end

local function ButtonClicked()
	if var3.Value then
		return
	end

	local var5 = var2.Network.Fire("ServerVerify", var4.Field.TextBox.Text)
	if var5 then
		var4.Field.TextBox.Text = var5
		task.wait(1.5)
		if var4.Field.TextBox.Text == var5 then
			var4.Field.TextBox.Text = ""
		end
	end
end

return { Init = function(_)
	var4.Verified.Visible = var3.Value
	var4.Field.Visible = not var3.Value
	var4.Redeem.Visible = not var3.Value
	var3.Changed:Connect(UpdateUI)
	var4.Redeem.MouseButton1Click:Connect(ButtonClicked)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Panel [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("ReplicatedStorage")
local var3 = require(var2.Framework)
local var4 = var1.LocalPlayer
var3.Stat.WaitForLoad(var4)
local var5 = var4:WaitForChild("PlayerGui")
local var6 = var5:WaitForChild("Front").MainFrame:WaitForChild("Admin")
local var7 = var5:WaitForChild("Frames"):WaitForChild("Panel")
local function GetMatches(arg1, arg2)
	local var1 = string.lower(arg2)
	local tbl1 = {}
	local tbl2 = {}
	for k1, v1 in arg1, nil do
		local var3 = string.find(string.lower(v1), var1, 1, true)
		if var3 == 1 then
			table.insert(tbl1, v1)
		elseif var3 then
			table.insert(tbl2, v1)
		end
	end

	table.sort(tbl1)
	table.sort(tbl2)
	local var4 = tbl2
	local num1 = 1
	local var5 = #tbl2
	local var6 = #tbl1 + 1
	local var7 = tbl1
	return table.move(var4, num1, var5, var6, var7)
end

local var8 = game:GetService("UserInputService")
local function UpdateAdminButton()
	var6.Visible = var4:GetAttribute("Admin") == true
end

local var9 = require(var2.Modules.Client.UI)
local function SetupAutofill(arg1, arg2)
	local var1 = Instance.new("Frame")
	var1.Name = arg1.Name .. "Suggestions"
	var1.AnchorPoint = Vector2.new(0.5, 0)
	var1.Position = UDim2.fromScale(arg1.Position.X.Scale - arg1.Size.X.Scale * arg1.AnchorPoint.X + arg1.Size.X.Scale / 2, arg1.Position.Y.Scale - arg1.Size.Y.Scale * arg1.AnchorPoint.Y + arg1.Size.Y.Scale + 0.01)
	var1.BackgroundColor3 = arg1.BackgroundColor3
	var1.ZIndex = 50
	var1.Visible = false
	local var2 = Instance.new("UICorner")
	var2.CornerRadius = UDim.new(0.1, 0)
	var2.Parent = var1
	local var3 = Instance.new("UIListLayout")
	var3.SortOrder = Enum.SortOrder.LayoutOrder
	var3.Parent = var1
	local tbl1 = {}
	local num1 = 1
	local str1 = ""
	local tbl2 = {}
	local tbl3 = {}
	local var4 = arg1.Size.X.Scale * 1.8
	local var5 = arg1.Size.Y.Scale * 0.6
	local var6 = nil
	local function Refresh()
		if arg1.Text ~= str1 then
			num1 = 1
			str1 = arg1.Text
			local var2 = if arg1.Text == "" then {} else GetMatches(tbl3, arg1.Text)
			tbl2 = var2
		end

		local var6 = math.min(#tbl2, 6)
		if var6 == 0 or #tbl2 == 1 and tbl2[1] == arg1.Text then
			var1.Visible = false
			return
		end

		for k1, v1 in tbl1, nil do
			v1.Visible = k1 <= var6
			v1.Text = tbl2[k1] or ""
			v1.Size = UDim2.fromScale(1, 1 / var6)
		end

		for k2, v2 in tbl1, nil do
			v2.BackgroundTransparency = if k2 == num1 then 0.8 else 1
		end

		var1.Size = UDim2.fromScale(var4, var5 * var6)
		var1.Visible = true
	end

	for i1 = 1, 6 do
		local var9 = Instance.new("TextButton")
		var9.Name = "Suggestion" .. i1
		var9.LayoutOrder = i1
		var9.AutoButtonColor = false
		var9.BackgroundColor3 = Color3.new(1, 1, 1)
		var9.BackgroundTransparency = 1
		var9.FontFace = arg1.FontFace
		var9.TextColor3 = arg1.TextColor3
		var9.TextScaled = true
		var9.ZIndex = 51
		var9.Parent = var1
		local var10 = Instance.new("UIPadding")
		var10.PaddingTop = UDim.new(0.15, 0)
		var10.PaddingBottom = UDim.new(0.15, 0)
		var10.Parent = var9
		var9.MouseEnter:Connect(function()
			var6 = i1
			num1 = i1
			for k1, v1 in tbl1, nil do
				v1.BackgroundTransparency = if k1 == num1 then 0.8 else 1
			end
		end)

		var9.MouseLeave:Connect(function()
			if var6 == i1 then
				var6 = nil
			end
		end)

		var9.MouseButton1Down:Connect(function()
			arg1.Text = var9.Text
			var1.Visible = false
		end)

		table.insert(tbl1, var9)
	end

	var1.Parent = var7
	arg1.Focused:Connect(function()
		tbl3 = arg2()
		str1 = nil
		Refresh()
	end)

	arg1:GetPropertyChangedSignal("Text"):Connect(function()
		if string.find(arg1.Text, "\t", 1, true) then
			arg1.Text = string.gsub(arg1.Text, "\t", "")
			return
		end

		if arg1:IsFocused() then
			Refresh()
		end
	end)

	var8.InputBegan:Connect(function(arg1)
		if not arg1:IsFocused() then
			return
		end

		if arg1.KeyCode == Enum.KeyCode.Tab then
			arg1:ReleaseFocus(true)
			return
		end

		if arg1.KeyCode == Enum.KeyCode.Down or arg1.KeyCode == Enum.KeyCode.Up then
			Refresh()
			if not var1.Visible then
				return
			end

			local var2 = math.min(#tbl2, 6)
			local var3 = num1
			local var4 = var3 - 1
			num1 = (var4 + (if arg1.KeyCode == Enum.KeyCode.Down then 1 else -1)) % var2 + 1
			for k1, v1 in tbl1, nil do
				v1.BackgroundTransparency = if k1 == num1 then 0.8 else 1
			end
		end
	end)

	arg1.FocusLost:Connect(function(arg1)
		if arg1.Text ~= str1 then
			num1 = 1
			str1 = arg1.Text
			local var2 = if arg1.Text == "" then {} else GetMatches(tbl3, arg1.Text)
			tbl2 = var2
		end

		local var3 = string.lower(arg1.Text)
		local var4 = if arg1 then tbl2[num1] else nil
		if not arg1 then
			for k1, v1 in tbl2, nil do
				if string.lower(v1) ~= var3 then
					continue
				end

				var4 = v1
				break
			end
		end

		if var4 then
			arg1.Text = var4
		end

		if var6 or var8:GetLastInputType() == Enum.UserInputType.Touch then
			task.delay(0.2, function()
				if not arg1:IsFocused() then
					var1.Visible = false
				end
			end)

			return
		end

		var1.Visible = false
	end)
end

local function GetStatNames()
	local var2 = var3.Stat.GetDataFolder(var4)
	local tbl1 = {}
	local tbl2 = {}
	if not var2 then
		return tbl1
	end

	for k1, v1 in var2:GetDescendants() do
		if not v1:IsA("ValueBase") then
			continue
		end

		if tbl2[v1.Name] then
			continue
		end

		tbl2[v1.Name] = true
		table.insert(tbl1, v1.Name)
	end

	return tbl1
end

local function GetPlayerNames()
	local tbl1 = {}
	for k1, v1 in var1:GetPlayers() do
		table.insert(tbl1, v1.Name)
	end

	return tbl1
end

local function Apply(arg1)
	local var1 = string.gsub(arg1.Name, "Apply", "")
	local var5 = var7:FindFirstChild(var1 .. "Stat")
	local var6 = var7:FindFirstChild(var1 .. "Amount")
	if not var5 or (not var6) then
		warn((("[Panel] no %*Stat / %*Amount to read from"):format(var1, var1)))
		return
	end

	local var9 = var7:FindFirstChild("Player")
	local var10 = var5.Text
	local var11 = var6.Text
	local var12 = if var9 then var9.Text else ""
	if var10 == "" or var11 == "" then
		return
	end

	var3.Sound.Play("UIClick")
	var3.Network.Fire("AdminPanel", var1, var10, var11, var12)
end

return { Init = function(_)
	local str1 = "Admin"
	var6.Visible = var4:GetAttribute(str1) == true
	var4:GetAttributeChangedSignal("Admin"):Connect(UpdateAdminButton)
	var6.MouseButton1Click:Connect(function()
		var3.Sound.Play("UIClick")
		var9.FrameOpenings.ToggleFrame(var7)
	end)

	var8.InputBegan:Connect(function(arg1, arg2)
		if arg2 or arg1.KeyCode ~= Enum.KeyCode.T then
			return
		end

		if var4:GetAttribute("Admin") ~= true then
			return
		end

		var3.Sound.Play("UIClick")
		var9.FrameOpenings.ToggleFrame(var7)
	end)

	for k1, v1 in var7:GetChildren() do
		if v1:IsA("TextBox") then
			v1.ClearTextOnFocus = false
			if string.find(v1.Name, "Stat$") then
				SetupAutofill(v1, GetStatNames)
			else
				if v1.Name ~= "Player" then
					continue
				end

				SetupAutofill(v1, GetPlayerNames)
				continue
			end
		else
			if not v1:IsA("TextButton") then
				continue
			end

			if v1.Name == "ImportMain" then
				v1.MouseButton1Click:Connect(function()
					var3.Sound.Play("UIClick")
					local var2 = var7:FindFirstChild("Player")
					local var4 = var3.Network.Fire
					local str1 = "ImportMainData"
					var4(str1, if var2 then var2.Text else "")
				end)

			else
				if not string.find(v1.Name, "Apply") then
					continue
				end

				v1.MouseButton1Click:Connect(function()
					Apply(v1)
				end)

			end
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.Frames.Shop [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("ReplicatedStorage")
local var3 = require(var2.Modules.Client.UI)
local var4 = var1.LocalPlayer
local var5 = var4:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("Shop")
local var6 = var5:WaitForChild("ShopGui")
local var7 = var5:WaitForChild("GiftGui")
local var8 = var7.content.main.bottomContent.offlineGift
local var9 = var7.content.main.players
local var10 = var6.main.items_frm
local var11 = var10.codes
local tbl1 = {}
local tbl2 = {}
local var12 = game:GetService("RunService")
local function StepFloat(arg1, arg2)
	local var1 = (arg1.Phase + arg2 / 2) % 1
	arg1.Phase = var1
	var1 = arg1.Card.AbsoluteSize.Y
	if var1 <= 0 then
		return
	end

	local var2 = math.sin(arg1.Phase * 3.1415926535897931 * 2)
	arg1.Object.Position = arg1.Base - UDim2.fromScale(0, (var2 + (math.asin(var2) * 2 / 3.1415926535897931 - var2) * 0.45) * arg1.Distance / var1)
end

local function StepShine(arg1, arg2)
	local var1 = (arg1.Clock + arg2) % arg1.Cycle
	arg1.Clock = var1
	if 3 <= arg1.Clock then
		arg1.Object.Position = UDim2.fromScale(-2, 0)
		return
	end

	var1 = arg1.Clock / 3
	arg1.Object.Position = UDim2.fromScale(-2 + (if var1 < 0.5 then 2 * var1 * var1 else 1 - (-2 * var1 + 2) ^ 2 / 2) * 4, 0)
end

local var13 = game:GetService("TweenService")
local var14 = require(var2.Framework)
local var15 = setmetatable({}, { __mode = "k" })
local tbl3 = {}
local var16 = game:GetService("MarketplaceService")
local var17 = require(var2.Modules.Shared.Robux)
local function SetPrice(arg1, arg2, arg3)
	local var2 = arg1:FindFirstChild("price", true)
	local var4 = if var2 and var2:IsA("GuiObject") then var2 else nil
	if var4 then
		if var4:IsA("TextLabel") then
			if not var15[var4] then
				var15[var4] = { Position = var4.Position, Size = var4.Size, Alignment = var4.TextXAlignment }
			end

			var2 = var15[var4]
			if arg3 then
				var4.Position = var2.Position
				var4.Size = var2.Size
				var4.TextXAlignment = var2.Alignment
			else
				var4.Position = UDim2.new(0, 0, var2.Position.Y.Scale, var2.Position.Y.Offset)
				var4.Size = UDim2.new(1, 0, var2.Size.Y.Scale, var2.Size.Y.Offset)
				var4.TextXAlignment = Enum.TextXAlignment.Center
			end

			var4.Text = arg2
		end
	end

	local var6 = arg1:FindFirstChild("robux_vct", true)
	var2 = if var6 and var6:IsA("GuiObject") then var6 else nil
	if var2 then
		var2.Visible = arg3
	end
end

local function SumPassPrices()
	local num1 = 0
	for k1, v1 in var17.Passes, nil do
		local var1 = v1.ID
		local var2 = Enum.InfoType.GamePass
		local var3 = ("%*:%*"):format(var1, var2.Name)
		if tbl3[var3] == nil then
			local success, result = pcall(var16.GetProductInfoAsync, var16, var1, var2)
			local var4 = tbl3
			var4[var3] = if success and result then result else false
		end

		local var6 = tbl3[var3]
		if not var6 then
			return nil
		end

		num1 = num1 + var6.PriceInRobux
	end

	return num1
end

local function SetPreviousPrice(arg1)
	if not arg1:GetAttribute("SumPasses") then
		return
	end

	local var2 = arg1:FindFirstChild("previousPrice", true)
	if not var2 then
		warn((("[Shop] %* is marked SumPasses but has no previousPrice to show it on"):format(arg1.Name)))
		return
	end

	local var4 = SumPassPrices()
	if not var4 then
		warn((("[Shop] could not price every gamepass, leaving %*'s previous price alone"):format(arg1.Name)))
		return
	end

	local var6 = var2:FindFirstChild("price", true)
	local var7 = tostring(var4)
	local var9 = if var6 and var6:IsA("GuiObject") then var6 else nil
	if var9 then
		if var9:IsA("TextLabel") then
			if not var15[var9] then
				var15[var9] = { Position = var9.Position, Size = var9.Size, Alignment = var9.TextXAlignment }
			end

			var6 = var15[var9]
			var9.Position = var6.Position
			var9.Size = var6.Size
			var9.TextXAlignment = var6.Alignment
			var9.Text = var7
		end
	end

	local var11 = var2:FindFirstChild("robux_vct", true)
	var6 = if var11 and var11:IsA("GuiObject") then var11 else nil
	if var6 then
		var6.Visible = true
	end
end

local bool1 = false
local var18 = var3.PopUps
local var19 = Color3.fromRGB(51, 255, 82)
local var20 = Color3.fromRGB(255, 56, 59)
local var21 = var11.code.code_txt
local var22 = nil
local bool2 = false
local var23 = var8.text.username
local var24 = var9:WaitForChild("Template")
local function RequestGift(arg1)
	if not var22 or bool2 then
		return
	end

	arg1 = arg1:gsub("^@", ""):match("^%s*(.-)%s*$")
	if arg1 == "" then
		var14.Sound.Play("CantAfford")
		return
	end

	bool2 = true
	var14.Network.Fire("GiftPass", var22, arg1)
	task.delay(10, function()
		bool2 = false
	end)
end

local function AnimateButton(arg1)
	local var1 = arg1:FindFirstChildOfClass("UIScale")
	var1 = var1 or Instance.new("UIScale", arg1)
	local function To(arg1, arg2)
		local var2 = TweenInfo.new(arg2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var13:Create(var1, var2, { Scale = arg1 }):Play()
	end

	arg1.MouseEnter:Connect(function()
		To(1.08, 0.12)
	end)

	arg1.MouseLeave:Connect(function()
		To(1, 0.12)
	end)

	arg1.MouseButton1Down:Connect(function()
		var14.Sound.Play("UIClick")
		To(0.9, 0.07)
	end)

	arg1.MouseButton1Up:Connect(function()
		To(1.08, 0.07)
	end)
end

local function FillGiftList()
	for k1, v1 in var9:GetChildren() do
		if not v1:IsA("GuiButton") or v1 == var24 then
			continue
		end

		v1:Destroy()
	end

	for k2, v2 in var1:GetPlayers() do
		if v2 == var4 then
			continue
		end

		local var2 = var24:Clone()
		var2.Name = v2.Name
		var2.Visible = true
		local str1 = "dropshadow"
		local var3 = var2:FindFirstChild(str1)
		local var5 = ("@%* (%*)"):format(v2.DisplayName, v2.Name)
		for k3, v3 in { var2:FindFirstChild("username"), var3 }, nil do
			if not v3 then
				continue
			end

			if not v3:IsA("TextLabel") then
				continue
			end

			v3.Text = var5
		end

		local var7 = var2:FindFirstChild("avatar")
		if var7 and var7:IsA("ImageLabel") then
			task.spawn(function()
				local success, result = pcall(var1.GetUserThumbnailAsync, var1, v2.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
				if success and var7.Parent then
					var7.Image = result
				end
			end)

		end

		var2.MouseButton1Click:Connect(function()
			RequestGift(v2.Name)
		end)

		var2.Parent = var9
		AnimateButton(var2)
	end
end

local function HandleGamepass(arg1, arg2, arg3)
	local var2 = var17.Passes[arg3]
	if not var2 then
		warn((("[Shop] %* asks for gamepass \"%*\", which is not in Shared.Robux.Passes"):format(arg1.Name, arg3)))
		return
	end

	local var3 = var2.ID
	local var5 = Enum.InfoType.GamePass
	local var6 = ("%*:%*"):format(var3, var5.Name)
	local var7 = if var2.DataName then var14.Stat.Get(var4, var2.DataName) else nil
	local str1 = "???"
	if tbl3[var6] == nil then
		local success, result = pcall(var16.GetProductInfoAsync, var16, var3, var5)
		local var8 = tbl3
		var8[var6] = if success and result then result else false
	end

	local var10 = tbl3[var6]
	if var10 then
		str1 = tostring(var10.PriceInRobux)
	end

	arg2.MouseButton1Click:Connect(function()
		if var7 and var7.Value then
			return
		end

		var16:PromptGamePassPurchase(var4, var2.ID)
	end)

	var3 = function()
		if var7 and var7.Value then
			SetPrice(arg2, "Owned", false)
			return
		end

		local var1 = arg2
		local var3 = var1:FindFirstChild("price", true)
		local var4 = str1
		local var6 = if var3 and var3:IsA("GuiObject") then var3 else nil
		if var6 then
			if var6:IsA("TextLabel") then
				if not var15[var6] then
					var15[var6] = { Position = var6.Position, Size = var6.Size, Alignment = var6.TextXAlignment }
				end

				var3 = var15[var6]
				var6.Position = var3.Position
				var6.Size = var3.Size
				var6.TextXAlignment = var3.Alignment
				var6.Text = var4
			end
		end

		local var9 = var1:FindFirstChild("robux_vct", true)
		var3 = if var9 and var9:IsA("GuiObject") then var9 else nil
		if var3 then
			var3.Visible = true
		end
	end

	if var7 then
		var7.Changed:Connect(var3)
	end

	if var7 and var7.Value then
		SetPrice(arg2, "Owned", false)
	else
		local var12 = arg2:FindFirstChild("price", true)
		var5 = str1
		var6 = if var12 and var12:IsA("GuiObject") then var12 else nil
		if var6 then
			if var6:IsA("TextLabel") then
				if not var15[var6] then
					var15[var6] = { Position = var6.Position, Size = var6.Size, Alignment = var6.TextXAlignment }
				end

				var12 = var15[var6]
				var6.Position = var12.Position
				var6.Size = var12.Size
				var6.TextXAlignment = var12.Alignment
				var6.Text = var5
			end
		end

		local var18 = arg2:FindFirstChild("robux_vct", true)
		var12 = if var18 and var18:IsA("GuiObject") then var18 else nil
		if var12 then
			var12.Visible = true
		end
	end
end

local function HandleProduct(arg1, arg2, arg3)
	local var1 = Enum.InfoType.Product
	local var2 = ("%*:%*"):format(arg3, var1.Name)
	local str1 = "???"
	if tbl3[var2] == nil then
		local success, result = pcall(var16.GetProductInfoAsync, var16, arg3, var1)
		local var3 = tbl3
		var3[var2] = if success and result then result else false
	end

	local var6 = tbl3[var2]
	if var6 then
		str1 = tostring(var6.PriceInRobux)
	else
		warn((("[Shop] %* asks for product %*, which the marketplace does not know"):format(arg1.Name, arg3)))
	end

	SetPreviousPrice(arg1)
	local var8 = arg2:FindFirstChild("price", true)
	var2 = if var8 and var8:IsA("GuiObject") then var8 else nil
	if var2 then
		if var2:IsA("TextLabel") then
			if not var15[var2] then
				var15[var2] = { Position = var2.Position, Size = var2.Size, Alignment = var2.TextXAlignment }
			end

			var8 = var15[var2]
			var2.Position = var8.Position
			var2.Size = var8.Size
			var2.TextXAlignment = var8.Alignment
			var2.Text = str1
		end
	end

	local var10 = arg2:FindFirstChild("robux_vct", true)
	var8 = if var10 and var10:IsA("GuiObject") then var10 else nil
	if var8 then
		var8.Visible = true
	end

	arg2.MouseButton1Click:Connect(function()
		var16:PromptProductPurchase(var4, arg3)
	end)
end

local var25 = var6.main.header.main.Close
local var26 = var7.content.main.bottomContent.Close
local function CloseGift()
	var7.Visible = false
	var22 = nil
	bool2 = false
end

local function CodeResult(arg1, arg2)
	bool1 = false
	local var1 = var18.NormalPopUp
	local var2 = arg2
	var1(var2, if arg1 then var19 else var20, 3)
	if arg1 then
		var21.Text = ""
	end
end

local var27 = var11.redeem_btn
local function Redeem()
	if bool1 then
		return
	end

	local var2 = var21.Text:match("^%s*(.-)%s*$")
	if var2 == "" then
		var14.Sound.Play("CantAfford")
		return
	end

	bool1 = true
	var14.Network.Fire("RedeemCode", var2)
	task.delay(5, function()
		bool1 = false
	end)
end

local function GiftResult(arg1, arg2)
	bool2 = false
	if not arg1 then
		var14.Sound.Play("CantAfford")
		var18.NormalPopUp(arg2, var20, 3)
		return
	end

	var23.Text = ""
	var7.Visible = false
	local var1 = var22
	var22 = nil
	bool2 = false
	if var1 then
		var16:PromptProductPurchase(var4, var1)
	end
end

local var28 = var8.Gift
local function SetupCards()
	for k1, v1 in var10:GetDescendants() do
		if not v1:IsA("GuiObject") then
			continue
		end

		local var4 = v1:GetAttribute("Gamepass")
		local var5 = v1:GetAttribute("Product")
		local var6 = v1:GetAttribute("GiftProduct")
		if not var4 then
			if var5 then
				local var11 = v1:FindFirstChild("price_btn", true)
				local var13 = if var11 and var11:IsA("GuiObject") then var11 else nil
				if not var13 or (not var13:IsA("GuiButton")) then
					warn((("[Shop] %* is priced but has no price_btn"):format(v1.Name)))
				elseif var4 then
					HandleGamepass(v1, var13, var4)
				else
					HandleProduct(v1, var13, var5)
				end
			end
		end

		if not var6 then
			continue
		end

		local var15 = v1:FindFirstChild("gift_btn", true)
		local var16 = if var15 and var15:IsA("GuiObject") then var15 else nil
		if not var16 then
			continue
		end

		if not var16:IsA("GuiButton") then
			continue
		end

		var16.MouseButton1Click:Connect(function()
			var22 = var6
			FillGiftList()
			var7.Visible = true
		end)

	end
end

local function StartAnimations()
	for k1, v1 in var10:GetDescendants() do
		if not v1:IsA("GuiObject") then
			continue
		end

		local var2 = v1:FindFirstChild("icon")
		if var2 and var2:IsA("GuiObject") then
			table.insert(tbl1, {
				Card = v1,
				Object = var2,
				Base = var2.Position,
				Distance = v1:GetAttribute("FloatDistance") or 5,
				Phase = 0,
			})

		end

		local var3 = v1:FindFirstChild("shine")
		if not var3 then
			continue
		end

		if not var3:IsA("GuiObject") then
			continue
		end

		if not v1:GetAttribute("Shine") then
			continue
		end

		local var4 = 4 + math.random() * 1
		table.insert(tbl2, { Object = var3, Cycle = var4, Clock = math.random() * var4 })
	end

	var12.RenderStepped:Connect(function(arg1)
		if not var5.Visible then
			return
		end

		for k1, v1 in tbl1, nil do
			StepFloat(v1, arg1)
		end

		for k2, v2 in tbl2, nil do
			StepShine(v2, arg1)
		end
	end)
end

return { Init = function(_)
	var25.MouseButton1Click:Connect(function()
		var7.Visible = false
		var22 = nil
		bool2 = false
		var3.FrameOpenings.CloseFrame(var5)
	end)

	var26.MouseButton1Click:Connect(CloseGift)
	if var21.Text == "Enter Code" then
		var21.Text = ""
	end

	var21.PlaceholderText = "Enter Code"
	var14.Network.Connect("RedeemCode", CodeResult)
	var27.MouseButton1Click:Connect(Redeem)
	var21.FocusLost:Connect(function(arg1)
		if arg1 then
			Redeem()
		end
	end)

	if var23.Text == "Enter a @username to gift offline" then
		var23.Text = ""
	end

	var23.PlaceholderText = "Enter a @username to gift offline"
	var14.Network.Connect("GiftPass", GiftResult)
	var28.MouseButton1Click:Connect(function()
		RequestGift(var23.Text)
	end)

	var23.FocusLost:Connect(function(arg1)
		if arg1 then
			RequestGift(var23.Text)
		end
	end)

	for k1, v1 in var5:GetDescendants() do
		if not v1:IsA("GuiButton") then
			continue
		end

		AnimateButton(v1)
	end

	SetupCards()
	StartAnimations()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.InitializeFeatures [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Modules.Shared.FeatureHandler)
return { Init = function(_)
	var2.Stat.WaitForLoad(var3)
	var4.InitializeFeatures()
	_ = var2.Stat.GetDataFolder(var3).TempValues
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Upgrades [ModuleScript]
-- y u r i

game:GetService("TweenService")
game:GetService("Debris")
game:GetService("RunService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
require(var3.UI)
local var4 = var2.Shared
require(var4.Multipliers)
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = var5.Stat.GetDataFolder(var6)
local var8 = require(var4.FeatureHandler)
local var9 = require(var3.Suffix)
local var10 = require(var4.BigNum)
local var11 = require(var4.Upgrades)
local var12 = require(var4.StatInformation)
local var13 = require(var3.Hover)
local var14 = require(var4.Colours)
local var15 = var1.Frames
local var16 = var1.Assets.Particles
local var17 = var7.TempValues
local tbl1 = { UpgradeCurrencies = {} }
for k1, v1 in var4.Upgrades:GetChildren() do
	table.insert(tbl1.UpgradeCurrencies, v1.Name)
end

local function UpdateUpgradeInfo(arg1, arg2, arg3, arg4, arg5)
	local var2 = var5.Stat.Get(var6, arg3)
	local var3 = arg1.Boost
	local var4 = arg1.Cost
	local var8 = arg1.Capacity
	local var11 = arg1.Buy
	local var13 = arg1.Max
	local var15 = arg2.Cap(var7)
	local var16 = arg2.Format
	local var17 = var12[arg4].Colour:ToHex()
	local var18 = var5.Stat.Get(var6, arg4)
	if not var2 then
		return
	end

	if not var18 then
		return
	end

	local var19 = arg2.Info(var2.Value).Price
	local var20 = arg2.Info(var2.Value).Reward
	local var21 = arg2.Info(var2.Value + 1).Reward
	var8.Text = "Level " .. var2.Value .. "/" .. var15
	if var2.Value < var15 then
		local var25 = var20
		local var26 = string.format(var16, var9.short(var25))
		local var27 = var21
		var3.Text = var26 .. " > " .. string.format(var16, var9.short(var27))
		var4.Text = ("Costs %* <font color=\"#%*\">%*</font>"):format(var9.short(var19), var17, arg5)
		if var10.gte(var18.Value, var19) then
			var11.UIGradient.Color = var14.Afford.Gradient
			var13.UIGradient.Color = var14.MaxButton.Gradient
			return
		end

		var11.UIGradient.Color = var14.Expensive.Gradient
		var13.UIGradient.Color = var14.Expensive.Gradient
		return
	end

	local var28 = var20
	var3.Text = string.format(var16, var9.short(var28))
	var4.Text = "MAX"
	var11.UIGradient.Color = var14.Maxed.Gradient
	var13.UIGradient.Color = var14.Maxed.Gradient
end

local function CreateButtonEffects(arg1)
	local var1 = arg1.Size
	arg1.MouseEnter:Connect(function()
		var13.Hover(arg1, var1)
	end)

	arg1.MouseLeave:Connect(function()
		var13.Up(arg1, var1)
	end)

	arg1.MouseButton1Down:Connect(function()
		var13.Down(arg1, var1)
	end)

	arg1.MouseButton1Up:Connect(function()
		var13.Up(arg1, var1)
	end)
end

local function Upgraded()
	var5.Sound.Play("Upgrade")
	var5.VFX.Emit(var6.Character.HumanoidRootPart, var16.Upgrade)
end

local function DisplayUpgrades(arg1)
	local var1 = var11[arg1]
	local var2 = var8.GetFeature(var1.Board)
	local var3 = var2.Board.SurfaceGui.Frame
	local var4 = var2[arg1]
	local var10 = var5.Stat.Get(var6, arg1)
	local var13 = var1.Display
	for k1, v1 in var1.Upgrades, nil do
		local var14 = var15.Upgrade:Clone()
		local var16 = v1.Icon
		local var18 = var14.Buy
		local var19 = var14.Max
		local var20 = var14.ImageLabel
		local var21 = var14.Upgrade
		local var22 = v1.Display
		local var23 = v1.ChangeStat
		local var24 = v1.Rank
		local var25 = nil
		local var26 = var5.Stat.Get(var6, k1)
		local var27 = var5.Stat.Get(var6, var23)
		var14.Parent = var3.Main
		var14.Name = k1
		var14.LayoutOrder = var24
		var21.Text = var22
		var21.TextLabel.Text = var22
		var20.Image = if var12[var16] ~= nil then var12[var16].Icon else var16
		var10.Changed:Connect(function()
			UpdateUpgradeInfo(var14, v1, k1, arg1, var13)
			var4.SurfaceGui.Frame.TextLabel.Text = var9.short(var5.Stat.Get(var6, arg1).Value)
		end)

		var26.Changed:Connect(function()
			UpdateUpgradeInfo(var14, v1, k1, arg1, var13)
		end)

		var27.Changed:Connect(function()
			var14.Visible = v1.Unlocked(var7)
			UpdateUpgradeInfo(var14, v1, k1, arg1, var13)
		end)

		var18.MouseButton1Click:Connect(function()
			var5.Sound.Play("UIClick")
			var5.Network.Fire("Upgrade", arg1, k1, false)
		end)

		var19.MouseButton1Click:Connect(function()
			var5.Sound.Play("UIClick")
			var5.Network.Fire("Upgrade", arg1, k1, true)
		end)

		var4.SurfaceGui.Frame.TextLabel.Text = var9.short(var5.Stat.Get(var6, arg1).Value)
		UpdateUpgradeInfo(var14, v1, k1, arg1, var13)
		CreateButtonEffects(var18)
		CreateButtonEffects(var19)
		var14.Visible = v1.Unlocked(var7)
	end
end

tbl1.Init = function(_)
	repeat
		task.wait()
	until var17:WaitForChild("FeaturesLoaded").Value

	var5.Network.Connect("Upgrade", Upgraded)
	for k1, v1 in tbl1.UpgradeCurrencies, nil do
		DisplayUpgrades(v1)
	end
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.LeaderBoards [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
local var4 = workspace.Leaderboards
local var5 = require(var1.Modules.Client.ConsoleScroll)
return { Init = function(_)
	var2.Stat.WaitForLoad(var3)
	task.spawn(function()
		task.wait(10)
		while var3 and var3.Parent do
			for k1, v1 in var4:GetChildren() do
				local var1 = v1:WaitForChild("Place").SurfaceGui.Frame
				local var2 = nil
				for k2, v2 in v1:WaitForChild("Board").SurfaceGui.Main.Scroll.GlobalContainer:GetChildren() do
					if not v2:IsA("Frame") then
						continue
					end

					if not v2:FindFirstChild("Username") then
						continue
					end

					if v2.Username.Text ~= var3.Name then
						continue
					end

					var2 = v2.Rank.Text
					break
				end

				if var2 then
					if v1.Name == "HighestCash" then
						var1.TextLabel.Text = var2 .. " (Global)"
					else
						var1.TextLabel.Text = var2
						continue
					end
				else
					var1.TextLabel.Text = "# >100"
				end
			end

			task.wait(30)
		end
	end)

	for k1, v1 in var4:GetChildren() do
		local var1 = v1:WaitForChild("Board").SurfaceGui.Main
		local var6 = var1.Title.Title
		var5.SetupScroll(v1.Board.SurfaceGui.Scroll, var1.Scroll)
		if var1:FindFirstChild("Buttons") == nil then
			continue
		end

		local var7 = var1.Buttons
		local var8 = var1.Scroll.F2PContainer
		local var9 = var1.Scroll.GlobalContainer
		var7.Free.MouseButton1Click:Connect(function()
			if var8.Visible then
				return
			end

			var9.Visible = false
			var8.Visible = true
			local var1 = var6
			local var2 = var1.Text .. " (F2P)"
			var1.Text = var2
			var1 = var6.TextLabel
			var2 = var1.Text .. " (F2P)"
			var1.Text = var2
		end)

		local var10 = var6.Text
		var7.Global.MouseButton1Click:Connect(function()
			if var9.Visible then
				return
			end

			var9.Visible = true
			var8.Visible = false
			var6.Text = var10
			var6.TextLabel.Text = var10
		end)

	end

	_ = v1:WaitForChild("Place").SurfaceGui.Frame
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.SeedHandler [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = workspace.MapEssentials.Seed
local var4 = var3.Holder.SeedHolderGui
local var5 = var4.Frame.Progressbar
local var6 = require(var1.Framework)
local var7 = var2:WaitForChild("PlayerGui"):WaitForChild("SeedButtonGui")
local var8 = var7.Buy
local var10 = var8:FindFirstChild("PressE")
local var11 = require(var1.Modules.Shared.Seeds)
local var12 = require(var1.Modules.Client.Suffix)
local var13 = require(var1.Modules.Shared.BigNum)
local var14 = require(var1.Modules.Shared.Colours)
local var15 = require(var1.Modules.Client.UI).PopUps
local var16 = var3:WaitForChild("Holder").CFrame
local var17 = var5.Bar
local var18 = var5.Progress
local var19 = var3.Holder.ProximityPrompt
local var20 = var6.Stat.Get("Cash")
local var21 = var6.Stat.Get("Seed")
local var22 = var6.Stat.Get("SeedLevel")
local var23 = var6.Stat.Get("ScientificNotation")
local var24 = var6.Stat.Get("Device")
local var25 = TweenInfo.new(0.26, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local var26 = TweenInfo.new(0.26, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local var27 = if var10 then var10.TextLabel:FindFirstChildWhichIsA("UIStroke") else nil
local tbl1 = { Afford = Color3.fromRGB(11, 152, 9) }
tbl1.Expensive = Color3.fromRGB(152, 9, 30)
tbl1.Evolve = Color3.fromRGB(35, 9, 152)
local bool1 = false
local bool2 = false
local function UpdateProgressColour(arg1)
	local var1 = arg1 * 0.26
	local var2 = var1
	local num1 = 0.7
	local num2 = 1
	local var3 = ColorSequenceKeypoint.new(0, Color3.fromHSV(var2, num1, num2))
	num1 = var1
	num2 = 1
	local num3 = 0.7
	local var4 = ColorSequenceKeypoint.new(0.5, Color3.fromHSV(num1, num2, num3))
	num2 = var1
	num3 = 0.7
	local num4 = 1
	var2 = 1
	var17.UIGradient.Color = ColorSequence.new({ var3, var4, ColorSequenceKeypoint.new(var2, Color3.fromHSV(num2, num3, num4)) })
	var17.UIStroke.Color = Color3.fromHSV(var1, 1, 0.67)
end

local function ShowBuy()
	local var1 = var21.Value
	local bool3 = false
	if var11.Seeds[var1].Levels <= var22.Value then
		bool3 = not var11.Seeds[var1 + 1]
	end

	bool1 = true
	var8.Visible = not bool3
	var8.UIScale.Scale = 0
	var6.Tween.Play(var8.UIScale, var25, { Scale = 1 })
end

local function UpdateSeedModel()
	local var2 = var21.Value
	local var6 = var11.Seeds[var2]
	if not var6 then
		warn("Seed info not found for: " .. var2)
		return
	end

	local var8 = var6.Seed
	local var10 = var1.Assets.Seeds.Main:FindFirstChild(var8)
	if not var10 then
		warn("Seed model not found for: " .. var8)
		return
	end

	local var13 = var3:FindFirstChild("Seed")
	if var13 then
		var19.Parent = var3.Holder
		var13:Destroy()
	end

	local var14 = var10.CFrame
	local var15 = var14.Position.Y - (var14.Position.Y - var10.Size.Y / 2)
	var10 = var10:Clone()
	var10.Name = "Seed"
	var10.CFrame = var16 * CFrame.new(0, var15 + 0.18, 0)
	var10.Parent = var3
	var4.Adornee = var10
	var7.Adornee = var10
	var4.StudsOffsetWorldSpace = vector.create(0, var10.Size.Y / 1.5 + 1, 0)
	var7.StudsOffsetWorldSpace = Vector3.new(0, 0, 0)
	var19.Parent = var10
end

local function UpdateSeedInfo()
	var20 = var6.Stat.Get(var2, "Cash")
	local var1 = var21.Value
	local var7 = var11.Seeds[var1]
	if not var7 then
		warn("Seed info not found for: " .. var1)
		return
	end

	local var9 = var7.Levels <= var22.Value
	local var16 = var7.Price(var2)
	var16 = var9 and var7.EvolvePrice
	local var19 = var13.gte(var20.Value, var16)
	local var24 = var19 and var9
	local var25 = var7.Seed
	local var26 = not var11.Seeds[var1 + 1]
	if var24 then
		if not var26 then
			if not bool2 then
				bool2 = true
				var15.NormalPopUp("You can evolve your seed!", var14.Evolve.Colour, 3.5)
			end
		else
			bool2 = false
		end
	else
		bool2 = false
	end

	var4.Frame.Level.Text = ("Level %*/%*"):format(var22.Value, var7.Levels)
	local var28 = var4.Frame.Seed
	local str1 = "%*%*"
	local var29 = var25
	var28.Text = str1:format(var29, if var9 then " [MAXED]" else "")
	var4.Frame.Seed.TextColor3 = var7.Colour
	var8.Stat.Boost.Text = var12.short(var16)
	str1 = var19
	var8.Green.Enabled = str1 and (not var24)
	var8.Purple.Enabled = var19 and var24
	var8.Evolve.Visible = var19 and var24
	var8.Red.Enabled = not var19
	if var10 then
		str1 = var19
		var10.Green.Enabled = str1 and (not var24)
		var10.Purple.Enabled = var19 and var24
		var10.Red.Enabled = not var19
	end

	if var27 then
		var28 = var27
		if var24 then
			str1 = tbl1.Evolve
		elseif var19 then
			str1 = tbl1.Afford
		else
			str1 = tbl1.Expensive
		end

		var28.Color = str1
	end

	local var30 = var20.Value
	var29 = var16
	var28 = var13.toNumber(var13.div(var30, var29))
	var30 = math.clamp(var28, 0, 1)
	var17:TweenSize(UDim2.new(var30, 0, 1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.05, true)
	UpdateProgressColour(var30)
	var18.Text = var6.Short.toSuffix((math.clamp(var28 * 100, 0, 100))) .. "%"
	var29 = var9
	var29 = var29 and (not var11.Seeds[var1 + 1])
	var5.Visible = not var29
	if var29 then
		bool1 = false
		var8.Visible = false
		return
	end

	if bool1 and (not var8.Visible) then
		ShowBuy()
	end
end

var6.Network.Connect("UpgradeSeed", function(arg1, _)
	if arg1 then
		UpdateSeedModel()
		var6.Sound.Play("NewHighestSeed", var3.Seed)
	else
		var6.Sound.Play("UpgradeSeed", var3.Seed)
	end

	UpdateSeedInfo()
	var6.VFX.Emit(var3.Seed, var1.Assets.Particles.UpgradeSeed)
	if arg1 then
		var6.VFX.Emit(var3.Seed, var1.Assets.Particles.Evolve)
	end
end)

local function HideBuy()
	bool1 = false
	var6.Tween.Play(var8.UIScale, var26, { Scale = 0 })
	task.wait(var26.Time + 0.05)
	if not bool1 then
		var8.Visible = false
	end
end

local function UpdatePressEVisibility()
	if not var10 then
		return
	end

	local var2 = var24.Value
	local var3 = var10
	local bool1 = true
	if var2 ~= "Mobile" then
		bool1 = var2 == "Console"
	end

	var3.Visible = not bool1
end

local function TweenButton(arg1)
	local var1 = TweenInfo.new(0.1)
	var6.Tween.Play(var8.UIScale, var1, { Scale = arg1 })
end

return { Init = function(_)
	var19.PromptShown:Connect(ShowBuy)
	var19.PromptHidden:Connect(HideBuy)
	var20.Changed:Connect(UpdateSeedInfo)
	var23.Changed:Connect(UpdateSeedInfo)
	var22.Changed:Connect(UpdateSeedInfo)
	var24.Changed:Connect(UpdatePressEVisibility)
	if not var10 then
	else
		local var2 = var24.Value
		local var3 = var10
		local bool1 = true
		if var2 ~= "Mobile" then
			bool1 = var2 == "Console"
		end

		var3.Visible = not bool1
	end

	var21.Changed:Connect(function()
		UpdateSeedInfo()
		UpdateSeedModel()
	end)

	UpdateSeedModel()
	UpdateSeedInfo()
	var8.MouseButton1Click:Connect(function()
		if not var8.Visible then
			return
		end

		var6.Network.Fire("UpgradeSeed")
	end)

	var19.Triggered:Connect(function()
		if not var8.Visible then
			return
		end

		var6.Tween.Play(var8.UIScale, TweenInfo.new(0.1), { Scale = 0.9 })
		task.delay(0.1, TweenButton, 1)
		if not var8.Visible then
			return
		end

		var6.Network.Fire("UpgradeSeed")
	end)

	var8.MouseEnter:Connect(function()
		var6.Tween.Play(var8.UIScale, TweenInfo.new(0.1), { Scale = 1.1 })
	end)

	var8.MouseLeave:Connect(function()
		var6.Tween.Play(var8.UIScale, TweenInfo.new(0.1), { Scale = 1 })
	end)

	var8.MouseButton1Down:Connect(function()
		var6.Tween.Play(var8.UIScale, TweenInfo.new(0.1), { Scale = 0.9 })
	end)

	var8.MouseButton1Up:Connect(function()
		var6.Tween.Play(var8.UIScale, TweenInfo.new(0.1), { Scale = 1 })
	end)

	var19.Enabled = false
	task.wait()
	var19.Enabled = true
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.UpgradeTree [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
game:GetService("UserInputService")
local var2 = game:GetService("ReplicatedStorage")
local var3 = var2.Modules
local var4 = var3.Client
local var5 = var3.Shared
require(var5.Requirements)
require(var5.Multipliers)
require(var4.Hover)
local var6 = require(var2.Framework)
local var7 = var1.LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = var6.Stat.GetDataFolder(var7)
local var9 = require(var5.StatInformation)
local var10 = require(var4.Suffix)
local var11 = require(var5.BigNum)
local var12 = require(var5.Colours)
local var13 = game:GetService("TweenService")
local var14 = TweenInfo.new(0.05, Enum.EasingStyle.Bounce, Enum.EasingDirection.InOut, 0, true)
local var15 = workspace.MapEssentials.UpgradeTree
local var16 = var2.Assets.Particles
local tbl1 = {}
local var17 = require(var4.UI).PopUps
local function Upgraded(arg1)
	var6.Sound.Play("Upgrade")
	var6.VFX.Emit(var7.Character.HumanoidRootPart, var16.Upgrade)
	local var1 = var15[arg1].Holder
	var13:Create(var1, var14, { Size = var1.Size + Vector3.new(1, 0, 1) }):Play()
end

local var18 = require(var5.UpgradeTree)
local bool1 = false
local function UpdateFrame(arg1, arg2, arg3)
	local var1 = arg3.Currency
	local var5 = arg3.DisplayCurrency
	local var11 = var6.Stat.Get(var7, arg2)
	local var12 = arg1.Price
	local var13 = arg1.Boost
	local var14 = arg1.UpgradeName
	local var15 = arg3.RewardDisplay
	local var16 = arg3.Price(var7)
	local var17 = arg3.Reward(var7)
	local var18 = arg3.Formatted
	local var19 = arg3.Display
	local var20 = arg3.Order
	local var21 = arg3.Cap(var8)
	local var22 = var9[var1].Colour:ToHex()
	if var5 == nil then
		var12.Text = ("Cost: %* <font color=\"#%*\">%*</font>"):format(var10.short(var16), var22, var1)
	else
		var12.Text = ("Cost: %* <font color=\"#%*\">%*</font>"):format(var10.short(var16), var22, var5)
	end

	var13.Text = var15
	if var18 ~= nil and 1 <= var11.Value then
		local var24 = var17
		var13.Text = string.format(var18, var10.short(var24))
	end

	if 1 < var21 then
		var14.Text = "[" .. var20 .. "] " .. var19 .. " (" .. var11.Value .. "/" .. var21 .. ")"
	end

	if var21 <= var11.Value then
		var12.Text = "MAXED"
	end
end

local function UpdateColouring(arg1, arg2, arg3)
	local var1 = var6.Stat.Get(var7, arg2)
	local var4 = arg3.Price(var7)
	local var5 = arg3.Cap(var8)
	local var9 = var6.Stat.Get(var7, arg3.Currency)
	if var1.Value < 1 then
		if var11.gte(var9.Value, var4) then
			arg1.Color = var12.UpgradeTree.Visible
			return
		end

		arg1.Color = var12.Expensive.Colour
		return
	end

	if var1.Value < var5 then
		if var11.gte(var9.Value, var4) then
			arg1.Color = var12.UpgradeTree.Visible
			return
		end

		arg1.Color = var12.Expensive.Colour
		return
	end

	arg1.Color = var12.UpgradeTree.Purchased
end

local function HandleNotification(arg1, arg2)
	local var1 = arg2.Cap(var8)
	local var2 = arg2.Unlocked(var8)
	local var3 = var6.Stat.Get(var7, arg1)
	if var11.gte(var6.Stat.Get(var7, arg2.Currency).Value, (arg2.Price(var7))) then
		if var3.Value < var1 then
			if var2 then
				if tbl1[arg1] ~= false then
					return
				end

				tbl1[arg1] = true
				task.spawn(function()
					var17.NormalPopUp("You can afford a Tree Upgrade!", Color3.fromRGB(123, 255, 121), 3.5)
				end)

				return
			end
		end
	end

	tbl1[arg1] = false
end

local var19 = var7:GetMouse().Icon
return { Init = function(_)
	var6.Network.Connect("TreeUpgrade", Upgraded)
	for k1, v1 in var18, nil do
		local var3 = var15[k1]
		if not var3 then
			print(k1 .. " Doesn't exist")
		else
			local var4 = var3:WaitForChild("Holder")
			local var5 = var4.SurfaceGui.Frame.items
			v1.Price(var7)
			local var9 = v1.Currency
			local var11 = var6.Stat.Get(var7, var9)
			local var12 = var6.Stat.Get(var7, k1)
			local var13 = var5.UpgradeName
			local var14 = v1.Display
			local var16 = v1.Order
			local var17 = v1.RewardChange
			local var19 = var6.Stat.Get(var7, v1.ChangeStat)
			if not var11 then
				print(var9)
			else
				var13.Text = "[" .. var16 .. "] " .. var14
				tbl1[k1] = false
				var4.Touched:Connect(function(arg1)
					local var3 = var1:GetPlayerFromCharacter(arg1.Parent)
					if not var3 then
						return
					end

					if var3 ~= var7 then
						return
					end

					if var4.Transparency == 1 then
						return
					end

					if v1.Cap(var8) <= var12.Value then
						return
					end

					if not bool1 then
						bool1 = true
						var6.Network.Fire("TreeUpgrade", k1)
						task.wait(0.05)
						bool1 = false
					end
				end)

				if var17 ~= nil then
					var6.Stat.Get(var7, var17).Changed:Connect(function()
						UpdateFrame(var5, k1, v1)
					end)

				end

				var12.Changed:Connect(function()
					UpdateFrame(var5, k1, v1)
					local var2 = v1.Unlocked(var8)
					local var3 = var4
					local var9 = var6.Stat.Get(var7, k1)
					if not var2 then
						var2 = 1 <= var9.Value
					end

					if not var2 then
						var3.Transparency = 1
						var3.CanCollide = false
						var3.SurfaceGui.Enabled = false
					else
						var3.Transparency = 0
						var3.CanCollide = true
						var3.SurfaceGui.Enabled = true
					end

					UpdateColouring(var4, k1, v1)
				end)

				var19.Changed:Connect(function()
					local var2 = v1.Unlocked(var8)
					local var3 = var4
					local var5 = var6.Stat.Get(var7, k1)
					if not var2 then
						var2 = 1 <= var5.Value
					end

					if not var2 then
						var3.Transparency = 1
						var3.CanCollide = false
						var3.SurfaceGui.Enabled = false
					else
						var3.Transparency = 0
						var3.CanCollide = true
						var3.SurfaceGui.Enabled = true
					end

					UpdateColouring(var4, k1, v1)
				end)

				var11.Changed:Connect(function()
					local var2 = v1.Unlocked(var8)
					local var3 = var4
					local var5 = var6.Stat.Get(var7, k1)
					if not var2 then
						var2 = 1 <= var5.Value
					end

					if not var2 then
						var3.Transparency = 1
						var3.CanCollide = false
						var3.SurfaceGui.Enabled = false
					else
						var3.Transparency = 0
						var3.CanCollide = true
						var3.SurfaceGui.Enabled = true
					end

					UpdateColouring(var4, k1, v1)
					HandleNotification(k1, v1)
				end)

				HandleNotification(k1, v1)
				UpdateFrame(var5, k1, v1)
				local var21 = v1.Unlocked(var8)
				local var22 = var6.Stat.Get(var7, k1)
				if not var21 then
					var21 = 1 <= var22.Value
				end

				if not var21 then
					var4.Transparency = 1
					var4.CanCollide = false
					var4.SurfaceGui.Enabled = false
				else
					var4.Transparency = 0
					var4.CanCollide = true
					var4.SurfaceGui.Enabled = true
				end

				UpdateColouring(var4, k1, v1)
			end
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Water [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.Requirements)
require(var4.FeatureHandler)
require(var4.Colours)
require(var3.Hover)
local var5 = var1.Assets
local var6 = workspace.Features:FindFirstChild("Water")
local var7 = (var6 or var5.Features:FindFirstChild("Water")):WaitForChild("Water")
local var8 = var7.InfoGui.Frame
local var9 = var8.Progressbar
local var10 = require(var4.Water)
local var11 = require(var1.Framework)
local var12 = game:GetService("Players").LocalPlayer
local var13 = var5.Particles
local tbl1 = {}
local var14 = nil
local var15 = game:GetService("TweenService")
local var16 = TweenInfo.new(0.1, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)
local var17 = var7.Size
local var18 = var11.Stat.Get(var12, "PopUpsSetting")
local var19 = var1.Frames.CollectPopUp
local var20 = require(var3.Suffix)
local var21 = require(var4.StatInformation)
local var22 = var11.Stat.Get(var12, "VFXSetting")
local function PlayWaterSplash(arg1)
	for k1, v1 in tbl1, nil do
		if v1:GetAttribute("EmitCount") then
			local str2 = "EmitCount"
			v1:Emit(v1:GetAttribute(str2))
		else
			v1:Emit(arg1 or 5)
		end
	end
end

local function PlayWaterPop()
	local var1 = var15:Create(var7, var16, { Size = var17 * 1.09 })
	var1:Play()
	var1.Completed:Once(function()
		var15:Create(var7, var16, { Size = var17 }):Play()
	end)
end

local function PlayRewardPopup(arg1)
	if not var18.Value then
		return
	end

	local var1 = Instance.new("Attachment")
	var1.Position = Vector3.new(math.random(-15, 15) / 10, var7.Size.Y / 2, 0)
	var1.Parent = var7
	local var2 = var19:Clone()
	var2.Adornee = var1
	var2.Parent = var1
	local var3 = var2.Frame.Reward1
	var3.Text = "+" .. var20.short(arg1) .. " Water"
	var3.TextColor3 = var21.Water.Colour
	var15:Create(var2, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { StudsOffsetWorldSpace = Vector3.new(0, 3, 0) }):Play()
	local var4 = var15:Create(var3, TweenInfo.new(0.8, Enum.EasingStyle.Linear), { TextTransparency = 1, TextStrokeTransparency = 1 })
	var4:Play()
	var15:Create(var3.UIStroke, TweenInfo.new(0.8, Enum.EasingStyle.Linear), { Transparency = 1 }):Play()
	var4.Completed:Once(function()
		var1:Destroy()
	end)
end

local var23 = require(var4.Multipliers)
local var24 = var10.Max
local var25 = require(var4.BigNum)
local var26 = var8.Level
local var27 = var9.Bar
local var28 = var9.Progress
local function HandleClick(arg1)
	local var1 = var11.Stat.Get(var12, "WaterLevel")
	if var22.Value then
		var14:Emit((math.clamp(var1.Value, 2, 10)))
		PlayWaterSplash()
	end

	var11.Sound.Play("Water", var7)
	PlayWaterPop()
	PlayRewardPopup(arg1)
end

local function HandleLevelUp()
	var11.Sound.Play("WaterLevelUp", var7)
	var11.VFX.Emit(var7, var13.WaterLevelUp, 10)
end

local var29 = var7.ProximityPrompt
local function UpdateModel()
	var23.GetWaterMultiplier(var12)
	local var1 = var11.Stat.Get(var12, "WaterLevel")
	local var2 = var11.Stat.Get(var12, "WaterXP")
	local var3 = var10[math.min(var1.Value, var24)].Price
	local var4 = var2.Value
	local var5 = var3
	local var6 = var25.toNumber(var25.div(var4, var5))
	local var7 = math.clamp(var6, 0, 1)
	var26.Text = "Level " .. var1.Value
	var27:TweenSize(UDim2.new(var7, 0, 1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.07, true)
	if var24 < var1.Value then
		var28.Text = ("%* XP [MAXED]"):format((var20.short(var2.Value)))
		return
	end

	var28.Text = ("%* / %* XP"):format(var20.short(var2.Value), (var20.short(var3)))
end

local function SetupDropletEmitter()
	local var1 = Instance.new("Attachment")
	var1.Name = "DropletPoint"
	var1.Position = Vector3.new(0, var7.Size.Y / 3, 0)
	var1.Parent = var7
	var14 = Instance.new("ParticleEmitter")
	var14.Texture = "rbxassetid://113668091012536"
	var14.Enabled = false
	var14.Rate = 0
	var14.Lifetime = NumberRange.new(0.5, 0.9)
	var14.Speed = NumberRange.new(6, 12)
	var14.SpreadAngle = Vector2.new(180, 180)
	var14.EmissionDirection = Enum.NormalId.Top
	var14.Acceleration = Vector3.new(0, -60, 0)
	var14.Rotation = NumberRange.new(-45, 45)
	var14.RotSpeed = NumberRange.new(-60, 60)
	local num1 = 1
	local num2 = 0.25
	var14.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(num1, num2) })
	num2 = 1
	local num3 = 1
	var14.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.7, 0),
		NumberSequenceKeypoint.new(num2, num3),
	})

	var14.Parent = var1
end

local function SetupWaterSplashEmitters()
	local var1 = Instance.new("Attachment")
	var1.Name = "SplashPoint"
	var1.Parent = var7
	for k1, v1 in var13.Water:GetDescendants() do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		local var2 = v1:Clone()
		var2.Parent = var1
		table.insert(tbl1, var2)
	end
end

local var30 = require(var3.UI).PopUps
return { Init = function(_)
	var11.Stat.WaitForLoad(var12)
	var11.Network.Connect("Water", HandleClick)
	var11.Network.Connect("WaterLevel", HandleLevelUp)
	local var1 = var11.Stat.GetDataFolder(var12).TempValues
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	local var2 = var11.Stat.Get(var12, "Device")
	local var4 = var2.Value
	local var5 = var11.Stat.Get(var12, "Water")
	local var6 = var11.Stat.Get(var12, "WaterLevel")
	local var7 = var29
	local bool1 = true
	if var4 ~= "Mobile" then
		bool1 = var4 == "Console"
	end

	var7.Enabled = bool1
	var29.Triggered:Connect(function()
		var11.Network.Fire("Water")
	end)

	var2.Changed:Connect(function()
		local var3 = var2.Value
		local var4 = var29
		local bool1 = true
		if var3 ~= "Mobile" then
			bool1 = var3 == "Console"
		end

		var4.Enabled = bool1
	end)

	var5.Changed:Connect(UpdateModel)
	var6.Changed:Connect(UpdateModel)
	UpdateModel()
	SetupDropletEmitter()
	SetupWaterSplashEmitters()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Tree [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.Requirements)
require(var4.FeatureHandler)
require(var3.Hover)
require(var1.Modules.Client.Binder)
local var5 = var1.Assets
local var6 = workspace.Features:FindFirstChild("Tree")
var6 = var6 or var5.Features:FindFirstChild("Tree")
local var7 = var6.Upgrading:WaitForChild("Ring"):WaitForChild("Main")
local var8 = var7.BillboardGui
local var9 = require(var1.Framework)
local var10 = game:GetService("Players").LocalPlayer
var9.Stat.Get(var10, "PopUpsSetting")
var9.Stat.Get(var10, "TreeComboUpdated")
local var11 = var9.Stat.Get(var10, "TreeLevel")
local var12 = require(var4.Tree)
local var13 = var8.WaterFrame.Amount
local var14 = require(var4.BigNum)
local var15 = require(var3.Suffix)
local var16 = nil
local var17 = var5.Particles
local bool1 = false
local bool2 = false
local var18 = require(var4.Colours)
local bool3 = false
local var19 = var7.Color
local var20 = require(var4.Features)
local bool4 = false
local var21 = var9.Stat.Get(var10, "Water")
local var22 = require(var3.UI).PopUps
local var23 = require(var4.StatInformation)
local var24 = nil
local tbl1 = {}
local var25 = var1.Assets.SwingAnim
local var26 = nil
local var27 = var9.Stat.Get(var10, "VFXSetting")
local tbl2 = {}
local var28 = nil
local var29 = game:GetService("TweenService")
local var30 = game:GetService("UserInputService")
local var31 = require(var4.Multipliers)
local var32 = require(var1.Modules.Client.DropCurrency)
local var33 = var10:WaitForChild("PlayerGui"):WaitForChild("Front"):WaitForChild("MainFrame"):WaitForChild("ComboBar")
local var34 = var10:GetMouse()
local var35 = var9.Stat.Get(var10, "AttackingTree")
local var36 = var9.Stat.Get(var10, "TreeComboMultiplier")
local var37 = Instance.new("UIScale")
var37.Parent = var13
local var38 = nil
local var39 = nil
var37 = {}
local var40 = var1.Assets.TreeHighlight
var39 = function(arg1)
	local var1 = arg1:GetPivot().Position
	local var2 = RaycastParams.new()
	var2.IncludeInstances = { arg1 }
	local var4 = workspace:Raycast(var1, Vector3.new(0, -2000, 0), var2)
	if var4 then
		return var4.Position.Y
	end
end

local var41 = nil
local var42 = nil
local bool5 = false
local function SetChoppingState(arg1)
	local var2 = var6.Tree:FindFirstChild("Model")
	if not var2 then
		return
	end

	var9.Network.Fire("ChoppingState", arg1 or false)
	local var3 = arg1 and Color3.fromRGB(0, 200, 0) or Color3.fromRGB(237, 234, 234)
	local var4
	local var5
	if var6 and var6.Tree:FindFirstChild("Ring") then
		var6.Tree.Ring.Main.Color = var3
		for k1, v1 in var6.Tree.Ring.Extra:GetChildren() do
			v1.Color3 = var3
		end
	end

	var40.Enabled = arg1
	var3 = var9.Tween.ScaleModel
	local var7 = var2
	local var8 = TweenInfo.new(0.1)
	var3(var7, var8, if arg1 then 1.03 else 1)
	for k2, v2 in { OutlineTransparency = if arg1 then 0 else 1, FillTransparency = 1 }, nil do
		var40[k2] = v2
	end

	if arg1 then
		if var42 then
			return
		end

		var42 = task.spawn(function()
			while bool5 do
				var9.Network.Fire("TreeHit")
				task.wait((math.max(var31.GetChoppingSpeed(var10) * 1.05, 0.05)))
			end

			var42 = nil
		end)

		return
	end

	var34.Icon = ""
end

local var43 = var1.Assets.DamageIndicator
local function SetupTreeHitEmitters(arg1)
	for k1, v1 in tbl2, nil do
		v1:Destroy()
	end

	table.clear(tbl2)
	for k2, v2 in var1.Assets.Particles.TreeHit:GetDescendants() do
		if not v2:IsA("ParticleEmitter") then
			continue
		end

		local var2 = v2:Clone()
		var2.Parent = arg1.vfx
		table.insert(tbl2, var2)
	end

	var28 = arg1
end

local function PlayTreeHitEmitters(arg1)
	if not var27.Value then
		return
	end

	for k1, v1 in tbl2, nil do
		if v1:GetAttribute("EmitCount") then
			local str2 = "EmitCount"
			v1:Emit(v1:GetAttribute(str2))
		else
			v1:Emit(arg1 or 5)
		end
	end
end

local function PlayCritEmitters(arg1)
	if not var27.Value then
		return
	end

	for k1, v1 in tbl1, nil do
		if v1:GetAttribute("EmitCount") then
			local str2 = "EmitCount"
			v1:Emit(v1:GetAttribute(str2))
		else
			v1:Emit(arg1 or 5)
		end
	end
end

local function CritFn()
	local var1 = var43:Clone()
	local var2 = var31.GetCritMultiplier(var10)
	var1.Parent = workspace
	var1.Display.Damage.Text = ("CRIT! (x%*)"):format((var9.Short.toSuffix(var2)))
	local var3 = var6.Tree.CurrencyDropPoint
	var1.Position = (var3.CFrame * CFrame.new((math.random() - 0.5) * var3.Size.X, var3.Position.Y - 5, (math.random() - 0.5) * var3.Size.Z)).Position
	local var4 = TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.Out)
	var9.Tween.Play(var1, var4, { Position = var1.Position + Vector3.new(0, 5, 0) })
	task.wait(0.5)
	var9.Tween.Play(var1.Display.Damage, TweenInfo.new(0.45, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), { TextTransparency = 1 })
	var9.Tween.Play(var1.Display.Damage.UIStroke, TweenInfo.new(0.45, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), { Transparency = 1 })
	task.wait(0.5)
	var1:Destroy()
end

var38 = function(arg1, arg2, arg3, arg4)
	local var1 = (var37[arg1] or 0) + 1
	var37[arg1] = var1
	local var2 = var14.toNumber(arg2)
	local var3 = var14.toNumber(arg3)
	task.spawn(function()
		local num1 = 0
		while true do
			if num1 >= arg4 then
				break
			end

			if var37[arg1] ~= var1 then
				return
			end

			num1 = math.min(num1 + task.wait(), arg4)
			arg1.Text = var15.short(var2 + (var3 - var2) * (num1 / arg4))
		end

		if var37[arg1] == var1 then
			arg1.Text = var15.short(arg3)
		end
	end)
end

local function fn7()
	if var38 then
		var38:Cancel()
	end

	if var39 then
		var39:Cancel()
	end

	var38 = var29:Create(var37, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 1.25 })
	var38:Play()
	var38.Completed:Once(function(arg1)
		if arg1 ~= Enum.PlaybackState.Completed then
			return
		end

		var39 = var29:Create(var37, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Scale = 1 })
		var39:Play()
	end)
end

local var44 = var8.LevelFrame.Level
local function HandleDeposit(arg1)
	if not arg1.Automatic then
		if arg1.LevelsGained then
			if 0 < arg1.LevelsGained then
				local var4 = arg1.LevelsGained
				local var5 = var22.NormalPopUp
				local str1 = "Upgraded %* %*"
				local var6 = var4
				str1 = str1:format(var6, if var4 == 1 then "level" else "levels")
				var5(str1, var23.Wood.Colour, 3)
			end
		end
	end

	if not bool1 then
		return
	end

	bool2 = arg1.RanOut
	if bool1 then
		var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
	else
		if bool3 then
			var7.Color = var18.UpgradeTree.Visible
		else
			var7.Color = var19
		end
	end

	if not arg1.Completed then
		local var10 = var14.toBN(arg1.WaterRemaining)
		var38(var13, var16 or var10, var10, 0.3)
		var16 = var10
	end

	if 0 < arg1.WaterPercent then
		local var11 = math.max(2, (math.floor(arg1.WaterPercent * 8 + 1)))
		var11 = var11 or 0
	end

	local num2 = 0
	if 0 < num2 then
		var9.Sound.Play("Collect (OLD)")
		if var27.Value then
			var24:Emit(num2)
		end

		fn7()
	end
end

local function TreeHit(arg1, arg2)
	if var26 then
		var26:Play()
		var26:AdjustSpeed(var26.Length / var31.GetChoppingSpeed(var10))
	end

	task.wait(var31.GetChoppingSpeed(var10) / 1.4)
	local var2 = if var10.Character then var10.Character:FindFirstChild("Axe") else nil
	if var2 then
		if var28 ~= var2 then
			SetupTreeHitEmitters(var2)
		end

		PlayTreeHitEmitters()
	end

	if arg2 then
		PlayCritEmitters()
		var9.Sound.Play("CriticalHit")
		task.spawn(CritFn)
	end

	var9.Sound.Play("AxeSwing")
	local var3 = var32
	local str1 = "Wood"
	local var4 = arg1
	var3(str1, if arg2 then 10 else 5, var6.Tree.CurrencyDropPoint, var4)
	for k1, v1 in { FillTransparency = 0 }, nil do
		var40[k1] = v1
	end

	var3 = var6.Tree:FindFirstChild("Model")
	if not var3 then
		return
	end

	var9.Tween.Play(var40, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), { FillTransparency = 1 })
	var9.Tween.ScaleModel(var3, TweenInfo.new(0.1), 1.06)
	task.wait(0.1)
	var9.Tween.ScaleModel(var3, TweenInfo.new(0.1), 1.03)
end

local var45 = var7.Size.X / 2 + 0.5
local function DetectProximity()
	local bool2 = false
	if vector.magnitude(var10.Character.HumanoidRootPart.Position - var6.Tree.Part.Position) < 7 then
		bool2 = var20.Tree.Unlocked(var10)
	end

	if bool2 and var35.Value then
		var34.Icon = "rbxassetid://122215945910061"
	end

	if bool2 ~= bool5 then
		bool5 = bool2
		SetChoppingState(bool2)
	end

	bool5 = bool2
	var33.Visible = bool2
end

local function SetupDepositEmitters(arg1)
	local var2 = arg1:WaitForChild("HumanoidRootPart")
	local var3 = Instance.new("Attachment")
	var3.Name = "DepositPoint"
	var3.Position = Vector3.new(0, 1, 0)
	var3.Parent = var2
	var24 = Instance.new("ParticleEmitter")
	var24.Texture = "rbxassetid://113668091012536"
	var24.Enabled = false
	var24.Rate = 0
	var24.Lifetime = NumberRange.new(0.5, 0.9)
	var24.Speed = NumberRange.new(6, 12)
	var24.SpreadAngle = Vector2.new(180, 180)
	var24.EmissionDirection = Enum.NormalId.Top
	var24.Acceleration = Vector3.new(0, -60, 0)
	var24.Rotation = NumberRange.new(-45, 45)
	var24.RotSpeed = NumberRange.new(-60, 60)
	local num1 = 1
	local num2 = 0.35
	var24.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(num1, num2) })
	num2 = 1
	local num3 = 1
	num1 = NumberSequenceKeypoint.new(num2, num3)
	var24.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), num1 })
	var24.Parent = var3
	table.clear(tbl1)
	local var4 = Instance.new("Attachment")
	var4.Name = "CritPoint"
	var4.Parent = var2
	for k1, v1 in var1.Assets.Particles.CriticalHit:GetDescendants() do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		num2 = v1:Clone()
		num2.Parent = var4
		table.insert(tbl1, num2)
	end
end

local var46 = var11.Value
local function InitTreeModel()
	local var2 = var6.Tree:FindFirstChild("Model")
	var40.Parent = nil
	if var2 then
		var2:Destroy()
	end

	local var3 = var1.Assets.Trees[tostring(var11.Value)]:Clone()
	var3.Name = "Model"
	var3.Parent = var6.Tree
	local var4 = var39(var3)
	local var5 = var3:GetPivot()
	var3:PivotTo(var41 * CFrame.new(0, var5.Position.Y - (var4 or var5.Position.Y) + 0.85, 0))
	var40.Parent = var3
	var3:ScaleTo(0.001)
	var9.Tween.ScaleModel(var3, TweenInfo.new(0.25), 1.06)
	task.delay(0.25, function()
		var9.Tween.ScaleModel(var3, TweenInfo.new(0.25), 1)
	end)
end

local function CheckAffordability(arg1)
	if not var20.Tree.Unlocked(var10) then
		bool3 = false
		bool4 = false
		if bool1 then
			var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
			return
		end

		if bool3 then
			var7.Color = var18.UpgradeTree.Visible
			return
		end

		var7.Color = var19
		return
	end

	if var12.Max <= var11.Value then
		bool3 = false
		bool4 = false
		if bool1 then
			var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
			return
		end

		if bool3 then
			var7.Color = var18.UpgradeTree.Visible
			return
		end

		var7.Color = var19
		return
	end

	bool3 = var14.gte(var21.Value, (var14.sub(var12.Pricing(arg1), arg1.Tree.WaterDeposited.Value)))
	if bool3 then
		if not bool4 then
			bool4 = true
			var22.NormalPopUp("You can upgrade your tree", var23.Wood.Colour, 3.5)
		end
	else
		bool4 = false
	end

	if bool1 then
		var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
		return
	end

	if bool3 then
		var7.Color = var18.UpgradeTree.Visible
		return
	end

	var7.Color = var19
end

local function UpdateCombo()
	local var1 = var31.TreeComboMultiplierCap(var10)
	local var2 = var1 - 1
	local var3 = (var36.Value - 1) / var2
	local var4 = var33.Minigame
	local var5 = UDim2.fromScale(1, (math.clamp(var3, 0, 1)))
	var4.Levels.quarter.Power.Text = ("x%*"):format((var9.Short.toSuffix(1 + var2 * 0.25)))
	var4.Levels.half.Power.Text = ("x%*"):format((var9.Short.toSuffix(1 + var2 * 0.5)))
	var4.Levels.threequarters.Power.Text = ("x%*"):format((var9.Short.toSuffix(1 + var2 * 0.75)))
	var4.Levels.Max.Power.Text = ("x%*"):format((var9.Short.toSuffix(var1)))
	var4.InfoBar.Icon.Power.Text = ("x%*"):format((var9.Short.toSuffix(var36.Value)))
	var4.MainBar.Bar.BackgroundColor3 = Color3.fromHSV(math.clamp(var3, 0, 1) * 0.3, 1, 1)
	local var6 = TweenInfo.new(0.1)
	var9.Tween.Play(var4.MainBar, var6, { Size = var5 })
	var6 = TweenInfo.new(0.1)
	var9.Tween.Play(var4.InfoBar, var6, { Size = var5 })
	var9.Tween.Play(var33.UIScale, TweenInfo.new(0.1), { Scale = 1.04 })
	task.wait(0.1)
	var9.Tween.Play(var33.UIScale, TweenInfo.new(0.1), { Scale = 1 })
end

local function IncrementCombo(arg1)
	if arg1.UserInputState ~= Enum.UserInputState.Begin then
		return
	end

	if arg1.UserInputType == Enum.UserInputType.MouseButton1 or (arg1.UserInputType == Enum.UserInputType.Touch or (arg1.KeyCode == Enum.KeyCode.ButtonR2 or arg1.KeyCode == Enum.KeyCode.ButtonR1)) then
		var9.Network.Fire("TreeCombo")
	end
end

return { Init = function(_)
	var9.Stat.WaitForLoad(var10)
	local var1 = var9.Stat.GetDataFolder(var10)
	var9.Network.Connect("TreeDeposit", HandleDeposit)
	var9.Network.Connect("TreeHit", TreeHit)
	local var2 = var1.TempValues
	repeat
		task.wait()
	until var2:WaitForChild("FeaturesLoaded").Value

	var41 = var6.Tree.Ring:GetPivot()
	task.spawn(function()
		while true do
			task.wait(0.1)
			if not var20.Tree.Unlocked(var10) then
				task.wait(1)
			else
				local var1 = var10.Character
				local var2 = var1
				var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
				if not var2 then
					continue
				end

				local var4 = (Vector3.new(var2.Position.X, 0, var2.Position.Z) - Vector3.new(var7.Position.X, 0, var7.Position.Z)).Magnitude <= var45
				if var4 and (not bool1) then
					bool1 = true
					var33.Visible = true
					if bool1 then
						var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
					else
						if bool3 then
							var7.Color = var18.UpgradeTree.Visible
						else
							var7.Color = var19
						end
					end
				else
					if not var4 and bool1 then
						bool1 = false
						var33.Visible = false
						if bool1 then
							var7.Color = bool2 and var18.Expensive.Colour or var18.Afford.Colour
						else
							if bool3 then
								var7.Color = var18.UpgradeTree.Visible
							else
								var7.Color = var19
							end
						end
					end
				end

				DetectProximity()
			end
		end
	end)

	var10.CharacterAdded:Connect(function(arg1)
		local var1 = arg1:WaitForChild("Humanoid"):WaitForChild("Animator"):LoadAnimation(var25)
		var1.Priority = Enum.AnimationPriority.Action4
		var26 = var1
		SetupDepositEmitters(arg1)
	end)

	var11.Changed:Connect(function()
		local var2 = var46 < var11.Value
		var46 = var11.Value
		local var3 = var1
		if var12.Max <= var11.Value then
			var13.Text = "MAX"
		else
			local var4 = var14.sub(var12.Pricing(var3), var3.Tree.WaterDeposited.Value)
			var13.Text = var15.short(var4)
			var16 = var4
		end

		InitTreeModel()
		var44.Text = "Level " .. var1.Stats.TreeLevel.Value
		CheckAffordability(var1)
		if var2 then
			var9.VFX.Emit(var6.Tree.CurrencyDropPoint, var17.TreeLevelUp)
			var9.VFX.Emit(var7, var17.RingLevelUp)
			var9.Sound.Play("TreeLevelUp", var7)
		end
	end)

	var21.Changed:Connect(function()
		CheckAffordability(var1)
	end)

	var1.Tree.WaterDeposited.Changed:Connect(function()
		CheckAffordability(var1)
	end)

	var36.Changed:Connect(UpdateCombo)
	var30.InputBegan:Connect(IncrementCombo)
	InitTreeModel()
	var44.Text = "Level " .. var1.Stats.TreeLevel.Value
	if var12.Max <= var11.Value then
		var13.Text = "MAX"
	else
		local var3 = var14.sub(var12.Pricing(var1), var1.Tree.WaterDeposited.Value)
		var13.Text = var15.short(var3)
		var16 = var3
	end

	CheckAffordability(var1)
	local var4 = var10.Character
	var4 = var4 or var10.CharacterAdded:Wait()
	local var5 = var4:WaitForChild("Humanoid"):WaitForChild("Animator"):LoadAnimation(var25)
	var5.Priority = Enum.AnimationPriority.Action4
	var26 = var5
	SetupDepositEmitters(var4)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Barn [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = game:GetService("ReplicatedStorage")
require(var1.Modules.Shared.Multipliers)
local var2 = game:GetService("Players").LocalPlayer
local var3 = var2:WaitForChild("PlayerGui"):WaitForChild("PetButtonGui")
local var4 = var3.Buy
local var6 = var4:FindFirstChild("PressE")
local var7 = game:GetService("RunService")
local var8 = game:GetService("TweenService")
local var9 = require(var1.Modules.Shared.BigNum)
local var10 = require(var1.Framework)
local var11 = require(var1.Modules.Shared.Pets)
local var12 = require(var1.Modules.Client.Suffix)
local var13 = require(var1.Modules.Shared.Colours)
local var14 = require(var1.Modules.Client.DropCurrency)
local var15 = require(var1.Modules.Client.UI).PopUps
local var16 = var1.Assets
local var17 = if var6 then var6.TextLabel:FindFirstChildWhichIsA("UIStroke") else nil
local tbl1 = { Afford = Color3.fromRGB(11, 152, 9) }
tbl1.Expensive = Color3.fromRGB(152, 9, 30)
tbl1.Evolve = Color3.fromRGB(35, 9, 152)
local var18 = workspace.Features:FindFirstChild("Barn")
var18 = var18 or var16.Features:FindFirstChild("Barn")
local var19 = var18.Holder.PetHolderGui
local var20 = var19.Frame.Progressbar
local var21 = var10.Stat.Get("Device")
local var22 = var18:WaitForChild("Holder").ProximityPrompt
local var23 = nil
local bool1 = false
local var24 = TweenInfo.new(0.26, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local var25 = var10.Stat.Get("Pet")
local var26 = var10.Stat.Get("PetLevel")
local var27 = TweenInfo.new(0.26, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local var28 = var20.Bar
local var29 = var10.Stat.Get("Grass")
local bool2 = false
local function UpdateProgressColour(arg1)
	local var1 = arg1 * 0.26
	local var2 = var1
	local num1 = 0.7
	local num2 = 1
	local var3 = ColorSequenceKeypoint.new(0, Color3.fromHSV(var2, num1, num2))
	num1 = var1
	num2 = 1
	local num3 = 0.7
	local var4 = ColorSequenceKeypoint.new(0.5, Color3.fromHSV(num1, num2, num3))
	num2 = var1
	num3 = 0.7
	local num4 = 1
	var2 = 1
	var28.UIGradient.Color = ColorSequence.new({ var3, var4, ColorSequenceKeypoint.new(var2, Color3.fromHSV(num2, num3, num4)) })
	var28.UIStroke.Color = Color3.fromHSV(var1, 1, 0.67)
end

local var30 = var20.Progress
local function ShowBuy()
	local var1 = var25.Value
	local bool3 = false
	if var11[var1].Levels <= var26.Value then
		bool3 = not var11[var1 + 1]
	end

	bool1 = true
	var4.Visible = not bool3
	var4.UIScale.Scale = 0
	var10.Tween.Play(var4.UIScale, var27, { Scale = 1 })
end

local function WeldModel(arg1)
	arg1 = arg1:Clone()
	if arg1:IsA("BasePart") then
		local var1 = Instance.new("Model")
		var1.Name = arg1.Name
		var1.Parent = arg1.Parent
		arg1.Parent = var1
		arg1 = var1
	end

	local var2 = Instance.new("Part")
	local var3 = arg1:GetPivot()
	local var4 = arg1:GetExtentsSize()
	var2.Transparency = 1
	var2.CanCollide = false
	var2.CanQuery = false
	var2.Anchored = true
	var2.Size = vector.create(var4.X, 0.1, var4.Y)
	local num1 = 0
	var2:PivotTo(var3 - vector.create(num1, var4.Y / 2, 0))
	for k1, v1 in arg1:QueryDescendants("BasePart") do
		local var5 = Instance.new("WeldConstraint")
		var5.Parent = var2
		var5.Part0 = v1
		var5.Part1 = var2
		v1.Anchored = false
		v1.CanCollide = false
		v1.Name = "FieldPet"
	end

	var2.Name = "FieldPet"
	var2.Parent = arg1
	var2.Orientation = Vector3.new(0, 270, 0)
	arg1.PrimaryPart = var2
	return arg1
end

local var31 = var18:WaitForChild("Holder").CFrame
local var32 = nil
local var33 = nil
local var34 = nil
local tbl2 = {}
local var35 = nil
local var36 = TweenInfo.new(0.4)
local var37 = nil
local var38 = var18:WaitForChild("Field")
local function UpdatePetModel()
	local var1 = var25.Value
	local var4 = var11[var1]
	if not var4 then
		warn("Pet info not found for: " .. var1)
		return
	end

	local var6 = var16.Pets:FindFirstChild(var4.Name)
	if not var6 then
		warn("Pet model not found for: " .. var4.Name)
		return
	end

	local var8 = var18:FindFirstChild("Pet")
	if var8 then
		var22.Parent = var18.Holder
		var8:Destroy()
	end

	var6 = WeldModel(var6)
	var6.Name = "Pet"
	var6:PivotTo(var31)
	var6.Parent = var18
	local var9 = var6:GetExtentsSize()
	var19.Adornee = var6.PrimaryPart
	var3.Adornee = var6.PrimaryPart
	var19.StudsOffsetWorldSpace = vector.create(0, var9.Y + 1, 0)
	var3.StudsOffsetWorldSpace = vector.create(0, var9.Y / 2, 0)
	local var12 = var18:FindFirstChild("FieldPet")
	if var12 then
		if var23 then
			var23.Parent = var18
		end

		var32 = nil
		var12:Destroy()
	end

	var32 = var6:Clone()
	var32.Name = "FieldPet"
	local var13 = var32
	var13:PivotTo(if var12 then var12:GetPivot() else var18.Field.CFrame)
	var32:ScaleTo(var32:GetScale() * 0.9)
	var32.Parent = var18
	var22.Parent = var6.PrimaryPart
	if var23 then
		var23.Parent = var32.PrimaryPart
	end
end

local function UpdatePetInfo()
	var29 = var10.Stat.Get(var2, "Grass")
	local var1 = var25.Value
	local var5 = var11[var1]
	if not var5 then
		warn("Pet info not found for: " .. var1)
		return
	end

	local var7 = var5.Levels <= var26.Value
	local var8 = var5.Price(var2)
	var8 = var7 and var5.EvolvePrice
	local var14 = var9.gte(var29.Value, var8)
	local var18 = var14 and var7
	local var21 = var5.Name
	local var22 = not var11[var1 + 1]
	if var18 then
		if not var22 then
			if not bool2 then
				bool2 = true
				var15.NormalPopUp("You can evolve your pet!", var13.Evolve.Colour, 3.5)
			end
		else
			bool2 = false
		end
	else
		bool2 = false
	end

	var19.Frame.Level.Text = ("Level %*/%*"):format(var26.Value, var5.Levels)
	local var23 = var19.Frame.Seed
	local str1 = "%*%*"
	local var24 = var21
	var23.Text = str1:format(var24, if var7 then " [MAXED]" else "")
	var19.Frame.Seed.TextColor3 = var5.Colour
	var4.Stat.Boost.Text = var12.short(var8)
	str1 = var14
	var4.Green.Enabled = str1 and (not var18)
	var4.Purple.Enabled = var14 and var18
	var4.Evolve.Visible = var14 and var18
	var4.Red.Enabled = not var14
	if var6 then
		str1 = var14
		var6.Green.Enabled = str1 and (not var18)
		var6.Purple.Enabled = var14 and var18
		var6.Red.Enabled = not var14
	end

	if var17 then
		var23 = var17
		if var18 then
			str1 = tbl1.Evolve
		elseif var14 then
			str1 = tbl1.Afford
		else
			str1 = tbl1.Expensive
		end

		var23.Color = str1
	end

	local var27 = var29.Value
	var24 = var8
	var23 = var9.toNumber(var9.div(var27, var24))
	var27 = math.clamp(var23, 0, 1)
	var28:TweenSize(UDim2.new(var27, 0, 1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.05, true)
	UpdateProgressColour(var27)
	var30.Text = var10.Short.toSuffix((math.clamp(var23 * 100, 0, 100))) .. "%"
	var24 = var7
	var24 = var24 and (not var11[var1 + 1])
	var20.Visible = not var24
	if var24 then
		bool1 = false
		var4.Visible = false
		return
	end

	if bool1 and (not var4.Visible) then
		ShowBuy()
	end
end

var10.Network.Connect("UpgradePet", function(arg1)
	if arg1 then
		UpdatePetModel()
		var10.Sound.Play("NewHighestSeed", var18.Pet)
	else
		var10.Sound.Play("UpgradeSeed", var18.Pet)
	end

	UpdatePetInfo()
	var10.VFX.Emit(var18.Pet, var1.Assets.Particles.UpgradeSeed)
	if var32 then
		var10.VFX.Emit(var32, var1.Assets.Particles.UpgradeSeed)
	end

	if arg1 then
		var10.VFX.Emit(var18.Pet, var1.Assets.Particles.Evolve)
		if var32 then
			var10.VFX.Emit(var32, var1.Assets.Particles.Evolve)
		end
	end
end)

local function Popup(arg1, arg2)
	if var33 then
		task.cancel(var33)
	end

	if var34 then
		for k1, v1 in tbl2, nil do
			v1:Cancel()
		end

		table.clear(tbl2)
		local var1 = var34.Frame.Inner
		var1.Amount.TextTransparency = 0
		var1.Amount.UIStroke.Transparency = 0
		var1.CurrencyImage.ImageTransparency = 0
		var34.Parent = arg1
		local var3 = var34.Parent
		if var3 and var3 ~= arg1 then
			var3:Destroy()
		end

		local var4 = var35
		local var5 = arg2
		var35 = var9.toString(var9.add(var4, var5))
		var10.Tween.Play(var34.Frame.UIScale, TweenInfo.new(0.1), { Scale = 1.2 })
		task.delay(0.1, var10.Tween.Play, var34.Frame.UIScale, TweenInfo.new(0.1), { Scale = 1 })
	else
		var34 = script.BillboardGui:Clone()
		var35 = arg2
		var34.Parent = arg1
		var34.Enabled = true
	end

	local var6 = var34
	local var7 = var6.Frame.Inner
	var7.Amount.Text = ("+%*"):format((var12.short(var35)))
	var33 = task.delay(3, function()
		local var1 = var7.CurrencyImage
		local var2 = var36
		local tbl1 = { ImageTransparency = 1 }
		local tbl3 = {
			var8:Create(var7.Amount, var36, { TextTransparency = 1 }),
			var8:Create(var7.Amount.UIStroke, var36, { Transparency = 1 }),
			var8:Create(var1, var2, tbl1),
		}

		tbl2 = tbl3
		for k1, v1 in tbl2, nil do
			v1:Play()
		end

		task.wait(var36.Time)
		var6:Destroy()
		arg1:Destroy()
		var34 = nil
		var35 = "0"
		var33 = nil
		table.clear(tbl2)
	end)
end

local var39 = TweenInfo.new(1, Enum.EasingStyle.Exponential)
var10.Network.Connect("CollectGrass", function(arg1)
	if not var32 then
		return
	end

	var10.VFX.Emit(var32, var1.Assets.Particles.CollectGrass)
	var10.Sound.Play("CollectGrass", var32.PrimaryPart)
	var14("Grass", 1, var32, nil, 0.25, Vector3.new(0, 3, 0))
	local var2 = Instance.new("Part")
	local var3 = var32:GetExtentsSize()
	var2.Transparency = 1
	var2.Anchored = true
	var2.CanCollide = false
	var2.CanQuery = false
	var2.Parent = workspace
	local var4 = var34 == nil
	var2:PivotTo(var32:GetPivot() + vector.create(0, var4 or var3.Y / 2 + 3, 0))
	Popup(var2, arg1)
	if var4 then
		var8:Create(var2, var39, { Position = var2.Position + Vector3.new(0, 3, 0) }):Play()
	end

	local var5 = var32:GetScale()
	var10.Tween.ScaleModel(var32, TweenInfo.new(0.1), var5 * 0.95)
	task.delay(0.1, var10.Tween.ScaleModel, var32, TweenInfo.new(0.1), var5)
end)

var10.Network.Connect("DropGrass", function(arg1)
	if not var32 then
		return
	end

	var10.Sound.Play("CollectGrass", var32.PrimaryPart)
	var14("Grass", 1, var32, nil, 0.25, Vector3.new(0, 3, 0), arg1)
end)

local function HideBuy()
	bool1 = false
	var10.Tween.Play(var4.UIScale, var24, { Scale = 0 })
	task.wait(var24.Time + 0.05)
	if not bool1 then
		var4.Visible = false
	end
end

local function SetupGrassPrompt()
	var23 = Instance.new("ProximityPrompt")
	var23.Name = "GrassPrompt"
	var23.ActionText = "Collect"
	var23.ObjectText = "Grass"
	var23.HoldDuration = 0
	var23.MaxActivationDistance = 10
	var23.RequiresLineOfSight = false
	var23.Exclusivity = Enum.ProximityPromptExclusivity.OnePerButton
	local var2 = var21.Value
	local var3 = var23
	local bool1 = true
	if var2 ~= "Mobile" then
		bool1 = var2 == "Console"
	end

	var3.Enabled = bool1
	var23.Parent = var18
	var23.Triggered:Connect(function()
		var10.Network.Fire("CollectGrass")
	end)
end

local var40 = var10.Stat.Get("ScientificNotation")
local function TweenButton(arg1)
	local var1 = TweenInfo.new(0.1)
	var10.Tween.Play(var4.UIScale, var1, { Scale = arg1 })
end

local function getRandomPositionOnPlane(arg1)
	local var1 = arg1.Size
	local var2 = vector.create(math.random() * (var1.X - 1.8) - var1.X / 2 + 0.9, var1.Y / 2 + var32.PrimaryPart.Size.Y / 2, math.random() * (var1.Z - 1.8) - var1.Z / 2 + 0.9)
	return var38.CFrame:PointToWorldSpace(var2)
end

return { Init = function(_)
	var4.Visible = false
	var4.UIScale.Scale = 0
	repeat
		task.wait()
		local var2 = var10.Stat.Get("FeaturesLoaded")
		if var2 then
			if var2.Value then
				break
			end
		end
	until var2.Value

	var22.PromptShown:Connect(ShowBuy)
	var22.PromptHidden:Connect(HideBuy)
	var21.Changed:Connect(function()
		local var2 = var21.Value
		local var3 = var23
		local bool1 = true
		if var2 ~= "Mobile" then
			bool1 = var2 == "Console"
		end

		var3.Enabled = bool1
		if not var6 then
			return
		end

		local var5 = var21.Value
		var3 = var6
		var2 = true
		if var5 ~= "Mobile" then
			var2 = var5 == "Console"
		end

		var3.Visible = not var2
	end)

	if not var6 then
	else
		local var5 = var21.Value
		local var8 = var6
		local bool1 = true
		if var5 ~= "Mobile" then
			bool1 = var5 == "Console"
		end

		var8.Visible = not bool1
	end

	SetupGrassPrompt()
	UpdatePetInfo()
	UpdatePetModel()
	var29.Changed:Connect(UpdatePetInfo)
	var40.Changed:Connect(UpdatePetInfo)
	var26.Changed:Connect(UpdatePetInfo)
	var25.Changed:Connect(function()
		UpdatePetInfo()
		UpdatePetModel()
	end)

	var4.MouseButton1Click:Connect(function()
		if not var4.Visible then
			return
		end

		var10.Network.Fire("UpgradePet")
	end)

	var22.Triggered:Connect(function()
		if not var4.Visible then
			return
		end

		var10.Tween.Play(var4.UIScale, TweenInfo.new(0.1), { Scale = 0.9 })
		task.delay(0.1, TweenButton, 1)
		if not var4.Visible then
			return
		end

		var10.Network.Fire("UpgradePet")
	end)

	var4.MouseEnter:Connect(function()
		var10.Tween.Play(var4.UIScale, TweenInfo.new(0.1), { Scale = 1.1 })
	end)

	var4.MouseLeave:Connect(function()
		var10.Tween.Play(var4.UIScale, TweenInfo.new(0.1), { Scale = 1 })
	end)

	var4.MouseButton1Down:Connect(function()
		var10.Tween.Play(var4.UIScale, TweenInfo.new(0.1), { Scale = 0.9 })
	end)

	var4.MouseButton1Up:Connect(function()
		var10.Tween.Play(var4.UIScale, TweenInfo.new(0.1), { Scale = 1 })
	end)

	var22.Enabled = false
	task.wait()
	var22.Enabled = true
	task.spawn(function()
		while true do
			local var1 = getRandomPositionOnPlane(var38)
			if var37 then
				var37:Disconnect()
				var37 = nil
			end

			local var2 = math.random()
			var37 = var7.PreRender:Connect(function(arg1)
				if var32 then
					local var4 = var32:GetPivot()
					local var5 = vector.create(var1.X - var4.X, 0, var1.Z - var4.Z)
					local var12 = var5.Magnitude
					local var13 = 1 - math.exp(arg1 * -25)
					if var12 <= 0.05 then
						local var14, var15 = var4:ToOrientation()
						local var16 = CFrame.new(var1 - Vector3.new(0, 0.05, 0)) * CFrame.Angles(0, var15, 0)
						local var17 = var4:Lerp(var16, var13)
						var32:PivotTo(var17)
						if (var17.Position - var1).Magnitude <= 0.001 and 0.9999 <= var17.UpVector:Dot(Vector3.new(0, 1, 0)) then
							var32:PivotTo(var16)
							var37:Disconnect()
							var37 = nil
						end

						return
					end

					local var18 = var5.Unit
					local var19 = var4.Position + var18 * math.min(arg1 * 15, var12)
					var19 = vector.create(var19.X, var1.Y + 0.05, var19.Z)
					local var20 = var2 + arg1
					var2 = var20
					var20 = var2 * 10
					local var21 = CFrame.lookAt(var19, var19 + var18) * CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.new(0, math.abs((math.sin(var20))) * 3 - 1.3, 0) * CFrame.Angles(math.rad((math.sin(var20))) * 20, 0, 0)
					local var22 = var13
					var32:PivotTo(var4:Lerp(var21, var22))
				end
			end)

			task.wait(7)
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Research [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = workspace.Features:FindFirstChild("Research")
local var8 = var1.Assets
var7 = var7 or var8.Features:FindFirstChild("Research")
local var9 = var7:WaitForChild("Board").SurfaceGui.Frame
local var10 = var7:WaitForChild("Ring"):WaitForChild("Main")
local var11 = var6:WaitForChild("PlayerGui"):WaitForChild("Frames")
local var12 = var11:WaitForChild("ResearchShop")
local str1 = "ResearchUpgrades"
local var13 = require(var4.StatInformation)
local var14 = require(var4.Multipliers)
local var15 = var7:WaitForChild("Table"):WaitForChild("Top").BillboardGui.PaperFrame.Amount
local var16 = require(var3.Suffix)
local var17 = require(var4.BigNum)
local var18 = var9.ResearchLevel
local var19 = var13.Research.Colour:ToHex()
local var20 = var5.Stat.Get(var6, "ResearchLevel")
local var21 = var9.Amount
local var22 = var13.Paper.Colour:ToHex()
str1 = var5.Stat.Get(var6, "Paper")
local var23 = require(var4.Research)
local var24 = var9.Requirement
local var25 = var9.Buy
local var26 = require(var4.Colours)
local bool1 = false
local var27 = require(var4.Features)
local var28 = require(var3.UI)
local tbl1 = {
	var12,
	var11:WaitForChild("ResearchBoosts"),
	var11:WaitForChild("ResearchAutomation"),
	var11:WaitForChild(str1),
}

local function UpdateBoard()
	var18.Text = ("<font color=\"#%*\">Research Level:</font> %*"):format(var19, var20.Value)
	var21.Text = ("<font color=\"#%*\">Paper</font>: %*"):format(var22, (var16.short(str1.Value)))
	local var2 = var23.Prices[var20.Value]
	local bool3 = true
	if var23.Max > var20.Value then
		bool3 = not var2
	end

	if bool3 then
		var24.Text = "Requirement: MAXED"
		var25.UIGradient.Color = var26.Maxed.Gradient
		bool1 = false
		return
	end

	var24.Text = ("Requirement: %* <font color=\"#%*\">%*</font>"):format(var16.short(var2), var22, var23.Currency)
	local var3 = var17.gte(str1.Value, var2)
	var25.UIGradient.Color = var3 and var26.Afford.Gradient or var26.Expensive.Gradient
	if var3 then
		if var27.Research.Unlocked(var6) then
			if not not bool1 then
				return
			end

			bool1 = true
			var28.PopUps.NormalPopUp("You can upgrade your research level", var13.Research.Colour, 3.5)
			return
		end
	end

	bool1 = false
end

local function UpdatePaperLabels()
	local var1 = ("<font color=\"#%*\">Paper</font>: %*"):format(var22, (var16.short(str1.Value)))
	for k1, v1 in tbl1, nil do
		local var2 = v1:FindFirstChild("Paper")
		if not var2 then
			continue
		end

		var2.Text = var1
	end
end

local bool2 = false
local var29 = var10.Color
local var30 = var10.Size.X / 2 + 0.5
local var31 = var12
local function Upgraded()
	var5.VFX.Emit(var6.Character.HumanoidRootPart, var8.Particles.Research)
	var5.Sound.Play("LabBegin", var6.Character.HumanoidRootPart)
end

local function Refresh()
	local var1 = var14.GetPaperMultiplier(var6)
	local var2 = var14.GetPaperCooldown(var6)
	var15.Text = ("+%*/s"):format((var16.short(var17.div(var1, var2))))
	UpdateBoard()
	UpdatePaperLabels()
end

local function UpdateRingColour()
	if bool2 then
		var10.Color = var26.Afford.Colour
		return
	end

	if var10:GetAttribute("CanAfford") then
		var10.Color = var26.UpgradeTree.Visible
		return
	end

	var10.Color = var29
end

local function HandleRing()
	while true do
		task.wait(0.1)
		local var1
		if not var27.Research.Unlocked(var6) then
			task.wait(1)
		else
			local var2 = var6.Character
			local var3 = var2
			var3 = var3 and var2:FindFirstChild("HumanoidRootPart")
			local var4
			if not var3 then
				var4 = false
			else
				var1 = var30
				var4 = (Vector3.new(var3.Position.X, 0, var3.Position.Z) - Vector3.new(var10.Position.X, 0, var10.Position.Z)).Magnitude <= var1
			end

			if var4 == bool2 then
				continue
			end

			bool2 = var4
			if bool2 then
				var10.Color = var26.Afford.Colour
			else
				if var10:GetAttribute("CanAfford") then
					var10.Color = var26.UpgradeTree.Visible
				else
					var10.Color = var29
				end
			end

			if var4 then
				var28.FrameOpenings.OpenFrame(var31)
			else
				for k1, v1 in tbl1, nil do
					if not v1.Visible then
						continue
					end

					var2 = v1
				end

				var2 = nil
				if not var2 then
					continue
				end

				var31 = var2
				var28.FrameOpenings.CloseFrame(var2)
			end
		end
	end
end

return { Init = function(_)
	var5.Network.Connect("UpgradeResearch", Upgraded)
	local var1 = var5.Stat.GetDataFolder(var6).TempValues
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	str1.Changed:Connect(Refresh)
	var20.Changed:Connect(Refresh)
	var25.MouseButton1Click:Connect(function()
		var5.Sound.Play("UIClick")
		var5.Network.Fire("UpgradeResearch")
	end)

	var10:GetAttributeChangedSignal("CanAfford"):Connect(UpdateRingColour)
	local var2 = var14.GetPaperMultiplier(var6)
	local var3 = var14.GetPaperCooldown(var6)
	var15.Text = ("+%*/s"):format((var16.short(var17.div(var2, var3))))
	UpdateBoard()
	UpdatePaperLabels()
	if bool2 then
		var10.Color = var26.Afford.Colour
	else
		if var10:GetAttribute("CanAfford") then
			var10.Color = var26.UpgradeTree.Visible
		else
			var10.Color = var29
		end
	end

	task.spawn(HandleRing)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.ResearchBoosts [ModuleScript]
-- y u r i

return { Init = function(_)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.ResearchNotifications [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
var3.Stat.WaitForLoad(var4)
local var5 = var3.Stat.GetDataFolder(var4)
local var6 = workspace.Features:FindFirstChild("Research")
local var7 = (var6 or var1.Assets.Features:FindFirstChild("Research")):WaitForChild("Ring"):WaitForChild("Main")
local var8 = require(var2.BigNum)
local var9 = var5.TempValues
local var10 = var4:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("ResearchShop"):WaitForChild("Buttons")
local var11 = var7.BillboardGui:WaitForChild("Notification")
local tbl1 = {}
for k1, v1 in require(var2.ResearchShops) do
	tbl1[k1] = require(var2[v1.Module])
end

local function IsAffordable(arg1, arg2)
	if not arg2.Unlocked(var5) then
		return false
	end

	local var2 = var3.Stat.Get(var4, arg1)
	local var6 = var3.Stat.Get(var4, arg2.Currency)
	if not var2 then
		return false
	end

	if not var6 then
		return false
	end

	if arg2.Cap(var5) <= var2.Value then
		return false
	end

	local var7 = var4
	local var9 = var2.Value
	local var10 = var6.Value
	return var8.gte(var10, arg2.Price(var7, var9))
end

local function UpdateShop(arg1, arg2)
	local var1 = var10:FindFirstChild(arg1)
	local var2 = var1
	var2 = var2 and var1:FindFirstChild("BG")
	local var3 = var2
	local str1 = "Notification"
	var3 = var3 and var2:FindFirstChild(str1)
	var1 = 0
	for k1, v1 in arg2, nil do
		if not IsAffordable(k1, v1) then
			continue
		end

		var1 = var1 + 1
	end

	if var3 then
		var3.Visible = 0 < var1
		var3.TextLabel.Text = tostring(var1)
	end

	return var1
end

local function GetWatchedStats()
	local tbl2 = {}
	for k1, v1 in tbl1, nil do
		for k2, v2 in v1, nil do
			tbl2[k2] = true
			tbl2[v2.Currency] = true
			if not v2.ChangeStat then
				continue
			end

			tbl2[v2.ChangeStat] = true
		end
	end

	return tbl2
end

local function Refresh()
	local num1 = 0
	for k1, v1 in tbl1, nil do
		num1 = num1 + UpdateShop(k1, v1)
	end

	local var1 = 0 < num1
	var11.Visible = var1
	var7:SetAttribute("CanAfford", var1)
end

return { Init = function(_)
	repeat
		task.wait()
	until var9:WaitForChild("FeaturesLoaded").Value

	for k1, v1 in var10:GetChildren() do
		if not v1:IsA("GuiObject") then
			continue
		end

		if tbl1[v1.Name] then
			continue
		end

		local var1 = var10:FindFirstChild(v1.Name)
		local var2 = var1
		var2 = var2 and var1:FindFirstChild("BG")
		local var5 = var2
		var5 = var5 and var2:FindFirstChild("Notification")
		if not var5 then
			continue
		end

		var5.Visible = false
	end

	for k2 in GetWatchedStats() do
		local var6 = var3.Stat.Get(var4, k2)
		if not var6 then
			continue
		end

		var6.Changed:Connect(Refresh)
	end

	Refresh()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.ResearchAutomation [ModuleScript]
-- y u r i

return { Init = function(_)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Quests [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
var3.Stat.WaitForLoad(var4)
local var5 = workspace.Features:FindFirstChild("Quests")
local var6 = (var5 or var1.Assets.Features:FindFirstChild("Quests")):WaitForChild("Quests"):WaitForChild("Main")
local var7 = var6.Size.X / 2 + 0.5
local var8 = require(var2.Shared.Features)
local bool1 = false
local var9 = require(var2.Client.UI)
local var10 = var4:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("Quests")
local function HandleRing()
	while true do
		task.wait(0.1)
		if not var8.Quests.Unlocked(var4) then
			task.wait(1)
		else
			local var1 = var4.Character
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
			local var5
			if not var2 then
				var5 = false
			elseif (Vector3.new(var2.Position.X, 0, var2.Position.Z) - Vector3.new(var6.Position.X, 0, var6.Position.Z)).Magnitude > var7 then
				var5 = false
			end

			if var5 == bool1 then
				continue
			end

			bool1 = var5
			if var5 then
				var3.Sound.Play("UIClick")
				var9.FrameOpenings.OpenFrame(var10)
			else
				if not var10.Visible then
					continue
				end

				var9.FrameOpenings.CloseFrame(var10)
			end
		end
	end
end

return { Init = function(_)
	local var1 = var3.Stat.GetDataFolder(var4).TempValues
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	task.spawn(HandleRing)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.ResearchShops [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = var5.Stat.GetDataFolder(var6)
local var8 = require(var3.Hover)
local var9 = require(var4.StatInformation)
local var10 = require(var3.Suffix)
local var11 = require(var4.Colours)
local var12 = require(var4.BigNum)
local function UpdateUpgradeInfo(arg1, arg2, arg3)
	local var2 = var5.Stat.Get(var6, arg3)
	local var3 = var5.Stat.Get(var6, arg2.Currency)
	if not var2 then
		return
	end

	if not var3 then
		return
	end

	local var4 = arg2.Cap(var7)
	local var8 = var2.Value
	local var13 = arg1:FindFirstChild("Capacity")
	local var14 = arg1.Buy
	local var15 = 1 < var4
	local var16 = var4 <= var8
	local var17
	if not var13 then
		var17 = nil
	else
		var13.Visible = var15
		var17 = var13
	end

	local var19 = arg1:FindFirstChild("Max")
	if not var19 then
		var13 = nil
	else
		var19.Visible = var15
		var13 = var19
	end

	var19 = arg1:FindFirstChild("CapImage")
	if not not var19 then
		var19.Visible = var15
	end

	if var17 then
		var17.Text = ("%*/%*"):format(var8, var4)
	end

	if var16 then
		var19 = arg1.Boost
		local var20
		if arg2.RewardDisplay then
			var20 = arg2.RewardDisplay
		else
			local var21 = var6
			local var22 = var8
			var20 = string.format(arg2.Format, var10.short(arg2.Reward(var21, var22)))
		end

		var19.Text = var20
		var19 = arg1.Cost
		var19.Text = if var15 then "MAX" else "Unlocked"
		var19 = arg1:FindFirstChild("PriceImage")
	if not not var19 then
			var19.Visible = var15
		end

		var14.UIGradient.Color = var11.Maxed.Gradient
		if var13 then
			var13.UIGradient.Color = var11.Maxed.Gradient
		end

		return
	end

	var19 = arg1:FindFirstChild("PriceImage")
	if not not var19 then
		var19.Visible = true
	end

	var19 = arg2.Price(var6, var8)
	var20 = arg1.Boost
	local var23
	if arg2.RewardDisplay then
		var23 = arg2.RewardDisplay
	else
		var23 = "%* > %*"
		local var24
		if arg2.RewardDisplay then
			var24 = arg2.RewardDisplay
		else
			local var25 = var6
			local var26 = var8
			var24 = string.format(arg2.Format, var10.short(arg2.Reward(var25, var26)))
		end

		local var27
		if arg2.RewardDisplay then
			var27 = arg2.RewardDisplay
		else
			local var28 = var6
			local var29 = var8 + 1
			var27 = string.format(arg2.Format, var10.short(arg2.Reward(var28, var29)))
		end

		var23 = var23:format(var24, var27)
	end

	var20.Text = var23
	arg1.Cost.Text = var10.short(var19)
	var20 = var12.gte(var3.Value, var19)
	var14.UIGradient.Color = var20 and var11.Afford.Gradient or var11.Expensive.Gradient
	if var13 then
		var13.UIGradient.Color = var20 and var11.MaxButton.Gradient or var11.Expensive.Gradient
	end
end

local tbl1 = {}
local function CreateButtonEffects(arg1)
	local var1 = arg1.Size
	arg1.MouseEnter:Connect(function()
		var8.Hover(arg1, var1)
	end)

	arg1.MouseLeave:Connect(function()
		var8.Up(arg1, var1)
	end)

	arg1.MouseButton1Down:Connect(function()
		var8.Down(arg1, var1)
	end)

	arg1.MouseButton1Up:Connect(function()
		var8.Up(arg1, var1)
	end)
end

local var13 = var1.Assets.Particles
local var14 = var7.TempValues
local var15 = require(var4.ResearchShops)
local var16 = var6:WaitForChild("PlayerGui"):WaitForChild("Frames")
local var17 = var1.Frames
local function Upgraded()
	var5.Sound.Play("Upgrade")
	var5.VFX.Emit(var6.Character.HumanoidRootPart, var13.Upgrade)
end

local var18 = require(var3.UI)
local function DisplayUpgrade(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg5:Clone()
	var1.Name = arg2
	var1.LayoutOrder = arg3.Order
	var1.Upgrade.Text = arg3.Display
	local var2 = arg3.Icon
	local var3 = var1.UpgradeImage
	var3.Image = if var9[var2] then var9[var2].Icon else var2
	var2 = arg3.Currency
	var3 = var1.PriceImage
	var3.Image = if var9[var2] then var9[var2].Icon else var2
	var1.Locked.Boost.Text = arg3.LockedText
	if arg3.Colour then
		var1.Boost.TextColor3 = Color3.fromHex(arg3.Colour)
	end

	var1.Parent = arg4
	local function Refresh()
		UpdateUpgradeInfo(var1, arg3, arg2)
	end

	table.insert(tbl1, Refresh)
	var3 = var5.Stat.Get(var6, arg2)
	var3.Changed:Connect(Refresh)
	var5.Stat.Get(var6, arg3.Currency).Changed:Connect(Refresh)
	var2 = var5.Stat.Get(var6, arg3.ChangeStat)
	if var2 then
		var2.Changed:Connect(function()
			var1.Locked.Visible = not arg3.Unlocked(var7)
			UpdateUpgradeInfo(var1, arg3, arg2)
		end)

	end

	local function Buy(arg1)
		if not arg3.Unlocked(var7) then
			return
		end

		if arg3.Cap(var7) <= var3.Value then
			return
		end

		var5.Sound.Play("UIClick")
		var5.Network.Fire(arg1.Remote, arg2, arg1)
	end

	var1.Buy.MouseButton1Click:Connect(function()
		Buy(false)
	end)

	CreateButtonEffects(var1.Buy)
	local var8 = var1:FindFirstChild("Max")
	if var8 then
		var8.MouseButton1Click:Connect(function()
			Buy(true)
		end)

		CreateButtonEffects(var8)
	end

	var1.Locked.Visible = not arg3.Unlocked(var7)
	UpdateUpgradeInfo(var1, arg3, arg2)
end

return { Init = function(_)
	repeat
		task.wait()
	until var14:WaitForChild("FeaturesLoaded").Value

	for k1, v1 in var15, nil do
		var5.Network.Connect(v1.Remote, Upgraded)
		local var1 = var16:WaitForChild(v1.Frame):WaitForChild("Main")
		var18.ConnectListAutoScale(var1)
		local var2 = var17[v1.Template]
		for k2, v2 in require(var4[v1.Module]) do
			DisplayUpgrade(v1, k2, v2, var1, var2)
		end
	end

	var5.Stat.Get(var6, "UpgradesBought").Changed:Connect(function()
		for k1, v1 in tbl1, nil do
			v1()
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Lab [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.BigNum)
local var5 = var1.Assets
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = var6.Stat.GetDataFolder(var7)
local var9 = workspace.Features:FindFirstChild("Lab")
local var10 = (var9 or var5.Features:FindFirstChild("Lab")):WaitForChild("Ring"):WaitForChild("Main")
local var11 = var7:WaitForChild("PlayerGui"):WaitForChild("Frames")
local var12 = var11:WaitForChild("LabShop")
local var13 = var11:WaitForChild("LabBoosts")
local var14 = var11:WaitForChild("LabUpgrades")
local var15 = require(var3.Hover)
local var16 = require(var4.StatInformation)
local var17 = require(var3.Suffix)
local var18 = var6.Stat.Get("LabResearchSlots"):GetChildren()
local var19 = require(var4.Multipliers)
local num1 = 0
local var20 = require(var4.Colours)
local function GetSlotState(arg1)
	for k1, v1 in var18, nil do
		if v1.LabUpgradeStat.Value ~= arg1 then
			continue
		end

		local var3 = v1.ResearchFinishTime.Value
		if var3 ~= 0 then
			local success, result = pcall(workspace.GetServerTimeNow, workspace)
			if var3 <= (if success then result else os.time()) then
				return "Claimable"
			end
		end

		local success, result = pcall(workspace.GetServerTimeNow, workspace)
		local str1 = "Researching"
		return str1, var3 - (if success then result else os.time())
	end

	return nil
end

local function UpdateUpgradeInfo(arg1, arg2, arg3)
	local var2 = var6.Stat.Get(var7, arg3)
	local var3 = var6.Stat.Get(var7, arg2.Currency)
	if not var2 then
		return
	end

	if not var3 then
		return
	end

	local var4 = arg2.Cap(var8)
	local var5 = var2.Value
	local var10 = arg1:FindFirstChild("Capacity")
	local var11 = arg1.Buy
	local var12 = 1 < var4
	local var13 = var4 <= var5
	local var14
	if not var10 then
		var14 = nil
	else
		var10.Visible = var12
		var14 = var10
	end

	local var16 = arg1:FindFirstChild("Max")
	if not var16 then
		var10 = nil
	else
		var16.Visible = var12
		var10 = var16
	end

	var16 = arg1:FindFirstChild("CapImage")
	if not not var16 then
		var16.Visible = var12
	end

	if var14 then
		var14.Text = ("%*/%*"):format(var5, var4)
	end

	if var13 then
		var16 = arg1.Boost
		local var18
		if arg2.RewardDisplay then
			var18 = arg2.RewardDisplay
		else
			local var21 = var7
			local var22 = var5
			var18 = string.format(arg2.Format, var17.short(arg2.Reward(var21, var22)))
		end

		var16.Text = var18
		var16 = arg1.Cost
		var16.Text = if var12 then "MAX" else "Unlocked"
		var16 = arg1:FindFirstChild("PriceImage")
	if not not var16 then
			var16.Visible = var12
		end

		var11.UIGradient.Color = var20.Maxed.Gradient
		if var10 then
			var10.UIGradient.Color = var20.Maxed.Gradient
		end

		return
	end

	var16 = arg1:FindFirstChild("PriceImage")
	if not not var16 then
		var16.Visible = true
	end

	var16 = arg2.Price(var7, var5) / var19.GetLabResearchSpeed(var7)
	local var23, var24 = GetSlotState(arg3)
	local var25 = arg1.Boost
	local var26
	if arg2.RewardDisplay then
		var26 = arg2.RewardDisplay
	else
		var26 = "%* > %*"
		local var27
		if arg2.RewardDisplay then
			var27 = arg2.RewardDisplay
		else
			local var28 = var7
			local var29 = var5
			var27 = string.format(arg2.Format, var17.short(arg2.Reward(var28, var29)))
		end

		local var30
		if arg2.RewardDisplay then
			var30 = arg2.RewardDisplay
		else
			local var31 = var7
			local var32 = var5 + 1
			var30 = string.format(arg2.Format, var17.short(arg2.Reward(var31, var32)))
		end

		var26 = var26:format(var27, var30)
	end

	var25.Text = var26
	arg1.Cost.Text = var6.Short.toTime(var16)
	var25 = 0 < num1
	var26 = var11.UIGradient
	local var33
	if var23 == "Claimable" then
		var33 = var20.Evolve.Gradient
	elseif var23 == "Researching" then
		var33 = var20.MaxButton.Gradient
	elseif var25 then
		var33 = var20.Afford.Gradient
		var33 = var33 or var20.Expensive.Gradient
	end

	var26.Color = var33
	var26 = var11.Boost
	if var23 == "Claimable" then
		var33 = "Claim"
	elseif var23 == "Researching" then
		var33 = var6.Short.toTime(var24)
	else
		var33 = "Research"
	end

	var26.Text = var33
	if var10 then
		var10.UIGradient.Color = var25 and var20.MaxButton.Gradient or var20.Expensive.Gradient
	end
end

local tbl1 = {}
local function CreateButtonEffects(arg1)
	local var1 = arg1.Size
	arg1.MouseEnter:Connect(function()
		var15.Hover(arg1, var1)
	end)

	arg1.MouseLeave:Connect(function()
		var15.Up(arg1, var1)
	end)

	arg1.MouseButton1Down:Connect(function()
		var15.Down(arg1, var1)
	end)

	arg1.MouseButton1Up:Connect(function()
		var15.Up(arg1, var1)
	end)
end

local var21 = var5.Particles
local tbl2 = { var12, var13, var14 }
local var22 = require(var4.Colours)
local var23 = var10.Color
local var24 = var10.Size.X / 2 + 0.5
local var25 = require(var4.Features)
local var26 = require(var3.UI)
local var27 = var12
local function SetAvailableSlots()
	local num2 = 0
	for k1, v1 in var18, nil do
		if v1.LabUpgradeStat.Value ~= "" or v1.ResearchFinishTime.Value ~= 0 then
			num2 = num2 + 1
		end
	end

	local var1 = var19.GetLabResearchSlots(var7)
	num1 = math.max(0, var1 - num2)
	local var2 = ("Research Slots: <font color=\"#%*\">%*/%*</font>"):format((if 0 < num1 then var20.Afford.Colour else var20.Expensive.Colour):ToHex(), num1, var1)
	var13.SlotsAvailable.Text = var2
	var14.SlotsAvailable.Text = var2
end

var6.Network.Connect("LabUpgrade", function()
	var18 = var6.Stat.Get("LabResearchSlots"):GetChildren()
	SetAvailableSlots()
	for k1, v1 in tbl1, nil do
		v1()
	end
end)

local var28 = var8.TempValues
local var29 = require(var4.LabShops)
local var30 = var1.Frames
local function Upgraded(arg1)
	if arg1 == "Started" then
		var6.Sound.Play("LabBegin")
		return
	end

	if arg1 == "Cancelled" then
		var6.Sound.Play("LabEnd")
		return
	end

	if arg1 == "Claimed" then
		var6.Sound.Play("Upgrade")
		var6.VFX.Emit(var7.Character.HumanoidRootPart, var21.Upgrade)
	end
end

local function DisplayUpgrade(arg1, arg2, arg3, arg4, arg5)
	local var1 = arg5:Clone()
	var1.Name = arg2
	var1.LayoutOrder = arg3.Order
	var1.Upgrade.Text = arg3.Display
	local var2 = arg3.Icon
	local var3 = var1.UpgradeImage
	var3.Image = if var16[var2] then var16[var2].Icon else var2
	var1.Locked.Boost.Text = arg3.LockedText
	if arg3.Colour then
		var1.Boost.TextColor3 = Color3.fromHex(arg3.Colour)
	end

	var1.Parent = arg4
	var3 = var6.Stat.Get(var7, arg2)
	local var4 = var6.Stat.Get(var7, arg3.Currency)
	var2 = var6.Stat.Get(var7, arg3.ChangeStat)
	local function Refresh()
		UpdateUpgradeInfo(var1, arg3, arg2)
	end

	tbl1[arg2] = Refresh
	var3.Changed:Connect(Refresh)
	var4.Changed:Connect(Refresh)
	if var2 then
		var2.Changed:Connect(function()
			var1.Locked.Visible = not arg3.Unlocked(var8)
			UpdateUpgradeInfo(var1, arg3, arg2)
		end)

	end

	local function Buy(arg1)
		if not arg3.Unlocked(var8) then
			return
		end

		if arg3.Cap(var8) <= var3.Value then
			return
		end

		var6.Sound.Play("UIClick")
		var6.Network.Fire(arg1.Remote, arg2, arg1)
	end

	var1.Buy.MouseButton1Click:Connect(function()
		Buy(false)
	end)

	CreateButtonEffects(var1.Buy)
	local var9 = var1:FindFirstChild("Max")
	if var9 then
		var9.MouseButton1Click:Connect(function()
			Buy(true)
		end)

		CreateButtonEffects(var9)
	end

	var1.Locked.Visible = not arg3.Unlocked(var8)
	UpdateUpgradeInfo(var1, arg3, arg2)
end

local function RefreshAll()
	SetAvailableSlots()
	for k1, v1 in tbl1, nil do
		v1()
	end
end

local function UpdateRingColour()
	if InRing then
		var10.Color = var22.Afford.Colour
		return
	end

	if var10:GetAttribute("CanAfford") then
		var10.Color = var22.UpgradeTree.Visible
		return
	end

	var10.Color = var23
end

local function HandleRing()
	while true do
		task.wait(0.1)
		local var1
		if not var25.Lab.Unlocked(var7) then
			task.wait(1)
		else
			local var2 = var7.Character
			local var3 = var2
			var3 = var3 and var2:FindFirstChild("HumanoidRootPart")
			local var4
			if not var3 then
				var4 = false
			else
				var1 = var24
				var4 = (Vector3.new(var3.Position.X, 0, var3.Position.Z) - Vector3.new(var10.Position.X, 0, var10.Position.Z)).Magnitude <= var1
			end

			if var4 == InRing then
				continue
			end

			InRing = var4
			if InRing then
				var10.Color = var22.Afford.Colour
			else
				if var10:GetAttribute("CanAfford") then
					var10.Color = var22.UpgradeTree.Visible
				else
					var10.Color = var23
				end
			end

			if var4 then
				var26.FrameOpenings.OpenFrame(var27)
			else
				for k1, v1 in tbl2, nil do
					if not v1.Visible then
						continue
					end

					var2 = v1
				end

				var2 = nil
				if not var2 then
					continue
				end

				var27 = var2
				var26.FrameOpenings.CloseFrame(var2)
			end
		end
	end
end

local function UpdateTimers()
	while true do
		if not task.wait(1) then
			break
		end

		local var1
		if var13.Visible or var14.Visible then
			SetAvailableSlots()
			for k1, v1 in var18, nil do
				local var2 = v1.LabUpgradeStat.Value
				if var2 == "" then
					continue
				end

				local var3 = tbl1[var2]
				if not var3 then
					continue
				end

				var3()
			end
		end
	end
end

return { Init = function(_)
	repeat
		task.wait()
	until var28:WaitForChild("FeaturesLoaded").Value

	local tbl1 = {}
	for k1, v1 in var29, nil do
		local var1 = require(var4[v1.Module])
		local var2 = var11:WaitForChild(v1.Frame):WaitForChild("Main")
		local var3 = var30[v1.Template]
		if not tbl1[v1.Remote] then
			tbl1[v1.Remote] = true
			var6.Network.Connect(v1.Remote, Upgraded)
		end

		var26.ConnectListAutoScale(var2)
		for k2, v2 in var1, nil do
			DisplayUpgrade(v1, k2, v2, var2, var3)
		end
	end

	var13:GetPropertyChangedSignal("Visible"):Connect(RefreshAll)
	var14:GetPropertyChangedSignal("Visible"):Connect(RefreshAll)
	var10:GetAttributeChangedSignal("CanAfford"):Connect(UpdateRingColour)
	task.spawn(HandleRing)
	task.spawn(UpdateTimers)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Scientists [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.StatInformation)
require(var4.Multipliers)
local var5 = var1.Assets
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = workspace.Features:FindFirstChild("Scientists")
var8 = var8 or var5.Features:FindFirstChild("Scientists")
local var9 = var8:WaitForChild("Table")
local var10 = var8:WaitForChild("Ring"):WaitForChild("Main")
local var11 = require(var3.Hover)
local var12 = require(var4.Colours)
local var13 = var10.Color
local var14 = require(var4.Features)
local var15 = require(var4.Scientists)
local var16 = require(var4.BigNum)
local var17 = var6.Stat.Get("Paper")
local var18 = var10:WaitForChild("BillboardGui"):WaitForChild("Notification")
local var19 = var10.Size.X / 2 + 0.5
local var20 = require(var3.UI)
local var21 = var7:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("ScientistsShop")
local var22 = var6.Stat.Get("EquippedScientist")
local var23 = var9:WaitForChild("Warning")
local var24 = var9:WaitForChild("Boosts")
local var25 = var8:WaitForChild("Holder").CFrame
local var26 = var1.Frames.ScientistNode
local var27 = require(var3.Suffix)
local var28 = require(var4.Colours)
local tbl1 = {}
local function RefreshNotification()
	local bool1 = false
	if var14.Scientists.Unlocked(var7) then
		for k1, v1 in var15, nil do
			local var1 = var6.Stat.Get((("Scientist%*"):format(k1)))
			local bool3 = true
			if v1.Unlocked ~= nil then
				bool3 = v1.Unlocked(var7)
			end

			if not bool3 or (not var1) then
				continue
			end

			if var1.Value then
				continue
			end

			if not var16.gte(var17.Value, v1.Price) then
				continue
			end

			bool1 = true
			break
		end
	end

	var18.Visible = bool1
	if var10:GetAttribute("CanAfford") ~= bool1 then
		var10:SetAttribute("CanAfford", bool1)
		if InRing then
			var10.Color = var12.Afford.Colour
			return
		end

		if var10:GetAttribute("CanAfford") then
			var10.Color = var12.UpgradeTree.Visible
			return
		end

		var10.Color = var13
	end
end

local var29 = var6.Stat.GetDataFolder(var7).TempValues
local function InitScientistNodes()
	for k1, v1 in var15, nil do
		local var1 = var26:Clone()
		local var2 = var1.Buy
		local var3 = var6.Stat.Get((("Scientist%*"):format(k1)))
		local function update()
			local var4 = v1.Price
			local var5 = var16.gte(var17.Value, var4)
			var1.Cost.Text = var27.short(var4)
			local var6 = var22.Value == k1
			local var8 = var2.Boost
			local var9
			if not var3.Value then
				var9 = "Buy"
			elseif var6 then
				var9 = "Unequip"
			else
				var9 = "Equip"
			end

			var8.Text = var9
			var8 = var2.UIGradient
			if var6 then
				var9 = var28.Evolve.Gradient
			else
				if var3.Value then
					var9 = var28.Yellow.Gradient
				elseif var5 then
					var9 = var28.Afford.Gradient
				else
					var9 = var28.Expensive.Gradient
				end
			end

			var8.Color = var9
			var1.Cost.Visible = not var3.Value
			var1.PriceImage.Visible = not var3.Value
			var9 = var3.Value
			var8 = var1
			if not var9 then
				local var11 = v1
				var9 = true
				if var11.Unlocked ~= nil then
					var9 = var11.Unlocked(var7)
				end
			end

			var8.Visible = var9
		end

		update()
		table.insert(tbl1, update)
		local tbl2 = {}
		local str1 = ""
		for k2, v2 in v1.Boosts, nil do
			tbl2[v2.Order] = v2
		end

		for k3, v3 in tbl2, nil do
			str1 = str1 .. (", <font color=\"#%*\">%*</font>"):format(v3.Colour:ToHex(), (v3.Display:format(v3.Reward)))
		end

		var1.Upgrade.Text = ("<font color=\"#ffffff\">%*</font>"):format(v1.Display)
		var1.Boost.Text = str1:sub(3)
		var1.UpgradeImage.Image = v1.Icon
		var1.Name = k1
		var1.LayoutOrder = k1
		var1.Parent = var21.Main
		var3.Changed:Connect(function()
			update()
			RefreshNotification()
		end)

		var2.MouseButton1Click:Connect(function()
			var6.Network.Fire("ScientistToggled", k1)
		end)

	end
end

local function UpdateAll()
	for k1, v1 in tbl1, nil do
		v1()
	end

	RefreshNotification()
end

local function UpdateModel()
	local var2 = var1.Assets.Scientists:FindFirstChild((tostring(var22.Value)))
	var23.Enabled = var2 == nil
	var24.Enabled = var2 ~= nil
	local var4 = var8:FindFirstChild("Model")
	if var4 then
		var4:Destroy()
	end

	if not var2 then
		return
	end

	var2 = var2:Clone()
	var2.Name = "Model"
	var2.Parent = var8
	local var5, var6 = var2:GetBoundingBox()
	local num1 = 0
	var2:PivotTo(var25 * CFrame.new(num1, var2:GetPivot().Position.Y - (var5.Position.Y - var6.Y / 2), 0))
	local var7 = var2.PrimaryPart
	var7 = var7 or var2:FindFirstChild("HumanoidRootPart")
	var24.Adornee = var7
	var24.StudsOffsetWorldSpace = Vector3.new(0, var6.Y + -1.5, 0)
	local var9 = var15[var22.Value].Boosts
	for k1, v1 in var24:GetChildren() do
		if not v1:IsA("TextLabel") then
			continue
		end

		if v1 == var24.Template then
			continue
		end

		v1:Destroy()
	end

	for k2, v2 in var9, nil do
		local var10 = var24.Template:Clone()
		var10.Parent = var24
		var10.LayoutOrder = v2.Order
		var10.Text = ("<font color=\"#%*\">%*</font>"):format(v2.Colour:ToHex(), (v2.Display:format(v2.Reward)))
		var10.Visible = true
	end
end

local function HandleRing()
	while true do
		task.wait(0.1)
		if not var14.Scientists.Unlocked(var7) then
			task.wait(1)
		else
			local var1 = var7.Character
			local var2 = var1
			var2 = var2 and var1:FindFirstChild("HumanoidRootPart")
			local var3
			if not var2 then
				var3 = false
			else
				var3 = (Vector3.new(var2.Position.X, 0, var2.Position.Z) - Vector3.new(var10.Position.X, 0, var10.Position.Z)).Magnitude <= var19
			end

			if var3 == InRing then
				continue
			end

			InRing = var3
			if InRing then
				var10.Color = var12.Afford.Colour
			else
				if var10:GetAttribute("CanAfford") then
					var10.Color = var12.UpgradeTree.Visible
				else
					var10.Color = var13
				end
			end

			if var3 then
				var20.FrameOpenings.OpenFrame(var21)
			else
				var20.FrameOpenings.CloseFrame(var21)
			end
		end
	end
end

return { Init = function(_)
	repeat
		task.wait()
	until var29:WaitForChild("FeaturesLoaded").Value

	InitScientistNodes()
	var20.ConnectListAutoScale(var21.Main)
	local tbl2 = {}
	for k1, v1 in var15, nil do
		if not v1.ChangeStat then
			continue
		end

		tbl2[v1.ChangeStat] = true
	end

	for k2 in tbl2, nil do
		var6.Stat.Get(k2).Changed:Connect(UpdateAll)
	end

	var17.Changed:Connect(UpdateAll)
	var22.Changed:Connect(function(arg1)
		local var1 = var6.Sound.Play
		var1(if arg1 == 0 then "Unequip" else "Equip")
		for k1, v1 in tbl1, nil do
			v1()
		end

		RefreshNotification()
		UpdateModel()
	end)

	task.spawn(HandleRing)
	UpdateModel()
	RefreshNotification()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.LabNotifications [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
local var4 = require(var1.Framework)
local var5 = game:GetService("Players").LocalPlayer
var4.Stat.WaitForLoad(var5)
local var6 = workspace.Features:FindFirstChild("Lab")
local var7 = (var6 or var1.Assets.Features:FindFirstChild("Lab")):WaitForChild("Ring"):WaitForChild("Main")
local var8 = require(var2.Client.UI).PopUps
local var9 = var4.Stat.GetDataFolder(var5).TempValues
local var10 = var5:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("LabShop"):WaitForChild("Buttons")
local var11 = var7.BillboardGui:WaitForChild("Notification")
local var12 = var4.Stat.Get("LabResearchSlots")
local var13 = Color3.fromRGB(167, 67, 255)
local var14 = nil
local tbl1 = {}
for k1, v1 in require(var3.LabShops) do
	local var15 = v1.Module
	for k2 in require(var3[var15]) do
		tbl1[k2] = k1
	end
end

local function Refresh()
	local tbl2 = {}
	local num1 = 0
	for k1, v1 in var12:GetChildren() do
		local var1 = v1.LabUpgradeStat.Value
		if var1 == "" then
			continue
		end

		local var4 = v1.ResearchFinishTime.Value
		if var4 ~= 0 then
			local success, result = pcall(workspace.GetServerTimeNow, workspace)
			if (if success then result else os.time()) < var4 then
				continue
			end
		end

		local var6 = tbl1[var1]
		if not var6 then
			continue
		end

		local var9 = (tbl2[var6] or 0) + 1
		tbl2[var6] = var9
		num1 = num1 + 1
	end

	for k2, v2 in var10:GetChildren() do
		if not v2:IsA("GuiObject") then
			continue
		end

		local var15 = var10:FindFirstChild(v2.Name)
		local var16 = var15
		var16 = var16 and var15:FindFirstChild("BG")
		local var17 = var16
		var17 = var17 and var16:FindFirstChild("Notification")
		if not var17 then
			continue
		end

		local var18 = tbl2[v2.Name] or 0
		var17.Visible = 0 < var18
		var17.TextLabel.Text = tostring(var18)
	end

	var11.Visible = 0 < num1
	var7:SetAttribute("CanAfford", 0 < num1)
	if var14 and var14 < num1 then
		var8.NormalPopUp("Lab Research Has Completed", var13, 7)
	end

	var14 = num1
	return num1
end

return { Init = function(_)
	repeat
		task.wait()
	until var9:WaitForChild("FeaturesLoaded").Value

	for k1, v1 in var12:GetChildren() do
		v1:WaitForChild("LabUpgradeStat").Changed:Connect(Refresh)
		v1:WaitForChild("ResearchFinishTime").Changed:Connect(Refresh)
	end

	var12.ChildAdded:Connect(function(arg1)
		arg1:WaitForChild("LabUpgradeStat").Changed:Connect(Refresh)
		arg1:WaitForChild("ResearchFinishTime").Changed:Connect(Refresh)
		Refresh()
	end)

	if 0 < Refresh() then
		var8.NormalPopUp("You have Lab Research to claim!", var13, 4)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.EventBoard [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
require(var1.Framework).Stat.WaitForLoad(game:GetService("Players").LocalPlayer)
local var3 = workspace.MapEssentials:WaitForChild("EventSign"):WaitForChild("Board"):WaitForChild("SurfaceGui"):WaitForChild("Frame").Join
local bool1 = false
local var4 = game:GetService("SocialService")
local var5 = require(var2.Shared.Colours)
local var6 = require(var2.Client.Hover)
return { Init = function(_)
	var3.MouseButton1Click:Connect(function()
		if not bool1 then
			bool1 = true
			local success, result = pcall(function()
				var4:PromptRsvpToEventAsync("7932522349566493295")
			end)

			if not success then
				warn((("Failed to prompt event 7932522349566493295: %*"):format(result)))
			end

			task.wait(1)
			bool1 = false
		end
	end)

	var3.TextLabel.Text = "Join"
	var3.UIGradient.Color = var5.Afford.Gradient
	var6.CreateHover(var3, var3.Size)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.ZoneHandler [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = require(var1.Framework)
local var4 = require(var1.Modules.Shared.Zones)
local var5 = workspace:WaitForChild("Map"):WaitForChild("Zones")
local var6 = workspace:WaitForChild("MapEssentials"):WaitForChild("ZoneWalls")
local var7 = Instance.new("Folder")
var7.Name = "HiddenZones"
var7.Parent = var1
local tbl1 = {}
local function ApplyZone(arg1, arg2)
	local var1 = arg2.Unlocked(var2)
	local var3 = var1
	local var4 = tostring(arg1)
	local var8 = var5:FindFirstChild(var4)
	var8 = var8 or var7:FindFirstChild(var4)
	var3 = var3 or arg2.Visible(var2)
	if var8 then
		var4 = if var1 then var5 else var7
		if var8.Parent ~= var4 then
			var8.Parent = var4
		end
	end

	var4 = var6:FindFirstChild((tostring(arg1)))
	if not var4 or (not var4:IsA("BasePart")) then
		return
	end

	if tbl1[var4] == nil then
		tbl1[var4] = var4.Transparency
	end

	local var9 = var3
	var9 = var9 and (not var1)
	local var11 = if var9 then tbl1[var4] else 1
	if var4.Transparency ~= var11 then
		var4.Transparency = var11
	end

	var11 = not var1
	if var4.CanCollide ~= var11 then
		var4.CanCollide = var11
	end

	var11 = not var1
	if var4.CanQuery ~= var11 then
		var4.CanQuery = var11
	end

	var11 = var4:FindFirstChildOfClass("SurfaceGui")
	if not var11 then
		return
	end

	if var11.Enabled ~= var9 then
		var11.Enabled = var9
	end

	local var12 = var11:FindFirstChild("LockedFrame")
	var12 = var12 and var11.LockedFrame:FindFirstChild("TextLabel")
	if var12 then
		if arg2.LockedMessage then
			if var12.RichText ~= true then
				var12.RichText = true
			end

			local var14 = arg2.LockedMessage
			if var12.Text ~= var14 then
				var12.Text = var14
			end
		end
	end
end

return { Init = function(_)
	var3.Stat.WaitForLoad(var2)
	for k1, v1 in var4.Zones, nil do
		local var1 = v1.VisibleStat
		for k2, v2 in { v1.ViewStat, var1 }, nil do
			local var5 = v2
			var5 = var5 and var3.Stat.Get(var2, v2)
			if not var5 then
				continue
			end

			var5.Changed:Connect(function()
				local var1 = k1
				local success, result = pcall(ApplyZone, var1, v1)
				if not success then
					warn((("[ZoneHandler] zone %* failed: %*"):format(var1, result)))
				end
			end)

		end

		local success, result = pcall(ApplyZone, k1, v1)
		if success then
			continue
		end

		warn((("[ZoneHandler] zone %* failed: %*"):format(k1, result)))
	end

	var6.DescendantAdded:Connect(function(arg1)
		local var1 = arg1
		while var1.Parent and var1.Parent ~= var6 do
			var1 = var1.Parent
		end

		local var2 = tonumber(var1.Name)
		local var3 = var2
		var3 = var3 and var4.Zones[var2]
		local success, result = pcall(ApplyZone, var2, var3)
		if var3 and (not success) then
			warn((("[ZoneHandler] zone %* failed: %*"):format(var2, result)))
		end
	end)

	task.spawn(function()
		while task.wait(1) do
			for k1, v1 in var4.Zones, nil do
				local success, result = pcall(ApplyZone, k1, v1)
				if success then
					continue
				end

				warn((("[ZoneHandler] zone %* failed: %*"):format(k1, result)))
			end
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.DailyUpgrades [ModuleScript]
-- y u r i

game:GetService("Debris")
game:GetService("RunService")
local var1 = game:GetService("Players")
local var2 = game:GetService("ReplicatedStorage")
local var3 = var2.Modules
local var4 = var3.Client
require(var4.UI)
local var5 = var3.Shared
require(var5.Multipliers)
require(var5.BigNum)
require(var5.StatInformation)
local var6 = require(var5.DailyUpgrades)
local var7 = require(var2.Framework)
local var8 = var1.LocalPlayer
var7.Stat.WaitForLoad(var8)
local var9 = var7.Stat.GetDataFolder(var8)
local var10 = var6.Currency
local var11 = require(var5.Colours)
local var12 = var2.Assets.Particles
local var13 = game:GetService("TweenService")
local var14 = require(var4.RubyTopUp)
local bool1 = false
local var15 = workspace.MapEssentials.DailyUpgrades
local function HandleDailyButton(arg1)
	var7.Sound.Play("Click")
	var7.VFX.Emit(arg1, var12.Click)
	var13:Create(arg1, TweenInfo.new(0.04, Enum.EasingStyle.Bounce, Enum.EasingDirection.InOut, 0, true), { Position = arg1.Position - Vector3.new(0, 0.15, 0) }):Play()
end

local function Upgraded(arg1)
	var7.Sound.Play("Upgrade")
	var7.VFX.Emit(var8.Character.HumanoidRootPart, var12.Upgrade)
	HandleDailyButton(var15[arg1].Head)
end

local var16 = require(var4.Suffix)
local function TryBuy(arg1)
	local var2 = var6.Upgrades[arg1.Name]
	if not var2 then
		return
	end

	local var3 = var7.Stat.Get(var8, arg1.Name)
	local var4 = var7.Stat.Get(var8, var10)
	if var2.Cap <= var3.Value then
		return
	end

	local var11 = var2.Info(var3.Value).Price
	if var6.IsUnlocked(var9, arg1.Name) and var4.Value < var11 then
		var14.Prompt(var11 - var4.Value)
		return
	end

	if not bool1 then
		bool1 = true
		var7.Network.Fire("DailyUpgrade", arg1.Name)
		task.wait(0.2)
		bool1 = false
	end
end

local function UpdateVisibility(arg1, arg2)
	local var1 = var7.Stat.Get(var8, arg1.Name)
	local var2 = var6.IsUnlocked(var9, arg1.Name)
	local var3 = var7.Stat.Get(var8, var10)
	local var4 = arg1.Head.InfoGui.Frame
	local var5 = arg2.Info(var1.Value).Price
	local var12 = arg2.Cap
	for k1, v1 in arg1.Connections:GetChildren() do
		if var2 then
			if var1.Value == 0 then
				if var5 <= var3.Value then
					v1.Color = var11.UpgradeTree.Visible
				else
					v1.Color = var11.Expensive.Colour
					continue
				end
			else
				if var2 and 1 <= var1.Value then
					v1.Color = var11.UpgradeTree.Purchased
				else
					v1.Color = var11.UpgradeTree.Locked
				end
			end
		else
			if var2 and 1 <= var1.Value then
				v1.Color = var11.UpgradeTree.Purchased
			else
				v1.Color = var11.UpgradeTree.Locked
			end
		end
	end

	if var2 then
		if var1.Value == 0 then
			if var5 <= var3.Value then
				arg1.Head.Color = var11.UpgradeTree.Visible
				arg1.Base.Color = var11.UpgradeTree.Visible
			else
				arg1.Head.Color = var11.Expensive.Colour
				arg1.Base.Color = var11.Expensive.Colour
			end
		else
			if var2 and 1 <= var1.Value then
				arg1.Head.Color = var11.UpgradeTree.Purchased
				arg1.Base.Color = var11.UpgradeTree.Purchased
			else
				arg1.Head.Color = var11.UpgradeTree.Locked
				arg1.Base.Color = var11.UpgradeTree.Locked
			end
		end
	else
		if var2 and 1 <= var1.Value then
			arg1.Head.Color = var11.UpgradeTree.Purchased
			arg1.Base.Color = var11.UpgradeTree.Purchased
		else
			arg1.Head.Color = var11.UpgradeTree.Locked
			arg1.Base.Color = var11.UpgradeTree.Locked
		end
	end

	if 1 < var12 then
		var4.Cap.Visible = true
		var4.Cap.Text = var1.Value .. "/" .. var12
	end
end

local var17 = game:GetService("UserInputService")
local var18 = var8:GetMouse()
return { Init = function(_)
	var7.Stat.WaitForLoad(var8)
	local var2 = var7.Stat.GetDataFolder(var8).TempValues
	repeat
		task.wait()
	until var2:WaitForChild("FeaturesLoaded").Value

	var7.Network.Connect("DailyUpgrade", Upgraded)
	for k1, v1 in var15:GetChildren() do
		local var3 = var6.Upgrades[v1.Name]
		if not var3 then
			continue
		end

		local var4 = var7.Stat.Get(var8, v1.Name)
		local var5 = v1:WaitForChild("Head")
		local var9 = var5.InfoGui.Frame
		local var11 = var7.Stat.Get(var8, var10)
		local var12 = var3.Info(var4.Value).Price
		var9.UpgradeName.Text = var3.Display
		var9.Price.Text = var16.short(var12)
		var5.Touched:Connect(function(arg1)
			local var3 = var1:GetPlayerFromCharacter(arg1.Parent)
			if not var3 then
				return
			end

			if var3 ~= var8 then
				return
			end

			TryBuy(v1)
		end)

		var11.Changed:Connect(function()
			UpdateVisibility(v1, var3)
		end)

		var4.Changed:Connect(function()
			UpdateVisibility(v1, var3)
		end)

		for k2, v2 in var6.GetWatchedStats(v1.Name) do
			local var13 = var7.Stat.Get(var8, v2)
			if not var13 then
				continue
			end

			var13.Changed:Connect(function()
				UpdateVisibility(v1, var3)
			end)

		end

		UpdateVisibility(v1, var3)
	end

	var17.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.UserInputType ~= Enum.UserInputType.Touch then
			if arg1.KeyCode ~= Enum.KeyCode.ButtonR2 then
				return
			end
		end

		local var4 = var18.Target
		local var5
		if not var4 or (not var4.Parent) then
			var5 = nil
		else
			var5 = if var4.Parent.Parent ~= var15 then nil else var4.Parent
		end

		if var5 then
			TryBuy(var5)
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Achievements [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
local var5 = require(var3.UI)
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = var6.Stat.GetDataFolder(var7)
local var9 = require(var4.StatInformation)
local var10 = require(var4.BigNum)
local var11 = require(var3.Suffix)
local var12 = require(var4.Features)
local var13 = nil
local var14 = require(var4.Achievements)
local tbl1 = {}
local var15 = var5.PopUps
local var16 = var9.Diamond.Colour
local var17 = var1.Frames
local function FormatAmount(arg1, arg2)
	if arg1.ShortenType == "Time" then
		local var1 = tonumber(arg2)
		return (var6.Short.toTime(var1 or var10.toNumber(arg2)):gsub("^%s+", ""):gsub("%s+$", ""))
	end

	local var2 = arg2
	return var11.short(var2)
end

local var18 = require(var4.Colours)
local function UpdateBoardNotification()
	if not var13 then
		return
	end

	local bool1 = false
	for k1, v1 in var14, nil do
		local var1
		if not var12.Achievements.Unlocked(var7) then
			var1 = false
		else
			local var4 = var8.Achievements:FindFirstChild(k1)
			local var5 = var6.Stat.Get(var7, v1.Stat)
			local var9
			local var11
			local var15
			if not var4 or (not var5) then
				var9 = nil
				var11 = nil
				var15 = nil
			else
				var9 = var4
				var11 = var5
				var15 = v1.Milestones[var4.Value + 1]
			end

			var1 = false
			if var9 ~= nil then
				var1 = false
				if var15 ~= nil then
					var1 = var10.gte(var11.Value, var15.Req)
				end
			end
		end

		if not var1 then
			continue
		end

		bool1 = true
		break
	end

	var13.Visible = bool1
end

local var19 = require(var3.Hover)
local var20 = var8.TempValues
local var21 = require(var4.FeatureHandler)
local var22 = require(var3.ConsoleScroll)
local function CreateRow(arg1, arg2, arg3)
	local var1 = var17.Achievement:Clone()
	local var2 = var1.Progressbar.Bar
	local var3 = var1.Boosts
	local var4 = var3.Claim
	var1.Name = arg2
	var1.LayoutOrder = arg3.Rank or 0
	var1.Title.Title.Text = arg3.Display
	var1.Title.Title.TextLabel.Text = arg3.Display
	local var5 = arg3.Icon
	local var13 = var9[var5]
	local var14 = var2.Size
	local var20 = var4.Size
	local var21 = var1.Icon
	var21.Image = if var13 then var13.Icon else var5
	var5 = arg3.RewardStat
	var13 = var9[var5]
	var21 = var3.Icon
	var21.Image = if var13 then var13.Icon else var5
	var4.MouseButton1Click:Connect(function()
		var6.Sound.Play("UIClick")
		local var1 = arg2
		local var2 = arg3
		local var3
		if not var12.Achievements.Unlocked(var7) then
			var3 = false
		else
			local var9 = var8.Achievements:FindFirstChild(var1)
			local var11 = var6.Stat.Get(var7, var2.Stat)
			local var13
			local var14
			local var15
			if not var9 or (not var11) then
				var13 = nil
				var15 = nil
				var14 = nil
			else
				var13 = var9
				var15 = var11
				var14 = var2.Milestones[var9.Value + 1]
			end

			var3 = false
			if var13 ~= nil then
				var3 = false
				if var14 ~= nil then
					var3 = var10.gte(var15.Value, var14.Req)
				end
			end
		end

		if not var3 then
			return
		end

		var6.Network.Fire("ClaimAchievement", arg2)
	end)

	var19.CreateHover(var4, var20)
	var13 = var8.Achievements:FindFirstChild(arg2)
	local var23 = var6.Stat.Get(var7, arg3.Stat)
	var21 = function()
		local var5 = arg3
		local var13 = var8.Achievements:FindFirstChild(arg2)
		local var17 = var6.Stat.Get(var7, var5.Stat)
		local var19
		local var20
		local var21
		if not var13 or (not var17) then
			var21 = nil
			var19 = nil
			var20 = nil
		else
			var21 = var13
			var19 = var17
			var20 = var5.Milestones[var13.Value + 1]
		end

		if not var21 then
			return
		end

		local var23 = var20 == nil
		var5 = if var23 then arg3.Milestones[#arg3.Milestones] else var20
		if var23 then
			var13 = 1
		else
			local var24 = var19.Value
			local var25 = var5.Req
			var17 = var10.toNumber(var10.div(var24, var25))
			var13 = math.clamp(var17, 0, 1)
		end

		var2.Size = UDim2.new(var13, 0, var14.Y.Scale, var14.Y.Offset)
		var1.Progressbar.Percentage.Text = ("%*%%"):format((math.floor(var13 * 100)))
		var17 = var1.Progressbar.Progress
		local var26 = if var23 then "Completed" else ("%* / %*"):format(FormatAmount(arg3, var19.Value), (FormatAmount(arg3, var5.Req)))
		var17.Text = var26
		var3.Reward.Text = ("+%*"):format(var5.Reward)
		var26 = arg2
		local var27 = arg3
		if not var12.Achievements.Unlocked(var7) then
			var17 = false
		else
			local var30 = var8.Achievements:FindFirstChild(var26)
			local var31 = var6.Stat.Get(var7, var27.Stat)
			local var32
			local var33
			local var34
			if not var30 or (not var31) then
				var33 = nil
				var32 = nil
				var34 = nil
			else
				var33 = var30
				var32 = var31
				var34 = var27.Milestones[var30.Value + 1]
			end

			var17 = false
			if var33 ~= nil then
				var17 = false
				if var34 ~= nil then
					var17 = var10.gte(var32.Value, var34.Req)
				end
			end
		end

		var26 = var4.Boost
		var26.Text = if var23 then "Maxed" else "Claim"
		var26 = var4.UIGradient
		if var23 then
			var27 = var18.Maxed.Gradient
		elseif var17 then
			var27 = var18.Afford.Gradient
		else
			var27 = var18.Expensive.Gradient
		end

		var26.Color = var27
		var26 = arg2
		var27 = arg3
		if not var12.Achievements.Unlocked(var7) then
			var33 = false
		else
			local var37 = var8.Achievements:FindFirstChild(var26)
			local var38 = var6.Stat.Get(var7, var27.Stat)
			local var39
			if not var37 or (not var38) then
				var32 = nil
				var34 = nil
				var39 = nil
			else
				var32 = var37
				var34 = var38
				var39 = var27.Milestones[var37.Value + 1]
			end

			var33 = false
			if var32 ~= nil then
				var33 = false
				if var39 ~= nil then
					var33 = var10.gte(var34.Value, var39.Req)
				end
			end
		end

		if tbl1[var26] == false and var33 then
			var15.NormalPopUp("Achievement completed! Claim your reward on the Achievements board", var16, 5)
			var6.Sound.Play("Notification")
		end

		tbl1[var26] = var33
		UpdateBoardNotification()
	end

	local var24
	if not var13 or (not var23) then
		var24 = nil
		var5 = nil
	else
		var24 = var13
		var5 = var23
		local var25 = arg3.Milestones[var13.Value + 1]
	end

	if var5 then
		var5.Changed:Connect(var21)
	end

	if var24 then
		var24.Changed:Connect(var21)
	end

	var1.Parent = arg1
	var21()
	return var21
end

local var23 = var1.Assets.Particles
return { Init = function(_)
	repeat
		task.wait()
	until var20:WaitForChild("FeaturesLoaded").Value

	local var1 = var21.GetFeature("Achievements"):WaitForChild("Board")
	local var2 = var1:FindFirstChild("BillboardGui")
	local var3 = var2
	var3 = var3 and var2:FindFirstChild("Notification")
	var13 = var3
	local var4 = var1.SurfaceGui.Frame
	var3 = var4:FindFirstChildWhichIsA("ScrollingFrame")
	local var11 = nil
	for k1, v1 in var4:GetChildren() do
		local var17 = v1:IsA("GuiObject")
		if not var17 then
			continue
		end

		var17 = v1:FindFirstChild("Up")
		if not var17 then
			continue
		end

		var17 = v1:FindFirstChild("Down")
		if not var17 then
			continue
		end

		var11 = v1
		break
	end

	if var11 then
		var22.SetupScroll(var11, var3)
	end

	var5.ConnectListAutoScale(var3)
	local tbl1 = {}
	for k2, v2 in var14, nil do
		table.insert(tbl1, (CreateRow(var3, k2, v2)))
	end

	var6.Network.Connect("ClaimAchievement", function(arg1, arg2)
		var6.Sound.Play("Achievement")
		local var1 = var7.Character
		var1 = var1 and var7.Character:FindFirstChild("HumanoidRootPart")
		if var1 then
			var6.VFX.Emit(var1, var23.Upgrade)
		end

		local var2 = var14[arg1]
		local var3 = var2
		var3 = var3 and var9[var2.RewardStat]
		if var3 and arg2 then
			task.spawn(var15.CreatePopUp, var7, var3.Icon, arg2, var3.Colour)
		end
	end)

	var6.Stat.Get(var7, var12.Achievements.ViewStat).Changed:Connect(function()
		for k1, v1 in tbl1, nil do
			v1()
		end
	end)

	for k3, v3 in var14, nil do
		local var18
		if not var12.Achievements.Unlocked(var7) then
			var18 = false
		else
			local var25 = var8.Achievements:FindFirstChild(k3)
			local var26 = var6.Stat.Get(var7, v3.Stat)
			local var27
			local var28
			local var29
			if not var25 or (not var26) then
				var27 = nil
				var29 = nil
				var28 = nil
			else
				var27 = var25
				var29 = var26
				var28 = v3.Milestones[var25.Value + 1]
			end

			var18 = false
			if var27 ~= nil then
				var18 = false
				if var28 ~= nil then
					var18 = var10.gte(var29.Value, var28.Req)
				end
			end
		end

		if not var18 then
			continue
		end

		var15.NormalPopUp("You have Achievement rewards to claim!", var16, 4)
		return
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Leaves [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
local var4 = var2.Client
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = var1.Assets
local var8 = game:GetService("UserInputService")
local var9 = game:GetService("TweenService")
local var10 = game:GetService("RunService")
local var11 = require(var3.Leaves)
local var12 = require(var3.Multipliers)
local var13 = require(var3.StatInformation)
local var14 = require(var3.FeatureHandler)
local var15 = require(var3.Features)
local var16 = require(var4.Suffix)
local var17 = require(var4.UI).PopUps
local var18 = var5.Stat.GetDataFolder(var6).TempValues
local var19 = var5.Stat.Get(var6, "PopUpsSetting")
local var20 = var6:GetMouse()
local var21 = var5.Stat.Get(var6, "Device")
local var22 = Instance.new("Folder")
var22.Name = "SpawnedLeaves"
var22.Parent = workspace
local var23 = Instance.new("Folder")
var23.Name = "LeafEffects"
var23.Parent = workspace
local var24 = var7.Leaves
local var25 = nil
local function PlaceLeaf(arg1)
	local var1 = var25.Size
	local var4 = Vector3.new(var25.Position.X, var25.Position.Y + var1.Y / 2, var25.Position.Z) + Vector3.new((math.random() - 0.5) * var1.X, 0, (math.random() - 0.5) * var1.Z)
	local var5 = CFrame.Angles(0, math.random() * 3.1415926535897931 * 2, 0)
	if arg1:IsA("Model") then
		local var6, var7 = arg1:GetBoundingBox()
		arg1:PivotTo(CFrame.new(var4 + Vector3.new(0, var7.Y / 2 + 0.02, 0)) * var5)
		return
	end

	arg1.CFrame = CFrame.new(var4 + Vector3.new(0, arg1.Size.Y / 2 + 0.02, 0)) * var5
end

local var26 = var7.Particles
local function Popup(_, arg2, arg3)
	if not var19.Value then
		return
	end

	local var1 = Instance.new("Part")
	var1.Size = Vector3.new(1, 1, 1)
	var1.Transparency = 1
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.CFrame = CFrame.new(arg2 + Vector3.new(0, 2, 0))
	var1.Parent = var23
	local var2 = script.BillboardGui:Clone()
	local var3 = var13.Leaves
	local var4 = var2.Frame.Inner
	var4.Amount.Text = ("+%*"):format((var16.short(arg3)))
	var3 = var3 and var13.Leaves.Icon
	if var3 then
		var4.CurrencyImage.Image = var3
	else
		var4.CurrencyImage.Visible = false
	end

	var2.Parent = var1
	var2.Enabled = true
	local var5 = TweenInfo.new(1, Enum.EasingStyle.Exponential)
	var9:Create(var1, var5, { Position = var1.Position + Vector3.new(0, 3, 0) }):Play()
	task.delay(0.6, function()
		if not var1.Parent then
			return
		end

		local var2 = TweenInfo.new(0.4)
		var9:Create(var4.Amount, var2, { TextTransparency = 1 }):Play()
		var9:Create(var4.Amount.UIStroke, var2, { Transparency = 1 }):Play()
		var9:Create(var4.CurrencyImage, var2, { ImageTransparency = 1 }):Play()
		task.wait(0.4)
		var1:Destroy()
	end)
end

local function AnimatePickup(arg1)
	local var1 = arg1:GetDescendants()
	table.insert(var1, arg1)
	local var2 = TweenInfo.new(0.3)
	for k1, v1 in var1, nil do
		if v1:IsA("Decal") then
			var9:Create(v1, var2, { Transparency = 1 }):Play()
		else
			if not v1:IsA("BasePart") then
				continue
			end

			v1.CanQuery = false
			var9:Create(v1, var2, { Transparency = 1, CFrame = v1.CFrame + Vector3.new(0, 5, 0) }):Play()
		end
	end

	task.delay(0.8, function()
		if not arg1.Parent then
			return
		end

		arg1:Destroy()
	end)
end

local bool1 = false
local tbl1 = {}
local num1 = -math.huge
local function Flush()
	bool1 = false
	if #tbl1 == 0 then
		return
	end

	local var1 = tbl1
	tbl1 = {}
	while var11.FieldCap < (#var1) do
		local var2 = var1
		table.insert(tbl1, table.remove(var2))
	end

	num1 = os.clock()
	var5.Network.Fire("CollectLeaf", var1)
	if 0 < (#tbl1) then
		bool1 = true
		task.delay(0.1, Flush)
	end
end

local var27 = nil
local function PlayCollectEffects(arg1, arg2, arg3)
	local var1
	if arg1:IsA("Model") then
		var1 = arg1.PrimaryPart
		if not var1 then
			var1 = arg1:FindFirstChildWhichIsA("BasePart")
		end
	else
		var1 = arg1
	end

	if var1 then
		var5.VFX.Emit(var1, var26.Collect)
		var5.Sound.Play("LeafCollect", var1)
	end

	Popup(arg1, arg2, arg3)
	AnimatePickup(arg1)
end

local num2 = 0
local function QueueSend(arg1)
	for k1, v1 in arg1, nil do
		table.insert(tbl1, v1)
	end

	if bool1 then
		return
	end

	local var2 = 0.1 - (os.clock() - num1)
	if var2 <= 0 then
		Flush()
		return
	end

	bool1 = true
	task.delay(var2, Flush)
end

local var28 = var1.Remotes
local function SpawnLeaf(arg1)
	if var22:FindFirstChild(arg1) then
		return
	end

	local var1 = var24:GetChildren()
	local var3 = if #var1 == 0 then nil else var1[math.random(1, #var1)]
	if not var3 then
		return
	end

	var1 = var3:Clone()
	var1.Name = arg1
	local var4
	local var5
	if var1:IsA("Model") then
		var4 = var1:GetDescendants()
	else
		var4 = { var1 }
	end

	for k1, v1 in var4, nil do
		if not v1:IsA("BasePart") then
			continue
		end

		v1.Anchored = true
		v1.CanCollide = false
		v1.CanTouch = false
		v1.CastShadow = false
		v1.CanQuery = true
	end

	PlaceLeaf(var1)
	var1.Parent = var22
end

local function CollectLeaves(arg1, arg2)
	if not arg1 and #arg2 == 0 then
		return
	end

	if not var15.Leaf.Unlocked(var6) then
		return
	end

	local var1 = var6.Character
	var1 = var1 and var6.Character:FindFirstChild("HumanoidRootPart")
	local bool2 = false
	if var1 ~= nil then
		bool2 = var11.IsInField(var27, var1.Position, var11.FieldMargin)
	end

	if not bool2 then
		return
	end

	var1 = {}
	bool2 = var12.GetLeafMultiplier(var6)
	local var2
	if arg1 then
		if arg1.Parent ~= var22 then
		else
			local var3 = if arg1:IsA("Model") then arg1:GetPivot().Position else arg1.Position
			arg1.Parent = var23
			table.insert(var1, arg1.Name)
			var2 = bool2
			PlayCollectEffects(arg1, var3, var2)
		end
	end

	for k1, v1 in arg2, nil do
		if v1.Parent ~= var22 then
		else
			local var4 = if v1:IsA("Model") then v1:GetPivot().Position else v1.Position
			v1.Parent = var23
			table.insert(var1, v1.Name)
			PlayCollectEffects(v1, var4, bool2)
		end
	end

	if #var1 == 0 then
		return
	end

	local var5 = num2 + 1
	num2 = var5
	QueueSend(var1)
end

local function LeavesNear(arg1, arg2)
	local tbl1 = {}
	if arg2 <= 0 then
		return tbl1
	end

	for k1, v1 in var22:GetChildren() do
		if not v1:IsA("BasePart") then
			if not v1:IsA("Model") then
				continue
			end
		end

		if arg2 < ((if v1:IsA("Model") then v1:GetPivot().Position else v1.Position) - arg1).Magnitude then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end

local num3 = 0
local bool2 = false
local bool3 = false
local var29 = nil
local var30 = nil
local function FieldSpot()
	local var1 = var20.Hit.Position
	local var2 = var25.CFrame:PointToObjectSpace(var1)
	local var3 = var25.Size
	if var3.X / 2 < math.abs(var2.X) or var3.Z / 2 < math.abs(var2.Z) then
		return nil
	end

	return (Vector3.new(var1.X, var25.Position.Y + var3.Y / 2 + 0.05, var1.Z))
end

local num4 = 0
local function CheckHover()
	if var21.Value ~= "Mobile" then
		if not var15.Leaf.Unlocked(var6) then
			if bool2 == false then
				return
			end

			bool2 = false
			if var20.Icon == "rbxassetid://125926190001856" then
				var20.Icon = ""
			end

			return
		end
	end

	local var1 = var6.Character
	var1 = var1 and var6.Character:FindFirstChild("HumanoidRootPart")
	local bool3 = false
	if var1 ~= nil then
		bool3 = var11.IsInField(var27, var1.Position, var11.FieldMargin)
	end

	local var2
	if bool3 then
		bool3 = var20.Target
		if not bool3 then
			var2 = nil
		else
			if bool3.Parent == var22 then
				var2 = bool3
			else
				if bool3.Parent and bool3.Parent.Parent == var22 then
					var2 = bool3.Parent
				else
					var2 = nil
				end
			end
		end
	else
		var2 = nil
	end

	bool3 = var2 ~= nil
	if bool3 ~= bool2 then
		bool2 = bool3
		if bool3 then
			var20.Icon = "rbxassetid://125926190001856"
		else
			if var20.Icon == "rbxassetid://125926190001856" then
				var20.Icon = ""
			end
		end
	end

	if var12.CanHoverCollectLeaves(var6) then
		CollectLeaves(var2, (LeavesNear(var20.Hit.Position, num3)))
	end
end

local function UpdateHover(arg1)
	local var2 = nil
	local var3 = num3
	if bool3 then
		local var4 = var6.Character
		var4 = var4 and var6.Character:FindFirstChild("HumanoidRootPart")
		local bool5 = false
		if var4 ~= nil then
			bool5 = var11.IsInField(var27, var4.Position, var11.FieldMargin)
		end

		if bool5 then
			if var21.Value ~= "Mobile" then
				var2 = FieldSpot()
				if var2 then
					var4 = var20.Target
					if not var4 then
						bool5 = nil
					else
						if var4.Parent == var22 then
							bool5 = var4
						else
							bool5 = if var4.Parent and var4.Parent.Parent == var22 then var4.Parent else nil
						end
					end

					var4 = bool5 ~= nil
	if var4 ~= bool2 then
						bool2 = var4
						if var4 then
							var20.Icon = "rbxassetid://125926190001856"
						else
							if var20.Icon == "rbxassetid://125926190001856" then
								var20.Icon = ""
							end
						end
					end

					CollectLeaves(bool5, (LeavesNear(var20.Hit.Position, num3)))
				end
			else
				bool5 = var6.Character
				bool5 = bool5 and var6.Character:FindFirstChild("HumanoidRootPart")
				var3 = math.max(num3, var11.MobileHoverRadius)
				var2 = if not bool5 then nil else Vector3.new(bool5.Position.X, var25.Position.Y + var25.Size.Y / 2 + 0.05, bool5.Position.Z)
				if var2 then
					CollectLeaves(nil, (LeavesNear(var2, var3)))
				end
			end
		end
	end

	if var2 then
		if var3 <= 0 then
			if var30.Transparency == 1 then
				return
			end

			var30.Transparency = 1
			return
		end
	end

	local var7 = var3 * 2
	if var29.Size.Y ~= var7 then
		var29.Size = Vector3.new(0.2, var7, var7)
	end

	local var8 = (num4 + arg1 * 60) % 360
	num4 = var8
	var29.CFrame = CFrame.new(var2) * CFrame.Angles(0, 1.5707963267948966, 1.5707963267948966) * CFrame.Angles(math.rad(num4), 0, 0)
	if var30.Transparency == 0 then
		return
	end

	var30.Transparency = 0
end

local var31 = nil
local var32 = nil
local var33 = nil
local var34 = nil
local function UpdateProgressColour(arg1)
	local var1 = arg1 * 0.26
	local var2 = var1
	local num1 = 0.7
	local num2 = 1
	local var3 = ColorSequenceKeypoint.new(0, Color3.fromHSV(var2, num1, num2))
	num1 = var1
	num2 = 1
	local num3 = 0.7
	local var4 = ColorSequenceKeypoint.new(0.5, Color3.fromHSV(num1, num2, num3))
	num2 = var1
	num3 = 0.7
	local num4 = 1
	var2 = 1
	var31.UIGradient.Color = ColorSequence.new({ var3, var4, ColorSequenceKeypoint.new(var2, Color3.fromHSV(num2, num3, num4)) })
	var31.UIStroke.Color = Color3.fromHSV(var1, 1, 0.67)
end

local var35 = nil
local function UpdateLabels()
	local var1 = var5.Stat.Get(var6, "LeavesLevel").Value
	local var2 = var5.Stat.Get(var6, "LeavesLeft").Value
	local var3 = var11.Levels[math.clamp(var1, 1, #var11.Levels)]
	var32.Text = ("Level %*"):format((math.max(var1, 1)))
	var33.Text = ("%*/%*"):format(var16.short(var2), (var16.short(var3)))
	local var4 = math.clamp(var2 / var3, 0, 1)
	var31:TweenSize(UDim2.new(var4, 0, 1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.05, true)
	var34.Text = ("%*%%"):format((math.floor(var4 * 100)))
	UpdateProgressColour(var4)
end

local function PlayLevelUp()
	local var1 = var6.Character
	var5.Sound.Play("TreeLevelUp", var25)
	var1 = var1 and var6.Character:FindFirstChild("HumanoidRootPart")
	if var1 then
		var5.VFX.Emit(var1, var26.LeafLevelUp)
	end

	var17.NormalPopUp("Your leaves levelled up", var13.Leaves.Colour)
end

local function CreateHoverRange()
	var29 = Instance.new("Part")
	var29.Name = "LeafHoverRange"
	var29.Shape = Enum.PartType.Cylinder
	var29.Color = Color3.fromRGB(0, 0, 0)
	var29.Transparency = 1
	var29.Anchored = true
	var29.CanCollide = false
	var29.CanTouch = false
	var29.CanQuery = false
	var29.CastShadow = false
	var29.Parent = var23
	var30 = var7.RangeDecal:Clone()
	var30.Transparency = 1
	var30.Parent = var29
end

local function Resync()
	if not var15.Leaf.Unlocked(var6) then
		return
	end

	if bool1 or (0 < (#tbl1) or os.clock() - num1 < 1) then
		return
	end

	local success, result = pcall(function()
		return var28.LeafField:InvokeServer()
	end)

	local var1 = num2
	if not success or type(result) ~= "table" then
		return
	end

	if var1 ~= num2 or (bool1 or 0 < (#tbl1)) then
		return
	end

	for k1 in result, nil do
		SpawnLeaf(k1)
	end

	for k2, v1 in var22:GetChildren() do
		if result[v1.Name] then
			continue
		end

		v1:Destroy()
	end
end

return { Init = function(_)
	repeat
		task.wait()
	until var18:WaitForChild("FeaturesLoaded").Value

	var35 = var14.GetFeature("Leaf")
	if not var35 then
		return
	end

	var25 = var35:WaitForChild("Spawnable")
	var27 = var35:WaitForChild("SpawnableRegion")
	local var1 = var25:WaitForChild("BillboardGui").Frame
	var32 = var1.Level
	var33 = var1.Amount
	var31 = var1.Progressbar.Bar
	var34 = var1.Progressbar.Progress
	var5.Network.Connect("LeafSpawn", SpawnLeaf)
	var5.Network.Connect("LeafCleared", function()
		var22:ClearAllChildren()
	end)

	var8.InputBegan:Connect(function(arg1, arg2)
		if arg2 then
			return
		end

		if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
			if not (arg1.UserInputType == Enum.UserInputType.Touch or arg1.KeyCode == Enum.KeyCode.ButtonR2) then
				return
			end

			if arg1.KeyCode ~= Enum.KeyCode.ButtonR2 then
				return
			end
		end

		local var2 = var20.Target
		local var3
		if not var2 then
			var3 = nil
		else
			if var2.Parent == var22 then
				var3 = var2
			else
				var3 = if var2.Parent and var2.Parent.Parent == var22 then var2.Parent else nil
			end
		end

		if var3 then
			if var3.Parent ~= var22 then
				return
			end

			var2 = CollectLeaves
			local var4 = var3
			local var5 = LeavesNear
			local var7 = var6
			var2(var4, (var5(if var3:IsA("Model") then var3:GetPivot().Position else var3.Position, var12.GetLeafClickRadius(var7))))
		end
	end)

	local var2 = var5.Stat.Get(var6, "LeavesLevel")
	local var3 = var2.Value
	var2.Changed:Connect(function()
		local bool1 = false
		if 1 <= var3 then
			bool1 = var3 < var2.Value
		end

		var3 = var2.Value
		UpdateLabels()
		if bool1 then
			PlayLevelUp()
		end
	end)

	var5.Stat.Get(var6, "LeavesLeft").Changed:Connect(UpdateLabels)
	CreateHoverRange()
	local var4 = var15.Leaf.Unlocked(var6)
	var4 = var4 and var12.CanHoverCollectLeaves(var6)
	bool3 = var4
	local var7 = if var4 then var12.GetLeafHoverRadius(var6) else 0
	num3 = var7
	var20.Move:Connect(CheckHover)
	var10.RenderStepped:Connect(UpdateHover)
	task.spawn(function()
		while true do
			local var1 = task.wait
			var1(if var15.Leaf.Unlocked(var6) then 0.25 else 2)
			var1 = var15.Leaf.Unlocked(var6)
			var1 = var1 and var12.CanHoverCollectLeaves(var6)
			bool3 = var1
			local var2 = if var1 then var12.GetLeafHoverRadius(var6) else 0
			num3 = var2
			CheckHover()
		end
	end)

	UpdateLabels()
	for k1 in var28.LeafField:InvokeServer() do
		SpawnLeaf(k1)
	end

	task.spawn(function()
		while task.wait(10) do
			Resync()
		end
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.LeafUpgrades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
local var4 = var2.Client
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = require(var3.LeafUpgrades)
local var8 = require(var3.StatInformation)
local var9 = require(var4.Hover)
local tbl1 = {}
local var10 = var8[var7.Currency].Colour:ToHex()
local var11 = require(var4.Suffix)
local var12 = require(var3.BigNum)
local var13 = require(var3.Colours)
local var14 = nil
local var15 = var1.Frames
local function CreateButtonEffects(arg1)
	local var1 = arg1.Size
	arg1.MouseEnter:Connect(function()
		var9.Hover(arg1, var1)
	end)

	arg1.MouseLeave:Connect(function()
		var9.Up(arg1, var1)
	end)

	arg1.MouseButton1Down:Connect(function()
		var9.Down(arg1, var1)
	end)

	arg1.MouseButton1Up:Connect(function()
		var9.Up(arg1, var1)
	end)
end

local function UpdateRow(arg1)
	local var1 = tbl1[arg1]
	local var4 = var5.Stat.Get(var6, arg1)
	local var8 = var5.Stat.Get(var6, var7.Currency)
	local var9 = var1.Frame
	if not var4 or (not var8) then
		return
	end

	local var14 = var7.IsMaxed(var6, arg1)
	local var15 = var7.GetBoost(var6, arg1)
	var9.Amount.Text = ("<font color=\"#%*\">%*</font>: %*"):format(var10, var7.Display, (var11.short(var4.Value)))
	local var16 = var15
	local var17 = "Boost: " .. string.format(var1.Info.Format, var11.short(var16))
	var16 = var4.Value
	local var18 = var8.Value
	local var19 = var12.sub(var7.GetBoost(var6, arg1, var12.add(var16, var18)), var15)
	var17 = var14 or var12.gt(var8.Value, 0) and (var12.gt(var19, 0) and var17 .. (" (+%*x)"):format((var11.short(var19))))
	var9.Boost.Text = var17
	if var14 then
		var9.Buy.UIGradient.Color = var13.Maxed.Gradient
		var9.Buy.Boost.Text = "Maxed"
		return
	end

	if var12.gt(var8.Value, 0) then
		var9.Buy.UIGradient.Color = var13.Afford.Gradient
		var9.Buy.Boost.Text = "Deposit"
		return
	end

	var9.Buy.UIGradient.Color = var13.Expensive.Gradient
	var9.Buy.Boost.Text = "Deposit"
end

local var16 = var1.Assets.Particles
local var17 = var5.Stat.GetDataFolder(var6).TempValues
local var18 = require(var3.FeatureHandler)
local function Deposited()
	local var1 = var6.Character
	var5.Sound.Play("Upgrade")
	var1 = var1 and var6.Character:FindFirstChild("HumanoidRootPart")
	if var1 then
		var5.VFX.Emit(var1, var16.Upgrade)
	end
end

local function CreateRow(arg1, arg2, arg3)
	local var1 = var15.DepositUpgrade:Clone()
	var1.Name = arg2
	var1.LayoutOrder = arg3.Rank
	var1.Upgrade.Text = arg3.Display
	var1.Upgrade.TextLabel.Text = arg3.Display
	var1.ImageLabel.Image = if var8[arg3.Icon] then var8[arg3.Icon].Icon else arg3.Icon
	var1.Parent = arg1
	tbl1[arg2] = { Frame = var1, Info = arg3 }
	var1.Buy.MouseButton1Click:Connect(function()
		var5.Sound.Play("UIClick")
		var5.Network.Fire("LeafDeposit", arg2)
	end)

	CreateButtonEffects(var1.Buy)
	var5.Stat.Get(var6, arg2).Changed:Connect(function()
		UpdateRow(arg2)
	end)

	UpdateRow(arg2)
	local var2 = tbl1[arg2]
	var2.Frame.Visible = var2.Info.Unlocked(var6)
end

return { Init = function(_)
	repeat
		task.wait()
	until var17:WaitForChild("FeaturesLoaded").Value

	local var2 = var18.GetFeature(var7.Board)
	if not var2 then
		return
	end

	local var3 = var2:FindFirstChild(var7.Currency)
	local var4 = var3
	var14 = var4 and var3.SurfaceGui.Frame.TextLabel
	var5.Network.Connect("LeafDeposit", Deposited)
	local var8 = var2.Board.SurfaceGui.Frame.Main
	var4 = {}
	for k1, v1 in var7.Upgrades, nil do
		CreateRow(var8, k1, v1)
		local var9 = var4[v1.ChangeStat]
		var4[v1.ChangeStat] = var9 or {}
		table.insert(var4[v1.ChangeStat], k1)
	end

	for k2, v2 in var4, nil do
		var5.Stat.Get(var6, k2).Changed:Connect(function()
			for k1, v1 in v2, nil do
				local var1 = tbl1[v1]
				var1.Frame.Visible = var1.Info.Unlocked(var6)
				UpdateRow(v1)
			end
		end)

	end

	var5.Stat.Get(var6, var7.Currency).Changed:Connect(function()
		local var1
		if not not var14 then
			var1 = var6
			var14.Text = var11.short(var5.Stat.Get(var1, var7.Currency).Value)
		end

		for k1 in tbl1, nil do
			UpdateRow(k1)
		end
	end)

	if not var14 then
		return
	end

	var14.Text = var11.short(var5.Stat.Get(var6, var7.Currency).Value)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Soil [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
local var5 = require(var4.Requirements)
local var6 = require(var4.StatInformation)
local var7 = var5.Soil.Stat
local var8 = require(var1.Framework)
local var9 = game:GetService("Players").LocalPlayer
var8.Stat.WaitForLoad(var9)
local var10 = require(var4.Multipliers)
local var11 = require(var4.BigNum)
local var12 = var8.Stat.Get(var9, var7)
local var13 = var5.Soil.Amount
local var14 = require(var3.Suffix)
local var15 = require(var4.Colours)
local var16 = var1.Assets.Particles
local var17 = require(var3.UI).PopUps
local var18 = var8.Stat.GetDataFolder(var9).TempValues
local function Converted(arg1)
	var8.VFX.Emit(var9.Character.HumanoidRootPart, var16.Soil)
	var8.Sound.Play("Soil")
	var17.CreatePopUp(var9, var6.Soil.Icon, arg1, var6.Soil.Colour)
end

local var19 = require(var4.FeatureHandler)
local var20 = var6[var7].Colour:ToHex()
local function UpdateReward(arg1, arg2)
	local var2 = var8.Stat.Get(var9, "Soil")
	local var3 = (var11.mul(var10.GetSoilConversion(var9), (var10.GetSoilMultiplier(var9))))
	if var11.gte(var12.Value, var13) then
		arg1.Text = ("<font color=\"#%*\">Soil</font>: %* (+%*)"):format(var6.Soil.Colour:ToHex(), var14.short(var2.Value), (var14.short(var3)))
		arg2.UIGradient.Color = var15.Afford.Gradient
		return
	end

	arg1.Text = ("<font color=\"#%*\">Soil</font>: %*"):format(var6.Soil.Colour:ToHex(), (var14.short(var2.Value)))
	arg2.UIGradient.Color = var15.Expensive.Gradient
end

local var21 = require(var3.Hover)
return { Init = function(_)
	repeat
		task.wait()
	until var18:WaitForChild("FeaturesLoaded").Value

	var8.Network.Connect("Soil", Converted)
	local var1 = var19.GetFeature("Soil"):WaitForChild("Board").SurfaceGui.Frame
	local var2 = var8.Stat.Get(var9, "Soil")
	var1.Requirement.Text = ("Requirement: %* <font color=\"#%*\">%*</font>"):format(var14.short(var13), var20, var7)
	local var3 = var1.Buy
	var3.MouseButton1Click:Connect(function()
		var8.Sound.Play("UIClick")
		var8.Network.Fire("Soil")
	end)

	local var4 = var1.Amount
	var12.Changed:Connect(function()
		UpdateReward(var4, var3)
	end)

	var2.Changed:Connect(function()
		UpdateReward(var4, var3)
	end)

	var21.CreateHover(var3, var3.Size)
	UpdateReward(var4, var3)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Harvest [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.Multipliers)
local var5 = require(var3.UI)
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = require(var4.Harvest)
local var9 = var8.Currency
var6.Stat.Get(var7, var9)
local var10 = require(var4.StatInformation)
var10[var9].Colour:ToHex()
local var11 = var7:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("HarvestNotification")
local var12 = var10.Harvest.Colour:ToHex()
local var13 = var8.Max
local var14 = require(var4.BigNum)
local var15 = require(var4.Colours)
local var16 = require(var3.Suffix)
local var17 = var10[var9].Colour:ToHex()
local var18 = require(var4.Features)
local bool1 = false
local var19 = var5.PopUps
local var20 = var1.Assets.Particles
local var21 = var6.Stat.Get(var7, "FirstHarvest")
local function CanAffordHarvest()
	local var1 = var6.Stat.Get(var7, "Harvest")
	local var2 = var6.Stat.Get(var7, var9)
	local var3 = var8.Prices[math.min(var1.Value, var13 - 1)]
	local bool2 = false
	if var1.Value < var13 then
		bool2 = var14.gte(var2.Value, var3)
	end

	return bool2
end

local var22 = var6.Stat.GetDataFolder(var7).TempValues
local var23 = require(var4.FeatureHandler)
local function Harvested()
	var6.Sound.Play("Harvest")
	var6.VFX.Emit(var7.Character.HumanoidRootPart, var20.Harvest)
end

local var24 = var1.Frames
local function HandleHarvestClick()
	var6.Sound.Play("UIClick")
	if var21.Value then
		if CanAffordHarvest() then
			if var11.Visible then
				return
			end

			var5.FrameOpenings.OpenFrame(var11)
			return
		end
	end

	var6.Network.Fire("Harvest")
end

local var25 = var11.MainBG.Button.Button
local function UpdateHarvestButton(arg1)
	local var1 = var6.Stat.Get(var7, "Harvest")
	local var3 = var8.Prices[math.min(var1.Value, var13 - 1)]
	local var4 = var6.Stat.Get(var7, var9)
	if var1.Value < var13 then
		if var14.gte(var4.Value, var3) then
			arg1.UIGradient.Color = var15.Afford.Gradient
			arg1.Boost.Text = "Harvest"
			return
		end

		arg1.UIGradient.Color = var15.Expensive.Gradient
		arg1.Boost.Text = ("%* <font color=\"#%*\">%*</font>"):format(var16.short(var3), var17, var9)
		return
	end

	arg1.UIGradient.Color = var15.Maxed.Gradient
	arg1.Boost.Text = "Max Harvest"
end

local function HandleNotification()
	local var1 = var6.Stat.Get(var7, "Harvest")
	local var2 = var6.Stat.Get(var7, var9)
	local var3 = var8.Prices[math.min(var1.Value, var13 - 1)]
	if not var18.Harvest.Unlocked(var7) then
		return
	end

	if var14.gte(var2.Value, var3) then
		if var1.Value < var13 then
			if not not bool1 then
				return
			end

			bool1 = true
			task.spawn(function()
				var19.NormalPopUp("You can Harvest!", Color3.fromRGB(220, 170, 18), 3.5)
				var6.Sound.Play("Notification")
			end)

			return
		end
	end

	bool1 = false
end

local var26 = require(var3.Hover)
local var27 = require(var1.Modules.Client.ConsoleScroll)
return { Init = function(_)
	repeat
		task.wait()
	until var22:WaitForChild("FeaturesLoaded").Value

	local var1 = var23.GetFeature("Harvest").Board.SurfaceGui.Frame
	local var2 = var1.Buy
	var6.Network.Connect("Harvest", Harvested)
	local var3 = var1.Tier
	local var4 = var2.Size
	local var10 = var6.Stat.Get(var7, "Harvest")
	local var13 = var6.Stat.Get(var7, var9)
	for k1, v1 in var8.Text, nil do
		local var14 = var24.HarvestInfo:Clone()
		var14.Parent = var1.Main
		local num1 = 142
		var14.Size = UDim2.new(0.8, 0, 0, num1)
		var14.LayoutOrder = k1
		local var15 = k1
		var14.Tier.Text = "Tier " .. var15
		for k2, v2 in v1, nil do
			local var16 = var24.HarvestBoost:Clone()
			var16.Parent = var14.Rewards
			var16.LayoutOrder = k2
			if v2.Type == "Function" then
				var10.Changed:Connect(function()
					local var1 = v2
					local var3 = var16
					local var4 = nil
					var4 = if var1.Type == "Function" then var1.Text(var7) else var1.Text
					var3.Text = var4
				end)

			end

			local var18 = nil
			var18 = if v2.Type == "Function" then v2.Text(var7) else v2.Text
			var16.Text = var18
		end

		var10.Changed:Connect(function()
			local var1 = var6.Stat.Get(var7, "Harvest").Value < k1
			var14.Unlocked.Visible = var1
			var3.Text = ("<font color=\"#%*\">Harvest</font>: %*"):format(var12, var6.Stat.Get(var7, "Harvest").Value)
		end)

		local var19 = var6.Stat.Get(var7, "Harvest").Value < k1
		var14.Unlocked.Visible = var19
	end

	var2.MouseButton1Click:Connect(HandleHarvestClick)
	var25.MouseButton1Click:Connect(function()
		var6.Sound.Play("UIClick")
		var5.FrameOpenings.CloseFrame(var11)
		var6.Network.Fire("Harvest")
	end)

	var13.Changed:Connect(function()
		UpdateHarvestButton(var2)
		HandleNotification()
	end)

	var10.Changed:Connect(function()
		UpdateHarvestButton(var2)
	end)

	HandleNotification()
	UpdateHarvestButton(var2)
	var3.Text = ("<font color=\"#%*\">Harvest</font>: %*"):format(var12, var6.Stat.Get(var7, "Harvest").Value)
	var26.CreateHover(var2, var4)
	var27.SetupScroll(var1.Scroll, var1.Main)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Seed [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
var2.Stat.WaitForLoad(var3)
local var4 = workspace.MapEssentials:WaitForChild("Seed"):WaitForChild("Board")
local var5 = var4:WaitForChild("SurfaceGui"):WaitForChild("Frame")
local var6 = var5:WaitForChild("Seed")
local var7 = var2.Stat.Get(var3, "HighestSeed")
local var8 = var4.Parent
local var9 = var1.Assets
local var10 = require(var1.Modules.Shared.Seeds)
local var11 = var1.Frames
local function UpdateBoardVisibility()
	local var2 = 4 <= var7.Value
	if not var2 and var4.Parent == var8 then
		var4.Parent = var9.Boards
		return
	end

	if var2 and var4.Parent ~= var8 then
		var4.Parent = var8
	end
end

local function UpdateSeed()
	var6.Text = ("Plant : %*"):format(var2.Stat.Get(var3, "Seed").Value)
end

local var12 = require(var1.Modules.Client.ConsoleScroll)
return { Init = function(_)
	local var1 = var2.Stat.GetDataFolder(var3).TempValues
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	local var13 = var2.Stat.Get(var3, "Seed")
	for k1, v1 in var10.Seeds, nil do
		local var14 = var11.SeedInfo:Clone()
		var14.Parent = var5.Main
		local num1 = 0
		local num2 = 142
		var14.Size = UDim2.new(0.8, 0, num1, num2)
		var14.LayoutOrder = k1
		var14.Seed.Text = v1.Seed
		var14.Seed.TextColor3 = v1.Colour
		for k2, v2 in v1.Text, nil do
			local var15 = var11.HarvestBoost:Clone()
			var15.Parent = var14.Rewards
			var15.LayoutOrder = k2
			local var17 = nil
			var17 = if v2.Type == "Function" then v2.Text(var3) else v2.Text
			var15.Text = var17
		end

		var7.Changed:Connect(function()
			local var1 = k1
			local var2 = var14
			var2.Visible = var1 <= var7.Value + 1
			var2.Unlocked.Visible = not (var1 <= var7.Value)
		end)

		var14.Visible = k1 <= var7.Value + 1
		var14.Unlocked.Visible = not (k1 <= var7.Value)
	end

	var7.Changed:Connect(UpdateBoardVisibility)
	var13.Changed:Connect(UpdateSeed)
	local var19 = 4 <= var7.Value
	if not var19 and var4.Parent == var8 then
		var4.Parent = var9.Boards
	else
		if var19 and var4.Parent ~= var8 then
			var4.Parent = var8
		end
	end

	var6.Text = ("Plant : %*"):format(var2.Stat.Get(var3, "Seed").Value)
	var12.SetupScroll(var5.Scroll, var5.Main)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Replant [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
local var5 = require(var3.UI)
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = require(var4.Replant)
local var9 = require(var4.StatInformation)
local var10 = var8.Currency
local var11 = var7:WaitForChild("PlayerGui"):WaitForChild("Frames"):WaitForChild("ReplantNotification")
local var12 = var8.Max
local var13 = var9.Replant.Colour:ToHex()
local var14 = require(var4.BigNum)
local var15 = require(var4.Colours)
local var16 = require(var3.Suffix)
local var17 = var9[var10].Colour:ToHex()
local var18 = require(var4.Features)
local bool1 = false
local var19 = var5.PopUps
local var20 = var1.Assets.Particles
local var21 = var6.Stat.Get(var7, "FirstReplant")
local var22 = var6.Stat.GetDataFolder(var7).TempValues
local var23 = require(var4.FeatureHandler)
local function Replanted()
	var6.Sound.Play("Replant")
	var6.VFX.Emit(var7.Character.HumanoidRootPart, var20.Harvest)
end

local var24 = var1.Frames
local function HandleReplantClick()
	var6.Sound.Play("UIClick")
	if var21.Value then
		local bool1 = false
		local var1 = var6.Stat.Get(var7, var10)
		if var6.Stat.Get(var7, "Replant").Value < var12 then
			bool1 = var14.gte(var1.Value, var8.Prices[math.min(var6.Stat.Get(var7, "Replant").Value, var12 - 1)])
		end

		if bool1 then
			if var11.Visible then
				return
			end

			var5.FrameOpenings.OpenFrame(var11)
			return
		end
	end

	var6.Network.Fire("Replant")
end

local var25 = var11.MainBG.Button.Button
local function UpdateReplantButton(arg1)
	local var2 = var6.Stat.Get(var7, var10)
	local var3 = var8.Prices[math.min(var6.Stat.Get(var7, "Replant").Value, var12 - 1)]
	if var6.Stat.Get(var7, "Replant").Value < var12 then
		if var14.gte(var2.Value, var3) then
			arg1.UIGradient.Color = var15.Afford.Gradient
			arg1.Boost.Text = "Replant"
			return
		end

		arg1.UIGradient.Color = var15.Expensive.Gradient
		arg1.Boost.Text = ("%* <font color=\"#%*\">%*</font>"):format(var16.short(var3), var17, var10)
		return
	end

	arg1.UIGradient.Color = var15.Maxed.Gradient
	arg1.Boost.Text = "Max Replant"
end

local function HandleNotification()
	if not var18.Replant.Unlocked(var7) then
		return
	end

	local bool2 = false
	local var1 = var6.Stat.Get(var7, var10)
	if var6.Stat.Get(var7, "Replant").Value < var12 then
		bool2 = var14.gte(var1.Value, var8.Prices[math.min(var6.Stat.Get(var7, "Replant").Value, var12 - 1)])
	end

	if bool2 then
		if not not bool1 then
			return
		end

		bool1 = true
		task.spawn(function()
			var19.NormalPopUp("You can Replant!", var9.Replant.Colour, 3.5)
			var6.Sound.Play("Notification")
		end)

		return
	end

	bool1 = false
end

local var26 = require(var3.Hover)
local var27 = require(var3.ConsoleScroll)
return { Init = function(_)
	repeat
		task.wait()
	until var22:WaitForChild("FeaturesLoaded").Value

	local var1 = var23.GetFeature("Replant").Board.SurfaceGui.Frame
	local var2 = var1.Buy
	var6.Network.Connect("Replant", Replanted)
	local var3 = var1.Tier
	local var4 = var2.Size
	local var9 = var6.Stat.Get(var7, "Replant")
	local var12 = var6.Stat.Get(var7, var10)
	for k1, v1 in var8.Text, nil do
		local var14 = var24.HarvestInfo:Clone()
		var14.Parent = var1.Main
		local num1 = 142
		var14.Size = UDim2.new(0.8, 0, 0, num1)
		var14.LayoutOrder = k1
		local var15 = k1
		var14.Tier.Text = "Tier " .. var15
		for k2, v2 in v1, nil do
			local var16 = var24.HarvestBoost:Clone()
			var16.Parent = var14.Rewards
			var16.LayoutOrder = k2
			if v2.Type == "Function" then
				var9.Changed:Connect(function()
					local var1 = v2
					local var3 = var16
					local var4 = nil
					var4 = if var1.Type == "Function" then var1.Text(var7) else var1.Text
					var3.Text = var4
				end)

			end

			local var18 = nil
			var18 = if v2.Type == "Function" then v2.Text(var7) else v2.Text
			var16.Text = var18
		end

		var9.Changed:Connect(function()
			local var1 = var6.Stat.Get(var7, "Replant").Value < k1
			var14.Unlocked.Visible = var1
			var3.Text = ("<font color=\"#%*\">Replant</font>: %*"):format(var13, var6.Stat.Get(var7, "Replant").Value)
		end)

		local var19 = var6.Stat.Get(var7, "Replant").Value < k1
		var14.Unlocked.Visible = var19
	end

	var2.MouseButton1Click:Connect(HandleReplantClick)
	var25.MouseButton1Click:Connect(function()
		var6.Sound.Play("UIClick")
		var5.FrameOpenings.CloseFrame(var11)
		var6.Network.Fire("Replant")
	end)

	var12.Changed:Connect(function()
		UpdateReplantButton(var2)
		HandleNotification()
	end)

	HandleNotification()
	UpdateReplantButton(var2)
	var3.Text = ("<font color=\"#%*\">Replant</font>: %*"):format(var13, var6.Stat.Get(var7, "Replant").Value)
	var26.CreateHover(var2, var4)
	var27.SetupScroll(var1.Scroll, var1.Main)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Bank [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Client
local var4 = var2.Shared
require(var4.Multipliers)
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = require(var4.Bank)
local tbl1 = {}
local var8 = require(var3.UI).PopUps
local var9 = require(var4.StatInformation).Ruby.Colour
local var10 = var1.Assets.Particles
local var11 = require(var4.BigNum)
local var12 = var5.Stat.Get(var6, var7.DepositStat)
local tbl2 = {}
local function GetNextTier()
	local var1 = nil
	local var2 = nil
	for k1 in tbl2, nil do
		if var7.Max < k1 then
			continue
		end

		local var3 = var7.Prices[k1] or 0
		local var4 = var3
		if var11.gte(var12.Value, var11.toString(var4)) then
			continue
		end

		if not var2 or var2 > var3 then
			var1 = k1
		end

		local var5 = var3
	end

	return var1
end

local var13 = require(var3.Suffix)
local function GetNextPrice()
	local var1 = nil
	for k1, v1 in var7.Prices, nil do
		if var7.Max < k1 then
			continue
		end

		local var2 = v1
		if var11.gte(var12.Value, var11.toString(var2)) then
			continue
		end

		if not var1 or var1 > v1 then
			var1 = v1
		end
	end

	return var1
end

local var14 = require(var4.Colours)
local var15 = var5.Stat.Get(var6, var7.Currency)
local var16 = var5.Stat.GetDataFolder(var6).TempValues
local var17 = require(var4.FeatureHandler)
local var18 = var1.Frames
local function Deposited()
	var5.Sound.Play("Bank")
	var5.VFX.Emit(var6.Character.HumanoidRootPart, var10.Bank)
end

local var19 = require(var3.Hover)
local var20 = require(var1.Modules.Client.ConsoleScroll)
return { Init = function(_)
	repeat
		task.wait()
	until var16:WaitForChild("FeaturesLoaded").Value

	local var1 = var17.GetFeature("Bank").Board.SurfaceGui.Frame
	local var2 = var1.Buy
	local var3 = var1.Ruby
	local var4 = var2.Size
	for k1, v1 in var7.Text, nil do
		local var10 = var7.Prices[k1] or 0
		local var21 = var10
		if var11.gte(var12.Value, var11.toString(var21)) then
			tbl1[k1] = true
		end

		local var22 = var18.HarvestInfo:Clone()
		var22.Parent = var1.Main
		var22.LayoutOrder = k1
		local var23 = var9:ToHex()
		local var24 = var13.short(var10)
		var22.Tier.Text = ("<font color=\"#%*\">Ruby</font> Required: %*"):format(var23, var24)
		for k2, v2 in v1, nil do
			local var25 = var18.HarvestBoost:Clone()
			var25.Parent = var22.Rewards
			var25.LayoutOrder = k2
			local var27 = nil
			var27 = if v2.Type == "Function" then v2.Text(var6) else v2.Text
			var25.Text = var27
		end

		tbl2[k1] = var22
	end

	local var28 = GetNextTier()
	for k3, v3 in tbl2, nil do
		local var29 = var7.Prices[k3] or 0
		local var30 = var11.gte(var12.Value, var11.toString(var29))
		local var32 = var30
		if not var32 then
			var32 = k3 == var28
		end

		v3.Visible = var32
		v3.Unlocked.Visible = not var30
		if not var30 then
			continue
		end

		if tbl1[k3] ~= nil then
			continue
		end

		if tbl1[k3] ~= nil then
			continue
		end

		tbl1[k3] = true
		var8.NormalPopUp("You unlocked a new bank reward", var9, 3)
	end

	var12.Changed:Connect(function()
		local var1 = GetNextTier()
		for k1, v1 in tbl2, nil do
			local var4 = var7.Prices[k1] or 0
			local var5 = var11.gte(var12.Value, var11.toString(var4))
			local var10 = var5
			if not var10 then
				var10 = k1 == var1
			end

			v1.Visible = var10
			v1.Unlocked.Visible = not var5
			if not var5 then
				continue
			end

			if tbl1[k1] ~= nil then
				continue
			end

			if tbl1[k1] ~= nil then
				continue
			end

			tbl1[k1] = true
			var8.NormalPopUp("You unlocked a new bank reward", var9, 3)
		end

		var3.Text = ("<font color=\"#%*\">Ruby</font> Deposited: %*"):format(var9:ToHex(), (var13.short(var12.Value)))
		var1 = var2
		var1.Boost.Text = "Deposit"
		local var16 = var1.UIGradient
		local var17
		if not GetNextPrice() then
			var17 = var14.Maxed.Gradient
		elseif 0 < var15.Value then
			var17 = var14.Afford.Gradient
		else
			var17 = var14.Expensive.Gradient
		end

		var16.Color = var17
	end)

	var15.Changed:Connect(function()
		local var1 = var2
		var1.Boost.Text = "Deposit"
		local var3 = var1.UIGradient
		local var4
		if not GetNextPrice() then
			var4 = var14.Maxed.Gradient
		elseif 0 < var15.Value then
			var4 = var14.Afford.Gradient
		else
			var4 = var14.Expensive.Gradient
		end

		var3.Color = var4
	end)

	var5.Network.Connect("BankDeposit", Deposited)
	var2.MouseButton1Click:Connect(function()
		if var15.Value <= 0 then
			return
		end

		if not GetNextPrice() then
			return
		end

		var5.Sound.Play("UIClick")
		var5.Network.Fire("BankDeposit")
	end)

	var19.CreateHover(var2, var4)
	var3.Text = ("<font color=\"#%*\">Ruby</font> Deposited: %*"):format(var9:ToHex(), (var13.short(var12.Value)))
	var2.Boost.Text = "Deposit"
	var28 = var2.UIGradient
	local var33
	if not GetNextPrice() then
		var33 = var14.Maxed.Gradient
	else
		var33 = if 0 < var15.Value then var14.Afford.Gradient else var14.Expensive.Gradient
	end

	var28.Color = var33
	var20.SetupScroll(var1.Scroll, var1.Main)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.Gamepasses [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("TweenService")
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
local var5 = game:GetService("MarketplaceService")
local var6 = utf8.char(57346)
local var7 = workspace:WaitForChild("Boards"):WaitForChild("Gamepasses"):WaitForChild("Board"):WaitForChild("SurfaceGui"):WaitForChild("Frame")
local var8 = require(var1.Modules.Shared.Robux)
local function AnimateButton(arg1)
	local var1 = arg1:FindFirstChildOfClass("UIScale")
	var1 = var1 or Instance.new("UIScale", arg1)
	local function To(arg1, arg2)
		local var3 = TweenInfo.new(arg2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		var2:Create(var1, var3, { Scale = arg1 }):Play()
	end

	arg1.MouseEnter:Connect(function()
		To(1.06, 0.12)
	end)

	arg1.MouseLeave:Connect(function()
		To(1, 0.12)
	end)

	arg1.MouseButton1Down:Connect(function()
		var3.Sound.Play("UIClick")
		To(0.94, 0.07)
	end)

	arg1.MouseButton1Up:Connect(function()
		To(1.06, 0.07)
	end)
end

local function HandlePass(arg1, arg2)
	local success, result = pcall(var5.GetProductInfoAsync, var5, arg2.ID, Enum.InfoType.GamePass)
	local var1 = if arg2.DataName then var3.Stat.Get(var4, arg2.DataName) else nil
	local str1 = "???"
	if success and result then
		str1 = tostring(result.PriceInRobux)
	else
		warn((("[GamepassBoard] the marketplace does not know gamepass %*"):format(arg2.ID)))
	end

	arg1.MouseButton1Click:Connect(function()
		if var1 and var1.Value then
			return
		end

		var5:PromptGamePassPurchase(var4, arg2.ID)
	end)

	local function Refresh()
		local bool2 = false
		if var1 ~= nil then
			bool2 = var1.Value
		end

		local var2 = arg1.Price
		var2.Text = if bool2 then "Owned" else var6 .. str1
	end

	if var1 then
		var1.Changed:Connect(Refresh)
	end

	local bool2 = false
	if var1 ~= nil then
		bool2 = var1.Value
	end

	local var2 = arg1.Price
	var2.Text = if bool2 then "Owned" else var6 .. str1
end

return { Init = function(_)
	var3.Stat.WaitForLoad(var4)
	for k1, v1 in var7:GetChildren() do
		if not v1:IsA("GuiButton") then
			continue
		end

		local var2 = var8.Passes[v1.Name]
		if not var2 then
			warn((("[GamepassBoard] %* is not a key in Shared.Robux.Passes"):format(v1.Name)))
		else
			AnimateButton(v1)
			HandlePass(v1, var2)
		end
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.World.Boards.FasterResearch [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
local var4 = workspace.Features:FindFirstChild("Lab")
local var5 = (var4 or var1.Assets.Features:FindFirstChild("Lab")):WaitForChild("FasterResearch"):WaitForChild("Board"):WaitForChild("SurfaceGui"):WaitForChild("Frame"):WaitForChild("Join")
local var6 = require(var1.Framework)
local var7 = game:GetService("Players").LocalPlayer
local var8 = require(var3.Robux).Passes.MoreResearchSpeedGamepass
local var9 = game:GetService("MarketplaceService")
local var10 = var5:WaitForChild("TextLabel")
local var11 = utf8.char(57346)
local var12 = require(var3.Colours)
local var13 = var5.UIGradient.Color
local var14 = require(var2.Client.Hover)
return { Init = function(_)
	var6.Stat.WaitForLoad(var7)
	local success, result = pcall(var9.GetProductInfoAsync, var9, var8.ID, Enum.InfoType.GamePass)
	local var1 = var6.Stat.Get(var7, var8.DataName)
	local str1 = "???"
	if success and result then
		str1 = tostring(result.PriceInRobux)
	else
		warn((("[FasterResearch] the marketplace does not know gamepass %*"):format(var8.ID)))
	end

	var5.MouseButton1Click:Connect(function()
		if var1 and var1.Value then
			return
		end

		var6.Sound.Play("UIClick")
		var9:PromptGamePassPurchase(var7, var8.ID)
	end)

	local function Refresh()
		local bool2 = false
		if var1 ~= nil then
			bool2 = var1.Value
		end

		local var2 = var10
		var2.Text = if bool2 then "Owned" else var11 .. str1
		var2 = var5.UIGradient
		var2.Color = if bool2 then var12.Maxed.Gradient else var13
	end

	if var1 then
		var1.Changed:Connect(Refresh)
	end

	var14.CreateHover(var5, var5.Size)
	local bool2 = false
	if var1 ~= nil then
		bool2 = var1.Value
	end

	local var2 = var10
	var2.Text = if bool2 then "Owned" else var11 .. str1
	var2 = var5.UIGradient
	var2.Color = if bool2 then var12.Maxed.Gradient else var13
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.HUD.HUDHandler [ModuleScript]
-- y u r i

game:GetService("TweenService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
local var4 = var2.Client
local var5 = require(var1.Modules.Client.UI)
local var6 = game:GetService("Players").LocalPlayer
local var7 = var6.PlayerGui
local var8 = var7:WaitForChild("Front")
local var9 = var8:WaitForChild("MainFrame")
local var10 = var9:WaitForChild("Right").SideStats
local var11 = var9.Right.Minimize
local var12 = var11.Click
local var13 = var9:WaitForChild("Tutorial")
local var14 = var13.BarFrame
local var15 = var9:WaitForChild("FriendBoost").FriendBoost
local var16 = require(var3.Tutorial)
local var17 = game:GetService("SocialService")
local var18 = game:GetService("CollectionService")
local var19 = require(var1.Framework)
local var20 = require(var3.BigNum)
local var21 = require(var4.Suffix)
local var22 = require(var3.StatInformation)
local var23 = require(var3.Pets)
local var24 = require(var4.Hover)
local var25 = var7:WaitForChild("Frames")
local var26 = var9.Left:WaitForChild("Buttons")
local tbl1 = { Collection = require(var3.Seeds).Seeds, Stat = "Seed" }
local tbl2 = { Seed = tbl1 }
tbl2.Pet = { Collection = var23, Stat = "Pet" }
var19.Stat.Get(var6, "Device")
var18:GetTagged("EditableSurfaceGui")
local var27 = var10.Cash.Size
local var28 = var5.PopUps
local var29 = #var16.Stages
local var30 = var13.TutorialLabel
local var31 = var13.Icon
local var32 = var13.Requirement
local var33 = var14.Amount
local var34 = var14.Bar
local var35 = workspace.MapEssentials.Seed.Holder
local num1 = 0
local function CreateBeam()
	local var1 = var19.Stat.Get(var6, "TutorialStage")
	local var2 = num1 + 1
	num1 = var2
	if var29 < var1.Value then
		return var19.Beam.Destroy()
	end

	var2 = var16.Stages[var1.Value]
	local var4 = typeof(var2.Arrow) == "function" and var2.Arrow() or var2.Arrow
	local var5 = var2.Overwrite or 10
	local var7 = var19.Beam.New
	local var8 = var6.Character.HumanoidRootPart
	if var4 == "Seed" then
		var4 = var35
	end

	var7(var8, var4)
	if var5 == -1 then
		return
	end

	var7 = num1
	task.spawn(function()
		local num2 = 0
		while var6 and var6.Parent do
			task.wait(1)
			if num1 ~= var7 then
				return
			end

			num2 = num2 + 1
			if var5 > num2 then
				continue
			end

			var19.Beam.Destroy()
			return
		end
	end)
end

local var36 = var13.Size
local var37 = var1.Assets.Particles
local function TweenTutorialFrame()
	var13:TweenSize(UDim2.new(var36.X.Scale + 0.05, 0, var36.Y.Scale + 0.05, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.1, true)
	task.wait(0.1)
	var13:TweenSize(UDim2.new(var36.X.Scale, 0, var36.Y.Scale, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.1, true)
end

local var38 = var15.Boost
local var39 = var15.Invite
local function UpdateFriendBoost()
	var38.Text = "+ " .. var19.Stat.Get(var6, "CurrentFriends").Value * 10 .. "% Cash boost"
end

local function HandlePopUp(arg1, arg2)
	local str2 = ""
	if arg1 == "Evolve" then
		str2 = "You just evolved your seed!"
	end

	if arg1 == "WaterLevel" then
		str2 = "Your Water leveled up!"
	end

	if arg1 == "CantAfford" then
		var19.Sound.Play("Error")
		str2 = "You can't afford this"
	end

	if arg1 == "Max" then
		var19.Sound.Play("Error")
		str2 = "Maxed upgrade"
	end

	if arg1 == "DailyQuestRefresh" then
		str2 = "New daily quests available!"
	end

	if arg1 == "WeeklyQuestRefresh" then
		str2 = "New weekly quests available!"
	end

	if arg1 == "QuestCompleted" then
		str2 = "You completed a quest! Go claim your reward!"
	end

	if arg1 == "LabResearchFinish" then
		str2 = "Lab Research Has Completed"
	end

	if arg1 == "LabSlotsLost" then
		var19.Sound.Play("Error")
		str2 = "Not enough Research Slots. Your newest Research was cancelled"
	end

	if arg1 == "NoQuestsAvailable" then
		var19.Sound.Play("Error")
		str2 = "No other quests available right now"
	end

	var28.NormalPopUp(str2, arg2)
end

local function NewTutorialStep()
	if not var19.Stat.Get("Guide").Value then
		return
	end

	var19.Sound.Play("Tutorial")
	var19.VFX.Emit(var6.Character.HumanoidRootPart, var37.Tutorial)
	TweenTutorialFrame()
	CreateBeam()
end

local function TutorialReward()
	var28.NormalPopUp(("Finished tutorial. 3m of x2 <font color=\"#%*\">Cash</font> Rewarded"):format((var22.Cash.Colour:ToHex())), nil, 4)
end

local function UpdateFrame(arg1, arg2)
	local var1 = var20.gt(var19.Stat.Get(var6, "Highest" .. arg2).Value, 0)
	var1 = var1 or var20.gt(var19.Stat.Get(var6, arg2).Value, 0)
	arg1.Visible = var1
	local var2 = var19.Stat.Get(var6, arg2)
	arg1.Amount.Text = var21.short(var2.Value)
	arg1.Amount.SubText.Text = var21.short(var2.Value)
end

local function TweenSideFrame(arg1)
	local var1 = arg1.Size
	arg1:TweenSize(UDim2.new(var1.X.Scale + 0.02, 0, var1.Y.Scale + 0.02, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.03, true)
	task.wait(0.03)
	arg1:TweenSize(var27, Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.03, true)
end

tbl1 = false
local var40 = var12.Size
local function UpdateTutorial()
	local var1 = var19.Stat.Get(var6, "TutorialStage")
	local var2 = var19.Stat.Get(var6, "Guide")
	local var3 = var19.Stat.Get(var6, "Tutorial")
	if var29 < var1.Value then
		var13.Visible = false
		return
	end

	local var4 = var16.Stages[var1.Value]
	local var5 = var4
	local var7 = var4
	local var8 = var4
	local var9 = var4
	local var10 = not var3.Value
	var5 = var5 and var4.Amount
	var7 = var7 and var4.Text
	var8 = var8 and var4.Image
	var9 = var9 and var4.Stat
	var10 = var10 or var2.Value and var3.Value
	local var14 = tbl2[var8]
	local var15 = if var3.Value then "Guide" else "Tutorial"
	local var17
	if not var14 then
		local var23 = var22[var8]
		if var23 then
			var17 = var23.Icon
		else
			var17 = var8
		end
	else
		local var24 = var14.Collection[if var9 == var14.Stat then var5 - 1 else var19.Stat.Get(var6, var14.Stat).Value]
		var17 = var24 and var24.Icon or var22[var8].Icon
	end

	local var25 = typeof(var5) == "boolean"
	local var27 = var25
	var14 = var19.Stat.Get(var6, var9)
	if var27 then
		var27 = var14.Value == var5
	end

	local var28
	if var25 then
		if var27 then
			var28 = 1
		else
			var28 = 0
		end
	else
		local var35 = var14.Value
		local var36 = var5
		local var37 = var20.toNumber(var20.div(var35, var36))
		var28 = math.clamp(var37, 0, 1)
	end

	local var38
	if var25 then
		if var27 then
			var38 = "1/1"
		else
			var38 = "0/1"
		end
	else
		var38 = var21.short(var14.Value) .. "/" .. var21.short(var5)
	end

	var30.Text = var15
	var13.Visible = var10
	var31.Image = var17
	var32.Text = var7
	var33.Text = var38
	var34:TweenSize(UDim2.new(var28, 0, 1, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Bounce, 0.07, true)
end

local function HandleFriends()
	var39.MouseButton1Click:Connect(function()
		if not var17:CanSendGameInviteAsync(var6) then
			return
		end

		var17:PromptGameInvite(var6)
	end)

	var19.Stat.Get(var6, "CurrentFriends").Changed:Connect(UpdateFriendBoost)
	var24.CreateHover(var39, var39.Size)
	var38.Text = "+ " .. var19.Stat.Get(var6, "CurrentFriends").Value * 10 .. "% Cash boost"
end

return { Init = function(_)
	var19.Stat.WaitForLoad(var6)
	local var1 = var19.Stat.GetDataFolder(var6)
	var19.Stat.Get(var6, "TutorialStage")
	local var2 = var1.Other
	local var3 = var19.Stat.Get(var6, "Guide")
	repeat
		task.wait()
	until var1:WaitForChild("TempValues"):WaitForChild("FeaturesLoaded").Value

	var19.Network.Connect("TextPopUp", HandlePopUp)
	var19.Network.Connect("TutorialStep", NewTutorialStep)
	var19.Network.Connect("TutorialReward", TutorialReward)
	for k1, v1 in var26:GetChildren() do
		if not v1:IsA("TextButton") then
			continue
		end

		local var4 = v1.Icon.Size
		var24.CreateHover(v1.Icon, var4)
		v1.MouseButton1Down:Connect(function()
			var24.Down(v1.Icon, var4)
		end)

		v1.MouseButton1Up:Connect(function()
			var24.Up(v1.Icon, var4)
		end)

		v1.MouseButton1Click:Connect(function()
			if not var25:FindFirstChild(v1.Name) then
				return
			end

			var19.Sound.Play("UIClick")
			var5.FrameOpenings.ToggleFrame(var25[v1.Name])
		end)

	end

	for k2, v2 in var10:GetChildren() do
		local var7 = v2:IsA("Frame")
		if not var7 then
			continue
		end

		var7 = v2.Name
		if var7 == "Ignore" then
			continue
		end

		var7 = v2.Name
		var19.Stat.Get(var6, var7).Changed:Connect(function()
			UpdateFrame(v2, var7)
			TweenSideFrame(v2)
		end)

		UpdateFrame(v2, var7)
	end

	var12.MouseButton1Click:Connect(function()
		var19.Sound.Play("UIClick")
		local var1 = not tbl1
		tbl1 = var1
		var1 = var19.Tween.Play
		local var2 = var8.MainFrame.Right
		local var3 = TweenInfo.new(0.1, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
		local var4 = Vector2.new
		var1(var2, var3, { AnchorPoint = var4(if tbl1 then 0.2 else 1, 0.5) })
		var1 = var19.Tween.Play
		var2 = var8.MainFrame.Right.Minimize.Icon
		var3 = TweenInfo.new(0.1, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
		var1(var2, var3, { Rotation = if tbl1 then 180 else 0 })
	end)

	var24.CreateHover(var12, var40)
	local tbl3 = {}
	for k3, v3 in var16.Stages, nil do
		tbl3[v3.Stat] = true
	end

	for k4, v4 in tbl2, nil do
		tbl3[v4.Stat] = true
	end

	for k5 in tbl3, nil do
		var19.Stat.Get(var6, k5).Changed:Connect(UpdateTutorial)
	end

	var2.TutorialStage.Changed:Connect(UpdateTutorial)
	var3.Changed:Connect(function()
		UpdateTutorial()
		if not var19.Stat.Get(var6, "Guide").Value then
			local var1 = num1 + 1
			num1 = var1
			var19.Beam.Destroy()
			return
		end

		CreateBeam()
	end)

	HandleFriends()
	UpdateTutorial()
	if not var19.Stat.Get(var6, "Guide").Value then
		local var9 = num1 + 1
		num1 = var9
		var19.Beam.Destroy()
		return
	end

	CreateBeam()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.HUD.RandomMessage [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
var2.Stat.WaitForLoad(var3)
local var4 = require(var1.Modules.Shared.Messages)
local var5 = Color3.fromRGB(141, 65, 255):ToHex()
local var6 = Color3.fromRGB(251, 255, 11):ToHex()
return { Init = function(_)
	local var1 = var2.Stat.GetDataFolder(var3).TempValues
	repeat
		task.wait()
	until var1:WaitForChild("FeaturesLoaded").Value

	var4.MakeMessage("New code at 1000 Likes!", var5, "FredokaOne")
	if not var2.Stat.Get(var3, "InGroup").Value then
		var4.MakeMessage("Join the group for free auto collect!", var6, "FredokaOne")
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.UI.HUD.ExtraBoosts [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = game:GetService("ReplicatedStorage")
local var3 = game:GetService("MarketplaceService")
local var4 = game:GetService("TweenService")
local var5 = var1:WaitForChild("PlayerGui"):WaitForChild("Front").MainFrame.ExtraTiers
local var6 = var2.Modules.Shared
local var7 = nil
local var8 = nil
local var9 = require(var2.Framework)
local var10 = require(var6.Features)
local tbl1 = { Wood = "Tree", Water = "Water", Grass = "Barn", Paper = "Research" }
local var11 = require(var6.StatInformation)
local tbl2 = {}
local var12 = workspace.Regions
local var13 = require(var6.Proximity)
local function UpdateRegion(arg1, arg2)
	var8 = arg1
	if arg1 == nil then
		var7 = nil
		var5.Visible = false
		return
	end

	local var4 = var9.Stat.Get("HideScreenProducts")
	if var4 and var4.Value then
		var7 = nil
		var5.Visible = false
		return
	end

	local var12 = var10[tbl1[arg1]]
	if var12 and (not var12.Unlocked(var1)) then
		var7 = nil
		var5.Visible = false
		return
	end

	local var13 = var9.Stat.Get((("Extra%*Tier"):format(arg1))).Value
	local var14 = arg2[var13 + 1]
	local var16 = tbl2[var14]
	local var17 = var11[arg1]
	if var14 and (not var16) then
		local success, result = pcall(function()
			local var1 = var14
			local var2 = Enum.InfoType.Product
			return var3:GetProductInfoAsync(var1, var2)
		end)

		_ = success
		var16 = result
		var16 = var16 and var16.PriceInRobux
	end

	if var14 == nil or var16 == nil then
		var7 = nil
		var5.Visible = false
		return
	end

	var5.Label.Text = ("x%* %*"):format(2 ^ (var13 + 1), arg1)
	var5.Price.Text = ("\238\128\130%*"):format((var9.Short.toComma(var16)))
	var5.Icon.Image = var17.Icon
	var7 = var14
	tbl2[var14] = var16
	var5.Visible = true
end

local function Cleanup()
	var8 = nil
	var7 = nil
	var5.Visible = false
end

local tbl3 = {
	Wood = { 3711704748, 3711704764 },
	Water = { 3711710351, 3711710361 },
	Cash = { 3712934162, 3712934173 },
	Grass = { 3713633009, 3713633024 },
	Paper = { 3713649721, 3713649750 },
}

local function InitTier(arg1, arg2)
	local var1 = var13.new(("%*Area"):format(arg1), (var12:WaitForChild(arg1)))
	var1:onEnter(function()
		task.defer(UpdateRegion, arg1, arg2)
	end)

	var1:onLeave(Cleanup)
	if var1:isInArea() then
		UpdateRegion(arg1, arg2)
	end
end

return { Init = function(_)
	var5.Visible = false
	local var2 = TweenInfo.new(13, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1)
	local tbl1 = { Rotation = 360 }
	var4:Create(var5.Spiral, var2, tbl1):Play()
	for k1, v1 in tbl3, nil do
		InitTier(k1, v1)
	end

	var5.Buy.MouseButton1Click:Connect(function()
		if var7 == nil then
			return
		end

		var3:PromptProductPurchase(var1, var7)
		var9.Tween.Play(var5.UIScale, TweenInfo.new(0.07), { Scale = 0.85 })
		task.wait(0.07)
		var9.Tween.Play(var5.UIScale, TweenInfo.new(0.07, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 })
	end)

	task.spawn(function()
		while task.wait(0.1) do
			UpdateRegion(var8, tbl3[var8])
		end
	end)

	var13.init()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.SpeedHandler [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
local var4 = require(var1.Modules.Shared.Multipliers)
return { Init = function(_)
	var2.Stat.WaitForLoad(var3)
	local var1 = var3.Character
	local var5 = (var1 or var3.CharacterAdded:Wait()):WaitForChild("Humanoid")
	task.spawn(function()
		while true do
			if not var3 then
				break
			end

			if not var3.Parent then
				break
			end

			local var6 = var2.Stat.Get(var3, "ChosenWalkspeed")
			local var7 = var4.GetPlayerSpeed(var3)
			if var6 and 0 < var6.Value then
				var7 = math.min(var6.Value, var7)
			end

			var5.WalkSpeed = var7
			task.wait(0.75)
		end
	end)

	var3.CharacterAdded:Connect(function(arg1)
		var5 = arg1:WaitForChild("Humanoid")
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.Falling [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = var1.LocalPlayer
require(game:GetService("ReplicatedStorage").Framework).Stat.WaitForLoad(var2)
local var3 = workspace.MapEssentials:WaitForChild("FallBlock")
local var4 = workspace:WaitForChild("SpawnLocation")
return { Init = function(_)
	var3.Touched:Connect(function(arg1)
		local var5 = var1:GetPlayerFromCharacter(arg1.Parent)
		if not var5 or var5 ~= var2 then
			return
		end

		var2.Character:PivotTo(var4.CFrame + Vector3.new(0, 2, 0))
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.AutoRejoin [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
require(var1.Framework).Stat.WaitForLoad(var2)
local bool1 = false
local var3 = game:GetService("RunService")
local var4 = game:GetService("TeleportService")
local function Rejoin()
	if bool1 or var3:IsStudio() then
		return
	end

	bool1 = true
	local success, result = pcall(var4.Teleport, var4, game.PlaceId, var2)
	if not success then
		warn((("[AutoRejoin] could not start the teleport: %*"):format(result)))
		task.delay(5, function()
			bool1 = false
		end)

	end
end

return { Init = function(_)
	var2.Idled:Connect(function(arg1)
		if 900 <= arg1 then
			Rejoin()
		end
	end)

	var4.TeleportInitFailed:Connect(function(arg1, arg2, arg3)
		if arg1 ~= var2 then
			return
		end

		warn((("[AutoRejoin] teleport failed (%*): %*"):format(arg2.Name, arg3)))
		task.delay(5, function()
			bool1 = false
		end)
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.ClientHandler [ModuleScript]
-- y u r i

game:GetService("GroupService")
game:GetService("TweenService")
game:GetService("Debris")
game:GetService("RunService")
local var1 = game:GetService("Players")
local var2 = game:GetService("ReplicatedStorage")
local var3 = var2.Modules
local var4 = var3.Shared
require(var4.Multipliers)
require(var4.StatInformation)
local var5 = var3.Client
require(var5.Suffix)
require(var4.BigNum)
require(var5.Hover)
require(var4.Colours)
require(var2.Modules.Client.Binder)
local var6 = require(var2.Framework)
local var7 = var1.LocalPlayer
var6.Stat.WaitForLoad(var7)
local var8 = var7:GetMouse()
local var9 = var6.Stat.Get(var7, "Device")
local var10 = game:GetService("GuiService")
local var11 = game:GetService("UserInputService")
local var12 = require(var4.DailyUpgrades)
local var13 = require(var5.RubyTopUp)
local var14 = var6.Stat.Get(var7, "AttackingTree")
local var15 = var2:WaitForChild("HiddenPlayers")
local var16 = workspace.MapEssentials
local var17 = workspace.Features
local bool1 = false
local bool2 = false
local var18 = var8.Target
local var19 = var8.Target
local bool3 = false
local bool4 = true
if var9.Value ~= "Mobile" then
	bool4 = var9.Value == "Console"
end

TweenInfo.new(0.08, Enum.EasingStyle.Bounce, Enum.EasingDirection.InOut, 0, true)
local var20 = nil
local var21 = nil
local var22 = var6.Stat.Get(var7, "PlayersSetting")
local tbl1 = {
	Match = function(arg1)
		if var14.Value then
			return
		end

		local var2 = var17:FindFirstChild("Water")
		if not var2 then
			return
		end

		if arg1 and (arg1.Name == "Water" and arg1.Parent == var2) then
			return arg1
		end
	end,
	OnClick = function()
		var6.Network.Fire("Water")
	end,
	NoHold = true,
	HoverColour = Color3.fromRGB(4, 192, 255),
}

local tbl2 = {
	TreeUpgrade = {
		Match = function(arg1)
			if arg1 and (arg1.Name == "Holder" and (arg1.Parent.Parent == var16.UpgradeTree and arg1.Transparency == 0)) then
				return arg1.Parent
			end
		end,
		OnClick = function(arg1)
			var6.Network.Fire("TreeUpgrade", arg1.Name)
		end,
	},
	DailyUpgrade = {
		Match = function(arg1)
			if arg1 and (arg1.Name == "Head" and arg1.Parent.Parent == var16.DailyUpgrades) then
				return arg1.Parent
			end
		end,
		OnClick = function(arg1)
			local var1 = var12.Upgrades[arg1.Name]
			local var2 = var1
			var2 = var2 and var6.Stat.Get(var7, arg1.Name)
			local var5 = var6.Stat.Get(var7, var12.Currency)
			local var8 = var1.Info(var2.Value).Price
			if var1 and (var2 and (var2.Value < var1.Cap and (var12.IsUnlocked(var6.Stat.GetDataFolder(var7), arg1.Name) and (var5 and var5.Value < var8)))) then
				var13.Prompt(var8 - var5.Value)
				return
			end

			var6.Network.Fire("DailyUpgrade", arg1.Name)
		end,
	},
	Water = tbl1,
}

tbl1 = {
	Match = function(arg1)
		if var14.Value then
			return
		end

		if not arg1 then
			return
		end

		local var2 = var17:FindFirstChild("Barn")
		if not var2 then
			return
		end

		local var4 = var2:FindFirstChild("FieldPet")
		if not var4 then
			return
		end

		if arg1:IsDescendantOf(var4) then
			return arg1
		end
	end,
	OnClick = function()
		var6.Network.Fire("CollectGrass")
	end,
	NoHold = true,
	HoverColour = Color3.fromRGB(255, 255, 255),
}

tbl2.FieldPet = tbl1
local var23 = nil
local function UpdateHover(arg1)
	var18 = var8.Target
	local var2 = var14.Value
	if var18 == var19 and var2 == bool3 then
		return
	end

	var19 = var18
	bool3 = var2
	local var4 = var18
	local var5
	local var6
	if not var4 then
		var6 = nil
		var5 = nil
	else
		for k1, v1 in tbl2, nil do
			local var7 = v1.Match(var4)
			if not var7 then
				continue
			end

			var6 = v1
			var5 = var7
		end

		var6 = nil
		var5 = nil
	end

	if var6 == var20 then
		if var5 == var21 then
			return
		end
	end

	if var20 and var23 then
		arg1.Adornee = nil
		if var8.Icon == "rbxassetid://125926190001856" then
			var8.Icon = ""
		end
	end

	var20 = nil
	var21 = nil
	var23 = nil
	if var6 then
		var20 = var6
		var21 = var5
		var23 = var18
		var4 = var18
		local var9 = var6.HoverColour
		if var4.Transparency == 1 then
			return
		end

		if arg1.Adornee then
			arg1.Adornee = nil
			if var8.Icon == "rbxassetid://125926190001856" then
				var8.Icon = ""
			end
		end

		local var10 = var9
		var10 = var10 or Color3.fromRGB(255, 255, 255)
		arg1.OutlineColor = var10
		var8.Icon = "rbxassetid://125926190001856"
		arg1.Adornee = var4
	end
end

local function HandlePlayerSetting()
	for k1, v1 in var1:GetPlayers() do
		if v1 == var7 then
		else
			local var3 = v1.Character
			if not var3 then
			else
				local var5 = if var22.Value then workspace else var15
	if var3.Parent ~= var5 then
					var3.Parent = var5
				end
			end
		end
	end
end

local function WatchPlayer(arg1)
	if arg1 == var7 then
		return
	end

	arg1.CharacterAdded:Connect(function(arg1)
		local var2 = arg1
		if var2 == var7 then
		else
			local var4 = var2.Character
			if not var4 then
			else
				local var6 = if var22.Value then workspace else var15
		if var4.Parent ~= var6 then
					var4.Parent = var6
				end
			end
		end

		arg1:GetPropertyChangedSignal("Parent"):Connect(function()
			if not arg1.Parent then
				return
			end

			local var3 = var2
			if var3 == var7 then
				return
			end

			local var5 = var3.Character
			if not var5 then
				return
			end

			local var8 = if var22.Value then workspace else var15
			if var5.Parent == var8 then
				return
			end

			var5.Parent = var8
		end)
	end)

	if arg1.Character then
		local var1 = arg1.Character
		if arg1 == var7 then
		else
			local var3 = arg1.Character
			if not var3 then
			else
				local var5 = if var22.Value then workspace else var15
	if var3.Parent ~= var5 then
					var3.Parent = var5
				end
			end
		end

		var1:GetPropertyChangedSignal("Parent"):Connect(function()
			if not var1.Parent then
				return
			end

			local var3 = arg1
			if var3 == var7 then
				return
			end

			local var5 = var3.Character
			if not var5 then
				return
			end

			local var8 = if var22.Value then workspace else var15
			if var5.Parent == var8 then
				return
			end

			var5.Parent = var8
		end)

	end
end

local function ForgetPlayer(arg1)
	local var2 = arg1.Character
	if var2 and var2.Parent == var15 then
		var2:Destroy()
	end
end

local function SpawnLoop(arg1)
	while true do
		if not task.wait(0.1) then
			break
		end

		if bool4 or (not bool1) then
			continue
		end

		UpdateHover(arg1)
		if not var20 then
			continue
		end

		if bool2 then
		else
			if var20.NoHold then
			else
				if var20.OnClick then
					var20.OnClick(var21)
				end

				if not var20.ClickSound then
					continue
				end

				var20.ClickSound(var21)
			end
		end
	end
end

return { Init = function(_)
	var6.Stat.WaitForLoad(var7)
	local var2 = var6.Stat.GetDataFolder(var7).Stats
	local var3 = Instance.new("Highlight")
	var3.FillTransparency = 1
	var3.Parent = var16
	var8.Button1Down:Connect(function()
		if bool4 then
			return
		end

		UpdateHover(var3)
		bool1 = true
		if var20 then
			if bool2 then
			else
				if var20.OnClick then
					var20.OnClick(var21)
				end

				if var20.ClickSound then
					var20.ClickSound(var21)
				end
			end
		end

		bool2 = true
		task.delay(0.15, function()
			bool2 = false
		end)
	end)

	var8.Move:Connect(function()
		if bool4 then
			return
		end

		UpdateHover(var3)
	end)

	var11.InputEnded:Connect(function(arg1, _)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.KeyCode == Enum.KeyCode.ButtonR2 then
			bool1 = false
		end

		var9 = var6.Stat.Get(var7, "Device")
		local bool2 = true
		if var9.Value ~= "Mobile" then
			bool2 = var9.Value == "Console"
		end

		bool4 = bool2
	end)

	var11.WindowFocusReleased:Connect(function()
		bool1 = false
	end)

	var10.MenuOpened:Connect(function()
		bool1 = false
	end)

	var22.Changed:Connect(HandlePlayerSetting)
	var1.PlayerAdded:Connect(WatchPlayer)
	var1.PlayerRemoving:Connect(ForgetPlayer)
	for k1, v1 in var1:GetPlayers() do
	if v1 ~= var7 then
			v1.CharacterAdded:Connect(function(arg1)
				local var2 = v1
				if var2 == var7 then
				else
					local var4 = var2.Character
					if not var4 then
					else
						local var6 = if var22.Value then workspace else var15
				if var4.Parent ~= var6 then
							var4.Parent = var6
						end
					end
				end

				arg1:GetPropertyChangedSignal("Parent"):Connect(function()
					if not arg1.Parent then
						return
					end

					local var3 = var2
					if var3 == var7 then
						return
					end

					local var5 = var3.Character
					if not var5 then
						return
					end

					local var8 = if var22.Value then workspace else var15
					if var5.Parent == var8 then
						return
					end

					var5.Parent = var8
				end)
			end)

			if not v1.Character then
				continue
			end

			local var4 = v1.Character
			if v1 == var7 then
			else
				local var12 = v1.Character
				if not var12 then
				else
					local var14 = if var22.Value then workspace else var15
	if var12.Parent ~= var14 then
						var12.Parent = var14
					end
				end
			end

			var4:GetPropertyChangedSignal("Parent"):Connect(function()
				if not var4.Parent then
					return
				end

				local var2 = v1
				if var2 == var7 then
					return
				end

				local var5 = var2.Character
				if not var5 then
					return
				end

				local var8 = if var22.Value then workspace else var15
				if var5.Parent == var8 then
					return
				end

				var5.Parent = var8
			end)

		end
	end

	task.spawn(function()
		while var7 and var7.Parent do
			var9 = var6.Stat.Get(var7, "Device")
			local bool1 = true
			if var9.Value ~= "Mobile" then
				bool1 = var9.Value == "Console"
			end

			bool4 = bool1
			task.wait(10)
		end
	end)

	task.spawn(function()
		while true do
			if not task.wait(0.1) then
				break
			end

			if bool4 then
				continue
			end

			UpdateHover(var3)
		end
	end)

	task.spawn(SpawnLoop, var3)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.RingsHandler [ModuleScript]
-- y u r i

return { Init = function(_)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.Robux [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Modules.Shared.Messages)
local var3 = require(var1.Framework)
local function DisplayMessage(arg1, arg2, arg3, arg4)
	if not arg1 then
		return
	end

	var2.MakeMessage(("[System] %* just gifted '%*' to %*!"):format(arg2, arg3, arg4), Color3.fromRGB(48, 255, 48):ToHex(), "FredokaOne")
end

local function Purchased()
	var2.MakeMessage("Thank you for your purchase!", "30ff2c", "FredokaOne")
end

local var4 = game:GetService("Players").LocalPlayer
return { Init = function(_)
	var3.Network.Connect("DisplayMessage", DisplayMessage)
	var3.Network.Connect("ShopPurchase", Purchased)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.DayNight [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = nil
local var3 = game:GetService("TweenService")
local var4 = TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local var5 = require(var1.Modules.Client.Lighting)
local function EachLight(arg1)
	if not var2 then
		return
	end

	for k1, v1 in var2:GetDescendants() do
		if not v1:IsA("PointLight") then
			continue
		end

		if v1.Name ~= "LanternLight" then
			continue
		end

		arg1(v1)
	end
end

local function SetLight(arg1, arg2, arg3)
	if not arg3 then
		arg1.Enabled = arg2
		arg1.Brightness = if arg2 then 5 else 0
		return
	end

	if arg2 then
		arg1.Enabled = true
	end

	local var1 = var3
	local var2 = arg1
	local var5 = var4
	var1 = var1:Create(var2, var5, { Brightness = if arg2 then 5 else 0 })
	if not arg2 then
		var1.Completed:Once(function(arg1)
			if arg1 == Enum.PlaybackState.Completed then
				arg1.Enabled = false
			end
		end)

	end

	var1:Play()
end

local var6 = nil
local function GoalFrom(arg1)
	local tbl1 = {}
	for k1, v1 in arg1, nil do
		if k1 == "TimeOfDay" then
			local var1, var2, var3 = tostring(v1):match("(%d+):(%d+):(%d+)")
			if not var1 then
				continue
			end

			tbl1.ClockTime = tonumber(var1) + tonumber(var2) / 60 + tonumber(var3) / 3600
		else
			tbl1[k1] = v1
		end
	end

	return tbl1
end

local var7 = game:GetService("Lighting")
local var8 = require(var1.Framework)
local var9 = game:GetService("Players").LocalPlayer
local bool1 = false
local function Apply(arg1, arg2)
	local var1 = var5.Modes
	local var8 = var1[if arg1 then "Night" else "Day"]
	if not var8 then
		var1 = warn
		local str1 = "[DayNight] Modules.Client.Lighting has no %* mode"
		var1((str1:format(if arg1 then "Night" else "Day")))
		return
	end

	EachLight(function(arg1)
		SetLight(arg1, arg1, arg2)
	end)

	if var6 then
		var6:Cancel()
		var6 = nil
	end

	var1 = GoalFrom(var8)
	if not arg2 then
		for k1, v1 in var1, nil do
			var7[k1] = v1
		end

		return
	end

	var6 = var3:Create(var7, var4, var1)
	var6:Play()
end

return { Init = function(_)
	var8.Stat.WaitForLoad(var9)
	var2 = workspace:WaitForChild("Map"):WaitForChild("ManMade"):WaitForChild("Lanterns")
	var2.DescendantAdded:Connect(function(arg1)
		if arg1:IsA("PointLight") and arg1.Name == "LanternLight" then
			local var1 = bool1
			arg1.Enabled = var1
			arg1.Brightness = if var1 then 5 else 0
		end
	end)

	local var3 = var8.Stat.Get(var9, "NightMode")
	if not var3 then
		warn("[DayNight] there is no NightMode setting to watch")
		return
	end

	bool1 = var3.Value
	Apply(bool1, false)
	var3.Changed:Connect(function()
		bool1 = var3.Value
		Apply(bool1, true)
	end)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.Collection.Collection [ModuleScript]
-- y u r i

game:GetService("UserInputService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = var2.Shared
require(var3.StatInformation)
require(var3.Features)
local var4 = require(var1.Framework)
local var5 = game:GetService("Players").LocalPlayer
var4.Stat.WaitForLoad(var5)
local var6 = require(var3.Multipliers)
local var7 = var1.Assets
local var8 = workspace.MapEssentials
local var9 = var8.Collection
local var10 = var9:WaitForChild("Spawnable")
var8:WaitForChild("PopUps")
local var11 = var5.PlayerGui
local var12 = var5.Character
var12 = var12 or var5.CharacterAdded:Wait()
local var13 = var11:WaitForChild("Front").MainFrame:WaitForChild("Combo")
local str1 = "PlayerModule"
local var14 = require(var5:WaitForChild("PlayerScripts"):WaitForChild(str1)):GetControls()
str1 = nil
local var15 = nil
local var16 = game:GetService("TweenService")
local var17 = var13.Progress.UIScale
local var18 = var12:WaitForChild("HumanoidRootPart")
local var19 = var6.GetCollectionRange(var5)
local var20 = nil
local var21 = var11:WaitForChild("Front").MainFrame.AutoCollect
local var22 = var9:WaitForChild("ShownSpawnable")
local var23 = require(var3.Requirements)
local var24 = var8:WaitForChild("Spawned")
local var25 = require(var3.Proximity)
local bool1 = false
local var26 = var4.Stat.Get(var5, "CurrentArea")
local bool2 = false
local var27 = var25.new("EnterArea", (var9:WaitForChild("SpawnableRegion")))
var27:onEnter(function()
	if not bool2 then
		return
	end

	bool1 = true
	RangeObject.Transparency = 1
	var20.Transparency = 0
	var26.Value = "Cash"
	var21.Visible = true
	var13.Visible = var23.Combo.Unlocked((var4.Stat.GetDataFolder(var5))) and true
end)

var27:onLeave(function()
	if not bool2 then
		return
	end

	bool1 = false
	RangeObject.Transparency = 1
	var20.Transparency = 1
	var21.Visible = false
	local var1 = var4.Stat.Get(var5, "AutoCollectionEnabled")
	var1.Value = false
	var13.Visible = var23.Combo.Unlocked((var4.Stat.GetDataFolder(var5))) and false
end)

local num1 = 0
local num2 = -math.huge
local var28 = nil
local function GetOldestPlant()
	local var1 = nil
	local num1 = math.huge
	for k1, v1 in var24:GetChildren() do
		if v1:GetAttribute("PickedUp") then
			continue
		end

		local var2 = v1:GetAttribute("SpawnOrder") or 0
		if var2 >= num1 then
			continue
		end

		var1 = v1
		local var3 = var2
	end

	return var1
end

local var29 = var12:WaitForChild("Humanoid")
local var30 = var1.Remotes
local var31 = var7.Particles
game:GetService("RunService").Heartbeat:Connect(function(arg1)
	local var1 = var4.Stat.Get(var5, "AutoCollectionEnabled")
	local var2 = var4.Stat.Get(var5, "InGroup")
	if var18 == nil or var18.Parent == nil then
		return
	end

	local var3 = (num1 + 60 * arg1) % 360
	num1 = var3
	if var1.Value then
		if bool1 then
			if var2.Value then
				if 0 < var14:GetMoveVector().Magnitude then
					num2 = os.clock()
				end

				if os.clock() - num2 < 1 then
					var28 = nil
				else
					if not var28 or (var28.Parent ~= var24 or var28:GetAttribute("PickedUp")) then
						var28 = GetOldestPlant()
					end

					if var28 then
						var29:MoveTo(var28.Position)
					end
				end
			else
				if var28 then
					var28 = nil
					var29:MoveTo(var18.Position)
				end
			end
		else
			if var28 then
				var28 = nil
				var29:MoveTo(var18.Position)
			end
		end
	else
		if var28 then
			var28 = nil
			var29:MoveTo(var18.Position)
		end
	end

	if bool1 then
		RangeObject.CFrame = (var18.CFrame * CFrame.Angles(0, 1.5707963267948966, 1.5707963267948966) - Vector3.new(0, var18.Size.Y / 2 + var12.Humanoid.HipHeight - 0.1, 0)) * CFrame.Angles(math.rad(num1), 0, 0)
		local var6 = var19
		for k1, v1 in workspace:GetPartBoundsInRadius(RangeObject.Position, var6 / 2) do
			if v1.Parent ~= var24 then
				continue
			end

			if v1:GetAttribute("PickedUp") then
				continue
			end

			v1:SetAttribute("PickedUp", true)
			var30.CollectPart:FireServer(v1.Name)
			var4.VFX.Emit(v1, var31.Collect)
			local var7 = v1.Size
			local var8 = v1.Transparency or 0
			coroutine.wrap(function()
				local num1 = 0
				while num1 < 0.3 do
					num1 = num1 + task.wait()
					local var1 = num1 / 0.3
					v1.Size = var7 * (math.sin(var1 * 3.1415926535897931) * 0.35 + 1)
					v1.Transparency = math.clamp(var8 + var1, 0, 1)
				end

				task.delay(0.3, function()
					v1:Destroy()
				end)
			end)()

		end
	end
end)

var5.CharacterAdded:Connect(function(arg1)
	var12 = arg1
	var18 = arg1:WaitForChild("HumanoidRootPart")
	var29 = arg1:WaitForChild("Humanoid")
	var28 = nil
	var27:init()
end)

local var32 = require(var2.Client.Suffix)
local function PulseComboScale()
	if str1 then
		str1:Cancel()
	end

	if var15 then
		var15:Cancel()
	end

	str1 = var16:Create(var17, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 1.1 })
	str1:Play()
	str1.Completed:Once(function(arg1)
		if arg1 ~= Enum.PlaybackState.Completed then
			return
		end

		var15 = var16:Create(var17, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Scale = 1 })
		var15:Play()
	end)
end

local function CreateRangeObject()
	RangeObject = Instance.new("Part")
	RangeObject.Parent = var8.RangeObject
	RangeObject.Name = var5.Name .. "'s range"
	RangeObject.Color = Color3.fromRGB(0, 0, 0)
	RangeObject.CFrame = CFrame.new(var18.Position)
	local var1 = var5
	RangeObject.Size = Vector3.new(var6.GetCollectionRange(var5), 0.2, var6.GetCollectionRange(var1))
	RangeObject.Shape = Enum.PartType.Cylinder
	RangeObject.Transparency = 1
	RangeObject.CanCollide = false
	RangeObject.CanQuery = false
	RangeObject.Anchored = true
	RangeObject.Size = Vector3.new(0.2, var19, var19)
	var20 = var7.RangeDecal:Clone()
	var20.Parent = RangeObject
	var20.Transparency = 1
end

return { Init = function(_)
	var4.Network.Connect("ClearCollects", function()
		for k1, v1 in var24:GetChildren() do
			v1:Destroy()
		end
	end)

	var22.Transparency = 0
	var22.CanCollide = true
	CreateRangeObject()
	task.spawn(function()
		while true do
			if not task.wait(1) then
				break
			end

			if not RangeObject then
				continue
			end

			if RangeObject.Parent == nil then
				continue
			end

			local var1 = var6.GetCollectionRange(var5)
			if var1 == var19 then
				continue
			end

			var19 = var1
			RangeObject.Size = Vector3.new(0.2, var19, var19)
		end
	end)

	local var1 = var4.Stat.Get(var5, "ComboMultiplier")
	local var2 = var1.Value
	var1.Changed:Connect(function()
		local var3 = var1.Value
		local var7 = math.clamp((var3 - 1) / (var6.GetMaxComboMulti(var5) - 1), 0, 1)
		local var8 = var2 < var3
		var2 = var3
		var13.Progress.Coins.Amount.Text = ("Combo: x%*"):format((var32.short(var3)))
		local var9 = TweenInfo.new(0.1)
		var4.Tween.Play(var13.Progress.BG, var9, { Size = UDim2.fromScale(var7, 1) })
		if var8 then
			PulseComboScale()
		end
	end)

	bool2 = true
	if var27:isInArea() then
		bool1 = true
		RangeObject.Transparency = 1
		var20.Transparency = 0
		var26.Value = "Cash"
		var21.Visible = true
		var13.Visible = var23.Combo.Unlocked((var4.Stat.GetDataFolder(var5))) and true
	end

	var25.init()
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.Collection.Spawning [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Assets
local var3 = var1.Modules
local var4 = var3.Shared
require(var4.BigNum)
require(var4.StatInformation)
local var5 = require(var1.Framework)
local var6 = game:GetService("Players").LocalPlayer
var5.Stat.WaitForLoad(var6)
local var7 = workspace.MapEssentials
local var8 = var7.Collection:WaitForChild("Spawnable")
TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
local var9 = var7:WaitForChild("Spawned")
local var10 = require(var4.Seeds)
local var11 = var2.Seeds.Collectibles
local var12 = var2.Particles
local num1 = 0
local function getRandomPositionOnPlane(arg1, arg2)
	return arg1.CFrame * CFrame.new((math.random() - 0.5) * arg1.Size.X, arg1.Size.Y / 2 + arg2.Size.Y / 2, (math.random() - 0.5) * arg1.Size.Z).Position
end

local var13 = var1.Remotes
local function LoadInCrystal(arg1, arg2)
	if var9:FindFirstChild(arg1) then
		return
	end

	local var1 = var11[var10.Seeds[var5.Stat.Get(var6, "Seed").Value].Seed]:Clone()
	local var2 = var12:FindFirstChild(arg2)
	local var3 = num1 + 1
	num1 = var3
	var1.Name = arg1
	var1:SetAttribute("SpawnOrder", num1)
	var1.Parent = var9
	var3 = getRandomPositionOnPlane(var8, var1)
	var1.Position = var3
	if var2 ~= nil then
		var5.VFX.EmitInf(var1, var2)
	end
end

local var14 = var7:WaitForChild("PopUps")
local var15 = require(var4.Multipliers)
local var16 = require(var3.Client.Suffix)
local var17 = game:GetService("TweenService")
local var18 = TweenInfo.new(0.4)
var13.CollectPart.OnClientEvent:Connect(LoadInCrystal)
local function Popup(arg1, arg2)
	local var1 = script.BillboardGui:Clone()
	local var2 = ("+%*"):format((var16.short((var15.GetCashMultiplier(var6, arg2)))))
	var1.Frame.Inner.Amount.Text = var2
	var1.Parent = arg1
	var1.Enabled = true
	task.delay(0.6, function()
		var17:Create(var1.Frame.Inner.Amount, var18, { TextTransparency = 1 }):Play()
		var17:Create(var1.Frame.Inner.Amount.UIStroke, var18, { Transparency = 1 }):Play()
		var17:Create(var1.Frame.Inner.CurrencyImage, var18, { ImageTransparency = 1 }):Play()
	end)
end

local var19 = game:GetService("Debris")
local var20 = TweenInfo.new(1, Enum.EasingStyle.Exponential)
var13.CrystalDestroyed.OnClientEvent:Connect(function(arg1, arg2)
	if var9:FindFirstChild(arg1) == nil then
		return
	end

	local var1 = var5.Stat.Get(var6, "PopUpsSetting")
	if var9:FindFirstChild(arg1) then
		if arg2 == "Gold" then
			var5.Sound.Play("Gold", var9[arg1])
		elseif arg2 == "Diamond" then
			var5.Sound.Play("Diamond", var9[arg1])
		elseif arg2 == "Void" then
			var5.Sound.Play("Void", var9[arg1])
		else
			var5.Sound.Play("Collect", var9[arg1])
		end

		if var1.Value then
			local var2 = Instance.new("Part")
			var2.Parent = var14
			var2.Size = Vector3.new(1, 1, 1)
			var2.CanCollide = false
			var2.CanQuery = false
			var2.CanTouch = false
			var2.Transparency = 1
			var2.Anchored = true
			local var3 = var9[arg1]
			var2.CFrame = var3.CFrame + Vector3.new(0, 2, 0)
			var2.Name = var3.Name
			if not var1.Value then
				RewardPopUp.Enabled = false
			end

			Popup(var2, arg2)
			var19:AddItem(var2, 1)
			var17:Create(var2, var20, { Position = var2.Position + Vector3.new(0, 3, 0) }):Play()
		end

		task.delay(3, function()
			if var9:FindFirstChild(arg1) == nil then
				return
			end

			var9[arg1]:Destroy()
		end)

	end
end)

return { Init = function(_)
	for k1, v1 in var13.Collectible:InvokeServer() do
		LoadInCrystal(k1, v1)
	end
end }

--- Players.LocalPlayer.PlayerScripts.Client.Components.General.Collection.AutoCollectionButton [ModuleScript]
-- y u r i

game:GetService("MarketplaceService")
local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.Robux)
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
var3.Stat.WaitForLoad(var4)
local var5 = var4.PlayerGui:WaitForChild("Front").MainFrame.AutoCollect
local var6 = var5:WaitForChild("PressQ")
local var7 = game:GetService("GroupService")
local var8 = game:GetService("UserInputService")
local var9 = require(var2.Colours)
local var10 = var6.TextLabel:FindFirstChildWhichIsA("UIStroke")
local tbl1 = { On = Color3.fromRGB(11, 152, 9) }
tbl1.Off = Color3.fromRGB(152, 9, 30)
local tbl2 = { PC = "Q", Console = "Y" }
local var11 = var3.Stat.Get(var4, "Device")
local bool1 = false
local function Toggle()
	local var1 = var3.Stat.Get(var4, "AutoCollectionEnabled")
	local var2 = var3.Stat.Get(var4, "InGroup")
	if not bool1 then
		bool1 = true
		if not var2.Value then
			var7:PromptJoinAsync(35558998)
		else
			local var5 = not var1.Value
			var1.Value = var5
		end

		task.wait(0.15)
		bool1 = false
	end
end

local tbl3 = { Enum.KeyCode.Q, Enum.KeyCode.ButtonY }
local var12 = var3.Stat.Get(var4, "AutoCollectionEnabled")
local function UpdateColour()
	local var1 = var3.Stat.Get(var4, "AutoCollectionEnabled")
	if not var1.Value then
		var5.UIGradient.Color = var9.Expensive.Gradient
	else
		var5.UIGradient.Color = var9.Afford.Gradient
	end

	var6.Green.Enabled = var1.Value
	var6.Red.Enabled = not var1.Value
	var6.Purple.Enabled = false
	if var10 then
		local var2 = var10
		var2.Color = if var1.Value then tbl1.On else tbl1.Off
	end
end

local function UpdatePressQVisibility()
	local var1 = tbl2[var11.Value]
	var6.Visible = var1 ~= nil
	if var1 then
		var6.TextLabel.Text = var1
	end
end

return { Init = function(_)
	var5.MouseButton1Click:Connect(Toggle)
	var8.InputBegan:Connect(function(arg1, arg2)
		if arg2 or (not table.find(tbl3, arg1.KeyCode)) then
			return
		end

		if not var5.Visible then
			return
		end

		Toggle()
	end)

	var12.Changed:Connect(function()
		UpdateColour()
		var3.Network.Fire("AutoCollecting", var12.Value)
	end)

	var11.Changed:Connect(UpdatePressQVisibility)
	UpdateColour()
	local var1 = tbl2[var11.Value]
	var6.Visible = var1 ~= nil
	if var1 then
		var6.TextLabel.Text = var1
	end

	var3.Network.Fire("AutoCollecting", var12.Value)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.UserInputs [ModuleScript]
-- y u r i

local var1 = game:GetService("UserInputService")
local var2 = require(script.LeftClick)
local function OnInputBegan(arg1, arg2)
	if var1:GetFocusedTextBox() ~= nil then
		return
	end

	local var4 = arg1.UserInputType
	if var4 == Enum.UserInputType.MouseButton1 or (var4 == Enum.UserInputType.Touch or arg1.KeyCode == Enum.KeyCode.ButtonR2) then
		var2(arg1, arg2)
	end
end

return { Init = function(_)
	var1.InputBegan:Connect(OnInputBegan)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.UserInputs.LeftClick [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local var3 = game:GetService("UserInputService")
local var4 = require(var1.Framework)
local function MouseClickEffect()
	local var1 = script.ClickEffect:Clone()
	local var5 = var3:GetMouseLocation()
	var1.Parent = var2.PlayerGui.ClickEffect
	var1.Position = UDim2.fromOffset(var5.X, var5.Y)
	local tbl1 = { X = var1.Size.X.Scale, Y = var1.Size.Y.Scale }
	var1:TweenSize(UDim2.fromScale(tbl1.X * 1.4300000000000002, tbl1.Y * 1.3), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.2)
	var4.Tween.Play(var1, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut), { BackgroundTransparency = 0.9 })
	wait(0.1)
	var1:Destroy()
	wait(0.2)
end

local var5 = var2.PlayerGui:WaitForChild("Frames")
local var6 = require(var1.Modules.Client.UI)
return function(arg1, _)
	task.spawn(MouseClickEffect)
	local var1 = arg1.Position.Y
	if #var2.PlayerGui:GetGuiObjectsAtPosition(arg1.Position.X, var1) < 2 then
		for k1, v1 in var5:GetChildren() do
			if (v1:IsA("Frame") or v1:IsA("ImageLabel")) and v1.Visible and v1.Name ~= "DailyReward" then
				var6.FrameOpenings.CloseFrame(v1)
			end
		end
	end
end

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.Sound [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Framework)
local function PlaySound(arg1)
	var1.Sound.Play(arg1)
end

return { Init = function(_)
	var1.Network.Connect("PlaySound", PlaySound)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.UIEffects [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game.Players.LocalPlayer
var2.PlayerGui:WaitForChild("Front")
local var3 = require(var1.Framework)
var3.Stat.Get("UILoaded")
local var4 = require(var1.Modules.Client.UI)
local var5 = var2.PlayerGui:WaitForChild("Frames")
local function AnimateButton(arg1)
	local var2 = arg1:GetAttribute("ButtonAnimation")
	if var2 then
		var4.ButtonAnimations.Create(arg1, var2)
	end

	local var7 = arg1:GetAttribute("ClickSound")
	if var7 then
		(arg1:FindFirstChildOfClass("TextButton") or arg1).MouseButton1Click:Connect(function()
			var3.Sound.Play(var7)
		end)

	end

	local var9 = arg1:GetAttribute("HoverSound")
	if var9 then
		arg1.MouseEnter:Connect(function()
			var3.Sound.Play(var9)
		end)

	end

	local var11 = arg1:GetAttribute("OpenFrame")
	local var12 = var5:FindFirstChild(var11)
	if var11 and var12 then
		arg1.MouseButton1Click:Connect(function()
			var4.FrameOpenings.ToggleFrame(var12)
		end)

	end
end

local tbl1 = { CreateButtons = function(arg1)
	for k1, v1 in arg1:GetDescendants() do
		AnimateButton(v1)
		v1.ChildAdded:Connect(AnimateButton)
	end
end }

local function CreateFrameCloseButtons()
	for k1, v1 in var5:GetChildren() do
		if v1.Name == "DailyReward" then
			continue
		end

		if v1.Name == "Shop" then
			continue
		end

		local var1 = v1:FindFirstChild("Close", true)
		if not var1 then
			continue
		end

		if not var1:IsA("GuiButton") then
			continue
		end

		var1.MouseButton1Click:Connect(function()
			var3.Sound.Play("UIClick")
			var4.FrameOpenings.CloseFrame(v1)
		end)

	end
end

tbl1.Init = function(_)
	task.spawn(function()
		repeat
			task.wait(0.25)
		until var2.PlayerGui:FindFirstChild("Front") ~= nil

		tbl1.CreateButtons(var2.PlayerGui)
		CreateFrameCloseButtons()
	end)
end

return tbl1

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.Chat [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Framework)
local var2 = game:GetService("Players")
local var3 = game:GetService("TextChatService")
local function OnChatMessage(arg1)
	local var5 = var2:GetPlayerByUserId(arg1.TextSource.UserId)
	local var6 = Instance.new("TextChatMessageProperties")
	if arg1.TextSource and var5 then
		local var7 = var1.Stat.GetDataFolder(var5).ChatTags
		var6.PrefixText = arg1.PrefixText
	end

	return var6
end

return { Init = function(_)
	var3.OnIncomingMessage = OnChatMessage
	var1.Network.Connect("ChatMessage", OnChatMessage)
end }

--- Players.LocalPlayer.PlayerScripts.Client.Controllers.DeviceHandler [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
var2.Stat.WaitForLoad(var3)
local var4 = game:GetService("UserInputService")
local var5 = game:GetService("GuiService")
return { Init = function(_)
	local var1 = var3:WaitForChild("PlayerGui")
	var1.ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
	task.spawn(function()
		while true do
			if not var3 then
				break
			end

			if not var3.Parent then
				break
			end

			local var1
			if var4.GamepadEnabled and (not var4.MouseEnabled and (not var4.KeyboardEnabled and var5:IsTenFootInterface())) then
				var1 = "Console"
			else
				var1 = if var4.TouchEnabled and (not var4.MouseEnabled and (not var4.KeyboardEnabled)) then "Mobile" else "PC"
			end

			var2.Network.Fire("SetDevice", var1)
			task.wait(10)
		end
	end)
end }

--- Players.LocalPlayer.PlayerGui.ChatTags [LocalScript]
-- y u r i

game:GetService("TextChatService")
local var1 = game:GetService("Players")
local var2 = game:GetService("ReplicatedStorage").Modules.Shared
local var3 = game:GetService("TextChatService")
local var4 = var3:WaitForChild("ChatWindowConfiguration")
local var5 = require(var2.ChatTags)
local var6 = require(var2.PlayerColour)
local var7 = game:GetService("Debris")
var3.OnChatWindowAdded = function(arg1)
	local var3 = var4:DeriveNewMessageProperties()
	if arg1.TextSource then
		local var8 = var1:GetPlayerByUserId(arg1.TextSource.UserId)
		var3.PrefixText = var5.getTagPrefix(var8) .. ("<font color=\"#%*\">%*</font>"):format(var6(var8.Name):ToHex(), arg1.PrefixText)
	end

	var7:AddItem(var3, 5)
	return var3
end

--- Players.LocalPlayer.PlayerGui.PromptUI.Prompt.ShopIcon.Spin [LocalScript]
-- y u r i

game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(100, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), { Rotation = 36000 }):Play()

--- ReplicatedStorage.Config [ModuleScript]
-- y u r i

return { MaxTagsEquipped = 2 }

--- ReplicatedStorage.Framework [ModuleScript]
-- y u r i

require(script.Types)
local var1 = game:GetService("RunService")
local bool1 = false
local tbl1 = {}
local function RequireModules(arg1)
	local tbl1 = {}
	for k1, v1 in arg1, nil do
		tbl1[v1.Name] = require(v1)
	end

	return tbl1
end

local var2 = require(script.Client)
local var3 = require(script.Shared)
local function TransferModules(arg1, arg2)
	for k1, v1 in arg2, nil do
		local var1
		local var2
		if not arg1[k1] then
			arg1[k1] = v1
		else
			local tbl1 = {}
			local var3 = arg1[k1]
			for k2, v2 in v1, nil do
				tbl1[k2] = v2
			end

			for k3, v3 in var3, nil do
				tbl1[k3] = v3
			end

			arg1[k1] = tbl1
		end
	end
end

return ({ Get = function()
	local var5 = var1:IsClient()
	if not bool1 and (not var5) then
		tbl1.Client = RequireModules(var2.GetModules())
		tbl1.Shared = RequireModules(var3.GetModules())
		if not var5 then
			tbl1.Server = RequireModules(require(game.ServerScriptService["Server Framework"].Server).GetModules())
		end

		bool1 = true
	else
		tbl1.Client = RequireModules(var2.GetModules())
		tbl1.Shared = RequireModules(var3.GetModules())
	end

	local tbl2 = {}
	TransferModules(tbl2, tbl1.Shared)
	if not pcall(settings) then
		if var5 then
			TransferModules(tbl2, tbl1.Client)
			return tbl2
		end

		TransferModules(tbl2, tbl1.Server)
		return tbl2
	end

	TransferModules(tbl2, tbl1.Client)
	TransferModules(tbl2, tbl1.Server)
	return tbl2
end }).Get()

--- ReplicatedStorage.Framework.Client [ModuleScript]
-- y u r i

return { GetModules = function()
	local tbl1 = {}
	for k1, v1 in script:GetChildren() do
		if not v1:IsA("ModuleScript") then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end }

--- ReplicatedStorage.Framework.Client.Sound [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("SoundService")
local var3 = game:GetService("Players").LocalPlayer
local var4 = var1.Sounds
local function PlaySound(arg1, arg2)
	local var3 = var4:FindFirstChild(arg1)
	if not var3 then
		warn((("%* does not have a valid Id"):format(arg1)))
		return
	end

	local var5 = arg2
	local var6 = var3:Clone()
	var6.Parent = var5 or var2
	var6:Play()
	task.wait(var6.TimeLength + 1)
	var6:Destroy()
end

return { Play = function(arg1, arg2)
	if not var1.Data[var3.Name].Settings.SoundsSetting.Value then
		return
	end

	task.spawn(PlaySound, arg1, arg2)
end }

--- ReplicatedStorage.Framework.Client.VFX [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(script.Parent.Tween)
local var3 = nil
local tbl1 = {}
local function BuildPool(arg1)
	if not var3 then
		var3 = Instance.new("Folder")
		var3.Name = "VFXPool"
		var3.Parent = workspace
	end

	local var1 = Instance.new("Part")
	var1.Name = arg1.Name
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.Transparency = 1
	var1.Size = Vector3.new(1, 1, 1)
	var1.Parent = var3
	local tbl2 = { Items = {}, Next = 1 }
	for i1 = 1, 16 do
		local var2 = Instance.new("Attachment")
		var2.Name = ("%*%*"):format(arg1.Name, i1)
		var2.Parent = var1
		for k1, v1 in arg1:GetDescendants() do
			if not v1:IsA("ParticleEmitter") then
				continue
			end

			local var4 = v1:Clone()
			var4.Enabled = false
			var4.LockedToPart = false
			var4.Parent = var2
		end

		table.insert(tbl2.Items, var2)
	end

	tbl1[arg1] = tbl2
	return tbl2
end

local tbl2 = {}
local function MakeEffectPart(arg1)
	local var1 = arg1:Clone()
	var1.Anchored = true
	var1.CanCollide = false
	var1.CanQuery = false
	var1.CanTouch = false
	var1.CastShadow = false
	for k1, v1 in var1:GetDescendants() do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		v1.Enabled = false
		v1.LockedToPart = false
	end

	return var1
end

local function FireEmitters(arg1, arg2)
	local num1 = 0
	for k1, v1 in arg1:GetDescendants() do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		local var1 = v1:GetAttribute("EmitCount")
		v1:Emit(var1 or (arg2 or 5))
		num1 = math.max(num1, v1.Lifetime.Max)
	end

	return num1
end

local var4 = game:GetService("Players").LocalPlayer
local function EmitPooled(arg1, arg2, arg3)
	local var1 = tbl1[arg2]
	var1 = var1 or BuildPool(arg2)
	local var2 = var1.Items
	local var3 = var1.Items[var1.Next]
	local var4 = var1.Next % #var2 + 1
	var1.Next = var4
	var3.WorldPosition = arg1.Position
	for k1, v1 in var3:GetChildren() do
		if not v1:IsA("ParticleEmitter") then
			continue
		end

		local var5 = v1:GetAttribute("EmitCount")
		v1:Emit(var5 or (arg3 or 5))
	end
end

local function EmitPartPooled(arg1, arg2, arg3)
	local var2 = tbl2[arg2]
	if not var2 then
		var2 = { Items = {}, Next = 1 }
		for i1 = 1, 16 do
			local var4 = MakeEffectPart(arg2)
			if not var3 then
				var3 = Instance.new("Folder")
				var3.Name = "VFXPool"
				var3.Parent = workspace
			end

			var4.Parent = var3
			table.insert(var2.Items, var4)
		end

		tbl2[arg2] = var2
	end

	local var5 = var2.Items[var2.Next]
	local var6 = var2.Next % #var2.Items + 1
	var2.Next = var6
	var5.CFrame = CFrame.new(arg1) * arg2.CFrame.Rotation
	FireEmitters(var5, arg3)
end

local function EmitPart(arg1, arg2, arg3)
	local var1 = MakeEffectPart(arg2)
	var1.CFrame = CFrame.new(arg1) * arg2.CFrame.Rotation
	if not var3 then
		var3 = Instance.new("Folder")
		var3.Name = "VFXPool"
		var3.Parent = workspace
	end

	var1.Parent = var3
	task.delay(FireEmitters(var1, arg3) * 2, function()
		var1:Destroy()
	end)
end

local function ShakeCamera(arg1, arg2, arg3)
	arg1.CameraOffset = arg3
	local var1 = TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
	var2.Play(arg1, var1, { CameraOffset = arg1.CameraOffset + Vector3.new((math.random() - 0.5) * arg2, 0, (math.random() - 0.5) * arg2) })
end

return {
	Emit = function(arg1, arg2, arg3)
		if not var1.Data[var4.Name].Settings.VFXSetting.Value then
			return
		end

		if arg2:IsA("Attachment") then
			if arg2:GetAttribute("Pooled") and (typeof(arg1) == "Instance" and arg1:IsA("BasePart")) then
				EmitPooled(arg1, arg2, arg3)
				return
			end

			local var2, var3 = task.spawn(function()
				local var1 = Instance.new("Attachment")
				var1.Parent = arg1
				local num1 = 0
				for k1, v1 in arg2:GetDescendants() do
					if not v1:IsA("ParticleEmitter") then
						continue
					end

					local var2 = v1:Clone()
					var2.Parent = var1
					if var2:GetAttribute("EmitCount") then
						local str2 = "EmitCount"
						var2:Emit(var2:GetAttribute(str2))
					else
						var2:Emit(arg3 or 5)
					end

					num1 = math.max(num1, var2.Lifetime.Max)
				end

				task.delay(num1 * 2, function()
					var1:Destroy()
				end)
			end)

			if var3 then
				print("Error playing particle" .. var3)
			end

			return
		end

		if arg2:IsA("BasePart") then
			local bool2 = false
			if typeof(arg1) == "Instance" then
				if arg1:IsA("BasePart") then
					bool2 = arg1.Position
				else
					if arg1:IsA("Attachment") then
						bool2 = arg1.WorldPosition
					else
						bool2 = if arg1:IsA("Model") then arg1:GetPivot().Position else nil
					end
				end
			end

			if not bool2 then
				return
			end

			if arg2:GetAttribute("Pooled") then
				EmitPartPooled(bool2, arg2, arg3)
				return
			end

			EmitPart(bool2, arg2, arg3)
			return
		end

		local var5, var6 = task.spawn(function()
			local var1 = Instance.new("Attachment")
			var1.Parent = arg1
			local var2 = arg2:Clone()
			var2.Parent = var1
			if var2:GetAttribute("EmitCount") then
				local str2 = "EmitCount"
				var2:Emit(var2:GetAttribute(str2))
			else
				var2:Emit(arg3 or 5)
			end

			task.wait(var2.Lifetime.Max * 2)
			var1:Destroy()
		end)

		if var6 then
			print("Error playing particle" .. var6)
		end
	end,
	EmitInf = function(arg1, arg2)
		local var1 = arg2:Clone()
		if var1:IsA("BasePart") then
			var1.Size = arg1.Size
			var1.Transparency = 1
			var1.Anchored = true
			var1.CanCollide = false
			local var2 = arg1
			var1.Parent = var2 or game.Workspace
			var1.Position = arg1 and arg1.Position or var4.Character.PrimaryPart.Position
		else
			local var3 = arg1
			var3 = var3 or (var4.Character:FindFirstChild("Torso") or var4.Character:FindFirstChild("UpperTorso"))
			var1.Parent = var3
		end

		for k1, v1 in var1:GetDescendants() do
			if not v1:IsA("ParticleEmitter") then
				continue
			end

			local var5 = v1:GetAttribute("EmitCount")
			v1.Enabled = true
			if not var5 or var5 == 0 then
				var5 = 1
			end

			v1:Emit(var5)
		end
	end,
	CameraShake = function(arg1, arg2)
		task.spawn(function()
			local var1 = var4.Character.Humanoid
			local num1 = 0
			local var2 = var1.CameraOffset
			while num1 < arg2 do
				task.spawn(function()
					ShakeCamera(var1, arg1, var2)
				end)

				task.wait(0.08)
				num1 = num1 + 0.08
			end

			var1.CameraOffset = var2
		end)
	end,
}

--- ReplicatedStorage.Framework.Client.Beam [ModuleScript]
-- y u r i

local tbl1 = {}
local var1 = nil
local var2 = nil
local var3 = script.Beam
tbl1.New = function(arg1, arg2)
	tbl1.Destroy()
	var1 = Instance.new("Attachment")
	var1.Name = "PlayerAttachment"
	var1.Parent = arg1
	var2 = Instance.new("Attachment")
	var2.Parent = arg2
	var3.Parent = workspace
	var3.Attachment0 = var1
	var3.Attachment1 = var2
	return tbl1
end

tbl1.Destroy = function()
	if var1 then
		var1:Destroy()
		var1 = nil
	end

	if var2 then
		var2:Destroy()
		var2 = nil
	end

	var3.Parent = script
end

return tbl1

--- ReplicatedStorage.Framework.Client.Tween [ModuleScript]
-- y u r i

local var1 = game:GetService("TweenService")
return {
	Play = function(arg1, arg2, arg3)
		var1:Create(arg1, arg2, arg3):Play()
	end,
	Model = function(arg1, arg2, arg3)
		local var2 = Instance.new("CFrameValue")
		var2.Value = arg1:GetPivot()
		local var3 = nil
		local var4 = var1:Create(var2, arg2, arg3)
		var4:Play()
		var3 = var2.Changed:Connect(function()
			arg1:PivotTo(var2.Value)
		end)

		var4.Completed:Connect(function()
			var2:Destroy()
			var3:Disconnect()
		end)
	end,
	ScaleModel = function(arg1, arg2, arg3)
		local var2 = Instance.new("NumberValue")
		var2.Value = arg1:GetScale()
		local var3 = var1:Create(var2, arg2, { Value = arg3 })
		var3:Play()
		local var4 = nil
		var4 = var2.Changed:Connect(function(arg1)
			arg1:ScaleTo(arg1)
		end)

		var3.Completed:Once(function()
			var4:Disconnect()
			var4 = nil
			var2:Destroy()
		end)
	end,
}

--- ReplicatedStorage.Framework.Client.Animation [ModuleScript]
-- y u r i

return { Play = function(arg1, arg2, arg3)
	task.spawn(function()
		local var1 = Instance.new("Animation")
		var1.AnimationId = arg2
		local var2 = arg1.Humanoid.Animator:LoadAnimation(var1)
		var2.Looped = false
		var2:Play()
		var2:AdjustSpeed(arg3 or 1)
		task.wait(5)
		var2:Stop()
		var2:Destroy()
		var1:Destroy()
	end)
end }

--- ReplicatedStorage.Framework.Shared [ModuleScript]
-- y u r i

return { GetModules = function()
	local tbl1 = {}
	for k1, v1 in script:GetChildren() do
		if not v1:IsA("ModuleScript") then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end }

--- ReplicatedStorage.Framework.Shared.Network [ModuleScript]
-- y u r i

local tbl1 = {}
local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("RunService")
function OnServerEvent(arg1, arg2, arg3, arg4, ...)
	if not tbl1[arg2] then
		tbl1[arg2] = {}
	end

	if tbl1[arg2][arg1.Name] then
		return
	end

	tbl1[arg2][arg1.Name] = true
	task.spawn(function()
		task.wait(arg4 or 0.02)
		tbl1[arg2][arg1.Name] = nil
	end)

	local var1 = arg1
	return arg3(var1, ...)
end

function FindRemote(arg1)
	local var2 = arg1
	return var1.Remotes:FindFirstChild(var2)
end

return {
	Fire = function(arg1, ...)
		local var2 = FindRemote(arg1)
		if var2 then
			if var2:IsA("RemoteEvent") then
				var2:FireServer(...)
				return
			end

			if not var2:IsA("RemoteFunction") then
				return
			end

			return var2:InvokeServer(...)
		end

		print("invalid remote: " .. arg1)
	end,
	FireClient = function(arg1, arg2, ...)
		local var1 = FindRemote(arg2)
		if var1:IsA("RemoteEvent") then
			var1:FireClient(arg1, ...)
			return
		end

		if var1:IsA("RemoteFunction") then
			local var3 = arg1
			return var1:InvokeClient(var3, ...)
		end
	end,
	FireAllClients = function(arg1, ...)
		FindRemote(arg1):FireAllClients(...)
	end,
	Connect = function(arg1, arg2, arg3, arg4)
		local var4 = FindRemote(arg1)
		if var4 == nil then
			var4 = Instance.new(arg4 or "RemoteEvent")
			var4.Name = arg1
			var4.Parent = var1.Remotes
		end

		if var2:IsClient() then
			if var4:IsA("RemoteEvent") then
				var4.OnClientEvent:Connect(function(...)
					arg2(...)
				end)

				return
			end

			if not var4:IsA("RemoteFunction") then
				return
			end

			var4.OnClientInvoke = function(_, ...)
				return arg2(...)
			end

			return
		end

		if var4:IsA("RemoteEvent") then
			var4.OnServerEvent:Connect(function(arg1, ...)
				OnServerEvent(arg1, arg1, arg2, arg3, ...)
			end)

			return
		end

		if var4:IsA("RemoteFunction") then
			var4.OnServerInvoke = function(arg1, ...)
				local var1 = arg1
				local var2 = arg1
				local var3 = arg2
				local var4 = arg3
				return OnServerEvent(var1, var2, var3, var4, ...)
			end

		end
	end,
}

--- ReplicatedStorage.Framework.Shared.Short [ModuleScript]
-- y u r i

local tbl1 = {
	Prefixes = {
		"K",
		"M",
		"B",
		"T",
		"Qd",
		"Qn",
		"Sx",
		"Sp",
		"Oc",
		"No",
		"De",
		"UDe",
		"DDe",
		"TDe",
		"QtDe",
		"QnDe",
		"SxDe",
		"SpDe",
		"OcDe",
		"NoDe",
		"Vg",
		"UVg",
		"DVg",
		"TVg",
		"QdVg",
		"QnVg",
		"SxVg",
		"SpVg",
		"OcVg",
		"NoVg",
		"Tg",
		"UTg",
		"DTg",
		"TTg",
		"QdTg",
		"QnTg",
		"SxTg",
		"SpTg",
		"OcTg",
		"NoTg",
		"qg",
		"Uqg",
		"Dqg",
		"Tqg",
		"Qdqg",
		"Qnqg",
		"Sxqg",
		"Spqg",
		"Ocqg",
		"Noqg",
		"Qg",
		"UQg",
		"DQg",
		"TQg",
		"QdQg",
		"QnQg",
		"SxQg",
		"SpQg",
		"OcQg",
		"NoQg",
		"sg",
		"Usg",
		"Dsg",
		"Tsg",
		"Qdsg",
		"Qnsg",
		"Sxsg",
		"Spsg",
		"Ocsg",
		"Nosg",
		"Sg",
		"USg",
		"DSg",
		"TSg",
		"QdSg",
		"QnSg",
		"SxSg",
		"SpSg",
		"OcSg",
		"NoSg",
		"Og",
		"UOg",
		"DOg",
		"TOg",
		"QdOg",
		"QnOg",
		"SxOg",
		"SpOg",
		"OcOg",
		"NoOg",
		"Ng",
		"UNg",
		"DNg",
		"TNg",
		"QdNg",
		"QnNg",
		"SxNg",
		"SpNg",
		"OcNg",
		"NoNg",
		"Ce",
	},
	CutDigits = function(arg1)
		if arg1 - math.floor(arg1) == 0 then
			return arg1
		end

		local str1 = "%.2f"
		local var1 = arg1
		return string.format(str1, var1)
	end,
	toComma = function(arg1)
		local var1 = tostring(arg1)
		local var2 = nil
		repeat
			local var3, var4 = string.gsub(var1, "^(-?%d+)(%d%d%d)", "%1,%2")
			var1 = var3
		until var4 == 0

		return var1
	end,
}

tbl1.toSuffix = function(arg1, arg2)
	if arg1 == 0 then
		return arg1
	end

	if arg1 < 1 then
		local var2 = arg1
		return tbl1.CutDigits(var2)
	end

	if arg1 < 0 then
		local var3 = math.abs(arg1)
		var3 = var3 or arg1
	end

	arg1 = arg1
	local var4 = math.floor(math.log10(arg1) / 3)
	return tbl1.CutDigits(arg1 / 1000 ^ var4) .. (tbl1.Prefixes[math.floor(var4)] or "")
end

tbl1.toTime = function(arg1)
	if not tonumber(arg1) then
		return arg1
	end

	arg1 = math.max(0, arg1)
	local var1 = math.floor(arg1 / 86400)
	arg1 = arg1 - var1 * 86400
	local var2 = math.floor(arg1 / 3600)
	arg1 = arg1 - var2 * 3600
	local var3 = math.floor(arg1 / 60)
	arg1 = arg1 - var3 * 60
	if 0 < arg1 then
		local var4 = " " .. math.floor(arg1) .. "s"
		var4 = var4 or ""
	end

	local var6 = (0 < var1 and var1 .. "d" or "") .. (0 < var2 and " " .. var2 .. "h" or "") .. (0 < var3 and " " .. var3 .. "m" or "") .. ""
	if var6 == "" then
		return "0s"
	end

	return var6
end

tbl1.toDate = function(arg1)
	if not tonumber(arg1) then
		return arg1
	end

	local var1 = os.date("!*t", arg1)
	return var1.day .. " " .. ({ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" })[var1.month] .. " " .. var1.year
end

tbl1.speedruntime = function(arg1, arg2)
	if arg1 < 60 then
		return arg1 .. "s"
	end

	local var1 = math.floor(arg1 / 86400)
	local var2 = math.floor(arg1 % 86400 / 3600)
	local var3 = math.floor(arg1 % 3600 / 60)
	local var4 = math.floor(arg1 % 60)
	local var8 = if arg2 then "%s" else "%s %s"
	if 0 < var1 then
		local var9 = var1 .. "d"
		local var10 = var2 .. "h"
		return var8:format(var9, var10)
	end

	if 0 < var2 then
		local var13 = var2 .. "h"
		local var14 = var3 .. "m"
		return var8:format(var13, var14)
	end

	if 0 < var3 then
		local var17 = var3 .. "m"
		local var18 = var4 .. "s"
		return var8:format(var17, var18)
	end

	return var4 .. "s"
end

tbl1.toFullTime = tbl1.speedruntime
return tbl1

--- ReplicatedStorage.Framework.Shared.Stat [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players")
local var3 = nil
local tbl1 = { Cached = {} }
local function CreatePath(arg1, arg2)
	local tbl1 = {}
	local var1 = arg2
	repeat
		table.insert(tbl1, 1, var1.Parent.Name)
		var1 = var1.Parent
	until var1.Parent == arg1

	return tbl1
end

tbl1.Get = function(arg1, arg2)
	if arg2 == nil then
		arg2 = arg1
		arg1 = var2.LocalPlayer
	end

	if not var3 then
		var3 = var1.Data
	end

	local var5 = var3:FindFirstChild(arg1.Name)
	if not var5 then
		return
	end

	local var7 = tbl1.Cached[arg2]
	local var8
	if var7 then
		if var7 == {} then
			return var5[arg2]
		end

		local var9 = nil
		local success, result = pcall(function()
			local var1 = var5
			for k1, v1 in var7, nil do
				var1 = var1[v1]
			end

			var9 = var1[arg2]
		end)

		if success then
			return var9
		end

		var8 = nil
		tbl1.Cached[arg2] = var8
	end

	if var5.Stats:FindFirstChild(arg2) then
		tbl1.Cached[arg2] = { "Stats" }
		return var5.Stats[arg2]
	end

	for k1, v1 in var5:GetDescendants() do
		if v1.Name ~= arg2 then
			continue
		end

		tbl1.Cached[arg2] = {}
		if v1.Parent ~= var5 then
			tbl1.Cached[arg2] = CreatePath(var5, v1)
		end

		return v1
	end
end

tbl1.GetDataFolder = function(arg1)
	if not var3 then
		var3 = var1.Data
	end

	local var2 = arg1.Name
	return var3:FindFirstChild(var2)
end

local function FolderIsComplete(arg1)
	local var2 = arg1:GetAttribute("ValueCount")
	if not var2 then
		return false
	end

	local num1 = 0
	for k1, v1 in arg1:GetDescendants() do
		if not v1:IsA("ValueBase") then
			continue
		end

		num1 = num1 + 1
		if var2 > num1 then
			continue
		end

		return true
	end

	return false
end

tbl1.IsLoaded = function(arg1)
	if not var3 then
		var3 = var1.Data
	end

	local var4 = arg1
	arg1 = var4 or var2.LocalPlayer
	if arg1.Parent == nil then
		return false
	end

	var4 = arg1:FindFirstChild("Loaded")
	if not var4 or (not var4.Value) then
		return false
	end

	local var6 = var1.Data:FindFirstChild(arg1.Name)
	if not var6 then
		return false
	end

	return (FolderIsComplete(var6))
end

tbl1.WaitForLoad = function(arg1)
	local var1 = arg1
	arg1 = var1 or var2.LocalPlayer
	repeat
		task.wait()
	until tbl1.IsLoaded(arg1)

	return arg1.Parent ~= nil
end

return tbl1

--- ReplicatedStorage.Framework.Shared.Friends [ModuleScript]
-- y u r i

local var1 = game:GetService("Players")
local var2 = game:GetService("SocialService")
return {
	GetFriendsInServer = function(arg1)
		local num1 = 0
		if arg1 == nil then
			arg1 = var1.LocalPlayer
		end

		local tbl1 = {}
		for k1, v1 in var1:GetPlayers() do
			if v1 == arg1 then
				continue
			end

			local success, result = pcall(function()
				local var1 = v1.UserId
				return arg1:IsFriendsWith(var1)
			end)

			if not success or (not result) then
				continue
			end

			table.insert(tbl1, v1)
			num1 = num1 + 1
		end

		return num1
	end,
	PromptFriendInvite = function(arg1)
		if arg1 == nil then
			arg1 = var1.LocalPlayer
		end

		pcall(function()
			var2:PromptGameInvite(arg1)
		end)
	end,
}

--- ReplicatedStorage.Framework.Shared.Policies [ModuleScript]
-- y u r i

local var1 = game:GetService("PolicyService")
local tbl1 = { PolicyInfoCache = {} }
tbl1.GetPolicyInfoForPlayerAsync = function(arg1)
	if tbl1.PolicyInfoCache[arg1] then
		return tbl1.PolicyInfoCache[arg1]
	end

	local success, result = pcall(function()
		local var2 = arg1
		return var1:GetPolicyInfoForPlayerAsync(var2)
	end)

	if success then
		tbl1.PolicyInfoCache[arg1] = result
		return result
	end
end

return tbl1

--- ReplicatedStorage.Framework.Types [ModuleScript]
-- y u r i

return {}

--- ReplicatedStorage.Modules.Client.UI [ModuleScript]
-- y u r i

game:GetService("Debris")
local var1 = game:GetService("UserInputService")
local var2 = game:GetService("Players")
local var3 = require(game:GetService("ReplicatedStorage").Framework)
local var4 = require(script.OnHold)
local tbl1 = { ButtonAnimations = require(script.ButtonAnimations) }
tbl1.Colors = require(script.Colors)
tbl1.FrameOpenings = require(script.FrameOpenings)
tbl1.Hover = require(script.Hover)
tbl1.Notification = require(script.Notification)
tbl1.OnHold = var4.OnHold
tbl1.Viewport = require(script.Viewport)
tbl1.Writer = require(script.Writer)
tbl1.PopUps = require(script.PopUps)
var3.Stat.WaitForLoad(game.Players.LocalPlayer)
tbl1.MakeDraggable = function(arg1)
	local var2 = nil
	local var4 = arg1.Position
	local var5 = nil
	local bool1 = false
	local var6 = TweenInfo.new(0.05)
	arg1:GetAttributeChangedSignal("Progress"):Connect(function()
		local tbl1 = { Position = UDim2.fromScale(arg1:GetAttribute("Progress"), var4.Y.Scale) }
		var3.Tween.Play(arg1, var6(tbl1))
	end)

	arg1.InputBegan:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseButton1 or arg1.UserInputType == Enum.UserInputType.Touch then
			bool1 = true
			arg1:SetAttribute("Dragging", true)
			var2 = arg1.Position
			var4 = arg1.Position
			arg1.Changed:Connect(function()
				if arg1.UserInputState == Enum.UserInputState.End then
					bool1 = false
					arg1:SetAttribute("Dragging", false)
					arg1:Destroy()
				end
			end)

		end
	end)

	arg1.InputChanged:Connect(function(arg1)
		if arg1.UserInputType == Enum.UserInputType.MouseMovement or arg1.UserInputType == Enum.UserInputType.Touch then
			var5 = arg1
		end
	end)

	local var7 = var1.InputChanged:Connect(function(arg1, _)
		if arg1 == var5 and bool1 then
			arg1:SetAttribute("Progress", (math.clamp(var4.X.Scale + (arg1.Position - var2).X / arg1.Parent.AbsoluteSize.X, 0, 1)))
		end
	end)

	arg1.Destroying:Connect(function()
		var7:Disconnect()
	end)
end

tbl1.ConnectListAutoScale = function(arg1)
	local var1 = arg1:FindFirstChildWhichIsA("UIListLayout")
	local var2 = arg1:FindFirstChildWhichIsA("UIPadding")
	local var3 = var1 and var1.Padding.Scale or 0
	local var4 = var2 and var2.PaddingTop.Scale or 0
	local var5 = var2 and var2.PaddingBottom.Scale or 0
	local tbl1 = {}
	local function Apply()
		local var7 = arg1.AbsoluteSize.Y
		if var7 <= 0 then
			return
		end

		local var10
		local var11
		if var1 and 0 < var3 then
			var10 = var3
			var11 = var7 * var10
			var1.Padding = UDim.new(0, var11)
		end

		if var2 then
			if 0 < var4 then
				var10 = var4
				var11 = var7 * var10
				var2.PaddingTop = UDim.new(0, var11)
			end

			if 0 < var5 then
				var10 = var5
				var11 = var7 * var10
				var2.PaddingBottom = UDim.new(0, var11)
			end
		end

		for k1, v1 in tbl1, nil do
			if k1.Parent ~= arg1 then
				continue
			end

			local var12 = UDim2.new(k1.Size.X.Scale, k1.Size.X.Offset, 0, var7 * v1)
			k1.Size = var12
		end
	end

	arg1.ChildAdded:Connect(function(arg1)
		if not arg1:IsA("GuiObject") then
			return
		end

		if tbl1[arg1] then
			return
		end

		local var2 = arg1.Size.Y.Scale
		if var2 <= 0 then
			return
		end

		tbl1[arg1] = var2
		Apply()
	end)

	arg1.ChildRemoved:Connect(function(arg1)
		tbl1[arg1] = nil
	end)

	arg1:GetPropertyChangedSignal("AbsoluteSize"):Connect(Apply)
	for k1, v1 in arg1:GetChildren() do
		if not v1:IsA("GuiObject") then
		else
			if tbl1[v1] then
			else
				local var7 = v1.Size.Y.Scale
	if var7 > 0 then
					tbl1[v1] = var7
					Apply()
				end
			end
		end
	end

	Apply()
end

local tbl2 = {}
tbl1.addStars = function(arg1)
	tbl2[arg1] = arg1
end

tbl1.removeStars = function(arg1)
	if tbl2[arg1] then
		tbl2[arg1] = nil
	end
end

tbl1.animateStar = function(_)
	task.spawn(function()
		task.wait(math.random(50, 200) / 100)
	end)
end

task.spawn(function()
	while true do
		for k1, v1 in tbl2, nil do
			if k1.Parent == nil then
				tbl1.removeStars(k1)
			else
				tbl1.animateStar(k1)
			end
		end

		task.wait(1.5)
	end
end)

local var5 = var2.LocalPlayer
local tbl3 = {}
tbl1.ErrorMessage = function(arg1)
	local var1 = var5.PlayerGui.Front.Errors
	local var2 = arg1
	if not tbl3[arg1] then
		tbl3[arg1] = 1
	else
		local var4 = tbl3
		local var6 = var4[arg1] + 1
		var4[arg1] = var6
		var4 = var1:FindFirstChild(var2)
		arg1 = ("%* (x%*)"):format(arg1, tbl3[arg1])
		if var4 then
			var4:Destroy()
		end
	end

	local var7 = var1.ErrorTemplate:Clone()
	var7.Text = arg1
	var7.Name = var2
	var7.Visible = true
	var7.Parent = var1
	var3.Sound.Play("Error")
	task.wait(2)
	local var8 = tbl3[var2]
	if var7 then
		var7:Destroy()
		if var8 == tbl3[var2] then
			tbl3[var2] = nil
		end
	end
end

var4.initialize()
return tbl1

--- ReplicatedStorage.Modules.Client.UI.ButtonAnimations [ModuleScript]
-- y u r i

require(game.ReplicatedStorage.Framework.Client.Tween)
return { Create = function(arg1, arg2, arg3)
	local tbl1 = { X = arg1.Size.X.Scale, Y = arg1.Size.Y.Scale }
	arg2 = arg2 or 1.05
	arg3 = arg3 or 0.075
	arg1.MouseEnter:Connect(function()
		arg1:TweenSize(UDim2.fromScale(tbl1.X * arg2, tbl1.Y * arg2), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, arg3, true)
	end)

	arg1.MouseLeave:Connect(function()
		task.wait(arg3)
		arg1:TweenSize(UDim2.fromScale(tbl1.X, tbl1.Y), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, arg3, true)
	end)

	local var2 = arg1:FindFirstChildOfClass("TextButton")
	if var2 then
		var2.MouseButton1Down:Connect(function()
			arg1:TweenSize(UDim2.fromScale(tbl1.X / arg2, tbl1.Y / arg2), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, arg3 / 1.5, true)
		end)

		var2.MouseButton1Up:Connect(function()
			arg1:TweenSize(UDim2.fromScale(tbl1.X * arg2, tbl1.Y * arg2), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, arg3 / 1.5, true)
		end)

	end
end }

--- ReplicatedStorage.Modules.Client.UI.Hover [ModuleScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
var1:WaitForChild("PlayerGui")
local var2 = game:GetService("RunService")
return { Create = function(arg1, arg2, arg3)
	local var3 = var1:GetMouse()
	local var4 = var3.Move:Connect(function()
		arg2.Visible = true
		arg2.Position = UDim2.fromOffset(var3.X - arg3.AbsolutePosition.X + 10, var3.Y - arg3.AbsolutePosition.Y + 10)
	end)

	local var5 = nil
	local var6 = nil
	var5 = arg1.MouseLeave:Connect(function()
		arg2.Visible = false
		var4:Disconnect()
		var5:Disconnect()
		if var6 then
			var6:Disconnect()
		end
	end)

	var2.Heartbeat:Connect(function()
		local var1 = Vector2.new(var3.X, var3.Y)
		local var2 = arg1.AbsolutePosition
		local var8 = arg1.AbsoluteSize
		if var2.X <= var1.X and (var1.X <= var2.X + var8.X and (var2.Y <= var1.Y and var1.Y > var2.Y + var8.Y)) or var5 then
			var4:Disconnect()
			var5:Disconnect()
			var6:Disconnect()
			arg2.Visible = false
		end
	end)
end }

--- ReplicatedStorage.Modules.Client.UI.Notification [ModuleScript]
-- y u r i

game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local var1 = game:GetService("ReplicatedStorage")
local var2 = game:GetService("Players").LocalPlayer
local tbl1 = {}
local var3 = game:GetService("TweenService")
local var4 = require(var1.Framework)
local var5 = var2:WaitForChild("PlayerGui")
local var6 = nil
local var7 = nil
local tbl2 = {
	MaxNotifications = 4,
	NotificationCount = 0,
	Create = function(arg1)
		table.insert(tbl1, arg1)
	end,
}

local function DeleteNotification(arg1)
	arg1:SetAttribute("Ended", true)
	if var7 == arg1 then
		var7 = nil
		var6 = nil
	end

	local var1 = tbl2
	local var2 = var1.NotificationCount - 1
	var1.NotificationCount = var2
	var3:Create(arg1.Label, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
	var3:Create(arg1.Label.UIStroke, TweenInfo.new(0.2), { Transparency = 1 }):Play()
	task.wait(0.2)
	arg1:Destroy()
end

local function SpawnNotification(arg1)
	var4.Sound.Play(var2, "Notification")
	if var6 == arg1.Text and var7 then
		local var9 = var7:GetAttribute("Count") or 2
		var7.Label.Text = arg1.Text .. " (x" .. var9 .. ")"
		var7:SetAttribute("Count", var9 + 1)
		var7:SetAttribute("End", os.clock() + (arg1.Duration or 3))
		return
	end

	local var10 = var1.Assets.UI.Main.Notification:Clone()
	var10:SetAttribute("End", os.clock() + (arg1.Duration or 3))
	var10.Label.Text = arg1.Text or ""
	local var11 = arg1.Color
	var11 = var11 or Color3.fromRGB(255, 255, 255)
	var10.Label.TextColor3 = var11
	var10.Parent = var5.Main.Notifications
	var10.Size = UDim2.fromScale(1.2, 0.2)
	local var12 = TweenInfo.new(0.1)
	var3:Create(var10, var12, { Size = UDim2.fromScale(1, 0.1) }):Play()
	local var13 = tbl2
	var11 = var13.NotificationCount + 1
	var13.NotificationCount = var11
	var7 = var10
	var6 = arg1.Text
end

tbl2.init = function()
	task.spawn(function()
		while task.wait() do
			for k1, v1 in var5.Main.Notifications:GetChildren() do
				if not v1:IsA("Frame") then
					continue
				end

				if v1:GetAttribute("Ended") then
					continue
				end

				if v1:GetAttribute("End") > os.clock() then
					continue
				end

				task.spawn(DeleteNotification, v1)
			end

			if tbl2.MaxNotifications <= tbl2.NotificationCount then
				continue
			end

			local var1 = table.remove(tbl1)
			if var1 == nil then
				continue
			end

			local success, result = pcall(SpawnNotification, var1)
			if success then
				continue
			end

			local var2 = "[NOTIFICATION] - " .. result
			warn(var2)
		end
	end)
end

return tbl2

--- ReplicatedStorage.Modules.Client.UI.OnHold [ModuleScript]
-- y u r i

local tbl1 = {}
local var1 = game:GetService("RunService")
local tbl2 = {
	init = false,
	OnHold = function(arg1, arg2, arg3)
		arg1.MouseButton1Down:Connect(function()
			arg1:SetAttribute("Pressing", true)
			arg2()
		end)

		arg1.MouseButton1Up:Connect(function()
			if arg1:GetAttribute("Pressing") then
				arg1:SetAttribute("Pressing", nil)
				arg3()
			end
		end)

		arg1.MouseEnter:Connect(function()
			arg1:SetAttribute("Selected", true)
		end)

		arg1.MouseLeave:Connect(function()
			arg1:SetAttribute("Selected", nil)
		end)

		local var1 = Instance.new("BindableEvent", script)
		tbl1[arg1] = var1
		var1.Event:Connect(function()
			if arg1:GetAttribute("Pressing") then
				arg1:SetAttribute("Pressing", nil)
				arg3()
			end
		end)

		arg1.Destroying:Connect(function()
			var1:Destroy()
		end)

		return var1
	end,
}

tbl2.initialize = function()
	if tbl2.init then
		return
	end

	tbl2.init = true
	var1.Heartbeat:Connect(function()
		for k1, v1 in tbl1, nil do
			if k1.Parent == nil or v1.Parent == nil then
				tbl1[k1] = nil
			else
				if not k1:GetAttribute("Pressing") then
					continue
				end

				if k1:GetAttribute("Selected") ~= nil then
					continue
				end

				v1:Fire()
			end
		end
	end)
end

return tbl2

--- ReplicatedStorage.Modules.Client.UI.Viewport [ModuleScript]
-- y u r i

local var1 = game:GetService("RunService")
local tbl1 = {}
tbl1.__index = tbl1
tbl1.init = function(arg1)
	local var1 = arg1.ViewportFrame
	if var1.CurrentCamera == nil then
		arg1.Cam = Instance.new("Camera", var1)
		arg1.Cam.CameraType = Enum.CameraType.Scriptable
		var1.CurrentCamera = arg1.Cam
	end
end

tbl1.SetModel = function(arg1, arg2)
	if arg1.Model then
		arg1.Model:Destroy()
	end

	arg1.Model = arg2:Clone()
	arg1.Model:PivotTo(CFrame.new())
	arg1.Model.Parent = arg1.ViewportFrame
	local var1 = math.max(arg2.Hitbox.Size.X, arg2.Hitbox.Size.Y, arg2.Hitbox.Size.Z)
	arg1.CameraYPos = arg2.Hitbox.Size.Y / 2
	arg1.CameraOffset = var1
end

tbl1.Disconnect = function(arg1)
	if arg1.Connection then
		arg1.Connection:Disconnect()
		arg1.Connection = nil
	end
end

tbl1.Connect = function(arg1)
	arg1:Disconnect()
	local num1 = 0
	arg1.Connection = var1.RenderStepped:Connect(function(arg1)
		local var1 = nil
		local var2 = nil
		arg1.Cam.CFrame = CFrame.lookAt(Vector3.new(arg1.CameraOffset * math.cos(num1 * arg1.CameraRotationSpeed), arg1.CameraYPos, arg1.CameraOffset * math.sin(num1 * arg1.CameraRotationSpeed)), (Vector3.new()))
		local var3 = num1 + arg1
		num1 = var3
	end)
end

local tbl2 = { Viewports = {} }
tbl2.new = function(arg1)
	if tbl2.Viewports[arg1] then
		return tbl2.Viewports[arg1]
	end

	local var1 = setmetatable({ ViewportFrame = arg1 }, tbl1)
	var1.CameraRotationSpeed = 1
	var1:init()
	arg1.Destroying:Connect(function()
		tbl2.Viewports[arg1] = nil
		var1:Disconnect()
	end)

	tbl2.Viewports[arg1] = var1
	return var1
end

return tbl2

--- ReplicatedStorage.Modules.Client.UI.Writer [ModuleScript]
-- y u r i

game:GetService("RunService")
require(game:GetService("ReplicatedStorage").Framework)
local var1 = game:GetService("TweenService")
local var2 = game:GetService("Players").LocalPlayer
return { Write = function(arg1, arg2, arg3)
	arg1.MaxVisibleGraphemes = 0
	arg1.Text = arg2
	local var2 = utf8.len(arg1.ContentText)
	local num1 = 0
	while true do
		if num1 >= 1 then
			break
		end

		if arg1.Parent == nil then
			break
		end

		num1 = math.min(num1 + task.wait() / arg3.Time, 1)
		local var4 = math.floor(var2 * var1:GetValue(num1, arg3.EasingStyle, arg3.EasingDirection))
		if arg1.MaxVisibleGraphemes < var4 then
		end

		arg1.MaxVisibleGraphemes = var4
	end
end }

--- ReplicatedStorage.Modules.Client.UI.Colors [ModuleScript]
-- y u r i

return { applyGradient = function(arg1, arg2)
	if arg1:FindFirstChildWhichIsA("UIGradient") then
		arg1:FindFirstChildWhichIsA("UIGradient"):Destroy()
	end

	arg2:Clone().Parent = arg1
end }

--- ReplicatedStorage.Modules.Client.UI.FrameOpenings [ModuleScript]
-- y u r i

local var1 = setmetatable({}, { __mode = "k" })
local var2 = require(game.ReplicatedStorage.Framework.Client.Tween)
local var3 = nil
local var4 = game:GetService("Lighting")
local var5 = game:GetService("Players").LocalPlayer
local bool1 = false
local function Setup()
	local var1 = Instance.new("ScreenGui")
	var1.Name = "Blur"
	var1.ResetOnSpawn = false
	var1.IgnoreGuiInset = true
	var1.DisplayOrder = -1
	var1.Parent = var5.PlayerGui
	var3 = script.Blur:Clone()
	var3.Parent = var1
	bool1 = true
	local var2 = Instance.new("BlurEffect")
	var2.Enabled = false
	var2.Parent = var4
end

local function BlurAnimation(arg1)
	local var1 = TweenInfo.new(0.25)
	var2.Play(var3, var1, { BackgroundTransparency = arg1 })
	local var5 = var2.Play
	local var6 = var4.Blur
	var1 = TweenInfo.new(0.25)
	var5(var6, var1, { Size = if arg1 == 1 then 0 else 12 })
end

local tbl1 = {
	CloseFrame = function(arg1)
		if not bool1 then
			Setup()
		end

		BlurAnimation(1)
		if not var1[arg1] then
			var1[arg1] = arg1.Position
		end

		local var3 = var1[arg1]
		local var4 = UDim2.new(var3.X.Scale, var3.X.Offset, -0.5, 0)
		arg1:TweenPosition(var4, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.2, true)
		task.wait(0.1)
		arg1.Visible = false
		var2.Play(workspace.Camera, TweenInfo.new(0.25), { FieldOfView = 70 })
	end,
	OpenFrame = function(arg1)
		if not bool1 then
			Setup()
		end

		for k1, v1 in arg1.Parent:GetChildren() do
			if not v1:IsA("Frame") then
				continue
			end

			if not v1.Visible then
				continue
			end

			if not var1[v1] then
				var1[v1] = v1.Position
			end

			local var3 = var1[v1]
			local var4 = UDim2.new(var3.X.Scale, var3.X.Offset, -0.5, 0)
			v1:TweenPosition(var4, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.1, true)
			task.wait(0.08)
			v1.Visible = false
		end

		task.wait(0.03)
		if not var1[arg1] then
			var1[arg1] = arg1.Position
		end

		local var5 = var1[arg1]
		arg1.Position = UDim2.new(var5.X.Scale, var5.X.Offset, -0.5, 0)
		arg1.Visible = true
		if not var1[arg1] then
			var1[arg1] = arg1.Position
		end

		arg1:TweenPosition(var1[arg1], Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.2, true)
		BlurAnimation(0.55)
		var2.Play(workspace.Camera, TweenInfo.new(0.25), { FieldOfView = 50 })
	end,
}

tbl1.ToggleFrame = function(arg1)
	if not bool1 then
		Setup()
	end

	if arg1.Visible then
		tbl1.CloseFrame(arg1)
		return
	end

	tbl1.OpenFrame(arg1)
end

return tbl1

--- ReplicatedStorage.Modules.Client.UI.PopUps [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
require(var2.Shared.BigNum)
local var3 = var1.Frames
local var4 = require(var1.Framework)
local var5 = game:GetService("Players").LocalPlayer
var4.Stat.WaitForLoad(var5)
local var6 = var3.PopUp
local var7 = require(var2.Client.Suffix)
local var8 = game:GetService("TweenService")
local var9 = TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
local var10 = TweenInfo.new(0.15, Enum.EasingStyle.Bounce, Enum.EasingDirection.InOut)
local var11 = var5.PlayerGui:WaitForChild("Front"):WaitForChild("MainFrame")
local tbl1 = {}
return {
	CreatePopUp = function(arg1, arg2, arg3, arg4)
		if not var4.Stat.Get(arg1, "PopUpsSetting").Value then
			return
		end

		local var2 = Random.new():NextNumber()
		local var3 = arg1.PlayerGui:WaitForChild("Front")
		if var2 <= 0.15 then
			var2 = 0.15
		else
			if 0.85 <= var2 then
				var2 = 0.85
			end
		end

		local tbl1 = { Position = UDim2.fromScale(var2, 0.4) }
		tbl1.Transparency = 1
		local tbl2 = { Size = UDim2.new(0, 0, 0, 0) }
		local var5 = var6:Clone()
		var5.Parent = var3
		var5.Icon.Image = arg2
		var5.Amount.Text = "+ " .. var7.short(arg3)
		var5.Amount.TextColor3 = arg4
		var5.Position = UDim2.fromScale(var2, 0.8)
		var8:Create(var5, var9, tbl1):Play()
		task.wait(0.5)
		var8:Create(var5, var10, tbl2):Play()
		task.wait(0.15)
		var5:Destroy()
	end,
	NormalPopUp = function(arg1, arg2, arg3)
		if not var4.Stat.Get(var5, "PopUpsSetting").Value then
			return
		end

		local var1 = arg2
		arg2 = var1 or Color3.fromRGB(255, 255, 255)
		var1 = tbl1[arg1]
		arg3 = arg3 or 2.5
		if var1 and (var1.Label and var1.Label.Parent) then
			local var2 = var1.Count + 1
			var1.Count = var2
			var1.Label.Text = string.format("%s (x%d)", var1.BaseText, var1.Count)
			return
		end

		local var6 = var3.TextPopUp:Clone()
		var6.Size = UDim2.new(0, 0, 0, 0)
		var6.Parent = var11.Notifications
		var6.Text = arg1
		var6.TextColor3 = arg2
		tbl1[arg1] = { Label = var6, Count = 1, BaseText = arg1 }
		var6:TweenSize(UDim2.new(0.754, 0, 0.109, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine, 0.15)
		task.delay(arg3, function()
			if not var6 or (not var6.Parent) then
				tbl1[arg1] = nil
				return
			end

			var6:TweenSize(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Quad, 0.1)
			task.delay(0.3, function()
				if var6 and var6.Parent then
					var6:Destroy()
				end

				tbl1[arg1] = nil
			end)
		end)
	end,
}

--- ReplicatedStorage.Modules.Client.Hover [ModuleScript]
-- y u r i

game:GetService("ReplicatedStorage")
game:GetService("TweenService")
game:GetService("Lighting")
TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.InOut)
local tbl1 = {
	Down = function(arg1, arg2)
		arg1:TweenSize(UDim2.new(arg2.X.Scale - arg2.X.Scale / 15, 0, arg2.Y.Scale - arg2.Y.Scale / 15, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine, 0.15, true)
	end,
	Hover = function(arg1, arg2)
		arg1:TweenSize(UDim2.new(arg2.X.Scale - arg2.X.Scale / 25, 0, arg2.Y.Scale - arg2.Y.Scale / 25, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine, 0.15, true)
	end,
	Up = function(arg1, arg2)
		arg1:TweenSize(UDim2.new(arg2.X.Scale, 0, arg2.Y.Scale, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Sine, 0.075, true)
	end,
}

tbl1.CreateHover = function(arg1, arg2)
	arg1.MouseEnter:Connect(function()
		tbl1.Hover(arg1, arg2)
	end)

	arg1.MouseLeave:Connect(function()
		tbl1.Up(arg1, arg2)
	end)

	if arg1:IsA("TextButton") then
		arg1.MouseButton1Down:Connect(function()
			tbl1.Down(arg1, arg2)
		end)

		arg1.MouseButton1Up:Connect(function()
			tbl1.Up(arg1, arg2)
		end)

	end
end

return tbl1

--- ReplicatedStorage.Modules.Client.Binder [ModuleScript]
-- y u r i

local var1 = game:GetService("ContextActionService")
local var2 = game:GetService("UserInputService")
local var3 = game:GetService("GuiService")
local tbl1 = {}
local tbl2 = { AttackTree = { Enum.UserInputType.MouseButton1, Enum.UserInputType.Touch, Enum.KeyCode.ButtonR1 } }
local tbl3 = {}
var2.InputEnded:Connect(function(arg1)
	for k1, v1 in tbl1, nil do
		if table.find(tbl2[k1], arg1.UserInputType) or table.find(tbl2[k1], arg1.KeyCode) then
			tbl3[k1] = nil
		end
	end
end)

var3.MenuOpened:Connect(function()
	for k1, v1 in tbl1, nil do
		tbl3[k1] = nil
	end
end)

return {
	RegisterAction = function(arg1, arg2)
		if tbl1[arg1] then
			return
		end

		local var3 = tbl2[arg1]
		if not var3 then
			warn("No input config for action:", arg1)
			return
		end

		local var4 = var3
		var1:BindAction(arg1, function(_, arg2)
			arg2(arg2)
			if arg2 == Enum.UserInputState.Begin then
				tbl3[arg1] = true
			else
				if arg2 == Enum.UserInputState.End then
					tbl3[arg1] = nil
				end
			end

			return Enum.ContextActionResult.Pass
		end, false, table.unpack(var4))

		tbl1[arg1] = true
	end,
	Unregister = function(arg1)
		if not tbl1[arg1] then
			return
		end

		var1:UnbindAction(arg1)
		tbl1[arg1] = nil
		tbl3[arg1] = nil
	end,
	IsHolding = function(arg1)
		return tbl3[arg1]
	end,
	IsBound = function(arg1)
		return tbl1[arg1] == true
	end,
}

--- ReplicatedStorage.Modules.Client.ConsoleScroll [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Framework)
local var2 = game:GetService("TweenService")
return { SetupScroll = function(arg1, arg2)
	arg1.Up.MouseButton1Click:Connect(function()
		local var1 = TweenInfo.new(0.5)
		var2:Create(arg2, var1, { CanvasPosition = arg2.CanvasPosition - Vector2.new(0, 100) }):Play()
	end)

	arg1.Down.MouseButton1Click:Connect(function()
		local var1 = TweenInfo.new(0.5)
		var2:Create(arg2, var1, { CanvasPosition = arg2.CanvasPosition + Vector2.new(0, 100) }):Play()
	end)

	local var3 = var1.Stat.Get("Device")
	arg1.Visible = var3.Value == "Console"
	var3.Changed:Connect(function()
		arg1.Visible = var3.Value == "Console"
	end)
end }

--- ReplicatedStorage.Modules.Client.DropCurrency [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game:GetService("Players").LocalPlayer
var2.Stat.WaitForLoad(var3)
local var4 = Random.new()
local function RandomInteger(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return var4:NextInteger(var1, var2)
end

local var5 = require(var1.Modules.Client.Suffix)
local var6 = game:GetService("TweenService")
local var7 = require(var1.Framework.Client.Sound)
local var8 = require(var1.Modules.Shared.BigNum)
local var9 = require(var1.Framework.Client.Tween)
local var10 = game:GetService("Debris")
local var11 = var2.Stat.Get(var3, "PopUpsSetting")
local var12 = require(var1.Modules.Shared.StatInformation)
local function Drop(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
	for i1 = 1, arg1 do
		local var1 = script.Part:Clone()
		var1.CanQuery = false
		var1.Parent = workspace
		var1.Position = arg2 + (arg7 or Vector3.new(0, 0, 0))
		local num1 = -90
		local num2 = 90
		var1.LinearVelocity.VectorVelocity = vector.create(var4:NextInteger(-90, 90), math.random(110, 150), RandomInteger(num1, num2))
		var1.BillboardGui.Amount.Stat.CurrencyImage.Image = arg3
		if arg8 then
			var1.BillboardGui.Amount.Stat.Amount.Text = ("+%*"):format((var5.short(arg8)))
			var1.BillboardGui.Amount.Stat.Amount.Visible = true
		end

		var6:Create(var1.LinearVelocity, TweenInfo.new(0.2, Enum.EasingStyle.Linear), { MaxForce = 0 }):Play()
		task.spawn(function()
			task.wait(0.1)
			var1.CanCollide = true
			local var2 = arg6
			task.wait(var2 or var4:NextNumber(0.2, 0.5))
			if arg4 then
				local var11 = TweenInfo.new(0.2)
				local var12 = var6:Create(var1, var11, { CFrame = var3.Character:GetPivot() })
				var1.CanCollide = false
				local var13 = TweenInfo.new(0.5)
				var6:Create(var1.BillboardGui, var13, { Size = UDim2.fromScale(0, 0) }):Play()
				var12:Play()
				var12.Completed:Once(function()
					if var1 then
						var7.Play("Pop", var3.Character.HumanoidRootPart)
						var1:Destroy()
						if arg4 then
							if i1 == 1 then
								local var11 = workspace:FindFirstChild((("%*CurrencyDrop"):format(arg5)))
								var11 = var11 or script.Part:Clone()
								local var12 = var11:GetAttribute("Value") or 0
								var11.CanQuery = false
								var12 = var8.toString(var12)
								if not var11:GetAttribute("Tweened") then
									var11:SetAttribute("Tweened", true)
									var11.Parent = workspace
									var11.Name = ("%*CurrencyDrop"):format(arg5)
									var11.Anchored = true
									var11.Position = var3.Character.HumanoidRootPart.Position
									local var13 = TweenInfo.new(2, Enum.EasingStyle.Exponential)
									var6:Create(var11, var13, { Position = var11.Position + Vector3.new(0, 2, 0) }):Play()
									var11.BillboardGui.Amount.Stat.CurrencyImage.Image = arg3
									var11.BillboardGui.Amount.Stat.Amount.Visible = true
								else
									var9.Play(var11.BillboardGui.Amount.Stat.UIScale, TweenInfo.new(0.1), { Scale = 1.2 })
									task.delay(0.1, function()
										var9.Play(var11.BillboardGui.Amount.Stat.UIScale, TweenInfo.new(0.1), { Scale = 1 })
									end)

									var11.Position = var3.Character.HumanoidRootPart.Position + Vector3.new(0, 2, 0)
								end

								local var14 = var12
								local var15 = arg4
								var11:SetAttribute("Value", var8.toString(var8.add(var14, var15)))
								var11:SetAttribute("LastUpdate", os.clock())
								var15 = "Value"
								var11.BillboardGui.Amount.Stat.Amount.Text = ("+%*"):format((var5.short(var11:GetAttribute(var15))))
								task.wait(2.5)
								if 2.5 <= os.clock() - var11:GetAttribute("LastUpdate") then
									var11.Name = "part"
									var10:AddItem(var11, 0.8)
									var6:Create(var11.BillboardGui.Amount.Stat.Amount, TweenInfo.new(0.8), { TextTransparency = 1 }):Play()
									var6:Create(var11.BillboardGui.Amount.Stat.Amount.UIStroke, TweenInfo.new(0.8), { Transparency = 1 }):Play()
									var6:Create(var11.BillboardGui.Amount.Stat.CurrencyImage, TweenInfo.new(0.8), { ImageTransparency = 1 }):Play()
								end
							end
						end
					end
				end)

				return
			end

			var10:AddItem(var1, arg6 or 0.8)
			var6:Create(var1.BillboardGui.Amount.Stat.Amount, TweenInfo.new(0.8), { TextTransparency = 1 }):Play()
			var6:Create(var1.BillboardGui.Amount.Stat.Amount.UIStroke, TweenInfo.new(0.8), { Transparency = 1 }):Play()
			var6:Create(var1.BillboardGui.Amount.Stat.CurrencyImage, TweenInfo.new(0.8), { ImageTransparency = 1 }):Play()
		end)

	end
end

return function(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
	if not var11.Value then
		return
	end

	if not arg3 and (not var3.Character or (not var3.Character:FindFirstChild("HumanoidRootPart"))) then
		return
	end

	local var1 = arg3
	arg3 = var1 or var3.Character.HumanoidRootPart
	arg2 = arg2 or 10
	if not arg3:IsDescendantOf(workspace) then
		return
	end

	Drop(arg2, arg3:GetPivot().Position, var12[arg1].Icon, arg4, arg1, arg5, arg6, arg7)
end

--- ReplicatedStorage.Modules.Client.Suffix [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = game.Players.LocalPlayer
var2.Stat.WaitForLoad(var3)
local var4 = require(var1.Modules.Shared.BigNum)
local var5 = var2.Stat.GetDataFolder(var3).Settings
return { short = function(arg1)
	local var1 = var2.Stat.Get(var3, "ScientificNotation")
	if var4.toString(arg1) == "0" then
		return "0"
	end

	if var1.Value then
		local var6 = arg1
		return var4.toScientific(var6)
	end

	local var7 = arg1
	return var4.toSuffix(var7)
end }

--- ReplicatedStorage.Modules.Client.RubyTopUp [ModuleScript]
-- y u r i

local var1 = game:GetService("MarketplaceService")
local var2 = game:GetService("Players").LocalPlayer
local tbl1 = {}
for k1, v1 in require(game:GetService("ReplicatedStorage").Modules.Shared.Robux).Products, nil do
	if v1.Type ~= "Ruby" then
		continue
	end

	table.insert(tbl1, { Id = k1, Reward = v1.Reward })
end

table.sort(tbl1, function(arg1, arg2)
	return arg1.Reward < arg2.Reward
end)

local tbl2 = { PackFor = function(arg1)
	if #tbl1 == 0 then
		return nil
	end

	for k1, v1 in tbl1, nil do
		if arg1 > v1.Reward then
			continue
		end

		return v1
	end

	return tbl1[#tbl1]
end }

local num1 = 0
tbl2.Prompt = function(arg1)
	if arg1 <= 0 then
		return false
	end

	local var4 = tbl2.PackFor(arg1)
	if not var4 then
		warn("[RubyTopUp] no Ruby products in Shared.Robux to offer")
		return false
	end

	if os.clock() - num1 < 2 then
		return false
	end

	num1 = os.clock()
	var1:PromptProductPurchase(var2, var4.Id)
	return true
end

return tbl2

--- ReplicatedStorage.Modules.Client.Lighting [ModuleScript]
-- y u r i

local var1 = game:GetService("Lighting")
local tbl1 = { TimeOfDay = "14:00:00", Ambient = Color3.fromRGB(132, 110, 189), Brightness = 1 }
tbl1.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl1.ColorShift_Top = Color3.fromRGB(28, 71, 189)
tbl1.OutdoorAmbient = Color3.fromRGB(132, 59, 156)
local tbl2 = { Day = tbl1 }
tbl1 = { TimeOfDay = "22:00:00", Ambient = Color3.fromRGB(103, 155, 189), Brightness = 2 }
tbl1.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
tbl1.ColorShift_Top = Color3.fromRGB(28, 71, 189)
tbl1.OutdoorAmbient = Color3.fromRGB(130, 26, 156)
tbl2.Night = tbl1
return {
	Modes = tbl2,
	SetMode = function(arg1)
		local var2 = tbl2
		for k1, v1 in var2[arg1 or "Day"], nil do
			var1[k1] = v1
		end
	end,
}

--- ReplicatedStorage.Modules.Shared.Multipliers [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = game:GetService("Players")
local var4 = require(var1.Framework)
local var5 = require(var2.BigNum)
local var6 = require(var2.Seeds)
local var7 = require(var2.UpgradeTree)
local var8 = require(var2.DailyUpgrades)
local var9 = require(var2.Upgrades)
local var10 = require(var2.Water)
local var11 = require(var2.Tree)
local var12 = require(var2.Harvest)
local var13 = require(var2.Pets)
local var14 = require(var2.Research)
local var15 = require(var2.ResearchBoosts)
local var16 = require(var2.ResearchUpgrades)
local var17 = require(var2.Replant)
local var18 = require(var2.Bank)
local var19 = require(var2.LabBoosts)
local var20 = require(var2.LabUpgrades)
local var21 = require(var2.Scientists)
local var22 = require(var2.Leaves)
local var23 = require(var2.LeafUpgrades)
local function GetBankBoost(arg1, arg2, arg3, arg4)
	local var1 = var18.Rewards[arg2]
	local var2 = var1
	var2 = var2 and var1[arg3]
	if not var2 then
		return 1
	end

	local var4 = arg4.Stats[var18.DepositStat]
	local var6 = if var2.Add then 0 else 1
	if not var4 then
		return var6
	end

	if var5.lt(var4.Value, var18.Prices[arg2] or 0) then
		return var6
	end

	if var2.Type == "Function" then
		return (var2.Reward(arg1))
	end

	return var2.Reward
end

local tbl1 = {
	DailyStreakMultiplier = function(arg1)
		return (math.min(2, 1 + var4.Stat.Get(arg1, "DailyStreak").Value * 0.05))
	end,
	GetPlayerSpeed = function(arg1)
		local var1 = var4.Stat.GetDataFolder(arg1)
		local var3 = var12.Rewards[1].Walkspeed
		local var5 = 16 + var8.Upgrades.DailyMoreWalkspeed.Info(var1.DailyUpgrades.DailyMoreWalkspeed.Value).Reward + var7.TreeMoreWalkspeed.Reward(arg1) + var7.TreeMoreWalkspeed2.Reward(arg1) + var7.TreeMoreWalkspeed3.Reward(arg1)
		local var6 = var4.Stat.Get(arg1, "MoreWalkspeedGamepass")
		local var9
		if not var3 then
			var9 = 1
		else
			local var10 = var1.Stats.Harvest
			local var11 = if var3.Add then 0 else 1
			if var10.Value < 1 then
				var9 = var11
			else
				var9 = if var3.Type == "Function" then var3.Reward(arg1) else var3.Reward
			end
		end

		var5 = var5 + var9
		var5 = var5 + var16.ResearchMoreWalkspeed.Reward(arg1)
		if var6.Value then
			var5 = var5 + 15
		end

		return var5
	end,
	GetCollectibleCooldown = function(arg1)
		local var1 = var4.Stat.GetDataFolder(arg1)
		local var2 = 1 - var7.TreeFasterSpawn.Reward(arg1) - var9.Soil.Upgrades.SoilFasterSpawn.Info(var1.SoilUpgrades.SoilFasterSpawn.Value).Reward - var9.Water.Upgrades.WaterFasterSpawn.Info(var1.WaterUpgrades.WaterFasterSpawn.Value).Reward
		if var4.Stat.Get(arg1, "MoreSpawnSpeedGamepass").Value then
			var2 = var2 / 1.5
		end

		local var5 = var12.Rewards[1].SpawnRate
		local var6
		if not var5 then
			var6 = 1
		else
			local var8 = var1.Stats.Harvest
			local var10 = if var5.Add then 0 else 1
			if var8.Value < 1 then
				var6 = var10
			else
				var6 = if var5.Type == "Function" then var5.Reward(arg1) else var5.Reward
			end
		end

		return var2 / var6
	end,
	GetCollectionRange = function(arg1)
		local var1 = var4.Stat.GetDataFolder(arg1)
		return 4 + var8.Upgrades.DailyMoreRange.Info(var1.DailyUpgrades.DailyMoreRange.Value).Reward + var7.TreeMoreRange.Reward(arg1) + var7.TreeMoreRange2.Reward(arg1) + var7.TreeMoreRange3.Reward(arg1) + GetBankBoost(arg1, 1, "Range", var1)
	end,
	GetSpawnBulk = function(arg1)
		local num1 = 1
		local var2 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 3 then nil else var21[3].Boosts.Bulk.Reward
		if var2 then
			num1 = num1 + var2
		end

		return num1
	end,
	GetCollectibleCap = function(arg1)
		local var1 = var4.Stat.GetDataFolder(arg1)
		local var3 = var12.Rewards[2].SpawnLimit
		local var5 = 5 + var8.Upgrades.DailyMoreCap.Info(var1.DailyUpgrades.DailyMoreCap.Value).Reward + var7.TreeMoreCap.Reward(arg1) + var7.TreeMoreCap2.Reward(arg1)
		local var6 = var4.Stat.Get(arg1, "MoreSpawnLimitGamepass")
		local var9
		if not var3 then
			var9 = 1
		else
			local var10 = var1.Stats.Harvest
			local var11 = if var3.Add then 0 else 1
			if var10.Value < 2 then
				var9 = var11
			else
				var9 = if var3.Type == "Function" then var3.Reward(arg1) else var3.Reward
			end
		end

		var5 = var5 + var9
		var5 = var5 + var16.ResearchMoreCap.Reward(arg1) + GetBankBoost(arg1, 5, "Cap", var1)
		if var6.Value then
			var5 = var5 + 25
		end

		return var5
	end,
	GetComboIncrement = function(arg1)
		local var2 = var17.Rewards[3].Combo
		local var3 = var4.Stat.GetDataFolder(arg1)
		local var5 = 0.001 + var7.TreeBetterCombo.Reward(arg1) + var7.TreeBetterCombo2.Reward(arg1)
		local var6
		if not var2 then
			var6 = 1
		else
			local var8 = var3.Stats.Replant
			local var9 = if var2.Add then 0 else 1
			if var8.Value < 3 then
				var6 = var9
			else
				var6 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
			end
		end

		var5 = var5 * var6
		return var5 * (1 + var20.LabBetterCombo.Reward(arg1) / 100)
	end,
	GetComboDecayDelay = function(_)
		return 3
	end,
	GetMaxComboMulti = function(arg1)
		var4.Stat.GetDataFolder(arg1)
		return 2 + var7.TreeMoreComboLimit.Reward(arg1) + var20.LabHigherComboLimit.Reward(arg1)
	end,
	GetChoppingSpeed = function(arg1)
		local var2 = var12.Rewards[3].ChoppingSpeed
		local var3 = var4.Stat.GetDataFolder(arg1)
		local num1 = 0.5
		local var5 = var4.Stat.Get(arg1, "FasterChoppingSpeedGamepass")
		local var6
		if not var2 then
			var6 = 1
		else
			local var7 = var3.Stats.Harvest
			local var8 = if var2.Add then 0 else 1
			if var7.Value < 3 then
				var6 = var8
			else
				var6 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
			end
		end

		num1 = num1 / var6
		if var5.Value then
			num1 = num1 / 1.5
		end

		return (math.max(num1, 0.1))
	end,
	GetCritChance = function(_)
		return 5
	end,
	GetCritMultiplier = function(_)
		return 3
	end,
	GetSoilConversion = function(arg1)
		local var1 = var4.Stat.Get(arg1, "Cash").Value
		local num1 = 1e-05
		return var5.floor(var5.mul(var1, num1))
	end,
}

local function GetUpgradeTreeBoost(arg1, arg2)
	local var1 = arg1
	return var7[arg2].Reward(var1)
end

local function GetResearchBoosts(arg1, arg2)
	local var1 = arg1
	return var15[arg2].Reward(var1)
end

local function GetLabBoosts(arg1, arg2)
	local var1 = arg1
	return var19[arg2].Reward(var1)
end

tbl1.GetCashMultiplier = function(arg1, arg2)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local num1 = 1
	local var2 = var4.Stat.Get(arg1, "Seed").Value
	local var3 = var4.Stat.Get(arg1, "x2CashBoost")
	local var7 = arg1
	local var10 = var5.mul(num1, tbl1.DailyStreakMultiplier(var7))
	var7 = arg1
	var10 = var5.mul(var5.mul(var10, var6.Types[arg2].Multiplier), var6.Seeds[var2].Reward(var7))
	var7 = arg1
	local str1 = "TreeMoreCash"
	var10 = var5.mul(var5.mul(var10, var6.Seeds[var2].Multiplier), GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash2"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash3"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash4"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash5"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash6"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash7"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash8"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash9"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash11"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = arg1
	str1 = "TreeMoreCash12"
	var10 = var5.mul(var10, GetUpgradeTreeBoost(var7, str1))
	var7 = var12.Rewards[1].AllStatsBoost
	local var11 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 3 then nil else var21[3].Boosts.Cash.Reward
	local var13 = var5.mul
	var10 = var5.mul(var5.mul(var5.mul(var10, var9.Soil.Upgrades.SoilMoreCash.Info(var1.SoilUpgrades.SoilMoreCash.Value).Reward), var9.Water.Upgrades.WaterMoreCash.Info(var1.WaterUpgrades.WaterMoreCash.Value).Reward), var9.Wood.Upgrades.WoodMoreCash.Info(var1.WoodUpgrades.WoodMoreCash.Value).Reward)
	local var14
	if not var7 then
		var14 = 1
	else
		str1 = var1.Stats.Harvest
		local var15 = if var7.Add then 0 else 1
		if str1.Value < 1 then
			var14 = var15
		else
			var14 = if var7.Type == "Function" then var7.Reward(arg1) else var7.Reward
		end
	end

	num1 = var13(var10, var14)
	var7 = var12.Rewards[2].Cash
	var13 = var5.mul
	var10 = num1
	if not var7 then
		var14 = 1
	else
		str1 = var1.Stats.Harvest
		local var16 = if var7.Add then 0 else 1
		if str1.Value < 2 then
			var14 = var16
		else
			var14 = if var7.Type == "Function" then var7.Reward(arg1) else var7.Reward
		end
	end

	num1 = var13(var10, var14)
	var7 = arg1
	str1 = "LeafMoreCash"
	var10 = var5.mul(var5.mul(num1, var9.Grass.Upgrades.GrassMoreCash.Info(var1.GrassUpgrades.GrassMoreCash.Value).Reward), var23.GetBoost(var7, str1))
	var7 = arg1
	str1 = "ResearchMoreCash"
	var10 = var5.mul(var10, GetResearchBoosts(var7, str1))
	var7 = arg1
	str1 = "LabMoreCash"
	var10 = var5.mul(var10, GetLabBoosts(var7, str1))
	var7 = var17.Rewards[1].Cash
	var13 = var5.mul
	if not var7 then
		var14 = 1
	else
		str1 = var1.Stats.Replant
		local var18 = if var7.Add then 0 else 1
		if str1.Value < 1 then
			var14 = var18
		else
			var14 = if var7.Type == "Function" then var7.Reward(arg1) else var7.Reward
		end
	end

	num1 = var13(var10, var14)
	var7 = var17.Rewards[4].Cash
	var13 = var5.mul
	var10 = num1
	if not var7 then
		var14 = 1
	else
		str1 = var1.Stats.Replant
		local var19 = if var7.Add then 0 else 1
		if str1.Value < 4 then
			var14 = var19
		else
			var14 = if var7.Type == "Function" then var7.Reward(arg1) else var7.Reward
		end
	end

	num1 = var13(var10, var14)
	var7 = var17.Rewards[5].Cash
	var13 = var5.mul
	var10 = num1
	if not var7 then
		var14 = 1
	else
		str1 = var1.Stats.Replant
		local var20 = if var7.Add then 0 else 1
		if str1.Value < 5 then
			var14 = var20
		else
			var14 = if var7.Type == "Function" then var7.Reward(arg1) else var7.Reward
		end
	end

	num1 = var13(var10, var14)
	num1 = var5.mul(var5.mul(var5.mul(num1, (GetBankBoost(arg1, 1, "Cash", var1))), var8.Upgrades.DailyMoreCash.Info(var1.DailyUpgrades.DailyMoreCash.Value).Reward), 2 ^ var4.Stat.Get(arg1, "ExtraCashTier").Value)
	if var11 then
		num1 = var5.mul(num1, var11)
	end

	if 1 <= var3.Value then
		num1 = var5.mul(num1, 2)
	end

	return (var5.mul(num1, var4.Stat.Get(arg1, "ComboMultiplier").Value))
end

tbl1.GetSoilMultiplier = function(arg1)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var2 = arg1
	local str1 = "TreeMoreSoil"
	local var3 = var5.mul(var5.mul(1, var9.Soil.Upgrades.SoilMoreSoil.Info(var1.SoilUpgrades.SoilMoreSoil.Value).Reward), GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreSoil2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = var12.Rewards[1].AllStatsBoost
	local var6 = var5.mul
	local var7
	if not var2 then
		var7 = 1
	else
		str1 = var1.Stats.Harvest
		local var10 = if var2.Add then 0 else 1
		if str1.Value < 1 then
			var7 = var10
		else
			var7 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	local var11 = var6(var3, var7)
	var2 = arg1
	str1 = "ResearchMoreSoil"
	var3 = var5.mul(var11, GetResearchBoosts(var2, str1))
	return (var5.mul(var5.mul(var3, (GetBankBoost(arg1, 2, "Soil", var1))), var8.Upgrades.DailyMoreSoil.Info(var1.DailyUpgrades.DailyMoreSoil.Value).Reward))
end

tbl1.GetWaterMultiplier = function(arg1)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var2 = var1
	local var3 = var5.mul(1, var10.Multiplier(var2))
	var2 = arg1
	local str1 = "TreeMoreWater"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWater2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWater3"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWater4"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWater5"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWater6"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = var12.Rewards[1].AllStatsBoost
	local var6 = var5.mul
	var3 = var5.mul(var5.mul(var3, var9.Wood.Upgrades.WoodMoreWater.Info(var1.WoodUpgrades.WoodMoreWater.Value).Reward), var9.Grass.Upgrades.GrassMoreWater.Info(var1.GrassUpgrades.GrassMoreWater.Value).Reward)
	local var7
	if not var2 then
		var7 = 1
	else
		str1 = var1.Stats.Harvest
		local var11 = if var2.Add then 0 else 1
		if str1.Value < 1 then
			var7 = var11
		else
			var7 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	local var13 = var6(var3, var7)
	var2 = arg1
	str1 = "ResearchMoreWater"
	var3 = var5.mul(var13, GetResearchBoosts(var2, str1))
	var2 = var17.Rewards[5].Water
	var6 = var5.mul
	var3 = var5.mul(var3, (GetBankBoost(arg1, 4, "Water", var1)))
	if not var2 then
		var7 = 1
	else
		str1 = var1.Stats.Replant
		local var14 = if var2.Add then 0 else 1
		if str1.Value < 5 then
			var7 = var14
		else
			var7 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	var13 = var6(var3, var7)
	return (var5.mul(var5.mul(var13, var8.Upgrades.DailyMoreWater.Info(var1.DailyUpgrades.DailyMoreWater.Value).Reward), 2 ^ var4.Stat.Get(arg1, "ExtraWaterTier").Value))
end

tbl1.GetWaterXPMultiplier = function(arg1)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var2 = arg1
	local str1 = "TreeMoreXP"
	local var3 = var5.mul(var5.mul(1, var9.Water.Upgrades.WaterMoreXP.Info(var1.WaterUpgrades.WaterMoreXP.Value).Reward), GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreXP2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreXP3"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreXP4"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = var12.Rewards[1].AllStatsBoost
	local var6 = var4.Stat.Get(arg1, "MoreXPGamepass")
	local var7 = var5.mul
	local var8
	if not var2 then
		var8 = 1
	else
		str1 = var1.Stats.Harvest
		local var10 = if var2.Add then 0 else 1
		if str1.Value < 1 then
			var8 = var10
		else
			var8 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	local var11 = var7(var3, var8)
	var2 = var12.Rewards[3].XP
	var7 = var5.mul
	var3 = var11
	if not var2 then
		var8 = 1
	else
		str1 = var1.Stats.Harvest
		local var13 = if var2.Add then 0 else 1
		if str1.Value < 3 then
			var8 = var13
		else
			var8 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	var11 = var7(var3, var8)
	var2 = arg1
	str1 = "LabMoreXP"
	var3 = var5.mul(var11, GetLabBoosts(var2, str1))
	var11 = var5.mul(var3, (GetBankBoost(arg1, 3, "XP", var1)))
	if var6.Value then
		var11 = var5.mul(var11, 2)
	end

	return var11
end

tbl1.TreeComboMultiplierCap = function(_)
	return 2
end

tbl1.GetWoodMultiplier = function(arg1)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var2 = var1
	local var3 = var5.mul(1, var11.Multiplier(var2))
	var2 = arg1
	local str1 = "TreeMoreWood"
	var3 = var5.mul(var5.mul(var3, var9.Wood.Upgrades.WoodMoreWood.Info(var1.WoodUpgrades.WoodMoreWood.Value).Reward), GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreWood2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = var12.Rewards[1].AllStatsBoost
	local var6 = var5.mul
	local var7
	if not var2 then
		var7 = 1
	else
		str1 = var1.Stats.Harvest
		local var10 = if var2.Add then 0 else 1
		if str1.Value < 1 then
			var7 = var10
		else
			var7 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	local var13 = var6(var3, var7)
	var2 = var12.Rewards[3].Wood
	var6 = var5.mul
	var3 = var13
	if not var2 then
		var7 = 1
	else
		str1 = var1.Stats.Harvest
		local var14 = if var2.Add then 0 else 1
		if str1.Value < 3 then
			var7 = var14
		else
			var7 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	var13 = var6(var3, var7)
	var2 = arg1
	str1 = "ResearchMoreWood"
	var3 = var5.mul(var13, GetResearchBoosts(var2, str1))
	return (var5.mul(var5.mul(var5.mul(var3, (GetBankBoost(arg1, 4, "Wood", var1))), var8.Upgrades.DailyMoreWood.Info(var1.DailyUpgrades.DailyMoreWood.Value).Reward), 2 ^ var4.Stat.Get(arg1, "ExtraWoodTier").Value))
end

tbl1.GetGrassMultiplier = function(arg1)
	local var1 = var4.Stat.GetDataFolder(arg1)
	local num1 = 1
	local var2 = var4.Stat.Get(arg1, "Pet").Value
	local var3 = arg1
	local var6 = var5.mul(num1, var13[var2].Reward(var3))
	var3 = arg1
	local str1 = "LeafMoreGrass"
	var6 = var5.mul(var5.mul(var5.mul(var6, var13[var2].Multiplier), var9.Grass.Upgrades.GrassMoreGrass.Info(var1.GrassUpgrades.GrassMoreGrass.Value).Reward), var23.GetBoost(var3, str1))
	var3 = arg1
	str1 = "TreeMoreGrass"
	var6 = var5.mul(var6, GetUpgradeTreeBoost(var3, str1))
	var3 = arg1
	str1 = "TreeMoreGrass2"
	var6 = var5.mul(var6, GetUpgradeTreeBoost(var3, str1))
	var3 = arg1
	str1 = "TreeMoreGrass3"
	var6 = var5.mul(var6, GetUpgradeTreeBoost(var3, str1))
	var3 = arg1
	str1 = "TreeMoreGrass4"
	var6 = var5.mul(var6, GetUpgradeTreeBoost(var3, str1))
	var3 = arg1
	str1 = "TreeMoreGrass5"
	var6 = var5.mul(var6, GetUpgradeTreeBoost(var3, str1))
	var3 = arg1
	str1 = "ResearchMoreGrass"
	var6 = var5.mul(var6, GetResearchBoosts(var3, str1))
	var3 = arg1
	str1 = "LabMoreGrass"
	var6 = var5.mul(var6, GetLabBoosts(var3, str1))
	var3 = var17.Rewards[1].Grass
	local var7 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 3 then nil else var21[3].Boosts.Grass.Reward
	local var10 = var4.Stat.Get(arg1, "MoreGrassGamepass")
	local var11 = var5.mul
	local var12
	if not var3 then
		var12 = 1
	else
		str1 = var1.Stats.Replant
		local var14 = if var3.Add then 0 else 1
		if str1.Value < 1 then
			var12 = var14
		else
			var12 = if var3.Type == "Function" then var3.Reward(arg1) else var3.Reward
		end
	end

	num1 = var11(var6, var12)
	var3 = var17.Rewards[4].Grass
	var11 = var5.mul
	var6 = num1
	if not var3 then
		var12 = 1
	else
		str1 = var1.Stats.Replant
		local var15 = if var3.Add then 0 else 1
		if str1.Value < 4 then
			var12 = var15
		else
			var12 = if var3.Type == "Function" then var3.Reward(arg1) else var3.Reward
		end
	end

	num1 = var11(var6, var12)
	var3 = var17.Rewards[5].Grass
	var11 = var5.mul
	var6 = num1
	if not var3 then
		var12 = 1
	else
		str1 = var1.Stats.Replant
		local var16 = if var3.Add then 0 else 1
		if str1.Value < 5 then
			var12 = var16
		else
			var12 = if var3.Type == "Function" then var3.Reward(arg1) else var3.Reward
		end
	end

	num1 = var11(var6, var12)
	num1 = var5.mul(var5.mul(var5.mul(num1, (GetBankBoost(arg1, 5, "Grass", var1))), var8.Upgrades.DailyMoreGrass.Info(var1.DailyUpgrades.DailyMoreGrass.Value).Reward), 2 ^ var4.Stat.Get(arg1, "ExtraGrassTier").Value)
	if var10.Value then
		num1 = var5.mul(num1, 2)
	end

	if var7 then
		num1 = var5.mul(num1, var7)
	end

	return num1
end

tbl1.GetGrassCooldown = function(arg1)
	return 1 - var16.ResearchFasterGrass.Reward(arg1)
end

tbl1.GetGrassResumeDelay = function(_)
	return 1
end

tbl1.GetPetClickCooldown = function(_)
	return 0.2
end

tbl1.GetPaperCooldown = function(arg1)
	return 1 - var16.ResearchFasterPaper.Reward(arg1)
end

tbl1.GetPaperMultiplier = function(arg1)
	local num1 = 1
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var2 = arg1
	local var3 = var5.mul(num1, var14.Boost(var2))
	var2 = arg1
	local str1 = "TreeMorePaper"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper3"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper4"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper5"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper6"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMorePaper7"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = var17.Rewards[1].Paper
	local var6 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 1 then nil else var21[1].Boosts.Paper.Reward
	local var7 = var5.mul
	local var9
	if not var2 then
		var9 = 1
	else
		str1 = var1.Stats.Replant
		local var10 = if var2.Add then 0 else 1
		if str1.Value < 1 then
			var9 = var10
		else
			var9 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	num1 = var7(var3, var9)
	var2 = var17.Rewards[4].Paper
	var7 = var5.mul
	var3 = num1
	if not var2 then
		var9 = 1
	else
		str1 = var1.Stats.Replant
		local var11 = if var2.Add then 0 else 1
		if str1.Value < 4 then
			var9 = var11
		else
			var9 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	num1 = var7(var3, var9)
	var2 = var17.Rewards[5].Paper
	var7 = var5.mul
	var3 = num1
	if not var2 then
		var9 = 1
	else
		str1 = var1.Stats.Replant
		local var12 = if var2.Add then 0 else 1
		if str1.Value < 5 then
			var9 = var12
		else
			var9 = if var2.Type == "Function" then var2.Reward(arg1) else var2.Reward
		end
	end

	num1 = var7(var3, var9)
	var2 = arg1
	str1 = "ResearchMorePaper"
	var3 = var5.mul(num1, GetResearchBoosts(var2, str1))
	var2 = arg1
	str1 = "LabMorePaper"
	var3 = var5.mul(var3, GetLabBoosts(var2, str1))
	num1 = var5.mul(var5.mul(var5.mul(var3, var8.Upgrades.DailyMorePaper.Info(var1.DailyUpgrades.DailyMorePaper.Value).Reward), 2 ^ var4.Stat.Get(arg1, "ExtraPaperTier").Value), (GetBankBoost(arg1, 6, "Paper", var1)))
	if var6 then
		num1 = var5.mul(num1, var6)
	end

	return num1
end

tbl1.GetLabResearchSlots = function(arg1)
	local num1 = 1
	local var2 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 2 then nil else var21[2].Boosts.ResearchSlots.Reward
	if var2 then
		num1 = num1 + var2
	end

	return num1 + var20.LabMoreSlots.Reward(arg1)
end

tbl1.GetLabResearchSpeed = function(arg1)
	local num1 = 1
	local var1 = var4.Stat.GetDataFolder(arg1)
	local var3 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 2 then nil else var21[2].Boosts.FasterResearch.Reward
	local var5 = var4.Stat.Get(arg1, "MoreResearchSpeedGamepass")
	if var3 then
		num1 = num1 * var3
	end

	local var9 = var17.Rewards[4].Research
	num1 = num1 * var16.ResearchFasterResearch.Reward(arg1) * var7.TreeFasterResearch.Reward(arg1) * var7.TreeFasterResearch2.Reward(arg1) * var7.TreeFasterResearch3.Reward(arg1) * var7.TreeFasterResearch4.Reward(arg1)
	local var10
	if not var9 then
		var10 = 1
	else
		local var11 = var1.Stats.Replant
		local var12 = if var9.Add then 0 else 1
		if var11.Value < 4 then
			var10 = var12
		else
			var10 = if var9.Type == "Function" then var9.Reward(arg1) else var9.Reward
		end
	end

	num1 = num1 * var10
	num1 = num1 * GetBankBoost(arg1, 7, "LabSpeed", var1) * var8.Upgrades.DailyMoreResearchSpeed.Info(var1.DailyUpgrades.DailyMoreResearchSpeed.Value).Reward
	if var5.Value then
		num1 = num1 * 2
	end

	return num1
end

tbl1.GetLeafMultiplier = function(arg1)
	local var1 = var5.mul(var22.Reward(arg1), var8.Upgrades.DailyMoreLeaves.Info(var4.Stat.GetDataFolder(arg1).DailyUpgrades.DailyMoreLeaves.Value).Reward)
	local var2 = arg1
	local str1 = "LeafMoreLeaves"
	local var3 = var5.mul(var1, var23.GetBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreLeaves"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreLeaves2"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "TreeMoreLeaves3"
	var3 = var5.mul(var3, GetUpgradeTreeBoost(var2, str1))
	var2 = arg1
	str1 = "LabMoreLeaves"
	local var7 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 4 then nil else var21[4].Boosts.Leaves.Reward
	var1 = var5.mul(var3, GetLabBoosts(var2, str1))
	if var7 then
		var1 = var5.mul(var1, var7)
	end

	return var1
end

tbl1.GetLeafClickRadius = function(arg1)
	local num1 = 0
	local var2 = if var4.Stat.Get(arg1, "EquippedScientist").Value ~= 4 then nil else var21[4].Boosts.ClickRadius.Reward
	num1 = num1 + var7.TreeBetterLeafCollect.Reward(arg1) + var7.TreeBetterLeafCollect2.Reward(arg1)
	if var2 then
		num1 = num1 + var2
	end

	return num1
end

tbl1.CanHoverCollectLeaves = function(_)
	return false
end

tbl1.GetLeafHoverRadius = function(_)
	return 0
end

return tbl1

--- ReplicatedStorage.Modules.Shared.BigNum [ModuleScript]
-- y u r i

local tbl1 = {
	POW_ZERO = { 0, 0 },
	precision = 5,
	display_precision = 2,
	ZERO = { 0, 0 },
	NAN = { -2, 0 },
}

tbl1.fromNumber = function(arg1)
	if type(arg1) ~= "number" then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg1 == 0 then
		local var4 = tbl1.ZERO
		return table.clone(var4)
	end

	if arg1 ~= arg1 then
		local var6 = tbl1.NAN
		return table.clone(var6)
	end

	return { math.sign(arg1), (math.log10((math.abs(arg1)))) }
end

local var1 = 10 ^ tbl1.precision
tbl1.toNumber = function(arg1)
	if arg1[1] == -2 then
		return 0/0
	end

	local var3 = arg1[1] * 10 ^ arg1[2]
	if var3 < 4503599627370496 then
		return math.round(var3 * var1) / var1
	end

	return var3
end

tbl1.fromString = function(arg1)
	local var2 = string.find(arg1, "e")
	if var2 then
		local var5 = tonumber((string.sub(arg1, 1, var2 - 1)))
		local var6 = tonumber((string.sub(arg1, var2 + 1, -1)))
		if var5 ~= var5 or var5 == nil then
			local var7 = tbl1.NAN
			return table.clone(var7)
		end

		if var6 ~= var6 or var6 == nil then
			local var9 = tbl1.NAN
			return table.clone(var9)
		end

		if var5 == 0 then
			local var11 = tbl1.ZERO
			return table.clone(var11)
		end

		return { math.sign(var5), math.log10((math.abs(var5))) + var6 }
	end

	if string.find(arg1, ";") then
		local var13 = string.find(arg1, ";")
		local var16 = tonumber((string.sub(arg1, 1, var13 - 1)))
		local var17 = tonumber((string.sub(arg1, var13 + 1, -1)))
		if var16 ~= var16 or var16 == nil then
			local var18 = tbl1.NAN
			return table.clone(var18)
		end

		if var17 ~= var17 or var17 == nil then
			local var20 = tbl1.NAN
			return table.clone(var20)
		end

		if var16 == 0 then
			local var22 = var17
			return tbl1.fromNumber(var22)
		end

		if math.abs(var16) == 1 then
			return { math.sign(var16), var17 }
		end

		return { math.sign(var16), math.huge }
	end

	if string.lower(arg1) == "inf" then
		return { 1, math.huge }
	end

	local var25 = tonumber(arg1)
	if var25 ~= var25 or var25 == nil then
		local var26 = tbl1.NAN
		return table.clone(var26)
	end

	if var25 == 0 then
		local var28 = tbl1.ZERO
		return table.clone(var28)
	end

	return { math.sign(var25), (math.log10((math.abs(var25)))) }
end

tbl1.toString = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == 0 then
		return "0e0"
	end

	if arg1[1] == -2 then
		return "NaN"
	end

	if arg1[2] == math.huge then
		return (if arg1[1] == -1 then "-" else "") .. "inf"
	end

	if arg1[2] < 13 then
		local var1 = 10 ^ arg1[2]
		local var2 = 10 ^ (12 - math.floor((math.log10(var1))))
		local var3 = math.round(var1 * var2) / var2
		return (if arg1[1] == -1 then "-" else "") .. tostring(var3)
	end

	local var4 = math.floor(arg1[2])
	local var5 = 10 ^ (arg1[2] - var4)
	return (if arg1[1] == -1 then "-" else "") .. var5 .. "e" .. var4
end

tbl1.add = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg1[1] == 0 then
		local var4 = arg2
		return table.clone(var4)
	end

	if arg2[1] == 0 then
		local var6 = arg1
		return table.clone(var6)
	end

	local var9 = arg1[2] - arg2[2]
	if 16 < var9 then
		local var10 = arg1
		return table.clone(var10)
	end

	if var9 < -16 then
		local var12 = arg2
		return table.clone(var12)
	end

	if var9 == 0 and arg1[1] ~= arg2[1] then
		local var14 = tbl1.ZERO
		return table.clone(var14)
	end

	if arg1[1] == arg2[1] then
		return { arg1[1], math.log10(10 ^ var9 + 1) + arg2[2] }
	end

	if 0 <= var9 then
		return { arg1[1], arg1[2] + math.log10(1 - 10 ^ (-var9)) }
	end

	return { -arg1[1], arg2[2] + math.log10(1 - 10 ^ var9) }
end

tbl1.sub = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg1[1] == 0 then
		local var4 = arg2
		return table.clone(var4)
	end

	if arg2[1] == 0 then
		local var6 = arg1
		return table.clone(var6)
	end

	local var9 = arg1[2] - arg2[2]
	if 16 < var9 then
		local var10 = arg1
		return table.clone(var10)
	end

	if var9 < -16 then
		local var12 = arg2
		return table.clone(var12)
	end

	if var9 == 0 and arg1[1] == arg2[1] then
		local var14 = tbl1.ZERO
		return table.clone(var14)
	end

	if arg1[1] == arg2[1] then
		if 0 <= var9 then
			return { arg1[1], arg1[2] + math.log10(1 - 10 ^ (-var9)) }
		end

		return { -arg1[1], arg2[2] + math.log10(1 - 10 ^ var9) }
	end

	return { arg1[1], math.log10(10 ^ var9 + 1) + arg2[2] }
end

tbl1.mul = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { arg1[1] * arg2[1], arg1[2] + arg2[2] }
end

tbl1.div = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg2[1] == 0 then
		local var4 = tbl1.NAN
		return table.clone(var4)
	end

	return { arg1[1] * arg2[1], arg1[2] - arg2[2] }
end

tbl1.intdiv = function(arg1, arg2)
	local var1 = arg1
	local var2 = arg2
	return tbl1.floor(tbl1.div(var1, var2))
end

tbl1.pow = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg1[1] == 0 then
		if arg2[1] == 0 then
			local var5 = tbl1.POW_ZERO
			return table.clone(var5)
		end

		local var6 = tbl1.ZERO
		return table.clone(var6)
	end

	if arg1[1] == -1 then
		return { if tbl1.toNumber(arg2) % 2 == 1 then -1 else 1, arg1[2] * 10 ^ arg2[2] * arg2[1] }
	end

	return { 1, arg1[2] * 10 ^ arg2[2] * arg2[1] }
end

tbl1.powf = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] ~= 1 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg2 == 0 then
		return { 0, 0 }
	end

	if arg2 == 1 then
		return { 1, 0 }
	end

	return { 1, arg1[2] * arg2 }
end

tbl1.pow10 = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { 1, arg1[1] * 10 ^ arg1[2] }
end

tbl1.sqrt = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] < 0 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg1[1] == 0 then
		local var4 = tbl1.ZERO
		return table.clone(var4)
	end

	return { 1, 0.5 * arg1[2] }
end

tbl1.root = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if arg2[2] == 0 or arg1[1] < 0 then
		local var4 = tbl1.NAN
		return table.clone(var4)
	end

	if arg1[1] == 0 then
		local var6 = tbl1.ZERO
		return table.clone(var6)
	end

	return { 1, 1 / tbl1.toNumber(arg2) * arg1[2] }
end

tbl1.cmp = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] ~= arg2[1] then
		if arg2[1] < arg1[1] then
			return 1
		end

		return -1
	end

	if math.abs(arg1[2] - arg2[2]) <= 1e-07 then
		if arg1[1] ~= -2 then
			return 0
		end

		return -1
	end

	if arg2[2] < arg1[2] then
		return arg1[1]
	end

	if arg1[2] < arg2[2] then
		return -1 * arg1[1]
	end

	if arg1[1] ~= -2 then
		return 0
	end

	return -1
end

tbl1.eq = function(arg1, arg2)
	return tbl1.cmp(arg1, arg2) == 0
end

tbl1.lt = function(arg1, arg2)
	return tbl1.cmp(arg1, arg2) == -1
end

tbl1.gt = function(arg1, arg2)
	return tbl1.cmp(arg1, arg2) == 1
end

tbl1.lte = function(arg1, arg2)
	return tbl1.cmp(arg1, arg2) ~= 1
end

tbl1.gte = function(arg1, arg2)
	return tbl1.cmp(arg1, arg2) ~= -1
end

tbl1.isBigNum = function(arg1)
	local bool2 = false
	if type(arg1) == "table" then
		bool2 = false
		if type(arg1[1]) == "number" then
			bool2 = type(arg1[2]) == "number"
		end
	end

	return bool2
end

tbl1.isNaN = function(arg1)
	return 1 < math.abs(arg1[1])
end

tbl1.sign = function(arg1)
	return arg1[1]
end

tbl1.isNegative = function(arg1)
	return arg1[1] == -1
end

tbl1.isPositive = function(arg1)
	return arg1[1] == 1
end

tbl1.isZero = function(arg1)
	return arg1[1] == 0
end

tbl1.isFloat = function(arg1)
	local bool1 = false
	if arg1[2] <= 308.2304489213783 then
		bool1 = math.abs(arg1[1]) <= 1
	end

	return bool1
end

tbl1.neg = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { -arg1[1], arg1[2] }
end

tbl1.abs = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { 1, arg1[2] }
end

tbl1.toBN = function(arg1)
	if type(arg1) == "string" then
		local var2 = arg1
		return tbl1.fromString(var2)
	end

	if type(arg1) == "number" then
		local var4 = arg1
		return tbl1.fromNumber(var4)
	end

	if type(arg1) == "table" then
		return { arg1[1], arg1[2] }
	end

	local var5 = ("Invalid input type '%*'"):format((type(arg1)))
	warn(debug.traceback(var5))
	local var6 = tbl1.ZERO
	return table.clone(var6)
end

tbl1.recip = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	return { arg1[1], arg1[2] * -1 }
end

tbl1.log10 = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] ~= 1 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { math.sign(arg1[2]), (math.log10((math.abs(arg1[2])))) }
end

tbl1.log2 = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] ~= 1 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { math.sign(arg1[2]), (math.log10(math.abs(arg1[2]) / 0.3010299956639812)) }
end

tbl1.ln = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] ~= 1 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { math.sign(arg1[2]), (math.log10(math.abs(arg1[2]) / 0.43429448190325182)) }
end

tbl1.log = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	local var1 = arg2
	arg2 = arg2 and tbl1.toNumber(tbl1.toBN(var1)) or 2.7182818284590451
	if arg1[1] ~= 1 then
		local var3 = tbl1.NAN
		return table.clone(var3)
	end

	if not arg2 then
		return { math.sign(arg1[2]), (math.log10(math.abs(arg1[2]) / 0.43429448190325182)) }
	end

	return { math.sign(arg1[2]), (math.log10(math.abs(arg1[2]) / math.log10(arg2))) }
end

tbl1.exp = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { 1, 0.43429448190325182 * 10 ^ arg1[2] * arg1[1] }
end

local tbl2 = {
	0.99999999999980993,
	676.5203681218851,
	-1259.1392167224028,
	771.32342877765313,
	-176.61502916214059,
	12.507343278686905,
	-0.13857109526572012,
	9.9843695780195716e-06,
	1.5056327351493116e-07,
}

local function gamma(arg1)
	if 0.5 < arg1 then
		arg1 = arg1 - 1
		local var2 = arg1 + 7.5
		return (tbl2[1] + tbl2[2] / (arg1 + 1) + tbl2[3] / (arg1 + 2) + tbl2[4] / (arg1 + 3) + tbl2[5] / (arg1 + 4) + tbl2[6] / (arg1 + 5) + tbl2[7] / (arg1 + 6) + tbl2[8] / (arg1 + 7)) * var2 ^ (arg1 + 0.5 - 36) * math.exp(-var2) * var2 ^ 36 * 2.5066282746310007
	end

	return 3.1415926535897931 / (math.sin(arg1 * 3.1415926535897931) * gamma(1 - arg1))
end

local tbl3 = { 1, 0.79817986835811505 }
local tbl4 = { 1, -1.079181246064997 }
local tbl5 = { 1, -2.5563025019833119 }
local tbl6 = { 1, 0.43429448190325182 }
tbl1.fact = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	local var4 = tbl1.toNumber(arg1)
	if arg1[1] == -1 then
		local var5 = tbl1.NAN
		return table.clone(var5)
	end

	if var4 < 170.61 then
		local var7 = gamma(var4 + 1)
		return tbl1.fromNumber(var7)
	end

	local var8 = arg1
	local num1 = 3
	local var9 = tbl1.div(tbl5, tbl1.powf(var8, num1))
	local var10 = tbl1.exp((tbl1.sub(tbl1.div(tbl4, arg1), var9)))
	local var11 = var10
	var8 = tbl1.mul(tbl1.pow(tbl1.div(arg1, tbl6), arg1), (tbl1.sqrt((tbl1.mul(tbl3, arg1)))))
	return tbl1.mul(var11, var8)
end

tbl1.random = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	local var3 = tbl1.mul(tbl1.sub(arg2, arg1), tbl1.fromNumber(math.random()))
	local var4 = arg1
	return tbl1.add(var3, var4)
end

tbl1.exprand = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if arg1[1] == -2 or arg2[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	return { arg1[1], arg1[2] + arg2[2] * math.random() }
end

tbl1.min = function(...)
	local tbl2 = { ... }
	local var1 = tbl2[1]
	for k1, v1 in tbl2, nil do
		if tbl1.cmp(v1, var1) ~= -1 then
			continue
		end

		var1 = v1
	end

	local var2 = var1
	return tbl1.toBN(var2)
end

tbl1.max = function(...)
	local tbl2 = { ... }
	local var1 = tbl2[1]
	for k1, v1 in tbl2, nil do
		if tbl1.cmp(v1, var1) ~= 1 then
			continue
		end

		var1 = v1
	end

	local var2 = var1
	return tbl1.toBN(var2)
end

tbl1.floor = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if 16 <= arg1[2] then
		local var4 = arg1
		return table.clone(var4)
	end

	if arg1[1] == 0 or arg1[2] < 0 then
		local var6 = tbl1.ZERO
		return table.clone(var6)
	end

	if arg1[1] == -1 then
		return { -1, (math.log10((math.ceil(10 ^ arg1[2])))) }
	end

	return { 1, (math.log10((math.floor(10 ^ arg1[2])))) }
end

tbl1.ceil = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if 16 <= arg1[2] then
		local var4 = arg1
		return table.clone(var4)
	end

	if arg1[1] == 0 or arg1[2] < 0 then
		local var6 = tbl1.ZERO
		return table.clone(var6)
	end

	if arg1[1] == -1 then
		return { -1, (math.log10((math.floor(10 ^ arg1[2])))) }
	end

	return { 1, (math.log10((math.ceil(10 ^ arg1[2])))) }
end

tbl1.round = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		local var2 = tbl1.NAN
		return table.clone(var2)
	end

	if 16 <= arg1[2] then
		local var4 = arg1
		return table.clone(var4)
	end

	if arg1[1] == 0 or arg1[2] < 0 then
		local var6 = tbl1.ZERO
		return table.clone(var6)
	end

	return { arg1[1], (math.log10((math.round(10 ^ arg1[2])))) }
end

tbl1.mod = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if type(arg2) ~= "table" then
		arg2 = tbl1.toBN(arg2)
	end

	if tbl1.isFloat(arg1) and tbl1.isFloat(arg2) then
		local var2 = tbl1.toNumber(arg1) % tbl1.toNumber(arg2)
		return tbl1.fromNumber(var2)
	end

	local var3 = arg1
	local var4 = arg2
	local var5 = arg2
	local var6 = arg1
	return tbl1.sub(var6, tbl1.mul(var5, tbl1.intdiv(var3, var4)))
end

tbl1.lbencode = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	local var1 = tbl1.add({ 1, arg1[2] }, { 1, 0 })
	if var1[2] ~= var1[2] then
		return 0
	end

	local var3 = var1[2]
	if 1.7976931348623157e+308 < var3 then
		var3 = 1.7976931348623157e+308
	end

	if var1[1] == 0 or var3 <= 0 then
		return 0
	end

	return math.floor((math.log10(var3 + 1) + 1) * 291262135922330) * arg1[1]
end

tbl1.lbencodePrecise = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	local var1 = tbl1.add({ 1, arg1[2] }, { 1, 0 })
	if var1[2] ~= var1[2] then
		return 0
	end

	local var3 = var1[2]
	if 1.7976931348623157e+308 < var3 then
		var3 = 1.7976931348623157e+308
	end

	if var1[1] == 0 or var3 <= 0 then
		return 0
	end

	return (math.floor((math.log10(var3 + 1) + 1) * 4503599627370496 * arg1[1]))
end

tbl1.lbdecode = function(arg1)
	if arg1 == 0 then
		local var2 = tbl1.ZERO
		return table.clone(var2)
	end

	local var3 = math.sign(arg1)
	return { var3, tbl1.sub({ 1, 10 ^ (math.abs(arg1) / 291262135922330 - 1) - 1 }, { 1, 0 })[2] }
end

tbl1.lbdecodePrecise = function(arg1)
	if arg1 == 0 then
		local var2 = tbl1.ZERO
		return table.clone(var2)
	end

	local var3 = math.sign(arg1)
	return { var3, tbl1.sub({ 1, 10 ^ (math.abs(arg1) / 4503599627370496 - 1) - 1 }, { 1, 0 })[2] }
end

local var2 = 10 ^ tbl1.display_precision
tbl1.toScientific = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		return "NaN"
	end

	if arg1[1] == 0 then
		return "0e0"
	end

	local var1 = math.floor(arg1[2])
	return (if arg1[1] == -1 then "-" else "") .. math.round(10 ^ (arg1[2] - var1) * var2) / var2 .. "e" .. var1
end

tbl1.toEngineer = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == -2 then
		return "NaN"
	end

	if arg1[1] == 0 then
		return "0e0"
	end

	local var1 = math.floor(arg1[2])
	var1 = var1 - var1 % 3
	return (if arg1[1] == -1 then "-" else "") .. math.round(10 ^ (arg1[2] - var1) * var2) / var2 .. "e" .. var1
end

local tbl7 = { "", "U", "D", "T", "Qd", "Qn", "Sx", "Sp", "Oc", "No" }
local tbl8 = { "", "De", "Vt", "Tg", "qg", "Qg", "sg", "Sg", "Og", "Ng" }
local tbl9 = { "", "Ce", "Du", "Tr", "Qa", "Qi", "Se", "Si", "Ot", "Ni" }
local tbl10 = {
	"Mi",
	"Mc",
	"Na",
	"Pi",
	"Fm",
	"At",
	"Zp",
	"Yc",
	"Xo",
	"Ve",
	"Me",
	"Due",
	"Tre",
	"Te",
	"Pt",
	"He",
	"Hp",
	"Oct",
	"En",
	"Ic",
	"Mei",
	"Dui",
	"Tri",
	"Teti",
	"Pti",
	"Hei",
	"Hp",
	"Oci",
	"Eni",
	"Tra",
	"TeC",
	"MTc",
	"DTc",
	"TrTc",
	"TeTc",
	"PeTc",
	"HTc",
	"HpT",
	"OcT",
	"EnT",
	"TetC",
	"MTetc",
	"DTetc",
	"TrTetc",
	"TeTetc",
	"PeTetc",
	"HTetc",
	"HpTetc",
	"OcTetc",
	"EnTetc",
	"PcT",
	"MPcT",
	"DPcT",
	"TPCt",
	"TePCt",
	"PePCt",
	"HePCt",
	"HpPct",
	"OcPct",
	"EnPct",
	"HCt",
	"MHcT",
	"DHcT",
	"THCt",
	"TeHCt",
	"PeHCt",
	"HeHCt",
	"HpHct",
	"OcHct",
	"EnHct",
	"HpCt",
	"MHpcT",
	"DHpcT",
	"THpCt",
	"TeHpCt",
	"PeHpCt",
	"HeHpCt",
	"HpHpct",
	"OcHpct",
	"EnHpct",
	"OCt",
	"MOcT",
	"DOcT",
	"TOCt",
	"TeOCt",
	"PeOCt",
	"HeOCt",
	"HpOct",
	"OcOct",
	"EnOct",
	"Ent",
	"MEnT",
	"DEnT",
	"TEnt",
	"TeEnt",
	"PeEnt",
	"HeEnt",
	"HpEnt",
	"OcEnt",
	"EnEnt",
	"Hect",
	"MeHect",
}

local tbl11 = { "k", "M", "B" }
local function highTier(arg1)
	local str1 = ""
	for k1, v1 in tbl10, nil do
		local var1 = 10 ^ (k1 * 3 - 3)
		if arg1 < var1 then
			break
		end

		local var2 = arg1 // var1 % 1000
		if 0 >= var2 then
			continue
		end

		if var2 == 1 then
			var2 = 0
		end

		str1 = tbl7[var2 % 10 + 1] .. tbl8[var2 // 10 % 10 + 1] .. tbl9[var2 // 100 % 10 + 1] .. v1 .. str1
	end

	return str1
end

tbl1.toSuffix = function(arg1)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	if arg1[1] == 0 then
		return "0"
	end

	if arg1[1] == -2 then
		return "NaN"
	end

	if arg1[2] == math.huge then
		return "inf"
	end

	local var3 = if arg1[1] == -1 then "-" else ""
	if arg1[2] < 0 then
		return var3 .. math.round(10 ^ arg1[2] * var2) / var2
	end

	local var4 = math.round(arg1[2] * 100000000000) / 100000000000
	arg1[2] = var4
	local var5 = math.floor(arg1[2])
	var4 = (arg1[2] - 3) // 3
	local var7 = math.round(10 ^ (arg1[2] - (var5 - var5 % 3)) * var2) / var2
	if var4 < 1000 then
		if var4 < 3 then
			return var3 .. var7 .. (tbl11[var4 + 1] or "")
		end

		return var3 .. var7 .. tbl7[var4 % 10 + 1] .. tbl8[var4 // 10 % 10 + 1] .. tbl9[var4 // 100 % 10 + 1]
	end

	local var8 = var4 % 1000
	return var3 .. var7 .. highTier(var4 // 1000) .. tbl7[var8 % 10 + 1] .. tbl8[var8 // 10 % 10 + 1] .. tbl9[var8 // 100 % 10 + 1]
end

tbl1.roundMantissa = function(arg1, arg2)
	if type(arg1) ~= "table" then
		arg1 = tbl1.toBN(arg1)
	end

	return {
		arg1[1],
		math.floor(arg1[2]) + math.log10(math.round(10 ^ (arg1[2] % 1 + arg2)) / 10 ^ arg2),
	}
end

tbl1.map = function(arg1, arg2, arg3, arg4, arg5)
	local var1 = tbl1.div(tbl1.mul(tbl1.sub(arg1, arg2), (tbl1.sub(arg5, arg4))), (tbl1.sub(arg3, arg2)))
	local var2 = arg4
	return tbl1.add(var1, var2)
end

return tbl1

--- ReplicatedStorage.Modules.Shared.StatInformation [ModuleScript]
-- y u r i

local tbl1 = { Icon = "rbxassetid://124397197440296", Colour = Color3.fromRGB(255, 42, 74) }
local tbl2 = { Ruby = tbl1 }
tbl1 = { Icon = "rbxassetid://123145060961508", Colour = Color3.fromRGB(113, 255, 111) }
tbl2.Cash = tbl1
tbl1 = { Icon = "rbxassetid://79946293943319", Colour = Color3.fromRGB(139, 57, 43) }
tbl2.Soil = tbl1
tbl1 = { Icon = "rbxassetid://113668091012536", Colour = Color3.fromRGB(26, 213, 255) }
tbl2.Water = tbl1
tbl1 = { Icon = "rbxassetid://112448665810895", Colour = Color3.fromRGB(255, 194, 39) }
tbl2.XP = tbl1
tbl1 = { Icon = "rbxassetid://97605720153349", Colour = Color3.fromRGB(255, 157, 108) }
tbl2.Wood = tbl1
tbl1 = { Icon = "rbxassetid://114856142416851", Colour = Color3.fromRGB(220, 170, 18) }
tbl2.Harvest = tbl1
tbl1 = { Icon = "rbxassetid://108163453770300", Colour = Color3.fromRGB(0, 115, 0) }
tbl2.Grass = tbl1
tbl1 = { Icon = "rbxassetid://102082505817616", Colour = Color3.fromRGB(194, 183, 157) }
tbl2.Paper = tbl1
tbl1 = { Icon = "rbxassetid://129765737093410", Colour = Color3.fromRGB(222, 146, 91) }
tbl2.Research = tbl1
tbl1 = { Icon = "rbxassetid://137275600063189", Colour = Color3.fromRGB(185, 185, 185) }
tbl2.Replant = tbl1
tbl1 = { Icon = "rbxassetid://135733827510257", Colour = Color3.fromRGB(29, 126, 245) }
tbl2.Diamond = tbl1
tbl1 = { Icon = "rbxassetid://75632986241042", Colour = Color3.fromRGB(103, 245, 60) }
tbl2.Leaves = tbl1
tbl1 = { Icon = "rbxassetid://128432448646814", Colour = Color3.fromRGB(32, 188, 32) }
tbl2.Plant = tbl1
tbl1 = { Icon = "rbxassetid://85575519884054", Colour = Color3.fromRGB(255, 186, 11) }
tbl2.Clicker = tbl1
tbl1 = { Icon = "rbxassetid://138354470464864", Colour = Color3.fromRGB(255, 255, 255) }
tbl2.Walkspeed = tbl1
tbl1 = { Icon = "rbxassetid://95372328415192", Colour = Color3.fromRGB(255, 52, 55) }
tbl2.Time = tbl1
tbl1 = { Icon = "rbxassetid://84505481705914", Colour = Color3.fromRGB(74, 255, 110) }
tbl2.Cap = tbl1
tbl1 = { Icon = "rbxassetid://115698157368137", Colour = Color3.fromRGB(255, 255, 255) }
tbl2.Range = tbl1
tbl1 = { Icon = "rbxassetid://84687071253921", Colour = Color3.fromRGB(154, 150, 151) }
tbl2.Axe = tbl1
tbl1 = { Icon = "rbxassetid://117528717927931", Colour = Color3.fromRGB(162, 176, 204) }
tbl2.Ores = tbl1
tbl1 = { Icon = "rbxassetid://93797727399039", Colour = Color3.fromRGB(222, 120, 4) }
tbl2.Collects = tbl1
tbl1 = { Icon = "rbxassetid://93465570730422", Colour = Color3.fromRGB(0, 115, 0) }
tbl2.PetDefault = tbl1
tbl1 = { Icon = "rbxassetid://131783038303103", Colour = Color3.fromRGB(236, 211, 19) }
tbl2.Achievement = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.Messages [ModuleScript]
-- y u r i

local var1 = game:GetService("TextChatService"):WaitForChild("TextChannels"):WaitForChild("RBXSystem")
return { MakeMessage = function(arg1, arg2, arg3)
	local tbl1 = { Text = arg1, Font = arg3, Color = arg2, FontSize = "17" }
	var1:DisplaySystemMessage("<font color=\"#" .. tbl1.Color .. "\"><font size=\"" .. tbl1.FontSize .. "\"><font face=\"" .. tbl1.Font .. "\">" .. tbl1.Text .. "</font></font></font>")
end }

--- ReplicatedStorage.Modules.Shared.AutoUpgrades [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Modules.Shared.Replant)
return {
	Soil = {
		Unlocked = function(arg1)
			return 2 <= arg1.Stats.Harvest.Value
		end,
		Infinite = function(arg1)
			return 2 <= arg1.Stats.Harvest.Value
		end,
		Currency = "Soil",
		Setting = "AutoSoilSetting",
	},
	Water = {
		Unlocked = function(arg1)
			return 3 <= arg1.Stats.Harvest.Value
		end,
		Infinite = function(arg1)
			return 3 <= arg1.Stats.Harvest.Value
		end,
		Currency = "Water",
		Setting = "AutoWaterSetting",
	},
	Wood = {
		Unlocked = function(arg1)
			return 4 <= arg1.Stats.Harvest.Value
		end,
		Infinite = function(arg1)
			return 4 <= arg1.Stats.Harvest.Value
		end,
		Currency = "Wood",
		Setting = "AutoWoodSetting",
	},
	Grass = {
		Unlocked = function(arg1)
			local var2 = arg1
			return var1.HasAutoGrassUpgrades(var2)
		end,
		Infinite = function(arg1)
			local var2 = arg1
			return var1.HasAutoGrassUpgrades(var2)
		end,
		Currency = "Grass",
		Setting = "AutoGrassSetting",
	},
}

--- ReplicatedStorage.Modules.Shared.FeatureHandler [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules
local var3 = require(var1.Framework)
local var4 = game:GetService("Players").LocalPlayer
var3.Stat.WaitForLoad(var4)
var3.Stat.GetDataFolder(var4)
local tbl1 = {}
local num1 = 0
local var5 = require(var2.Shared.Features)
local var6 = require(var2.Client.UI).PopUps
local var7 = workspace.Features
local tbl2 = {}
local tbl3 = {}
local tbl4 = {}
tbl4.InitializeFeatures = function()
	for k1, v1 in var7:GetChildren() do
		tbl2[v1.Name] = v1
		tbl3[v1.Name] = false
		tbl1[v1.Name] = false
		local var2 = var5[v1.Name]
		if not var2 then
			print(v1.Name, "Board not found")
		else
			local var8 = var3.Stat.Get(var4, var2.ViewStat)
			local var9 = var3.Stat.Get(var4, var2.VisibleStat)
			if not var8 then
				print("Stat not found")
			elseif not var9 then
				print("Stat not found")
			else
				var8.Changed:Connect(function()
					tbl4.UpdateFeature(v1.Name)
				end)

				var9.Changed:Connect(function()
					tbl4.UpdateFeature(v1.Name)
				end)

				tbl4.UpdateFeature(v1.Name)
			end
		end
	end

	var3.Network.Fire("FeaturesLoaded")
end

tbl4.GetFeature = function(arg1)
	if var5[arg1] == nil then
		return
	end

	return tbl2[arg1]
end

local var8 = var1.Assets
local function CreateNotification(arg1)
	local bool1 = true
	for k1, v1 in tbl1, nil do
		bool1 = bool1 and v1
		if not bool1 then
			break
		end
	end

	tbl1[arg1] = false
	if bool1 == true and (0 < num1 and var5[arg1].Ignore == false) then
		local num5 = 255
		local num6 = 255
		local num7 = 255
		var6.NormalPopUp("New board(s) unlocked", Color3.fromRGB(num5, num6, num7))
		num1 = 0
	end
end

tbl4.UpdateFeature = function(arg1)
	local var2 = var5[arg1]
	local var3 = tbl4.GetFeature(arg1)
	if not var2 then
		print("Board not found")
		return
	end

	tbl1[arg1] = true
	local var9 = var2.NoBoard
	local var10 = var2.Unlocked(var4)
	local var11 = var2.Visible(var4)
	if var9 == nil then
		local var12 = var3:WaitForChild("Board").SurfaceGui.LockedFrame.TextLabel
		var12.Text = var2.LockedMessage
	end

	if not var11 and var3.Parent == var7 then
		var3.Parent = var8.Features
		tbl3[arg1] = true
		return
	end

	if var11 then
		var3.Parent = var7
		if var10 then
			if var9 == nil then
				local var13 = var3:WaitForChild("Board").SurfaceGui.LockedFrame
				var13.Visible = false
				var13 = var3:WaitForChild("Board").SurfaceGui.Frame
				var13.Visible = true
			end

			if var2.UpgradeBoard then
				local var14 = var3:WaitForChild(var2.StatName).SurfaceGui
				var14.Enabled = true
			end

			if tbl3[arg1] ~= true then
				return
			end

			tbl3[arg1] = false
			local var15 = num1 + 1
			num1 = var15
			CreateNotification(arg1)
			return
		end

		if var9 == nil then
			local var16 = var3:WaitForChild("Board").SurfaceGui.LockedFrame
			var16.Visible = true
			var16 = var3:WaitForChild("Board").SurfaceGui.Frame
			var16.Visible = false
		end

		if var2.UpgradeBoard then
			local var17 = var3:WaitForChild(var2.StatName).SurfaceGui
			var17.Enabled = false
		end
	end
end

return tbl4

--- ReplicatedStorage.Modules.Shared.Features [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var2.Seeds)
var3.Seeds[2].Colour:ToHex()
local var4 = require(var2.StatInformation)
local var5 = require(var2.BigNum)
local var6 = require(var1.Framework)
local var7 = var3.Seeds[4].Colour:ToHex()
local var8 = var3.Seeds[5].Colour:ToHex()
local var9 = var3.Seeds[6].Colour:ToHex()
local var10 = var3.Seeds[7].Colour:ToHex()
local var11 = var3.Seeds[10].Colour:ToHex()
local var12 = var3.Seeds[11].Colour:ToHex()
local var13 = var3.Seeds[14].Colour:ToHex()
local var14 = var4.Harvest.Colour:ToHex()
local var15 = var4.Replant.Colour:ToHex()
local tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 3
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
}

local tbl2 = { Soil = tbl1 }
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 3
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
	UpgradeBoard = true,
	StatName = "Soil",
}

tbl2.SoilUpgrades = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
	NoBoard = true,
}

tbl2.Water = tbl1
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Onion</font> Seed"):format(var8),
	UpgradeBoard = true,
	StatName = "Water",
}

tbl2.WaterUpgrades = tbl1
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
}

tbl2.Bank = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 6
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 6
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
	NoBoard = true,
}

tbl2.Tree = tbl1
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 6
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Cucumber</font> Seed"):format(var9),
	UpgradeBoard = true,
	StatName = "Wood",
}

tbl2.WoodUpgrades = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 7
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 6
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Tomato</font> Seed"):format(var10),
}

tbl2.Harvest = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestHarvest").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestHarvest",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestHarvest").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestHarvest",
	LockedMessage = ("Reach <font color=\"#%*\">Lettuce</font> Seed"):format(var7),
	NoBoard = true,
}

tbl2.Barn = tbl1
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestHarvest").Value
		local num1 = 5
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestHarvest",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestHarvest").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestHarvest",
	LockedMessage = ("Reach <font color=\"#%*\">Harvest</font> 5"):format(var14),
	UpgradeBoard = true,
	StatName = "Grass",
}

tbl2.GrassUpgrades = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 10
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 10
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Strawberry</font> Seed"):format(var11),
}

tbl2.Research = tbl1
tbl1 = {
	Ignore = false,
	NoBoard = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 10
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 10
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Strawberry</font> Seed"):format(var11),
}

tbl2.Quests = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 11
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 10
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Orange</font> Seed"):format(var12),
}

tbl2.Replant = tbl1
tbl1 = {
	Ignore = false,
	NoBoard = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestReplant").Value
		local num1 = 3
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestReplant",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestReplant").Value
		local num1 = 3
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestReplant",
	LockedMessage = ("Reach <font color=\"#%*\">Replant</font> 3"):format(var15),
}

tbl2.Lab = tbl1
tbl1 = {
	Ignore = false,
	NoBoard = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestReplant").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestReplant",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestReplant").Value
		local num1 = 4
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestReplant",
	LockedMessage = ("Reach <font color=\"#%*\">Orange</font> Seed"):format(var12),
}

tbl2.Scientists = tbl1
tbl1 = {
	Ignore = false,
	NoBoard = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Grape</font> Seed"):format(var13),
}

tbl2.Leaf = tbl1
tbl1 = {
	Ignore = true,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Grape</font> Seed"):format(var13),
	UpgradeBoard = true,
	StatName = "Leaves",
}

tbl2.LeafUpgrades = tbl1
tbl1 = {
	Ignore = false,
	Unlocked = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		local var1 = var6.Stat.Get(arg1, "HighestSeed").Value
		local num1 = 14
		return var5.gte(var1, num1)
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Grape</font> Seed"):format(var13),
}

tbl2.Achievements = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.Tutorial [ModuleScript]
-- y u r i

game:GetService("RunService")
game:GetService("Players")
local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = var1.Modules.Shared
local var3 = workspace:WaitForChild("Features")
local var4 = var1.Assets
local var5 = require(var2.StatInformation)
local var6 = require(var2.Seeds)
local var7 = require(var2.Pets)
var7[1].Colour:ToHex()
var7[2].Colour:ToHex()
local var8 = workspace.MapEssentials
local var9 = var5.Cash.Colour:ToHex()
local var10 = Color3.fromRGB(255, 255, 255):ToHex()
local var11 = var5.Soil.Colour:ToHex()
local var12 = var5.Water.Colour:ToHex()
local var13 = var5.Wood.Colour:ToHex()
local var14 = var5.Harvest.Colour:ToHex()
local var15 = var5.Grass.Colour:ToHex()
local var16 = var5.Research.Colour:ToHex()
local var17 = var5.Paper.Colour:ToHex()
local var18 = var5.Replant.Colour:ToHex()
local var19 = var5.Achievement.Colour:ToHex()
local var20 = var5.Leaves.Colour:ToHex()
local var21 = var6.Seeds[0].Colour:ToHex()
local var22 = var6.Seeds[1].Colour:ToHex()
local var23 = var6.Seeds[2].Colour:ToHex()
local var24 = var6.Seeds[3].Colour:ToHex()
local var25 = var6.Seeds[4].Colour:ToHex()
local var26 = var6.Seeds[5].Colour:ToHex()
local var27 = var6.Seeds[6].Colour:ToHex()
local var28 = var6.Seeds[7].Colour:ToHex()
local var29 = var6.Seeds[8].Colour:ToHex()
local var30 = var6.Seeds[9].Colour:ToHex()
local var31 = var6.Seeds[10].Colour:ToHex()
local var32 = var6.Seeds[11].Colour:ToHex()
local var33 = var6.Seeds[12].Colour:ToHex()
local var34 = var6.Seeds[13].Colour:ToHex()
local var35 = var6.Seeds[14].Colour:ToHex()
local var36 = var7[0].Colour:ToHex()
local var37 = var7[4].Colour:ToHex()
local var38 = var7[6].Colour:ToHex()
local var39 = var8:WaitForChild("Collection"):WaitForChild("ShownSpawnable")
local var40 = var8.DailyUpgrades.DailyMoreWalkspeed:WaitForChild("Head")
local var41 = var8.UpgradeTree.TreeMoreCash:WaitForChild("Holder")
local var42 = var8.UpgradeTree.TreeMoreCash2:WaitForChild("Holder")
local var43 = var8.UpgradeTree.TreeMoreCash3:WaitForChild("Holder")
local var44 = var8.UpgradeTree.TreeMoreCash4:WaitForChild("Holder")
local var45 = var8.UpgradeTree.TreeMoreCash5:WaitForChild("Holder")
local var46 = var8.UpgradeTree.TreeMoreCash8:WaitForChild("Holder")
local var47 = var8.UpgradeTree.TreeMoreCash9:WaitForChild("Holder")
local var48 = var8.UpgradeTree.TreeMoreCash10:WaitForChild("Holder")
local var49 = var8.UpgradeTree.TreeMoreCash11:WaitForChild("Holder")
local var50 = var8.UpgradeTree.TreeMoreLeaves2:WaitForChild("Holder")
local var51 = var8.UpgradeTree.TreeMoreGrass5:WaitForChild("Holder")
local var52 = var8.UpgradeTree.TreeBetterLeafCollect2:WaitForChild("Holder")
local var53 = var8.UpgradeTree.TreeMoreLeaves3:WaitForChild("Holder")
local var54 = var8.UpgradeTree.TreeMorePaperUpgradesCap:WaitForChild("Holder")
local var55 = var8.UpgradeTree.TreeMoreSoil:WaitForChild("Holder")
local var56 = var8.UpgradeTree.TreeMoreSoil2:WaitForChild("Holder")
local var57 = var8.UpgradeTree.TreeMoreWater:WaitForChild("Holder")
local var58 = var8.UpgradeTree.TreeMoreWater2:WaitForChild("Holder")
local var59 = var8.UpgradeTree.TreeMoreWater4:WaitForChild("Holder")
local var60 = var8.UpgradeTree.TreeMoreWater5:WaitForChild("Holder")
local var61 = var8.UpgradeTree.TreeMoreXP:WaitForChild("Holder")
local var62 = var8.UpgradeTree.TreeMoreWalkspeed:WaitForChild("Holder")
local var63 = var8.UpgradeTree.TreeFasterSpawn:WaitForChild("Holder")
local var64 = var8.UpgradeTree.TreeMoreCap:WaitForChild("Holder")
local var65 = var8.UpgradeTree.TreeUnlockCombo:WaitForChild("Holder")
local var66 = var8.UpgradeTree.TreeMoreWood:WaitForChild("Holder")
local var67 = var8.UpgradeTree.TreeMorePaper4:WaitForChild("Holder")
local var68 = var8.UpgradeTree.TreeMorePaper5:WaitForChild("Holder")
local var69 = var8.UpgradeTree.TreeMorePaper6:WaitForChild("Holder")
local var70 = var8.UpgradeTree.TreeBetterCombo2:WaitForChild("Holder")
local var71 = var8.UpgradeTree.TreeMoreWalkspeed2:WaitForChild("Holder")
local var72 = var8.UpgradeTree.TreeMoreRange2:WaitForChild("Holder")
local var73 = var8.UpgradeTree.TreeFasterResearch:WaitForChild("Holder")
local var74 = var8.UpgradeTree.TreeFasterResearch2:WaitForChild("Holder")
local var75 = var8.UpgradeTree.TreeMoreGrass4:WaitForChild("Holder")
local var76 = var8.UpgradeTree.TreeMoreComboLimit:WaitForChild("Holder")
local var77 = var8.UpgradeTree.TreeMorePaper2:WaitForChild("Holder")
local tbl1 = {
	Text = ("Get <font color=\"#%*\">10 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 10,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 10 Cash",
}

tbl1.Arrow = var39
local tbl2 = {
	Text = ("Upgrade your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "SeedLevel",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your wheat 1",
}

local tbl3 = {
	Text = ("Get <font color=\"#%*\">15 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 15,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 20 Cash",
}

tbl3.Arrow = var39
local tbl4 = {
	Text = ("Upgrade your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "SeedLevel",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your wheat 2",
}

local tbl5 = {
	Text = ("Get <font color=\"#%*\">20 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 20,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 30 Cash",
}

tbl5.Arrow = var39
local tbl6 = {
	Text = ("Upgrade your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "SeedLevel",
	Amount = 3,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your wheat 3",
}

local tbl7 = {
	Text = ("Get <font color=\"#%*\">25 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 25,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 40 Cash",
}

tbl7.Arrow = var39
local tbl8 = {
	Text = ("Upgrade your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "SeedLevel",
	Amount = 4,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your wheat 4",
}

local tbl9 = {
	Text = ("Get <font color=\"#%*\">30 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 30,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 50 Cash",
}

tbl9.Arrow = var39
local tbl10 = {
	Text = ("Upgrade your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your wheat 5",
}

local tbl11 = {
	Text = ("Get <font color=\"#%*\">50 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 50,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 75 Cash",
}

tbl11.Arrow = var39
local tbl12 = {
	Text = ("Evolve your <font color=\"#%*\">Wheat</font>"):format(var21),
	Stat = "Seed",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Evolve your wheat",
}

local tbl13 = {
	Text = ("Upgrade your <font color=\"#%*\">Apple</font>"):format(var22),
	Stat = "SeedLevel",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your Apple 1",
}

local tbl14 = {
	Text = ("Upgrade your <font color=\"#%*\">Apple</font>"):format(var22),
	Stat = "SeedLevel",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your Apple 2",
}

local tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	{
		Text = "Buy <font color=\"#ffffff\">More Walkspeed</font>",
		Stat = "DailyMoreWalkspeed",
		Amount = 1,
		Arrow = var40,
		Image = "Walkspeed",
		Overwrite = -1,
		Funnel = "Buy More Walkspeed",
	},
	tbl13,
	tbl14,
	{
		Text = ("Upgrade your <font color=\"#%*\">Apple</font>"):format(var22),
		Stat = "SeedLevel",
		Amount = 3,
		Arrow = "Seed",
		Image = "Seed",
		Overwrite = -1,
		Funnel = "Upgrade your Apple 3",
	},
}

tbl1 = {
	Text = ("Upgrade your <font color=\"#%*\">Apple</font>"):format(var22),
	Stat = "SeedLevel",
	Amount = 4,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your Apple 4",
}

tbl2 = {
	Text = ("Upgrade your <font color=\"#%*\">Apple</font>"):format(var22),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your Apple 5",
}

tbl3 = {
	Text = ("Get <font color=\"#%*\">150 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 150,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 150 Cash",
}

tbl3.Arrow = var39
tbl4 = {
	Text = ("Evolve your <font color=\"#%*\">Apple</font>"):format(var22),
	Stat = "Seed",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Evolve your Apple",
}

tbl5 = {
	Text = ("Get <font color=\"#%*\">50 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 50,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 50 Cash",
}

tbl5.Arrow = var39
tbl6 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash",
	Amount = 1,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Buy Tree More Cash",
}

tbl6.Arrow = var41
tbl7 = {
	Text = ("Get <font color=\"#%*\">100 Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 100,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 100 Cash (Second tree upgrade)",
}

tbl7.Arrow = var39
tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash",
	Amount = 2,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Buy Tree More Cash 2",
}

tbl8.Arrow = var41
tbl9 = {
	Text = ("Upgrade your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "SeedLevel",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Upgrade your Carrot 1",
}

tbl10 = {
	Text = ("Buy <font color=\"#%*\">Faster Spawn</font>"):format(var10),
	Stat = "TreeFasterSpawn",
	Amount = 1,
	Image = "Time",
	Overwrite = -1,
	Funnel = "Buy Tree Faster Spawn",
}

tbl10.Arrow = var63
tbl11 = {
	Text = ("Buy <font color=\"#%*\">More Cap</font>"):format(var10),
	Stat = "TreeMoreCap",
	Amount = 1,
	Image = "Cap",
	Overwrite = -1,
	Funnel = "Buy Tree More Cap",
}

tbl11.Arrow = var64
tbl12 = {
	Text = ("Upgrade your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "SeedLevel",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
}

local tbl16 = {
	Text = ("Upgrade your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "SeedLevel",
	Amount = 3,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
}

tbl13 = {
	Text = ("Upgrade your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "SeedLevel",
	Amount = 4,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
}

tbl14 = {
	Text = ("Upgrade your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
}

local tbl17 = {
	Text = ("Get <font color=\"#%*\">15k Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 15000,
	Image = "Cash",
	Overwrite = -1,
	Funnel = "Get 15k Cash",
}

tbl17.Arrow = var39
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Evolve your <font color=\"#%*\">Carrot</font>"):format(var23),
	Stat = "Seed",
	Amount = 3,
	Arrow = "Seed",
	Image = "Seed",
	Overwrite = -1,
	Funnel = "Evolve your Carrot",
}

tbl2 = {
	Text = ("Upgrade your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "SeedLevel",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
}

tbl3 = {
	Text = ("Upgrade your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "SeedLevel",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
}

tbl4 = {
	Text = ("Get <font color=\"#%*\">25k Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 25000,
	Image = "Cash",
	Overwrite = 10,
}

tbl4.Arrow = var39
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash2",
	Amount = 1,
	Image = "Cash",
	Overwrite = 10,
	Funnel = "Buy Tree More Cash 2",
}

tbl5.Arrow = var42
tbl6 = {
	Text = ("Upgrade your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "SeedLevel",
	Amount = 3,
	Arrow = "Seed",
	Image = "Seed",
}

tbl7 = {
	Text = ("Upgrade your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "SeedLevel",
	Amount = 4,
	Arrow = "Seed",
	Image = "Seed",
}

tbl8 = {
	Text = ("Upgrade your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
}

tbl9 = {
	Text = ("Get <font color=\"#%*\">250k Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 250000,
	Image = "Cash",
	Funnel = "Get 250k Cash",
}

tbl9.Arrow = var39
tbl10 = {
	Text = ("Evolve your <font color=\"#%*\">Potato</font>"):format(var24),
	Stat = "Seed",
	Amount = 4,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Potato",
}

tbl11 = {
	Text = ("Get <font color=\"#%*\">100k Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 100000,
	Image = "Cash",
	Funnel = "Get 100k Cash",
}

tbl11.Arrow = var39
tbl12 = {
	Text = ("Convert <font color=\"#%*\">1 Soil</font>"):format(var11),
	Stat = "Soil",
	Amount = 1,
	Image = "Soil",
	Funnel = "Convert 1 Soil",
}

local function SoilBoard()
	local var1 = var3:FindFirstChild("Soil")
	local str1 = "SoilArrow"
	return (var1 or var4.Features:FindFirstChild("Soil")):WaitForChild("Board"):WaitForChild(str1)
end

tbl12.Arrow = SoilBoard
tbl16 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "SoilMoreCash",
	Amount = 1,
	Image = "Cash",
	Funnel = "Buy Soil More Cash",
}

local function SoilMoreCash()
	local var1 = var3:FindFirstChild("SoilUpgrades")
	local str1 = "CashArrow"
	return (var1 or var4.Features:FindFirstChild("SoilUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl16.Arrow = SoilMoreCash
tbl13 = {
	Text = ("Upgrade your <font color=\"#%*\">Lettuce</font>"):format(var25),
	Stat = "SeedLevel",
	Amount = 1,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Upgrade your Lettuce 1",
}

tbl14 = {
	Text = ("Upgrade your <font color=\"#%*\">Lettuce</font>"):format(var25),
	Stat = "SeedLevel",
	Amount = 2,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Upgrade your Lettuce 2",
}

tbl17 = {
	Text = ("Convert <font color=\"#%*\">9 Soil</font>"):format(var11),
	Stat = "Soil",
	Amount = 9,
	Image = "Soil",
	Funnel = "Convert 10 Soil",
}

tbl17.Arrow = SoilBoard
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "SoilMoreCash",
	Amount = 2,
	Image = "Cash",
	Funnel = "Buy Soil More Cash 2",
}

tbl1.Arrow = SoilMoreCash
tbl2 = {
	Text = ("Buy <font color=\"#%*\">Faster Spawn</font>"):format(var10),
	Stat = "SoilFasterSpawn",
	Amount = 1,
	Image = "Time",
	Funnel = "Buy Soil Faster Spawn",
}

tbl2.Arrow = function()
	local var1 = var3:FindFirstChild("SoilUpgrades")
	local str1 = "SpawnArrow"
	return (var1 or var4.Features:FindFirstChild("SoilUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl3 = {
	Text = ("Upgrade your <font color=\"#%*\">Lettuce</font>"):format(var25),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Upgrade your Lettuce 5",
}

tbl4 = {
	Text = ("Get <font color=\"#%*\">25M Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 25000000,
	Image = "Cash",
	Funnel = "Get 25M Cash",
}

tbl4.Arrow = var39
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More Soil</font>"):format(var11),
	Stat = "TreeMoreSoil",
	Amount = 1,
	Image = "Soil",
	Funnel = "Buy Tree More Soil",
}

tbl5.Arrow = var55
tbl6 = {
	Text = ("Upgrade your <font color=\"#%*\">Lettuce</font>"):format(var25),
	Stat = "SeedLevel",
	Amount = 10,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Upgrade your Lettuce 10",
}

tbl7 = {
	Text = ("Get <font color=\"#%*\">5B Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 5000000000,
	Image = "Cash",
	Funnel = "Get 5B Cash",
}

tbl7.Arrow = var39
tbl8 = {
	Text = ("Evolve your <font color=\"#%*\">Lettuce</font>"):format(var25),
	Stat = "Seed",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Lettuce",
}

tbl9 = {
	Text = ("Click the <font color=\"#%*\">Water</font> 10 times"):format(var12),
	Stat = "Clicks",
	Amount = 10,
	Image = "Water",
	Funnel = "Click the Water 10 times",
}

local function WaterModel()
	local var1 = var3:FindFirstChild("Water")
	local str1 = "Water"
	return (var1 or var4.Features:FindFirstChild("Water")):WaitForChild(str1)
end

tbl9.Arrow = WaterModel
tbl10 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "WaterMoreCash",
	Amount = 2,
	Image = "Cash",
	Funnel = "Buy Water More Cash",
}

local function WaterMoreCash()
	local var1 = var3:FindFirstChild("WaterUpgrades")
	local str1 = "CashArrow"
	return (var1 or var4.Features:FindFirstChild("WaterUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl10.Arrow = WaterMoreCash
tbl11 = {
	Text = ("Buy <font color=\"#%*\">More Soil</font>"):format(var11),
	Stat = "SoilMoreSoil",
	Amount = 8,
	Image = "Soil",
	Funnel = "Buy Soil More Soil",
}

tbl11.Arrow = function()
	local var1 = var3:FindFirstChild("SoilUpgrades")
	local str1 = "SoilArrow"
	return (var1 or var4.Features:FindFirstChild("SoilUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl12 = {
	Text = ("Convert <font color=\"#%*\">2.5B Soil</font>"):format(var11),
	Stat = "Soil",
	Amount = 2500000000,
	Image = "Soil",
	Funnel = "Convert 2.5B Soil",
}

tbl12.Arrow = SoilBoard
tbl16 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater",
	Amount = 1,
	Image = "Water",
	Funnel = "Buy Tree More Water",
}

tbl16.Arrow = var57
tbl13 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "WaterMoreCash",
	Amount = 3,
	Image = "Cash",
	Funnel = "Buy Water More Cash",
}

tbl13.Arrow = WaterMoreCash
tbl14 = {
	Text = ("Get <font color=\"#%*\">250B Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 250000000000,
	Image = "Cash",
	Funnel = "Get 250B Cash",
}

tbl14.Arrow = var39
tbl17 = {
	Text = ("Buy <font color=\"#%*\">More XP</font>"):format(var12),
	Stat = "TreeMoreXP",
	Amount = 1,
	Image = "XP",
	Funnel = "Buy Tree More XP",
}

tbl17.Arrow = var61
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get <font color=\"#%*\">1k Water</font>"):format(var12),
	Stat = "Water",
	Amount = 1000,
	Image = "Water",
	Funnel = "Get 1k Water",
}

tbl1.Arrow = WaterModel
tbl2 = {
	Text = ("Buy <font color=\"#%*\">More Walkspeed</font>"):format(var10),
	Stat = "TreeMoreWalkspeed",
	Amount = 1,
	Image = "Walkspeed",
	Funnel = "Buy Tree More Walkspeed",
}

tbl2.Arrow = var62
tbl3 = {
	Text = ("Buy <font color=\"#%*\">More XP</font>"):format(var12),
	Stat = "WaterMoreXP",
	Amount = 1,
	Image = "XP",
}

tbl3.Arrow = function()
	local var1 = var3:FindFirstChild("WaterUpgrades")
	local str1 = "XPArrow"
	return (var1 or var4.Features:FindFirstChild("WaterUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl4 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater",
	Amount = 2,
	Image = "Water",
}

tbl4.Arrow = var57
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More XP</font>"):format(var12),
	Stat = "TreeMoreXP",
	Amount = 2,
	Image = "XP",
}

tbl5.Arrow = var61
tbl6 = {
	Text = ("Get <font color=\"#%*\">5k Water</font>"):format(var12),
	Stat = "Water",
	Amount = 5000,
	Image = "Water",
	Funnel = "Get 5000 Water",
}

tbl6.Arrow = WaterModel
tbl7 = {
	Text = ("Buy <font color=\"#%*\">Unlock Combo</font>"):format(var9),
	Stat = "TreeUnlockCombo",
	Amount = 1,
	Image = "Cash",
	Funnel = "Buy Tree Unlock Combo",
}

tbl7.Arrow = var65
tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater",
	Amount = 5,
	Image = "Water",
}

tbl8.Arrow = var57
tbl9 = {
	Text = ("Get <font color=\"#%*\">50k Water</font>"):format(var12),
	Stat = "Water",
	Amount = 50000,
	Image = "Water",
	Funnel = "Get 50k Water",
}

tbl9.Arrow = WaterModel
tbl10 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash3",
	Amount = 1,
	Image = "Cash",
	Funnel = "Buy Tree More Cash 3",
}

tbl10.Arrow = var43
tbl11 = {
	Text = ("Evolve your <font color=\"#%*\">Onion</font>"):format(var26),
	Stat = "Seed",
	Amount = 6,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Onion",
}

tbl12 = {
	Text = ("Harvest <font color=\"#%*\">10 Wood</font>"):format(var13),
	Stat = "Wood",
	Amount = 10,
	Image = "Wood",
	Funnel = "Harvest 10 Wood",
}

local function Tree()
	local var1 = var3:FindFirstChild("Tree")
	local str1 = "Main"
	return (var1 or var4.Features:FindFirstChild("Tree")):WaitForChild("Tree"):WaitForChild("Ring"):WaitForChild(str1)
end

tbl12.Arrow = Tree
tbl16 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "WoodMoreCash",
	Amount = 1,
	Image = "Cash",
}

tbl16.Arrow = function()
	local var1 = var3:FindFirstChild("WoodUpgrades")
	local str1 = "CashArrow"
	return (var1 or var4.Features:FindFirstChild("WoodUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl13 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "WoodMoreWater",
	Amount = 1,
	Image = "Water",
}

tbl13.Arrow = function()
	local var1 = var3:FindFirstChild("WoodUpgrades")
	local str1 = "WaterArrow"
	return (var1 or var4.Features:FindFirstChild("WoodUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl14 = {
	Text = ("Get <font color=\"#%*\">250T Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 250000000000000,
	Image = "Cash",
}

tbl14.Arrow = var39
tbl17 = {
	Text = ("Buy <font color=\"#%*\">More Wood</font>"):format(var13),
	Stat = "TreeMoreWood",
	Amount = 1,
	Image = "Wood",
}

tbl17.Arrow = var66
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get <font color=\"#%*\">100k Water</font>"):format(var12),
	Stat = "Water",
	Amount = 100000,
	Image = "Water",
	Funnel = "Get 100k Water",
}

tbl1.Arrow = WaterModel
tbl2 = {
	Text = ("Upgrade your <font color=\"#%*\">Tree</font>"):format(var13),
	Stat = "TreeLevel",
	Amount = 1,
	Image = "Wood",
	Funnel = "Upgrade your tree",
}

tbl2.Arrow = function()
	local var1 = var3:FindFirstChild("Tree")
	local str1 = "Main"
	return (var1 or var4.Features:FindFirstChild("Tree")):WaitForChild("Upgrading"):WaitForChild("Ring"):WaitForChild(str1)
end

tbl3 = {
	Text = ("Buy <font color=\"#%*\">More Wood</font>"):format(var13),
	Stat = "WoodMoreWood",
	Amount = 1,
	Image = "Wood",
}

tbl3.Arrow = function()
	local var1 = var3:FindFirstChild("WoodUpgrades")
	local str1 = "WoodArrow"
	return (var1 or var4.Features:FindFirstChild("WoodUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl4 = {
	Text = ("Evolve your <font color=\"#%*\">Cucumber</font>"):format(var27),
	Stat = "Seed",
	Amount = 7,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Cucumber",
}

tbl5 = {
	Text = ("Harvest <font color=\"#%*\">50k Wood</font>"):format(var13),
	Stat = "Wood",
	Amount = 50000,
	Image = "Wood",
}

tbl5.Arrow = Tree
tbl6 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash4",
	Amount = 1,
	Image = "Cash",
}

tbl6.Arrow = var44
tbl7 = {
	Text = ("Get <font color=\"#%*\">750Qd Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 7.5e+17,
	Image = "Cash",
}

tbl7.Arrow = var39
tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater2",
	Amount = 1,
	Image = "Water",
}

tbl8.Arrow = var58
tbl9 = {
	Text = ("Get <font color=\"#%*\">2.5Qn Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 2.5e+18,
	Image = "Cash",
}

tbl9.Arrow = var39
tbl10 = {
	Text = ("Get  <font color=\"#%*\">Harvest 1</font>"):format(var14),
	Stat = "Harvest",
	Amount = 1,
	Image = "Harvest",
	Funnel = "Get Harvest 1",
}

local function HarvestBoard()
	local var1 = var3:FindFirstChild("Harvest")
	local str1 = "HarvestArrow"
	return (var1 or var4.Features:FindFirstChild("Harvest")):WaitForChild("Board"):WaitForChild(str1)
end

tbl10.Arrow = HarvestBoard
tbl11 = {
	Text = ("Get <font color=\"#%*\">25Qn Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 2.5e+19,
	Image = "Cash",
}

tbl11.Arrow = var39
tbl12 = {
	Text = ("Get  <font color=\"#%*\">Harvest 2</font>"):format(var14),
	Stat = "Harvest",
	Amount = 2,
	Image = "Harvest",
	Funnel = "Get Harvest 2",
}

tbl12.Arrow = HarvestBoard
tbl16 = {
	Text = ("Evolve to after <font color=\"#%*\">Tomato</font>"):format(var28),
	Stat = "Seed",
	Amount = 8,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Tomato",
}

tbl13 = {
	Text = ("Harvest <font color=\"#%*\">50M Wood</font>"):format(var13),
	Stat = "Wood",
	Amount = 50000000,
	Image = "Wood",
}

tbl13.Arrow = Tree
tbl14 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash5",
	Amount = 1,
	Image = "Cash",
}

tbl14.Arrow = var45
tbl17 = {
	Text = ("Get <font color=\"#%*\">10Sx Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1e+22,
	Image = "Cash",
}

tbl17.Arrow = var39
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get  <font color=\"#%*\">Harvest 3</font>"):format(var14),
	Stat = "Harvest",
	Amount = 3,
	Image = "Harvest",
	Funnel = "Get Harvest 3",
}

tbl1.Arrow = HarvestBoard
tbl2 = {
	Text = ("Get <font color=\"#%*\">150Sx Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1.5e+23,
	Image = "Cash",
}

tbl2.Arrow = var39
tbl3 = {
	Text = ("Get  <font color=\"#%*\">Harvest 4</font>"):format(var14),
	Stat = "Harvest",
	Amount = 4,
	Image = "Harvest",
	Funnel = "Get Harvest 4",
}

tbl3.Arrow = HarvestBoard
tbl4 = {
	Text = ("Convert <font color=\"#%*\">10Sx Soil</font>"):format(var11),
	Stat = "Soil",
	Amount = 1e+22,
	Image = "Soil",
}

tbl4.Arrow = SoilBoard
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "SoilMoreCash",
	Amount = 11,
	Image = "Cash",
	Funnel = "Buy Soil More Cash 2",
}

tbl5.Arrow = SoilMoreCash
tbl6 = {
	Text = ("Evolve to after <font color=\"#%*\">Corn</font>"):format(var29),
	Stat = "Seed",
	Amount = 9,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Corn",
}

tbl7 = {
	Text = ("Get <font color=\"#%*\">500B Water</font>"):format(var12),
	Stat = "Water",
	Amount = 500000000000,
	Image = "Water",
}

tbl7.Arrow = WaterModel
tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Soil</font>"):format(var11),
	Stat = "TreeMoreSoil2",
	Amount = 1,
	Image = "Soil",
}

tbl8.Arrow = var56
tbl9 = {
	Text = ("Convert <font color=\"#%*\">50Sp Soil</font>"):format(var11),
	Stat = "Soil",
	Amount = 5e+25,
	Image = "Soil",
}

tbl9.Arrow = SoilBoard
tbl10 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater4",
	Amount = 1,
	Image = "Water",
}

tbl10.Arrow = var59
tbl11 = {
	Text = ("Get <font color=\"#%*\">100Sp Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1e+26,
	Image = "Cash",
}

tbl11.Arrow = var39
tbl12 = {
	Text = ("Get  <font color=\"#%*\">Harvest 5</font>"):format(var14),
	Stat = "Harvest",
	Amount = 5,
	Image = "Harvest",
	Funnel = "Get Harvest 5",
}

tbl12.Arrow = HarvestBoard
tbl16 = {
	Text = ("Get  <font color=\"#%*\">10 Grass</font>"):format(var15),
	Stat = "Grass",
	Amount = 10,
	Image = "Grass",
}

local function BarnField()
	local var1 = var3:FindFirstChild("Barn")
	local str1 = "Field"
	return (var1 or var4.Features:FindFirstChild("Barn")):WaitForChild(str1)
end

tbl16.Arrow = BarnField
tbl13 = {
	Text = ("Upgrade your  <font color=\"#%*\">Doggy</font>"):format(var36),
	Stat = "PetLevel",
	Amount = 1,
	Image = "Pet",
}

local function PetHolder()
	local var1 = var3:FindFirstChild("Barn")
	local str1 = "Holder"
	return (var1 or var4.Features:FindFirstChild("Barn")):WaitForChild(str1)
end

tbl13.Arrow = PetHolder
tbl14 = {
	Text = ("Buy <font color=\"#%*\">More Grass</font>"):format(var15),
	Stat = "GrassMoreGrass",
	Amount = 1,
	Image = "Grass",
}

tbl14.Arrow = function()
	local var1 = var3:FindFirstChild("GrassUpgrades")
	local str1 = "GrassArrow"
	return (var1 or var4.Features:FindFirstChild("GrassUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	{
		Text = ("Evolve to after <font color=\"#%*\">Radish</font>"):format(var30),
		Stat = "Seed",
		Amount = 10,
		Arrow = "Seed",
		Image = "Seed",
		Funnel = "Evolve your Radish",
	},
}

tbl1 = {
	Text = ("Get  <font color=\"#%*\">50 Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 50,
	Image = "Paper",
}

local function ResearchTable()
	local var1 = var3:FindFirstChild("Research")
	local str1 = "Top"
	return (var1 or var4.Features:FindFirstChild("Research")):WaitForChild("Table"):WaitForChild(str1)
end

tbl1.Arrow = ResearchTable
tbl2 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "ResearchMoreCash",
	Amount = 1,
	Image = "Cash",
}

local function ResearchShopRing()
	local var1 = var3:FindFirstChild("Research")
	local str1 = "Main"
	return (var1 or var4.Features:FindFirstChild("Research")):WaitForChild("Ring"):WaitForChild(str1)
end

tbl2.Arrow = ResearchShopRing
tbl3 = {
	Text = ("Upgrade your  <font color=\"#%*\">Strawberry</font>"):format(var31),
	Stat = "SeedLevel",
	Amount = 5,
	Arrow = "Seed",
	Image = "Seed",
}

tbl4 = {
	Text = ("Get  <font color=\"#%*\">1.25M Grass</font>"):format(var15),
	Stat = "Grass",
	Amount = 1250000,
	Image = "Grass",
}

tbl4.Arrow = BarnField
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More Walkspeed</font>"):format(var10),
	Stat = "TreeMoreWalkspeed2",
	Amount = 1,
	Image = "Walkspeed",
}

tbl5.Arrow = var71
tbl6 = {
	Text = ("Get <font color=\"#%*\">50Oc Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 5e+28,
	Image = "Cash",
}

tbl6.Arrow = var39
tbl7 = {
	Text = ("Buy <font color=\"#%*\">Better Combo</font>"):format(var9),
	Stat = "TreeBetterCombo2",
	Amount = 1,
	Image = "Cash",
}

tbl7.Arrow = var70
tbl8 = {
	Text = ("Harvest <font color=\"#%*\">2.5T Wood</font>"):format(var13),
	Stat = "Wood",
	Amount = 2500000000000,
	Image = "Wood",
}

tbl8.Arrow = Tree
tbl9 = {
	Text = ("Buy <font color=\"#%*\">More Combo Limit</font>"):format(var9),
	Stat = "TreeMoreComboLimit",
	Amount = 1,
	Image = "Cash",
}

tbl9.Arrow = var76
tbl10 = {
	Text = ("Get <font color=\"#%*\">50Oc Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 5e+28,
	Image = "Cash",
}

tbl10.Arrow = var39
tbl11 = {
	Text = ("Buy <font color=\"#%*\">More Paper</font>"):format(var17),
	Stat = "TreeMorePaper2",
	Amount = 1,
	Image = "Paper",
}

tbl11.Arrow = var77
tbl12 = {
	Text = ("Get  <font color=\"#%*\">2.5k Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 2500,
	Image = "Paper",
}

tbl12.Arrow = ResearchTable
tbl16 = {
	Text = ("Reach <font color=\"#%*\">Research Level 2</font>"):format(var16),
	Stat = "ResearchLevel",
	Amount = 2,
	Image = "Research",
	Funnel = "Reach Research Level 2",
}

local function ResearchButton()
	local var1 = var3:FindFirstChild("Research")
	local str1 = "ResearchArrow"
	return (var1 or var4.Features:FindFirstChild("Research")):WaitForChild("Board"):WaitForChild(str1)
end

tbl16.Arrow = ResearchButton
tbl13 = {
	Text = ("Evolve to after <font color=\"#%*\">Strawberry</font>"):format(var31),
	Stat = "Seed",
	Amount = 11,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve your Strawberry",
}

tbl14 = {
	Text = ("Get <font color=\"#%*\">750No Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 7.5e+32,
	Image = "Cash",
}

tbl14.Arrow = var39
tbl17 = {
	Text = ("Get  <font color=\"#%*\">Replant 1</font>"):format(var18),
	Stat = "Replant",
	Amount = 1,
	Image = "Replant",
	Funnel = "Get Replant 1",
}

local function ReplantButton()
	local var1 = var3:FindFirstChild("Replant")
	local str1 = "ReplantArrow"
	return (var1 or var4.Features:FindFirstChild("Replant")):WaitForChild("Board"):WaitForChild(str1)
end

tbl17.Arrow = ReplantButton
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get <font color=\"#%*\">25De Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 2.5e+34,
	Image = "Cash",
}

tbl1.Arrow = var39
tbl2 = {
	Text = ("Get  <font color=\"#%*\">Replant 2</font>"):format(var18),
	Stat = "Replant",
	Amount = 2,
	Image = "Replant",
	Funnel = "Get Replant 2",
}

tbl2.Arrow = ReplantButton
tbl3 = {
	Text = ("Buy <font color=\"#%*\">More Paper</font>"):format(var17),
	Stat = "TreeMorePaper4",
	Amount = 1,
	Image = "Cash",
}

tbl3.Arrow = var67
tbl4 = {
	Text = ("Get  <font color=\"#%*\">Replant 3</font>"):format(var18),
	Stat = "Replant",
	Amount = 3,
	Image = "Replant",
	Funnel = "Get Replant 3",
}

tbl4.Arrow = ReplantButton
tbl5 = {
	Text = ("Research  <font color=\"#%*\">More Cash</font> in the lab"):format(var9),
	Stat = "LabMoreCash",
	Amount = 1,
	Image = "Research",
}

local function LabShopRing()
	local var1 = var3:FindFirstChild("Lab")
	local str1 = "Main"
	return (var1 or var4.Features:FindFirstChild("Lab")):WaitForChild("Ring"):WaitForChild(str1)
end

tbl5.Arrow = LabShopRing
tbl6 = {
	Text = ("Evolve to after <font color=\"#%*\">Orange</font>"):format(var32),
	Stat = "Seed",
	Amount = 12,
	Arrow = "Seed",
	Image = "Seed",
}

tbl7 = {
	Text = ("Get <font color=\"#%*\">2.5Qn Water</font>"):format(var12),
	Stat = "Water",
	Amount = 2.5e+18,
	Image = "Water",
}

tbl7.Arrow = WaterModel
tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Range</font>"):format(var10),
	Stat = "TreeMoreRange2",
	Amount = 1,
	Image = "Range",
}

tbl8.Arrow = var72
tbl9 = {
	Text = ("Get <font color=\"#%*\">100UDe Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1e+38,
	Image = "Cash",
}

tbl9.Arrow = var39
tbl10 = {
	Text = ("Buy <font color=\"#%*\">Faster Research</font>"):format(var16),
	Stat = "TreeFasterResearch",
	Amount = 1,
	Image = "Research",
}

tbl10.Arrow = var73
tbl11 = {
	Text = ("Get  <font color=\"#%*\">1Qd Grass</font>"):format(var15),
	Stat = "Grass",
	Amount = 1000000000000000,
	Image = "Grass",
}

tbl11.Arrow = BarnField
tbl12 = {
	Text = ("Buy <font color=\"#%*\">More Paper</font>"):format(var17),
	Stat = "TreeMorePaper5",
	Amount = 1,
	Image = "Paper",
}

tbl12.Arrow = var68
tbl16 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash8",
	Amount = 1,
	Image = "Cash",
}

tbl16.Arrow = var46
tbl13 = {
	Text = ("Get  <font color=\"#%*\">1B Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 1000000000,
	Image = "Paper",
}

tbl13.Arrow = ResearchTable
tbl14 = {
	Text = ("Reach <font color=\"#%*\">Research Level 4</font>"):format(var16),
	Stat = "ResearchLevel",
	Amount = 4,
	Image = "Research",
}

tbl14.Arrow = ResearchButton
tbl17 = {
	Text = ("Buy <font color=\"#%*\">More Soil Upgrades</font> limit"):format(var11),
	Stat = "ResearchMoreSoilCap",
	Amount = 1,
	Image = "Soil",
}

tbl17.Arrow = ResearchShopRing
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get <font color=\"#%*\">1DDe Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1e+39,
	Image = "Cash",
}

tbl1.Arrow = var39
tbl2 = {
	Text = ("Get  <font color=\"#%*\">Replant 4</font>"):format(var18),
	Stat = "Replant",
	Amount = 4,
	Image = "Replant",
	Funnel = "Get Replant 4",
}

tbl2.Arrow = ReplantButton
tbl3 = {
	Text = ("Get  <font color=\"#%*\">15B Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 15000000000,
	Image = "Paper",
}

tbl3.Arrow = ResearchTable
tbl4 = {
	Text = ("Buy <font color=\"#%*\">Noob</font> Scientist"):format((Color3.fromRGB(255, 255, 56):ToHex())),
	Stat = "Scientist1",
	Amount = true,
	Image = "rbxassetid://86320950698701",
}

local function ScientistRing()
	local var1 = var3:FindFirstChild("Scientists")
	local str1 = "Main"
	return (var1 or var4.Features:FindFirstChild("Scientists")):WaitForChild("Ring"):WaitForChild(str1)
end

tbl4.Arrow = ScientistRing
tbl5 = {
	Text = ("Evolve to after <font color=\"#%*\">Lemon</font>"):format(var33),
	Stat = "Seed",
	Amount = 13,
	Arrow = "Seed",
	Image = "Seed",
}

tbl6 = {
	Text = ("Buy <font color=\"#%*\">Faster Research</font>"):format(var16),
	Stat = "TreeFasterResearch2",
	Amount = 1,
	Image = "Research",
}

tbl6.Arrow = var74
tbl7 = {
	Text = ("Get  <font color=\"#%*\">100B Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 100000000000,
	Image = "Paper",
}

tbl7.Arrow = ResearchTable
tbl8 = {
	Text = ("Buy <font color=\"#%*\">Amateur</font> Scientist"):format(var10),
	Stat = "Scientist2",
	Amount = true,
	Image = "rbxassetid://108486676808435",
}

tbl8.Arrow = ScientistRing
tbl9 = {
	Text = ("Evolve to after  <font color=\"#%*\">Bear</font>"):format(var37),
	Stat = "Pet",
	Amount = 5,
	Image = "Pet",
}

tbl9.Arrow = PetHolder
tbl10 = {
	Text = ("Buy <font color=\"#%*\">More Paper</font>"):format(var17),
	Stat = "TreeMorePaper6",
	Amount = 1,
	Image = "Paper",
}

tbl10.Arrow = var69
tbl11 = {
	Text = ("Get <font color=\"#%*\">15Qn Water</font>"):format(var12),
	Stat = "Water",
	Amount = 1.5e+19,
	Image = "Water",
}

tbl11.Arrow = WaterModel
tbl12 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash9",
	Amount = 1,
	Image = "Cash",
}

tbl12.Arrow = var47
tbl16 = {
	Text = ("Get  <font color=\"#%*\">150B Paper</font>"):format(var17),
	Stat = "Paper",
	Amount = 150000000000,
	Image = "Paper",
}

tbl16.Arrow = ResearchTable
tbl13 = {
	Text = ("Buy <font color=\"#%*\">Farmer</font> Scientist"):format(var15),
	Stat = "Scientist3",
	Amount = true,
	Image = "rbxassetid://113506866009879",
}

tbl13.Arrow = ScientistRing
tbl14 = {
	Text = ("Get <font color=\"#%*\">25TDe Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 2.5e+43,
	Image = "Cash",
}

tbl14.Arrow = var39
tbl17 = {
	Text = ("Get  <font color=\"#%*\">Replant 5</font>"):format(var18),
	Stat = "Replant",
	Amount = 5,
	Image = "Replant",
	Funnel = "Get Replant 5",
}

tbl17.Arrow = ReplantButton
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Get <font color=\"#%*\">15TDe Cash</font>"):format(var9),
	Stat = "Cash",
	Amount = 1.5e+43,
	Image = "Cash",
}

tbl1.Arrow = var39
tbl2 = {
	Text = ("Buy <font color=\"#%*\">More Grass</font>"):format(var15),
	Stat = "TreeMoreGrass4",
	Amount = 1,
	Image = "Grass",
}

tbl2.Arrow = var75
tbl3 = {
	Text = ("Evolve to after  <font color=\"#%*\">Monkey</font>"):format(var37),
	Stat = "Pet",
	Amount = 6,
	Image = "Pet",
}

tbl3.Arrow = PetHolder
tbl4 = {
	Text = ("Buy <font color=\"#%*\">More Water</font>"):format(var12),
	Stat = "TreeMoreWater5",
	Amount = 1,
	Image = "Water",
}

tbl4.Arrow = var60
tbl5 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash10",
	Amount = 1,
	Image = "Water",
}

tbl5.Arrow = var48
tbl6 = {
	Text = ("Evolve to after <font color=\"#%*\">Guava</font>"):format(var34),
	Stat = "Seed",
	Amount = 14,
	Arrow = "Seed",
	Image = "Seed",
	Funnel = "Evolve to after Guava",
}

tbl7 = {
	Text = ("Claim an <font color=\"#%*\">Achievement</font>"):format(var19),
	Stat = "AchievementsClaimed",
	Amount = 1,
	Image = "Achievement",
}

tbl7.Arrow = function()
	local var1 = var3:FindFirstChild("Achievements")
	local str1 = "Board"
	return (var1 or var4.Features:FindFirstChild("Achievements")):WaitForChild(str1)
end

tbl8 = {
	Text = ("Buy <font color=\"#%*\">More Cash</font>"):format(var9),
	Stat = "TreeMoreCash11",
	Amount = 1,
	Image = "Cash",
}

tbl8.Arrow = var49
tbl9 = {
	Text = ("Collect a <font color=\"#%*\">Leaf</font>"):format(var20),
	Stat = "LeavesCollected",
	Amount = 1,
	Image = "Leaves",
}

tbl9.Arrow = function()
	local var1 = var3:FindFirstChild("Leaf")
	local str1 = "ShownSpawnable"
	return (var1 or var4.Features:FindFirstChild("Leaf")):WaitForChild(str1)
end

tbl10 = {
	Text = ([[Deposit <font color="#%*">Leaves</font> into <font color="#%*">More Cash</font>]]):format(var20, var9),
	Stat = "LeafMoreCash",
	Amount = 1,
	Image = "Cash",
}

tbl10.Arrow = function()
	local var1 = var3:FindFirstChild("LeafUpgrades")
	local str1 = "CashArrow"
	return (var1 or var4.Features:FindFirstChild("LeafUpgrades")):WaitForChild("Board"):WaitForChild(str1)
end

tbl11 = {
	Text = ("Buy <font color=\"#%*\">Gardener</font> Scientist"):format(var20),
	Stat = "Scientist4",
	Amount = true,
	Image = "rbxassetid://113506866009879",
}

tbl11.Arrow = ScientistRing
tbl12 = {
	Text = ("Buy <font color=\"#%*\">More Leaves</font>"):format(var20),
	Stat = "TreeMoreLeaves2",
	Amount = 1,
	Image = "Leaves",
}

tbl12.Arrow = var50
tbl16 = {
	Text = ("Buy <font color=\"#%*\">More Grass</font>"):format(var15),
	Stat = "TreeMoreGrass5",
	Amount = 1,
	Image = "Grass",
}

tbl16.Arrow = var51
tbl13 = {
	Text = ("Evolve to after <font color=\"#%*\">Elephant</font>"):format(var38),
	Stat = "Pet",
	Amount = 7,
	Image = "Pet",
}

tbl13.Arrow = PetHolder
tbl14 = {
	Text = ("Research <font color=\"#%*\">More Leaves</font> in the lab"):format(var20),
	Stat = "LabMoreLeaves",
	Amount = 1,
	Image = "Research",
}

tbl14.Arrow = LabShopRing
tbl17 = {
	Text = ("Buy <font color=\"#%*\">Better Collection</font>"):format(var20),
	Stat = "TreeBetterLeafCollect2",
	Amount = 1,
	Image = "Range",
}

tbl17.Arrow = var52
tbl15 = {
	tbl1,
	tbl2,
	tbl3,
	tbl4,
	tbl5,
	tbl6,
	tbl7,
	tbl8,
	tbl9,
	tbl10,
	tbl11,
	tbl12,
	tbl16,
	tbl13,
	tbl14,
	tbl17,
}

tbl1 = {
	Text = ("Buy <font color=\"#%*\">More Leaves</font>"):format(var20),
	Stat = "TreeMoreLeaves3",
	Amount = 1,
	Image = "Leaves",
}

tbl1.Arrow = var53
tbl2 = {
	Text = ("Buy <font color=\"#%*\">More Research Cap</font>"):format(var16),
	Stat = "TreeMorePaperUpgradesCap",
	Amount = 1,
	Image = "Research",
}

tbl2.Arrow = var54
tbl15 = {
	tbl1,
	tbl2,
	{
		Text = ("Evolve to after <font color=\"#%*\">Grape</font>"):format(var35),
		Stat = "Seed",
		Amount = 15,
		Arrow = "Seed",
		Image = "Seed",
	},
}

return { First = 21, Stages = tbl15 }

--- ReplicatedStorage.Modules.Shared.Colours [ModuleScript]
-- y u r i

local num1 = 193
local num2 = 255
local num3 = 193
local var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 46
num3 = 255
local num4 = 81
local var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 115
num4 = 255
local num5 = 84
num1 = 1
local tbl1 = { Colour = Color3.fromRGB(75, 255, 81) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
local tbl2 = { Afford = tbl1 }
num1 = 255
num2 = 137
num3 = 139
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 255
num3 = 28
num4 = 32
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 255
num4 = 138
num5 = 140
num1 = 1
tbl1 = { Colour = Color3.fromRGB(255, 60, 63) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
tbl2.Expensive = tbl1
num1 = 250
num2 = 255
num3 = 149
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 255
num3 = 241
num4 = 49
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 250
num4 = 255
num5 = 149
num1 = 1
tbl1 = { Colour = Color3.fromRGB(241, 255, 88) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
tbl2.Yellow = tbl1
num1 = 255
num2 = 255
num3 = 255
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 138
num3 = 138
num4 = 138
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 255
num4 = 255
num5 = 255
num1 = 1
tbl1 = { Colour = Color3.fromRGB(167, 167, 167) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
tbl2.Maxed = tbl1
num1 = 255
num2 = 215
num3 = 166
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 255
num3 = 165
num4 = 39
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 255
num4 = 234
num5 = 171
num1 = 1
tbl1 = { Colour = Color3.fromRGB(255, 215, 12) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
tbl2.MaxButton = tbl1
tbl1 = { Visible = Color3.fromRGB(255, 255, 78) }
tbl1.Purchased = Color3.fromRGB(111, 255, 116)
tbl1.Upgradeable = Color3.fromRGB(162, 255, 155)
tbl1.Locked = Color3.fromRGB(27, 42, 53)
tbl2.UpgradeTree = tbl1
num1 = 150
num2 = 58
num3 = 255
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 98
num3 = 38
num4 = 167
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 150
num4 = 58
num5 = 255
num1 = 1
tbl1 = { Colour = Color3.fromRGB(150, 58, 255) }
tbl1.Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) })
tbl2.Evolve = tbl1
num1 = 255
num2 = 255
num3 = 255
var1 = ColorSequenceKeypoint.new(0, Color3.fromRGB(num1, num2, num3))
num2 = 49
num3 = 165
num4 = 255
var2 = ColorSequenceKeypoint.new(0.5, Color3.fromRGB(num2, num3, num4))
num3 = 64
num4 = 69
num5 = 161
num1 = 1
tbl1 = { Gradient = ColorSequence.new({ var1, var2, ColorSequenceKeypoint.new(num1, Color3.fromRGB(num3, num4, num5)) }) }
tbl1.Colour = Color3.fromRGB(49, 165, 255)
tbl2.Challenge = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.Upgrades [ModuleScript]
-- y u r i

local tbl1 = {}
for k1, v1 in script:GetChildren() do
	tbl1[v1.Name] = require(v1)
end

return tbl1

--- ReplicatedStorage.Modules.Shared.Upgrades.Soil [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Modules.Shared.BigNum)
return {
	Currency = "Soil",
	Display = "Soil",
	Board = "SoilUpgrades",
	Upgrades = {
		SoilMoreCash = {
			Rank = 1,
			Format = "x%s",
			Display = "More Cash",
			Icon = "Cash",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 4
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(arg1)
				local num1 = 10
				local var1 = arg1.ResearchUpgrades.ResearchMoreSoilCap.Value
				if 4 <= arg1.Stats.Harvest.Value then
					num1 = num1 + 5
				end

				return num1 + var1
			end,
			Info = function(arg1)
				local tbl1 = {}
				local var2
				if arg1 < 10 then
					var2 = 7 ^ arg1
				else
					var2 = if 10 <= arg1 and arg1 < 15 then var1.mul(1e+22, 50 ^ (arg1 - 10)) else var1.mul(1e+44, 10000 ^ (arg1 - 15))
				end

				tbl1.Price = var2
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		SoilFasterSpawn = {
			Rank = 2,
			Format = "-%ss",
			Display = "Faster Spawn",
			Icon = "Time",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 4
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 5
			end,
			Info = function(arg1)
				return { Price = if arg1 < 10 then 6 ^ arg1 * 2 else 100 ^ (arg1 + 1), Reward = arg1 * 0.05 }
			end,
		},
		SoilMoreSoil = {
			Rank = 3,
			Format = "x%s",
			Display = "More Soil",
			Icon = "Soil",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 4
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(arg1)
				local num1 = 10
				local var1 = arg1.ResearchUpgrades.ResearchMoreSoilCap.Value
				if 4 <= arg1.Stats.Harvest.Value then
					num1 = num1 + 5
				end

				return num1 + var1
			end,
			Info = function(arg1)
				local tbl1 = {}
				local var2
				if arg1 < 10 then
					var2 = 7 ^ (arg1 + 3)
				else
					var2 = if 10 <= arg1 and arg1 < 15 then var1.mul(1e+23, 100 ^ (arg1 - 10)) else var1.mul(1e+45, 10000 ^ (arg1 - 15))
				end

				tbl1.Price = var2
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
	},
}

--- ReplicatedStorage.Modules.Shared.Upgrades.Water [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Modules.Shared.BigNum)
return {
	Currency = "Water",
	Display = "Water",
	Board = "WaterUpgrades",
	Upgrades = {
		WaterMoreCash = {
			Rank = 1,
			Format = "x%s",
			Display = "More Cash",
			Icon = "Cash",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(arg1)
				return 10 + arg1.ResearchUpgrades.ResearchMoreWaterCap.Value
			end,
			Info = function(arg1)
				local var2 = if arg1 <= 10 then var1.mul(2, 5 ^ (arg1 + 1)) else var1.mul(1e+18, 10 ^ (arg1 - 10))
				local tbl1 = { Price = var2 }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		WaterFasterSpawn = {
			Rank = 2,
			Format = "-%ss",
			Display = "Faster Spawn",
			Icon = "Time",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 5
			end,
			Info = function(arg1)
				local num1 = 2.5
				local var2 = arg1
				local tbl1 = { Price = var1.mul(100, var1.pow(num1, var2)) }
				tbl1.Reward = arg1 * 0.02
				return tbl1
			end,
		},
		WaterMoreXP = {
			Rank = 3,
			Format = "x%s",
			Display = "More XP",
			Icon = "XP",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(arg1)
				return 10 + arg1.ResearchUpgrades.ResearchMoreWaterCap.Value
			end,
			Info = function(arg1)
				local var2 = if arg1 < 10 then var1.mul(1000, 5 ^ arg1) else var1.mul(1e+19, 10 ^ (arg1 - 10))
				local tbl1 = { Price = var2 }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
	},
}

--- ReplicatedStorage.Modules.Shared.Upgrades.Wood [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Modules.Shared.BigNum)
return {
	Currency = "Wood",
	Display = "Wood",
	Board = "WoodUpgrades",
	Upgrades = {
		WoodMoreCash = {
			Rank = 1,
			Format = "x%s",
			Display = "More Cash",
			Icon = "Cash",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 6
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(2, 5 ^ (arg1 + 1)) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		WoodMoreWater = {
			Rank = 2,
			Format = "x%s",
			Display = "More Water",
			Icon = "Water",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 6
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(6, 5 ^ (arg1 + 1)) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		WoodMoreWood = {
			Rank = 3,
			Format = "x%s",
			Display = "More Wood",
			Icon = "Wood",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestSeed.Value
				local num1 = 6
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(100, 5 ^ arg1) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
	},
}

--- ReplicatedStorage.Modules.Shared.Upgrades.Grass [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Modules.Shared.BigNum)
return {
	Currency = "Grass",
	Display = "Grass",
	Board = "GrassUpgrades",
	Upgrades = {
		GrassMoreGrass = {
			Rank = 1,
			Format = "x%s",
			Display = "More Grass",
			Icon = "Grass",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestHarvest.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestHarvest",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(50, (5 + arg1 / 10) ^ arg1) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		GrassMoreWater = {
			Rank = 2,
			Format = "x%s",
			Display = "More Water",
			Icon = "Water",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestHarvest.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestHarvest",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(200, 10 ^ arg1) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
		GrassMoreCash = {
			Rank = 3,
			Format = "x%s",
			Display = "More Cash",
			Icon = "Cash",
			Unlocked = function(arg1)
				local var2 = arg1.HighestStats.HighestHarvest.Value
				local num1 = 5
				return var1.gte(var2, num1)
			end,
			ChangeStat = "HighestHarvest",
			Cap = function(_)
				return 10
			end,
			Info = function(arg1)
				local tbl1 = { Price = var1.mul(500, 10 ^ arg1) }
				tbl1.Reward = 2 ^ arg1
				return tbl1
			end,
		},
	},
}

--- ReplicatedStorage.Modules.Shared.PlayerColour [ModuleScript]
-- y u r i

local tbl1 = {
	Color3.new(0.99215686274509807, 0.16078431372549021, 0.2627450980392157),
	Color3.new(0.0039215686274509803, 0.63529411764705879, 1),
	Color3.new(0.0078431372549019607, 0.72156862745098038, 0.3411764705882353),
	BrickColor.new("Bright violet").Color,
	BrickColor.new("Bright orange").Color,
	BrickColor.new("Bright yellow").Color,
	BrickColor.new("Light reddish violet").Color,
	BrickColor.new("Brick yellow").Color,
}

NAME_COLORS = tbl1
tbl1 = function(arg1)
	local num1 = 0
	for i1 = 1, #arg1 do
		local var1 = string.byte((string.sub(arg1, i1, i1)))
		local var2 = #arg1 - i1 + 1
		if #arg1 % 2 == 1 then
			var2 = var2 - 1
		end

		if 2 <= var2 % 4 then
			var1 = -var1
		end

		num1 = num1 + var1
	end

	return num1
end

return function(arg1)
	return NAME_COLORS[tbl1(arg1) % #NAME_COLORS + 1]
end

--- ReplicatedStorage.Modules.Shared.Requirements [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
require(var1.Modules.Shared.BigNum)
return {
	Soil = { Stat = "Cash", Amount = 100000 },
	Combo = { Unlocked = function(arg1)
		return 1 <= arg1.UpgradeTree.TreeUnlockCombo.Value
	end },
}

--- ReplicatedStorage.Modules.Shared.ResetLayers [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.BigNum)
require(var2.Multipliers)
local var3 = require(var1.Framework)
local var4 = require(var2.Upgrades)
local var5 = require(var2.UpgradeTree)
local var6 = require(var2.Replant)
local tbl1 = {
	Soil = function(arg1)
		local var1 = var3.Stat.GetDataFolder(arg1).Stats.Cash
		var1.Value = "0"
	end,
	Harvest = function(arg1)
		local var2 = var3.Stat.GetDataFolder(arg1)
		local var7 = var2.Stats
		var7.Cash.Value = "0"
		var7.Soil.Value = "0"
		var7.Water.Value = "0"
		var7.Wood.Value = "0"
		var2.Tree.WaterDeposited.Value = "0"
		local var8 = var2.SoilUpgrades
		local var9 = var2.WaterUpgrades
		local var10 = var2.WoodUpgrades
		if not var6.KeepsPlantOnHarvest(var2) then
			var7.Seed.Value = 0
			var7.SeedLevel.Value = 0
		end

		if not var6.KeepsLevelsOnHarvest(var2) then
			var7.WaterXP.Value = "0"
			var7.WaterLevel.Value = 0
			var7.TreeLevel.Value = 0
		end

		for k1, v1 in var4.Soil.Upgrades, nil do
			var8[k1].Value = 0
		end

		for k2, v2 in var4.Water.Upgrades, nil do
			var9[k2].Value = 0
		end

		for k3, v3 in var4.Wood.Upgrades, nil do
			var10[k3].Value = 0
		end

		for k4, v4 in var5, nil do
			if v4.Tier > 1 then
				continue
			end

			var2.UpgradeTree[k4].Value = 0
		end

		var1.Remotes.ResetTables:Fire(arg1)
	end,
}

tbl1.Replant = function(arg1)
	local var1 = var3.Stat.GetDataFolder(arg1)
	local var2 = var1.Stats
	var2.Harvest.Value = 0
	var2.Grass.Value = "0"
	var2.Pet.Value = 0
	var2.PetLevel.Value = 0
	local var6 = var1.GrassUpgrades
	for k1, v1 in var4.Grass.Upgrades, nil do
		var6[k1].Value = 0
	end

	for k2, v2 in var5, nil do
		if v2.Tier > 2 then
			continue
		end

		var1.UpgradeTree[k2].Value = 0
	end

	tbl1.Harvest(arg1)
	var2.Seed.Value = 0
	var2.SeedLevel.Value = 0
	var2.WaterXP.Value = "0"
	var2.WaterLevel.Value = 0
	var2.TreeLevel.Value = 0
end

return tbl1

--- ReplicatedStorage.Modules.Shared.Robux [ModuleScript]
-- y u r i

return {
	Passes = {
		MoreResearchSpeedGamepass = { ID = 1970515474, DataName = "MoreResearchSpeedGamepass" },
		MoreWalkspeedGamepass = { ID = 1966149410, DataName = "MoreWalkspeedGamepass" },
		MoreGrassGamepass = { ID = 1969599711, DataName = "MoreGrassGamepass" },
		MoreXPGamepass = { ID = 1963659802, DataName = "MoreXPGamepass" },
		FasterChoppingSpeedGamepass = { ID = 1968511683, DataName = "FasterChoppingSpeedGamepass" },
		MoreSpawnSpeedGamepass = { ID = 1969379777, DataName = "MoreSpawnSpeedGamepass" },
		MoreSpawnLimitGamepass = { ID = 1968935679, DataName = "MoreSpawnLimitGamepass" },
	},
	Products = {
		[3711825526] = { Reward = 5, Type = "Ruby", DisplayName = "+5 Ruby" },
		[3711825574] = { Reward = 25, Type = "Ruby", DisplayName = "+25 Ruby" },
		[3711825602] = { Reward = 50, Type = "Ruby", DisplayName = "+50 Ruby" },
		[3711825661] = { Reward = 150, Type = "Ruby", DisplayName = "+150 Ruby" },
		[3711825713] = { Reward = 1, Type = "Bundle", DisplayName = "Gamepass Bundle" },
		[3711782941] = { Reward = 1, Type = "SkipDaily", DisplayName = "Skip Daily" },
		[3712934162] = { Reward = 1, Type = "ExtraMultiplier", DisplayName = "x2 Cash", Stat = "ExtraCashTier" },
		[3712934173] = { Reward = 2, Type = "ExtraMultiplier", DisplayName = "x4 Cash", Stat = "ExtraCashTier" },
		[3711710351] = {
			Reward = 1,
			Type = "ExtraMultiplier",
			DisplayName = "x2 Water",
			Stat = "ExtraWaterTier",
		},
		[3711710361] = {
			Reward = 2,
			Type = "ExtraMultiplier",
			DisplayName = "x4 Water",
			Stat = "ExtraWaterTier",
		},
		[3711704748] = { Reward = 1, Type = "ExtraMultiplier", DisplayName = "x2 Wood", Stat = "ExtraWoodTier" },
		[3711704764] = { Reward = 2, Type = "ExtraMultiplier", DisplayName = "x4 Wood", Stat = "ExtraWoodTier" },
		[3713633009] = {
			Reward = 1,
			Type = "ExtraMultiplier",
			DisplayName = "x2 Grass",
			Stat = "ExtraGrassTier",
		},
		[3713633024] = {
			Reward = 2,
			Type = "ExtraMultiplier",
			DisplayName = "x4 Grass",
			Stat = "ExtraGrassTier",
		},
		[3713649721] = {
			Reward = 1,
			Type = "ExtraMultiplier",
			DisplayName = "x2 Paper",
			Stat = "ExtraPaperTier",
		},
		[3713649750] = {
			Reward = 2,
			Type = "ExtraMultiplier",
			DisplayName = "x4 Paper",
			Stat = "ExtraPaperTier",
		},
		[3711826627] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "MoreResearchSpeedGamepass",
			DisplayName = "x2 Research Speed",
		},
		[3711826665] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "MoreWalkspeedGamepass",
			DisplayName = "+15 Walkspeed",
		},
		[3711826692] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "MoreGrassGamepass",
			DisplayName = "x2 Grass",
		},
		[3711826707] = { Reward = 1, Type = "PassGift", DataName = "MoreXPGamepass", DisplayName = "x2 XP" },
		[3711826727] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "FasterChoppingSpeedGamepass",
			DisplayName = "50% Chopping Speed",
		},
		[3711826758] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "MoreSpawnSpeedGamepass",
			DisplayName = "50% Spawn Speed",
		},
		[3711826778] = {
			Reward = 1,
			Type = "PassGift",
			DataName = "MoreSpawnLimitGamepass",
			DisplayName = "+25 Spawn Limit",
		},
		[3711826442] = { Reward = 5, Type = "RubyGift", DisplayName = "5 Ruby" },
		[3711826480] = { Reward = 25, Type = "RubyGift", DisplayName = "25 Ruby" },
		[3711826552] = { Reward = 50, Type = "RubyGift", DisplayName = "50 Ruby" },
		[3711826578] = { Reward = 150, Type = "RubyGift", DisplayName = "+150 Ruby" },
		[3711826600] = { Reward = 50, Type = "BundleGift", DisplayName = "Gamepass Bundle" },
	},
}

--- ReplicatedStorage.Modules.Shared.Leaderboards [ModuleScript]
-- y u r i

local tbl1 = {
	Datastore = "CashR1",
	Colour = Color3.fromRGB(120, 255, 140),
	Rank = 1,
	Emoji = "\240\159\146\184",
	Stat = "TotalCash",
	F2P = true,
	F2PDatastore = "CashF2PR1",
	Text = "Total Cash",
	Folder = "Other",
}

local tbl2 = { HighestCash = tbl1 }
tbl1 = {
	Datastore = "PlayTimeR1",
	Colour = Color3.fromRGB(255, 255, 255),
	Rank = 2,
	Emoji = "\240\159\149\146",
	Stat = "PlayTime",
	Text = "Play Time",
	Folder = "Other",
	ShortenType = "Time",
}

tbl2.PlayTime = tbl1
tbl1 = {
	Datastore = "ClicksR1",
	Colour = Color3.fromRGB(255, 255, 255),
	Rank = 3,
	Emoji = "\240\159\149\146",
	Stat = "Clicks",
	Text = "Clicks",
	Folder = "Other",
	ShortenType = "Normal",
}

tbl2.Clicks = tbl1
tbl1 = {
	Datastore = "RobuxSpentR1",
	Colour = Color3.fromRGB(25, 203, 25),
	Rank = 4,
	Emoji = "\240\159\149\146",
	Stat = "RobuxSpent",
	Text = "Robux Spent",
	Folder = "Other",
	ShortenType = "Normal",
}

tbl2.RobuxSpent = tbl1
tbl1 = {
	Datastore = "CollectsR1",
	Colour = Color3.fromRGB(255, 255, 255),
	Stat = "Collects",
	Text = "Collects",
	Folder = "Other",
	ShortenType = "Normal",
}

tbl2.Collects = tbl1
return { Normal = tbl2 }

--- ReplicatedStorage.Modules.Shared.Proximity [ModuleScript]
-- y u r i

game:GetService("RunService")
local var1 = game:GetService("Players")
local tbl1 = {
	initialised = false,
	isInArea = function(arg1, arg2)
		local var2 = arg1.Character
		if var2 == nil then
			return false
		end

		local var4 = var2:FindFirstChild("HumanoidRootPart")
		if var4 == nil then
			return false
		end

		return (arg2.Position - var4.Position).Magnitude < arg2.Size.Magnitude / 2
	end,
}

local tbl2 = {}
tbl1.init = function()
	if tbl1.initialised then
		return
	end

	tbl1.initialised = true
	task.spawn(function()
		while task.wait(0.1) do
			for k1, v1 in tbl2, nil do
				if v1.updaterLeave then
					v1.updaterLeave()
				end

				if not v1.updaterEnter then
					continue
				end

				v1.updaterEnter()
			end
		end
	end)
end

local tbl3 = {}
tbl3.__index = tbl3
tbl3.init = function(arg1)
	local var2 = var1.LocalPlayer.Character
	var2 = var2 or var1.LocalPlayer.CharacterAdded:Wait()
	var2:WaitForChild("HumanoidRootPart")
	arg1.Magnitude = arg1.part.Size.Magnitude
	arg1.Position = arg1.part.Position
	arg1.OverlapParams = OverlapParams.new()
	arg1.OverlapParams.FilterDescendantsInstances = { var2 }
	arg1.OverlapParams.FilterType = Enum.RaycastFilterType.Include
	arg1.OverlapParams.MaxParts = 1
end

tbl3.getPlayers = function(arg1)
	local tbl1 = {}
	for k1, v1 in var1:GetPlayers() do
		local var2 = v1.Character
		if var2 == nil then
			continue
		end

		local var3 = var2:FindFirstChild("HumanoidRootPart")
		if var3 == nil then
			continue
		end

		if (arg1.Position - var3.Position).Magnitude >= arg1.Magnitude then
			continue
		end

		table.insert(tbl1, v1)
	end

	return tbl1
end

tbl3.isInArea = function(arg1)
	local var3 = var1.LocalPlayer.Character
	if var3 == nil then
		return false
	end

	if var3:FindFirstChild("HumanoidRootPart") == nil then
		return false
	end

	return #workspace:GetPartBoundsInBox(arg1.part:GetPivot(), arg1.part.Size, arg1.OverlapParams) == 1
end

tbl3.onEnter = function(arg1, arg2)
	arg1.enterfunc = arg2
	arg1.wasInArea = false
	arg1.updaterEnter = function()
		local var1 = arg1:isInArea()
		local var3 = var1
		if var3 then
			var3 = arg1.wasInArea == false
		end

		arg1.wasInArea = var1
		if var3 and 0.01 < os.clock() - arg1.debounce then
			arg1.debounce = os.clock()
			task.spawn(arg1.enterfunc, arg1.ident)
		end
	end
end

tbl3.onLeave = function(arg1, arg2)
	arg1.leavefunc = arg2
	arg1.wasInArea1 = false
	arg1.updaterLeave = function()
		local var1 = arg1:isInArea()
		local var2 = not var1
		arg1.wasInArea1 = var1
		if var2 and arg1.wasInArea1 and 0.01 < os.clock() - arg1.debounce then
			arg1.debounce = os.clock()
			task.spawn(arg1.leavefunc, arg1.ident)
		end
	end
end

tbl3.Disconnect = function(arg1)
	arg1.updaterEnter = nil
	arg1.updaterLeave = nil
	tbl2[arg1.ident] = nil
end

tbl1.new = function(arg1, arg2)
	local var1 = setmetatable({ part = arg2, ident = arg1, debounce = os.clock() }, tbl3)
	var1:init()
	arg2.Destroying:Connect(function()
		print((("disconnecting '%*' proximity area"):format(arg1)))
		var1:Disconnect()
	end)

	tbl2[arg1] = var1
	return var1
end

return tbl1

--- ReplicatedStorage.Modules.Shared.ChatTags [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = workspace:WaitForChild("Leaderboards"):WaitForChild("HighestCash"):WaitForChild("Board"):WaitForChild("SurfaceGui"):WaitForChild("Main"):WaitForChild("Scroll"):WaitForChild("GlobalContainer")
local tbl1 = { Owner = "#" .. Color3.fromRGB(144, 70, 255):ToHex() }
tbl1.Developer = "#" .. Color3.fromRGB(245, 67, 168):ToHex()
tbl1.Tester = "#" .. Color3.fromRGB(240, 33, 26):ToHex()
tbl1.Member = "#" .. Color3.fromRGB(88, 247, 255):ToHex()
tbl1["#"] = "#" .. Color3.fromRGB(113, 255, 111):ToHex()
return {
	setTags = function(arg1)
		if not arg1 or arg1.Parent == nil then
			return
		end

		local var1 = var2.Stat.Get(arg1, "InGroup")
		local str1 = ""
		local num1 = 0
		if arg1.UserId == 1266834230 then
			str1 = str1 .. ",Owner"
			num1 = num1 + 1
		else
			if arg1:GetRoleInGroup(35558998) == "Developer" then
				str1 = str1 .. ",Developer"
				num1 = num1 + 1
			else
				if arg1:GetRoleInGroup(35558998) == "Tester" then
					str1 = str1 .. ",Tester"
					num1 = num1 + 1
				else
					if var1.Value == true then
						str1 = str1 .. ",Member"
						num1 = num1 + 1
					end
				end
			end
		end

		for k1, v1 in var3:GetChildren() do
			if not v1:IsA("Frame") then
				continue
			end

			if v1.Username.Text ~= arg1.Name then
				continue
			end

			str1 = str1 .. ",#" .. v1.Name .. "\240\159\146\181"
			num1 = num1 + 1
		end

		arg1:SetAttribute("Tags", str1)
	end,
	getTagPrefix = function(arg1)
		local var2 = arg1:GetAttribute("Tags")
		if var2 == nil then
			return ""
		end

		local str1 = ""
		for k1, v1 in string.split(var2, ",") do
			if v1 == "" then
				continue
			end

			str1 = if string.find(v1, "#") then str1 .. ("<font color = '%*'>[%*] </font>"):format(tbl1["#"], v1) else str1 .. ("<font color = '%*'>[%*] </font>"):format(tbl1[v1], v1)
		end

		return str1
	end,
}

--- ReplicatedStorage.Modules.Shared.Seeds [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Assets
local var3 = var1.Modules.Shared
Color3.fromRGB(255, 255, 255):ToHex()
local var4 = require(var3.StatInformation)
local var5 = require(var1.Framework)
local var6 = require(var3.BigNum)
local var7 = var4.Cash.Colour:ToHex()
local var8 = var4.Soil.Colour:ToHex()
local var9 = var4.Water.Colour:ToHex()
local var10 = var4.Wood.Colour:ToHex()
local var11 = var4.Harvest.Colour:ToHex()
local var12 = var4.Research.Colour:ToHex()
local var13 = var4.Replant.Colour:ToHex()
local var14 = var2.Seeds.Main
local tbl1 = {
	Seed = "Wheat",
	Colour = Color3.fromRGB(245, 205, 48),
	Icon = "rbxassetid://134021782546764",
	Rank = 1,
	Multiplier = 1,
	Levels = 5,
	EvolvePrice = 50,
}

tbl1.MainModel = var14.Wheat
local var15 = var2.Seeds.Collectibles
tbl1.CollectableModel = var15.Wheat
tbl1.Price = function(arg1)
	local num1 = 5
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value + 1
	local num2 = 5
	return var6.add(num2, var6.mul(num1, var1))
end

tbl1.Reward = function(arg1)
	return var5.Stat.Get(arg1, "SeedLevel").Value + 1
end

tbl1.Text = { { Type = "Text", Text = "- Unlocks Nothing" } }
local tbl2 = { [0] = tbl1 }
local tbl3 = {
	Seed = "Apple",
	Colour = Color3.fromRGB(255, 0, 0),
	Icon = "rbxassetid://81643024200132",
	Rank = 2,
	Multiplier = 2,
	Levels = 5,
	EvolvePrice = 150,
}

tbl3.MainModel = var14.Apple
tbl3.CollectableModel = var15.Apple
tbl3.Price = function(arg1)
	local num1 = 15
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value + 1
	return var6.mul(num1, var1)
end

tbl3.Reward = function(arg1)
	return var5.Stat.Get(arg1, "SeedLevel").Value + 1
end

tbl3.Text = { { Type = "Text", Text = "- Unlocks Nothing" } }
tbl2[1] = tbl3
tbl3 = {
	Seed = "Carrot",
	Colour = Color3.fromRGB(218, 133, 65),
	Icon = "rbxassetid://116867856625026",
	Rank = 3,
	Multiplier = 4,
	Levels = 5,
	EvolvePrice = 15000,
}

tbl3.MainModel = var14.Carrot
tbl3.CollectableModel = var15.Carrot
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 150 * (var1 + 1)
	local var3 = var1 + 1
	return var6.mul(var2, var3)
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 2
end

local tbl4 = {
	Type = "Text",
	Text = ("- Unlocks the <font color=\"#%*\">Upgrade Tree</font>"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[2] = tbl3
tbl3 = {
	Seed = "Potato",
	Colour = Color3.fromRGB(218, 203, 91),
	Icon = "rbxassetid://138002362127831",
	Rank = 4,
	Multiplier = 15,
	Levels = 5,
	EvolvePrice = 250000,
}

tbl3.MainModel = var14.Potato
tbl3.CollectableModel = var15.Potato
tbl3.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 5000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 2
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks a new <font color=\"#%*\">Upgrade Tree</font> upgrade"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[3] = tbl3
tbl3 = {
	Seed = "Lettuce",
	Colour = Color3.fromRGB(121, 218, 91),
	Icon = "rbxassetid://124935730420069",
	Rank = 5,
	Multiplier = 40,
	Levels = 10,
	EvolvePrice = 5000000000,
}

tbl3.MainModel = var14.Lettuce
tbl3.CollectableModel = var15.Lettuce
tbl3.Price = function(arg1)
	local num1 = 2.7
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 150000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 4.5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Soil</font> feature"):format(var8),
}

tbl3.Text = { tbl4 }
tbl2[4] = tbl3
tbl3 = {
	Seed = "Onion",
	Colour = Color3.fromRGB(188, 106, 238),
	Icon = "rbxassetid://78617248924818",
	Rank = 6,
	Multiplier = 100,
	Levels = 10,
	EvolvePrice = 50000000000000,
}

tbl3.MainModel = var14.Onion
tbl3.CollectableModel = var15.Onion
tbl3.Price = function(arg1)
	local num1 = 2.9
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 1000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 4.5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Water</font> feature"):format(var9),
}

tbl3.Text = { tbl4 }
tbl2[5] = tbl3
tbl3 = {
	Seed = "Cucumber",
	Colour = Color3.fromRGB(22, 156, 13),
	Icon = "rbxassetid://129101496588058",
	Rank = 7,
	Multiplier = 300,
	Levels = 10,
	EvolvePrice = 5e+17,
}

tbl3.MainModel = var14.Cucumber
tbl3.CollectableModel = var15.Cucumber
tbl3.Price = function(arg1)
	local num1 = 2.75
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 2500000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Tree</font> feature"):format(var10),
}

tbl1 = { tbl4 }
tbl4 = {
	Type = "Text",
	Text = ("- Unlocks a new <font color=\"#%*\">Upgrade Tree</font> upgrade"):format(var7),
}

tbl1[2] = tbl4
tbl3.Text = tbl1
tbl2[6] = tbl3
tbl3 = {
	Seed = "Tomato",
	Colour = Color3.fromRGB(212, 29, 57),
	Icon = "rbxassetid://81764780932148",
	Rank = 8,
	Multiplier = 1000,
	Levels = 10,
	EvolvePrice = 2e+21,
}

tbl3.MainModel = var14.Tomato
tbl3.CollectableModel = var15.Tomato
tbl3.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 1.5e+16
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl1 = { tbl4 }
tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Harvest</font> feature"):format(var11),
}

tbl1[2] = tbl4
tbl3.Text = tbl1
tbl2[7] = tbl3
tbl3 = {
	Seed = "Corn",
	Colour = Color3.fromRGB(255, 206, 30),
	Icon = "rbxassetid://126506266778782",
	Rank = 9,
	Multiplier = 2500,
	Levels = 10,
	EvolvePrice = 1e+25,
}

tbl3.MainModel = var14.Corn
tbl3.CollectableModel = var15.Corn
tbl3.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 5e+19
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 6
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[8] = tbl3
tbl3 = {
	Seed = "Radish",
	Colour = Color3.fromRGB(189, 24, 46),
	Icon = "rbxassetid://117668315816630",
	Rank = 10,
	Multiplier = 5000,
	Levels = 10,
	EvolvePrice = 3.5e+27,
}

tbl3.MainModel = var14.Radish
tbl3.CollectableModel = var15.Radish
tbl3.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local num2 = 1e+23
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 7.5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[9] = tbl3
tbl3 = {
	Seed = "Strawberry",
	Colour = Color3.fromRGB(241, 52, 102),
	Icon = "rbxassetid://101961609911391",
	Rank = 11,
	Multiplier = 10000,
	Levels = 10,
	EvolvePrice = 5e+32,
}

tbl3.MainModel = var14.Strawberry
tbl3.CollectableModel = var15.Strawberry
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3 + var1 / 10
	local var3 = var1
	local num1 = 1e+26
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 10
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl1 = { tbl4 }
tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Research</font> feature"):format(var12),
}

tbl1[2] = tbl4
tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Quests</font> feature"):format(var12),
}

tbl1[3] = tbl4
tbl3.Text = tbl1
tbl2[10] = tbl3
tbl3 = {
	Seed = "Orange",
	Colour = Color3.fromRGB(241, 181, 30),
	Icon = "rbxassetid://94715804747917",
	Rank = 12,
	Multiplier = 40000,
	Levels = 10,
	EvolvePrice = 1e+37,
}

tbl3.MainModel = var14.Orange
tbl3.CollectableModel = var15.Orange
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3 + var1 / 10
	local var3 = var1
	local num1 = 1e+31
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 12.5
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks <font color=\"#%*\">Replant</font> feature"):format(var13),
}

tbl3.Text = { tbl4 }
tbl2[11] = tbl3
tbl3 = {
	Seed = "Lemon",
	Colour = Color3.fromRGB(241, 234, 22),
	Icon = "rbxassetid://125640081165222",
	Rank = 13,
	Multiplier = 250000,
	Levels = 10,
	EvolvePrice = 1e+42,
}

tbl3.MainModel = var14.Lemon
tbl3.CollectableModel = var15.Lemon
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3.2 + var1 / 10
	local var3 = var1
	local num1 = 5e+35
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 15
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[12] = tbl3
tbl3 = {
	Seed = "Guava",
	Colour = Color3.fromRGB(167, 241, 128),
	Icon = "rbxassetid://113295267805207",
	Rank = 14,
	Multiplier = 1000000,
	Levels = 10,
	EvolvePrice = 2.5e+46,
}

tbl3.MainModel = var14.Guava
tbl3.CollectableModel = var15.Guava
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3.2 + var1 / 10
	local var3 = var1
	local num1 = 5e+40
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 15
end

tbl4 = {
	Type = "Text",
	Text = ("- Unlocks new <font color=\"#%*\">Upgrade Tree</font> upgrades"):format(var7),
}

tbl3.Text = { tbl4 }
tbl2[13] = tbl3
tbl3 = {
	Seed = "Grape",
	Colour = Color3.fromRGB(116, 13, 241),
	Icon = "rbxassetid://79266515071865",
	Rank = 15,
	Multiplier = 5000000,
	Levels = 10,
	EvolvePrice = 1e+52,
}

tbl3.MainModel = var14.Grape
tbl3.CollectableModel = var15.Grape
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3.2 + var1 / 10
	local var3 = var1
	local num1 = 1e+46
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 15
end

tbl3.Text = { { Type = "Text", Text = "- Unlocks Zone 2" } }
tbl2[14] = tbl3
tbl3 = {
	Seed = "Mango",
	Colour = Color3.fromRGB(241, 203, 11),
	Icon = "rbxassetid://126910420531135",
	Rank = 16,
	Multiplier = 10000000,
	Levels = 10,
	EvolvePrice = 3.5e+55,
}

tbl3.MainModel = var14.Mango
tbl3.CollectableModel = var15.Mango
tbl3.Price = function(arg1)
	local var1 = var5.Stat.Get(arg1, "SeedLevel").Value
	local var2 = 3.2 + var1 / 10
	local var3 = var1
	local num1 = 1e+51
	return var6.mul(num1, var6.pow(var2, var3))
end

tbl3.Reward = function(arg1)
	return (var5.Stat.Get(arg1, "SeedLevel").Value + 1) * 20
end

tbl3.Text = { { Type = "Text", Text = "- Unlocks reset layer" } }
tbl2[15] = tbl3
local tbl5 = { Seeds = tbl2 }
tbl5.Types = {
	Normal = { Chance = 100, Multiplier = 1 },
	Gold = { Chance = 6.666666666666667, Multiplier = 3 },
	Diamond = { Chance = 2.8571428571428572, Multiplier = 10 },
	Void = { Chance = 0.33333333333333331, Multiplier = 50 },
}

return tbl5

--- ReplicatedStorage.Modules.Shared.SeedChoosing [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local tbl1 = {}
local tbl2 = {}
for k1, v1 in require(var1.Modules.Shared.Seeds).Types, nil do
	table.insert(tbl2, { name = k1, chance = v1.Chance / 100 })
end

table.sort(tbl2, function(arg1, arg2)
	return arg1.chance < arg2.chance
end)

tbl1.GetSeed = function()
	local var1 = math.random()
	for k1, v1 in tbl2, nil do
		if var1 > v1.chance then
			continue
		end

		return v1.name
	end

	return "Normal"
end

return tbl1

--- ReplicatedStorage.Modules.Shared.UpgradeTree [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var2.StatInformation)
var3.XP.Colour:ToHex()
var3.Harvest.Colour:ToHex()
var3.Diamond.Colour:ToHex()
local var4 = var3.Cash.Colour:ToHex()
local var5 = require(var1.Framework)
local var6 = require(var2.BigNum)
local var7 = var3.Soil.Colour:ToHex()
local var8 = var3.Water.Colour:ToHex()
local var9 = var3.Wood.Colour:ToHex()
local var10 = var3.Grass.Colour:ToHex()
local var11 = var3.Paper.Colour:ToHex()
local var12 = var3.Research.Colour:ToHex()
local var13 = var3.Leaves.Colour:ToHex()
local var14 = Color3.fromRGB(255, 255, 255):ToHex()
local tbl1 = {
	Display = "More Cash",
	Order = 1,
	Tier = 1,
	RewardDisplay = ("+1x <font color=\"#%*\">Cash</font> per upgrade"):format(var4),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font>"):format(var4)
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(arg1)
	local num1 = 50
	if 2 <= arg1.Stats.Harvest.Value then
		num1 = num1 + 25
	end

	return num1
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreCash").Value
	local num2 = 50
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreCash").Value + 1
end

local tbl2 = { TreeMoreCash = tbl1 }
tbl2.TreeFasterSpawn = {
	Display = "Faster Spawn",
	Order = 2,
	Tier = 1,
	RewardDisplay = "-0.5s cooldown",
	Currency = "Cash",
	Unlocked = function(arg1)
		return 1 <= arg1.UpgradeTree.TreeMoreCash.Value
	end,
	ChangeStat = "UpgradesBought",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 250
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeFasterSpawn").Value * 0.5
	end,
}

tbl2.TreeMoreCap = {
	Display = "Higher Limit",
	Order = 3,
	Tier = 1,
	RewardDisplay = "+5 Plant limit",
	Currency = "Cash",
	Unlocked = function(arg1)
		return 1 <= arg1.UpgradeTree.TreeMoreCash.Value
	end,
	ChangeStat = "UpgradesBought",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 200
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeMoreCap").Value * 5
	end,
}

tbl1 = {
	Display = "More Cash",
	Order = 4,
	Tier = 1,
	RewardDisplay = ("Boost <font color=\"#%*\">Cash</font> based on Collects"):format(var4),
	Currency = "Cash",
	RewardChange = "Collects",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font> based on Collects"):format(var4)
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 25000
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "Collects")
	local var2 = var5.Stat.Get(arg1, "TreeMoreCash10").Value
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash2").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 100) then
		return num1
	end

	local var4 = var6.sub(var6.log10(var1.Value), 1)
	if 1 <= var2 then
		return (var6.pow(2.62, var4))
	end

	return (var6.pow(2.05, var4))
end

tbl2.TreeMoreCash2 = tbl1
tbl2.TreeMoreRange = {
	Display = "More Range",
	Order = 5,
	Tier = 1,
	RewardDisplay = "+1 Range",
	Currency = "Cash",
	Unlocked = function(arg1)
		return 4 <= arg1.Stats.Seed.Value
	end,
	ChangeStat = "Seed",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 10000000
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeMoreRange").Value
	end,
}

tbl1 = {
	Display = "More Soil",
	Order = 6,
	Tier = 1,
	RewardDisplay = ("+1x <font color=\"#%*\">Soil</font> per upgrade"):format(var7),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Soil</font>"):format(var7)
tbl1.Unlocked = function(arg1)
	return 4 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1)
	local num1 = 2.2
	local var1 = var5.Stat.Get(arg1, "TreeMoreSoil").Value
	local num2 = 25000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreSoil").Value + 1
end

tbl2.TreeMoreSoil = tbl1
tbl2.TreeMoreCap2 = {
	Display = "Higher Limit",
	Order = 7,
	Tier = 1,
	RewardDisplay = "+5 Plant limit",
	Currency = "Soil",
	Unlocked = function(arg1)
		return 4 <= arg1.Stats.Seed.Value
	end,
	ChangeStat = "Seed",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 100000
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeMoreCap2").Value * 5
	end,
}

tbl1 = {
	Display = "More XP",
	Order = 8,
	Tier = 1,
	RewardDisplay = ("+1x <font color=\"#%*\">XP</font> per upgrade"):format(var8),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">XP</font>"):format(var8)
tbl1.Unlocked = function(arg1)
	return 5 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreXP").Value
	local num2 = 250000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreXP").Value + 1
end

tbl2.TreeMoreXP = tbl1
tbl1 = {
	Display = "More Water",
	Order = 9,
	Tier = 1,
	RewardDisplay = ("Doubles <font color=\"#%*\">Water</font> per upgrade"):format(var8),
	Currency = "Soil",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Water</font>"):format(var8)
tbl1.Unlocked = function(arg1)
	return 5 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMoreWater").Value
	local num2 = 2500000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreWater").Value))
end

tbl2.TreeMoreWater = tbl1
tbl1 = {
	Display = "More Walkspeed",
	Order = 10,
	Tier = 1,
	RewardDisplay = ("+5 <font color=\"#%*\">Walkspeed</font>"):format(var14),
	Currency = "Water",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 5 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreWalkspeed").Value * 5
end

tbl2.TreeMoreWalkspeed = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 11,
	Tier = 1,
	RewardDisplay = ([[Boost <font color="#%*">Cash</font> based on <font color="#%*">Water</font> Clicks]]):format(var4, var8),
	Currency = "Water",
	RewardChange = "Clicks",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ([[x%%s <font color="#%*">Cash</font> based on <font color="#%*">Water</font> Clicks]]):format(var4, var8)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreXP.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreWater.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreWalkspeed.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 50000
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "Clicks")
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash3").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 750) then
		return num1
	end

	return (var6.sub(var6.pow(1.8, (var6.sub(var6.log10(var1.Value), 1))), 1))
end

tbl2.TreeMoreCash3 = tbl1
tbl1 = {
	Display = "Unlock Combo",
	Order = 12,
	Tier = 1,
	RewardDisplay = ("Unlocks <font color=\"#%*\">Collection Combo</font>"):format(var4),
	Currency = "Water",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreXP.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreWater.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreWalkspeed.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 5000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreWalkspeed").Value * 5
end

tbl2.TreeUnlockCombo = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 13,
	Tier = 1,
	RewardDisplay = ([[Boost <font color="#%*">Cash</font> based on <font color="#%*">Tree</font> Hits]]):format(var4, var9),
	Currency = "Wood",
	RewardChange = "TreeHits",
	ChangeStat = "Seed",
}

tbl1.Formatted = ([[x%%s <font color="#%*">Cash</font> based on <font color="#%*">Tree</font> Hits]]):format(var4, var9)
tbl1.Unlocked = function(arg1)
	return 7 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 50000
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "TreeHits")
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash4").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 350) then
		return num1
	end

	return (var6.sub(var6.pow(2.1, (var6.sub(var6.log10(var1.Value), 1))), 1))
end

tbl2.TreeMoreCash4 = tbl1
tbl1 = {
	Display = "More Wood",
	Order = 14,
	Tier = 1,
	RewardDisplay = ("x3 <font color=\"#%*\">Wood</font>"):format(var9),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 6 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 250000000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMoreWood").Value))
end

tbl2.TreeMoreWood = tbl1
tbl1 = {
	Display = "More Water",
	Order = 15,
	Tier = 1,
	RewardDisplay = ("x2 <font color=\"#%*\">Water</font>"):format(var8),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 7 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 7.5e+17
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreWater2").Value))
end

tbl2.TreeMoreWater2 = tbl1
tbl1 = {
	Display = "More Water",
	Order = 16,
	Tier = 1,
	RewardDisplay = ("x3 <font color=\"#%*\">Water</font>"):format(var8),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 8 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 5e+22
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMoreWater3").Value))
end

tbl2.TreeMoreWater3 = tbl1
tbl1 = {
	Display = "Better Combo",
	Order = 17,
	Tier = 1,
	RewardDisplay = ("Improves <font color=\"#%*\">Combo</font> gain"):format(var4),
	Currency = "Water",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 8 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 25000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeBetterCombo").Value * 0.00025
end

tbl2.TreeBetterCombo = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 18,
	Tier = 1,
	RewardDisplay = ("Doubles <font color=\"#%*\">Cash</font> per upgrade"):format(var4),
	Currency = "Wood",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font>"):format(var4)
tbl1.Unlocked = function(arg1)
	return 8 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 10
	local var1 = var5.Stat.Get(arg1, "TreeMoreCash5").Value
	local num2 = 50000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreCash5").Value))
end

tbl2.TreeMoreCash5 = tbl1
tbl1 = {
	Display = "More Soil",
	Order = 19,
	Tier = 1,
	RewardDisplay = ("Doubles <font color=\"#%*\">Soil</font> per upgrade"):format(var7),
	Currency = "Water",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Soil</font>"):format(var7)
tbl1.Unlocked = function(arg1)
	return 9 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMoreSoil2").Value
	local num2 = 500000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreSoil2").Value))
end

tbl2.TreeMoreSoil2 = tbl1
tbl1 = {
	Display = "More Water",
	Order = 20,
	Tier = 1,
	RewardDisplay = ("+1x <font color=\"#%*\">Water</font> per upgrade"):format(var8),
	Currency = "Soil",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Water</font>"):format(var8)
tbl1.Unlocked = function(arg1)
	return 9 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMoreWater4").Value
	local num2 = 5e+25
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreWater4").Value + 1
end

tbl2.TreeMoreWater4 = tbl1
tbl1 = {
	Display = "More Grass",
	Order = 21,
	Tier = 2,
	RewardDisplay = ("x2 <font color=\"#%*\">Grass</font>"):format(var10),
	Currency = "Wood",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 10 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMoreGrass").Value
	return 1000000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreGrass").Value))
end

tbl2.TreeMoreGrass = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 22,
	Tier = 2,
	RewardDisplay = ("x2 <font color=\"#%*\">Paper</font>"):format(var11),
	Currency = "Grass",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 10 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaper").Value
	return 75000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMorePaper").Value))
end

tbl2.TreeMorePaper = tbl1
tbl1 = {
	Display = "More XP",
	Order = 23,
	Tier = 2,
	RewardDisplay = ("x2 <font color=\"#%*\">XP</font>"):format(var8),
	Currency = "Soil",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 10 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMoreXP2").Value
	return 1e+33
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreXP2").Value))
end

tbl2.TreeMoreXP2 = tbl1
tbl1 = {
	Display = "Better Combo",
	Order = 24,
	Tier = 2,
	RewardDisplay = ("Improves <font color=\"#%*\">Combo</font> gain"):format(var4),
	Currency = "Cash",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreGrass.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMorePaper.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreXP2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 5e+28
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeBetterCombo2").Value * 0.00025
end

tbl2.TreeBetterCombo2 = tbl1
tbl1 = {
	Display = "More Combo Limit",
	Order = 25,
	Tier = 2,
	RewardDisplay = ("+0.5x <font color=\"#%*\">Combo</font> limit"):format(var4),
	Currency = "Wood",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreGrass.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMorePaper.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreXP2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 2500000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreComboLimit").Value * 0.5
end

tbl2.TreeMoreComboLimit = tbl1
tbl1 = {
	Display = "More Walkspeed",
	Order = 26,
	Tier = 2,
	RewardDisplay = ("+5 <font color=\"#%*\">Walkspeed</font>"):format(var14),
	Currency = "Grass",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreGrass.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMorePaper.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreXP2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1250000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreWalkspeed2").Value * 5
end

tbl2.TreeMoreWalkspeed2 = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 27,
	Tier = 2,
	RewardDisplay = ("+1x <font color=\"#%*\">Paper</font> per upgrade"):format(var11),
	Currency = "Cash",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Paper</font>"):format(var11)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreWalkspeed2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreComboLimit.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeBetterCombo2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1)
	local num1 = 1.5
	local var1 = var5.Stat.Get(arg1, "TreeMorePaper2").Value
	local num2 = 5e+28
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMorePaper2").Value + 1
end

tbl2.TreeMorePaper2 = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 28,
	Tier = 2,
	RewardDisplay = ("Doubles <font color=\"#%*\">Cash</font> per upgrade"):format(var4),
	Currency = "Soil",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font>"):format(var4)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreWalkspeed2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreComboLimit.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeBetterCombo2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMoreCash6").Value
	local num2 = 1e+35
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreCash6").Value))
end

tbl2.TreeMoreCash6 = tbl1
tbl1 = {
	Display = "More Grass",
	Order = 29,
	Tier = 2,
	RewardDisplay = ("+1x <font color=\"#%*\">Grass</font> per upgrade"):format(var10),
	Currency = "Water",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Grass</font>"):format(var10)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreWalkspeed2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreComboLimit.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeBetterCombo2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreGrass2").Value
	local num2 = 250000000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreGrass2").Value + 1
end

tbl2.TreeMoreGrass2 = tbl1
tbl1 = {
	Display = "More XP",
	Order = 30,
	Tier = 2,
	RewardDisplay = ("x3 <font color=\"#%*\">XP</font>"):format(var8),
	Currency = "Grass",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreGrass2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreCash6.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMorePaper2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMoreXP3").Value
	return 500000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMoreXP3").Value))
end

tbl2.TreeMoreXP3 = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 31,
	Tier = 2,
	RewardDisplay = ("x2 <font color=\"#%*\">Paper</font>"):format(var11),
	Currency = "Wood",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreGrass2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreCash6.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMorePaper2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaper3").Value
	return 50000000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMorePaper3").Value))
end

tbl2.TreeMorePaper3 = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 32,
	Tier = 3,
	RewardDisplay = ("Doubles <font color=\"#%*\">Paper</font> per upgrade"):format(var11),
	Currency = "Cash",
	ChangeStat = "Replant",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Paper</font>"):format(var11)
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.Replant.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMorePaper4").Value
	local num2 = 1e+34
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMorePaper4").Value))
end

tbl2.TreeMorePaper4 = tbl1
tbl1 = {
	Display = "More Grass",
	Order = 33,
	Tier = 3,
	RewardDisplay = ("Doubles <font color=\"#%*\">Grass</font> per upgrade"):format(var10),
	Currency = "Soil",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Grass</font>"):format(var10)
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMorePaper4.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 3
	local var1 = var5.Stat.Get(arg1, "TreeMoreGrass3").Value
	local num2 = 5e+41
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreGrass3").Value))
end

tbl2.TreeMoreGrass3 = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 34,
	Tier = 3,
	RewardDisplay = ("+1x <font color=\"#%*\">Cash</font> per upgrade"):format(var4),
	Currency = "Wood",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font>"):format(var4)
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMorePaper4.Value
end

tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreCash7").Value
	local num2 = 100000000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreCash7").Value + 1
end

tbl2.TreeMoreCash7 = tbl1
tbl1 = {
	Display = "More XP",
	Order = 35,
	Tier = 3,
	RewardDisplay = ("x3 <font color=\"#%*\">XP</font>"):format(var8),
	Currency = "Grass",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMorePaper4.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMoreXP4").Value
	return 10000000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMoreXP4").Value))
end

tbl2.TreeMoreXP4 = tbl1
tbl1 = {
	Display = "Faster Research",
	Order = 36,
	Tier = 3,
	RewardDisplay = ("x1.25 <font color=\"#%*\">Research</font> speed"):format(var12),
	Currency = "Cash",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Research</font> speed"):format(var12)
tbl1.Unlocked = function(arg1)
	return 12 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeFasterResearch").Value
	return 1e+38
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeFasterResearch").Value * 0.25 + 1
end

tbl2.TreeFasterResearch = tbl1
tbl2.TreeMoreRange2 = {
	Display = "More Range",
	Order = 37,
	Tier = 3,
	RewardDisplay = "+1 Range",
	Currency = "Water",
	Unlocked = function(arg1)
		return 12 <= arg1.Stats.Seed.Value
	end,
	ChangeStat = "Seed",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 2.5e+18
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeMoreRange2").Value
	end,
}

tbl1 = {
	Display = "More Paper",
	Order = 38,
	Tier = 3,
	RewardDisplay = ("x3 <font color=\"#%*\">Paper</font>"):format(var11),
	Currency = "Grass",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 12 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaper5").Value
	return 1000000000000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMorePaper5").Value))
end

tbl2.TreeMorePaper5 = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 39,
	Tier = 3,
	RewardDisplay = ("Doubles <font color=\"#%*\">Cash</font> per upgrade"):format(var4),
	Currency = "Grass",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font>"):format(var4)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMorePaper5.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreRange2.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeFasterResearch.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 2.5
	local var1 = var5.Stat.Get(arg1, "TreeMoreCash8").Value
	local num2 = 1000000000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreCash8").Value))
end

tbl2.TreeMoreCash8 = tbl1
tbl1 = {
	Display = "More Wood",
	Order = 40,
	Tier = 3,
	RewardDisplay = ("Doubles <font color=\"#%*\">Wood</font> per upgrade"):format(var9),
	Currency = "Water",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Wood</font>"):format(var9)
tbl1.Unlocked = function(arg1)
	return 13 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreWood2").Value
	local num2 = 1e+18
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreWood2").Value))
end

tbl2.TreeMoreWood2 = tbl1
tbl1 = {
	Display = "Faster Research",
	Order = 41,
	Tier = 3,
	RewardDisplay = ("+0.25x <font color=\"#%*\">Research</font> speed per upgrade"):format(var12),
	Currency = "Wood",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Research</font> speed"):format(var12)
tbl1.Unlocked = function(arg1)
	return 13 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 2.5
	local var1 = var5.Stat.Get(arg1, "TreeFasterResearch2").Value
	local num2 = 2500000000000000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeFasterResearch2").Value * 0.25 + 1
end

tbl2.TreeFasterResearch2 = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 42,
	Tier = 3,
	RewardDisplay = ("x2 <font color=\"#%*\">Paper</font>"):format(var11),
	Currency = "Grass",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 13 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaper6").Value
	return 1e+17
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMorePaper6").Value))
end

tbl2.TreeMorePaper6 = tbl1
tbl1 = {
	Display = "More Water",
	Order = 43,
	Tier = 3,
	RewardDisplay = ("x5 <font color=\"#%*\">Water</font>"):format(var8),
	Currency = "Soil",
	ChangeStat = "Seed",
}

tbl1.Unlocked = function(arg1)
	return 13 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1e+52
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(5, var5.Stat.Get(arg1, "TreeMoreWater5").Value))
end

tbl2.TreeMoreWater5 = tbl1
tbl1 = {
	Display = "More Grass",
	Order = 44,
	Tier = 3,
	RewardDisplay = ("Doubles <font color=\"#%*\">Grass</font> per upgrade"):format(var10),
	Currency = "Cash",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Grass</font>"):format(var10)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMorePaper6.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeFasterResearch2.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreWood2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 1.5
	local var1 = var5.Stat.Get(arg1, "TreeMoreGrass4").Value
	local num2 = 1.5e+43
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreGrass4").Value))
end

tbl2.TreeMoreGrass4 = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 45,
	Tier = 3,
	RewardDisplay = ("Pet Boosts <font color=\"#%*\">Cash</font>"):format(var4),
	Currency = "Water",
	RewardChange = "Pet",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font> based on Pet"):format(var4)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMorePaper6.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeFasterResearch2.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreWood2.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1.5e+19
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "Pet")
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash9").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 5) then
		return num1
	end

	return (var6.pow(2, var1.Value - 4))
end

tbl2.TreeMoreCash9 = tbl1
tbl2.TreeMoreCash10 = {
	Display = "More Cash",
	Order = 46,
	Tier = 3,
	RewardDisplay = "Improves upgrade [4]'s boost",
	Currency = "Grass",
	RewardChange = "PlayTime",
	Unlocked = function(arg1)
		local bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMoreCash9.Value then
			bool2 = false
			if 1 <= arg1.UpgradeTree.TreeMoreGrass4.Value then
				bool2 = 1 <= arg1.UpgradeTree.TreeMoreWater5.Value
			end
		end

		return bool2
	end,
	ChangeStat = "UpgradesBought",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 1e+20
	end,
	Reward = function(arg1)
		local var1 = var5.Stat.Get(arg1, "PlayTime")
		local num1 = 1
		if var5.Stat.Get(arg1, "TreeMoreCash10").Value < 1 then
			return num1
		end

		if var6.lt(var1.Value, 5) then
			return num1
		end

		return (var6.pow(2, var1.Value - 4))
	end,
}

tbl1 = {
	Display = "More Cash",
	Order = 47,
	Tier = 4,
	RewardDisplay = ("Playtime boosts <font color=\"#%*\">Cash</font>"):format(var4),
	Currency = "Diamond",
	RewardChange = "PlayTime",
	ChangeStat = "HighestSeed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Cash</font> based on Playtime"):format(var4)
tbl1.Unlocked = function(arg1)
	return 14 <= arg1.HighestStats.HighestSeed.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "PlayTime")
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash10").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 10000) then
		return num1
	end

	return (var6.sub(var6.pow(2.1, (var6.sub(var6.log10(var1.Value / 15), 1))), 1))
end

tbl2.TreeMoreCash11 = tbl1
tbl1 = {
	Display = "More Walkspeed",
	Order = 48,
	Tier = 4,
	RewardDisplay = ("+5 <font color=\"#%*\">Walkspeed</font>"):format(var14),
	Currency = "Diamond",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreCash11.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 1
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMoreWalkspeed3").Value * 5
end

tbl2.TreeMoreWalkspeed3 = tbl1
tbl1 = {
	Display = "Better Quests",
	Order = 49,
	Tier = 4,
	RewardDisplay = ("x2 <font color=\"#%*\">Quest</font> rewards"):format((Color3.fromRGB(255, 207, 15):ToHex())),
	Currency = "Diamond",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreWalkspeed3.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 2
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeBetterQuests").Value))
end

tbl2.TreeBetterQuests = tbl1
tbl1 = {
	Display = "Faster Research",
	Order = 50,
	Tier = 4,
	RewardDisplay = ("x2 <font color=\"#%*\">Research</font> speed"):format(var12),
	Currency = "Diamond",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreWalkspeed3.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeFasterResearch3").Value
	return 2
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return 2 ^ var5.Stat.Get(arg1, "TreeFasterResearch3").Value
end

tbl2.TreeFasterResearch3 = tbl1
tbl2.TreeMoreRange3 = {
	Display = "More Range",
	Order = 51,
	Tier = 4,
	RewardDisplay = "+1 Range",
	Currency = "Diamond",
	Unlocked = function(arg1)
		return 1 <= arg1.UpgradeTree.TreeMoreWalkspeed3.Value
	end,
	ChangeStat = "UpgradesBought",
	Cap = function(_)
		return 1
	end,
	Price = function(_)
		return 2
	end,
	Reward = function(arg1)
		local num1 = 0
		return var5.Stat.Get(arg1, "TreeMoreRange3").Value
	end,
}

tbl1 = {
	Display = "Better Collection",
	Order = 52,
	Tier = 4,
	RewardDisplay = ("+0.5 <font color=\"#%*\">Leaf</font> click radius"):format(var13),
	Currency = "Diamond",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreRange3.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeFasterResearch3.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeBetterQuests.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 4
end

tbl1.Reward = function(arg1)
	local num1 = 0
	return var5.Stat.Get(arg1, "TreeBetterLeafCollect").Value * 0.5
end

tbl2.TreeBetterLeafCollect = tbl1
tbl1 = {
	Display = "More Leaves",
	Order = 53,
	Tier = 4,
	RewardDisplay = ("x2 <font color=\"#%*\">Leaves</font>"):format(var13),
	Currency = "Diamond",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMoreRange3.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeFasterResearch3.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeBetterQuests.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 4
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreLeaves").Value))
end

tbl2.TreeMoreLeaves = tbl1
tbl1 = {
	Display = "More Leaves",
	Order = 53,
	Tier = 4,
	RewardDisplay = ("x2 <font color=\"#%*\">Leaves</font> per upgrade"):format(var13),
	Currency = "Leaves",
	ChangeStat = "Seed",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Leaves</font>"):format(var13)
tbl1.Unlocked = function(arg1)
	return 14 <= arg1.Stats.Seed.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 20
	local var1 = var5.Stat.Get(arg1, "TreeMoreLeaves2").Value
	local num2 = 2000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreLeaves2").Value))
end

tbl2.TreeMoreLeaves2 = tbl1
tbl1 = {
	Display = "More Grass",
	Order = 54,
	Tier = 4,
	RewardDisplay = ("Doubles <font color=\"#%*\">Grass</font> per upgrade"):format(var10),
	Currency = "Leaves",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Grass</font>"):format(var10)
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves2.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 5
	local var1 = var5.Stat.Get(arg1, "TreeMoreGrass5").Value
	local num2 = 15000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreGrass5").Value))
end

tbl2.TreeMoreGrass5 = tbl1
tbl1 = {
	Display = "Faster Research",
	Order = 55,
	Tier = 4,
	RewardDisplay = ("Doubles <font color=\"#%*\">Research</font> speed per upgrade"):format(var12),
	Currency = "Leaves",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Research</font> speed"):format(var12)
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves2.Value
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 50
	local var1 = var5.Stat.Get(arg1, "TreeFasterResearch4").Value
	local num2 = 100000
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return 2 ^ var5.Stat.Get(arg1, "TreeFasterResearch4").Value
end

tbl2.TreeFasterResearch4 = tbl1
tbl1 = {
	Display = "Better Collection",
	Order = 56,
	Tier = 4,
	RewardDisplay = ("+0.5 <font color=\"#%*\">Leaf</font> click radius"):format(var13),
	Currency = "Leaves",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves2.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 250000
end

tbl1.Reward = function(arg1)
	local num1 = 0
	return var5.Stat.Get(arg1, "TreeBetterLeafCollect2").Value * 0.5
end

tbl2.TreeBetterLeafCollect2 = tbl1
tbl1 = {
	Display = "More Leaves",
	Order = 57,
	Tier = 4,
	RewardDisplay = ("x2 <font color=\"#%*\">Leaves</font> per upgrade"):format(var13),
	Currency = "Wood",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ("x%%s <font color=\"#%*\">Leaves</font>"):format(var13)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeBetterLeafCollect2.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeFasterResearch4.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreGrass5.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1)
	local num1 = 2
	local var1 = var5.Stat.Get(arg1, "TreeMoreLeaves3").Value
	local num2 = 2.5e+19
	return var6.mul(num2, var6.pow(num1, var1))
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(2, var5.Stat.Get(arg1, "TreeMoreLeaves3").Value))
end

tbl2.TreeMoreLeaves3 = tbl1
tbl1 = {
	Display = "More Water",
	Order = 58,
	Tier = 3,
	RewardDisplay = ("x3 <font color=\"#%*\">Water</font>"):format(var8),
	Currency = "Cash",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves3.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 2.5e+49
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(3, var5.Stat.Get(arg1, "TreeMoreWater6").Value))
end

tbl2.TreeMoreWater6 = tbl1
tbl1 = {
	Display = "More Research Cap",
	Order = 59,
	Tier = 4,
	RewardDisplay = ("+10 <font color=\"#%*\">Research Boosts</font> cap"):format(var12),
	Currency = "Grass",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves3.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaperUpgradesCap").Value
	return 5e+23
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return var5.Stat.Get(arg1, "TreeMorePaperUpgradesCap").Value * 10
end

tbl2.TreeMorePaperUpgradesCap = tbl1
tbl1 = {
	Display = "More Paper",
	Order = 60,
	Tier = 4,
	RewardDisplay = ("x5 <font color=\"#%*\">Paper</font>"):format(var11),
	Currency = "Leaves",
	ChangeStat = "UpgradesBought",
}

tbl1.Unlocked = function(arg1)
	return 1 <= arg1.UpgradeTree.TreeMoreLeaves3.Value
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(arg1)
	_ = var5.Stat.Get(arg1, "TreeMorePaper7").Value
	return 25000000
end

tbl1.Reward = function(arg1)
	local num1 = 1
	return (var6.pow(5, var5.Stat.Get(arg1, "TreeMorePaper7").Value))
end

tbl2.TreeMorePaper7 = tbl1
tbl1 = {
	Display = "More Cash",
	Order = 61,
	Tier = 4,
	RewardDisplay = ([[<font color="#%*">Leaf Collects</font> boost <font color="#%*">Cash</font>]]):format(var13, var4),
	Currency = "Soil",
	RewardChange = "LeavesCollected",
	ChangeStat = "UpgradesBought",
}

tbl1.Formatted = ([[x%%s <font color="#%*">Cash</font> based on <font color="#%*">Leaf Collects</font>]]):format(var4, var13)
tbl1.Unlocked = function(arg1)
	local bool2 = false
	if 1 <= arg1.UpgradeTree.TreeMorePaper7.Value then
		bool2 = false
		if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
			bool2 = 1 <= arg1.UpgradeTree.TreeMoreWater6.Value
		end
	end

	return bool2
end

tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_)
	return 5e+58
end

tbl1.Reward = function(arg1)
	local var1 = var5.Stat.Get(arg1, "LeavesCollected")
	local num1 = 1
	if var5.Stat.Get(arg1, "TreeMoreCash12").Value < 1 then
		return num1
	end

	if var6.lt(var1.Value, 5000) then
		return num1
	end

	return (var6.sub(var6.pow(1.95, (var6.sub(var6.log10(var1.Value), 1))), 3))
end

tbl2.TreeMoreCash12 = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.DailyUpgrades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage").Modules.Shared
local var2 = require(var1.StatInformation)
local var3 = require(var1.BigNum)
local var4 = var2.Cash.Colour:ToHex()
local var5 = var2.Soil.Colour:ToHex()
local var6 = var2.Water.Colour:ToHex()
local var7 = var2.Wood.Colour:ToHex()
local var8 = var2.Grass.Colour:ToHex()
local var9 = var2.Paper.Colour:ToHex()
local var10 = var2.Research.Colour:ToHex()
local var11 = var2.Leaves.Colour:ToHex()
local tbl1 = { Display = ("x2 <font color=\"#%*\">Cash</font>"):format(var4), Cap = 1 }
tbl1.Requires = { "DailyMoreRange" }
tbl1.Info = function(arg1)
	return { Price = 5, Reward = 2 ^ arg1 }
end

local tbl2 = {
	DailyMoreWalkspeed = {
		Display = "+5 Walkspeed",
		Unlocked = function(arg1)
			local var1 = arg1.HighestStats.HighestCash.Value
			local num1 = 0
			return var3.gte(var1, num1)
		end,
		ChangeStat = "Cash",
		Cap = 1,
		Info = function(arg1)
			return { Price = 1, Reward = arg1 * 5 }
		end,
	},
	DailyMoreRange = {
		Display = "+1 Range",
		Requires = { "DailyMoreWalkspeed" },
		Cap = 1,
		Info = function(arg1)
			return { Price = 3, Reward = arg1 * 1 }
		end,
	},
	DailyMoreCap = {
		Display = "+5 Plant limit",
		Requires = { "DailyMoreWalkspeed" },
		Cap = 1,
		Info = function(arg1)
			return { Price = 3, Reward = arg1 * 5 }
		end,
	},
	DailyMoreCash = tbl1,
}

tbl1 = { Display = ("x2 <font color=\"#%*\">Soil</font>"):format(var5), Cap = 1 }
tbl1.Requires = { "DailyMoreCap" }
tbl1.Info = function(arg1)
	return { Price = 5, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreSoil = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Water</font>"):format(var6), Cap = 1 }
tbl1.Requires = { "DailyMoreCash", "DailyMoreSoil" }
tbl1.Info = function(arg1)
	return { Price = 10, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreWater = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Wood</font>"):format(var7), Cap = 1 }
tbl1.Requires = { "DailyMoreWater" }
tbl1.Info = function(arg1)
	return { Price = 20, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreWood = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Grass</font>"):format(var8), Cap = 1 }
tbl1.Requires = { "DailyMoreWater" }
tbl1.Info = function(arg1)
	return { Price = 20, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreGrass = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Paper</font>"):format(var9), Cap = 1 }
tbl1.Requires = { "DailyMoreWood", "DailyMoreGrass" }
tbl1.Info = function(arg1)
	return { Price = 35, Reward = 2 ^ arg1 }
end

tbl2.DailyMorePaper = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Research speed</font>"):format(var10), Cap = 1 }
tbl1.Requires = { "DailyMorePaper" }
tbl1.Info = function(arg1)
	return { Price = 35, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreResearchSpeed = tbl1
tbl1 = { Display = ("x2 <font color=\"#%*\">Leaves</font>"):format(var11), Cap = 1 }
tbl1.Requires = { "DailyMoreResearchSpeed" }
tbl1.Info = function(arg1)
	return { Price = 35, Reward = 2 ^ arg1 }
end

tbl2.DailyMoreLeaves = tbl1
local tbl3 = { Currency = "Ruby", Upgrades = tbl2 }
tbl3.IsUnlocked = function(arg1, arg2)
	local var2 = tbl3.Upgrades[arg2]
	if not var2 then
		return false
	end

	if var2.Unlocked then
		local var4 = arg1
		return var2.Unlocked(var4)
	end

	if not var2.Requires then
		return true
	end

	for k1, v1 in var2.Requires, nil do
		local var6 = arg1.DailyUpgrades[v1]
		if not var6 or var6.Value < 1 then
			return false
		end
	end

	return true
end

tbl3.GetWatchedStats = function(arg1)
	local var2 = tbl3.Upgrades[arg1]
	local tbl1 = {}
	if not var2 then
		return tbl1
	end

	local var3 = var2.Requires
	for k1, v1 in var3 or {}, nil do
		table.insert(tbl1, v1)
	end

	if var2.ChangeStat then
		table.insert(tbl1, var2.ChangeStat)
	end

	return tbl1
end

return tbl3

--- ReplicatedStorage.Modules.Shared.Daily [ModuleScript]
-- y u r i

local var1 = require(game:GetService("ReplicatedStorage").Framework)
return { Reward = function(arg1, arg2)
	local var2 = arg2
	return math.min(math.floor(((var2 or var1.Stat.Get(arg1, "DaysClaimed").Value) + 1) / 2), 10) + 1
end }

--- ReplicatedStorage.Modules.Shared.Boosts [ModuleScript]
-- y u r i

return { x2CashBoost = {
	Icon = "rbxassetid://120266853291761",
	Display = "x2 Cash",
	Stat = "Cash",
	Rank = 1,
	Description = "Double Cash!",
} }

--- ReplicatedStorage.Modules.Shared.Water [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = var1.Modules.Shared
require(var2.Seeds)
local var3 = require(var2.BigNum)
return {
	{ Price = 350 },
	{ Price = 1000 },
	{ Price = 5000 },
	{ Price = 15000 },
	{ Price = 50000 },
	{ Price = 150000 },
	{ Price = 750000 },
	{ Price = 5000000 },
	{ Price = 25000000 },
	{ Price = 250000000 },
	{ Price = 750000000 },
	{ Price = 5000000000 },
	{ Price = 25000000000 },
	{ Price = 500000000000 },
	{ Price = 2500000000000 },
	{ Price = 10000000000000 },
	{ Price = 50000000000000 },
	{ Price = 250000000000000 },
	{ Price = 1000000000000000 },
	{ Price = 5000000000000000 },
	{ Price = 2e+16 },
	{ Price = 5e+16 },
	Max = 21,
	Multiplier = function(arg1)
		local num1 = 2
		local var1 = arg1.Stats.WaterLevel.Value
		return var3.pow(num1, var1)
	end,
	[0] = { Price = 100 },
}

--- ReplicatedStorage.Modules.Shared.Tree [ModuleScript]
-- y u r i

game:GetService("Players")
local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = require(var1.Modules.Shared.BigNum)
return {
	Max = 34,
	Pricing = function(arg1)
		local var1 = arg1.Stats.TreeLevel.Value
		local var3 = 3 + var1 / 18.5
		local var4 = var1
		local num1 = 100000
		return var2.mul(num1, var2.pow(var3, var4))
	end,
	Multiplier = function(arg1)
		local num1 = 2
		local var1 = arg1.Stats.TreeLevel.Value
		return var2.pow(num1, var1)
	end,
}

--- ReplicatedStorage.Modules.Shared.Harvest [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
Color3.fromRGB(255, 255, 255):ToHex()
local var3 = require(var2.StatInformation)
local var4 = require(var2.Seeds)
var4.Seeds[0].Colour:ToHex()
var4.Seeds[1].Colour:ToHex()
var4.Seeds[2].Colour:ToHex()
var4.Seeds[3].Colour:ToHex()
var4.Seeds[4].Colour:ToHex()
var4.Seeds[5].Colour:ToHex()
var4.Seeds[6].Colour:ToHex()
var4.Seeds[7].Colour:ToHex()
local var5 = require(var1.Framework)
local var6 = require(var2.BigNum)
local var7 = var3.Cash.Colour:ToHex()
local var8 = var3.Soil.Colour:ToHex()
local var9 = var3.Water.Colour:ToHex()
local var10 = var3.Wood.Colour:ToHex()
local var11 = var3.Harvest.Colour:ToHex()
local var12 = var3.Grass.Colour:ToHex()
local tbl1 = {
	Max = 5,
	Currency = "Cash",
	Rewards = {
		{
			AllStatsBoost = {
				Type = "Function",
				Reward = function(arg1)
					return 2 ^ var5.Stat.Get(arg1, "Harvest").Value
				end,
			},
			SpawnRate = { Type = "Normal", Reward = 2 },
			Walkspeed = { Type = "Normal", Reward = 5, Add = true },
		},
		{
			SpawnLimit = { Type = "Normal", Reward = 5, Add = true },
			UpgradeLimit = { Type = "Normal", Reward = 15, Add = true },
			Cash = { Type = "Normal", Reward = 2 },
		},
		{
			ChoppingSpeed = { Type = "Normal", Reward = 1.5 },
			XP = { Type = "Normal", Reward = 5 },
			Wood = { Type = "Normal", Reward = 3 },
		},
		{ SoilLimit = { Type = "Normal", Reward = 5, Add = true } },
	},
}

local tbl2 = {
	Type = "Text",
	Text = ([[- Automatically convert, buy <font color="#%*">Soil Upgrades</font> without spending <font color="#%*">Soil</font>]]):format(var8, var8),
}

local tbl3 = { tbl2 }
tbl3[2] = { Type = "Text", Text = "- +25 Limit on the first Upgrade in the Upgrade Tree" }
tbl2 = {
	Type = "Text",
	Text = ("- +5 Plant Limit, x2 <font color=\"#%*\">Cash</font>"):format(var7),
}

tbl3[3] = tbl2
local tbl4 = {
	{
		{
			Type = "Function",
			Text = function(arg1)
				return (("- x2 All Stats per <font color=\"#%*\">Harvest</font> %*"):format(var11, 1 <= var5.Stat.GetDataFolder(arg1).Stats.Harvest.Value and ("(x%*)"):format((var6.toSuffix((tbl1.Rewards[1].AllStatsBoost.Reward(arg1))))) or ""))
			end,
			Reward = function(arg1)
				local var1 = arg1
				return tbl1.Rewards[1].AllStatsBoost.Reward(var1)
			end,
		},
		{ Type = "Text", Text = "- +5 Walkspeed" },
		{ Type = "Text", Text = "- x2 Spawn speed" },
	},
	tbl3,
}

tbl2 = {
	Type = "Text",
	Text = ([[- Automatically buy <font color="#%*">Water Upgrades</font> without spending <font color="#%*">Water</font>]]):format(var9, var9),
}

tbl3 = { tbl2 }
tbl2 = {
	Type = "Text",
	Text = ("- 50%% faster <font color=\"#%*\">Chopping</font> speed"):format(var10),
}

tbl3[2] = tbl2
tbl2 = {
	Type = "Text",
	Text = ([[- x5 <font color="#%*">XP</font>, x3 <font color="#%*">Wood</font>]]):format(var9, var10),
}

tbl3[3] = tbl2
tbl4[3] = tbl3
tbl2 = {
	Type = "Text",
	Text = ([[- Automatically buy <font color="#%*">Wood Upgrades</font> without spending <font color="#%*">Wood</font>]]):format(var10, var10),
}

tbl3 = { tbl2 }
tbl2 = {
	Type = "Text",
	Text = ("- Automatically buy <font color=\"#%*\">Upgrade Tree</font> Upgrades 1-18 without spending anything"):format(var7),
}

tbl3[2] = tbl2
tbl2 = {
	Type = "Text",
	Text = ("- +5 <font color=\"#%*\">Soil Upgrades</font> limit"):format(var8),
}

tbl3[3] = tbl2
tbl4[4] = tbl3
tbl2 = { Type = "Text", Text = ("- Unlock <font color=\"#%*\">The Barn</font>"):format(var12) }
tbl4[5] = { tbl2 }
tbl1.Text = tbl4
tbl1.Prices = { 2.5e+19, 1e+22, 1.5e+23, 1e+26, [0] = 2.5e+18 }
return tbl1

--- ReplicatedStorage.Modules.Shared.Pets [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = require(var1.Modules.Shared.BigNum)
local tbl1 = {
	Name = "Doggy",
	Colour = Color3.fromRGB(195, 98, 0),
	Icon = "rbxassetid://89060213437576",
	Rank = 1,
	Multiplier = 1,
	Levels = 10,
	EvolvePrice = 100000,
}

tbl1.Price = function(arg1)
	local num1 = 2.5
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 10
	return var3.floor(var3.mul(num2, var3.pow(num1, var1)))
end

tbl1.Reward = function(arg1)
	return var2.Stat.Get(arg1, "PetLevel").Value + 1
end

local tbl2 = {
	Name = "Kitty",
	Colour = Color3.fromRGB(194, 194, 194),
	Icon = "rbxassetid://105106957098264",
	Rank = 2,
	Multiplier = 5,
	Levels = 10,
	EvolvePrice = 25000000,
}

tbl2.Price = function(arg1)
	local num1 = 1.75
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 10000
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl2.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 2
end

local tbl3 = {
	Name = "Bunny",
	Colour = Color3.fromRGB(255, 170, 255),
	Icon = "rbxassetid://88735140569675",
	Rank = 2,
	Multiplier = 30,
	Levels = 10,
	EvolvePrice = 25000000000,
}

tbl3.Price = function(arg1)
	local num1 = 2.5
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1000000
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl3.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 3
end

local tbl4 = {
	Name = "Deer",
	Colour = Color3.fromRGB(179, 106, 32),
	Icon = "rbxassetid://130526787252717",
	Rank = 3,
	Multiplier = 200,
	Levels = 10,
	EvolvePrice = 50000000000000,
}

tbl4.Price = function(arg1)
	local num1 = 3
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1000000000
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl4.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 3
end

local tbl5 = {
	Name = "Bear",
	Colour = Color3.fromRGB(179, 106, 32),
	Icon = "rbxassetid://71473715169817",
	Rank = 4,
	Multiplier = 800,
	Levels = 10,
	EvolvePrice = 5e+16,
}

tbl5.Price = function(arg1)
	local num1 = 3
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1000000000000
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl5.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 3
end

local tbl6 = { [0] = tbl1 }
local tbl7 = {
	Name = "Monkey",
	Colour = Color3.fromRGB(179, 106, 32),
	Icon = "rbxassetid://107073173174678",
	Rank = 5,
	Multiplier = 2500,
	Levels = 10,
	EvolvePrice = 2.5e+19,
}

tbl7.Price = function(arg1)
	local num1 = 3
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1000000000000000
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl7.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 5
end

local tbl8 = {
	Name = "Elephant",
	Colour = Color3.fromRGB(179, 179, 179),
	Icon = "rbxassetid://120035902645896",
	Rank = 6,
	Multiplier = 7500,
	Levels = 10,
	EvolvePrice = 5e+22,
}

tbl8.Price = function(arg1)
	local num1 = 3
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1e+18
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl8.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 7.5
end

local tbl9 = {
	Name = "Tiger",
	Colour = Color3.fromRGB(218, 156, 32),
	Icon = "rbxassetid://135908576562013",
	Rank = 7,
	Multiplier = 15000,
	Levels = 10,
	EvolvePrice = 1e+30,
}

tbl9.Price = function(arg1)
	local num1 = 3
	local var1 = var2.Stat.Get(arg1, "PetLevel").Value
	local num2 = 1e+21
	return var3.mul(num2, var3.pow(num1, var1))
end

tbl9.Reward = function(arg1)
	return (var2.Stat.Get(arg1, "PetLevel").Value + 1) * 10
end

tbl6 = { tbl2, tbl3, tbl4, tbl5, tbl7, tbl8, tbl9 }
return tbl6

--- ReplicatedStorage.Modules.Shared.Research [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.Seeds)
Color3.fromRGB(255, 255, 255):ToHex()
local var3 = require(var2.StatInformation)
var3.Cash.Colour:ToHex()
var3.Soil.Colour:ToHex()
var3.Water.Colour:ToHex()
var3.Wood.Colour:ToHex()
var3.Harvest.Colour:ToHex()
var3.Grass.Colour:ToHex()
local var4 = require(var1.Framework)
local var5 = require(var2.BigNum)
return {
	Max = 4,
	Currency = "Paper",
	Prices = { 2500, 1000000, 1000000000 },
	Boost = function(arg1)
		local num1 = 2
		local var1 = var4.Stat.Get(arg1, "ResearchLevel").Value - 1
		return var5.pow(num1, var1)
	end,
}

--- ReplicatedStorage.Modules.Shared.ResearchBoosts [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var2.StatInformation)
var3.XP.Colour:ToHex()
var3.Harvest.Colour:ToHex()
local var4 = require(var1.Framework)
local var5 = require(var2.BigNum)
local var6 = var3.Soil.Colour:ToHex()
local var7 = var3.Water.Colour:ToHex()
local var8 = var3.Wood.Colour:ToHex()
local var9 = var3.Research.Colour:ToHex()
local var10 = var3.Grass.Colour:ToHex()
local var11 = var3.Paper.Colour:ToHex()
local var12 = Color3.fromRGB(255, 255, 255):ToHex()
local tbl1 = {
	Display = ("More <font color=\"#%*\">Cash</font>"):format((var3.Cash.Colour:ToHex())),
	Order = 1,
	Icon = "Cash",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMoreCash").Value
	local num2 = 50
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMoreCash").Value) + 1
end

local tbl2 = { ResearchMoreCash = tbl1 }
tbl1 = {
	Display = ("More <font color=\"#%*\">Soil</font>"):format(var6),
	Order = 2,
	Icon = "Soil",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMoreSoil").Value
	local num2 = 100
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMoreSoil").Value) + 1
end

tbl2.ResearchMoreSoil = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Water</font>"):format(var7),
	Order = 3,
	Icon = "Water",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2.5
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMoreWater").Value
	local num2 = 150
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMoreWater").Value) + 1
end

tbl2.ResearchMoreWater = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Wood</font>"):format(var8),
	Order = 4,
	Icon = "Wood",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 1 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2.5
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMoreWood").Value
	local num2 = 250
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMoreWood").Value) + 1
end

tbl2.ResearchMoreWood = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Grass</font>"):format(var10),
	Order = 5,
	Icon = "Grass",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMoreGrass").Value
	local num2 = 1500
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMoreGrass").Value) + 1
end

tbl2.ResearchMoreGrass = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Paper</font>"):format(var11),
	Order = 6,
	Icon = "Paper",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var12
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var9)
tbl1.Cap = function(arg1)
	local num1 = 25
	if 1 <= arg1.UpgradeTree.TreeMorePaperUpgradesCap.Value then
		num1 = num1 + 10
	end

	return num1
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2
	local var2 = var1 or var4.Stat.Get(arg1, "ResearchMorePaper").Value
	local num2 = 500000
	return var5.mul(num2, var5.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "ResearchMorePaper").Value) + 1
end

tbl2.ResearchMorePaper = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.ResearchAutomation [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = var1.Modules.Shared
require(var2.BigNum)
local var3 = require(var2.StatInformation)
var3.Soil.Colour:ToHex()
var3.XP.Colour:ToHex()
Color3.fromRGB(255, 255, 255):ToHex()
local var4 = var3.Water.Colour:ToHex()
local var5 = var3.Cash.Colour:ToHex()
local var6 = var3.Wood.Colour:ToHex()
local var7 = var3.Harvest.Colour:ToHex()
local var8 = var3.Research.Colour:ToHex()
local var9 = var3.Grass.Colour:ToHex()
local var10 = var3.Plant.Colour:ToHex()
local tbl1 = {
	Display = ("Auto <font color=\"#%*\">Water</font>"):format(var4),
	Order = 1,
	Icon = "Water",
	Currency = "Paper",
	ChangeStat = "ResearchLevel",
}

tbl1.RewardDisplay = ("Automatically generate <font color=\"#%*\">Water</font> every second"):format(var4)
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var8)
tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_, _)
	return 10000
end

local tbl2 = { ResearchAutoWater = tbl1 }
tbl1 = {
	Display = ("Auto <font color=\"#%*\">Wood</font>"):format(var6),
	Order = 2,
	Icon = "Wood",
	Currency = "Paper",
	ChangeStat = "ResearchLevel",
}

tbl1.RewardDisplay = ("Automatically generate <font color=\"#%*\">Wood</font> every second"):format(var6)
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var8)
tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_, _)
	return 50000
end

tbl2.ResearchAutoWood = tbl1
tbl1 = {
	Display = ("Auto <font color=\"#%*\">Plant</font>"):format(var10),
	Order = 3,
	Icon = "Plant",
	Currency = "Paper",
	ChangeStat = "ResearchLevel",
}

tbl1.RewardDisplay = ([[Automatically upgrades/evolves your <font color="#%*">Plant</font> every second without spending <font color="#%*">Cash</font>]]):format(var10, var5)
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var8)
tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_, _)
	return 10000000
end

tbl2.ResearchAutoPlantLevel = tbl1
tbl1 = {
	Display = ("Auto <font color=\"#%*\">Harvest</font>"):format(var7),
	Order = 4,
	Icon = "Harvest",
	Currency = "Paper",
	ChangeStat = "ResearchLevel",
}

tbl1.RewardDisplay = ("Automatically <font color=\"#%*\">Harvest</font> without getting reset"):format(var7)
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var8)
tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_, _)
	return 100000000
end

tbl2.ResearchAutoHarvest = tbl1
tbl1 = {
	Display = ("Auto <font color=\"#%*\">Pet</font>"):format(var9),
	Order = 5,
	Icon = "Pet",
	Currency = "Paper",
	ChangeStat = "ResearchLevel",
}

tbl1.RewardDisplay = ([[Automatically upgrades/evolves your <font color="#%*">Pet</font> every second without spending <font color="#%*">Grass</font>]]):format(var9, var9)
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var8)
tbl1.Cap = function(_)
	return 1
end

tbl1.Price = function(_, _)
	return 500000000
end

tbl2.ResearchAutoPet = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.Quests [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var2.StatInformation)
local var4 = require(var2.Boosts)
local var5 = require(var1.Framework.Shared.Short)
local var6 = require(var1.Framework)
return {
	Pool = {
		["Game Enjoyer"] = {
			Display = "Play for %s",
			Requirements = { Daily = 3600, Weekly = 86400 },
			Image = "rbxassetid://95372328415192",
			Format = var5.toFullTime,
			Unlocked = function(_)
				return true
			end,
		},
		Lumberjack = {
			Display = "Hit the tree %s times",
			Requirements = { Daily = 7500, Weekly = 30000 },
			Image = "rbxassetid://116883433801575",
			Unlocked = function(_)
				return true
			end,
		},
		Farmer = {
			Display = "Collect %s Seeds",
			Requirements = { Daily = 10000, Weekly = 100000 },
			Image = "rbxassetid://134021782546764",
			Unlocked = function(_)
				return true
			end,
		},
		Water = {
			Display = "Click the water %s times",
			Requirements = { Daily = 12500, Weekly = 50000 },
			Image = var3.Water.Icon,
			Unlocked = function(_)
				return true
			end,
		},
	},
	Rewards = {
		x2CashBoost = {
			Image = var4.x2CashBoost.Icon,
			Format = var5.toFullTime,
			Chance = 60,
			RewardAmount = function(arg1, arg2)
				local num2 = 900
				local var1 = var6.Stat.Get(arg1, "TreeBetterQuests").Value
				if arg2 == "Weekly" then
					num2 = 3600
				end

				if 1 <= var1 then
					num2 = num2 * 2
				end

				return num2
			end,
		},
		Ruby = {
			Image = var3.Ruby.Icon,
			Format = var5.toSuffix,
			Chance = 40,
			RewardAmount = function(arg1, arg2)
				local num2 = 1
				local var1 = var6.Stat.Get(arg1, "TreeBetterQuests").Value
				if arg2 == "Weekly" then
					num2 = 4
				end

				if 1 <= var1 then
					num2 = num2 * 2
				end

				return num2
			end,
		},
	},
}

--- ReplicatedStorage.Modules.Shared.ResearchUpgrades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
local var3 = require(var2.StatInformation)
var3.XP.Colour:ToHex()
var3.Wood.Colour:ToHex()
var3.Harvest.Colour:ToHex()
local var4 = Color3.fromRGB(255, 255, 255):ToHex()
local var5 = require(var1.Framework)
local var6 = require(var2.BigNum)
local var7 = var3.Cash.Colour:ToHex()
local var8 = var3.Soil.Colour:ToHex()
local var9 = var3.Water.Colour:ToHex()
local var10 = var3.Research.Colour:ToHex()
local var11 = var3.Grass.Colour:ToHex()
local var12 = var3.Paper.Colour:ToHex()
local tbl1 = {
	Display = ("More <font color=\"#%*\">Walkspeed</font>"):format(var4),
	Order = 1,
	Icon = "Walkspeed",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchMoreWalkspeed").Value
	local num2 = 1500
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return var1 or var5.Stat.Get(arg1, "ResearchMoreWalkspeed").Value
end

local tbl2 = { ResearchMoreWalkspeed = tbl1 }
tbl1 = {
	Display = ("More <font color=\"#%*\">Plant</font> capacity"):format(var7),
	Order = 2,
	Icon = "Plant",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 2 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var10)
tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 2.5
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchMoreCap").Value
	local num2 = 2500
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return var1 or var5.Stat.Get(arg1, "ResearchMoreCap").Value
end

tbl2.ResearchMoreCap = tbl1
tbl1 = {
	Display = ("Faster auto <font color=\"#%*\">Grass</font> generation"):format(var11),
	Order = 3,
	Icon = "Grass",
	Currency = "Paper",
	Format = "-%ss",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 3
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchFasterGrass").Value
	local num2 = 250000
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "ResearchFasterGrass").Value) * 0.1
end

tbl2.ResearchFasterGrass = tbl1
tbl1 = {
	Display = ("Faster <font color=\"#%*\">Paper</font> generation"):format(var12),
	Order = 4,
	Icon = "Paper",
	Currency = "Paper",
	Format = "-%ss",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 3 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 3"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 5
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchFasterPaper").Value
	local num2 = 500000
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "ResearchFasterPaper").Value) * 0.1
end

tbl2.ResearchFasterPaper = tbl1
tbl1 = {
	Display = ("Faster lab <font color=\"#%*\">Research</font> time"):format(var10),
	Order = 5,
	Icon = "Research",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 4 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 4"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 3
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchFasterResearch").Value
	local num2 = 1000000000
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "ResearchFasterResearch").Value) * 0.25 + 1
end

tbl2.ResearchFasterResearch = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Soil Upgrades</font> cap"):format(var8),
	Order = 6,
	Icon = "Soil",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 4 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 4"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 10
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchMoreSoilCap").Value
	local num2 = 1000000000
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return var1 or var5.Stat.Get(arg1, "ResearchMoreSoilCap").Value
end

tbl2.ResearchMoreSoilCap = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Water Upgrades</font> cap"):format(var9),
	Order = 7,
	Icon = "Water",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var4
tbl1.Unlocked = function(arg1)
	return 4 <= arg1.Stats.ResearchLevel.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 4"):format(var10)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	local num1 = 10
	local var2 = var1 or var5.Stat.Get(arg1, "ResearchMoreWaterCap").Value
	local num2 = 1000000000
	return var6.mul(num2, var6.pow(num1, var2))
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return var1 or var5.Stat.Get(arg1, "ResearchMoreWaterCap").Value
end

tbl2.ResearchMoreWaterCap = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.ResearchShops [ModuleScript]
-- y u r i

return {
	Boosts = {
		Module = "ResearchBoosts",
		Template = "ResearchBoost",
		Frame = "ResearchBoosts",
		Remote = "UpgradeResearchBoost",
	},
	Automation = {
		Module = "ResearchAutomation",
		Template = "ResearchAuto",
		Frame = "ResearchAutomation",
		Remote = "UpgradeResearchAutomation",
	},
	Upgrades = {
		Module = "ResearchUpgrades",
		Template = "ResearchUpgrade",
		Frame = "ResearchUpgrades",
		Remote = "UpgradeResearchUpgrade",
	},
}

--- ReplicatedStorage.Modules.Shared.Replant [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = var1.Modules.Shared
require(var2.BigNum)
Color3.fromRGB(255, 255, 255):ToHex()
local var3 = require(var2.StatInformation)
var3.Soil.Colour:ToHex()
local var4 = require(var2.Seeds)
var4.Seeds[0].Colour:ToHex()
var4.Seeds[1].Colour:ToHex()
var4.Seeds[2].Colour:ToHex()
var4.Seeds[3].Colour:ToHex()
var4.Seeds[4].Colour:ToHex()
var4.Seeds[5].Colour:ToHex()
var4.Seeds[6].Colour:ToHex()
var4.Seeds[7].Colour:ToHex()
local var5 = var3.Cash.Colour:ToHex()
local var6 = var3.Water.Colour:ToHex()
local var7 = var3.Wood.Colour:ToHex()
local var8 = var3.Harvest.Colour:ToHex()
local var9 = var3.Grass.Colour:ToHex()
local var10 = var3.Paper.Colour:ToHex()
local var11 = var3.Plant.Colour:ToHex()
local var12 = var3.Research.Colour:ToHex()
local tbl1 = { {
	Paper = { Type = "Normal", Reward = 5 },
	Cash = { Type = "Normal", Reward = 10 },
	Grass = { Type = "Normal", Reward = 5 },
} }

tbl1[3] = { Combo = { Type = "Normal", Reward = 2 } }
tbl1[4] = {
	Paper = { Type = "Normal", Reward = 3 },
	Cash = { Type = "Normal", Reward = 5 },
	Grass = { Type = "Normal", Reward = 3 },
	Research = { Type = "Normal", Reward = 2 },
}

tbl1[5] = {
	Paper = { Type = "Normal", Reward = 3 },
	Grass = { Type = "Normal", Reward = 3 },
	Cash = { Type = "Normal", Reward = 15 },
	Water = { Type = "Normal", Reward = 5 },
}

local tbl2 = { Max = 5, Currency = "Cash", Rewards = tbl1 }
local tbl3 = {
	Type = "Text",
	Text = ([[- x5 <font color="#%*">Paper</font>, x5 <font color="#%*">Grass</font>, x10 <font color="#%*">Cash</font>]]):format(var10, var9, var5),
}

local tbl4 = { tbl3 }
tbl3 = {
	Type = "Text",
	Text = ([[- Automatically upgrade your <font color="#%*">Tree</font> without spending <font color="#%*">Water</font>]]):format(var7, var6),
}

tbl4[2] = tbl3
tbl3 = {
	Type = "Text",
	Text = ([[- Your <font color="#%*">Plant</font> does not reset on <font color="#%*">Harvest</font>]]):format(var11, var8),
}

tbl4[3] = tbl3
tbl1 = { tbl4 }
tbl3 = {
	Type = "Text",
	Text = ([[- <font color="#%*">Water</font>, <font color="#%*">Tree</font> Levels don't reset on <font color="#%*">Harvest</font>]]):format(var6, var7, var8),
}

tbl4 = { tbl3 }
tbl3 = {
	Type = "Text",
	Text = ("- Automatically buy <font color=\"#%*\">Upgrade Tree</font> Upgrades 1-31 without spending anything"):format(var5),
}

tbl4[2] = tbl3
tbl3 = {
	Type = "Text",
	Text = ("- Unlock new <font color=\"#%*\">Upgrade Tree</font> Upgrades"):format(var5),
}

tbl4[3] = tbl3
tbl1[2] = tbl4
tbl3 = {
	Type = "Text",
	Text = ("- Significantly improve <font color=\"#%*\">Combo</font> gain"):format(var5),
}

tbl4 = { tbl3 }
tbl3 = {
	Type = "Text",
	Text = ([[- Automatically Upgrade <font color="#%*">Grass Upgrades</font> without spending <font color="#%*">Grass</font>]]):format(var9, var9),
}

tbl4[2] = tbl3
tbl4[3] = { Type = "Text", Text = "- Unlock the Lab" }
tbl1[3] = tbl4
tbl3 = {
	Type = "Text",
	Text = ([[- x3 <font color="#%*">Paper</font>, x3 <font color="#%*">Grass</font>, x5 <font color="#%*">Cash</font>]]):format(var10, var9, var5),
}

tbl4 = { tbl3 }
tbl3 = { Type = "Text", Text = ("- x2 <font color=\"#%*\">Research</font> speed"):format(var12) }
tbl4[2] = tbl3
tbl4[3] = { Type = "Text", Text = "- Unlock Scientists" }
tbl1[4] = tbl4
tbl3 = { Type = "Text", Text = ("- x15 <font color=\"#%*\">Cash</font>"):format(var5) }
tbl4 = { tbl3 }
tbl3 = { Type = "Text", Text = ("- x5 <font color=\"#%*\">Water</font>"):format(var6) }
tbl4[2] = tbl3
tbl3 = {
	Type = "Text",
	Text = ([[- x3 <font color="#%*">Paper</font>, x3 <font color="#%*">Grass</font>]]):format(var10, var9),
}

tbl4[3] = tbl3
tbl1[5] = tbl4
tbl2.Text = tbl1
tbl2.HasFreeTreeUpgrade = function(arg1)
	return 1 <= arg1.Stats.Replant.Value
end

tbl2.KeepsPlantOnHarvest = function(arg1)
	return 1 <= arg1.Stats.Replant.Value
end

tbl2.KeepsLevelsOnHarvest = function(arg1)
	return 2 <= arg1.Stats.Replant.Value
end

tbl2.HasExtendedAutoTree = function(arg1)
	return 2 <= arg1.Stats.Replant.Value
end

tbl2.HasAutoGrassUpgrades = function(arg1)
	return 3 <= arg1.Stats.Replant.Value
end

tbl2.Prices = { 2.5e+34, 3.5e+35, 1e+39, 2.5e+43, [0] = 7.5e+32 }
return tbl2

--- ReplicatedStorage.Modules.Shared.LabBoosts [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.BigNum)
local var3 = require(var2.StatInformation)
var3.Soil.Colour:ToHex()
var3.XP.Colour:ToHex()
var3.Wood.Colour:ToHex()
var3.Harvest.Colour:ToHex()
local var4 = require(var1.Framework)
local var5 = var3.Water.Colour:ToHex()
local var6 = var3.Research.Colour:ToHex()
local var7 = var3.Grass.Colour:ToHex()
local var8 = var3.Paper.Colour:ToHex()
local var9 = var3.Leaves.Colour:ToHex()
local var10 = Color3.fromRGB(255, 255, 255):ToHex()
local var11 = require(var2.Seeds).Seeds[14].Colour:ToHex()
local tbl1 = {
	Display = ("More <font color=\"#%*\">Cash</font>"):format((var3.Cash.Colour:ToHex())),
	Order = 1,
	Icon = "Cash",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var10
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var6)
tbl1.Cap = function(_)
	return 25
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 30 * 2 ^ (var1 or var4.Stat.Get(arg1, "LabMoreCash").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "LabMoreCash").Value) + 1
end

local tbl2 = { LabMoreCash = tbl1 }
tbl1 = {
	Display = ("More <font color=\"#%*\">XP</font>"):format(var5),
	Order = 2,
	Icon = "XP",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var10
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var6)
tbl1.Cap = function(_)
	return 25
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 60 * 2 ^ (var1 or var4.Stat.Get(arg1, "LabMoreXP").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "LabMoreXP").Value) + 1
end

tbl2.LabMoreXP = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Grass</font>"):format(var7),
	Order = 3,
	Icon = "Grass",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var10
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var6)
tbl1.Cap = function(_)
	return 25
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 120 * 2 ^ (var1 or var4.Stat.Get(arg1, "LabMoreGrass").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "LabMoreGrass").Value) + 1
end

tbl2.LabMoreGrass = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Paper</font>"):format(var8),
	Order = 4,
	Icon = "Paper",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var10
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 1"):format(var6)
tbl1.Cap = function(_)
	return 25
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 180 * 2 ^ (var1 or var4.Stat.Get(arg1, "LabMorePaper").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "LabMorePaper").Value) + 1
end

tbl2.LabMorePaper = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Leaves</font>"):format(var9),
	Order = 5,
	Icon = "Leaves",
	Currency = "Paper",
	Format = "x%s",
	ChangeStat = "HighestSeed",
}

tbl1.Colour = var10
tbl1.Unlocked = function(arg1)
	return 14 <= arg1.HighestStats.HighestSeed.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Grape</font> plant"):format(var11)
tbl1.Cap = function(_)
	return 25
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 7200 * 1.75 ^ (var1 or var4.Stat.Get(arg1, "LabMoreLeaves").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var4.Stat.Get(arg1, "LabMoreLeaves").Value) + 1
end

tbl2.LabMoreLeaves = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.LabUpgrades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.BigNum)
local var3 = require(var2.StatInformation)
var3.Soil.Colour:ToHex()
var3.Water.Colour:ToHex()
var3.XP.Colour:ToHex()
var3.Wood.Colour:ToHex()
var3.Harvest.Colour:ToHex()
var3.Grass.Colour:ToHex()
local var4 = var3.Cash.Colour:ToHex()
local var5 = require(var1.Framework)
local var6 = var3.Research.Colour:ToHex()
local var7 = var3.Leaves.Colour:ToHex()
local var8 = Color3.fromRGB(255, 255, 255):ToHex()
local var9 = require(var2.Seeds).Seeds[14].Colour:ToHex()
local tbl1 = {
	Display = ("More <font color=\"#%*\">Combo</font> limit"):format(var4),
	Order = 1,
	Icon = "Cash",
	Currency = "Paper",
	Format = "+%sx",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var8
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var6)
tbl1.Cap = function(_)
	return 10
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 60 * 10 ^ (var1 or var5.Stat.Get(arg1, "LabHigherComboLimit").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "LabHigherComboLimit").Value) * 0.5
end

local tbl2 = { LabHigherComboLimit = tbl1 }
tbl1 = {
	Display = ("Better <font color=\"#%*\">Combo</font> gain"):format(var4),
	Order = 2,
	Icon = "Cash",
	Currency = "Paper",
	Format = "+%s%%",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var8
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var6)
tbl1.Cap = function(_)
	return 5
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 60 * 10 ^ (var1 or var5.Stat.Get(arg1, "LabMoreSlots").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "LabMoreSlots").Value) * 10
end

tbl2.LabBetterCombo = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Research Slots</font>"):format(var8),
	Order = 4,
	Icon = "Research",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "ResearchLevel",
}

tbl1.Colour = var8
tbl1.Unlocked = function(_)
	return true
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Research Level</font> 2"):format(var6)
tbl1.Cap = function(_)
	return 2
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 3600 * 10 ^ (var1 or var5.Stat.Get(arg1, "LabMoreSlots").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return var1 or var5.Stat.Get(arg1, "LabMoreSlots").Value
end

tbl2.LabMoreSlots = tbl1
tbl1 = {
	Display = ("More <font color=\"#%*\">Leaf</font> click radius"):format(var7),
	Order = 5,
	Icon = "Range",
	Currency = "Paper",
	Format = "+%s",
	ChangeStat = "HighestSeed",
}

tbl1.Colour = var8
tbl1.Unlocked = function(arg1)
	return 14 <= arg1.HighestStats.HighestSeed.Value
end

tbl1.LockedText = ("Unlocked at <font color=\"#%*\">Grape</font> plant"):format(var9)
tbl1.Cap = function(_)
	return 2
end

tbl1.Price = function(arg1, arg2)
	local var1 = arg2
	return 270000 * 7.5 ^ (var1 or var5.Stat.Get(arg1, "LabBetterLeafCollect").Value)
end

tbl1.Reward = function(arg1, arg2)
	local var1 = arg2
	local num1 = 1
	return (var1 or var5.Stat.Get(arg1, "LabBetterLeafCollect").Value) * 0.5
end

tbl2.LabBetterLeafCollect = tbl1
return tbl2

--- ReplicatedStorage.Modules.Shared.LabShops [ModuleScript]
-- y u r i

return {
	Boosts = {
		Module = "LabBoosts",
		Template = "LabBoost",
		Frame = "LabBoosts",
		Remote = "LabUpgrade",
	},
	Upgrades = {
		Module = "LabUpgrades",
		Template = "LabUpgrade",
		Frame = "LabUpgrades",
		Remote = "LabUpgrade",
	},
}

--- ReplicatedStorage.Modules.Shared.Scientists [ModuleScript]
-- y u r i

Color3.fromRGB(255, 255, 255)
local var1 = require(script.Parent.StatInformation)
local var2 = require(game:GetService("ReplicatedStorage").Framework)
local var3 = Color3.fromRGB(0, 208, 255)
local var4 = var1.Leaves.Colour
return {
	{
		Display = "Noob",
		Icon = "rbxassetid://86320950698701",
		Price = 15000000000,
		Unlocked = function(_)
			return true
		end,
		Boosts = { Paper = { Display = "x%s Paper", Reward = 3, Colour = var1.Paper.Colour, Order = 1 } },
	},
	{
		Display = "Amateur",
		Icon = "rbxassetid://108486676808435",
		Price = 100000000000,
		Unlocked = function(_)
			return true
		end,
		Boosts = {
			FasterResearch = { Display = "x%s Research speed", Reward = 1.5, Colour = var1.Research.Colour, Order = 1 },
			ResearchSlots = { Display = "+%s Research Slot", Reward = 1, Colour = var3, Order = 2 },
		},
	},
	{
		Display = "Farmer",
		Icon = "rbxassetid://113506866009879",
		Price = 150000000000,
		Unlocked = function(_)
			return true
		end,
		Boosts = {
			Grass = { Display = "x%s Grass", Reward = 3, Colour = var1.Grass.Colour, Order = 1 },
			Cash = { Display = "x%s Cash", Reward = 2, Colour = var1.Cash.Colour, Order = 2 },
			Bulk = { Display = "+%s Plant bulk", Reward = 1, Colour = var1.Plant.Colour, Order = 3 },
		},
	},
	{
		Display = "Gardener",
		Icon = "rbxassetid://81693069357456",
		Price = 5000000000000,
		Unlocked = function(arg1)
			return 14 <= var2.Stat.Get(arg1, "HighestSeed").Value
		end,
		ChangeStat = "HighestSeed",
		Boosts = {
			Leaves = { Display = "x%s Leaves", Reward = 2, Colour = var4, Order = 1 },
			ClickRadius = { Display = "+%s Leaf click radius", Reward = 0.5, Colour = var4, Order = 2 },
		},
	},
}

--- ReplicatedStorage.Modules.Shared.Bank [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
require(var1.Framework)
local var2 = var1.Modules.Shared
require(var2.BigNum)
local var3 = require(var2.StatInformation)
var3.Harvest.Colour:ToHex()
var3.Replant.Colour:ToHex()
local var4 = Color3.fromRGB(255, 255, 255):ToHex()
local var5 = var3.Cash.Colour:ToHex()
local var6 = var3.Soil.Colour:ToHex()
local var7 = var3.Water.Colour:ToHex()
local var8 = var3.Wood.Colour:ToHex()
local var9 = var3.Grass.Colour:ToHex()
local var10 = var3.Research.Colour:ToHex()
local var11 = var3.Plant.Colour:ToHex()
local var12 = var3.Paper.Colour:ToHex()
local tbl1 = { Type = "Text", Text = ("- x2 <font color=\"#%*\">Cash</font>"):format(var5) }
local tbl2 = {
	tbl1,
	{ Type = "Text", Text = ("- +0.5 <font color=\"#%*\">Range</font>"):format(var4) },
}

local tbl3 = { tbl2 }
tbl2 = { { Type = "Text", Text = ("- x2 <font color=\"#%*\">Soil</font>"):format(var6) } }
tbl3[2] = tbl2
tbl2 = { { Type = "Text", Text = ("- x2 <font color=\"#%*\">XP</font>"):format(var7) } }
tbl3[3] = tbl2
tbl1 = { Type = "Text", Text = ("- x2 <font color=\"#%*\">Water</font>"):format(var7) }
tbl2 = { tbl1, { Type = "Text", Text = ("- x2 <font color=\"#%*\">Wood</font>"):format(var8) } }
tbl3[4] = tbl2
tbl1 = { Type = "Text", Text = ("- +5 <font color=\"#%*\">Plant</font> limit"):format(var11) }
tbl2 = { tbl1, { Type = "Text", Text = ("- x2 <font color=\"#%*\">Grass</font>"):format(var9) } }
tbl3[5] = tbl2
tbl2 = { { Type = "Text", Text = ("- x3 <font color=\"#%*\">Paper</font>"):format(var12) } }
tbl3[6] = tbl2
tbl2 = { { Type = "Text", Text = ("- x1.5 <font color=\"#%*\">Lab</font> speed"):format(var10) } }
tbl3[7] = tbl2
local tbl4 = {
	Max = 6,
	Currency = "Ruby",
	DepositStat = "DepositedRuby",
	Rewards = {
		{
			Cash = { Type = "Normal", Reward = 2 },
			Range = { Type = "Normal", Reward = 0.5, Add = true },
		},
		{ Soil = { Type = "Normal", Reward = 2 } },
		{ XP = { Type = "Normal", Reward = 2 } },
		{ Water = { Type = "Normal", Reward = 2 }, Wood = { Type = "Normal", Reward = 2 } },
		{
			Cap = { Type = "Normal", Reward = 5, Add = true },
			Grass = { Type = "Normal", Reward = 2 },
		},
		{ Paper = { Type = "Normal", Reward = 3 } },
		{ LabSpeed = { Type = "Normal", Reward = 1.5 } },
	},
	Text = tbl3,
}

tbl4.Prices = { 10, 25, 50, 100, 150, 200, 350, 650, 1150, 1750 }
return tbl4

--- ReplicatedStorage.Modules.Shared.Zones [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.StatInformation)
require(var2.Boosts)
require(var1.Framework.Shared.Short)
local var3 = require(var2.Seeds)
var3.Seeds[13].Colour:ToHex()
local var4 = require(var1.Framework)
local var5 = var3.Seeds[14].Colour:ToHex()
local tbl1 = {
	Display = "Zone 2",
	Unlocked = function(arg1)
		return 14 <= var4.Stat.Get(arg1, "HighestSeed").Value
	end,
	ViewStat = "HighestSeed",
	Visible = function(arg1)
		return 13 <= var4.Stat.Get(arg1, "HighestSeed").Value
	end,
	VisibleStat = "HighestSeed",
	LockedMessage = ("Reach <font color=\"#%*\">Grape</font> Seed to unlock area"):format(var5),
}

local tbl2 = {}
tbl2[2] = tbl1
return { Zones = tbl2 }

--- ReplicatedStorage.Modules.Shared.Achievements [ModuleScript]
-- y u r i

local tbl1 = {}
for k1, v1 in script:GetChildren() do
	tbl1[v1.Name] = require(v1)
end

return tbl1

--- ReplicatedStorage.Modules.Shared.Achievements.PlayTimeAchievement [ModuleScript]
-- y u r i

local tbl1 = {}
return {
	Stat = "PlayTime",
	Display = "Play Time",
	Rank = 1,
	Icon = "Time",
	RewardStat = "Diamond",
	ShortenType = "Time",
	Milestones = {
		{ Req = 7200, Reward = 1 },
		{ Req = 14400, Reward = 1 },
		{ Req = 28800, Reward = 2 },
		{ Req = 86400, Reward = 3 },
		{ Req = 172800, Reward = 4 },
		{ Req = 345600, Reward = 5 },
		{ Req = 691200, Reward = 6 },
		{ Req = 1382400, Reward = 6 },
		{ Req = 2764800, Reward = 6 },
		{ Req = 5529600, Reward = 6 },
		{ Req = 11059200, Reward = 7 },
		{ Req = 22118400, Reward = 8 },
	},
}

--- ReplicatedStorage.Modules.Shared.Achievements.ClicksAchievement [ModuleScript]
-- y u r i

local tbl1 = {}
return {
	Stat = "Clicks",
	Display = "Clicks",
	Rank = 2,
	Icon = "Clicker",
	RewardStat = "Diamond",
	Milestones = {
		{ Req = 5000, Reward = 1 },
		{ Req = 7500, Reward = 1 },
		{ Req = 12500, Reward = 1 },
		{ Req = 25000, Reward = 2 },
		{ Req = 50000, Reward = 3 },
		{ Req = 100000, Reward = 3 },
		{ Req = 200000, Reward = 4 },
		{ Req = 400000, Reward = 4 },
		{ Req = 1000000, Reward = 5 },
		{ Req = 2000000, Reward = 6 },
		{ Req = 5000000, Reward = 6 },
		{ Req = 10000000, Reward = 7 },
	},
}

--- ReplicatedStorage.Modules.Shared.Achievements.CollectsAchievement [ModuleScript]
-- y u r i

local tbl1 = {}
return {
	Stat = "Collects",
	Display = "Collects",
	Rank = 3,
	Icon = "Collects",
	RewardStat = "Diamond",
	Milestones = {
		{ Req = 50000, Reward = 1 },
		{ Req = 100000, Reward = 1 },
		{ Req = 200000, Reward = 1 },
		{ Req = 500000, Reward = 2 },
		{ Req = 1000000, Reward = 2 },
		{ Req = 2500000, Reward = 2 },
		{ Req = 7500000, Reward = 3 },
		{ Req = 25000000, Reward = 3 },
		{ Req = 100000000, Reward = 3 },
		{ Req = 500000000, Reward = 4 },
		{ Req = 1000000000, Reward = 5 },
		{ Req = 10000000000, Reward = 6 },
	},
}

--- ReplicatedStorage.Modules.Shared.Achievements.TreeHitsAchievement [ModuleScript]
-- y u r i

local tbl1 = {}
return {
	Stat = "TreeHits",
	Display = "Tree Hits",
	Rank = 4,
	Icon = "Axe",
	RewardStat = "Diamond",
	Milestones = {
		{ Req = 2500, Reward = 1 },
		{ Req = 5000, Reward = 1 },
		{ Req = 7500, Reward = 1 },
		{ Req = 12500, Reward = 2 },
		{ Req = 20000, Reward = 2 },
		{ Req = 35000, Reward = 2 },
		{ Req = 75000, Reward = 3 },
		{ Req = 150000, Reward = 3 },
		{ Req = 500000, Reward = 3 },
		{ Req = 1000000, Reward = 4 },
		{ Req = 5000000, Reward = 5 },
		{ Req = 10000000, Reward = 6 },
	},
}

--- ReplicatedStorage.Modules.Shared.Leaves [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = var1.Modules.Shared
require(var2.StatInformation)
require(var2.Boosts)
require(var1.Framework.Shared.Short)
local var3 = require(var1.Framework)
local var4 = require(var2.BigNum)
return {
	FieldCap = 100,
	FieldMargin = 2,
	MobileHoverRadius = 0.5,
	Levels = { 250, 500, 1250, 2500, 7500, 15000, 30000, 75000, 150000 },
	IsInField = function(arg1, arg2, arg3)
		local var1 = arg1.CFrame:PointToObjectSpace(arg2)
		local var2 = arg3 or 0
		local bool1 = false
		if math.abs(var1.X) <= arg1.Size.X / 2 + var2 then
			bool1 = math.abs(var1.Z) <= arg1.Size.Z / 2 + var2
		end

		return bool1
	end,
	Reward = function(arg1)
		local num1 = 2
		local var1 = var3.Stat.Get(arg1, "LeavesLevel").Value - 1
		return var4.pow(num1, var1)
	end,
}

--- ReplicatedStorage.Modules.Shared.LeafUpgrades [ModuleScript]
-- y u r i

local var1 = game:GetService("ReplicatedStorage")
local var2 = require(var1.Framework)
local var3 = require(var1.Modules.Shared.BigNum)
local tbl1 = {
	Currency = "Leaves",
	Display = "Leaves",
	Board = "LeafUpgrades",
	Upgrades = {
		LeafMoreCash = {
			Rank = 1,
			Format = "x%s",
			Display = "More Cash",
			Icon = "Cash",
			Unlocked = function(arg1)
				return 14 <= var2.Stat.Get(arg1, "HighestSeed").Value
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 100
			end,
			Reward = function(arg1, arg2)
				local var1 = arg2
				local var4 = var1 or var2.Stat.Get(arg1, "LeafMoreCash").Value
				local num1 = 1
				local num2 = 1.2
				return var3.pow(num2, var3.log(var3.add(var4, num1)))
			end,
		},
		LeafMoreGrass = {
			Rank = 2,
			Format = "x%s",
			Display = "More Grass",
			Icon = "Grass",
			Unlocked = function(arg1)
				return 14 <= var2.Stat.Get(arg1, "HighestSeed").Value
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 100
			end,
			Reward = function(arg1, arg2)
				local var1 = arg2
				local var4 = var1 or var2.Stat.Get(arg1, "LeafMoreGrass").Value
				local num1 = 1
				local num2 = 1.2
				return var3.pow(num2, var3.log(var3.add(var4, num1)))
			end,
		},
		LeafMoreLeaves = {
			Rank = 3,
			Format = "x%s",
			Display = "More Leaves",
			Icon = "Leaves",
			Unlocked = function(arg1)
				return 14 <= var2.Stat.Get(arg1, "HighestSeed").Value
			end,
			ChangeStat = "HighestSeed",
			Cap = function(_)
				return 100
			end,
			Reward = function(arg1, arg2)
				local var1 = arg2
				var1 = var1 or var2.Stat.Get(arg1, "LeafMoreLeaves").Value
				local var4 = var1
				local num1 = 1
				local var5 = var3.log10(var3.add(var4, num1))
				local var6 = var1
				local num2 = 1
				var4 = 1.03
				local var7 = var3.mul(var5, var3.pow(var4, var3.log(var3.add(var6, num2))))
				var5 = 1
				return var3.max(var7, var5)
			end,
		},
	},
}

tbl1.GetBoost = function(arg1, arg2, arg3)
	local var4 = tbl1.Upgrades[arg2]
	if not var4 or (not var2.Stat.Get(arg1, arg2)) then
		local num2 = 1
		return var3.toBN(num2)
	end

	local var5 = arg1
	local var6 = var4.Reward(arg1, arg3)
	return var3.min(var6, var4.Cap(var2.Stat.GetDataFolder(var5)))
end

tbl1.IsMaxed = function(arg1, arg2)
	local var4 = tbl1.Upgrades[arg2]
	if not var4 or (not var2.Stat.Get(arg1, arg2)) then
		return false
	end

	local var5 = arg1
	local var6 = var4.Reward(arg1)
	return var3.gte(var6, var4.Cap(var2.Stat.GetDataFolder(var5)))
end

return tbl1

--- ReplicatedStorage.Assets.Features.Quests.shadowwsparoww.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- ReplicatedStorage.Assets.Scientists.4.Animate [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = var1:WaitForChild("Torso")
var2:WaitForChild("Neck")
local success, result = pcall(function()
	local str1 = "UserAnimateRemoveEmoteChatHook"
	return UserSettings():IsUserFeatureEnabled(str1)
end)

local var3 = nil
var3 = success and result
local var4 = var2:WaitForChild("Right Shoulder")
local var5 = var2:WaitForChild("Left Shoulder")
local var6 = var2:WaitForChild("Right Hip")
local var7 = var2:WaitForChild("Left Hip")
local var8 = var1:WaitForChild("Humanoid")
local tbl1 = {}
function configureAnimationSet(arg1, arg2)
	local var1
	local var2
	if tbl1[arg1] ~= nil then
		for k1, v1 in pairs(tbl1[arg1].connections) do
			v1:disconnect()
		end
	end

	tbl1[arg1] = {}
	tbl1[arg1].count = 0
	tbl1[arg1].totalWeight = 0
	tbl1[arg1].connections = {}
	local var4 = script:FindFirstChild(arg1)
	local var5
	if var4 ~= nil then
		var2 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var4.ChildAdded:connect(var2))
		var2 = function(_)
			configureAnimationSet(arg1, arg2)
		end

		table.insert(tbl1[arg1].connections, var4.ChildRemoved:connect(var2))
		local num1 = 1
		for k2, v2 in pairs(var4:GetChildren()) do
			if not v2:IsA("Animation") then
				continue
			end

			local function fn2(_)
				configureAnimationSet(arg1, arg2)
			end

			table.insert(tbl1[arg1].connections, v2.Changed:connect(fn2))
			tbl1[arg1][num1] = {}
			tbl1[arg1][num1].anim = v2
			local var7 = v2:FindFirstChild("Weight")
			if var7 == nil then
				tbl1[arg1][num1].weight = 1
			else
				tbl1[arg1][num1].weight = var7.Value
			end

			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + tbl1[arg1][num1].weight
			num1 = num1 + 1
		end
	end

	if tbl1[arg1].count <= 0 then
		for k3, v3 in pairs(arg2) do
			tbl1[arg1][k3] = {}
			tbl1[arg1][k3].anim = Instance.new("Animation")
			tbl1[arg1][k3].anim.Name = arg1
			tbl1[arg1][k3].anim.AnimationId = v3.id
			tbl1[arg1][k3].weight = v3.weight
			tbl1[arg1].count = tbl1[arg1].count + 1
			tbl1[arg1].totalWeight = tbl1[arg1].totalWeight + v3.weight
		end
	end
end

local tbl2 = {
	idle = {
		{ id = "http://www.roblox.com/asset/?id=180435571", weight = 9 },
		{ id = "http://www.roblox.com/asset/?id=180435792", weight = 1 },
	},
	walk = { { id = "http://www.roblox.com/asset/?id=180426354", weight = 10 } },
	run = { { id = "run.xml", weight = 10 } },
	jump = { { id = "http://www.roblox.com/asset/?id=125750702", weight = 10 } },
	fall = { { id = "http://www.roblox.com/asset/?id=180436148", weight = 10 } },
	climb = { { id = "http://www.roblox.com/asset/?id=180436334", weight = 10 } },
	sit = { { id = "http://www.roblox.com/asset/?id=178130996", weight = 10 } },
	toolnone = { { id = "http://www.roblox.com/asset/?id=182393478", weight = 10 } },
	toolslash = { { id = "http://www.roblox.com/asset/?id=129967390", weight = 10 } },
	toollunge = { { id = "http://www.roblox.com/asset/?id=129967478", weight = 10 } },
	wave = { { id = "http://www.roblox.com/asset/?id=128777973", weight = 10 } },
	point = { { id = "http://www.roblox.com/asset/?id=128853357", weight = 10 } },
	dance1 = {
		{ id = "http://www.roblox.com/asset/?id=182435998", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491037", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491065", weight = 10 },
	},
	dance2 = {
		{ id = "http://www.roblox.com/asset/?id=182436842", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491248", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491277", weight = 10 },
	},
	dance3 = {
		{ id = "http://www.roblox.com/asset/?id=182436935", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491368", weight = 10 },
		{ id = "http://www.roblox.com/asset/?id=182491423", weight = 10 },
	},
	laugh = { { id = "http://www.roblox.com/asset/?id=129423131", weight = 10 } },
	cheer = { { id = "http://www.roblox.com/asset/?id=129423030", weight = 10 } },
}

function scriptChildModified(arg1)
	local var2 = tbl2[arg1.Name]
	if var2 ~= nil then
		configureAnimationSet(arg1.Name, var2)
	end
end

script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local str1 = "Standing"
result = ""
local var9 = nil
local var10 = nil
local var11 = nil
local num1 = 1
local var13 = if var8 then var8:FindFirstChildOfClass("Animator") else nil
local tbl3 = { "dance1", "dance2", "dance3" }
local tbl4 = {
	wave = false,
	point = false,
	dance1 = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false,
}

local var14
local var15
if var13 then
	for k1, v1 in ipairs((var13:GetPlayingAnimationTracks())) do
		v1:Stop(0)
		v1:Destroy()
	end
end

for k2, v2 in pairs(tbl2) do
	configureAnimationSet(k2, v2)
end

function stopAllAnimations()
	local var1 = result
	if tbl4[var1] ~= nil and tbl4[var1] == false then
		var1 = "idle"
	end

	result = ""
	var9 = nil
	if var11 ~= nil then
		var11:disconnect()
	end

	if var10 ~= nil then
		var10:Stop()
		var10:Destroy()
		var10 = nil
	end

	return var1
end

function setAnimationSpeed(arg1)
	if arg1 ~= num1 then
		num1 = arg1
		var10:AdjustSpeed(num1)
	end
end

function keyFrameReachedFunc(arg1)
	if arg1 == "End" then
		local var2 = result
		if tbl4[var2] ~= nil and tbl4[var2] == false then
			var2 = "idle"
		end

		playAnimation(var2, 0, var8)
		setAnimationSpeed(num1)
	end
end

function playAnimation(arg1, arg2, arg3)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num2 = 1
	while tbl1[arg1][num2].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num2].weight
		num2 = num2 + 1
	end

	local var4 = tbl1[arg1][num2].anim
	if var4 ~= var9 then
		if var10 ~= nil then
			var10:Stop(arg2)
			var10:Destroy()
		end

		num1 = 1
		var10 = arg3:LoadAnimation(var4)
		var10.Priority = Enum.AnimationPriority.Core
		var10:Play(arg2)
		result = arg1
		var9 = var4
		if var11 ~= nil then
			var11:disconnect()
		end

		var11 = var10.KeyframeReached:connect(keyFrameReachedFunc)
	end
end

local str2 = ""
function toolKeyFrameReachedFunc(arg1)
	if arg1 == "End" then
		playToolAnimation(str2, 0, var8)
	end
end

local var16 = nil
local var17 = nil
local var18 = nil
function playToolAnimation(arg1, arg2, arg3, arg4)
	local var1 = math.random(1, tbl1[arg1].totalWeight)
	local num1 = 1
	while tbl1[arg1][num1].weight < var1 do
		local var2 = var1
		var1 = var1 - tbl1[arg1][num1].weight
		num1 = num1 + 1
	end

	local var4 = tbl1[arg1][num1].anim
	if var16 ~= var4 then
		if var17 ~= nil then
			var17:Stop()
			var17:Destroy()
			arg2 = 0
		end

		var17 = arg3:LoadAnimation(var4)
		if arg4 then
			var17.Priority = arg4
		end

		var17:Play(arg2)
		str2 = arg1
		var16 = var4
		var18 = var17.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end

function stopToolAnimations()
	local var1 = str2
	if var18 ~= nil then
		var18:disconnect()
	end

	str2 = ""
	var16 = nil
	if var17 ~= nil then
		var17:Stop()
		var17:Destroy()
		var17 = nil
	end

	return var1
end

function onRunning(arg1)
	arg1 = arg1 / var1:GetScale()
	if 0.01 < arg1 then
		playAnimation("walk", 0.1, var8)
		if var9 and var9.AnimationId == "http://www.roblox.com/asset/?id=180426354" then
			setAnimationSpeed(arg1 / 14.5)
		end

		str1 = "Running"
		return
	end

	if tbl4[result] == nil then
		playAnimation("idle", 0.1, var8)
		str1 = "Standing"
	end
end

function onDied()
	str1 = "Dead"
end

local num2 = 0
function onJumping()
	playAnimation("jump", 0.1, var8)
	num2 = 0.3
	str1 = "Jumping"
end

function onClimbing(arg1)
	playAnimation("climb", 0.1, var8)
	setAnimationSpeed(arg1 / var1:GetScale() / 12)
	str1 = "Climbing"
end

function onGettingUp()
	str1 = "GettingUp"
end

function onFreeFall()
	if num2 <= 0 then
		playAnimation("fall", 0.3, var8)
	end

	str1 = "FreeFall"
end

function onFallingDown()
	str1 = "FallingDown"
end

function onSeated()
	str1 = "Seated"
end

function onPlatformStanding()
	str1 = "PlatformStanding"
end

function onSwimming(arg1)
	if 0 < arg1 then
		str1 = "Running"
		return
	end

	str1 = "Standing"
end

function getTool()
	for k1, v1 in ipairs(var1:GetChildren()) do
		if v1.className ~= "Tool" then
			continue
		end

		return v1
	end

	return nil
end

function getToolAnim(arg1)
	for k1, v1 in ipairs(arg1:GetChildren()) do
		if v1.Name ~= "toolanim" then
			continue
		end

		if v1.className ~= "StringValue" then
			continue
		end

		return v1
	end

	return nil
end

local str3 = "None"
function animateTool()
	if str3 == "None" then
		playToolAnimation("toolnone", 0.1, var8, Enum.AnimationPriority.Idle)
		return
	end

	if str3 == "Slash" then
		playToolAnimation("toolslash", 0, var8, Enum.AnimationPriority.Action)
		return
	end

	if str3 == "Lunge" then
		playToolAnimation("toollunge", 0, var8, Enum.AnimationPriority.Action)
		return
	end
end

function moveSit()
	var4.MaxVelocity = 0.15
	var5.MaxVelocity = 0.15
	var4:SetDesiredAngle(1.57)
	var5:SetDesiredAngle(-1.57)
	var6:SetDesiredAngle(1.57)
	var7:SetDesiredAngle(-1.57)
end

local num3 = 0
local num4 = 0
function move(arg1)
	local var1 = arg1 - num3
	num3 = arg1
	local num1 = 1
	local num5 = 1
	local bool1 = false
	if 0 < num2 then
		local var2 = num2 - var1
		num2 = var2
	end

	if str1 == "FreeFall" and num2 <= 0 then
		playAnimation("fall", 0.3, var8)
	else
		if str1 == "Seated" then
			playAnimation("sit", 0.5, var8)
			return
		end

		if str1 == "Running" then
			playAnimation("walk", 0.1, var8)
		else
			if str1 == "Dead" or (str1 == "GettingUp" or (str1 == "FallingDown" or (str1 == "Seated" or str1 == "PlatformStanding"))) then
				stopAllAnimations()
				num1 = 0.1
				num5 = 1
				bool1 = true
			end
		end
	end

	if bool1 then
		local var3 = num1 * math.sin(arg1 * num5)
		var4:SetDesiredAngle(var3 + 0)
		var5:SetDesiredAngle(var3 - 0)
		var6:SetDesiredAngle(-var3)
		var7:SetDesiredAngle(-var3)
	end

	local var11 = getTool()
	if var11 then
		if var11:FindFirstChild("Handle") then
			local var14 = getToolAnim(var11)
			if var14 then
				str3 = var14.Value
				var14.Parent = nil
				num4 = arg1 + 0.3
			end

			if num4 < arg1 then
				num4 = 0
				str3 = "None"
			end

			animateTool()
			return
		end
	end

	stopToolAnimations()
	str3 = "None"
	var16 = nil
	num4 = 0
end

var8.Died:connect(onDied)
var8.Running:connect(onRunning)
var8.Jumping:connect(onJumping)
var8.Climbing:connect(onClimbing)
var8.GettingUp:connect(onGettingUp)
var8.FreeFalling:connect(onFreeFall)
var8.FallingDown:connect(onFallingDown)
var8.Seated:connect(onSeated)
var8.PlatformStanding:connect(onPlatformStanding)
var8.Swimming:connect(onSwimming)
if not var3 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(arg1)
		local str3 = ""
		if arg1 == "/e dance" then
			str3 = tbl3[math.random(1, #tbl3)]
		else
			if string.sub(arg1, 1, 3) == "/e " then
				str3 = string.sub(arg1, 4)
			else
				if string.sub(arg1, 1, 7) == "/emote " then
					str3 = string.sub(arg1, 8)
				end
			end
		end

		if str1 == "Standing" and tbl4[str3] ~= nil then
			playAnimation(str3, 0.1, var8)
		end
	end)

end

local var19 = script:WaitForChild("PlayEmote")
var19.OnInvoke = function(arg1)
	if str1 ~= "Standing" then
		return
	end

	if tbl4[arg1] ~= nil then
		playAnimation(arg1, 0.1, var8)
		return true, var10
	end

	return false
end

playAnimation("idle", 0.1, var8)
while var1.Parent ~= nil do
	local var20, var21 = wait(0.1)
	move(var21)
end

--- ReplicatedStorage.Assets.Scientists.4.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.Map.SecretShedwa.Script [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- Workspace.hspspjl.Health [Script]
-- Failed to get bytecode:
--[[
nil
--]]

--- ReplicatedFirst.LoadingScreen [LocalScript]
-- y u r i

local var1 = game:GetService("Players").LocalPlayer
local var2 = script.LoadingGui:Clone()
local var3 = var2.container
local var4 = var3.loading
local var5 = var4.bar
local var6 = var4.tip
local tbl1 = {
	0.47,
	0.39,
	0.38,
	0.42,
	0.5,
	0.6,
	0.655,
	0.549,
	0.412,
	0.281,
	0.187,
	0.164,
	0.187,
	0.267,
	0.412,
	0.566,
	0.68,
	0.76,
	0.8,
	0.72,
	0.47,
}

local var7 = game:GetService("TweenService")
local var8 = game:GetService("ReplicatedStorage")
local var9 = game:GetService("ReplicatedFirst")
local var10 = game:GetService("ContentProvider")
local var11 = game:GetService("RunService")
local var12 = var1:WaitForChild("PlayerGui")
local var13 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local var14 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local tbl2 = {
	MeshPart = { "MeshId", "TextureID" },
	SpecialMesh = { "MeshId", "TextureId" },
	Decal = { "Texture" },
	Sound = { "SoundId" },
	ParticleEmitter = { "Texture" },
	Beam = { "Texture" },
	Trail = { "Texture" },
	ImageLabel = { "Image" },
	ImageButton = { "Image" },
	SurfaceAppearance = { "ColorMap", "NormalMap", "MetalnessMap", "RoughnessMap" },
}

local function AddContent(arg1, arg2)
	local var1 = nil
	for k1, v1 in tbl2, nil do
		if not arg2:IsA(k1) then
			continue
		end

		var1 = v1
		break
	end

	if not var1 then
		return
	end

	for k2, v2 in var1, nil do
		local success, result = pcall(function()
			return arg2[v2]
		end)

		if not success then
			continue
		end

		if typeof(result) == "Content" then
			result = result.Uri
		end

		if type(result) ~= "string" or result == "" then
			continue
		end

		arg1[result] = true
	end
end

local var15 = var4.leaves
local var16 = var5.img.UIGradient
local num1 = -1
local function SetBarFill(arg1)
	if arg1 <= 0 then
		var16.Transparency = NumberSequence.new(1)
		return
	end

	if 1 <= arg1 then
		var16.Transparency = NumberSequence.new(0)
		return
	end

	local var1 = math.clamp(arg1, 0.002, 0.998)
	local num1 = 1
	local num2 = 1
	var16.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(var1 - 0.001, 0),
		NumberSequenceKeypoint.new(var1, 1),
		NumberSequenceKeypoint.new(num1, num2),
	})
end

local var17 = var5.Position.X.Scale
local var18 = var5.Size.X.Scale
local var19 = var6.Size.X.Scale / 2
local var20 = var5.Position.Y.Scale
local var21 = var5.Size.Y.Scale
local var22 = var6.Size.Y.Scale / 2
local var23 = (function()
	local tbl1 = {}
	local var1 = var15.Position.X.Scale
	local var2 = var15.Size.X.Scale
	local var3 = var5.Position.X.Scale
	local var4 = var5.Size.X.Scale
	for k1, v1 in var15:GetChildren() do
		if not v1:IsA("GuiObject") then
			continue
		end

		v1.AnchorPoint = Vector2.new(0.5, 0.5)
		local var6 = v1.Size
		local var7 = v1.Position + UDim2.fromScale(var6.X.Scale / 2, var6.Y.Scale / 2)
		v1.Position = var7
		v1.Visible = false
		v1.Size = UDim2.new()
		var7 = var1 + v1.Position.X.Scale * var2
		table.insert(tbl1, {
			Object = v1,
			Size = var6,
			Shown = false,
			Tween = nil,
			Threshold = if 0 < var4 then (var7 - var3) / var4 else 1,
		})

	end

	return tbl1
end)()

local function SetLeafShown(arg1, arg2)
	if arg1.Tween then
		arg1.Tween:Cancel()
		arg1.Tween = nil
	end

	arg1.Object.Size = UDim2.new()
	arg1.Object.Visible = arg2
	if not arg2 then
		return
	end

	arg1.Tween = var7:Create(arg1.Object, var14, { Size = arg1.Size })
	arg1.Tween:Play()
end

local var24 = var4.percentage
local str1 = "Growing your garden\226\128\166"
local bool1 = false
local num2 = 0
local var25 = nil
local num3 = 0
local function ApplyProgress(arg1)
	if math.abs(arg1 - num1) < 0.0005 then
		return
	end

	num1 = arg1
	SetBarFill(arg1)
	local var1 = math.clamp(arg1, 0, 1) * (#tbl1 - 1)
	local var2 = math.clamp(math.floor(var1), 0, #tbl1 - 2)
	local var3 = tbl1[var2 + 1]
	local var4 = var3 + (tbl1[var2 + 2] - var3) * (var1 - var2)
	local var5 = var20 + var4 * var21 - var22
	var6.Position = UDim2.new(var17 + var18 * arg1 - var19, 0, var5, 0)
	for k1, v1 in var23, nil do
		local var7 = v1.Threshold <= arg1
		if var7 == v1.Shown then
			continue
		end

		v1.Shown = var7
		SetLeafShown(v1, var7)
	end

	var24.Text = ("%* %*%%"):format(str1, (math.round(arg1 * 100)))
end

local function TweenFramesOut()
	for k1, v1 in var2:GetDescendants() do
		if v1:IsA("UIStroke") then
			var7:Create(v1, var13, { Transparency = 1 }):Play()
		else
			if not v1:IsA("GuiObject") then
				continue
			end

			local tbl1 = { BackgroundTransparency = 1 }
			if v1:IsA("TextLabel") or (v1:IsA("TextButton") or v1:IsA("TextBox")) then
				tbl1.TextTransparency = 1
			end

			if v1:IsA("ImageLabel") or v1:IsA("ImageButton") then
				tbl1.ImageTransparency = 1
			end

			var7:Create(v1, var13, tbl1):Play()
		end
	end
end

local function PreloadChunked(arg1, arg2)
	for i1 = 1, #arg1, 20 do
		local var1 = table.move(arg1, i1, math.min(i1 + 20 - 1, #arg1), 1, {})
		local success, result = pcall(function()
			var10:PreloadAsync(var1, arg2)
		end)

		if not success then
			warn("[LoadingScreen] preload failed:", result)
		end

		task.wait(0.1)
	end
end

local function CollectContent(arg1)
	local tbl1 = {}
	for k1, v1 in arg1, nil do
		AddContent(tbl1, v1)
		for k2, v2 in v1:GetDescendants() do
			AddContent(tbl1, v2)
		end
	end

	local tbl2 = {}
	for k3 in tbl1, nil do
		table.insert(tbl2, k3)
	end

	return tbl2
end

local var26 = var2.skip_btn
local function RunIndeterminate(arg1, arg2, arg3, arg4, arg5, arg6)
	local var1 = os.clock()
	while true do
		if arg5() then
			break
		end

		if arg6 and arg6 <= os.clock() - var1 then
			warn((("[LoadingScreen] timed out waiting on: %*"):format(arg4)))
			break
		end

		local var2 = arg1 + (arg2 - arg1) * (1 - math.exp(-(os.clock() - var1) / arg3))
	if not bool1 then
			num2 = math.clamp(var2, 0, 1)
		end

		task.wait()
	end

	if bool1 then
		return
	end

	num2 = math.clamp(arg2, 0, 1)
end

local function Finish()
	if bool1 then
		return
	end

	bool1 = true
	if var25 then
		var25:Disconnect()
		var25 = nil
	end

	TweenFramesOut()
	task.wait(var13.Time)
	var3.Visible = false
	var2.Enabled = false
	var2:Destroy()
end

local success, result = pcall(function()
	if var11:IsStudio() then
		bool1 = true
		task.spawn(function()
			if not game:IsLoaded() then
				game.Loaded:Wait()
			end

			local str1 = "Particles"
			PreloadChunked((CollectContent({ var8:WaitForChild("Assets"):WaitForChild(str1) })))
		end)

		return
	end

	var9:RemoveDefaultLoadingScreen()
	local var4 = os.clock()
	var2.DisplayOrder = 100
	var26.Visible = false
	var3.Visible = true
	var2.Enabled = true
	var2.Parent = var12
	ApplyProgress(0)
	if not var25 then
		var25 = var11.RenderStepped:Connect(function(arg1)
			local var1 = num3 + (num2 - num3) * math.min(arg1 * 8, 1)
			num3 = var1
			ApplyProgress(num3)
		end)

	end

	RunIndeterminate(0, 0.2, 4, "Loading Game...", function()
		return game:IsLoaded()
	end)

	local str1 = "Framework"
	local var5 = require(var8:WaitForChild(str1))
	var26.Visible = true
	var26.MouseButton1Click:Connect(Finish)
	local str2 = "Particles"
	local var6 = CollectContent({
		workspace:WaitForChild("MapEssentials"),
		var8:WaitForChild("Assets"):WaitForChild(str2),
	})

	local var7 = #var6
	str1 = 0
	local bool2 = false
	local var10 = (if 0 < var7 then str1 / var7 else 1) * 0.65000000000000013 + 0.2
	if not bool1 then
		num2 = math.clamp(var10, 0, 1)
	end

	task.spawn(function()
		PreloadChunked(var6, function()
			local var1 = str1 + 1
			str1 = var1
			local var2 = (if 0 < var7 then str1 / var7 else 1) * 0.65000000000000013 + 0.2
			if bool1 then
				return
			end

			num2 = math.clamp(var2, 0, 1)
		end)

		bool2 = true
	end)

	str2 = os.clock()
	repeat
		task.wait()
	until bool2 or 10 <= os.clock() - str2

	str1 = var7
	local var13 = (if 0 < var7 then str1 / var7 else 1) * 0.65000000000000013 + 0.2
	if not bool1 then
		num2 = math.clamp(var13, 0, 1)
	end

	var8:WaitForChild("Data")
	RunIndeterminate(0.85000000000000009, 1, 2, "Loading Save...", function()
		return not not var5.Stat.IsLoaded(var1)
	end, 10)

	var10 = os.clock() - var4
	if var10 < 1 then
		task.wait(1 - var10)
	end

	var13 = os.clock()
	repeat
		task.wait()
	until 0.999 <= num3 or 1 <= os.clock() - var13
end)

if not success then
	warn("[LoadingScreen] failed:", result)
end

if bool1 then
elseif var25 then
	var25:Disconnect()
end

--- ReplicatedFirst.LoadingScreen.LoadingGui.skip_btn.ClickScript [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = var1:FindFirstChildOfClass("UIScale")
local var4 = var1:FindFirstChild("ClickSound")
local var5 = game:GetService("TweenService")
var2 = var2 or Instance.new("UIScale", var1)
if not var4 then
	var4 = Instance.new("Sound")
	var4.Name = "ClickSound"
	var4.SoundId = "rbxassetid://132948338000932"
	var4.Volume = 0.6
	var4.Parent = var1
end

local var6 = var1.Position
local function growFromCenter(arg1, arg2)
	local var3 = var1.AbsoluteSize
	local var4 = var6 - UDim2.new(0, var3.X * (arg1 - 1) / 2, 0, var3.Y * (arg1 - 1) / 2)
	var5:Create(var2, arg2, { Scale = arg1 }):Play()
	var5:Create(var1, arg2, { Position = var4 }):Play()
end

var1.InputBegan:Connect(function(arg1)
	local bool2 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool2 = true
		if arg1.UserInputType ~= Enum.UserInputType.Touch then
			bool2 = arg1.KeyCode == Enum.KeyCode.ButtonA
		end
	end

	if not bool2 then
		return
	end

	var4:Play()
	local num1 = 0.07
	local var1 = Enum.EasingStyle.Quad
	local var2 = Enum.EasingDirection.Out
	growFromCenter(0.9, TweenInfo.new(num1, var1, var2))
end)

var1.InputEnded:Connect(function(arg1)
	local bool2 = true
	if arg1.UserInputType ~= Enum.UserInputType.MouseButton1 then
		bool2 = true
		if arg1.UserInputType ~= Enum.UserInputType.Touch then
			bool2 = arg1.KeyCode == Enum.KeyCode.ButtonA
		end
	end

	if not bool2 then
		return
	end

	local num1 = 0.09
	local var3 = Enum.EasingStyle.Quad
	local var4 = Enum.EasingDirection.Out
	growFromCenter(1.08, TweenInfo.new(num1, var3, var4))
	task.wait(0.09)
	num1 = 0.08
	var3 = Enum.EasingStyle.Quad
	var4 = Enum.EasingDirection.Out
	growFromCenter(0.97, TweenInfo.new(num1, var3, var4))
	task.wait(0.08)
	var5:Create(var2, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	num1 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	var5:Create(var1, num1, { Position = var6 }):Play()
end)

--- ReplicatedFirst.LoadingScreen.LoadingGui.skip_btn.HoverScript [LocalScript]
-- y u r i

local var1 = script.Parent
local var2 = var1:FindFirstChildOfClass("UIScale")
local var3 = var1.Position
local var4 = game:GetService("TweenService")
var2 = var2 or Instance.new("UIScale", var1)
local var5 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local function growFromCenter(arg1)
	local var6 = var1.AbsoluteSize
	local var7 = var3 - UDim2.new(0, var6.X * (arg1 - 1) / 2, 0, var6.Y * (arg1 - 1) / 2)
	var4:Create(var2, var5, { Scale = arg1 }):Play()
	var4:Create(var1, var5, { Position = var7 }):Play()
end

var1.MouseEnter:Connect(function()
	growFromCenter(1.05)
end)

var1.MouseLeave:Connect(function()
	var4:Create(var2, var5, { Scale = 1 }):Play()
	var4:Create(var1, var5, { Position = var3 }):Play()
end)

