if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
        if type(f) == t then return f end
        return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function" or typeof(queueonteleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
    HookMeta = (typeof(hookmetamethod) == "function"),
    Firesignal = (typeof(firesignal) == "function"),
}
Services = setmetatable({}, {
        __index = function(self, name)
                local success, cache = pcall(function()
                        return cloneref(game:GetService(name))
                end)
                if success then
                        rawset(self, name, cache)
                        return cache
                else
                        error("Invalid Service: " .. tostring(name))
                end
        end
})
local Players = Services.Players
local Plr = Players.LocalPlayer
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local l,f={},"1log.txt";if isfile and isfile(f)then delfile(f)end;if writefile then writefile(f,"")end;function notyuri(...)local t=table.create(select("#",...))for i=1,select("#",...)do t[i]=tostring(select(i,...))end local s=("[%s] %s"):format(os.date("%H:%M:%S"),table.concat(t," "));l[#l+1]=s;if appendfile then appendfile(f,s.."\n")end end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true
Library.ShowCustomCursor = true
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "6pCsSbVd3E"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end
local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
}
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
}
function AddMultiDropdown(group, id, config)
    if type(group) == "string" then
        local selected = {}
        local dropdown = Options[group]
        local values = dropdown and dropdown.Values or {}
        local chosen = dropdown and dropdown.Value or {}
        if chosen["All"] then
            for _, label in ipairs(values) do
                if label ~= "All" then selected[label] = true end
            end
        else
            for label, active in pairs(chosen) do
                if active and label ~= "All" then selected[label] = true end
            end
        end
        return selected
    end
    config = config or {}
    local values = { "All" }
    for _, v in ipairs(config.Values or {}) do
        table.insert(values, v)
    end
    group:AddDropdown(id, {
        Text = config.Text,
        Values = values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    return Options[id]
end
function SafeLabel(target, id, text)
    if type(target) == "string" then
        local entry = Shared.Labels[target]
        if entry then
            entry.Text = id
            entry.Dirty = true
        end
        return
    end
    local label = target:AddLabel(text, true)
    Shared.Labels[id] = {Label = label, Text = text, Dirty = false}
    Thread("SafeLabel", function()
        while not Library.Unloaded do
            for key, entry in pairs(Shared.Labels) do
                if entry.Dirty then
                    entry.Dirty = false
                    local ok, err = pcall(function()
                        entry.Label:SetText(entry.Text)
                    end)
                    if not ok then
                    end
                end
            end
            task.wait()
        end
    end, true)
    return label
end
function AddSliderToggle(Config)
    local Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false,
        Disabled = Config.Disabled,
    })
    local Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    Toggle:OnChanged(function()
        Slider:SetVisible(Toggle.Value)
    end)
    return Toggle, Slider
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local function SafeInvoke(remote, skip, ...)
    local args = {...}
    local result = nil
    task.spawn(function()
        local success, res = pcall(function()
            return remote:InvokeServer(unpack(args))
        end)
        result = res
    end)
    if skip then return end
    local start = tick()
    repeat task.wait() until result ~= nil or (tick() - start) > 2
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        local args = {...}
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Fire then
                pcall(function() connection:Fire(unpack(args)) end)
            elseif connection.Function then
                task.spawn(connection.Function, unpack(args))
            end
        end
    else
        warn("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            currentTable[flagKey] = task.spawn(featureFunc, ...)
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            warn("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
local function GetCharacter()
    local c = Plr.Character
    return (c and c:FindFirstChild("HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function TPTo(target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    hrp.CFrame = cframe
    return true
end
local function TweenTo(speed, target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    local goal = cframe.Position
    while true do
        local _, delta = RunService.Stepped:Wait()
        char = GetCharacter()
        hrp = char and char:FindFirstChild("HumanoidRootPart")
        if not hrp then return false end
        local diff = goal - hrp.Position
        local dist = diff.Magnitude
        local stepDist = speed * delta
        if dist <= stepDist then
            hrp.CFrame = cframe
            return true
        end
        hrp.CFrame = CFrame.new(hrp.Position + diff.Unit * stepDist) * (hrp.CFrame - hrp.CFrame.Position)
    end
end
local function GetNearest(list, filterFn)
    local char = GetCharacter()
    local root = char and char:FindFirstChild("HumanoidRootPart")
    if not root then return nil end
    local best, bestDist = nil, math.huge
    for _, inst in ipairs(list) do
        if not filterFn or filterFn(inst) then
            local part = inst:IsA("BasePart") and inst or (inst:IsA("Model") and inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart"))
            if part then
                local dist = (part.Position - root.Position).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    best = inst
                end
            end
        end
    end
    return best, bestDist
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            pcall(function()
                local promptOverlay = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = promptOverlay.promptOverlay:FindFirstChild("ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Plr)
                    end
                end
            end)
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local success, err = pcall(function()
            local pauseGui = game:GetService("CoreGui").RobloxGui:FindFirstChild("CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    if teleport then
        local char = GetCharacter()
        local hrp = char and GetObject(char, "HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local pos = isModel and part:GetPivot().Position or part.Position
            if (hrp.Position - pos).Magnitude > target.MaxActivationDistance then
                TPTo(part)
                task.wait(0.2)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and Plr.Character:FindFirstChild("HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, true)
        task.wait()
        firetouchinterest(part, root, false)
    end)
end
local function Serverhop()
    local hopSuccess, hopErr = pcall(function()
        local baseUrl = 'https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100'
        local servers = {}
        local cursor = ''
        for _ = 1, 3 do
            local url = baseUrl
            if cursor ~= '' then url = url .. '&cursor=' .. cursor end
            local pages = game:HttpGet(url)
            local data = HttpService:JSONDecode(pages)
            for _, server in ipairs(data.data) do
                if server.playing < server.maxPlayers and server.id ~= game.JobId then
                    table.insert(servers, server)
                end
            end
            cursor = data.nextPageCursor
            if not cursor or cursor == '' then break end
        end
        table.sort(servers, function(a, b) return a.playing < b.playing end)
        if #servers == 0 then
            Library:Notify("No servers found to hop to.", 3)
            return
        end
        local best = servers[1]
        for _, server in ipairs(servers) do
            if server.playing > 0 then
                best = server
                break
            end
        end
        TeleportService:TeleportToPlaceInstance(game.PlaceId, best.id, Plr)
    end)
    if not hopSuccess then
        Library:Notify("Serverhop failed: " .. tostring(hopErr), 5)
    end
end
local Window = Library:CreateWindow({
        Title = "Yuri",
        Center = true,
        AutoShow = true,
        Resizable = true,
        ShowCustomCursor = false,
        UnlockMouseWhileOpen = false,
        NotifySide = "Left",
        TabPadding = 8,
        MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
        Main = Window:AddTab("Main"),
    Player = Window:AddTab("Player"),
    Config = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Autofarm"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
}
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
local TPW_T, TPW_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1})
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
local FPS_T, FPS_S = AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused"})
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function() Serverhop() end })
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Plr) end })
GB.Player.Left.Server:AddToggle("AutoServerhop", { Text = "Auto Serverhop" })
GB.Player.Left.Server:AddSlider("AutoHopMins", { Text = "Minutes", Default = 30, Min = 0, Max = 300, Compact = true, Rounding = 0 })
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    TPW_S:SetVisible(TPW_T.Value)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Toggles.AutoServerhop:OnChanged(function(state)
    Thread("AutoServerhop", function()
        local lastHop = tick()
        while Toggles.AutoServerhop.Value do
            task.wait(5)
            if not Toggles.AutoServerhop.Value then break end
            if (tick() - lastHop) >= (Options.AutoHopMins.Value * 60) then
                Serverhop()
                break
            end
        end
    end, state)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then Hum.JumpPower = Options.JPValue.Value Hum.UseJumpPower = true end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if FPS_T.Value then
        setfpscap(FPS_S.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    FPS_S:SetVisible(FPS_T.Value)
    if not v and Support.FPS then
        setfpscap(2000)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local SnackOk = false
do
Shared.Labels = {}
Shared.PosDir = "Yuri/Snack"
Shared.MDir = "Yuri/Snack/Macros"
local S = {
        RemotesReady = false,
        Place = "",
        MatchStart = 0,
        WaveSeen = 0,
        PlacedCount = 0,
        UpgradeCount = 0,
        WebhookSent = "",
        Voted = {},
        FlowNotified = {},
        TowerValues = {},
        UpgradeValues = {},
        TargetValues = {},
        EquippedNames = {},
        TraitValues = {},
        MacroValues = {},
        MapKeys = {},
        BannerKeys = {},
        SpeedValues = {},
        LevelValues = {},
        Rec = false,
        Rep = false,
        Cur = nil,
        Step = 0,
        Total = 0,
        NextKey = 0,
        RecKeys = {},
        RepMap = {},
        Pending = {},
        Adopted = {},
        Saved = false,
        SelfThreads = {},
        Hooked = false,
        Timings = {
                PendingExpiry = 12,
                PendingLateResolve = 0.35,
                MaxAttempts = 5,
                CashWait = 5,
                RemoteWait = 10,
        },
}
local MacroGetSelection = nil
local UpgradeGetSelection = nil
local TargetGetSelection = nil
local SellGetSelection = nil
local TraitGetSelection = nil
local TemplatesFolder = GetObject(RS, "ReplicatedFramework.Templates")
local FrameworkSettings = GetSafeModule(TemplatesFolder, "FrameworkSettings")
local TowersMod = GetSafeModule(TemplatesFolder, "Towers")
local TowerTraits = GetSafeModule(TemplatesFolder, "TowerTraits")
local TowerStars = GetSafeModule(TemplatesFolder, "TowerStars")
local SummonDictionary = GetSafeModule(TemplatesFolder, "SummonDictionary")
local QuestsMod = GetSafeModule(TemplatesFolder, "Quests")
local MapsFolder = GetObject(RS, "ReplicatedFramework.Templates.Maps")
local LevelCurve = GetSafeModule(MapsFolder, "LevelCurve")
local RoundCodeFolder = GetObject(RS, "InRoundCode")
local ClientUtilities = GetObject(Plr, "PlayerScripts.InRoundCode.Utilities")
local PlacementMath = RoundCodeFolder and GetSafeModule(RoundCodeFolder, "PlacementMath") or nil
local PlacementArea = ClientUtilities and GetSafeModule(ClientUtilities, "PlacementArea") or nil
local FrameworkReady = (FrameworkSettings ~= nil and TowersMod ~= nil)
if not FrameworkReady then
        Library:Notify("Snack: framework modules unavailable", 4)
else
S.Place = (FrameworkSettings:IsLobbyPlace() and "Lobby") or (FrameworkSettings:IsAfkPlace() and "Afk") or "Round"
local IsRound = S.Place == "Round"
local IsLobby = S.Place == "Lobby"
local RemoteFunctionNames = {
        PlaceTower = true,
        UpgradeTower = true,
        SellTower = true,
        SetTowerTarget = true,
        QuestState = true,
        QuestClaim = true,
        StarsFuseRequest = true,
        RequestGroupRewardClaim = true,
        IndexRewardClaim = true,
}
local RemoteEventNames = {
        SetHeldTower = true,
        RequestGameSpeed = true,
        RequestPauseToggle = true,
        ModalVote = true,
        RequestNextLevel = true,
        RequestReplayLevel = true,
        RequestReturnToLobby = true,
        RequestRestartMatch = true,
        RequestPlayNewMap = true,
        RequestPlay = true,
        RequestStartGame = true,
        LeaveParty = true,
        RequestSummon = true,
        SetTowerEquipped = true,
        EquipBestTowers = true,
        DeleteTowers = true,
        RequestTraitRoll = true,
        RequestAfkTeleport = true,
        MatchRejoinAnswer = true,
}
local function RemotesForPlace()
        local list = {}
        if IsRound then
                for _, n in ipairs({ "PlaceTower", "UpgradeTower", "SellTower", "SetTowerTarget", "SetHeldTower", "RequestGameSpeed", "RequestPauseToggle", "ModalVote", "RequestNextLevel", "RequestReplayLevel", "RequestReturnToLobby", "RequestRestartMatch", "RequestPlayNewMap" }) do
                        table.insert(list, n)
                end
        elseif IsLobby then
                for _, n in ipairs({ "QuestState", "QuestClaim", "StarsFuseRequest", "RequestGroupRewardClaim", "IndexRewardClaim", "RequestPlay", "LeaveParty", "RequestSummon", "EquipBestTowers", "DeleteTowers", "SetTowerEquipped", "RequestTraitRoll", "RequestAfkTeleport", "MatchRejoinAnswer", "MatchRejoinOffer" }) do
                        table.insert(list, n)
                end
        end
        return list
end
local function ResolveRemotes()
        local folder = RS:FindFirstChild("FrameworkEvents")
        if not folder then
                folder = RS:WaitForChild("FrameworkEvents", 5)
        end
        if not folder then return false end
        local missing = false
        for _, name in ipairs(RemotesForPlace()) do
                if not Remotes[name] then
                        local remote = folder:FindFirstChild(name)
                        if not remote then
                                remote = folder:WaitForChild(name, 2)
                        end
                        local wantedClass = RemoteFunctionNames[name] and "RemoteFunction" or "RemoteEvent"
                        if remote and remote:IsA(wantedClass) then
                                Remotes[name] = remote
                        else
                                missing = true
                        end
                end
        end
        S.RemotesReady = not missing
        return not missing
end
task.spawn(function()
        local deadline = os.clock() + 30
        while os.clock() < deadline and not Library.Unloaded do
                if pcall(ResolveRemotes) and S.RemotesReady then break end
                task.wait(1)
        end
end)
local function SnackSend(remote, ...)
        if not remote then return false end
        local args = {...}
        local ok, err = pcall(function()
                remote:FireServer(unpack(args))
        end)
        if not ok then
                notyuri("Snack send error:", tostring(err))
        end
        return ok
end
local function GetCash()
        return tonumber(Plr:GetAttribute("RoundCurrency")) or 0
end
local function GetWave()
        return tonumber(RS:GetAttribute("CurrentWave")) or 0
end
local function GetPhase()
        return RS:GetAttribute("RoundPhase") or ""
end
local function RoundLive()
        return RS:GetAttribute("RoundActive") == true and GetPhase() ~= "Waiting"
end
local function BoardLive()
        local phase = GetPhase()
        return phase == "Prep" or phase == "Wave" or phase == "Intermission" or phase == "TutorialHold"
end
local function GetTowerCfg(name)
        local towers = TowersMod and TowersMod.Towers
        if type(towers) ~= "table" then return nil end
        return towers[name]
end
local function MaxLevelOf(cfg)
        if type(cfg) ~= "table" then return 0 end
        return (type(cfg.Upgrades) == "table") and #cfg.Upgrades or 0
end
local function GetPlacedFolder()
        local mapName = RS:GetAttribute("SelectedMap")
        local map = mapName and workspace:FindFirstChild(mapName)
        return (map and map:FindFirstChild("PlacedTowers")) or workspace:FindFirstChild("PlacedTowers")
end
local function GetOwnTowers()
        local folder = GetPlacedFolder()
        local list = {}
        if not folder then return list end
        for _, model in ipairs(folder:GetChildren()) do
                if model:IsA("Model") and model:GetAttribute("OwnerUserId") == Plr.UserId then
                        table.insert(list, model)
                end
        end
        return list
end
local function GetTowerLevel(model)
        local cfg = model:FindFirstChild("TowerConfig")
        local lvl = cfg and cfg:GetAttribute("Level")
        return tonumber(lvl) or 0
end
local function TowerCap(cfg)
        if type(cfg) ~= "table" then return 0 end
        if cfg.CustomMaxPerPlayer ~= nil then
                return tonumber(cfg.CustomMaxPerPlayer) or 0
        end
        local settings = TowersMod.GlobalSettings
        return settings and tonumber(settings.MaxTowerPerPlayer) or 0
end
local function BoardCap()
        local settings = TowersMod.GlobalSettings
        if type(settings) ~= "table" then return 0 end
        local base = tonumber(settings.MaxTotalTowers) or 0
        local endless = RS:GetAttribute("EndlessMatch") == true
        if not endless then return base end
        local wave = GetWave()
        local grown = base + math.floor(math.max(wave, 0) / 5)
        return math.min(grown, math.max(base, 45))
end
local function FootprintRadiusFor(name)
        local folder = RS:FindFirstChild("PlayerTowers")
        local model = folder and folder:FindFirstChild(name)
        if model and model:IsA("Model") and PlacementMath then
                local ok, size = pcall(function()
                        local _, sz = model:GetBoundingBox()
                        return sz
                end)
                if ok and typeof(size) == "Vector3" then
                        return PlacementMath.footprintRadius(size.X, size.Z)
                end
        end
        return 2
end
local function PlacedFootprints()
        local list = {}
        for _, model in ipairs(GetOwnTowers()) do
                local ok, pivot, size = pcall(function()
                        local _, sz = model:GetBoundingBox()
                        return model:GetPivot().Position, sz
                end)
                if ok and pivot then
                        local radius = 2
                        if typeof(size) == "Vector3" and PlacementMath then
                                radius = PlacementMath.footprintRadius(size.X, size.Z)
                        end
                        table.insert(list, { position = pivot, radius = radius, model = model })
                end
        end
        return list
end
local function FindSpotNear(fpRadius, centerX, centerZ, maxDist)
        if not (PlacementArea and PlacementMath) then return nil end
        local layout = PlacementArea.Get()
        if not layout then
                pcall(function()
                        PlacementArea.Start()
                end)
                return nil
        end
        local sampleRadius = PlacementMath.spotSampleRadius(fpRadius)
        local placed = PlacedFootprints()
        local best = nil
        PlacementArea.ForEachCellByDistance(layout, centerX, centerZ, maxDist or 200, function(_, x, z, groundY, clearance)
                if clearance < sampleRadius then
                        return false
                end
                local pos = Vector3.new(x, groundY, z)
                if not PlacementMath.hasClearance(pos, fpRadius, placed, PlacementMath.SPACING_PADDING + 1) then
                        return false
                end
                best = { x = x, y = groundY, z = z }
                return true
        end)
        return best
end
local function FindSpotAnywhere(fpRadius)
        if not PlacementArea then return nil end
        local layout = PlacementArea.Get()
        if not layout then
                pcall(function()
                        PlacementArea.Start()
                end)
                return nil
        end
        local cx = layout.minX + (layout.cols - 1) * layout.cell / 2
        local cz = layout.minZ + (layout.rows - 1) * layout.cell / 2
        return FindSpotNear(fpRadius, cx, cz, 400)
end
local function EquippedSlots()
        local list = {}
        local slots = Plr:FindFirstChild("TowerSlots")
        if not slots then return list end
        for i = 1, 12 do
                local slot = slots:FindFirstChild(tostring(i))
                if not slot then
                        if i > 6 then break end
                else
                        local tower = slot:GetAttribute("Tower")
                        if type(tower) == "string" and tower ~= "" and slot:GetAttribute("Unlocked") == true then
                                table.insert(list, { slot = i, tower = tower, uid = slot:GetAttribute("TowerUid") })
                        end
                end
        end
        return list
end
local function NotifyOnce(key, message)
        if S.FlowNotified[key] then return end
        S.FlowNotified[key] = true
        Library:Notify(message, 5)
end
local function WaitForCash(amount, timeout)
        if not amount or amount <= 0 then return true end
        if GetCash() >= amount then return true end
        local limit = timeout or S.Timings.CashWait
        local start = os.clock()
        while os.clock() - start < limit do
                if Library.Unloaded then return false end
                if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then
                        return false
                end
                if GetCash() >= amount then return true end
                task.wait()
        end
        return GetCash() >= amount
end
if IsRound then
local function InvokeTower(remote, payload)
        local result = SafeInvoke(remote, nil, payload)
        if type(result) == "table" then
                return result
        end
        return nil
end
local function TryPlaceTower(name, slotIndex, spot, rotationY)
        local payload = {
                towerKey = name,
                slotIndex = slotIndex,
                x = spot.x,
                y = spot.y,
                z = spot.z,
                rotationY = rotationY or 0,
        }
        local result = InvokeTower(Remotes.PlaceTower, payload)
        if type(result) == "table" and result.success then
                S.PlacedCount = S.PlacedCount + 1
                return true, result
        end
        return false, result
end
local function TryUpgradeTower(model)
        local result = InvokeTower(Remotes.UpgradeTower, { tower = model })
        if type(result) == "table" and result.success then
                S.UpgradeCount = S.UpgradeCount + 1
                return true, result
        end
        return false, result
end
local function TrySellTower(model)
        local result = InvokeTower(Remotes.SellTower, { tower = model })
        if type(result) == "table" and result.success then
                return true, result
        end
        return false, result
end
local function TrySetTarget(model, mode)
        local result = InvokeTower(Remotes.SetTowerTarget, { tower = model, mode = mode })
        if type(result) == "table" and result.success then
                return true, result
        end
        return false, result
end
local function StepAutoPlace()
        if not BoardLive() then return end
        if not ResolveRemotes() then return end
        local selected = MacroGetSelection and MacroGetSelection() or {}
        if not next(selected) then return end
        local own = GetOwnTowers()
        local total = #own
        local cap = BoardCap()
        if cap > 0 and total >= cap then
                NotifyOnce("SnackPlaceCap", "Snack board cap reached (" .. tostring(cap) .. ")")
                return
        end
        local typeCounts = {}
        for _, model in ipairs(own) do
                typeCounts[model.Name] = (typeCounts[model.Name] or 0) + 1
        end
        local slots = EquippedSlots()
        for _, entry in ipairs(slots) do
                if selected[entry.tower] then
                        local cfg = GetTowerCfg(entry.tower)
                        if cfg then
                                local typeCap = TowerCap(cfg)
                                local typeCount = typeCounts[entry.tower] or 0
                                local capped = typeCap > 0 and typeCount >= typeCap
                                local cost = tonumber(cfg.Cost) or 0
                                local affordable = GetCash() >= cost
                                if not capped and affordable then
                                        local spot = FindSpotAnywhere(FootprintRadiusFor(entry.tower))
                                        if spot then
                                                local ok, result = TryPlaceTower(entry.tower, entry.slot, spot, 0)
                                                if ok then
                                                        S.FlowNotified["SnackPlaceCap"] = nil
                                                        return
                                                elseif type(result) == "table" then
                                                        if result.reason == "NotEnoughCoins" or result.reason == "MaxTotalReached" or result.reason == "MaxTypeReached" then
                                                                return
                                                        end
                                                end
                                        end
                                end
                        end
                end
        end
end
local function StepAutoUpgrade()
        if not BoardLive() then return end
        if not ResolveRemotes() then return end
        local selected = UpgradeGetSelection and UpgradeGetSelection() or {}
        if not next(selected) then return end
        local candidates = {}
        for _, model in ipairs(GetOwnTowers()) do
                if selected[model.Name] then
                        local cfg = GetTowerCfg(model.Name)
                        local maxLevel = MaxLevelOf(cfg)
                        local level = GetTowerLevel(model)
                        if level < maxLevel then
                                local nextCost = cfg.Upgrades[level + 1] and tonumber(cfg.Upgrades[level + 1].Cost) or nil
                                if nextCost then
                                        table.insert(candidates, { model = model, cost = nextCost })
                                end
                        end
                end
        end
        if #candidates == 0 then return end
        table.sort(candidates, function(a, b)
                return a.cost < b.cost
        end)
        for _, candidate in ipairs(candidates) do
                if GetCash() >= candidate.cost then
                        TryUpgradeTower(candidate.model)
                        return
                end
        end
end
local function StepAutoSell()
        if not BoardLive() then return end
        if not ResolveRemotes() then return end
        local selected = SellGetSelection and SellGetSelection() or {}
        if not next(selected) then return end
        for _, model in ipairs(GetOwnTowers()) do
                if selected[model.Name] then
                        TrySellTower(model)
                        return
                end
        end
end
local function StepAutoTarget()
        if not BoardLive() then return end
        if not ResolveRemotes() then return end
        local selected = TargetGetSelection and TargetGetSelection() or {}
        if not next(selected) then return end
        local mode = Options.SnackTargetMode and Options.SnackTargetMode.Value or "First"
        for _, model in ipairs(GetOwnTowers()) do
                if selected[model.Name] then
                        local cfg = GetTowerCfg(model.Name)
                        if cfg and (mode ~= "Air" or cfg.CanHitAir == true) then
                                local cfgChild = model:FindFirstChild("TowerConfig")
                                local current = cfgChild and cfgChild:GetAttribute("TargetingMode")
                                if current ~= mode then
                                        TrySetTarget(model, mode)
                                        return
                                end
                        end
                end
        end
end
local function StepAutoVote()
        local voteId = tonumber(RS:GetAttribute("ModalVoteId")) or 0
        if voteId <= 0 then return end
        if S.Voted[voteId] then return end
        S.Voted[voteId] = true
        SnackSend(Remotes.ModalVote, voteId, true)
end
SafeConnect("Snack_Phase", function()
        return RS:GetAttributeChangedSignal("RoundPhase")
end, function()
        local phase = GetPhase()
        if phase == "Complete" then
                if Toggles.SnackAutoFlow and Toggles.SnackAutoFlow.Value then
                        task.wait(1.5)
                        SnackSend(Remotes.RequestNextLevel)
                end
        elseif phase == "Defeat" then
                if Toggles.SnackAutoFlow and Toggles.SnackAutoFlow.Value then
                        local mode = Options.SnackDefeatMode and Options.SnackDefeatMode.Value or "Replay Level"
                        task.wait(1.5)
                        if mode == "Replay Level" then
                                SnackSend(Remotes.RequestReplayLevel)
                        elseif mode == "Return to Lobby" then
                                SnackSend(Remotes.RequestReturnToLobby)
                        elseif mode == "Restart Match" then
                                SnackSend(Remotes.RequestRestartMatch)
                        end
                end
        end
end)
local function ApplyGameSpeed()
        if not (Toggles.SnackAutoSpeed and Toggles.SnackAutoSpeed.Value) then return end
        if not RoundLive() then return end
        local speed = tonumber(Options.SnackSpeed and Options.SnackSpeed.Value) or 1
        SnackSend(Remotes.RequestGameSpeed, speed)
end
SafeConnect("Snack_RoundActive", function()
        return RS:GetAttributeChangedSignal("RoundActive")
end, function()
        if RS:GetAttribute("RoundActive") == true then
                S.MatchStart = os.clock()
                S.WaveSeen = 0
                S.PlacedCount = 0
                S.UpgradeCount = 0
                S.WebhookSent = ""
                S.Voted = {}
                S.FlowNotified = {}
                task.wait(1)
                ApplyGameSpeed()
        end
end)
local function SendWebhook(title, description, color)
        if not Support.Webhook then return end
        local url = Options.SnackWebhookURL and Options.SnackWebhookURL.Value or ""
        if url == "" then return end
        local body = {
                username = "Snack Defense",
                embeds = { {
                        title = title,
                        description = description,
                        color = color,
                        footer = { text = "Yuri | SNACK Defense" },
                } },
        }
        task.spawn(function()
                pcall(function()
                        request({
                                Url = url,
                                Method = "POST",
                                Headers = { ["Content-Type"] = "application/json" },
                                Body = HttpService:JSONEncode(body),
                        })
                end)
        end)
end
SafeConnect("Snack_Webhook", function()
        return RS:GetAttributeChangedSignal("RoundPhase")
end, function()
        local phase = GetPhase()
        if phase ~= "Complete" and phase ~= "Defeat" and phase ~= "ContinueOffer" then return end
        if not (Toggles.SnackWebhook and Toggles.SnackWebhook.Value) then return end
        local matchId = RS:GetAttribute("MatchId") or ""
        if S.WebhookSent == matchId and matchId ~= "" then return end
        S.WebhookSent = matchId
        local endless = RS:GetAttribute("EndlessMatch") == true
        local result = (phase == "Complete" and "VICTORY") or "DEFEAT"
        local totalWaves = tonumber(RS:GetAttribute("TotalWaves")) or 0
        local waves = tonumber(RS:GetAttribute("WavesCleared")) or 0
        local best = tonumber(RS:GetAttribute("MatchBestWave")) or 0
        local hp = tonumber(RS:GetAttribute("BaseHealth")) or 0
        local hpMax = tonumber(RS:GetAttribute("BaseHealthMax")) or 0
        local map = RS:GetAttribute("SelectedMap") or "?"
        local level = tonumber(RS:GetAttribute("SelectedLevel")) or 0
        local duration = tonumber(RS:GetAttribute("MatchDuration")) or 0
        local lines = {
                "**Result:** " .. result,
                "**Map:** " .. map .. (endless and " (Endless)" or (" - Level " .. tostring(level))),
                "**Waves:** " .. tostring(waves) .. "/" .. (endless and "-" or tostring(totalWaves)) .. " (best " .. tostring(best) .. ")",
                "**Base:** " .. tostring(math.floor(hp)) .. "/" .. tostring(math.floor(hpMax)),
                "**Session:** " .. tostring(S.PlacedCount) .. " placed, " .. tostring(S.UpgradeCount) .. " upgraded",
                "**Duration:** " .. tostring(math.floor(duration / 60)) .. "m " .. tostring(math.floor(duration % 60)) .. "s",
        }
        SendWebhook("Match " .. result, table.concat(lines, "\n"), (phase == "Complete" and 3066993) or 15158332)
end)
local function EnsureFolderPath(path)
        if isfolder and not isfolder(path) then
                makefolder(path)
        end
end
local function SaveJSON(path, data)
        if not Support.FileIO then return false end
        local ok, encoded = pcall(function()
                return HttpService:JSONEncode(data)
        end)
        if not ok or not encoded then return false end
        local wrote = false
        pcall(function()
                writefile(path, encoded)
                wrote = true
        end)
        return wrote
end
local function LoadJSON(path)
        if not Support.FileIO then return nil end
        if isfile and not isfile(path) then return nil end
        local ok, decoded = pcall(function()
                return HttpService:JSONDecode(readfile(path))
        end)
        if ok then
                return decoded
        end
        return nil
end
local function ListMacros()
        local list = {}
        if not Support.FileIO then return list end
        EnsureFolderPath(Shared.MDir)
        local ok, files = pcall(function()
                return listfiles(Shared.MDir)
        end)
        if not ok or type(files) ~= "table" then return list end
        for _, file in ipairs(files) do
                local name = tostring(file):match("([^%/]+)%.[jJ][sS][oO][nN]$") or tostring(file):match("([^%/]+)$")
                if name and name ~= "" then
                        table.insert(list, name)
                end
        end
        table.sort(list)
        return list
end
local function SaveMacro(name, macro)
        if not Support.FileIO then return false end
        EnsureFolderPath(Shared.MDir)
        return SaveJSON(Shared.MDir .. "/" .. name .. ".json", macro)
end
local function LoadMacro(name)
        if type(name) ~= "string" or name == "" then return nil end
        return LoadJSON(Shared.MDir .. "/" .. name .. ".json")
end
local function UpdateMacroLabel(suffix)
        local txt
        if S.Rec then
                txt = string.format("Recording [%d actions]", S.Step)
        elseif S.Rep then
                txt = string.format("Replaying [%d / %d]", S.Step, S.Total)
        else
                txt = "Idle"
        end
        if suffix then
                txt = txt .. " | " .. suffix
        end
        SafeLabel("SnackMacro", txt)
end
local function RecordAct(kind, data, wave, elapsed)
        if not S.Cur then return end
        S.Step = S.Step + 1
        local entry = { Type = kind, Time = tostring(wave or 0) .. " " .. tostring(math.floor((elapsed or 0) * 1000)) }
        for k, v in pairs(data or {}) do
                entry[k] = v
        end
        table.insert(S.Cur.entries, entry)
        UpdateMacroLabel(kind)
end
local function ParseMacroTime(entry)
        local wStr, eStr = (entry.Time or ""):match("^(%d+)%s+(.+)$")
        return tonumber(wStr) or 0, (tonumber(eStr) or 0) / 1000
end
local function SortMacroEntries(entries)
        table.sort(entries, function(a, b)
                local wa, ea = ParseMacroTime(a)
                local wb, eb = ParseMacroTime(b)
                if wa ~= wb then return wa < wb end
                return ea < eb
        end)
end
local function MatchElapsed()
        if S.MatchStart <= 0 then return 0 end
        return os.clock() - S.MatchStart
end
local function EnsureRecKey(inst)
        if typeof(inst) ~= "Instance" then return nil end
        local key = S.RecKeys[inst]
        if not key then
                S.NextKey = S.NextKey + 1
                key = S.NextKey
                S.RecKeys[inst] = key
                S.Adopted[key] = true
        end
        return key
end
local function TowerNearPos(tower, pos, radius)
        local part = tower.PrimaryPart or tower:FindFirstChildWhichIsA("BasePart")
        if not (part and pos) then return false end
        return (part.Position - pos).Magnitude <= (radius or 5)
end
local function ConfirmPlace(pend, inst)
        if pend.Resolved then return end
        pend.Resolved = true
        local key = EnsureRecKey(inst)
        if not key then
                pend.Dropped = true
                return
        end
        pend.Key = key
        RecordAct("Place", { Key = key, Name = pend.Name, Pos = pend.Pos, Rot = pend.Rot, Slot = pend.Slot }, pend.Wave, pend.Elapsed)
end
local function ConfirmUpgrade(pend)
        if pend.Resolved then return end
        pend.Resolved = true
        local key = nil
        if typeof(pend.Tower) == "Instance" then
                key = S.RecKeys[pend.Tower]
        end
        key = key or EnsureRecKey(pend.Tower)
        if not key then
                pend.Dropped = true
                return
        end
        pend.Key = key
        RecordAct("Upgrade", { Key = key, Name = pend.Name, LVL = pend.LVL, Pos = pend.Pos }, pend.Wave, pend.Elapsed)
end
local function ConfirmSell(pend)
        if pend.Resolved then return end
        pend.Resolved = true
        local key = nil
        if typeof(pend.Tower) == "Instance" then
                key = S.RecKeys[pend.Tower]
                S.RecKeys[pend.Tower] = nil
        end
        pend.Key = key
        RecordAct("Sell", { Key = key, Name = pend.Name }, pend.Wave, pend.Elapsed)
end
local function ConfirmMode(pend)
        if pend.Resolved then return end
        pend.Resolved = true
        local key = nil
        if typeof(pend.Tower) == "Instance" then
                key = S.RecKeys[pend.Tower] or EnsureRecKey(pend.Tower)
        end
        pend.Key = key
        RecordAct("Mode", { Key = key, Name = pend.Name, Mode = pend.Mode }, pend.Wave, pend.Elapsed)
end
local function SnapshotCall(self, nargs)
        if not (S.Rec and S.Cur) then return nil end
        local payload = nargs[3]
        local wave = GetWave()
        local elapsed = MatchElapsed()
        local pend
        if rawequal(self, Remotes.PlaceTower) then
                if type(payload) ~= "table" or type(payload.towerKey) ~= "string" then return nil end
                pend = {
                        Kind = "Place",
                        Name = payload.towerKey,
                        Slot = payload.slotIndex,
                        Pos = { payload.x, payload.y, payload.z },
                        Rot = payload.rotationY or 0,
                        Position = Vector3.new(payload.x or 0, payload.y or 0, payload.z or 0),
                }
        elseif rawequal(self, Remotes.UpgradeTower) then
                local tower = type(payload) == "table" and payload.tower
                if typeof(tower) ~= "Instance" then return nil end
                pend = { Kind = "Upgrade", Tower = tower, Name = tower.Name, LVL = GetTowerLevel(tower) + 1 }
                local part = tower.PrimaryPart or tower:FindFirstChildWhichIsA("BasePart")
                if part then
                        pend.Position = part.Position
                        pend.Pos = { part.Position.X, part.Position.Y, part.Position.Z }
                end
        elseif rawequal(self, Remotes.SellTower) then
                local tower = type(payload) == "table" and payload.tower
                if typeof(tower) ~= "Instance" then return nil end
                pend = { Kind = "Sell", Tower = tower, Name = tower.Name }
                local part = tower.PrimaryPart or tower:FindFirstChildWhichIsA("BasePart")
                if part then
                        pend.Position = part.Position
                end
        elseif rawequal(self, Remotes.SetTowerTarget) then
                local tower = type(payload) == "table" and payload.tower
                if typeof(tower) ~= "Instance" then return nil end
                pend = { Kind = "Mode", Tower = tower, Name = tower.Name, Mode = payload.mode }
                local part = tower.PrimaryPart or tower:FindFirstChildWhichIsA("BasePart")
                if part then
                        pend.Position = part.Position
                end
        else
                return nil
        end
        pend.Wave = wave
        pend.Elapsed = elapsed
        pend.At = os.clock()
        pend.Resolved = false
        table.insert(S.Pending, pend)
        return pend
end
local function ResolveCall(pend, ret)
        if not (pend and not pend.Resolved) then return end
        local result = (ret and ret.n and ret.n > 0) and ret[1] or nil
        if type(result) ~= "table" then return end
        if pend.Kind == "Place" then
                if result.success then
                        pend.AwaitInstance = true
                else
                        pend.Resolved = true
                        pend.Dropped = true
                end
        elseif pend.Kind == "Upgrade" then
                if result.success then
                        ConfirmUpgrade(pend)
                else
                        pend.Resolved = true
                        pend.Dropped = true
                end
        elseif pend.Kind == "Sell" then
                if result.success then
                        ConfirmSell(pend)
                else
                        pend.Resolved = true
                        pend.Dropped = true
                end
        elseif pend.Kind == "Mode" then
                if result.success then
                        ConfirmMode(pend)
                else
                        pend.Resolved = true
                        pend.Dropped = true
                end
        end
end
local function FindUnkeyedOwnedTower(predFn)
        for _, tower in ipairs(GetOwnTowers()) do
                if not S.RecKeys[tower] and predFn(tower) then
                        return tower
                end
        end
        return nil
end
local function ProcessPendingSweep()
        local now = os.clock()
        for _, pend in ipairs(S.Pending) do
                if not pend.Resolved then
                        local age = now - pend.At
                        if age > S.Timings.PendingExpiry then
                                pend.Resolved = true
                                pend.Dropped = true
                        elseif pend.Kind == "Place" and pend.AwaitInstance then
                                local inst = FindUnkeyedOwnedTower(function(t)
                                        return t.Name == pend.Name and TowerNearPos(t, pend.Position, 6)
                                end)
                                if inst then
                                        ConfirmPlace(pend, inst)
                                end
                        elseif age > S.Timings.PendingLateResolve then
                                if pend.Kind == "Upgrade" then
                                        local inst = FindUnkeyedOwnedTower(function(t)
                                                return t.Name == pend.Name and TowerNearPos(t, pend.Position, 6)
                                        end)
                                        if inst then
                                                pend.Tower = inst
                                                ConfirmUpgrade(pend)
                                        end
                                elseif pend.Kind == "Sell" then
                                        local old = pend.Tower
                                        if typeof(old) ~= "Instance" or old.Parent == nil then
                                                ConfirmSell(pend)
                                        end
                                end
                        end
                end
        end
        local kept = {}
        for _, pend in ipairs(S.Pending) do
                if not pend.Resolved then
                        table.insert(kept, pend)
                end
        end
        S.Pending = kept
end
local function MacroSweeper()
        while S.Rec do
                local ok, err = pcall(ProcessPendingSweep)
                if not ok then
                        notyuri("Snack sweep error:", tostring(err))
                end
                task.wait()
        end
        for _ = 1, 3 do
                if S.Rec or not S.Cur then break end
                pcall(ProcessPendingSweep)
                task.wait()
        end
end
local function WaitForMacroRemotes()
        local deadline = os.clock() + S.Timings.RemoteWait
        while os.clock() < deadline and not Library.Unloaded do
                if pcall(ResolveRemotes) and S.RemotesReady then return true end
                task.wait(0.5)
        end
        return S.RemotesReady
end
local function InstallMacroHook()
        if S.Hooked then return end
        if not Support.HookMeta then
                Library:Notify("Macro record requires hookmetamethod support", 4)
                return
        end
        WaitForMacroRemotes()
        S.Hooked = true
        local cc = (typeof(newcclosure) == "function") and newcclosure or (function(f) return f end)
        local originalNamecall
        originalNamecall = hookmetamethod(game, "__namecall", cc(function(...)
                local self = ...
                local method = getnamecallmethod()
                local ret = table.pack(originalNamecall(...))
                if method == "InvokeServer" and S.Rec then
                        local isPlace = rawequal(self, Remotes.PlaceTower)
                        local isUpgrade = rawequal(self, Remotes.UpgradeTower)
                        local isSell = rawequal(self, Remotes.SellTower)
                        local isMode = rawequal(self, Remotes.SetTowerTarget)
                        if isPlace or isUpgrade or isSell or isMode then
                                local nargs = table.pack(...)
                                local ok, snap = pcall(SnapshotCall, self, nargs)
                                if ok and snap then
                                        pcall(ResolveCall, snap, ret)
                                end
                        end
                end
                return table.unpack(ret, 1, ret.n)
        end))
        notyuri("Snack macro hook installed")
end
local function Func_MacroRecord(state)
        if not state then return end
        if Toggles.SnackReplay and Toggles.SnackReplay.Value then
                Toggles.SnackReplay:SetValue(false)
        end
        InstallMacroHook()
        S.Cur = { entries = {}, map = RS:GetAttribute("SelectedMap"), level = RS:GetAttribute("SelectedLevel") }
        S.Step = 0
        S.NextKey = 0
        S.RecKeys = {}
        S.Saved = false
        S.Pending = {}
        S.Adopted = {}
        UpdateMacroLabel("Waiting for match")
        while Toggles.SnackRecord and Toggles.SnackRecord.Value and not RoundLive() do
                task.wait()
        end
        if not (Toggles.SnackRecord and Toggles.SnackRecord.Value) then
                S.Cur = nil
                S.Step = 0
                UpdateMacroLabel()
                return
        end
        S.Rec = true
        UpdateMacroLabel()
        task.spawn(MacroSweeper)
        while Toggles.SnackRecord and Toggles.SnackRecord.Value and RoundLive() do
                task.wait()
        end
        S.Rec = false
        task.wait(0.1)
        pcall(ProcessPendingSweep)
        local entries = S.Cur and #S.Cur.entries or 0
        if entries > 0 and not S.Saved then
                S.Saved = true
                SortMacroEntries(S.Cur.entries)
                local fname = (Options.SnackMacroName and Options.SnackMacroName.Value) or ""
                if fname == "" then
                        fname = "Macro_" .. os.date("%Y%m%d_%H%M%S")
                end
                task.spawn(function()
                        if SaveMacro(fname, S.Cur) then
                                Library:Notify("Macro saved: " .. fname, 4)
                                S.MacroValues = ListMacros()
                                if Options.SnackMacroSelected then
                                        Options.SnackMacroSelected:SetValues(S.MacroValues)
                                end
                        else
                                Library:Notify("Failed to save macro (writefile unsupported?)", 4)
                        end
                end)
        end
        S.Cur = nil
        S.Step = 0
        UpdateMacroLabel("Stopped (" .. tostring(entries) .. ")")
end
local function MatchTowerAt(name, pos, radius)
        local best, bestDist = nil, radius or 6
        for _, tower in ipairs(GetOwnTowers()) do
                local part = tower.PrimaryPart or tower:FindFirstChildWhichIsA("BasePart")
                if part and tower.Name == name then
                        local dist = (part.Position - pos).Magnitude
                        if dist < bestDist then
                                best, bestDist = tower, dist
                        end
                end
        end
        return best
end
local function FindTowerForEntry(entry)
        local t = entry.Key and S.RepMap[entry.Key]
        if t and t.Parent then
                return t
        end
        local pos = entry.Pos
        if type(pos) ~= "table" or #pos ~= 3 then return nil end
        local target = Vector3.new(pos[1], pos[2], pos[3])
        if type(entry.Name) ~= "string" or entry.Name == "" then return nil end
        local best = MatchTowerAt(entry.Name, target, 7)
        if best and entry.Key then
                S.RepMap[entry.Key] = best
        end
        return best
end
local function ResolveTowerRetry(entry)
        local tower = FindTowerForEntry(entry)
        if tower and tower.Parent then return tower end
        local start = os.clock()
        while os.clock() - start < 1 do
                task.wait()
                tower = FindTowerForEntry(entry)
                if tower and tower.Parent then return tower end
        end
        return nil
end
local function MacroEntryCost(entry)
        local cfg = GetTowerCfg(entry.Name)
        if not cfg then return nil end
        if entry.Type == "Place" then
                return tonumber(cfg.Cost) or nil
        elseif entry.Type == "Upgrade" then
                if type(entry.LVL) == "number" and type(cfg.Upgrades) == "table" then
                        local tier = cfg.Upgrades[entry.LVL]
                        if type(tier) == "table" then
                                return tonumber(tier.Cost) or nil
                        end
                end
        end
        return nil
end
local function SlotForTower(name)
        for _, entry in ipairs(EquippedSlots()) do
                if entry.tower == name then
                        return entry.slot
                end
        end
        return nil
end
local function DoMacroAction(entry)
        if entry.Type == "Place" then
                local pos = entry.Pos
                if type(pos) ~= "table" or #pos ~= 3 then return end
                local slot = SlotForTower(entry.Name)
                if not slot then
                        notyuri("Place SKIP: not equipped:", tostring(entry.Name))
                        return
                end
                local placed = false
                for attempt = 1, S.Timings.MaxAttempts do
                        if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then return end
                        local spot = { x = pos[1], y = pos[2], z = pos[3] }
                        if attempt > 1 then
                                local alt = FindSpotNear(FootprintRadiusFor(entry.Name), pos[1], pos[3], 30)
                                if alt then
                                        spot = alt
                                end
                        end
                        local ok = TryPlaceTower(entry.Name, slot, spot, entry.Rot or 0)
                        if ok then
                                placed = true
                                break
                        end
                        local cost = MacroEntryCost(entry)
                        if not WaitForCash(cost, S.Timings.CashWait) then break end
                end
                if placed and entry.Key then
                        local start = os.clock()
                        local target = Vector3.new(pos[1], pos[2], pos[3])
                        while os.clock() - start < 1.5 do
                                local inst = MatchTowerAt(entry.Name, target, 7)
                                if inst then
                                        S.RepMap[entry.Key] = inst
                                        break
                                end
                                task.wait()
                        end
                end
        elseif entry.Type == "Upgrade" then
                local tower = ResolveTowerRetry(entry)
                if not (tower and tower.Parent) then
                        notyuri("Upgrade SKIP: no tower for key", tostring(entry.Key))
                        return
                end
                if type(entry.LVL) == "number" and GetTowerLevel(tower) >= entry.LVL then
                        return
                end
                for attempt = 1, S.Timings.MaxAttempts do
                        if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then return end
                        if TryUpgradeTower(tower) then return end
                        local cost = MacroEntryCost(entry)
                        if not WaitForCash(cost, S.Timings.CashWait) then return end
                end
        elseif entry.Type == "Sell" then
                local tower = ResolveTowerRetry(entry)
                if not (tower and tower.Parent) then
                        notyuri("Sell SKIP: no tower for key", tostring(entry.Key))
                        return
                end
                if TrySellTower(tower) and entry.Key then
                        S.RepMap[entry.Key] = nil
                end
        elseif entry.Type == "Mode" then
                local tower = ResolveTowerRetry(entry)
                if not (tower and tower.Parent) then return end
                TrySetTarget(tower, entry.Mode or "First")
        end
end
local function Func_MacroReplay()
        while Toggles.SnackReplay and Toggles.SnackReplay.Value do
                local name = Options.SnackMacroSelected and Options.SnackMacroSelected.Value or ""
                local macro = LoadMacro(name)
                if not (macro and type(macro.entries) == "table" and #macro.entries > 0) then
                        Toggles.SnackReplay:SetValue(false)
                        Library:Notify("No macro loaded", 3)
                        return
                end
                InstallMacroHook()
                S.Rep = true
                S.Total = #macro.entries
                S.Step = 0
                S.RepMap = {}
                SortMacroEntries(macro.entries)
                UpdateMacroLabel()
                while Toggles.SnackReplay and Toggles.SnackReplay.Value and not RoundLive() do
                        task.wait()
                end
                if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then break end
                for i, entry in ipairs(macro.entries) do
                        if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then break end
                        if not RoundLive() then
                                notyuri("match ended mid-pass")
                                break
                        end
                        S.Step = i
                        UpdateMacroLabel(entry.Type)
                        local replayMode = Options.SnackReplayMode and Options.SnackReplayMode.Value or "Money"
                        if replayMode == "Money" then
                                local cost = MacroEntryCost(entry)
                                if cost and cost > 0 then
                                        if not WaitForCash(cost) then
                                                notyuri("money wait aborted")
                                        end
                                end
                        else
                                local tWave = ParseMacroTime(entry)
                                while Toggles.SnackReplay and Toggles.SnackReplay.Value and GetWave() < tWave do
                                        if not RoundLive() then break end
                                        task.wait()
                                end
                        end
                        if not (Toggles.SnackReplay and Toggles.SnackReplay.Value) then break end
                        local ok, err = pcall(DoMacroAction, entry)
                        if not ok then
                                notyuri("Snack action failed:", tostring(err))
                        end
                        task.wait(0)
                end
                S.Rep = false
                S.Step = 0
                UpdateMacroLabel("Finished")
                while Toggles.SnackReplay and Toggles.SnackReplay.Value and RoundLive() do
                        task.wait()
                end
                while Toggles.SnackReplay and Toggles.SnackReplay.Value and not RoundLive() do
                        task.wait()
                end
        end
        S.Rep = false
        UpdateMacroLabel()
end
task.spawn(function()
        local deadline = os.clock() + 20
        while os.clock() < deadline and not Library.Unloaded do
                local slots = EquippedSlots()
                if #slots > 0 then
                        local names = {}
                        for _, entry in ipairs(slots) do
                                if not table.find(names, entry.tower) then
                                        table.insert(names, entry.tower)
                                end
                        end
                        S.TowerValues = names
                        S.UpgradeValues = names
                        S.TargetValues = names
                        S.SellValues = names
                        S.TraitValues = names
                        if Options.SnackPlaceTowers then
                                Options.SnackPlaceTowers:SetValues(names)
                        end
                        if Options.SnackUpgradeTowers then
                                Options.SnackUpgradeTowers:SetValues(names)
                        end
                        if Options.SnackTargetTowers then
                                Options.SnackTargetTowers:SetValues(names)
                        end
                        if Options.SnackSellTowers then
                                Options.SnackSellTowers:SetValues(names)
                        end
                        if Options.SnackTraitTowers then
                                Options.SnackTraitTowers:SetValues(names)
                        end
                        break
                end
                task.wait(1)
        end
end)
local GB_SnackFarm = TB_Tabs.Autofarm.T1:AddLeftGroupbox("Tower Farm")
GB_SnackFarm:AddToggle("SnackAutoPlace", { Text = "Auto Place" })
AddMultiDropdown(GB_SnackFarm, "SnackPlaceTowers", { Text = "Place Towers", Values = S.TowerValues, Default = { "All" } })
GB_SnackFarm:AddSlider("SnackPlaceDelay", { Text = "Place Delay", Default = 0.5, Min = 0.25, Max = 3, Rounding = 2, Suffix = "s" })
GB_SnackFarm:AddDivider()
GB_SnackFarm:AddToggle("SnackAutoUpgrade", { Text = "Auto Upgrade" })
AddMultiDropdown(GB_SnackFarm, "SnackUpgradeTowers", { Text = "Upgrade Towers", Values = S.UpgradeValues, Default = { "All" } })
GB_SnackFarm:AddDivider()
GB_SnackFarm:AddToggle("SnackAutoSell", { Text = "Auto Sell" })
AddMultiDropdown(GB_SnackFarm, "SnackSellTowers", { Text = "Sell Towers", Values = S.TowerValues, Default = {} })
GB_SnackFarm:AddDivider()
GB_SnackFarm:AddToggle("SnackAutoTarget", { Text = "Auto Target Mode" })
AddMultiDropdown(GB_SnackFarm, "SnackTargetTowers", { Text = "Target Towers", Values = S.TargetValues, Default = { "All" } })
GB_SnackFarm:AddDropdown("SnackTargetMode", { Text = "Targeting Mode", Values = { "First", "Last", "Strongest", "Weakest", "Bosses", "Healers", "Air" }, Default = "First" })
local GB_SnackFlow = TB_Tabs.Autofarm.T1:AddLeftGroupbox("Match Flow")
GB_SnackFlow:AddToggle("SnackAutoVote", { Text = "Auto Vote Yes", Tooltip = "Accepts start-wave and other match votes" })
GB_SnackFlow:AddToggle("SnackAutoFlow", { Text = "Auto Next Level", Tooltip = "Next level on win, chosen action on defeat" })
GB_SnackFlow:AddDropdown("SnackDefeatMode", { Text = "On Defeat", Values = { "Replay Level", "Return to Lobby", "Restart Match" }, Default = "Replay Level" })
GB_SnackFlow:AddToggle("SnackAutoSpeed", { Text = "Auto Game Speed" })
local function BuildSpeedValues()
        local values = { "1", "2" }
        if Plr:GetAttribute("OwnsSpeed3") == true then
                table.insert(values, "3")
        end
        if Plr:GetAttribute("OwnsSpeed5") == true then
                table.insert(values, "10")
        end
        return values
end
S.SpeedValues = BuildSpeedValues()
GB_SnackFlow:AddDropdown("SnackSpeed", { Text = "Speed", Values = S.SpeedValues, Default = S.SpeedValues[1] })
local GB_SnackMacro = TB.Main.Right.Autofarm:AddTab("Macro")
local GB_MacroRecord = GB_SnackMacro:AddLeftGroupbox("Record")
GB_MacroRecord:AddToggle("SnackRecord", { Text = "Record Macro" })
GB_MacroRecord:AddInput("SnackMacroName", { Text = "Macro Name", Placeholder = "auto = timestamp", Numeric = false, Finished = true })
local GB_MacroReplay = GB_SnackMacro:AddRightGroupbox("Replay")
S.MacroValues = ListMacros()
GB_MacroReplay:AddToggle("SnackReplay", { Text = "Replay Macro" })
GB_MacroReplay:AddDropdown("SnackMacroSelected", { Text = "Macro", Values = S.MacroValues, Default = S.MacroValues[1] })
GB_MacroReplay:AddDropdown("SnackReplayMode", { Text = "Replay Mode", Values = { "Money", "Wave" }, Default = "Money" })
GB_MacroReplay:AddButton({ Text = "Refresh Macros", Func = function()
        S.MacroValues = ListMacros()
        Options.SnackMacroSelected:SetValues(S.MacroValues)
end })
local GB_MacroStatus = GB_SnackMacro:AddLeftGroupbox("Status")
SafeLabel(GB_MacroStatus, "SnackMacro", "Idle")
local GB_SnackStats = TB.Main.Right.Autofarm:AddTab("Stats")
local GB_StatsMain = GB_SnackStats:AddLeftGroupbox("Match")
SafeLabel(GB_StatsMain, "SnackStatWave", "Wave -/-")
SafeLabel(GB_StatsMain, "SnackStatPhase", "Phase -")
SafeLabel(GB_StatsMain, "SnackStatCash", "Cash -")
SafeLabel(GB_StatsMain, "SnackStatBase", "Base -/-")
SafeLabel(GB_StatsMain, "SnackStatPlaced", "Placed -/-")
local GB_StatsWebhook = GB_SnackStats:AddRightGroupbox("Webhook")
GB_StatsWebhook:AddInput("SnackWebhookURL", { Text = "Webhook URL", Placeholder = "discord.com/api/webhooks/...", Numeric = false, Finished = true })
GB_StatsWebhook:AddToggle("SnackWebhook", { Text = "Send Match Results" })
local function FuncAutoPlace()
        while Toggles.SnackAutoPlace.Value do
                local ok, err = pcall(StepAutoPlace)
                if not ok then
                        notyuri("Snack place error:", tostring(err))
                end
                task.wait(Options.SnackPlaceDelay and Options.SnackPlaceDelay.Value or 0.5)
        end
end
local function FuncAutoUpgrade()
        while Toggles.SnackAutoUpgrade.Value do
                local ok, err = pcall(StepAutoUpgrade)
                if not ok then
                        notyuri("Snack upgrade error:", tostring(err))
                end
                task.wait(0.3)
        end
end
local function FuncAutoTarget()
        while Toggles.SnackAutoTarget.Value do
                local ok, err = pcall(StepAutoTarget)
                if not ok then
                        notyuri("Snack target error:", tostring(err))
                end
                task.wait(0.4)
        end
end
local function FuncAutoSell()
        while Toggles.SnackAutoSell.Value do
                local ok, err = pcall(StepAutoSell)
                if not ok then
                        notyuri("Snack sell error:", tostring(err))
                end
                task.wait(0.5)
        end
end
local function FuncAutoVote()
        while Toggles.SnackAutoVote.Value do
                local ok, err = pcall(StepAutoVote)
                if not ok then
                        notyuri("Snack vote error:", tostring(err))
                end
                task.wait(0.5)
        end
end
local function FuncStats()
        while not Library.Unloaded do
                local ok, _ = pcall(function()
                        local wave = GetWave()
                        local total = tonumber(RS:GetAttribute("TotalWaves")) or 0
                        local totalText = (total == -1) and "inf" or tostring(total)
                        SafeLabel("SnackStatWave", ("Wave %d/%s  |  Cleared %d"):format(wave, totalText, tonumber(RS:GetAttribute("WavesCleared")) or 0))
                        SafeLabel("SnackStatPhase", "Phase " .. ((GetPhase() ~= "") and GetPhase() or "-"))
                        SafeLabel("SnackStatCash", "Cash $" .. CommaFormat(math.floor(GetCash())))
                        local hp = tonumber(RS:GetAttribute("BaseHealth")) or 0
                        local hpMax = tonumber(RS:GetAttribute("BaseHealthMax")) or 0
                        SafeLabel("SnackStatBase", ("Base %d/%d"):format(math.floor(hp), math.floor(hpMax)))
                        local own = #GetOwnTowers()
                        local cap = BoardCap()
                        SafeLabel("SnackStatPlaced", ("Placed %d/%d  |  Mobs %d"):format(own, cap, tonumber(RS:GetAttribute("MobsRemaining")) or 0))
                end)
                task.wait(0.5)
        end
end
MacroGetSelection = function()
        return AddMultiDropdown("SnackPlaceTowers")
end
UpgradeGetSelection = function()
        return AddMultiDropdown("SnackUpgradeTowers")
end
TargetGetSelection = function()
        return AddMultiDropdown("SnackTargetTowers")
end
SellGetSelection = function()
        return AddMultiDropdown("SnackSellTowers")
end
Toggles.SnackAutoPlace:OnChanged(function(state)
        Thread("Snack.AutoPlace", SafeLoop("Snack.AutoPlace", FuncAutoPlace), state)
end)
Toggles.SnackAutoUpgrade:OnChanged(function(state)
        Thread("Snack.AutoUpgrade", SafeLoop("Snack.AutoUpgrade", FuncAutoUpgrade), state)
end)
Toggles.SnackAutoTarget:OnChanged(function(state)
        Thread("Snack.AutoTarget", SafeLoop("Snack.AutoTarget", FuncAutoTarget), state)
end)
Toggles.SnackAutoSell:OnChanged(function(state)
        Thread("Snack.AutoSell", SafeLoop("Snack.AutoSell", FuncAutoSell), state)
end)
Toggles.SnackAutoVote:OnChanged(function(state)
        if state then
                S.Voted = {}
        end
        Thread("Snack.AutoVote", SafeLoop("Snack.AutoVote", FuncAutoVote), state)
end)
Toggles.SnackAutoSpeed:OnChanged(function(state)
        if state then
                ApplyGameSpeed()
        end
end)
Toggles.SnackRecord:OnChanged(function(state)
        Thread("Snack.Record", SafeLoop("Snack.Record", function()
                Func_MacroRecord(state)
        end), state)
end)
Toggles.SnackReplay:OnChanged(function(state)
        if state and Toggles.SnackRecord and Toggles.SnackRecord.Value then
                Toggles.SnackRecord:SetValue(false)
        end
        Thread("Snack.Replay", SafeLoop("Snack.Replay", Func_MacroReplay), state)
end)
Thread("Snack.Stats", SafeLoop("Snack.Stats", FuncStats), true)
elseif IsLobby then
local function LeaderValue(name)
        local stats = Plr:FindFirstChild("leaderstats")
        local value = stats and stats:FindFirstChild(name)
        return value and tonumber(value.Value) or 0
end
local function GetMaps()
        local list = {}
        if not MapsFolder then return list end
        local skip = { LevelCurve = true, Geometry = true, RosterTuning = true }
        for _, child in ipairs(MapsFolder:GetChildren()) do
                if child:IsA("ModuleScript") and not skip[child.Name] then
                        table.insert(list, child.Name)
                end
        end
        table.sort(list)
        return list
end
local function LevelCountFor(mapName)
        if type(LevelCurve) == "table" and type(LevelCurve.Curve) == "table" and type(LevelCurve.Curve.MaxWaves) == "table" then
                return #LevelCurve.Curve.MaxWaves
        end
        return 6
end
local function HighestUnlockedLevel(mapName)
        local stats = Plr:FindFirstChild("PlayerMapStats")
        local mapStats = stats and stats:FindFirstChild(mapName)
        local levelCount = LevelCountFor(mapName)
        local best = 1
        for i = 1, levelCount do
                local entry = mapStats and mapStats:FindFirstChild("Level_" .. tostring(i))
                if entry and entry:GetAttribute("Beaten") == true then
                        best = math.min(i + 1, levelCount)
                end
        end
        return best
end
local function GetGemsBanners()
        local list = {}
        if type(SummonDictionary) ~= "table" then return list end
        for key, banner in pairs(SummonDictionary) do
                if type(banner) == "table" and type(banner.Cost) == "table" then
                        for _, cost in ipairs(banner.Cost) do
                                if type(cost) == "table" and cost.Currency == "Gems" and cost.CanBuy ~= false then
                                        table.insert(list, { key = key, cost = tonumber(cost.Amount) or 0, amounts = cost.AvailableAmounts or { 1 } })
                                        break
                                end
                        end
                end
        end
        table.sort(list, function(a, b)
                return a.cost < b.cost
        end)
        return list
end
local function DiceCount()
        local items = Plr:FindFirstChild("PlayerItems")
        local dice = items and items:FindFirstChild("TraitDice")
        if dice and dice:IsA("NumberValue") then
                return math.floor(dice.Value)
        end
        return 0
end
local function OwnedTowerFolders()
        local list = {}
        local folder = Plr:FindFirstChild("PlayerTowers")
        if not folder then return list end
        for _, child in ipairs(folder:GetChildren()) do
                if child:IsA("Folder") then
                        table.insert(list, child)
                end
        end
        return list
end
local function TowerUidEntryMap()
        local map = {}
        local folder = Plr:FindFirstChild("PlayerTowers")
        if not folder then return map end
        for _, child in ipairs(folder:GetChildren()) do
                if child:IsA("Folder") then
                        map[child.Name] = child
                end
        end
        return map
end
local function EquippedUids()
        local map = {}
        local slots = Plr:FindFirstChild("TowerSlots")
        if not slots then return map end
        for i = 1, 12 do
                local slot = slots:FindFirstChild(tostring(i))
                if not slot then
                        if i > 6 then break end
                else
                        local uid = slot:GetAttribute("TowerUid")
                        local tower = slot:GetAttribute("Tower")
                        if type(uid) == "string" and uid ~= "" and type(tower) == "string" and tower ~= "" then
                                map[uid] = tower
                        end
                end
        end
        return map
end
local function TraitTierOf(uidEntry)
        if type(TowerTraits) ~= "table" or type(TowerTraits.Get) ~= "function" then return 0 end
        local trait = uidEntry and uidEntry:GetAttribute("Trait")
        if type(trait) ~= "string" or trait == "" then return 0 end
        local ok, data = pcall(function()
                return TowerTraits:Get(trait)
        end)
        if ok and type(data) == "table" then
                return tonumber(data.Tier) or 0
        end
        return 0
end
local function StepAutoQueue()
        if not ResolveRemotes() then return end
        local padId = Plr:GetAttribute("PartyPadId")
        local isHost = Plr:GetAttribute("IsPartyHost") == true
        if not (type(padId) == "string" and padId ~= "" and isHost) then
                local zones = GetObject(workspace, "Lobby.Functional.Zones")
                local candidates = {}
                if zones then
                        for _, zone in ipairs(zones:GetChildren()) do
                                table.insert(candidates, zone)
                        end
                end
                if #candidates == 0 then
                        NotifyOnce("SnackNoZones", "No free party pads found in the lobby")
                        return
                end
                local char = GetCharacter()
                if not char then return end
                local zone = GetNearest(candidates)
                if not zone then
                        zone = candidates[1]
                end
                TweenTo(60, zone)
                return
        end
        S.FlowNotified["SnackNoZones"] = nil
        local map = Options.SnackQueueMap and Options.SnackQueueMap.Value or ""
        if map == "" then return end
        local levelPick = Options.SnackQueueLevel and Options.SnackQueueLevel.Value or "Highest Unlocked"
        local level
        if levelPick == "Highest Unlocked" then
                level = HighestUnlockedLevel(map)
        else
                level = tonumber(levelPick) or 1
        end
        if Toggles.SnackEquipBest and Toggles.SnackEquipBest.Value then
                SnackSend(Remotes.EquipBestTowers)
                task.wait(1)
        end
        notyuri("Snack queue:", map, "level", tostring(level))
        SnackSend(Remotes.RequestPlay, map, level)
        task.wait(5)
end
local function FuncAutoQueue()
        while Toggles.SnackAutoQueue.Value do
                local ok, err = pcall(StepAutoQueue)
                if not ok then
                        notyuri("Snack queue error:", tostring(err))
                end
                local waited = 0
                while waited < 5 and Toggles.SnackAutoQueue.Value do
                        task.wait(0.5)
                        waited = waited + 0.5
                end
        end
end
local function StepAutoSummon()
        if not ResolveRemotes() then return end
        local bannerKey = Options.SnackSummonBanner and Options.SnackSummonBanner.Value or ""
        local key = bannerKey:match("^(%S+) %(") or bannerKey
        if key == "" then return end
        local banners = GetGemsBanners()
        local banner = nil
        for _, entry in ipairs(banners) do
                if entry.key == key then
                        banner = entry
                        break
                end
        end
        if not banner then return end
        local amount = tonumber(Options.SnackSummonAmount and Options.SnackSummonAmount.Value) or 1
        if not table.find(banner.amounts, amount) then
                amount = banner.amounts[1] or 1
        end
        local reserve = Options.SnackSummonReserve and Options.SnackSummonReserve.Value or 0
        local gems = LeaderValue("Gems")
        if gems - reserve < banner.cost * amount then return end
        SnackSend(Remotes.RequestSummon, key, amount)
        task.wait(2.5)
end
local function FuncAutoSummon()
        while Toggles.SnackAutoSummon.Value do
                local ok, err = pcall(StepAutoSummon)
                if not ok then
                        notyuri("Snack summon error:", tostring(err))
                end
                task.wait(0.5)
        end
end
local function StepAutoTraitRoll()
        if not ResolveRemotes() then return end
        local selected = TraitGetSelection and TraitGetSelection() or {}
        if not next(selected) then return end
        if DiceCount() < 1 then return end
        local minTier = 2
        local pick = Options.SnackTraitStop and Options.SnackTraitStop.Value or "Tier 2+"
        if pick == "Tier 3" then
                minTier = 3
        elseif pick == "Roll All Dice" then
                minTier = 99
        end
        local uidMap = TowerUidEntryMap()
        local equipped = EquippedUids()
        for uid, towerName in pairs(equipped) do
                if selected[towerName] then
                        local entry = uidMap[uid]
                        if entry then
                                local tier = TraitTierOf(entry)
                                if tier < minTier then
                                        SnackSend(Remotes.RequestTraitRoll, uid)
                                        return
                                end
                        end
                end
        end
end
local function FuncAutoTraitRoll()
        while Toggles.SnackAutoTraitRoll.Value do
                local ok, err = pcall(StepAutoTraitRoll)
                if not ok then
                        notyuri("Snack trait error:", tostring(err))
                end
                task.wait(1.3)
        end
end
local function StepAutoFuse()
        if not ResolveRemotes() then return end
        if type(TowerStars) ~= "table" then return end
        local uidMap = TowerUidEntryMap()
        local equipped = EquippedUids()
        local groups = {}
        for _, entry in ipairs(OwnedTowerFolders()) do
                local towerName = entry:GetAttribute("Tower")
                if type(towerName) == "string" and towerName ~= "" then
                        groups[towerName] = groups[towerName] or {}
                        table.insert(groups[towerName], entry)
                end
        end
        local maxStars = tonumber(TowerStars.MaxStars) or 5
        for towerName, copies in pairs(groups) do
                local cfg = GetTowerCfg(towerName)
                if cfg then
                        local needed = 5
                        if type(TowerStars.copiesFor) == "function" then
                                local ok, n = pcall(TowerStars.copiesFor, TowerStars, cfg)
                                needed = ok and tonumber(n) or 5
                        end
                        local best = nil
                        for _, copy in ipairs(copies) do
                                if not best then
                                        best = copy
                                else
                                        local bs = tonumber(best:GetAttribute("Stars")) or 0
                                        local cs = tonumber(copy:GetAttribute("Stars")) or 0
                                        local bl = tonumber(best:GetAttribute("Level")) or 0
                                        local cl = tonumber(copy:GetAttribute("Level")) or 0
                                        if cs > bs or (cs == bs and cl > bl) then
                                                best = copy
                                        end
                                end
                        end
                        local bestStars = best and (tonumber(best:GetAttribute("Stars")) or 0) or 0
                        if best and bestStars < maxStars then
                                local fodder = {}
                                for _, copy in ipairs(copies) do
                                        if #fodder >= needed then break end
                                        if copy ~= best then
                                                local stars = tonumber(copy:GetAttribute("Stars")) or 0
                                                local shiny = copy:GetAttribute("Shiny") == true
                                                local locked = copy:GetAttribute("Locked") == true
                                                local isEquipped = false
                                                for uid, _ in pairs(equipped) do
                                                        if uidMap[uid] == copy then
                                                                isEquipped = true
                                                                break
                                                        end
                                                end
                                                if stars == 0 and not shiny and not locked and not isEquipped then
                                                        table.insert(fodder, copy.Name)
                                                end
                                        end
                                end
                                if #fodder >= needed then
                                        local result = SafeInvoke(Remotes.StarsFuseRequest, nil, best.Name, fodder)
                                        if type(result) == "table" and result.ok then
                                                Library:Notify("Fused " .. towerName .. " +1 star", 4)
                                        end
                                        return
                                end
                        end
                end
        end
end
local function FuncAutoFuse()
        while Toggles.SnackAutoFuse.Value do
                local ok, err = pcall(StepAutoFuse)
                if not ok then
                        notyuri("Snack fuse error:", tostring(err))
                end
                task.wait(8)
        end
end
local function StepAutoQuests()
        if not ResolveRemotes() then return end
        if Plr:GetAttribute("QuestsUnlocked") ~= true then return end
        if type(QuestsMod) ~= "table" then return end
        local state = SafeInvoke(Remotes.QuestState)
        if type(state) ~= "table" or not state.ok then return end
        local boards = { { key = QuestsMod.Boards.Daily, data = state.daily }, { key = QuestsMod.Boards.Weekly, data = state.weekly } }
        for _, board in ipairs(boards) do
                local slots = type(board.data) == "table" and type(board.data.slots) == "table" and board.data.slots or {}
                for _, entry in ipairs(slots) do
                        if type(entry) == "table" and entry.Claimed ~= true then
                                local target = tonumber(entry.Target)
                                local progress = tonumber(entry.Progress) or 0
                                if target and progress >= target then
                                        local result = SafeInvoke(Remotes.QuestClaim, nil, board.key, entry.Slot)
                                        if type(result) == "table" and result.ok then
                                                Library:Notify("Quest claimed: " .. tostring(board.key) .. " " .. tostring(entry.Slot), 4)
                                        end
                                end
                        end
                end
        end
end
local function FuncAutoQuests()
        while Toggles.SnackAutoQuests.Value do
                local ok, err = pcall(StepAutoQuests)
                if not ok then
                        notyuri("Snack quest error:", tostring(err))
                end
                task.wait(60)
        end
end
local function FuncAutoIndex()
        while Toggles.SnackAutoIndex.Value do
                local ok, err = pcall(function()
                        if not ResolveRemotes() then return end
                        local result = SafeInvoke(Remotes.IndexRewardClaim)
                        if type(result) == "table" and result.ok then
                                Library:Notify("Index reward: +" .. tostring(result.amount or 3) .. " Trait Dice", 4)
                        end
                end)
                if not ok then
                        notyuri("Snack index error:", tostring(err))
                end
                task.wait(60)
        end
end
local function FuncGroupReward()
        if Plr:GetAttribute("GroupRewardClaimed") == true then
                Library:Notify("Group reward already claimed", 3)
        elseif not ResolveRemotes() then
                Library:Notify("Group reward remote unavailable", 3)
        else
                local result = SafeInvoke(Remotes.RequestGroupRewardClaim)
                if type(result) == "table" then
                        if result.ok then
                                Library:Notify("Group reward claimed!", 4)
                        else
                                Library:Notify("Group reward: " .. tostring(result.reason or "join the group first"), 4)
                        end
                end
        end
        if Toggles.SnackGroupReward then
                Toggles.SnackGroupReward:SetValue(false)
        end
end
local function FuncAfkTeleport()
        if not ResolveRemotes() then
                Library:Notify("AFK teleport unavailable", 3)
        else
                SnackSend(Remotes.RequestAfkTeleport)
                Library:Notify("Teleporting to the AFK place...", 3)
        end
        if Toggles.SnackAfkTeleport then
                Toggles.SnackAfkTeleport:SetValue(false)
        end
end
task.spawn(function()
        local deadline = os.clock() + 30
        while os.clock() < deadline and not Library.Unloaded do
                if pcall(ResolveRemotes) and S.RemotesReady then break end
                task.wait(1)
        end
        if Remotes.MatchRejoinOffer and not Library.Unloaded then
                Connections["Snack_Rejoin"] = Remotes.MatchRejoinOffer.OnClientEvent:Connect(function()
                        if not (Toggles.SnackAutoRejoin and Toggles.SnackAutoRejoin.Value) then return end
                        task.wait(0.5)
                        SnackSend(Remotes.MatchRejoinAnswer, true)
                end)
        end
end)
task.spawn(function()
        local deadline = os.clock() + 20
        while os.clock() < deadline and not Library.Unloaded do
                local slots = EquippedUids()
                if next(slots) then
                        local names = {}
                        for _, towerName in pairs(slots) do
                                if not table.find(names, towerName) then
                                        table.insert(names, towerName)
                                end
                        end
                        table.sort(names)
                        S.TraitValues = names
                        if Options.SnackTraitTowers then
                                Options.SnackTraitTowers:SetValues(names)
                        end
                        break
                end
                task.wait(1)
        end
end)
S.MapKeys = GetMaps()
local levelValues = { "Highest Unlocked" }
local maxLevelCount = 1
for _, mapName in ipairs(S.MapKeys) do
        local count = LevelCountFor(mapName)
        if count > maxLevelCount then
                maxLevelCount = count
        end
end
for i = 1, maxLevelCount do
        table.insert(levelValues, tostring(i))
end
S.LevelValues = levelValues
local banners = GetGemsBanners()
local bannerLabels = {}
S.BannerKeys = {}
for _, banner in ipairs(banners) do
        table.insert(bannerLabels, banner.key .. " (" .. tostring(banner.cost) .. " gems)")
        table.insert(S.BannerKeys, banner.key)
end
local firstAmounts = (banners[1] and banners[1].amounts) or { 1 }
local amountLabels = {}
for _, amount in ipairs(firstAmounts) do
        table.insert(amountLabels, tostring(amount))
end
local GB_Queue = TB_Tabs.Autofarm.T1:AddLeftGroupbox("Auto Queue")
GB_Queue:AddToggle("SnackAutoQueue", { Text = "Auto Queue Match" })
GB_Queue:AddDropdown("SnackQueueMap", { Text = "Map", Values = S.MapKeys, Default = S.MapKeys[1] })
GB_Queue:AddDropdown("SnackQueueLevel", { Text = "Level", Values = S.LevelValues, Default = "Highest Unlocked" })
GB_Queue:AddToggle("SnackEquipBest", { Text = "Equip Best Before Queue" })
local GB_Summon = TB_Tabs.Autofarm.T1:AddLeftGroupbox("Auto Summon")
GB_Summon:AddToggle("SnackAutoSummon", { Text = "Auto Summon" })
GB_Summon:AddDropdown("SnackSummonBanner", { Text = "Banner", Values = bannerLabels, Default = bannerLabels[1] })
GB_Summon:AddDropdown("SnackSummonAmount", { Text = "Amount", Values = amountLabels, Default = amountLabels[1] })
GB_Summon:AddSlider("SnackSummonReserve", { Text = "Keep Gems Above", Default = 0, Min = 0, Max = 10000, Rounding = 0 })
local GB_Trait = TB_Tabs.Autofarm.T1:AddLeftGroupbox("Auto Trait Roll")
GB_Trait:AddToggle("SnackAutoTraitRoll", { Text = "Auto Trait Roll" })
AddMultiDropdown(GB_Trait, "SnackTraitTowers", { Text = "Equipped Towers", Values = S.TraitValues, Default = { "All" } })
GB_Trait:AddDropdown("SnackTraitStop", { Text = "Stop At", Values = { "Tier 2+", "Tier 3", "Roll All Dice" }, Default = "Tier 2+" })
local GB_Inv = TB.Main.Right.Autofarm:AddTab("Inventory")
local GB_InvMain = GB_Inv:AddLeftGroupbox("Inventory")
GB_InvMain:AddToggle("SnackAutoFuse", { Text = "Auto Fuse Stars", Tooltip = "Fuses duplicate snacks into stars" })
GB_InvMain:AddToggle("SnackAutoQuests", { Text = "Auto Claim Quests" })
GB_InvMain:AddToggle("SnackAutoIndex", { Text = "Auto Claim Index Rewards" })
GB_InvMain:AddToggle("SnackGroupReward", { Text = "Claim Group Reward" })
GB_InvMain:AddToggle("SnackAfkTeleport", { Text = "Teleport to AFK Farm" })
GB_InvMain:AddToggle("SnackAutoRejoin", { Text = "Auto Accept Match Rejoin" })
local GB_InvStats = GB_Inv:AddRightGroupbox("Lobby Stats")
SafeLabel(GB_InvStats, "SnackStatGems", "Gems -")
SafeLabel(GB_InvStats, "SnackStatLevel", "Level -")
SafeLabel(GB_InvStats, "SnackStatStorage", "Towers -/-")
SafeLabel(GB_InvStats, "SnackStatDice", "Trait Dice -")
SafeLabel(GB_InvStats, "SnackStatStreak", "Win Streak -")
local function FuncLobbyStats()
        while not Library.Unloaded do
                local ok, _ = pcall(function()
                        SafeLabel("SnackStatGems", "Gems " .. CommaFormat(LeaderValue("Gems")))
                        local levelStats = Plr:FindFirstChild("PlayerLevelStats")
                        local lvl = levelStats and tonumber(levelStats:GetAttribute("Level")) or 0
                        local xp = levelStats and tonumber(levelStats:GetAttribute("Progress")) or 0
                        SafeLabel("SnackStatLevel", ("Level %d (%d%%)"):format(lvl, math.floor(xp * 100)))
                        local folder = Plr:FindFirstChild("PlayerTowers")
                        local maxStorage = folder and tonumber(folder:GetAttribute("MaxStorage")) or 0
                        local count = 0
                        if folder then
                                for _, child in ipairs(folder:GetChildren()) do
                                        if child:IsA("Folder") then
                                                count = count + 1
                                        end
                                end
                        end
                        SafeLabel("SnackStatStorage", ("Towers %d/%d"):format(count, maxStorage))
                        SafeLabel("SnackStatDice", "Trait Dice " .. tostring(DiceCount()))
                        SafeLabel("SnackStatStreak", "Win Streak " .. tostring(tonumber(Plr:GetAttribute("WinStreak")) or 0))
                end)
                task.wait(1)
        end
end
local function OnSummonBannerChanged()
        local label = Options.SnackSummonBanner and Options.SnackSummonBanner.Value or ""
        local key = label:match("^(%S+) %(")
        local banner = nil
        for _, entry in ipairs(GetGemsBanners()) do
                if entry.key == key then
                        banner = entry
                        break
                end
        end
        local labels = {}
        if banner then
                for _, amount in ipairs(banner.amounts) do
                        table.insert(labels, tostring(amount))
                end
        end
        if #labels == 0 then
                table.insert(labels, "1")
        end
        if Options.SnackSummonAmount then
                Options.SnackSummonAmount:SetValues(labels)
                Options.SnackSummonAmount:SetValue(labels[1])
        end
end
Options.SnackSummonBanner:OnChanged(OnSummonBannerChanged)
Toggles.SnackAutoQueue:OnChanged(function(state)
        Thread("Snack.AutoQueue", SafeLoop("Snack.AutoQueue", FuncAutoQueue), state)
end)
Toggles.SnackAutoSummon:OnChanged(function(state)
        Thread("Snack.AutoSummon", SafeLoop("Snack.AutoSummon", FuncAutoSummon), state)
end)
Toggles.SnackAutoTraitRoll:OnChanged(function(state)
        Thread("Snack.AutoTrait", SafeLoop("Snack.AutoTrait", FuncAutoTraitRoll), state)
end)
Toggles.SnackAutoFuse:OnChanged(function(state)
        Thread("Snack.AutoFuse", SafeLoop("Snack.AutoFuse", FuncAutoFuse), state)
end)
Toggles.SnackAutoQuests:OnChanged(function(state)
        Thread("Snack.AutoQuests", SafeLoop("Snack.AutoQuests", FuncAutoQuests), state)
end)
Toggles.SnackAutoIndex:OnChanged(function(state)
        Thread("Snack.AutoIndex", SafeLoop("Snack.AutoIndex", FuncAutoIndex), state)
end)
Toggles.SnackGroupReward:OnChanged(function(state)
        if state then
                Thread("Snack.GroupReward", SafeLoop("Snack.GroupReward", FuncGroupReward), true)
        end
end)
Toggles.SnackAfkTeleport:OnChanged(function(state)
        if state then
                Thread("Snack.AfkTeleport", SafeLoop("Snack.AfkTeleport", FuncAfkTeleport), true)
        end
end)
TraitGetSelection = function()
        return AddMultiDropdown("SnackTraitTowers")
end
Thread("Snack.LobbyStats", SafeLoop("Snack.LobbyStats", FuncLobbyStats), true)
else
Library:Notify("Snack: AFK place detected - game features idle", 4)
end
SnackOk = true
end
end
local antiAFKConn = nil
local function RunAntiAFK()
    if antiAFKConn then antiAFKConn:Enable() return end
    local GC = getconnections or get_signal_cons
    if GC then
        local conns = GC(Players.LocalPlayer.Idled)
        local target = conns and conns[1]
        if target and target.Disable then
            target:Disable()
            antiAFKConn = target
            return
        end
        for _, c in pairs(conns or {}) do
            if c.Disable then
                c:Disable()
                antiAFKConn = c
                return
            elseif c.Disconnect then
                c:Disconnect()
                return
            end
        end
    end
    Players.LocalPlayer.Idled:Connect(function()
        VirtualUser:CaptureController()
        VirtualUser:ClickButton2(Vector2.new())
    end)
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then
        RunAntiAFK()
    elseif antiAFKConn and antiAFKConn.Enable then
        antiAFKConn:Enable()
    end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
        Default = Library.KeybindFrame.Visible,
        Text = "Open Keybind Menu",
        Callback = function(value)
                Library.KeybindFrame.Visible = value
        end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
        Text = "Custom Cursor",
        Default = false,
        Callback = function(Value)
                Library.ShowCustomCursor = Value
        end,
})
MenuGroup:AddDropdown("NotificationSide", {
        Values = { "Left", "Right" },
        Default = "Right",
        Text = "Notification Side",
        Callback = function(Value)
                Library:SetNotifySide(Value)
        end,
})
MenuGroup:AddDropdown("DPIDropdown", {
        Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
        Default = "100%",
        Text = "DPI Scale",
        Callback = function(Value)
                Value = Value:gsub("%%", "")
                local DPI = tonumber(Value)
                Library:SetDPIScale(DPI)
        end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
        :AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    if antiAFKConn and antiAFKConn.Enable then pcall(function() antiAFKConn:Enable() end) end
    if Support.FPS then pcall(function() setfpscap(2000) end) end
    Cleanup(Connections)
    Cleanup(Flags)
        Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
SaveManager:IgnoreThemeSettings()
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/Snack")
SaveManager:BuildConfigSection(Tabs.Config)
ThemeManager:ApplyToTab(Tabs.Config)
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
SaveManager:SetLoadingOrder(true, {"Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle"})
if UIS.TouchEnabled and not UIS.KeyboardEnabled then
    Library:SetDPIScale(75)
elseif UIS.KeyboardEnabled then
    Library:SetDPIScale(100)
end
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end
