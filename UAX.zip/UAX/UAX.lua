repeat task.wait() until game:IsLoaded()
repeat task.wait() until game.GameId ~= 0
if getgenv().ayasemiyatongekissazumirisa then
    warn("yuri")
    return
end
function missing(t, f, fallback)
    if type(f) == t then return f end
    return fallback
end
cloneref = missing("function", cloneref, function(...) return ... end)
getgc = missing("function", getgc or get_gc_objects)
getconnections = missing("function", getconnections or get_signal_cons)
local Support = {
    Webhook = (typeof(request) == "function" or typeof(http_request) == "function"),
    Clipboard = (typeof(setclipboard) == "function"),
    FileIO = (typeof(writefile) == "function" and typeof(isfile) == "function"),
    QueueOnTeleport = (typeof(queue_on_teleport) == "function" or typeof(queueonteleport) == "function"),
    Connections = (typeof(getconnections) == "function"),
    FPS = (typeof(setfpscap) == "function"),
    Proximity = (typeof(fireproximityprompt) == "function"),
    HookMeta = (typeof(hookmetamethod) == "function"),
    Firesignal = (typeof(firesignal) == "function"),
}
Services = setmetatable({}, {
    __index = function(self, name)
        local success, cache = pcall(function()
            return cloneref(game:GetService(name))
        end)
        if success then
            rawset(self, name, cache)
            return cache
        else
            error("Invalid Service: " .. tostring(name))
        end
    end
})
local Players = Services.Players
local Plr = setmetatable({}, {
    __index = function(_, key)
        local lp = Players.LocalPlayer
        if not lp then return nil end
        local val = lp[key]
        if type(val) == "function" then
            return function(_, ...)
                return val(lp, ...)
            end
        end
        return val
    end,
    __newindex = function(_, key, value)
        local lp = Players.LocalPlayer
        if not lp then return end
        lp[key] = value
    end,
})
local Lighting = Services.Lighting
local RS = Services.ReplicatedStorage
local RunService = Services.RunService
local HttpService = Services.HttpService
local GuiService = Services.GuiService
local TeleportService = Services.TeleportService
local Marketplace = Services.MarketplaceService
local UIS = Services.UserInputService
local VirtualUser = Services.VirtualUser
local v, Asset = pcall(function()
    return Marketplace:GetProductInfo(game.PlaceId)
end)
local assetName = "game name"
if v and Asset then
    assetName = Asset.Name
end
local executorName = (identifyexecutor and identifyexecutor() or "Unknown"):lower()
local executorDisplayName = (identifyexecutor and identifyexecutor() or "Unknown")
local LimitedExecutors = {"xeno", "solara",}
local isLimitedExecutor = false
for _, name in ipairs(LimitedExecutors) do
    if string.find(executorName, name) then
        isLimitedExecutor = true
        break
    end
end
local yuri = {
    "https://mangadex.org/covers/5311ac6f-3651-43a8-bb9c-b40dea7ab72d/062845cb-4498-4499-a23a-89ecac694ea9.jpg",
    "https://mangadex.org/covers/df01a222-faeb-4952-84ac-d6040815e2dd/ec777628-a5d7-4d5f-92f5-11a8a746427e.jpg",
    "https://cdn.donmai.us/original/dc/0e/__hayafuji_kasane_and_aoyama_meguru_keiyaku_shimai_drawn_by_hijiki_hijikini__dc0e2235f2ca00dcb06aa3db2999bd1f.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/233/thumbnail.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/328/thumbnail.jpg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/1339/thumbnail.jpeg",
    "https://db.yurigarden.com/storage/v1/object/public/yuri-garden-store/comics/1268/thumbnail.jpeg",
    "https://dynasty-scans.com/system/releases/000/040/979/001.webp",
    "https://dynasty-scans.com/system/images_images/000/031/460/full/GErfQqXagAA4mk7-orig.webp",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2026/02/01/15/33/44/140636490_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2022/08/15/23/52/23/100515820_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2025/07/22/17/09/45/132989170_p0_master1200.jpg",
    "https://i.pximg.net/c/1200x1200_80_webp/img-master/img/2019/12/01/21/59/30/78092730_p0_master1200.jpg",
}
local function notyuri()
end
local repo = "https://raw.githubusercontent.com/iLove-yuri/Linoria/main/"
local Library = loadstring(game:HttpGet(repo .. "Library.lua"))()
local ThemeManager = loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))()
local SaveManager = loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))()
getgenv().ayasemiyatongekissazumirisa = true
local Options = Library.Options
local Toggles = Library.Toggles
Library.ShowToggleFrameInKeybinds = true
Library.ShowCustomCursor = true
Library.NotifySide = "Left"
local function AddInfo(Window)
    local InfoTab = Window:AddTab("Info")
    local InfoLeft = InfoTab:AddLeftGroupbox("Information")
    local statusText = isLimitedExecutor and "<font color='#FFA500'>Semi-Working</font>" or "<font color='#00FF00'>Working</font>"
    local extraNote = isLimitedExecutor
        and "<b>NOTE:</b> May experiencing bugs for some features!"
        or "All features should works properly!"
    InfoLeft:AddLabel("<b>Executor:</b> " .. executorDisplayName .. "\n<b>Status:</b> " .. statusText .. "\n" .. extraNote, true)
    local InfoRight = InfoTab:AddRightGroupbox("Others")
    InfoRight:AddButton({
        Text = "Join Discord Server",
        Func = function()
            local inviteCode = "6pCsSbVd3E"
            local inviteLink = "https://discord.gg/" .. inviteCode
            local success = false
            if request then
                success = pcall(function()
                    request({
                        Url = "http://127.0.0.1:6463/rpc?v=1",
                        Method = "POST",
                        Headers = {
                            ["Content-Type"] = "application/json",
                            ["Origin"] = "https://discord.com"
                        },
                        Body = HttpService:JSONEncode({
                            cmd = "INVITE_BROWSER",
                            args = { code = inviteCode },
                            nonce = HttpService:GenerateGUID(false)
                        })
                    })
                end)
            end
            if not success and setclipboard then
                setclipboard(inviteLink)
            end
        end,
    })
end
local eh_success, err = pcall(function()
local function GetObject(parent, pathString)
    local current = parent
    for _, name in ipairs(pathString:split(".")) do
        if not current then return nil end
        current = current:FindFirstChild(name)
    end
    return current
end
local function GetSafeModule(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and obj:IsA("ModuleScript") then
        local success, result = pcall(require, obj)
        if success then return result end
    end
    return nil
end
local function GetSafeRemote(parent, name)
    local obj = parent:FindFirstChild(name)
    if obj and (obj:IsA("RemoteEvent") or obj:IsA("RemoteFunction")) then
        return obj
    end
    return nil
end
local function FireRemote(remote, ...)
    if not remote then return false end
    local args = {...}
    local ok, err = pcall(function()
        remote:FireServer(unpack(args))
    end)
    if not ok then notyuri("FireRemote error:", tostring(remote), tostring(err)) end
    return ok
end
local Remotes = {
}
local Modules = {
}
local Flags = {}
local Shared = {
    SelfThreads = {},
    UAXCmds = {"RequestPlace", "UpgradeUnit", "SellUnit", "ChangePriority", "UseActive"},
    PosDir = "yuri/UAX",
    Labels = {},
    MacroTimings = {
        PendingExpiry = 12,
        RemoteWait = 8,
        MaxAttempts = 10,
    },
    MState = {
        Rec = false,
        Rep = false,
        Cur = nil,
        Load = nil,
        Hooked = false,
        Step = 0,
        Total = 0,
        NextKey = 0,
        RecKeys = {},
        RepMap = {},
        Saved = false,
        Pending = {},
        Adopted = {},
    },
    Place = {
        FailPos = {},
        TypeFails = {},
        PauseUntil = {},
        GridCache = nil,
        GridKey = "",
        SpiralCenter = nil,
        SpiralCursor = 0,
        Spiral = nil,
        SpiralFailMemo = {},
        SlotPositions = {},
        MapLabelRef = nil,
    },
    Memo = {
        AbilityAt = {},
        SummonFails = 0,
        SkipVoted = false,
        ReadyFired = false,
        EndNotified = false,
    },
    PlaceCube = {
        PartName = "PCube",
        Pending = Color3.fromRGB(80, 160, 255),
        Success = Color3.fromRGB(80, 255, 120),
        Fail = Color3.fromRGB(255, 80, 80),
    },
    PCubePool = {
        Free = {},
        Active = {},
    },
    WaveStartAt = 0,
    LastWave = 0,
    LobbyQuest = {Cache = nil},
}
Shared.MDir = Shared.PosDir .. "/Macros"
Shared.PosPath = Shared.PosDir .. "/position.json"
local Connections = {
    Player_General = nil,
    Knockback = {},
    Reconnect = nil,
}
local function AddMultiDropdown(group, id, config)
    if type(group) == "string" then
        local selected = {}
        local dropdown = Options[group]
        local values = dropdown and dropdown.Values or {}
        local chosen = dropdown and dropdown.Value or {}
        if chosen["All"] then
            for _, label in ipairs(values) do
                if label ~= "All" then selected[label] = true end
            end
        else
            for label, active in pairs(chosen) do
                if active and label ~= "All" then selected[label] = true end
            end
        end
        return selected
    end
    config = config or {}
    local values = { "All" }
    for _, v in ipairs(config.Values or {}) do
        table.insert(values, v)
    end
    group:AddDropdown(id, {
        Text = config.Text,
        Values = values,
        Default = config.Default or {},
        Multi = true,
        Searchable = true,
        Callback = config.Callback,
    })
    return Options[id]
end
local function SafeLabel(target, id, text)
    if type(target) == "string" then
        local entry = Shared.Labels[target]
        if entry then
            entry.Text = id
            entry.Dirty = true
        end
        return
    end
    local label = target:AddLabel(text, true)
    Shared.Labels[id] = {Label = label, Text = text, Dirty = false}
    Thread("SafeLabel", function()
        while not Library.Unloaded do
            for key, entry in pairs(Shared.Labels) do
                if entry.Dirty then
                    entry.Dirty = false
                    local ok, err = pcall(function()
                        entry.Label:SetText(entry.Text)
                    end)
                    if not ok then
                        notyuri("SafeLabel SetText FAILED:", tostring(key), tostring(err))
                    end
                end
            end
            task.wait()
        end
    end, true)
    return label
end
function AddSliderToggle(Config, ...)
    if type(Config) == "string" then
        return Toggles[Config], Options[Config .. "Value"]
    end
    local Handlers = {...}
    local Toggle, Slider
    Toggle = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.DefaultToggle or false,
        Disabled = Config.Disabled,
        Callback = function(state)
            if Slider then Slider:SetVisible(state) end
            for _, Handler in ipairs(Handlers) do
                Handler(state, Toggle, Slider)
            end
        end,
    })
    Slider = Config.Group:AddSlider(Config.Id .. "Value", {
        Text = Config.Text,
        Default = Config.Default,
        Min = Config.Min,
        Max = Config.Max,
        Rounding = Config.Rounding or 0,
        Compact = true,
        Visible = false
    })
    return Toggles[Config.Id], Options[Config.Id .. "Value"]
end
function MultiToggle(Config)
    local Parent
    local Children = {}
    Parent = Config.Group:AddToggle(Config.Id, {
        Text = Config.Text,
        Default = Config.Default or false,
        Disabled = Config.Disabled,
        Callback = function(Value)
            for _, Child in ipairs(Children) do
                Child.TextLabel.Parent.Visible = Value
                Child:SetVisible(Value)
            end
        end,
    })
    for _, ChildConfig in ipairs(Config.Children) do
        table.insert(Children, Config.Group:AddToggle(ChildConfig.Id, {
            Text = ChildConfig.Text,
            Default = ChildConfig.Default or false,
            Disabled = ChildConfig.Disabled,
            Visible = Parent.Value,
        }))
    end
    return Parent, Children
end
local function SafeConnect(key, getSignalFn, handler)
    local ok, signal = pcall(getSignalFn)
    if not ok or not signal then
        return
    end
    Connections[key] = signal:Connect(handler)
end
local function SafeInvoke(remote, skip, ...)
    local args = {...}
    local result = nil
    task.spawn(function()
        local success, res = pcall(function()
            return remote:InvokeServer(unpack(args))
        end)
        result = res
    end)
    if skip then return end
    local start = tick()
    repeat task.wait() until result ~= nil or (tick() - start) > 2
    return result
end
local function fire_event(signal, ...)
    if firesignal then
        return firesignal(signal, ...)
    elseif getconnections then
        local args = {...}
        for _, connection in ipairs(getconnections(signal)) do
            if connection.Fire then
                pcall(function() connection:Fire(unpack(args)) end)
            elseif connection.Function then
                task.spawn(connection.Function, unpack(args))
            end
        end
    else
        warn("Your executor does not support firesignal or getconnections.")
    end
end
local function Cleanup(tbl)
    for key, value in pairs(tbl) do
        if typeof(value) == "RBXScriptConnection" then
            value:Disconnect()
            tbl[key] = nil
        elseif typeof(value) == 'thread' then
            task.cancel(value)
            tbl[key] = nil
        elseif type(value) == 'table' then
            Cleanup(value)
        end
    end
end
function Thread(featurePath, featureFunc, isEnabled, ...)
    local pathParts = featurePath:split(".")
    local currentTable = Flags
    for i = 1, #pathParts - 1 do
        local part = pathParts[i]
        if not currentTable[part] then currentTable[part] = {} end
        currentTable = currentTable[part]
    end
    local flagKey = pathParts[#pathParts]
    local activeThread = currentTable[flagKey]
    if isEnabled then
        if not activeThread or coroutine.status(activeThread) == "dead" then
            currentTable[flagKey] = task.spawn(featureFunc, ...)
        end
    else
        if activeThread and typeof(activeThread) == 'thread' then
            task.cancel(activeThread)
            currentTable[flagKey] = nil
        end
    end
end
local function SafeLoop(name, func)
    return function()
        local success, err = pcall(func)
        if not success then
            Library:Notify("Error in ["..name.."]: "..tostring(err), 10)
            warn("Error in ["..name.."]: "..tostring(err))
        end
    end
end
local function CommaFormat(n)
    local s = tostring(n)
    return s:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end
local function Abbreviate(n)
    local abbrev = {{1e12, "T"}, {1e9, "B"}, {1e6, "M"}, {1e3, "K"}}
    for _, v in ipairs(abbrev) do
        if n >= v[1] then return string.format("%.1f%s", n / v[1], v[2]) end
    end
    return tostring(n)
end
local function GetCharacter()
    local c = Plr.Character
    return (c and c:FindFirstChild("HumanoidRootPart") and c:FindFirstChildOfClass("Humanoid")) and c or nil
end
local function TPTo(target, offset)
    local char = GetCharacter()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end
    local cframe
    if typeof(target) == "CFrame" then
        cframe = target
    elseif typeof(target) == "Vector3" then
        cframe = CFrame.new(target)
    elseif typeof(target) == "Instance" then
        if target:IsA("BasePart") then
            cframe = target.CFrame
        elseif target:IsA("Model") then
            cframe = target:GetPivot()
        end
    end
    if not cframe then return false end
    if offset then
        cframe = cframe * CFrame.new(offset)
    end
    hrp.CFrame = cframe
    return true
end
local function GetNearest(list, filterFn)
    local char = GetCharacter()
    local root = char and char:FindFirstChild("HumanoidRootPart")
    if not root then return nil end
    local best, bestDist = nil, math.huge
    for _, inst in ipairs(list) do
        if not filterFn or filterFn(inst) then
            local part = inst:IsA("BasePart") and inst or (inst:IsA("Model") and inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart"))
            if part then
                local dist = (part.Position - root.Position).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    best = inst
                end
            end
        end
    end
    return best, bestDist
end
local function FuncTPW()
    while true do
        local delta = RunService.Heartbeat:Wait()
        local char = GetCharacter()
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if char and hum and hum.Health > 0 then
            if hum.MoveDirection.Magnitude > 0 then
                local speed = Options.TPWValue.Value
                char:TranslateBy(hum.MoveDirection * speed * delta * 10)
            end
        end
    end
end
local function FuncNoclip()
    while Toggles.Noclip.Value do
        RunService.Stepped:Wait()
        local char = GetCharacter()
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end
local function Func_AntiKnockback()
    if type(Connections.Knockback) == "table" then
        for _, conn in pairs(Connections.Knockback) do
            if conn then conn:Disconnect() end
        end
        table.clear(Connections.Knockback)
    else
        Connections.Knockback = {}
    end
    local function ApplyAntiKB(character)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 10)
        if root then
            local conn = root.ChildAdded:Connect(function(child)
                if not Toggles.AntiKnockback.Value then return end
                if child:IsA("BodyVelocity") and child.MaxForce == Vector3.new(40000, 40000, 40000) then
                    child:Destroy()
                end
            end)
            table.insert(Connections.Knockback, conn)
        end
    end
    if Plr.Character then
        ApplyAntiKB(Plr.Character)
    end
    local charAddedConn = Plr.CharacterAdded:Connect(function(newChar)
        ApplyAntiKB(newChar)
    end)
    table.insert(Connections.Knockback, charAddedConn)
    repeat task.wait(1) until not Toggles.AntiKnockback.Value
    for _, conn in pairs(Connections.Knockback) do
        if conn then conn:Disconnect() end
    end
    table.clear(Connections.Knockback)
end
local function Func_AutoReconnect()
    if Connections.Reconnect then Connections.Reconnect:Disconnect() end
    Connections.Reconnect = GuiService.ErrorMessageChanged:Connect(function()
        if not Toggles.AutoReconnect.Value then return end
        task.delay(2, function()
            local ok, err = pcall(function()
                local promptOverlay = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui")
                if promptOverlay then
                    local errorPrompt = promptOverlay.promptOverlay:FindFirstChild("ErrorPrompt")
                    if errorPrompt and errorPrompt.Visible then
                        local secondaryTimer = 5
                        task.wait(secondaryTimer)
                        TeleportService:Teleport(game.PlaceId, Players.LocalPlayer)
                    end
                end
            end)
            if not ok then
                notyuri("AutoReconnect error:", tostring(err))
            end
        end)
    end)
end
local function Func_NoGameplayPaused()
    while Toggles.NoGameplayPaused.Value do
        local ok, err = pcall(function()
            local pauseGui = game:GetService("CoreGui").RobloxGui:FindFirstChild("CoreScripts/NetworkPause")
            if pauseGui then
                pauseGui:Destroy()
            end
        end)
        if not ok then
            notyuri("NoGameplayPaused error:", tostring(err))
        end
        task.wait(1)
    end
end
local function ApplyFPSBoost(state)
    if not state then return end
    pcall(function()
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 9e9
        Lighting.Brightness = 1
        for _, v in pairs(Lighting:GetChildren()) do
            if v:IsA("PostProcessEffect") or v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("SunRaysEffect") then
                v.Enabled = false
            end
        end
        task.spawn(function()
            for i, v in pairs(workspace:GetDescendants()) do
                if Toggles.FPSBoost and not Toggles.FPSBoost.Value then break end
                pcall(function()
                    if v:IsA("BasePart") then
                        v.Material = Enum.Material.SmoothPlastic
                        v.CastShadow = false
                    elseif v:IsA("Decal") or v:IsA("Texture") then
                        v:Destroy()
                    elseif v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Beam") then
                        v.Enabled = false
                    end
                end)
                if i % 500 == 0 then task.wait() end
            end
        end)
    end)
end
function gsc(guiObject)
    if not guiObject then return false end
    local success = false
    pcall(function()
        if Services.GuiService and Services.VirtualInputManager then
            Services.GuiService.SelectedObject = guiObject
            task.wait(0.05)
            local keys = {Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter, Enum.KeyCode.ButtonA}
            for _, key in ipairs(keys) do
                Services.VirtualInputManager:SendKeyEvent(true, key, false, game); task.wait(0.03)
                Services.VirtualInputManager:SendKeyEvent(false, key, false, game); task.wait(0.03)
            end
            Services.GuiService.SelectedObject = nil
            success = true
        end
    end)
    return success
end
local function FireCD(target)
    if not fireclickdetector then
        return
    end
    if not target or not target:IsA("ClickDetector") then
        return
    end
    fireclickdetector(target)
end
local function FirePP(target, teleport)
    if not fireproximityprompt then return end
    if not target or not target:IsA("ProximityPrompt") then return end
    local prevDist = target.MaxActivationDistance
    if teleport then
        local char = GetCharacter()
        local hrp = char and char:FindFirstChild("HumanoidRootPart")
        local part = target.Parent
        local isModel = false
        if part then
            if part:IsA("Model") then
                isModel = true
            elseif not part:IsA("BasePart") then
                part = target:FindFirstAncestorWhichIsA("BasePart")
                if not part then
                    part = target:FindFirstAncestorWhichIsA("Model")
                    if part then
                        isModel = true
                    end
                end
            end
        end
        if hrp and part then
            local partPos = isModel and part:GetPivot().Position or part.Position
            local dist = (hrp.Position - partPos).Magnitude
            if dist > prevDist then
                local partCFrame = isModel and part:GetPivot() or part.CFrame
                hrp.CFrame = partCFrame * CFrame.new(0, 3, 0)
                task.wait(0.175)
            end
        end
    end
    fireproximityprompt(target)
end
local function FireTI(target)
    if not firetouchinterest then
        return
    end
    local root = Plr.Character and Plr.Character:FindFirstChild("HumanoidRootPart")
    if not root then
        return
    end
    local part
    if target:IsA("BasePart") then
        part = target
    else
        part = target:FindFirstAncestorWhichIsA("BasePart")
    end
    if not part then
        return
    end
    task.spawn(function()
        firetouchinterest(part, root, true)
        task.wait()
        firetouchinterest(part, root, false)
    end)
end
local function Serverhop()
    local hopSuccess, hopErr = pcall(function()
        local baseUrl = 'https://games.roblox.com/v1/games/' .. game.PlaceId .. '/servers/Public?sortOrder=Asc&limit=100'
        local servers = {}
        local cursor = ''
        for _ = 1, 3 do
            local url = baseUrl
            if cursor ~= '' then url = url .. '&cursor=' .. cursor end
            local pages = game:HttpGet(url)
            local data = HttpService:JSONDecode(pages)
            for _, server in ipairs(data.data) do
                if server.playing < server.maxPlayers and server.id ~= game.JobId then
                    table.insert(servers, server)
                end
            end
            cursor = data.nextPageCursor
            if not cursor or cursor == '' then break end
        end
        table.sort(servers, function(a, b) return a.playing < b.playing end)
        if #servers == 0 then
            Library:Notify("No servers found to hop to.", 3)
            return
        end
        local best = servers[1]
        for _, server in ipairs(servers) do
            if server.playing > 0 then
                best = server
                break
            end
        end
        TeleportService:TeleportToPlaceInstance(game.PlaceId, best.id, Players.LocalPlayer)
    end)
    if not hopSuccess then
        Library:Notify("Serverhop failed: " .. tostring(hopErr), 5)
    end
end
local function GetGameInfo()
    return RS:FindFirstChild("GameInfo")
end
local function GetWave()
    local info = GetGameInfo()
    return (info and info:GetAttribute("Wave")) or 0
end
local function GetMaxWave()
    local info = GetGameInfo()
    return (info and info:GetAttribute("MaxWave")) or 0
end
local function GetGold()
    local ok, result = pcall(function()
        local hud = Plr:FindFirstChild("PlayerGui") and Plr.PlayerGui:FindFirstChild("Hud")
        local num = hud and GetObject(hud, "Canvas.Bottom.Gold.Num")
        return num and tonumber(num.Text) or 0
    end)
    return ok and result or 0
end
local function GetMapName()
    local ok, name = pcall(function()
        local sv = workspace:FindFirstChild("ServerValues")
        local map = sv and sv:FindFirstChild("Map")
        local value = map and map.Value
        return value and value.Name or nil
    end)
    return ok and name or nil
end
local function IsGameEnded()
    local gs = _G.GameState
    return (gs and gs.GameEnded) == true
end
local function IsMatchActive()
    return GetWave() > 0 and not IsGameEnded()
end
local function GetPlrCls()
    return _G.PlrCls
end
local function GetUnitManager()
    local pc = GetPlrCls()
    return pc and pc.UnitManager or nil
end
local function GetHotbarUnit(slot)
    local um = GetUnitManager()
    if not um then return nil end
    local ok, result = pcall(function()
        return um:GetUnitDataByHotbar(slot)
    end)
    if ok then return result end
    return nil
end
local function GetUnitInfo(name)
    local um = GetUnitManager()
    if not um then return nil end
    local ok, result = pcall(function()
        return um:GetUnitInfo(name)
    end)
    if ok then return result end
    return nil
end
local function GetUnitStats(unitData, instanceID)
    local um = GetUnitManager()
    if not um then return nil end
    local ok, result = pcall(function()
        return um:GetStats(unitData, instanceID)
    end)
    if ok then return result end
    return nil
end
local function GetOwnUnits()
    local um = GetUnitManager()
    local list = {}
    if not um or type(um.ActiveUnits) ~= "table" then return list end
    for iid, data in pairs(um.ActiveUnits) do
        if type(data) == "table" and data.Owner == Plr.Name and data.UnitData then
            table.insert(list, {
                InstanceID = iid,
                UnitData = data.UnitData,
                Name = data.UnitData.Name,
                Upgrade = data.Upgrade or 0,
                GeneralID = data.GeneralID,
                Model = data.Model,
                Data = data,
            })
        end
    end
    return list
end
local function CountOwnedByID(id)
    local count = 0
    for _, unit in ipairs(GetOwnUnits()) do
        if unit.GeneralID == id then
            count = count + 1
        end
    end
    return count
end
local function GetMaxUpgrade(unitData)
    local info = unitData and GetUnitInfo(unitData.Name)
    return (info and info.Upgrades and #info.Upgrades) or 0
end
local function GetNextUpgradeCost(unitData, instanceID)
    local unit
    for _, own in ipairs(GetOwnUnits()) do
        if own.InstanceID == instanceID then
            unit = own
            break
        end
    end
    local level = unit and unit.Upgrade or 0
    local info = unitData and GetUnitInfo(unitData.Name)
    if not (info and info.Upgrades and info.Upgrades[level + 1]) then return nil end
    local stats = GetUnitStats(unitData, instanceID)
    local mult = stats and stats.UpgradeCostMultiplier or 1
    return math.round(info.Upgrades[level + 1].Cost * mult)
end
local function GetSpawnCap(unitData)
    local stats = GetUnitStats(unitData)
    return (stats and stats.SpawnCap) or 0
end
local function GetDeploymentCost(unitData)
    local stats = GetUnitStats(unitData)
    return (stats and stats.DeploymentCost) or 0
end
local function GetSlotName(slot)
    local data = GetHotbarUnit(slot)
    return data and data.Name or nil
end
local function EnsureFolderPath(path)
    pcall(function()
        local built = ""
        for _, part in ipairs(path:split("/")) do
            built = (built == "") and part or (built .. "/" .. part)
            if not isfolder(built) then
                makefolder(built)
            end
        end
    end)
end
local function ListMacros()
    local names = {}
    if not listfiles then return names end
    local ok, files = pcall(listfiles, Shared.MDir)
    if not ok or type(files) ~= "table" then return names end
    for _, path in ipairs(files) do
        if type(path) == "string" and path:sub(-5):lower() == ".json" then
            local fname = path:match("([^/\\]+)%.json$")
            if fname and fname ~= "" then
                table.insert(names, fname)
            end
        end
    end
    table.sort(names)
    return names
end
local function SaveJSON(path, data)
    return (pcall(function()
        writefile(path, HttpService:JSONEncode(data))
    end))
end
local function LoadJSON(path)
    if not isfile(path) then return nil end
    local ok, raw = pcall(readfile, path)
    if not ok or type(raw) ~= "string" or raw == "" then return nil end
    local data
    pcall(function()
        data = HttpService:JSONDecode(raw)
    end)
    if type(data) ~= "table" then return nil end
    return data
end
local function LoadMacro(name)
    if not name or name == "" or not readfile then return nil end
    local path = Shared.MDir .. "/" .. name .. ".json"
    local data = LoadJSON(path)
    if not data then return nil end
    local entries = {}
    local i = 1
    while data[tostring(i)] do
        entries[i] = data[tostring(i)]
        i = i + 1
    end
    return {entries = entries}
end
local function SaveMacro(name, macro)
    if not name or name == "" or not writefile then return false end
    EnsureFolderPath(Shared.MDir)
    local path = Shared.MDir .. "/" .. name .. ".json"
    local out = {}
    for i, entry in ipairs(macro.entries) do
        out[tostring(i)] = entry
    end
    return SaveJSON(path, out)
end
local function SavePositions()
    if not writefile then return false end
    EnsureFolderPath(Shared.PosDir)
    local out = {}
    for mapName, slots in pairs(Shared.Place.SlotPositions) do
        local slotOut = {}
        for slot, cfs in pairs(slots) do
            local cfOut = {}
            for i, cf in ipairs(cfs) do
                cfOut[i] = {cf:GetComponents()}
            end
            slotOut[tostring(slot)] = cfOut
        end
        out[mapName] = slotOut
    end
    return SaveJSON(Shared.PosPath, out)
end
local function LoadPositions()
    if not readfile or not isfile then return end
    local data = LoadJSON(Shared.PosPath)
    if not data then return end
    local loaded = {}
    for mapName, slots in pairs(data) do
        if type(slots) == "table" then
            loaded[mapName] = {}
            for slotStr, cfs in pairs(slots) do
                local slot = tonumber(slotStr)
                if slot and type(cfs) == "table" then
                    local cfList = {}
                    for i, comp in ipairs(cfs) do
                        if type(comp) == "table" and #comp == 12 then
                            cfList[i] = CFrame.new(unpack(comp))
                        end
                    end
                    loaded[mapName][slot] = cfList
                end
            end
        end
    end
    Shared.Place.SlotPositions = loaded
end
local function GetSlotDisplayNames()
    local names = {}
    for i = 1, 6 do
        local name = GetSlotName(i)
        table.insert(names, "Slot " .. i .. (name and (" - " .. name) or ""))
    end
    return names
end
local function SlotDisplayToNumber(display)
    local num = display and tonumber(string.match(display, "Slot (%d+)"))
    return num or nil
end
local function GetSlotOption(prefix, slot, fallback)
    local opt = Options[prefix .. slot]
    local val = opt and tonumber(opt.Value)
    if val == nil then return fallback end
    return val
end
local function UpdatePosLabels()
    local mapName = GetMapName()
    if not Shared.Labels["Positions"] then return end
    if not mapName then
        SafeLabel("Positions", "No positions set")
        return
    end
    local slotPositions = Shared.Place.SlotPositions[mapName]
    if not slotPositions then
        SafeLabel("Positions", "No positions set")
        return
    end
    local count = 0
    for slot, list in pairs(slotPositions) do
        count = count + #list
    end
    SafeLabel("Positions", mapName .. ": " .. tostring(count) .. " positions")
end
local function GetSlotByUnitName()
    local result = {}
    for i = 1, 6 do
        local name = GetSlotName(i)
        if name then
            result[name] = i
        end
    end
    return result
end
local function GetSelectedUnitSlots()
    local result = {}
    local order = {}
    for i = 1, 6 do
        table.insert(order, i)
    end
    table.sort(order, function(a, b)
        local oa = GetSlotOption("PlaceOrder", a, a)
        local ob = GetSlotOption("PlaceOrder", b, b)
        return oa < ob
    end)
    for _, slot in ipairs(order) do
        local name = GetSlotName(slot)
        if name then
            table.insert(result, {name = name, slot = slot})
        end
    end
    return result
end
local function CFToTable(cf)
    local t = {}
    local x, y, z, r00, r01, r02, r10, r11, r12, r20, r21, r22 = cf:GetComponents()
    for _, v in ipairs({x, y, z, r00, r01, r02, r10, r11, r12, r20, r21, r22}) do
        table.insert(t, v)
    end
    return t
end
local function TableToCF(t)
    if type(t) ~= "table" or #t ~= 12 then return nil end
    return CFrame.new(unpack(t))
end
local function PCubeAcq()
    local part = table.remove(Shared.PCubePool.Free)
    if not part then
        part = Instance.new("Part")
        part.Name = Shared.PlaceCube.PartName
        part.Size = Vector3.new(0.5, 0.5, 0.5)
        part.Anchored = true
        part.CanCollide = false
        part.CastShadow = false
        part.Material = Enum.Material.Neon
    end
    part.Transparency = 0.55
    part.Color = Shared.PlaceCube.Pending
    part.Parent = workspace
    Shared.PCubePool.Active[part] = true
    return part
end
local function PCubeRelease(part)
    if part then
        if not Shared.PCubePool.Active[part] then return end
        Shared.PCubePool.Active[part] = nil
        part.Parent = nil
        table.insert(Shared.PCubePool.Free, part)
    else
        for p in pairs(Shared.PCubePool.Active) do
            Shared.PCubePool.Active[p] = nil
            p.Parent = nil
            table.insert(Shared.PCubePool.Free, p)
        end
    end
end
local function GetPlacementParts()
    local ok, parts = pcall(function()
        local sv = workspace:FindFirstChild("ServerValues")
        local map = sv and sv:FindFirstChild("Map")
        local value = map and map.Value
        local boundaries = value and value:FindFirstChild("Boundaries")
        if not boundaries then return nil end
        local list = {}
        for _, part in ipairs(boundaries:GetDescendants()) do
            if part:IsA("BasePart") and part.Name ~= "Barrier" and not (part.Parent and part.Parent.Name == "Barrier") then
                table.insert(list, part)
            end
        end
        table.sort(list, function(a, b)
            return (a.Size.X * a.Size.Z) > (b.Size.X * b.Size.Z)
        end
        )
        return #list > 0 and list or nil
    end)
    return ok and parts or nil
end
local function GetUnitYOffset(model)
    local hip = 0
    local legY = 2
    local humanoid = model and model:FindFirstChildOfClass("Humanoid")
    if humanoid then hip = humanoid.HipHeight end
    local hrp = model and (model.PrimaryPart or model:FindFirstChild("HumanoidRootPart"))
    if hrp then legY = hrp.Size.Y / 2 end
    return hip, legY
end
local function TryCandidateSpot(part, x, z, hip, legY)
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Include
    params.FilterDescendantsInstances = {part}
    local origin = Vector3.new(x, part.Position.Y + 60, z)
    local result = workspace:Raycast(origin, Vector3.new(0, -200, 0), params)
    if not result then return nil end
    if result.Instance.Name ~= "Part" then return nil end
    local y = result.Position.Y + hip + legY
    return CFrame.new(x, y, z)
end
local function GetSpotForUnit(model)
    local spacing = 3
    local key = tostring(spacing)
    local cache = Shared.Place.GridCache
    local alive = cache and cache[1] and cache[1].Part and cache[1].Part.Parent ~= nil
    if Shared.Place.GridKey ~= key or not alive then
        local parts = GetPlacementParts()
        if not parts then return nil end
        local grid = {}
        for _, part in ipairs(parts) do
            local halfX, halfZ = part.Size.X / 2, part.Size.Z / 2
            local minX = part.Position.X - halfX + (spacing / 2)
            local maxX = part.Position.X + halfX - (spacing / 2)
            local minZ = part.Position.Z - halfZ + (spacing / 2)
            local maxZ = part.Position.Z + halfZ - (spacing / 2)
            local x = minX
            while x <= maxX do
                local z = minZ
                while z <= maxZ do
                    table.insert(grid, {Part = part, X = x, Z = z})
                    z = z + spacing
                end
                x = x + spacing
            end
        end
        Shared.Place.GridCache = grid
        Shared.Place.GridKey = key
        cache = grid
    end
    if not cache then return nil end
    local now = tick()
    for pos, expiry in pairs(Shared.Place.FailPos) do
        if expiry < now then
            Shared.Place.FailPos[pos] = nil
        end
    end
    local hip, legY = GetUnitYOffset(model)
    for _, spot in ipairs(cache) do
        local posKey = string.format("%.1f,%.1f", spot.X, spot.Z)
        if not Shared.Place.FailPos[posKey] then
            local cf = TryCandidateSpot(spot.Part, spot.X, spot.Z, hip, legY)
            if cf then
                return cf, posKey
            end
        end
    end
    return nil
end
local function SpiralNext(spacing)
    local center = Shared.Place.SpiralCenter
    if not center then
        local parts = GetPlacementParts()
        if not parts or not parts[1] then return nil end
        center = parts[1].Position
        Shared.Place.SpiralCenter = center
    end
    local cursor = Shared.Place.SpiralCursor
    Shared.Place.SpiralCursor = cursor + 1
    if cursor == 0 then
        return Vector3.new(center.X, center.Y, center.Z)
    end
    local st = Shared.Place.Spiral
    st.x = st.x + st.dx
    st.z = st.z + st.dz
    local result = Vector3.new(center.X + st.x * spacing, center.Y, center.Z + st.z * spacing)
    st.stepped = st.stepped + 1
    if st.stepped >= st.segLen then
        st.stepped = 0
        st.dx, st.dz = -st.dz, st.dx
        st.turns = st.turns + 1
        if st.turns % 2 == 0 then
            st.segLen = st.segLen + 1
        end
    end
    return result
end
local function GetSpotForUnitSpiral(model)
    if not Shared.Place.Spiral then
        Shared.Place.SpiralCursor = 0
        Shared.Place.SpiralCenter = nil
        Shared.Place.Spiral = {x = 0, z = 0, dx = 1, dz = 0, segLen = 1, stepped = 0, turns = 0}
        Shared.Place.SpiralFailMemo = {}
    end
    local hip, legY = GetUnitYOffset(model)
    local spacing = 3
    for _ = 1, 40 do
        local candidate = SpiralNext(spacing)
        if not candidate then return nil end
        local key = string.format("%.1f_%.1f", candidate.X, candidate.Z)
        local memo = Shared.Place.SpiralFailMemo[key]
        local blocked = memo and (tick() - memo) <= 30
        if not blocked then
            local parts = GetPlacementParts()
            local part = parts and parts[1]
            if not part then return nil end
            local cf = TryCandidateSpot(part, candidate.X, candidate.Z, hip, legY)
            if cf then
                return cf, key
            end
            Shared.Place.SpiralFailMemo[key] = tick()
        end
    end
    return nil
end
local function UpdateMacroLabel(suffix, elapsed, nextEntry)
    local txt = "Idle"
    if Shared.MState.Rec then
        txt = string.format("Recording [%d]", Shared.MState.Step)
        if suffix then
            txt = txt .. " " .. tostring(suffix)
        end
    elseif Shared.MState.Rep then
        txt = string.format("Replaying [%d / %d]", Shared.MState.Step, Shared.MState.Total)
    end
    if Shared.Labels["Macro"] then
        SafeLabel("Macro", txt)
    end
end
local function SortMacroEntries(entries)
    table.sort(entries, function(a, b)
        if a.Wave ~= b.Wave then
            return a.Wave < b.Wave
        end
        return (a.Time or 0) < (b.Time or 0)
    end)
end
local OrigRemotes = {}
local function ResolveOrigRemotes()
    pcall(function()
        local origRS = game:GetService("ReplicatedStorage")
        local events = origRS:FindFirstChild("RemoteEvents")
        local server = events and events:FindFirstChild("Server")
        local gu = server and server:FindFirstChild("GameUnit")
        if gu and not OrigRemotes.GameUnit then
            OrigRemotes.GameUnit = gu
        end
    end)
end
local function IsGameUnitRemote(self)
    if OrigRemotes.GameUnit and rawequal(self, OrigRemotes.GameUnit) then return true end
    if Remotes.GameUnit and rawequal(self, Remotes.GameUnit) then return true end
    return false
end
local function NameOfInstance(iid)
    local um = GetUnitManager()
    local data = um and type(um.ActiveUnits) == "table" and um.ActiveUnits[iid]
    return data and data.UnitData and data.UnitData.Name or nil
end
local function PosOfInstance(iid)
    local um = GetUnitManager()
    local data = um and type(um.ActiveUnits) == "table" and um.ActiveUnits[iid]
    local model = data and data.Model
    local pp = model and (model.PrimaryPart or model:FindFirstChild("HumanoidRootPart"))
    if pp then
        return CFToTable(pp.CFrame)
    end
    return nil
end
local function CaptureMacro(args, ret)
    if not (Shared.MState.Rec and Shared.MState.Cur) then return end
    local cmd = args[1]
    if not table.find(Shared.UAXCmds, cmd) then return end
    local entry = {Type = cmd, Wave = GetWave(), Time = math.max(0, tick() - Shared.WaveStartAt)}
    if cmd == "RequestPlace" then
        entry.ID = args[2]
        if typeof(args[3]) == "CFrame" then
            entry.CF = CFToTable(args[3])
        end
        local res = ret[1]
        if type(res) == "table" and type(res.ServerData) == "table" then
            entry.Key = res.ServerData.InstanceID
        end
    else
        entry.Key = args[2]
        if cmd == "ChangePriority" then
            entry.Mode = args[3]
        elseif cmd == "UseActive" then
            entry.Active = args[3]
            if typeof(args[4]) == "CFrame" then
                entry.CF = CFToTable(args[4])
            end
        end
    end
    if entry.Key then
        entry.Name = NameOfInstance(entry.Key)
        entry.Pos = PosOfInstance(entry.Key)
    end
    table.insert(Shared.MState.Cur.entries, entry)
    Shared.MState.Step = Shared.MState.Step + 1
    UpdateMacroLabel(cmd)
end
local function InstallMacroHook()
    if Shared.MState.Hooked then return end
    if not Support.HookMeta then
        Library:Notify("Macro record requires hookmetamethod support", 4)
        return
    end
    ResolveOrigRemotes()
    Shared.MState.Hooked = true
    local cc = (typeof(newcclosure) == "function") and newcclosure or (function(f) return f end)
    local checkCaller = typeof(checkcaller) == "function" and checkcaller or (typeof(iscaller) == "function" and iscaller or nil)
    local originalNamecall
    originalNamecall = hookmetamethod(game, "__namecall", cc(function(...)
        local self = ...
        local method = getnamecallmethod()
        local ret = table.pack(originalNamecall(...))
        if method == "InvokeServer" and Shared.MState.Rec
            and not Shared.SelfThreads[coroutine.running() or false]
            and not (checkCaller and checkCaller())
            and IsGameUnitRemote(self) then
            local nargs = table.pack(select(2, ...))
            if nargs.n >= 1 and type(nargs[1]) == "string" then
                local ok, err = pcall(CaptureMacro, nargs, ret)
                if not ok then
                    notyuri("capture error:", tostring(err))
                end
            end
        end
        return table.unpack(ret, 1, ret.n)
    end))
    notyuri("hook active; orig remote refs resolved:", tostring(OrigRemotes.GameUnit ~= nil))
end
local function FindUnitForEntry(entry)
    local um = GetUnitManager()
    if not (um and type(um.ActiveUnits) == "table") then return nil end
    if entry.Key then
        local data = um.ActiveUnits[entry.Key]
        local model = data and data.Model
        if model and model.Parent then
            return data
        end
    end
    local pos = entry.Pos and TableToCF(entry.Pos)
    if not pos then return nil end
    local base = entry.Name
    if type(base) ~= "string" or base == "" then return nil end
    local best, bestDist = nil, 6
    for _, unit in ipairs(GetOwnUnits()) do
        local pp = unit.Model and (unit.Model.PrimaryPart or unit.Model:FindFirstChild("HumanoidRootPart"))
        if pp and unit.Name == base then
            local dist = (pp.Position - pos.Position).Magnitude
            if dist < bestDist then
                best, bestDist = unit, dist
            end
        end
    end
    if best then
        notyuri("position fallback resolved", tostring(entry.Name), string.format("(%.1f studs)", bestDist))
    end
    return best and best.Data or nil
end
local function ResolveUnitRetry(entry)
    local unit = FindUnitForEntry(entry)
    if unit and unit.Model and unit.Model.Parent then return unit end
    local start = tick()
    while (Toggles.LoadMacro.Value) and (tick() - start) < 1 do
        task.wait()
        unit = FindUnitForEntry(entry)
        if unit and unit.Model and unit.Model.Parent then return unit end
    end
    return nil
end
local function GetEntryCost(entry)
    if entry.Type == "RequestPlace" then
        local data = GetHotbarUnit(1)
        local info = entry.Name and GetUnitInfo(entry.Name)
        if info and info.BaseStats then
            return info.BaseStats.DeploymentCost or 0
        end
        return nil
    elseif entry.Type == "UpgradeUnit" then
        local um = GetUnitManager()
        local data = entry.Key and um and um.ActiveUnits[entry.Key]
        if data and data.UnitData then
            return GetNextUpgradeCost(data.UnitData, entry.Key)
        end
        return nil
    end
    return nil
end
local function WaitForGold(amount, timeout)
    if not amount or amount <= 0 then return true end
    if GetGold() >= amount then return true end
    local start = tick()
    local startMap = GetMapName()
    while Toggles.LoadMacro.Value and GetGold() < amount do
        if timeout and (tick() - start) >= timeout then
            break
        end
        if GetMapName() ~= startMap then
            break
        end
        task.wait()
    end
    return Toggles.LoadMacro.Value and GetGold() >= amount
end
local function DoMacroAction(entry)
    if entry.Type == "RequestPlace" then
        local cf = TableToCF(entry.CF)
        if not cf then return end
        if entry.ID == nil then return end
        local result
        for attempt = 1, Shared.MacroTimings.MaxAttempts do
            if not Toggles.LoadMacro.Value then break end
            result = SafeInvoke(Remotes.GameUnit, false, "RequestPlace", entry.ID, cf)
            if type(result) == "table" and result.Success then break end
            if attempt < Shared.MacroTimings.MaxAttempts then
                local cost = GetEntryCost(entry)
                if not WaitForGold(cost, 5) then break end
            end
        end
        if not (type(result) == "table" and result.Success) then
            notyuri("Place SKIP: server rejected", tostring(entry.Name))
        end
    elseif entry.Type == "UpgradeUnit" then
        local unit = ResolveUnitRetry(entry)
        if not unit then
            notyuri("Upgrade SKIP: no unit resolved", tostring(entry.Name))
            return
        end
        local cost = GetEntryCost(entry)
        local result
        for attempt = 1, Shared.MacroTimings.MaxAttempts do
            if not Toggles.LoadMacro.Value then break end
            result = SafeInvoke(Remotes.GameUnit, false, "UpgradeUnit", unit.InstanceID)
            if result == true then break end
            if attempt < Shared.MacroTimings.MaxAttempts then
                if not WaitForGold(cost, 5) then break end
            end
        end
        if result ~= true then
            notyuri("Upgrade SKIP: server rejected", tostring(entry.Name))
        end
    elseif entry.Type == "SellUnit" then
        local unit = ResolveUnitRetry(entry)
        if not unit then
            notyuri("Sell SKIP: no unit resolved", tostring(entry.Name))
            return
        end
        SafeInvoke(Remotes.GameUnit, true, "SellUnit", unit.InstanceID)
    elseif entry.Type == "ChangePriority" then
        local unit = ResolveUnitRetry(entry)
        if not unit then return end
        SafeInvoke(Remotes.GameUnit, true, "ChangePriority", unit.InstanceID, entry.Mode)
    elseif entry.Type == "UseActive" then
        local unit = ResolveUnitRetry(entry)
        if not unit then return end
        local cf = entry.CF and TableToCF(entry.CF)
        if cf then
            SafeInvoke(Remotes.GameUnit, true, "UseActive", unit.InstanceID, entry.Active, cf)
        else
            SafeInvoke(Remotes.GameUnit, true, "UseActive", unit.InstanceID, entry.Active)
        end
    end
end
local function Func_MacroRecord(state)
    if not state then
        if Shared.MState.Rec then
            Shared.MState.Rec = false
        end
        return
    end
    if Toggles.LoadMacro and Toggles.LoadMacro.Value then
        Toggles.LoadMacro:SetValue(false)
    end
    InstallMacroHook()
    Shared.MState.Cur = {entries = {}}
    Shared.MState.Step = 0
    Shared.MState.Saved = false
    UpdateMacroLabel("Waiting")
    notyuri("waiting for match to start")
    while Toggles.MacroRecord.Value and not IsMatchActive() do
        task.wait()
    end
    if not Toggles.MacroRecord.Value then
        Shared.MState.Cur = nil
        Shared.MState.Step = 0
        UpdateMacroLabel()
        return
    end
    Shared.MState.Rec = true
    UpdateMacroLabel()
    notyuri("recording started")
    while Toggles.MacroRecord.Value and IsMatchActive() do
        task.wait()
    end
    Shared.MState.Rec = false
    task.wait()
    local entries = Shared.MState.Cur and #Shared.MState.Cur.entries or 0
    notyuri("recording stopped,", tostring(entries), "actions")
    if entries > 0 and not Shared.MState.Saved then
        Shared.MState.Saved = true
        SortMacroEntries(Shared.MState.Cur.entries)
        local recorded = Shared.MState.Cur
        local fname = (Options.FileName and Options.FileName.Value) or ""
        if fname == "" then
            fname = "Macro_" .. os.date("%Y%m%d_%H%M%S")
        end
        task.spawn(function()
            local ok = SaveMacro(fname, recorded)
            if ok then
                Library:Notify("Macro saved: " .. fname, 4)
                if Options.MacroSelected then
                    Options.MacroSelected:SetValues(ListMacros())
                end
            else
                Library:Notify("Failed to save macro (writefile unsupported?)", 4)
            end
        end)
    end
    Shared.MState.Cur = nil
    Shared.MState.Step = 0
    UpdateMacroLabel()
end
local function Func_MacroReplay()
    while Toggles.LoadMacro.Value do
        local macro = Shared.MState.Load
        if not macro or not macro.entries or #macro.entries == 0 then
            Toggles.LoadMacro:SetValue(false)
            Library:Notify("No macro loaded", 3)
            return
        end
        Shared.MState.Rep = true
        Shared.MState.Step = 0
        Shared.MState.RepMap = {}
        Shared.MState.Total = #macro.entries
        SortMacroEntries(macro.entries)
        UpdateMacroLabel()
        while Toggles.LoadMacro.Value and not IsMatchActive() do
            task.wait()
        end
        if not Toggles.LoadMacro.Value then break end
        local startMap = GetMapName()
        for i, entry in ipairs(macro.entries) do
            if not Toggles.LoadMacro.Value then break end
            if not IsMatchActive() then
                notyuri("match ended mid-pass, aborting pass")
                break
            end
            Shared.MState.Step = i
            UpdateMacroLabel(entry.Type)
            local replayMode = Options.ReplayMode and Options.ReplayMode.Value or "Time"
            local skipStep = false
            if replayMode == "Money" then
                local cost = GetEntryCost(entry)
                if cost and cost > 0 then
                    if not WaitForGold(cost) then
                        notyuri("gold wait aborted (toggle off or map changed)")
                    end
                end
                if Toggles.LoadMacro.Value and GetMapName() ~= startMap then
                    notyuri("map changed during gold wait, aborting pass")
                    break
                end
            else
                local tWave = entry.Wave or 0
                local tElapsed = entry.Time or 0
                while Toggles.LoadMacro.Value and GetWave() < tWave do
                    if not IsMatchActive() then break end
                    task.wait()
                end
                if not Toggles.LoadMacro.Value then break end
                if GetWave() > tWave then
                    skipStep = true
                else
                    local diff = (tick() - Shared.WaveStartAt) - tElapsed
                    if diff > 0 then
                        while Toggles.LoadMacro.Value and IsMatchActive() and (tick() - Shared.WaveStartAt) < tElapsed do
                            task.wait()
                        end
                    end
                end
            end
            if not Toggles.LoadMacro.Value then break end
            if not skipStep then
                local ok, err = pcall(DoMacroAction, entry)
                if not ok then
                    notyuri("action failed:", tostring(err))
                end
                task.wait(0)
            else
                UpdateMacroLabel("skipped")
                notyuri("skipped stale entry", entry.Type, tostring(entry.Time))
            end
        end
        Shared.MState.Rep = false
        Shared.MState.Step = 0
        UpdateMacroLabel("Finished")
        if Toggles.LoadMacro.Value then
            UpdateMacroLabel("Waiting")
            while Toggles.LoadMacro.Value and IsMatchActive() and GetMapName() == startMap do
                task.wait()
            end
            while Toggles.LoadMacro.Value and not IsMatchActive() do
                task.wait()
            end
        end
    end
    Shared.MState.Rep = false
    UpdateMacroLabel()
end
local function TryPlaceUnit(slot)
    local unitData = GetHotbarUnit(slot)
    if not unitData then return false end
    local name = unitData.Name
    if not name then return false end
    local placeWave = GetSlotOption("PlaceWave", slot, 0)
    if placeWave > 0 and GetWave() < placeWave then return false end
    local slotLimit = GetSlotOption("PlaceLimit", slot, 0)
    if slotLimit > 0 and CountOwnedByID(unitData.ID) >= slotLimit then return false end
    local stats = GetUnitStats(unitData)
    if not stats then return false end
    local spawnCap = stats.SpawnCap or 0
    if spawnCap > 0 and CountOwnedByID(unitData.ID) >= spawnCap then return false end
    local cost = stats.DeploymentCost or 0
    if cost > 0 and GetGold() < cost then return false end
    if (Shared.Place.PauseUntil[name] or 0) > tick() then return false end
    local mapName = GetMapName()
    local savedList = mapName and Shared.Place.SlotPositions[mapName] and Shared.Place.SlotPositions[mapName][slot]
    local cf, posKey, fromSaved
    if savedList and #savedList > 0 then
        cf = savedList[math.random(1, #savedList)]
        fromSaved = true
    else
        cf, posKey = GetSpotForUnit(nil)
        if not cf then
            cf, posKey = GetSpotForUnitSpiral(nil)
        end
    end
    if not cf then return false end
    local ghost = PCubeAcq()
    ghost.CFrame = cf
    local result = SafeInvoke(Remotes.GameUnit, false, "RequestPlace", unitData.ID, cf)
    if type(result) == "table" and result.Success then
        ghost.Color = Shared.PlaceCube.Success
        Shared.Place.TypeFails[name] = 0
        PCubeRelease(ghost)
        return true
    end
    ghost.Color = Shared.PlaceCube.Fail
    PCubeRelease(ghost)
    if posKey and not fromSaved then
        Shared.Place.FailPos[posKey] = tick() + 30
        if Shared.Place.SpiralFailMemo and posKey:find("_") then
            Shared.Place.SpiralFailMemo[posKey] = tick()
        end
    end
    Shared.Place.TypeFails[name] = (Shared.Place.TypeFails[name] or 0) + 1
    if Shared.Place.TypeFails[name] >= 3 then
        Shared.Place.PauseUntil[name] = tick() + 10
        Shared.Place.TypeFails[name] = 0
        notyuri("3 rejects for", name, "- pausing 10s")
    end
    return false
end
local function Func_AutoPlace()
    while Toggles.AutoPlace.Value do
        local ok, err = pcall(function()
            if not (Remotes.GameUnit and IsMatchActive()) then return end
            for _, entry in ipairs(GetSelectedUnitSlots()) do
                if not Toggles.AutoPlace.Value then return end
                local placed = TryPlaceUnit(entry.slot)
                if placed then
                    notyuri("Placed", entry.name, "slot", tostring(entry.slot))
                    if Toggles.PlaceAndUpgrade and Toggles.PlaceAndUpgrade.Value then
                        local upgLimit = GetSlotOption("UpgradeLimit", entry.slot, 0)
                        local unitData = GetHotbarUnit(entry.slot)
                        if unitData then
                            for _ = 1, 20 do
                                if not Toggles.PlaceAndUpgrade.Value then break end
                                local target
                                for _, unit in ipairs(GetOwnUnits()) do
                                    if unit.GeneralID == unitData.ID then
                                        target = unit
                                        break
                                    end
                                end
                                if not target then break end
                                local maxUpg = GetMaxUpgrade(unitData)
                                if upgLimit > 0 and target.Upgrade >= upgLimit then break end
                                if maxUpg > 0 and target.Upgrade >= maxUpg then break end
                                local nextCost = GetNextUpgradeCost(unitData, target.InstanceID)
                                if not (nextCost and nextCost <= GetGold()) then break end
                                local result = SafeInvoke(Remotes.GameUnit, false, "UpgradeUnit", target.InstanceID)
                                if result ~= true then break end
                                task.wait()
                            end
                        end
                    end
                end
                task.wait()
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
end
local function GetUpgradableUnits()
    local slotByName = GetSlotByUnitName()
    local result = {}
    for _, unit in ipairs(GetOwnUnits()) do
        local slot = slotByName[unit.Name]
        local upgLimit = slot and GetSlotOption("UpgradeLimit", slot, 0) or 0
        local maxUpg = GetMaxUpgrade(unit.UnitData)
        if maxUpg > 0 and unit.Upgrade < maxUpg then
            if upgLimit <= 0 or unit.Upgrade < upgLimit then
                local price = GetNextUpgradeCost(unit.UnitData, unit.InstanceID)
                if price then
                    table.insert(result, {
                        unit = unit,
                        slot = slot,
                        level = unit.Upgrade,
                        name = unit.Name,
                        price = price,
                    })
                end
            end
        end
    end
    return result
end
local function UpgradeTarget(units)
    local method = Options.UpgradeMethod and Options.UpgradeMethod.Value or "Lowest Level (Spread Upgrade)"
    if #units == 0 then return nil end
    if Toggles.FocusFarm and Toggles.FocusFarm.Value then
        local farms = {}
        for _, e in ipairs(units) do
            local info = GetUnitInfo(e.name)
            if info and info.BaseStats and (info.BaseStats.Gold or 0) > 0 then
                table.insert(farms, e)
            end
        end
        if #farms > 0 then units = farms end
    end
    if method == "Randomize" then
        return units[math.random(1, #units)]
    elseif method == "Hotbar left to right (until Max)" or method == "Customize upgrade order (Set below)" then
        table.sort(units, function(a, b)
            local sa = a.slot and GetSlotOption("PlaceOrder", a.slot, a.slot) or 99
            local sb = b.slot and GetSlotOption("PlaceOrder", b.slot, b.slot) or 99
            if sa ~= sb then return sa < sb end
            return a.level < b.level
        end)
        return units[1]
    end
    table.sort(units, function(a, b) return a.level < b.level end)
    return units[1]
end
local function Func_AutoUpgrade()
    while Toggles.AutoUpgrade.Value do
        local ok, err = pcall(function()
            if not (Remotes.GameUnit and IsMatchActive()) then return end
            local units = GetUpgradableUnits()
            local target = UpgradeTarget(units)
            if not target then return end
            if GetGold() < target.price then return end
            local result = SafeInvoke(Remotes.GameUnit, false, "UpgradeUnit", target.unit.InstanceID)
            if result == true then
                notyuri("Upgraded", target.name, "slot", tostring(target.slot))
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
end
local function GetUnitActives(unit)
    local um = GetUnitManager()
    if not um then return nil end
    local info = GetUnitInfo(unit.Name)
    if not info then return nil end
    local ok, actives = pcall(function()
        return um:GetActives(unit.Data, info)
    end)
    if ok and type(actives) == "table" then return actives end
    return nil
end
local function IsGlobalActiveReady(activeName)
    local gs = _G.GameState
    if not (gs and type(gs.GlobalActiveCDs) == "table") then return true end
    local cd = gs.GlobalActiveCDs[activeName]
    if not cd then return true end
    return not ((cd.Cooldown or 0) - (os.time() - (cd.BeganAt or 0)) > 0)
end
local function IsUnitActiveReady(unit, activeName)
    local info = unit.Data and unit.Data.ActiveCooldownInfo
    local cd = info and info[activeName]
    if not cd then return true end
    return (workspace:GetServerTimeNow() - (cd.BeganAt or 0)) >= (cd.Cooldown or 0)
end
local function GetActiveInfo(activeName)
    local managers = GetObject(RS, "ModuleScripts.Managers")
    local getter = managers and GetSafeModule(managers, "ActiveSkillGetter")
    if not getter then return nil end
    local ok, result = pcall(function()
        return getter:GetActiveInfo(activeName)
    end)
    if ok then return result end
    return nil
end
local function Func_AutoAbility()
    while Toggles.AutoAbility.Value do
        local ok, err = pcall(function()
            if not (Remotes.GameUnit and IsMatchActive()) then return end
            for _, unit in ipairs(GetOwnUnits()) do
                if not Toggles.AutoAbility.Value then break end
                local actives = GetUnitActives(unit)
                if actives then
                    for _, active in ipairs(actives) do
                        if not Toggles.AutoAbility.Value then break end
                        local activeName = active and active.Name
                        if type(activeName) == "string" and activeName ~= "" then
                            if IsUnitActiveReady(unit, activeName) and IsGlobalActiveReady(activeName) then
                                local last = Shared.Memo.AbilityAt[unit.InstanceID .. activeName] or 0
                                if tick() - last > 1 then
                                    Shared.Memo.AbilityAt[unit.InstanceID .. activeName] = tick()
                                    local aInfo = GetActiveInfo(activeName)
                                    if aInfo and aInfo.RequiresLocationPick then
                                        local pp = unit.Model and (unit.Model.PrimaryPart or unit.Model:FindFirstChild("HumanoidRootPart"))
                                        if pp then
                                            SafeInvoke(Remotes.GameUnit, true, "UseActive", unit.InstanceID, activeName, CFrame.new(pp.Position))
                                        end
                                    else
                                        SafeInvoke(Remotes.GameUnit, true, "UseActive", unit.InstanceID, activeName)
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(1)
    end
end
local function Func_AutoSkip()
    while Toggles.AutoSkip.Value do
        local ok, err = pcall(function()
            if not (Remotes.VoteSkip and IsMatchActive()) then return end
            local voteFrame = Plr:FindFirstChild("PlayerGui")
                and GetObject(Plr.PlayerGui, "Hud.Canvas.VoteSkip")
            if voteFrame and voteFrame.Visible then
                if not Shared.Memo.SkipVoted then
                    Shared.Memo.SkipVoted = true
                    FireRemote(Remotes.VoteSkip)
                    notyuri("skip vote fired")
                end
            else
                Shared.Memo.SkipVoted = false
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(0.5)
    end
end
local function Func_AutoReady()
    while Toggles.AutoReady.Value do
        local ok, err = pcall(function()
            if not (Remotes.ReadyUp and IsMatchActive()) then return end
            local readyFrame = Plr:FindFirstChild("PlayerGui")
                and GetObject(Plr.PlayerGui, "Hud.Canvas.ReadyUp")
            if readyFrame and readyFrame.Visible then
                if not Shared.Memo.ReadyFired then
                    Shared.Memo.ReadyFired = true
                    FireRemote(Remotes.ReadyUp)
                    notyuri("ready up fired")
                end
            else
                Shared.Memo.ReadyFired = false
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(0.5)
    end
end
local function Func_AutoAtWave(toggle, thresholdOption, action)
    while toggle.Value do
        local ok, err = pcall(function()
            if not IsMatchActive() then return end
            local threshold = tonumber(thresholdOption and thresholdOption.Value) or 0
            local wave = GetWave()
            if wave >= threshold and threshold > 0 then
                if action == "sell" then
                    if Remotes.GameUnit then
                        for _, unit in ipairs(GetOwnUnits()) do
                            SafeInvoke(Remotes.GameUnit, true, "SellUnit", unit.InstanceID)
                        end
                        notyuri("AutoSell", "sold all units", "wave", tostring(wave))
                    end
                elseif action == "leave" then
                    if Remotes.Return then
                        FireRemote(Remotes.Return)
                        notyuri("AutoLeave", "leave sent", "wave", tostring(wave))
                    end
                end
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait()
    end
end
local function SendWebhook(title, description)
    if not request then return end
    local img = yuri[math.random(1, #yuri)]
    pcall(function()
        request({
            Url = Options.WebhookURL.Value,
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = HttpService:JSONEncode({
                username = "Yuri",
                avatar_url = img,
                embeds = {
                    {
                        title = title,
                        description = description,
                    }
                },
            }),
        })
    end)
end
local function Func_MatchEnd()
    while true do
        if _G.GameState and _G.GameState.GameEnded then
            if not Shared.Memo.EndNotified then
                Shared.Memo.EndNotified = true
                if Toggles.WHMatchEnd and Toggles.WHMatchEnd.Value and Options.WebhookURL.Value ~= "" then
                    SendWebhook("Match Finished", "Map: " .. tostring(GetMapName())
                        .. " | Wave: " .. tostring(GetWave()) .. "/" .. tostring(GetMaxWave()))
                end
            end
            if Toggles.AutoReplay and Toggles.AutoReplay.Value and Remotes.VoteRetry then
                FireRemote(Remotes.VoteRetry)
            end
            if Toggles.AutoNewMap and Toggles.AutoNewMap.Value and Remotes.VoteNext then
                FireRemote(Remotes.VoteNext)
            end
            task.wait(10)
        else
            if Shared.Memo.EndNotified then
                Shared.Memo.EndNotified = false
            end
            task.wait(0.5)
        end
    end
end
local function GetBannerNames()
    local names = {}
    local info = GetObject(RS, "ModuleScripts.Information")
    local banners = info and GetSafeModule(info, "Banners")
    if type(banners) == "table" then
        for name in pairs(banners) do
            if type(name) == "string" then
                table.insert(names, name)
            end
        end
    end
    table.sort(names)
    return #names > 0 and names or { "Loading..." }
end
local function GetSummonChannel()
    local services = GetObject(RS, "ModuleScripts.Services")
    local sp = services and GetSafeModule(services, "ServiceProviderPlus")
    if not (sp and sp.Network) then return nil end
    local ok, channel = pcall(function()
        return sp.Network:GetChannel("Summon")
    end)
    if ok then return channel end
    return nil
end
local function Func_AutoSummon()
    while Toggles.AutoSummon.Value do
        local ok, err = pcall(function()
            local channel = GetSummonChannel()
            if not channel then return end
            local invoke = channel:Invoke("RequestSummon")
            if not invoke then return end
            local banner = Options.SummonBanner and Options.SummonBanner.Value or ""
            if banner == "" or banner == "Loading..." then return end
            local amount = tonumber(Options.SummonAmount and Options.SummonAmount.Value) or 1
            local info = GetObject(RS, "ModuleScripts.Information")
            local banners = info and GetSafeModule(info, "Banners")
            local bannerData = banners and type(banners[banner]) == "table" and banners[banner]
            if not bannerData then return end
            local pc = GetPlrCls()
            local souls = pc and pc:Get("Souls") or 0
            local price = bannerData.Prices and bannerData.Prices[tostring(amount)]
            if price and souls < price then return end
            invoke:CallServerAsync(function(success, result)
                if success and typeof(result) ~= "boolean" then
                    Shared.Memo.SummonFails = 0
                else
                    Shared.Memo.SummonFails = (Shared.Memo.SummonFails or 0) + 1
                    notyuri("summon failed", tostring(result))
                end
            end, { Banner = banner, Amount = amount, AutosellSettings = {} })
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(Toggles.FastSummon and Toggles.FastSummon.Value and 0.5 or 2)
    end
end
local function GetStoryMapNames()
    local names = {}
    local folder = GetObject(RS, "ModuleScripts.GameplayPackages.StoryModeMaps")
    if not folder then return names end
    for _, child in ipairs(folder:GetChildren()) do
        if child:IsA("ModuleScript") then
            table.insert(names, child.Name)
        end
    end
    table.sort(names)
    return names
end
local function Func_AutoQueue()
    while Toggles.AutoQueue.Value do
        local ok, err = pcall(function()
            if not (Remotes.CreateParty and Remotes.SendPartyPackage and Remotes.BeginParty) then return end
            local info = GetGameInfo()
            if info then return end
            local map = Options.QueueMap and Options.QueueMap.Value or ""
            if map == "" then return end
            local act = tonumber(Options.QueueAct and Options.QueueAct.Value) or 1
            FireRemote(Remotes.CreateParty, "StoryMode", nil)
            task.wait(1)
            local result = SafeInvoke(Remotes.SendPartyPackage, false, "StoryMode", {
                Map = map,
                Act = act,
                Difficulty = "Neutral",
            })
            if result then
                task.wait(0.5)
                FireRemote(Remotes.BeginParty)
                notyuri("queue started", map, "act", tostring(act))
                task.wait(10)
            else
                task.wait(3)
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(2)
    end
end
local function Func_AutoCollectQuests()
    local claimed = {}
    while Toggles.AutoCollectQuests.Value do
        local ok, err = pcall(function()
            if not Remotes.QuestContact then return end
            local info = GetObject(RS, "ModuleScripts.Information")
            local questTypes = info and GetSafeModule(info, "QuestTypes")
            if type(questTypes) ~= "table" then return end
            for _, category in pairs(questTypes) do
                if type(category) == "table" then
                    for _, quest in ipairs(category) do
                        if type(quest) == "table" and type(quest.Name) == "string" and not claimed[quest.Name] then
                            claimed[quest.Name] = true
                            FireRemote(Remotes.QuestContact, { Action = "ClaimQuest", Name = quest.Name })
                            task.wait(0.5)
                        end
                    end
                end
            end
        end)
        if not ok then
            notyuri("error:", tostring(err))
        end
        task.wait(10)
    end
end
local function HandleSlotPos(act, slot)
    local mapName = GetMapName()
    if not mapName then
        return
    end
    if act == "reset" then
        if slot then
            if Shared.Place.SlotPositions[mapName] then Shared.Place.SlotPositions[mapName][slot] = nil end
            notyuri("ResetPos slot=" .. slot .. " map=" .. mapName)
        else
            Shared.Place.SlotPositions[mapName] = nil
            notyuri("ResetPos all map=" .. mapName)
        end
        SavePositions()
        UpdatePosLabels()
        return
    end
    local char = Plr.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then
        Library:Notify("Character not found", 3)
        return
    end
    local cf = CFrame.new(hrp.Position)
    if not Shared.Place.SlotPositions[mapName] then Shared.Place.SlotPositions[mapName] = {} end
    if act == "set" then
        if not Shared.Place.SlotPositions[mapName][slot] then Shared.Place.SlotPositions[mapName][slot] = {} end
        table.insert(Shared.Place.SlotPositions[mapName][slot], cf)
        local count = #Shared.Place.SlotPositions[mapName][slot]
        notyuri("SetPos slot=" .. slot .. " count=" .. count .. " map=" .. mapName)
    elseif act == "massset" then
        for i = 1, 6 do
            if not Shared.Place.SlotPositions[mapName][i] then Shared.Place.SlotPositions[mapName][i] = {} end
            table.insert(Shared.Place.SlotPositions[mapName][i], cf)
        end
        notyuri("MassSetPos map=" .. mapName)
    end
    SavePositions()
    UpdatePosLabels()
end
local function PopulateRemotes()
    local events = RS:FindFirstChild("RemoteEvents")
    if events then
        local server = events:FindFirstChild("Server")
        if server then
            local gameUnit = GetSafeRemote(server, "GameUnit")
            if gameUnit then Remotes.GameUnit = gameUnit end
            local returnRemote = GetSafeRemote(server, "Return")
            if returnRemote then Remotes.Return = returnRemote end
            local questContact = GetSafeRemote(server, "QuestContact")
            if questContact then Remotes.QuestContact = questContact end
            local createParty = GetSafeRemote(server, "CreateParty")
            if createParty then Remotes.CreateParty = createParty end
            local beginParty = GetSafeRemote(server, "BeginParty")
            if beginParty then Remotes.BeginParty = beginParty end
            local sendParty = GetSafeRemote(server, "SendPartyPackage")
            if sendParty then Remotes.SendPartyPackage = sendParty end
        end
        local readyUp = GetSafeRemote(events, "ReadyUp")
        if readyUp then Remotes.ReadyUp = readyUp end
        local voteSkip = GetSafeRemote(events, "VoteSkip")
        if voteSkip then Remotes.VoteSkip = voteSkip end
        local voteRetry = GetSafeRemote(events, "VoteRetry")
        if voteRetry then Remotes.VoteRetry = voteRetry end
        local voteNext = GetSafeRemote(events, "VoteNext")
        if voteNext then Remotes.VoteNext = voteNext end
    end
end
PopulateRemotes()
task.spawn(function()
    while true do
        local info = GetGameInfo()
        if info then break end
        task.wait(1)
        PopulateRemotes()
    end
    PopulateRemotes()
end)
do
    SafeConnect("WaveChanged", function()
        local info = GetGameInfo()
        return info and info:GetAttributeChangedSignal("Wave")
    end, function()
        local wave = GetWave()
        if wave ~= Shared.LastWave then
            if wave < Shared.LastWave then
                Shared.Place.FailPos = {}
                Shared.Place.SpiralCenter = nil
                Shared.Place.Spiral = nil
                Shared.Place.GridCache = nil
                Shared.Place.GridKey = ""
                Shared.Memo.SkipVoted = false
                Shared.Memo.ReadyFired = false
                notyuri("new match detected, placement state cleared")
            end
            Shared.LastWave = wave
            Shared.WaveStartAt = tick()
            UpdatePosLabels()
        end
    end)
    SafeConnect("MapChanged", function()
        local sv = workspace:FindFirstChild("ServerValues")
        local map = sv and sv:FindFirstChild("Map")
        return map and map.Changed
    end, function()
        Shared.Place.GridCache = nil
        Shared.Place.GridKey = ""
        Shared.Place.SpiralCenter = nil
        Shared.Place.Spiral = nil
        UpdatePosLabels()
    end)
end
Thread("MatchEnd", Func_MatchEnd, true)
local Window = Library:CreateWindow({
        Title = "Yuri",
        Center = true,
        AutoShow = true,
        Resizable = true,
        ShowCustomCursor = false,
        UnlockMouseWhileOpen = false,
        NotifySide = "Left",
        TabPadding = 8,
        MenuFadeTime = 0.2
})
AddInfo(Window)
local Tabs = {
        Main     = Window:AddTab("Main"),
    Player   = Window:AddTab("Player"),
    AutoPlay = Window:AddTab("Auto Play"),
    Webhook  = Window:AddTab("Webhook"),
    Config   = Window:AddTab("Config"),
}
local TB = {
    Main = {
        Left = {
            Autofarm = Tabs.Main:AddLeftTabbox(),
        },
        Right = {
            Autofarm = Tabs.Main:AddRightTabbox(),
        },
    },
}
local TB_Tabs = {
    Autofarm = {
        T1 = TB.Main.Left.Autofarm:AddTab("Game"),
        T2 = TB.Main.Left.Autofarm:AddTab("Macro"),
        T3 = TB.Main.Left.Autofarm:AddTab("Lobby"),
    },
    Autofarm2 = {
        T1 = TB.Main.Right.Autofarm:AddTab("Config"),
        T2 = TB.Main.Right.Autofarm:AddTab("LobbyConfig"),
    },
}
local GB = {
    Player = {
        Left = {
            General = Tabs.Player:AddLeftGroupbox("General"),
            Server  = Tabs.Player:AddLeftGroupbox("Server"),
        },
        Right = {
            Game = Tabs.Player:AddRightGroupbox("Game"),
        },
    },
    Webhook = {
        Left = {
            Webhook = Tabs.Webhook:AddLeftGroupbox("Webhook"),
        },
    },
}
GB.Webhook.Left.Webhook:AddInput("WebhookURL", {
    Text = "Webhook URL",
    Default = "",
})
GB.Webhook.Left.Webhook:AddToggle("WHMatchEnd", {
    Text = "Match Finished",
    Default = false,
})
if not Support.Webhook then
    GB.Webhook.Left.Webhook:AddLabel("<font color='#FFA500'>Executor does not support HTTP requests.</font>", true)
end
AddSliderToggle({ Group = GB.Player.Left.General, Id = "WS", Text = "WalkSpeed", Default = 16, Min = 16, Max = 1000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "TPW", Text = "TPWalk", Default = 1, Min = 1, Max = 30, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "JP", Text = "JumpPower", Default = 50, Min = 0, Max = 500 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "HH", Text = "HipHeight", Default = 2, Min = 0, Max = 10, Rounding = 1 })
GB.Player.Left.General:AddToggle("Noclip", { Text = "Noclip" })
GB.Player.Left.General:AddToggle("AntiKnockback", {
    Text = "Anti Knockback",
    Default = false,
})
GB.Player.Left.General:AddToggle("Disable3DRender", { Text = "Disable 3D Rendering" })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Grav", Text = "Gravity", Default = 196, Min = 0, Max = 500, Rounding = 1 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "Zoom", Text = "Camera Zoom", Default = 128, Min = 128, Max = 10000 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "FOV", Text = "Field of View", Default = 70, Min = 30, Max = 120 })
AddSliderToggle({ Group = GB.Player.Left.General, Id = "LimitFPS", Text = "Set Max FPS", Disabled = not Support.FPS, Default = 60, Min = 5, Max = 360 })
GB.Player.Left.General:AddToggle("FPSBoost", { Text = "FPS Boost" })
GB.Player.Left.Server:AddToggle("AntiAFK", {
    Text = "Anti AFK",
    Default = true,
    Disabled = not Support.Connections,
})
GB.Player.Left.Server:AddToggle("AutoJump", { Text = "Auto Jump" })
GB.Player.Left.Server:AddToggle("AutoReconnect", { Text = "Auto Reconnect" })
GB.Player.Left.Server:AddToggle("NoGameplayPaused", { Text = "No Gameplay Paused" })
GB.Player.Left.Server:AddButton({ Text = "Serverhop", Func = function() Serverhop() end })
GB.Player.Left.Server:AddButton({ Text = "Rejoin", Func = function() Services.TeleportService:Teleport(game.PlaceId, Players.LocalPlayer) end })
AddSliderToggle({ Group = GB.Player.Left.Server, Id = "AutoServerhop", Text = "Auto Serverhop (Minutes)", Default = 30, Min = 0, Max = 300 }, function(state)
    Thread("AutoServerhop", function()
        local lastHop = tick()
        while Toggles.AutoServerhop.Value do
            task.wait(5)
            if not Toggles.AutoServerhop.Value then break end
            if (tick() - lastHop) >= (Options.AutoServerhopValue.Value * 60) then
                Serverhop()
                break
            end
        end
    end, state)
end)
AddSliderToggle({ Group = GB.Player.Left.Server, Id = "AutoRejoin", Text = "Auto Rejoin (Minutes)", Default = 30, Min = 0, Max = 300 }, function(state)
    Thread("AutoRejoin", function()
        local lastRejoin = tick()
        while Toggles.AutoRejoin.Value do
            task.wait(5)
            if not Toggles.AutoRejoin.Value then break end
            if (tick() - lastRejoin) >= (Options.AutoRejoinValue.Value * 60) then
                TeleportService:Teleport(game.PlaceId, Players.LocalPlayer)
                break
            end
        end
    end, state)
end)
GB.Player.Right.Game:AddToggle("InstantPP", { Text = "Instant Prompt" })
GB.Player.Right.Game:AddToggle("Fullbright", { Text = "Fullbright" })
GB.Player.Right.Game:AddToggle("NoFog", { Text = "No Fog" })
AddSliderToggle({ Group = GB.Player.Right.Game, Id = "OverrideTime", Text = "Time Of Day", Default = 12, Min = 0, Max = 24, Rounding = 1 })
local APLeft = Tabs.AutoPlay:AddLeftGroupbox("Auto Play")
APLeft:AddToggle("AutoPlace", { Text = "Auto Place" })
APLeft:AddToggle("AutoUpgrade", { Text = "Auto Upgrade" })
APLeft:AddDropdown("UpgradeMethod", {
    Text = "Upgrade Method",
    Values = {
        "Lowest Level (Spread Upgrade)",
        "Hotbar left to right (until Max)",
        "Randomize",
        "Customize upgrade order (Set below)",
    },
    Default = "Lowest Level (Spread Upgrade)",
})
APLeft:AddToggle("PlaceAndUpgrade", { Text = "Place and Upgrade" })
APLeft:AddToggle("FocusFarm", { Text = "Focus Farm Units" })
AddSliderToggle({ Group = APLeft, Id = "AutoSell", Text = "Auto Sell at Wave", Default = 10, Min = 0, Max = 100, Rounding = 0 })
APLeft:AddDivider()
local APRight = Tabs.AutoPlay:AddRightGroupbox("Limits")
APRight:AddLabel("Place Order per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceOrder" .. i, {
        Text = "Slot " .. i,
        Default = i,
        Min = 1,
        Max = 6,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Place Wave per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceWave" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 50,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Place Limit per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("PlaceLimit" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 10,
        Rounding = 0,
        Compact = true,
    })
end
APRight:AddDivider()
APRight:AddLabel("Upgrade Limit per Slot", true)
for i = 1, 6 do
    APRight:AddSlider("UpgradeLimit" .. i, {
        Text = "Slot " .. i,
        Default = 0,
        Min = 0,
        Max = 30,
        Rounding = 0,
        Compact = true,
    })
end
SafeLabel(APLeft, "Positions", "No positions set")
APLeft:AddDropdown("SetSlotSelect", {
    Text = "Set Slot Position",
    Values = GetSlotDisplayNames(),
    Default = GetSlotDisplayNames()[1] or "",
})
APLeft:AddButton({
    Text = "Set Slot Position",
    Func = function()
        local val = Options.SetSlotSelect and Options.SetSlotSelect.Value or ""
        local slot = SlotDisplayToNumber(val)
        if slot then
            HandleSlotPos("set", slot)
        else
            Library:Notify("Select a slot first", 3)
        end
    end,
})
APLeft:AddButton({ Text = "Save Position for All Slots", Func = function() HandleSlotPos("massset") end })
APLeft:AddDivider()
do
    local function GetResetSlotValues()
        local names = GetSlotDisplayNames()
        table.insert(names, "All Slots")
        return names
    end
    APLeft:AddDropdown("ResetSlotSelect", {
        Text = "Reset Slot Position",
        Values = GetResetSlotValues(),
        Default = "All Slots",
    })
end
APLeft:AddButton({
    Text = "Reset Position",
    Func = function()
        local val = Options.ResetSlotSelect and Options.ResetSlotSelect.Value or "All Slots"
        if val == "All Slots" then
            HandleSlotPos("reset", nil)
        else
            HandleSlotPos("reset", SlotDisplayToNumber(val))
        end
    end,
})
UpdatePosLabels()
TB_Tabs.Autofarm.T1:AddToggle("AutoAbility", { Text = "Auto Tower Ability", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoSkip", { Text = "Auto Skip", Default = false })
AddSliderToggle({ Group = TB_Tabs.Autofarm.T1, Id = "AutoReady", Text = "Auto Ready", Default = 2, Min = 0, Max = 30, Rounding = 1 })
TB_Tabs.Autofarm.T1:AddToggle("AutoReplay", { Text = "Auto Replay", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoNewMap", { Text = "Auto New Map", Default = false })
TB_Tabs.Autofarm.T1:AddToggle("AutoLeave", { Text = "Auto Leave", Default = false })
TB_Tabs.Autofarm2.T1:AddSlider("AutoLeaveValue", {
    Text = "Leave at Wave",
    Default = 10,
    Min = 0,
    Max = 100,
    Rounding = 0,
    Compact = true,
})
TB_Tabs.Autofarm.T2:AddDropdown("MacroSelected", {
    Text = "Select File",
    Values = ListMacros(),
    Default = ListMacros()[1] or "",
})
TB_Tabs.Autofarm.T2:AddInput("FileName", {
    Text = "File Name",
    Default = "",
    Placeholder = "yuriyuri",
})
TB_Tabs.Autofarm.T2:AddDropdown("ReplayMode", {
    Text = "Replay Mode",
    Values = {"Time", "Money"},
    Default = "Time",
})
TB_Tabs.Autofarm.T2:AddToggle("MacroRecord", {
    Text = "Record Macro",
    Default = false,
})
TB_Tabs.Autofarm.T2:AddToggle("LoadMacro", {
    Text = "Play Macro",
    Default = false,
})
SafeLabel(TB_Tabs.Autofarm.T2, "Macro", "Idle")
TB_Tabs.Autofarm.T3:AddToggle("AutoQueue", { Text = "Auto Queue" })
MultiToggle({
    Group = TB_Tabs.Autofarm.T3,
    Id = "AutoSummon",
    Text = "Auto Summon",
    Children = { { Id = "FastSummon", Text = "Fast Summon" } },
})
TB_Tabs.Autofarm.T3:AddToggle("AutoCollectQuests", { Text = "Auto Collect Quests" })
TB_Tabs.Autofarm2.T2:AddDropdown("QueueMap", {
    Text = "Queue Map",
    Values = GetStoryMapNames(),
    Searchable = true,
    Default = "",
})
TB_Tabs.Autofarm2.T2:AddDropdown("QueueAct", {
    Text = "Queue Act",
    Values = { "1", "2", "3", "4", "5", "6" },
    Default = "1",
})
TB_Tabs.Autofarm2.T2:AddDropdown("SummonBanner", {
    Text = "Summon Banner",
    Values = GetBannerNames(),
    Searchable = true,
    Default = "",
})
TB_Tabs.Autofarm2.T2:AddDropdown("SummonAmount", {
    Text = "Summon Amount",
    Values = { "1", "10" },
    Default = "1",
})
EnsureFolderPath(Shared.MDir)
LoadPositions()
Toggles.AntiKnockback:OnChanged(function(state)
    Thread("AntiKnockback", Func_AntiKnockback, state)
end)
Toggles.TPW:OnChanged(function(v)
    Thread("TPW", FuncTPW, v)
end)
Toggles.Noclip:OnChanged(function(v)
    Thread("Noclip", FuncNoclip, v)
end)
Connections.Player_General = RunService.Stepped:Connect(function()
    local Hum = Plr.Character and Plr.Character:FindFirstChildOfClass("Humanoid")
    if Hum then
        if Toggles.WS.Value then Hum.WalkSpeed = Options.WSValue.Value end
        if Toggles.JP.Value then
            Hum.JumpPower = Options.JPValue.Value
            Hum.UseJumpPower = true
        end
        if Toggles.HH.Value then Hum.HipHeight = Options.HHValue.Value end
    end
    workspace.Gravity = Toggles.Grav.Value and Options.GravValue.Value or 192
    if Toggles.FOV.Value then workspace.CurrentCamera.FieldOfView = Options.FOVValue.Value end
    if Toggles.Zoom.Value then Plr.CameraMaxZoomDistance = Options.ZoomValue.Value end
end)
task.spawn(function()
    while task.wait() do
        if Toggles.Fullbright.Value then
            Lighting.Brightness = 2
            Lighting.ClockTime = 14
            Lighting.GlobalShadows = false
        elseif Toggles.OverrideTime.Value then
            Lighting.ClockTime = Options.OverrideTimeValue.Value
        end
        if Toggles.NoFog.Value then Lighting.FogEnd = 9e9 end
        if Library.Unloaded then break end
    end
end)
Options.LimitFPSValue:OnChanged(function()
    if Toggles.LimitFPS.Value then
        setfpscap(Options.LimitFPSValue.Value)
    end
end)
Toggles.LimitFPS:OnChanged(function(v)
    if not v and Support.FPS then
        setfpscap(2000)
    end
end)
Toggles.Disable3DRender:OnChanged(function(v) RunService:Set3dRenderingEnabled(not v) end)
Toggles.FPSBoost:OnChanged(function(state)
    ApplyFPSBoost(state)
end)
Toggles.AutoReconnect:OnChanged(function(state)
    if state then Func_AutoReconnect() end
end)
Toggles.NoGameplayPaused:OnChanged(function(state)
    Thread("NoGameplayPaused", SafeLoop("Anti-Pause", Func_NoGameplayPaused), state)
end)
Toggles.AutoJump:OnChanged(function(state)
    Thread("AutoJump", function()
        while Toggles.AutoJump.Value do
            local hum = Plr.Character and Plr.Character:FindFirstChildWhichIsA("Humanoid")
            if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
            Services.VirtualInputManager:SendKeyEvent(true, Enum.KeyCode.W, false, game)
            task.wait(0.3)
            Services.VirtualInputManager:SendKeyEvent(false, Enum.KeyCode.W, false, game)
            task.wait(5)
        end
    end, state)
end)
game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(prompt)
    if Toggles.InstantPP and Toggles.InstantPP.Value then
        prompt.HoldDuration = 0
    end
end)
local function RunAntiAFK()
    if Shared.antiAFKConn then Shared.antiAFKConn:Enable() return end
    local GC = getconnections or get_signal_cons
    if GC then
        local conns = GC(Players.LocalPlayer.Idled)
        local target = conns and conns[1]
        if target and target.Disable then
            target:Disable()
            Shared.antiAFKConn = target
            return
        end
        for _, c in pairs(conns or {}) do
            if c.Disable then
                c:Disable()
                Shared.antiAFKConn = c
                return
            elseif c.Disconnect then
                c:Disconnect()
                return
            end
        end
    end
    Players.LocalPlayer.Idled:Connect(function()
        VirtualUser:CaptureController()
        VirtualUser:ClickButton2(Vector2.new())
    end)
end
Toggles.AntiAFK:OnChanged(function(state)
    if state then
        RunAntiAFK()
    elseif Shared.antiAFKConn and Shared.antiAFKConn.Enable then
        Shared.antiAFKConn:Enable()
    end
end)
if Toggles.AntiAFK.Value then RunAntiAFK() end
Toggles.AutoPlace:OnChanged(function(state)
    Thread("AutoPlace", SafeLoop("AutoPlace", Func_AutoPlace), state)
end)
Toggles.AutoUpgrade:OnChanged(function(state)
    Thread("AutoUpgrade", SafeLoop("AutoUpgrade", Func_AutoUpgrade), state)
end)
Toggles.AutoAbility:OnChanged(function(state)
    Thread("AutoAbility", SafeLoop("AutoAbility", Func_AutoAbility), state)
end)
Toggles.AutoSkip:OnChanged(function(state)
    Thread("AutoSkip", SafeLoop("AutoSkip", Func_AutoSkip), state)
end)
Toggles.AutoReady:OnChanged(function(state)
    Thread("AutoReady", SafeLoop("AutoReady", Func_AutoReady), state)
end)
Toggles.AutoLeave:OnChanged(function(state)
    Thread("AutoLeave", SafeLoop("AutoLeave", function()
        Func_AutoAtWave(Toggles.AutoLeave, Options.AutoLeaveValue, "leave")
    end), state)
end)
Toggles.AutoSell:OnChanged(function(state)
    Thread("AutoSell", SafeLoop("AutoSell", function()
        Func_AutoAtWave(Toggles.AutoSell, Options.AutoSellValue, "sell")
    end), state)
end)
Toggles.AutoQueue:OnChanged(function(state)
    Thread("AutoQueue", SafeLoop("AutoQueue", Func_AutoQueue), state)
end)
Toggles.AutoSummon:OnChanged(function(state)
    Thread("AutoSummon", SafeLoop("AutoSummon", Func_AutoSummon), state)
end)
Toggles.AutoCollectQuests:OnChanged(function(state)
    Thread("AutoCollectQuests", SafeLoop("AutoCollectQuests", Func_AutoCollectQuests), state)
end)
Toggles.MacroRecord:OnChanged(function(state)
    Thread("MacroRecord", function()
        Func_MacroRecord(state)
    end, state)
end)
Toggles.LoadMacro:OnChanged(function(state)
    Thread("LoadMacro", function()
        Func_MacroReplay()
    end, state)
end)
if Options.MacroSelected.Value and Options.MacroSelected.Value ~= "" then
    Shared.MState.Load = LoadMacro(Options.MacroSelected.Value)
end
Options.MacroSelected:OnChanged(function()
    local name = Options.MacroSelected.Value
    Shared.MState.Load = (type(name) == "string" and name ~= "") and LoadMacro(name) or nil
end)
local MenuGroup = Tabs.Config:AddLeftGroupbox("Menu")
MenuGroup:AddToggle("AutoShowUI", {
    Text = "Auto Show UI",
    Default = true,
})
MenuGroup:AddToggle("KeybindMenuOpen", {
        Default = Library.KeybindFrame.Visible,
        Text = "Open Keybind Menu",
        Callback = function(value)
                Library.KeybindFrame.Visible = value
        end,
})
MenuGroup:AddToggle("ShowCustomCursor", {
        Text = "Custom Cursor",
        Default = false,
        Callback = function(Value)
                Library.ShowCustomCursor = Value
        end,
})
MenuGroup:AddDropdown("NotificationSide", {
        Values = { "Left", "Right" },
        Default = "Right",
        Text = "Notification Side",
        Callback = function(Value)
                Library:SetNotifySide(Value)
        end,
})
MenuGroup:AddDropdown("DPIDropdown", {
        Values = { "50%", "75%", "100%", "125%", "150%", "175%", "200%" },
        Default = "100%",
        Text = "DPI Scale",
        Callback = function(Value)
                Value = Value:gsub("%%", "")
                local DPI = tonumber(Value)
                Library:SetDPIScale(DPI)
        end,
})
MenuGroup:AddDivider()
MenuGroup:AddLabel("Menu bind")
        :AddKeyPicker("MenuKeybind", { Default = "U", NoUI = true, Text = "Menu keybind" })
MenuGroup:AddButton("Unload", function()
    getgenv().ayasemiyatongekissazumirisa = false
    Shared.MState.Rec = false
    Shared.MState.Rep = false
    Shared.MState.Cur = nil
    Shared.MState.Load = nil
    Shared.MState.Pending = {}
    PCubeRelease()
    if Shared.antiAFKConn and Shared.antiAFKConn.Enable then pcall(function() Shared.antiAFKConn:Enable() end) end
    if Support.FPS then pcall(function() setfpscap(2000) end) end
    Cleanup(Connections)
    Cleanup(Flags)
        Library:Unload()
end)
Library.ToggleKeybind = Options.MenuKeybind
ThemeManager:SetLibrary(Library)
SaveManager:SetLibrary(Library)
ThemeManager:SetFolder("Yuri")
SaveManager:SetFolder("Yuri/UAX")
SaveManager:IgnoreThemeSettings()
SaveManager:SetIgnoreIndexes({ "MenuKeybind" })
SaveManager:BuildConfigSection(Tabs.Config)
SaveManager:SetLoadingOrder(true, { "Dropdown", "Slider", "ColorPicker", "KeyPicker", "Input", "Toggle" })
task.defer(function()
    SaveManager:LoadAutoloadConfig()
end)
Library:Notify("Script loaded.", 2)
Library:Notify("Yuri!", 5)
end)
if not eh_success then
    Library:Notify("ERROR: " .. tostring(err), 4)
    notyuri("ERROR: " .. tostring(err))
end
